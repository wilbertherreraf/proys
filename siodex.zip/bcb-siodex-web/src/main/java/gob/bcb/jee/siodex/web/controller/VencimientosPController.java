package gob.bcb.jee.siodex.web.controller;

import gob.bcb.jee.siodex.QL.VencimientoQLBeanLocal;
import gob.bcb.jee.siodex.controller.BaseBean;
import gob.bcb.jee.siodex.entities.Vencimiento;
import gob.bcb.jee.siodex.exception.DataException;
import gob.bcb.jee.siodex.util.File;
import gob.bcb.jee.siodex.util.UtilsDate;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

// The @Model stereotype is a convenience mechanism to make this a request-scoped bean that has an
// EL name
// Read more about the @Model stereotype in this FAQ:
// http://sfwk.org/Documentation/WhatIsThePurposeOfTheModelAnnotation
//@Model
@ManagedBean(name = "vencimientosPController")
@ViewScoped
public class VencimientosPController extends BaseBean {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	static final Logger logger = Logger.getLogger(VencimientosPController.class);

	@Inject
	private VencimientoQLBeanLocal vencimientoQLBeanLocal;

	private Date fechaDesde;
	private Date fechaHasta;

	private Vencimiento liq;
	private String contextPath;
	private String SIODEX_PARAM = "";
	private List<Vencimiento> listaVen = new ArrayList<Vencimiento>();

	public List<Vencimiento> getListaVen() {
		return listaVen;
	}

	@PostConstruct
	public void inicio() throws Exception {
		logger.info("PostConstruct VencimientosHistoricos - " + this.getClass().getName());
		recuperarParametros();
		// obteniendo el path de la aplicacion
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		SIODEX_PARAM = (String) ((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false))
				.getAttribute("SIODEX_PARAM");

		String codEnt = getVisitBean().getParticipante().getCodPte();
		logger.info("Opcion menu SIODEX_PARAM " + SIODEX_PARAM + " codEnt: " + codEnt);

		contextPath = request.getContextPath();

		liq = new Vencimiento();
		crearObjetosPorDefecto();
		
		buscar(fechaDesde, fechaHasta);
	}

	public void buscar(Date fechadesde, Date fechahasta) throws DataException {

		String codEnt = getVisitBean().getParticipante().getCodPte();

		listaVen = vencimientoQLBeanLocal.listaVencimiento(null, null, codEnt, fechadesde, fechahasta);
		
		
	}
	public String buscarVencimientos() {

		try {
			logger.info("buscarVencimientos Fec " + fechaDesde + " " + fechaHasta);

			buscar(fechaDesde, fechaHasta);
		} catch (DataException e) {
			logger.error("Error al obtener vencimientos " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage("errorcito",
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Ocurrió un error: " + e.getMessage(), null));
		}
		return "";
	}

	public String botonIrEditarLiq() throws IOException {

		logger.info("detalle: " + liq.getLiqCodigo());
		String codigo = liq.getLiqCodigo();
			((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("codigo", codigo);

		FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/detalleven_edit.jsf");

		return "/pages/detalleven_edit";			
	}
	public String botonDetalle() throws IOException {

		logger.info("detalle: " + liq.getLiqCodigo());
		String codigo = liq.getLiqCodigo();
		if ((liq.getCveEstado().equals("A") || liq.getCveEstado().equals("S") || liq.getCveEstado().equals("P") || liq.getCveEstado().equals("E"))){
			File file = new File();
			file.setData(liq.getDocPdf()); // cargando el byte del archivo desde
											// bbdd
			file.setName("estado.pdf");
			if (liq.getDocPdf() != null) {
				file.setLength(liq.getDocPdf().length);
			} else {
				file.setLength(0);
			}
			// cargando prestamo
			((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("codigo", codigo);
			((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("file2", file);

			FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/detalleVen.jsf");

			return "/pages/detalleVen";			
		} else {
			((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("codigo", codigo);

			FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/detalleOperacion.jsf");

			return "/pages/detalleOperacion";			
		}
	}

	public Vencimiento getLiq() {
		return liq;
	}

	public void setLiq(Vencimiento liq) {
		this.liq = liq;
	}

	public Date getFechaDesde() {
		return fechaDesde;
	}

	public void setFechaDesde(Date fechaDesde) {
		this.fechaDesde = fechaDesde;
	}

	public Date getFechaHasta() {
		return fechaHasta;
	}

	public void setFechaHasta(Date fechaHasta) {
		this.fechaHasta = fechaHasta;
	}

	private void crearObjetosPorDefecto() {
		fechaDesde = UtilsDate.restarDias(new Date(), -3);
		fechaHasta = UtilsDate.restarDias(new Date(), 3);
	}

}
