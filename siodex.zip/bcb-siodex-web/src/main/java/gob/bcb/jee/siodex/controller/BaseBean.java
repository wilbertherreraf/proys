package gob.bcb.jee.siodex.controller;

import gob.bcb.jee.siodex.entities.LogAuditoria;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.inject.Inject;

public class BaseBean implements Serializable{
	@Inject
	private VisitBean visitBean;

	public VisitBean getVisitBean() {
		return visitBean;
	}

	public void setVisitBean(VisitBean visitBean) {
		this.visitBean = visitBean;
	}
	public void recuperarParametros() {
		try {
			Map<String, String> sesiones = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
			visitBean.getParametro().putAll(sesiones);
		} catch (Exception e) {
			throw new RuntimeException("Error al recuperar visit " + e.getMessage());
		}
	}
	/**
	 * retorna logauditoria sin codtransaccion
	 * @return
	 */
	public LogAuditoria getLogAuditoriaFromVisit(){
		LogAuditoria logAuditoria = new LogAuditoria();
		logAuditoria.setCodUsuario(visitBean.getUsuario().getUsrLogin());
		logAuditoria.setEstacion(visitBean.getUsuario().getUsrIpasignado());
		logAuditoria.setFechaHora(new Date());
		return logAuditoria;
	}
	
}
