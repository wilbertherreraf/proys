package gob.bcb.jee.siodex.util;

/**
 * Clase que realiza la manipulacion de un File
 * 
 * 
 * @author eibanez
 * 
 */
public class File {

	private String Name;
	private String mime;
	private long length;
	private byte[] data;

	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		this.data = data;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
		int extDot = name.lastIndexOf('.');
		if (extDot > 0) {
			String extension = name.substring(extDot + 1);
			if ("docx".equals(extension)) {
				mime = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
			} else if ("xlsx".equals(extension)) {
				mime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
			} else if ("doc".equals(extension)) {
				mime = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
			} else if ("xls".equals(extension)) {
				mime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
			} else if ("bmp".equals(extension)) {
				mime = "image/bmp";
			} else if ("jpg".equals(extension)) {
				mime = "image/jpeg";
			} else if ("jpeg".equals(extension)) {
				mime = "image/jpeg";
			} else {
				mime = "image/unknown";
			}
		}
	}

	public long getLength() {
		return length;
	}

	public void setLength(long length) {
		this.length = length;
	}

	public String getMime() {
		return mime;
	}

	public void setMime(String mime) {
		this.mime = mime;
	}
}
