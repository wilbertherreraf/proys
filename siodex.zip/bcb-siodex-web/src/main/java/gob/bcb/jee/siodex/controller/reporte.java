package gob.bcb.jee.siodex.controller;

import gob.bcb.jee.siodex.QL.CoinQLBeanLocal;
import gob.bcb.jee.siodex.QL.ConexionSQLBeanLocal;
import gob.bcb.jee.siodex.QL.LiquidacionQLBeanLocal;
import gob.bcb.jee.siodex.QL.VencimientoQLBeanLocal;
import gob.bcb.jee.siodex.entities.Liquidacion;
import gob.bcb.jee.siodex.entities.Vencimiento;
import gob.bcb.jee.siodex.util.CadenaEncDec;

import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.sql.Connection;
import java.text.DateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporter;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JRRuntimeException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.util.JRLoader;

import org.apache.commons.lang.ArrayUtils;
import org.apache.log4j.Logger;

/**
 * Servlet implementation class reporte
 */
public class reporte extends HttpServlet {

	private static final long serialVersionUID = 1L;

	static final Logger logger = Logger.getLogger(reporte.class);

	@Inject
	private ConexionSQLBeanLocal conexionSQLBeanLocal;
	@Inject
	private LiquidacionQLBeanLocal liquidacionQLBeanLocal;
	@Inject
	private CoinQLBeanLocal coinQLBeanLocal;
	@Inject
	private VencimientoQLBeanLocal vencimientoQLBeanLocal;

	/**
	 * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
	 * methods.
	 * 
	 * @param request
	 *            servlet request
	 * @param response
	 *            servlet response
	 * @throws ServletException
	 *             if a servlet-specific error occurs
	 * @throws IOException
	 *             if an I/O error occurs
	 */
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		Connection conexion = null;
		logger.info("=======ooOOInicio ReporteOOoo=======");
		try {

			// Estableciendo la cabedera del reporte en pdf
			response.setContentType("application/pdf");

			response.setHeader("Content-Disposition", "attachment; filename=\"reporte.pdf\";");
			response.setHeader("Cache-Control", "no-cache");
			response.setHeader("Pragma", "no-cache");
			response.setDateHeader("Expires", 0);
			// //parametros leidos de la session

			String tipo = request.getParameter("tipo");
		
			String codigoLiq = request.getParameter("cod");
			
			// variable para determinar si viene de WS
			String codRepo = request.getParameter("codRepo");
			
			if (codRepo != null){

				Map<String, String> decodeMap = CadenaEncDec.decode(codRepo);
				logger.info("URL Reporte Decodificado " + ArrayUtils.toString(decodeMap) + "\nUrl orig.: " + codRepo);
				codigoLiq = decodeMap.get("cod");
				
				tipo = decodeMap.get("tipo");
				
			}
			
			String URL_SUBREPORT = getServletContext().getRealPath("/jasper/");

			logger.info("Reporte: codigoLiq:" + codigoLiq  + "; tipo:" + tipo + "; ruta subreporte:" + URL_SUBREPORT);
			
			Liquidacion liquidacion = liquidacionQLBeanLocal.getLiquidacion(codigoLiq);
			
			if (liquidacion == null){
				throw new RuntimeException("Liquidacion inexistente " + codigoLiq);
			}
			logger.info("liquidacion para reporte: " + liquidacion.toString());
			
			String nombreReporte = "";
			
			// Para pasarle parametros al reporte
			Map<String, Object> parametros = new HashMap<String, Object>();
			parametros.put("codigo", codigoLiq);
			parametros.put("SUBREPORT_DIR", URL_SUBREPORT + "/");
			
			Date fechaTc = liquidacion.getFechaTc();
			
			BigDecimal tipoCambioV = coinQLBeanLocal.getTC(fechaTc, "35");
			BigDecimal tipoCambioC = coinQLBeanLocal.getTC(fechaTc, "34");			
			
			parametros.put("tc", tipoCambioC);
			parametros.put("tcV", tipoCambioV);
			
			if (tipo.equals("AUT")) {
				nombreReporte = "autorizacion.jasper";
				
			} else if (tipo.equals("CON")) {
				String prestamo = request.getParameter("prestamo");
				parametros.put("prestamo", prestamo);

				nombreReporte = "confirmacion.jasper";
				
			} else if (tipo.equals("REPCONFIRM")) {
				response.setHeader("Content-Type", "application/pdf");
				//response.setIntHeader("Content-Length", (int) file.getLength());

				response.setHeader("Content-Disposition", "attachment; filename=\"adjunto" + codigoLiq + ".pdf\";");
				response.setHeader("Cache-Control", "no-cache");
				response.setHeader("Pragma", "no-cache");
				response.setHeader("Content-Disposition", "inline");
				response.setDateHeader("Expires", 0);
				
				Vencimiento vencimiento = vencimientoQLBeanLocal.getVencimiento(null, 0, codigoLiq);
				
				String titulo = vencimiento.getAcreedor() + " - " + vencimiento.getRefAcre() + " - " + vencimiento.getPrestamo();
				String prestamo = "PAGO PRESTAMO " + titulo + " - VENCIMIENTO " + DateFormat.getDateInstance().format(vencimiento.getFechaVenc());
				
				parametros.put("prestamo", prestamo);
				parametros.put("TITULO", "Reporte de Confirmación de Pago");
				parametros.put("ref_acreedor", vencimiento.getVcDatosAdic().getAcreedor() + " " + vencimiento.getVcDatosAdic().getRefAcreedor());
				parametros.put("descripcion", vencimiento.getVcDatosAdic().getProyecto());
				parametros.put("deudor",  vencimiento.getVcDatosAdic().getSiglaProv() + " " + vencimiento.getVcDatosAdic().getProveedor());
				
				nombreReporte = "confirmacion.jasper";
				nombreReporte = "confpago.jasper";				
				
			} else if (tipo.equals("REPDB")) {
				gob.bcb.jee.siodex.util.File file = new gob.bcb.jee.siodex.util.File();
				file.setData(liquidacion.getDocPdf()); // cargando el byte del archivo desde
												// bbdd
				file.setName("estado.pdf");
				if (liquidacion.getDocPdf() != null) {
					file.setLength(liquidacion.getDocPdf().length);
				} else {
					logger.error("Archivo liquidacion[" + codigoLiq + "] nulo ");
					file.setLength(0);
				}
			
				logger.info("file Length :" + file.getLength());				
				response.setHeader("Content-Type", "application/pdf");
				response.setIntHeader("Content-Length", (int) file.getLength());

				response.setHeader("Content-Disposition", "attachment; filename=\"adjunto" + codigoLiq + ".pdf\";");
				response.setHeader("Cache-Control", "no-cache");
				response.setHeader("Pragma", "no-cache");
				response.setHeader("Content-Disposition", "inline");
				response.setDateHeader("Expires", 0);
				
				OutputStream outputStream = response.getOutputStream();

				outputStream.write(file.getData());
				outputStream.close();
				logger.info("FIN reporte [" + codigoLiq + "]");				
				return;
			}
			String reportFileName = URL_SUBREPORT + "//" + nombreReporte;
			java.io.File reportFile = new java.io.File(reportFileName);
			
			if (!reportFile.exists())
				throw new JRRuntimeException("Archivo " + nombreReporte
						+ " no encontrado. El reporte no puede ser visualizado, comunique al administrador del sistema.");			

			parametros.put("USUARIO", request.getRemoteAddr());			
			logger.info("Parametros reporte reportFileName: " + reportFileName);			
			logger.info("Parametros reporte[" + nombreReporte + "," + tipo + "] " + ArrayUtils.toString(parametros));
			
			parametros.put("BaseDir", reportFile.getParentFile());
			
			conexion = conexionSQLBeanLocal.getConexion();

			// Cargando el archivo creado en iReport
			JasperReport reporte = (JasperReport) JRLoader.loadObjectFromFile(getServletContext().getRealPath("/jasper/" + nombreReporte));

			// creamos enar el reporte con datos obtenidos de distintas fuentes
			// de
			// datos (una de estas fuentes es la sentencia SQL que escribimos al
			// generar el reporte con el wizard
			

			JasperPrint jasperPrint = JasperFillManager.fillReport(reporte, parametros, conexion);
			// Creamos objeto que sera un pdf

			JRExporter exporter = new JRPdfExporter();

			// asigna a nuestro exporter el jasperPrint (el reporte con datos)
			// que
			// creamos anteriormente

			exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);

			// Creando objeto que permite la salida del archivo binario pdf
			ServletOutputStream out = response.getOutputStream();
			
			// dice al exporter que la salida sera tratada por el browser
			exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, out);

			exporter.exportReport();

		} catch (JRException e) {
			logger.error("Error JRE: " + e.getMessage(), e);
		} catch (Exception ex) {
			logger.error("Error al cargar el reporte: " + ex.getMessage(), ex);
		} finally {
			try {
				if (conexion != null)
					conexion.close();
			} catch (Exception e1) {
				logger.info("Error al cerrar conexion: " + e1.getMessage(), e1);
			}
		}
	}

	/**
	 * Handles the HTTP <code>GET</code> method.
	 * 
	 * @param request
	 *            servlet request
	 * @param response
	 *            servlet response
	 * @throws ServletException
	 *             if a servlet-specific error occurs
	 * @throws IOException
	 *             if an I/O error occurs
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * Handles the HTTP <code>POST</code> method.
	 * 
	 * @param request
	 *            servlet request
	 * @param response
	 *            servlet response
	 * @throws ServletException
	 *             if a servlet-specific error occurs
	 * @throws IOException
	 *             if an I/O error occurs
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * Returns a short description of the servlet.
	 * 
	 * @return a String containing servlet description
	 */
	@Override
	public String getServletInfo() {
		return "Short description";
	}
}
