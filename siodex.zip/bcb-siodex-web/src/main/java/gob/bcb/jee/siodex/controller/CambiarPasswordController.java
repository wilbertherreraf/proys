package gob.bcb.jee.siodex.controller;

import gob.bcb.ejb.seguridad.entity.AxsUsuario;
import gob.bcb.ejb.seguridad.services.AdministrarUsuarioMLBeanRemote;
import gob.bcb.jee.siodex.util.Util;

import java.io.Serializable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.NotNull;

import org.apache.log4j.Logger;

@ManagedBean(name = "cambiarPasswordController")
@ViewScoped
public class CambiarPasswordController implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	static final Logger logger = Logger.getLogger(CambiarPasswordController.class);
	
	@NotNull(message = "Campo es requerido")
	private String passworActual;
	@NotNull(message = "Campo es requerido")
	private String passworNuevo;
	@NotNull(message = "Campo es requerido")
	private String passworNuevoRep;	
	
	private String tituloError;
	private String mensajeError;
	private boolean mostrarError = false;
	
	@Inject
	HttpServletRequest request;
	@Inject
	private Util util;

	public CambiarPasswordController() {
	}

	@PostConstruct
	public void inicio() {

	}

	public String guardarModificacion() {
		
		// verificadno validez de la contraseña ingresada
		try {
			AdministrarUsuarioMLBeanRemote administrarUsuarioMLBeanRemote = util.consumirEJBSeguridad(AdministrarUsuarioMLBeanRemote.class);
			
			String codUsuario = request.getUserPrincipal().getName();
			
			// verificando si la contraseña es correcta
			boolean esCorrecta = administrarUsuarioMLBeanRemote.verificarPasswordUsuario(codUsuario, passworActual);
			
			if(esCorrecta){
				
				// verificando que la nueva no sea igual a la anterior
				if(!passworActual.equals(passworNuevo)){
					
					// verificando si ambas contraseñas nuevas
					if(passworNuevo.equals(passworNuevoRep)){
					
						if(verficaFortaleza(passworNuevo)){
							AxsUsuario usuarioModificar = administrarUsuarioMLBeanRemote.buscarUsuario(codUsuario);
						
							administrarUsuarioMLBeanRemote.modificarUsuario(usuarioModificar, passworNuevo);
							System.out.println("Modificación correcta...");	
							logger.info("Modificación correcta...");
						
							mostrarError = true;
							tituloError = "CAMBIAR CONTRASEÑA";
							mensajeError = "La contraseña se modificó correctamente";
						
						} else {
							System.out.println("Error de fortaleza de contraseña");
							logger.info("Error de fortaleza de contraseña");
							
							mostrarError = true;
							tituloError = "CAMBIAR CONTRASEÑA";
							mensajeError = "Error de fortaleza de contraseña";
						}
					
					} else {
						System.out.println("Contraseñas introducidas no son iguales");
						logger.info("Contraseñas introducidas no son iguales");
					
						mostrarError = true;
						tituloError = "CAMBIAR CONTRASEÑA";
						mensajeError = "Contraseñas introducidas no son iguales";
					}
				} else {
					System.out.println("La nueva contraseña no puede ser igual a la anterior");
					logger.info("La nueva contraseña no puede ser igual a la anterior");
					
					mostrarError = true;
					tituloError = "CAMBIAR CONTRASEÑA";
					mensajeError = "La nueva contraseña no puede ser igual a la anterior";
				}
				
			} else {
				System.out.println("Contraseña no es correcta");
				logger.info("Contraseña no es correcta");
				
				mostrarError = true;
				tituloError = "CAMBIAR CONTRASEÑA";
				mensajeError = "Contraseña no es correcta";
			}
			
			
		} catch (Exception e) {
			logger.info("Se produjo un error al cambiar la contraseña");
			mostrarError = true;
			tituloError = "CAMBIAR CONTRASEÑA";
			mensajeError = "Se produjo un error al cambiar la contraseña";
			
			e.printStackTrace();
		}
		
		return "";
	}
	
	public String botonRetornar() {
		
		mostrarError = false;
		return "";
	}
	
	/**
	 * Metodo que verifica
	 * 
	 * @param claveA
	 * @return
	 */
	private static boolean verficaFortaleza(String claveA) {
		boolean resultado = false;
		if (claveA.length() >= 8) {
			Pattern pattern = Pattern.compile(".*[A-Z]+.*");
			Matcher matcher = pattern.matcher(claveA);
			if (matcher.find()) {
				pattern = Pattern.compile(".*[0-9]+.*");
				matcher = pattern.matcher(claveA);
				if (matcher.find()) {
					pattern = Pattern.compile(".*[a-z]+.*");
					matcher = pattern.matcher(claveA);
					if (matcher.find()) {
						resultado = true;
					}
				}
			}
		}
		return resultado;
	}
	
	public String getPassworActual() {
		return passworActual;
	}

	public void setPassworActual(String passworActual) {
		this.passworActual = passworActual;
	}

	public String getPassworNuevo() {
		return passworNuevo;
	}

	public void setPassworNuevo(String passworNuevo) {
		this.passworNuevo = passworNuevo;
	}

	public String getPassworNuevoRep() {
		return passworNuevoRep;
	}

	public void setPassworNuevoRep(String passworNuevoRep) {
		this.passworNuevoRep = passworNuevoRep;
	}

	public String getTituloError() {
		return tituloError;
	}

	public void setTituloError(String tituloError) {
		this.tituloError = tituloError;
	}

	public String getMensajeError() {
		return mensajeError;
	}

	public void setMensajeError(String mensajeError) {
		this.mensajeError = mensajeError;
	}

	public boolean isMostrarError() {
		return mostrarError;
	}

	public void setMostrarError(boolean mostrarError) {
		this.mostrarError = mostrarError;
	}
	
}
