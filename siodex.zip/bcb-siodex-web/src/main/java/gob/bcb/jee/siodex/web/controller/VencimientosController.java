package gob.bcb.jee.siodex.web.controller;

import gob.bcb.jee.siodex.QL.VencimientoQLBeanLocal;
import gob.bcb.jee.siodex.controller.BaseBean;
import gob.bcb.jee.siodex.entities.Vencimiento;
import gob.bcb.jee.siodex.exception.DataException;
import gob.bcb.jee.siodex.util.File;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

// The @Model stereotype is a convenience mechanism to make this a request-scoped bean that has an
// EL name
// Read more about the @Model stereotype in this FAQ:
// http://sfwk.org/Documentation/WhatIsThePurposeOfTheModelAnnotation
//@Model
@ManagedBean(name = "vencimientosController")
@ViewScoped
public class VencimientosController extends BaseBean {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	static final Logger logger = Logger.getLogger(VencimientosController.class);

	@Inject
	private VencimientoQLBeanLocal vencimientoQLBeanLocal;

	private String nombre = "";

	private List<Vencimiento> listaVen = new ArrayList<Vencimiento>();

	private Vencimiento liq;
	private String contextPath;

	@PostConstruct
	public void inicio() {
		logger.info("PostConstruct en vencimiento: ");
		// obteniendo el path de la aplicacion
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		contextPath = request.getContextPath();
		recuperarParametros();
		String codEnt = getVisitBean().getParticipante().getCodPte();
		logger.info("codEnt: " + codEnt);

		liq = new Vencimiento();

		try {
			listaVen = vencimientoQLBeanLocal.listaVencimiento("P", codEnt);
			logger.info("lista: " + (listaVen == null ? "NULL" : listaVen.size()));			
		} catch (Exception e) {
			logger.error("Error al obtener lista vencimientos " + e.getMessage());
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Ocurrió un error: " + e.getMessage(), null));
		}


	}

	public String botonDetalle() throws IOException {

		logger.info("Detalle2: " + liq.getPtmCodigo());

		String codigo = liq.getLiqCodigo();
		File file = new File();
		file.setData(liq.getDocPdf()); // cargando el byte del archivo desde
										// bbdd
		file.setName("estado.pdf");
		if (liq.getDocPdf() != null) {
			file.setLength(liq.getDocPdf().length);
		} else {
			file.setLength(0);
		}

		// cargando prestamo
		((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("codigo", codigo);
		((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("file2", file);

		FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/detalleVen.jsf");

		return "/pages/detalleVen";
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Vencimiento getLiq() {
		return liq;
	}

	public void setLiq(Vencimiento liq) {
		this.liq = liq;
	}

	public List<Vencimiento> getListaVen() {
		return listaVen;
	}

}
