package gob.bcb.jee.siodex.web.controller;

import gob.bcb.jee.siodex.QL.MensajeQLBeanLocal;
import gob.bcb.jee.siodex.controller.MenuController;
import gob.bcb.jee.siodex.entities.Mensaje;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

// The @Model stereotype is a convenience mechanism to make this a request-scoped bean that has an
// EL name
// Read more about the @Model stereotype in this FAQ:
// http://sfwk.org/Documentation/WhatIsThePurposeOfTheModelAnnotation
//@Model
@ManagedBean(name = "mensajesModificarController")
@ViewScoped
public class MensajesModificarController implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	static final Logger logger = Logger.getLogger(MensajesModificarController.class);

	@Inject
	private MensajeQLBeanLocal mensajeQLBeanLocal;

	private List<Mensaje> listaMen = new ArrayList<Mensaje>();

	private Mensaje men;
	private String contextPath;

	public List<Mensaje> getListaMen() {
		return listaMen;
	}

	@PostConstruct
	public void inicio() {

		// obteniendo el path de la aplicacion
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		contextPath = request.getContextPath();

		men = new Mensaje();

		listaMen = mensajeQLBeanLocal.listaMensajeOtros("M");

		logger.info("lista: " + (listaMen == null ? "NULL" : listaMen.size()));

	}

	public String botonDetalle() throws IOException {
		logger.info("detalle: " + men.getMenSwift());

		String ptm = men.getPtmCodigo();
		int tramo = men.getTraCodigo();
		String codigo = men.getMenCodigo();
		int swift = men.getMenSwift();

		// cargando prestamo
		((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("ptm", ptm);
		((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("tramo", tramo);
		((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("codigo", codigo);
		((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("swift", swift);

		HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);

		session.removeAttribute("detalleMenModifController");

		FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/detalleMenModif.jsf");

		return "/pages/detalleMenModif";
	}

	public Mensaje getMen() {
		return men;
	}

	public void setMen(Mensaje men) {
		this.men = men;
	}

}
