package gob.bcb.jee.siodex.web.controller;

import gob.bcb.jee.siodex.QL.MensajeDatosQLBeanLocal;
import gob.bcb.jee.siodex.QL.MensajeEstadoQLBeanLocal;
import gob.bcb.jee.siodex.QL.MensajeQLBeanLocal;
import gob.bcb.jee.siodex.controller.BaseBean;
import gob.bcb.jee.siodex.entities.MensajeEstado;
import gob.bcb.jee.siodex.entities.MensajeEstadoPK;
import gob.bcb.jee.siodex.entities.Mensaje;
import gob.bcb.jee.siodex.entities.MensajeDatos;
import gob.bcb.jee.siodex.entities.Datos;
import gob.bcb.jee.siodex.service.MensajeSwiftBeanLocal;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

// The @Model stereotype is a convenience mechanism to make this a request-scoped bean that has an
// EL name
// Read more about the @Model stereotype in this FAQ:
// http://sfwk.org/Documentation/WhatIsThePurposeOfTheModelAnnotation
//@Model
@ManagedBean(name = "detalleMenController")
@ViewScoped
public class DetalleMenController extends BaseBean {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	static final Logger logger = Logger.getLogger(DetalleMenController.class);

	@Inject
	private MensajeQLBeanLocal mensajeQLBeanLocal;

	@Inject
	private MensajeDatosQLBeanLocal mensajeDatosQLBeanLocal;

	@Inject
	private MensajeSwiftBeanLocal mensajeSwiftBeanLocal;

	private String codigo = "";
	private String observacion = "";
	private String usuario = "";
	private String swiftTexto;
	private boolean mostrarObserv = false;

	private String tituloError;
	private String mensajeError;
	private boolean mostrarError = false;

	private MensajeDatos dat = null;
	private List<Datos> listaCampos = new ArrayList<Datos>();
	private Mensaje mensaje;

	private String contextPath;

	@PostConstruct
	public void inicio() {
		// posterior a la generacion de operacion
		// obteniendo el path de la aplicacion
		
		try {
			HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
			contextPath = request.getContextPath();
			recuperarParametros();

			usuario = request.getUserPrincipal().getName();

			codigo = (String) ((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).getAttribute("codigo");

			logger.info("En ver mensaje swift ..." + codigo);

			mensaje = mensajeQLBeanLocal.getMensaje(codigo);

			if (mensaje == null) {
				throw new RuntimeException("No existe el mensaje swift " + codigo);
			}

			listaCampos = mensajeDatosQLBeanLocal.getDatosVer(codigo);

			swiftTexto = verMensSwitfTexto();

		} catch (Exception e) {
			logger.error("Error al obtener mensaje swift " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage("errorcito",
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Ocurrió un error al obtener mensaje swift: " + e.getMessage(), null));
		}
	}

	public String botonCancelar() throws IOException {
		HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);

		session.removeAttribute("mensajesController");

		FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/mensajes.jsf");

		return "";
	}

	public String botonAutorizar() {

		logger.info("botonAutorizar mensaje...");
		String ip = getVisitBean().getUsuario().getUsrIpasignado();
		String usuario = getVisitBean().getUsuario().getUsrLogin();
		try {

			mensaje = mensajeQLBeanLocal.guardarArchivoSwift(mensaje, usuario, ip);

			mostrarError = true;
			tituloError = "MENSAJE";
			mensajeError = "El archivo de mensaje se generó exitosamente con numero swift " + mensaje.getMenSwift();

			FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/mensajes.jsf");
		} catch (Exception e) {
			mostrarError = true;
			tituloError = "ERROR";
			mensajeError = "La operación generó ERROR: " + e.getMessage();
			logger.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "La operacion produjo un error: " + e.getMessage(), null));
			return null;
		}

		return "";
	}

	public String botonRechazar() {

		logger.info("Enviando mensaje a botonRechazar...");

		String ip = getVisitBean().getUsuario().getUsrIpasignado();

		try {
			Mensaje mensaje = mensajeQLBeanLocal.getMensaje(codigo);
			mensaje.setCveEstadoS("Z");
			mensaje.setFechaHora(new Date());
			mensaje.setEstacion(ip);
			mensaje.setUsrCodigo(usuario);

			mensajeQLBeanLocal.edit(mensaje);

			logger.info("Mensaje rechazado " + mensaje.toString());
			// MensajeEstado menEstado = new MensajeEstado(new
			// MensajeEstadoPK(codigo, "Z"), observacion, usuario, new Date(),
			// ip);
			// mensajeEstadoQLBeanLocal.create(menEstado);

			mostrarError = true;
			tituloError = "MENSAJE";
			mensajeError = "El mensaje fue rechazado";
			FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/mensajes.jsf");

		} catch (Exception e) {
			mostrarError = true;
			tituloError = "ERROR";
			mensajeError = "La operación generó ERROR: " + e.getMessage();
			logger.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "La operacion produjo un error: " + e.getMessage(), null));
			return null;
		}

		return "";
	}

	public String botonModificar() {
		logger.info("Enviando mensaje a modificación...");

		mostrarObserv = true;

		return "";
	}

	public String botonRetornar() throws IOException {

		HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);

		session.removeAttribute("mensajesController");

		FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/mensajes.jsf");

		return "";
	}

	public String verMensSwitfTexto() {
		logger.info("yupii en verMensSwitfTexto");
		swiftTexto = mensajeSwiftBeanLocal.crearSwiftTexto(mensaje.getMenCodigo());

		return swiftTexto;
	}

	public String getTituloError() {
		return tituloError;
	}

	public void setTituloError(String tituloError) {
		this.tituloError = tituloError;
	}

	public String getMensajeError() {
		return mensajeError;
	}

	public void setMensajeError(String mensajeError) {
		this.mensajeError = mensajeError;
	}

	public boolean isMostrarError() {
		return mostrarError;
	}

	public void setMostrarError(boolean mostrarError) {
		this.mostrarError = mostrarError;
	}

	public String getObservacion() {
		return observacion;
	}

	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}

	public boolean isMostrarObserv() {
		return mostrarObserv;
	}

	public void setMostrarObserv(boolean mostrarObserv) {
		this.mostrarObserv = mostrarObserv;
	}

	public MensajeDatos getDat() {
		return dat;
	}

	public void setDat(MensajeDatos dat) {
		this.dat = dat;
	}

	public List<Datos> getListaCampos() {
		return listaCampos;
	}

	public Mensaje getMensaje() {
		return mensaje;
	}

	public void setMensaje(Mensaje mensaje) {
		this.mensaje = mensaje;
	}

	public String getSwiftTexto() {
		return swiftTexto;
	}

	public void setSwiftTexto(String swiftTexto) {
		this.swiftTexto = swiftTexto;
	}

}
