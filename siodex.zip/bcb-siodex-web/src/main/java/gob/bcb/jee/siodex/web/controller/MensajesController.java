package gob.bcb.jee.siodex.web.controller;

import gob.bcb.jee.siodex.QL.MensajeQLBeanLocal;
import gob.bcb.jee.siodex.controller.BaseBean;
import gob.bcb.jee.siodex.controller.MenuController;
import gob.bcb.jee.siodex.entities.Mensaje;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

// The @Model stereotype is a convenience mechanism to make this a request-scoped bean that has an
// EL name
// Read more about the @Model stereotype in this FAQ:
// http://sfwk.org/Documentation/WhatIsThePurposeOfTheModelAnnotation
//@Model
@ManagedBean(name = "mensajesController")
@ViewScoped
public class MensajesController extends BaseBean  {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	static final Logger logger = Logger.getLogger(MensajesController.class);

	@Inject
	private MensajeQLBeanLocal mensajeQLBeanLocal;

	private List<Mensaje> listaMen = new ArrayList<Mensaje>();

	private Mensaje men;
	private String contextPath;

	public List<Mensaje> getListaMen() {
		return listaMen;
	}

	@PostConstruct
	public void inicio() {
		// obteniendo el path de la aplicacion
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		contextPath = request.getContextPath();

		men = new Mensaje();

		listaMen = mensajeQLBeanLocal.listaMensajeOtros("E");
	}

	public String botonDetalle() throws IOException {
		logger.info("detalle: " + men.getMenSwift());

		String codigo = men.getMenCodigo();

		// cargando prestamo
		((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("codigo", codigo);

		HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);

		session.removeAttribute("detalleMenController");

		FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/detalleMen.jsf");

		return "/pages/detalleMen";
	}

	public Mensaje getMen() {
		return men;
	}

	public void setMen(Mensaje men) {
		this.men = men;
	}

}
