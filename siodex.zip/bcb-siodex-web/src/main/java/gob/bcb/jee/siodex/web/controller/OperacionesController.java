package gob.bcb.jee.siodex.web.controller;

import gob.bcb.jee.siodex.QL.ComprobanteQLBeanLocal;
import gob.bcb.jee.siodex.QL.ConsultasSdxQLBeanLocal;
import gob.bcb.jee.siodex.QL.SolicitudQLBeanLocal;
import gob.bcb.jee.siodex.QL.VencimientoQLBeanLocal;
import gob.bcb.jee.siodex.WS.ServicioUtil;
import gob.bcb.jee.siodex.commons.Constants;
import gob.bcb.jee.siodex.controller.BaseBean;
import gob.bcb.jee.siodex.entities.Comprobante;
import gob.bcb.jee.siodex.entities.Mensaje;
import gob.bcb.jee.siodex.entities.Solicitud;
import gob.bcb.jee.siodex.entities.Vencimiento;
import gob.bcb.jee.siodex.service.ComprobanteBeanLocal;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import gob.bcb.jee.siodex.service.OperacionBeanLocal;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

// The @Model stereotype is a convenience mechanism to make this a request-scoped bean that has an
// EL name
// Read more about the @Model stereotype in this FAQ:
// http://sfwk.org/Documentation/WhatIsThePurposeOfTheModelAnnotation
//@Model
@ManagedBean(name = "operacionesController")
@ViewScoped
public class OperacionesController extends BaseBean {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	static final Logger logger = Logger.getLogger(OperacionesController.class);

	@Inject
	private SolicitudQLBeanLocal solicitudQLBeanLocal;

	@Inject
	private ComprobanteBeanLocal comprobante;
	
	@Inject
	private VencimientoQLBeanLocal vencimientoQLBeanLocal;

	@Inject
	private OperacionBeanLocal operacion;

	@Inject
	private ComprobanteQLBeanLocal comprobQLBeanLocal;

	@Inject
	private ConsultasSdxQLBeanLocal consultasSdxQLBeanLocal;

	private List<Mensaje> mensajeLista = new ArrayList<Mensaje>();

	private List<Solicitud> listaSol = new ArrayList<Solicitud>();

	private String contextPath;

	private String tituloError;
	private String mensajeError;
	private boolean mostrarError = false;

	private Solicitud sol;

	@Inject
	private ServicioUtil servicio;
	
	@PostConstruct
	public void inicio() {
		logger.info("En operaciones contables controller ");
		// obteniendo el path de la aplicacion
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		contextPath = request.getContextPath();
		recuperarParametros();
		sol = new Solicitud();

		listaSol = solicitudQLBeanLocal.listaSolicitud("O", null, null);

	}

	public String botonDetalle() throws IOException {

		logger.info("detalle: " + sol.getLiqCodigo());

		String codigo = sol.getLiqCodigo();
		// cargando prestamo
		((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("codigo", codigo);

		FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/detalleOperacion.jsf");

		return "/pages/detalleOperacion";
	}

	public String botonRenglones() throws IOException {

		logger.info("codigo solicitud seleccionado para ver comprobante: " + sol.getSolCodigo());

		Integer codSol = sol.getSolCodigo();

		// cargando prestamo
		((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("codSol", codSol);

		FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/detalleComp.jsf");

		return "/pages/detalleComp";
	}

	public String botonRetornar() {
		return "";
	}

	public String botonEnviar() throws IOException {
		try {
			mostrarError = false;
			Map<String, Object> mapaResult = new HashMap<String, Object>();

			logger.info("registrando un rastro contable...");

			// whf ojooo eliminar ip y usuario reemplazar por visit
			String usuario = getVisitBean().getUsuario().getUsrLogin();
			String ip = getVisitBean().getUsuario().getUsrIpasignado();
			
			mapaResult = comprobante.contabilizarSolo(sol, usuario, ip);
			
			logger.info("Solictud genero comprobante existosamente " + sol.getLiqCodigo() );									
			
			Integer continuar = (Integer) mapaResult.get("continuar");
			String descError = (String) mapaResult.get("descMensaje");
			String nroComprobCoin = (String) mapaResult.get("nroComprobCoin");
			
			logger.info("continuar: " + continuar);
			logger.info("descerror: " + descError);
			mensajeError = "La operación se generó exitosamente liq.: " + sol.getLiqCodigo() + " nro comprobante: " + nroComprobCoin + "\n";
			
			mostrarError = true;
			tituloError = "MENSAJE";
			
			if (!StringUtils.isBlank(sol.getCodPart()) &&  sol.getCodPart().trim().equals(Constants.COD_TGN)){
				//////////////////////////////////////////////////////////			
				Map<String, Object> parametros = new HashMap<String, Object>();
				parametros.put("SIODEX_PARAM", getVisitBean().getParametro("SIODEX_PARAM"));
				
				parametros.put("tipooperacion", "AUTORIZAR_MSG_TGN_LIQ");			
				parametros.put("codigoLiq", sol.getLiqCodigo());
				parametros.put("urlServ", VencimientosOController.urlServ());

				logger.info("Operacion TGN: Parametros a enviar al WS: " + ArrayUtils.toString(parametros));

				Map<String, Object> mapResult = servicio.procesarMensaje(parametros);

				String codResp = (String) mapResult.get("cod_resp");
				String respuesta = (String) mapResult.get("respuesta");
				String desError = (String) mapResult.get("des_error");
				
				logger.info("respuesta: " + respuesta);
				
				if (!StringUtils.isBlank(codResp) && codResp.equals("-1")) {
					mensajeError = mensajeError + "\n   PERO!!! ocurrió un ERROR al enviar la confirmación al servidor Web del TGN: " + respuesta;
					logger.error("Error: " + mensajeError);					
					FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, mensajeError, null));
				} else {
					mensajeError = mensajeError + "\n y se genero el envio del mensaje al servicio WEB del TGN : " + respuesta;
					FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, mensajeError, null));
				}
				//FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/operaciones.jsf");	
				
				//----enviamos mail de confirmación con la codResp que nos envío la generación de WS -1 si es error
				Vencimiento vencimiento = vencimientoQLBeanLocal.getVencimiento("", 0, sol.getLiqCodigo());
				try {
					vencimientoQLBeanLocal.enviarCorreos(vencimiento, "", "LIQCONTABILIZADA", "WS", codResp, desError);
				} catch (Exception e) {
					logger.warn("Error al enviar correos pero la operacion fue cntabilzada " + e.getMessage(), e);
				}

				return "";				
			}
			
			
			
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_INFO, mensajeError, null));
			FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/operaciones.jsf");			
			return "";
		} catch (Exception e) {
			mostrarError = true;
			tituloError = "ERROR";
			mensajeError = "La operación generó ERROR: " + e.getMessage();			
			logger.error("La operación generó ERROR: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Ocurrió un error: " + e.getMessage(), null));
			return "";
		}
	}

	public String botonRechazar() {

		mostrarError = false;
		logger.info("rechazando operación...");

		/*
		 * HttpServletRequest request = (HttpServletRequest)
		 * FacesContext.getCurrentInstance().getExternalContext().getRequest();
		 * String ip = getVisitBean().getUsuario().getUsrIpasignado(); String
		 * usuario = request.getUserPrincipal().getName();
		 */
		try {
			sol.setCveEstado("Z");
			solicitudQLBeanLocal.cambioEstado(sol, "", "Z");

			mostrarError = true;
			tituloError = "MENSAJE";
			mensajeError = "La operación fue rechazada.";
		} catch (Exception e) {
			mostrarError = true;
			tituloError = "ERROR";
			mensajeError = "Se produjo un error al rechazar la operación.";
			logger.info("error al rechazar la operación" + e.getMessage());
		}

		return "";
	}

	public Solicitud getSol() {
		return sol;
	}

	public void setSol(Solicitud sol) {
		this.sol = sol;
	}

	public String getTituloError() {
		return tituloError;
	}

	public void setTituloError(String tituloError) {
		this.tituloError = tituloError;
	}

	public String getMensajeError() {
		return mensajeError;
	}

	public void setMensajeError(String mensajeError) {
		this.mensajeError = mensajeError;
	}

	public boolean isMostrarError() {
		return mostrarError;
	}

	public void setMostrarError(boolean mostrarError) {
		this.mostrarError = mostrarError;
	}

	public List<Solicitud> getListaSol() {
		return listaSol;
	}

}
