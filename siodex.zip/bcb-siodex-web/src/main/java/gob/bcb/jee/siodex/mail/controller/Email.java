/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-web-seguridad
 * gob.bcb.web.seguridad.common.Email
 * 06/12/2011 - 15:53:22
 * Creado por Gustavo Flores
 */
package gob.bcb.jee.siodex.mail.controller;

import gob.bcb.jee.siodex.entities.Cuenta;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Map.Entry;
import java.util.Set;

import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;

/**
 * 
 * @author Gustavo Flores
 */
public class Email {
	private String asunto;
	private String mensajeHtml;
	
	private BigDecimal rango = BigDecimal.valueOf(0.5);

	static final Logger logger = Logger.getLogger(Email.class);

	public void enviarNotificacion(Date fecha, BigDecimal importe, Cuenta cuenta) {
		
		logger.info("Preparando e-mail de notificación");
		this.asunto = "Solicitud de provisión de fondos";
		this.armarMensaje(fecha, importe, cuenta);
		logger.info("Se enviará e-mail a: ");
		try {
			//ResourceBundle resource = ResourceBundle.getBundle("Email");
			Locale locale = new Locale("es","ES");
			ResourceBundle resource = ResourceBundle.getBundle("Email",locale);
			JavaMailSenderImpl sender = new JavaMailSenderImpl();
			sender.setHost(resource.getString("MAIL_SERVER"));
			sender.setPort(Integer.valueOf(resource.getString("MAIL_PORT")));
			MimeMessage message = sender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(message, true);
			if ("SI".equals(resource.getString("HABILITAR_ENVIO_A_USUARIOS"))) {
				helper.setTo(resource.getString("MAIL_BU").split(";"));
				helper.setBcc(resource.getString("MAIL_ADMIN").split(";"));
			} else {
				helper.setTo(resource.getString("MAIL_ADMIN").split(";"));
			}
			helper.setSubject(this.asunto);
			helper.setFrom(resource.getString("MAIL_SENDER"),
					resource.getString("MAIL_SENDER_NAME"));
			helper.setText(this.mensajeHtml, true);
			sender.send(message);
			logger.info("E-mail de notificación enviado satisfactoriamente");
		} catch (Exception e) {
			logger.error("Error al enviar la notificación", e);
			e.printStackTrace();
		}
	}

		
	@SuppressWarnings("deprecation")
	private void armarMensaje(Date fecha, BigDecimal importe, Cuenta cuenta) {
		StringBuffer sb = new StringBuffer("Se&ntilde;ores");
		sb.append("<br/>");
		sb.append("BANCO UNION S.A.");
		sb.append("<br/>");
		sb.append("Presente.");
		sb.append("<br/><br/><br/>Se&ntilde;ores:");
		sb.append("<br/>Comunicamos a ustedes que en fecha ");
		sb.append(Integer.toString(fecha.getDate()));
		sb.append("-0");
		sb.append(Integer.toString(fecha.getMonth() + 1));
		sb.append("-2013");
		sb.append(", el Banco Central de Bolivia efectuar&aacute; un d&eacute;bito en su cuenta corriente fiscal que mantiene en nuestra instituci&oacute;n ");
		sb.append("por concepto de pago de deuda externa seg&uacute;n detalle:<br/><br/>");
		this.mensajeHtml = sb.toString();

		Map<String, String> mapDatos = new LinkedHashMap<String, String>();
		
		mapDatos.put("ENTIDAD", cuenta.getCtaFactura());
		mapDatos.put("CUENTA", cuenta.getCtaNumero());
		mapDatos.put("", cuenta.getCtaNombre());
		
		System.out.println("importe1: " + importe);
		importe = importe.multiply(rango.divide(BigDecimal.valueOf(100)).add(BigDecimal.valueOf(1)));
		System.out.println("importe2: " + importe);
		BigDecimal estimado = importe.divide(BigDecimal.valueOf(1000), 0, RoundingMode.CEILING).multiply(BigDecimal.valueOf(1000)).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
		System.out.println("estimado: " + estimado);
		
		int pos = 0;
		int ll = 0;
		int sep = 0;
		String valor = estimado.toString();
		String montoT = "";

		valor = valor.replace('.', ',');
		pos = valor.indexOf(',');
		if (pos > -1)
		{
		  valor = valor.substring(0, pos + 3);
			ll = pos - 1;
			sep = ll - 3;
			if (sep > -1)
			{
				montoT = valor.substring(0, sep + 1) + "." + valor.substring(sep + 1);
				valor = montoT;
				ll = sep;
				sep = ll - 3;
				if (sep > -1)
					montoT = valor.substring(0, sep + 1) + "." + valor.substring(sep + 1);
			}
		}
		
		mapDatos.put("IMPORTE ESTIMADO Bs. ", montoT);

		sb.append(this.armarGrillaDosColumnas(mapDatos));

		sb.append("<br/><br/>Agradeceremos tomar los recaudos necesarios para la provisi&oacute;n oportuna de fondos.");
		sb.append("<br/><br/><br/>Atentamente,<br/><br/>Departamento de Deuda Externa<br/>BANCO CENTRAL DE BOLIVIA");
		this.mensajeHtml = this.darFormato(sb.toString());
	}

	private String armarGrillaDosColumnas(Map<String, String> datos) {
		StringBuffer sb = new StringBuffer(
				"<table cellSpacing='0' cellPadding='0'>");
		Set<Entry<String, String>> entries = datos.entrySet();
		for (Entry<String, String> entry : entries) {
			sb.append("<tr>");
			sb.append("<td class='a'>").append(entry.getKey()).append("</td>");
			sb.append("<td class='b'>").append(entry.getValue())
					.append("</td>");
			sb.append("</tr>");
		}
		sb.append("</table>");
		return sb.toString();
	}

	private String darFormato(String contenido) {
		StringBuffer sb = new StringBuffer(
				"<html><head><style type='text/css'>");
		sb.append("html,body{margin:10px;font-style:normal;font-size:14px;font-family:Arial,Verdana,Tahoma;color:#555555;}");
		sb.append("h2{color:#204D84;font-size:14px;font-weight:bold;margin: 0px 0px 0px 0px;padding: 0px 0px 0px 0px;}");
		sb.append("table{vertical-align:middle;}");
		sb.append("tr.a td{background-color:#D5E0F3;}tr.b td {background-color:#EAF0FB;}");
		sb.append("td.a{background-color:#D5E0F3;font-weight:bold;border: 1px solid #D5D5D5;}td.b{background-color:#EAF0FB;border: 1px solid #D5D5D5;}");
		sb.append("th{color:#FFFFFF;font-size:14px;background-color:#204D84;padding: 1px 10px 1px 10px;}");
		sb.append("td{color:#204D84;font-size:14px;padding: 0px 10px 0px 10px;}");
		sb.append("</style></head><body>");
		sb.append(contenido);
		sb.append("</body></html>");
		return sb.toString();
	}

}
