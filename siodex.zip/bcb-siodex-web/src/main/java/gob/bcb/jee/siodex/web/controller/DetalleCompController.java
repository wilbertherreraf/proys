package gob.bcb.jee.siodex.web.controller;

import gob.bcb.jee.siodex.QL.*;
import gob.bcb.jee.siodex.controller.BaseBean;
import gob.bcb.jee.siodex.entities.*;
import gob.bcb.jee.siodex.exception.DataException;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import gob.bcb.jee.siodex.service.MensajeSwiftBeanLocal;
import org.apache.log4j.Logger;

// The @Model stereotype is a convenience mechanism to make this a request-scoped bean that has an
// EL name
// Read more about the @Model stereotype in this FAQ:
// http://sfwk.org/Documentation/WhatIsThePurposeOfTheModelAnnotation
//@Model
@ManagedBean(name = "detalleCompController")
@ViewScoped
public class DetalleCompController extends BaseBean {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	static final Logger logger = Logger.getLogger(DetalleCompController.class);

	@Inject
	private SolicitudQLBeanLocal solicitudQLBeanLocal;

	@Inject
	private ComprobanteQLBeanLocal comprobQLBeanLocal;
	@Inject
	private VencimientoQLBeanLocal vencimientoQLBeanLocal;

	@Inject
	private MensajeSwiftBeanLocal mensajeSwiftBeanLocal;

	@Inject
	private MensajeDatosQLBeanLocal mensajeDatosQLBeanLocal;

	@Inject
	private ConsultasSdxQLBeanLocal consultasSdxQLBeanLocal;

	@Inject
	private MensajeQLBeanLocal mensajeQLBeanLocal;

	private Integer codigo = 0;

	private List<Mensaje> mensajeLista = new ArrayList<Mensaje>();
	List<MensajeDatos> mensajeDatosList = new ArrayList<MensajeDatos>();

	private List<Comprobante> listaComprob = new ArrayList<Comprobante>();
	private List<Comprobante> listaComprobAdic = new ArrayList<Comprobante>();
	private Solicitud sol;
	private BigDecimal sumaDebe = BigDecimal.ZERO;
	private BigDecimal sumaHaber = BigDecimal.ZERO;
	private Vencimiento vencimiento;
	private String contextPath;
	private Mensaje selectedMensaje;
	private String swiftTexto;
	private boolean mostrarMensaje;


	@PostConstruct
	public void inicio() {
		try {
			// obteniendo el path de la aplicacion
			HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
			contextPath = request.getContextPath();

			codigo = (Integer) ((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).getAttribute("codSol");

			recuperarParametros();

			logger.info("Objeto Solicitud instanciado: " + codigo);

			sol = solicitudQLBeanLocal.getSolicitud(codigo);

			vencimiento = vencimientoQLBeanLocal.getVencimiento("", 0, sol.getLiqCodigo());

			listaComprob = comprobQLBeanLocal.listaComprobante(codigo);
			listaComprobAdic = comprobQLBeanLocal.listaComprobanteAdic(codigo);
			mostrarMensaje = false;
			// Generamos el mensaje swift
			if(vencimiento.getCantMensSwift() == 0){

				String ctasBidOpInternas = consultasSdxQLBeanLocal.getParametro("CTAS_BID_OP_INTERNAS");

				String[] ctasMonedas = null;
				if (ctasBidOpInternas != null && !ctasBidOpInternas.isEmpty()) {
					ctasMonedas = ctasBidOpInternas.split(";");
				}

				for (Comprobante comprobante1 : listaComprob) {
					for (String ctasMoneda : ctasMonedas) {
						if(comprobante1.getCuentaMov().equalsIgnoreCase(ctasMoneda.split(":")[0])){
							// Creamos el mensaje para las operaciones 0640 y 0642
							// Verificamos si ya se creo el mensaje
							mostrarMensaje = true;
							List<Mensaje> mensajeListaPre = mensajeQLBeanLocal.mensajeByLiqcodigoMonSigade(vencimiento.getLiqCodigo(),
									comprobante1.getMoneda());

							if(mensajeListaPre.size() == 0){

								Mensaje mensaje = new Mensaje("", 0, vencimiento.getPtmCodigo(), vencimiento.getTraCodigo(), comprobante1.getMontoMn(),
										"E", "BBS", "DMS1", vencimiento.getCapitalUsd(), vencimiento.getInteresUsd(),
										vencimiento.getComisionUsd(), vencimiento.getFechaTc(), vencimiento.getFechaVenc(), vencimiento.getUsuario(), new Date(), vencimiento.getLogAuditoria().getEstacion());

								mensajeDatosList = mensajeSwiftBeanLocal.crearSwift(vencimiento, mensaje,
										vencimiento.getReferencia(), 0, mensaje.getPtmCodigo(), mensaje.getTraCodigo(), comprobante1.getCuentaMov());

								mensajeLista.add(mensaje);

//								mensajeDatosList = mensajeDatosQLBeanLocal.crearMensajeDatos(mensajeDatosList);
							} else{
								mensajeLista = mensajeListaPre;
								for (Mensaje mensaje : mensajeListaPre) {
									mensajeDatosList = mensajeSwiftBeanLocal.crearSwift(vencimiento, mensaje,
											vencimiento.getReferencia(), 0, mensaje.getPtmCodigo(), mensaje.getTraCodigo(), comprobante1.getCuentaMov());
								}
							}

						}
					}
				}



			}


			calcular();
		} catch (Exception e) {
			logger.error("Error al obtener vencimiento " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Ocurrió un error: " + e.getMessage(), null));
		}

	}

	public void calcular() {
		sumaDebe = BigDecimal.ZERO;
		sumaHaber = BigDecimal.ZERO;

		for (Comprobante comprobante : listaComprob) {
			if (comprobante.getMontoMn() != null) {
				if (comprobante.getDebeHaber() != null) {
					if (comprobante.getDebeHaber().equals("D")) {
						sumaDebe = sumaDebe.add(comprobante.getMontoMn());
					}
					if (comprobante.getDebeHaber().equals("H")) {
						sumaHaber = sumaHaber.add(comprobante.getMontoMn());
					}
				}
			}

		}
		if ((sumaDebe.subtract(sumaHaber)).abs().compareTo(new BigDecimal(0.04)) > 0) {
			if (sumaDebe.compareTo(sumaHaber) < 0) {
				try {
					comprobQLBeanLocal.ajustarComprobante(codigo);
				} catch (DataException e) {
					logger.error("Error al ajustar comprobante " + e.getMessage(), e);
					FacesContext.getCurrentInstance().addMessage(null,
							new FacesMessage(FacesMessage.SEVERITY_ERROR, "Ocurrió un error: " + e.getMessage(), null));
				}
			}
		}
	}

	public String botonRetornar() throws IOException {
		if (sol.getCveEstado().equals("P")) {
			((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("codigo", sol.getLiqCodigo());			
			FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/detalleVenO.jsf");

			return "/pages/detalleVenO";
		}
		
		FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/operaciones.jsf");

		return "";

	}

	public String verMensajeSwiftTexto() {

		logger.info("en verMensajeSwiftTexto " + (selectedMensaje == null));
		try {
			if (selectedMensaje != null) {
				logger.info("retornando swift en texto " + selectedMensaje.getMenCodigo());

				if (vencimiento.getReferencia() == null) {
					vencimiento.setReferencia("");
				}

				if (selectedMensaje.getCveEstadoS() != null && selectedMensaje.getCveEstadoS().equals("PRELIMINAR")) {

					logger.info("swift en texto PRELIMINAR " + selectedMensaje.getMenCodigo());

					Integer nroSwift = Integer.valueOf(selectedMensaje.getLiqDetalle());


					swiftTexto = mensajeSwiftBeanLocal.crearSwiftTexto(mensajeDatosList);
				} else {
					logger.info("swift en texto REGISTRADO " + selectedMensaje.getMenCodigo());

//					List<MensajeDatos> mensajeDatosList = mensajeDatosQLBeanLocal.getDatos(selectedMensaje.getMenCodigo());
					swiftTexto = mensajeSwiftBeanLocal.crearSwiftTexto(mensajeDatosList);
				}
			}
		} catch (Exception e) {
			logger.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "La operacion produjo un error: " + e.getMessage(), null));
		}
		return "";
	}

	public String botonGuardar() throws IOException {
		try {
			sol.setFechaHora(new Date());
			sol.setUsrCodigo(getVisitBean().getUsuario().getUsrLogin());
			solicitudQLBeanLocal.edit(sol);

			this.botonRetornar();

			logger.info("se guardo la solicitud: " + sol.toString());
			return "";
		} catch (Exception e) {
			logger.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "La operacion produjo un error: " + e.getMessage(), null));
			return null;
		}

	}

	public Solicitud getSol() {
		return sol;
	}

	public void setSol(Solicitud sol) {
		this.sol = sol;
	}

	public List<Comprobante> getListaComprob() {
		return listaComprob;
	}

	public Vencimiento getVencimiento() {
		return vencimiento;
	}

	public void setVencimiento(Vencimiento vencimiento) {
		this.vencimiento = vencimiento;
	}

	public List<Comprobante> getListaComprobAdic() {
		return listaComprobAdic;
	}

	public void setListaComprobAdic(List<Comprobante> listaComprobAdic) {
		this.listaComprobAdic = listaComprobAdic;
	}

	public BigDecimal getSumaDebe() {
		return sumaDebe;
	}

	public void setSumaDebe(BigDecimal sumaDebe) {
		this.sumaDebe = sumaDebe;
	}

	public BigDecimal getSumaHaber() {
		return sumaHaber;
	}

	public void setSumaHaber(BigDecimal sumaHaber) {
		this.sumaHaber = sumaHaber;
	}

	public Mensaje getSelectedMensaje() {
		return selectedMensaje;
	}

	public void setSelectedMensaje(Mensaje selectedMensaje) {
		this.selectedMensaje = selectedMensaje;
	}

	public String getSwiftTexto() {
		return swiftTexto;
	}

	public List<Mensaje> getMensajeLista() {
		return mensajeLista;
	}


	public boolean isMostrarMensaje() {
		return mostrarMensaje;
	}

	public void setMostrarMensaje(boolean mostrarMensaje) {
		this.mostrarMensaje = mostrarMensaje;
	}
}
