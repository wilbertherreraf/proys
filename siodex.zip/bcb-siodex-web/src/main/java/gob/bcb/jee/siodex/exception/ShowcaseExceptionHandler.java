/*
 * Copyright 2009-2012 Prime Teknoloji.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package gob.bcb.jee.siodex.exception;

import java.util.Iterator;
import javax.faces.FacesException;
import javax.faces.application.NavigationHandler;
import javax.faces.application.ViewExpiredException;
import javax.faces.context.ExceptionHandler;
import javax.faces.context.ExceptionHandlerWrapper;
import javax.faces.context.FacesContext;
import javax.faces.event.ExceptionQueuedEvent;
import javax.faces.event.ExceptionQueuedEventContext;

import org.apache.log4j.Logger;

public class ShowcaseExceptionHandler extends ExceptionHandlerWrapper {
	static final Logger logger = Logger.getLogger(ShowcaseExceptionHandler.class);
	private ExceptionHandler wrapped;

	public ShowcaseExceptionHandler(ExceptionHandler wrapped) {
		this.wrapped = wrapped;
	}

	@Override
	public ExceptionHandler getWrapped() {
		return this.wrapped;
	}

	@Override
	public void handle() throws FacesException {
		Iterable<ExceptionQueuedEvent> events = this.wrapped.getUnhandledExceptionQueuedEvents();
		for (Iterator<ExceptionQueuedEvent> it = events.iterator(); it.hasNext();) {
			ExceptionQueuedEvent event = it.next();
			ExceptionQueuedEventContext eqec = event.getContext();
			logger.info("XXX: en handle() ShowcaseExceptionHandler " + eqec.getException().getMessage());
			if (eqec.getException() instanceof ViewExpiredException) {
				FacesContext context = eqec.getContext();
				NavigationHandler navHandler = context.getApplication().getNavigationHandler();

				try {
					navHandler.handleNavigation(context, null, "/login?faces-redirect=true&expired=true");
				} finally {
					it.remove();
				}
//			} else if (eqec.getException() instanceof DataException) {
//				logger.info("XXX: 222en handle() throws FacesException");				
//				FacesContext context = eqec.getContext();
//				NavigationHandler navHandler = context.getApplication().getNavigationHandler();
//
//				try {
//					
//					navHandler.handleNavigation(context, null, "index?faces-redirect=true");
//				} finally {
//					it.remove();
//				}
//			}else if (eqec.getException() instanceof FacesException) {
//				logger.info("XXX: 33333en handle() throws FacesException");				
//				FacesContext context = eqec.getContext();
//				NavigationHandler navHandler = context.getApplication().getNavigationHandler();
//
//				try {
//					logger.info("XXX: 444en handle() throws FacesException");					
//					navHandler.handleNavigation(context, null, "/error?faces-redirect=true");
//					logger.info("XXX: 555en handle() throws FacesException");					
//				} finally {
//					it.remove();
//				}				
			}
		}

		this.wrapped.handle();
		
	}
}
