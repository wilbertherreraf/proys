package gob.bcb.jee.siodex.servlet;

import gob.bcb.jee.siodex.util.File;
import gob.bcb.jee.siodex.web.controller.DetalleVenOController;

import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

public class ObtenerBlob extends HttpServlet {
	static final Logger logger = Logger.getLogger(ObtenerBlob.class);
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
	 * methods.
	 * 
	 * @param request
	 *            servlet request
	 * @param response
	 *            servlet response
	 * @throws ServletException
	 *             if a servlet-specific error occurs
	 * @throws IOException
	 *             if an I/O error occurs
	 */
	@SuppressWarnings("null")
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			logger.info("Carga de reporte blob "  + request.getSession().getAttributeNames());
			File f = (File) request.getSession().getAttribute("file2");

			// verificando si se envio uin id para mostrar la imagen
			if (f == null) {
				throw new Exception("[utils.imagenes.ObtenerImagen]Parametro tiene un valor desconocido");
			} else {
				response.setHeader("Content-Type", "application/pdf");
				response.setIntHeader("Content-Length", (int) f.getLength());

				response.setHeader("Content-Disposition", "attachment; filename=\"adjunto.pdf\";");
				response.setHeader("Cache-Control", "no-cache");
				response.setHeader("Pragma", "no-cache");
				response.setHeader("Content-Disposition", "inline");
				response.setDateHeader("Expires", 0);
				
				int cont = 0;
				do {
					// si el reporte no recibe parametros en los 10 seg
					f = (File) request.getSession().getAttribute("file2");

					try {
						Thread.sleep(500);
					} catch (InterruptedException e) {
						logger.error(e);
					}
					cont++;
					logger.info("Recuperando blob ... esperando: " + cont);
				} while ((f.getData() == null) && cont <= 18);
				
				OutputStream outputStream = response.getOutputStream();
				logger.info("888888........" + (f == null) + " "  + (f.getData() == null));
				outputStream.write(f.getData());
				outputStream.close();
				outputStream.flush();
			}

		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
		}

	}

	// <editor-fold defaultstate="collapsed"
	// desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
	/**
	 * Handles the HTTP <code>GET</code> method.
	 * 
	 * @param request
	 *            servlet request
	 * @param response
	 *            servlet response
	 * @throws ServletException
	 *             if a servlet-specific error occurs
	 * @throws IOException
	 *             if an I/O error occurs
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * Handles the HTTP <code>POST</code> method.
	 * 
	 * @param request
	 *            servlet request
	 * @param response
	 *            servlet response
	 * @throws ServletException
	 *             if a servlet-specific error occurs
	 * @throws IOException
	 *             if an I/O error occurs
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * Returns a short description of the servlet.
	 * 
	 * @return a String containing servlet description
	 */
	@Override
	public String getServletInfo() {
		return "Short description";
	}// </editor-fold>

}
