package gob.bcb.jee.siodex.web.controller;

import gob.bcb.jee.siodex.QL.LiqEstadoQLBeanLocal;
import gob.bcb.jee.siodex.QL.LiquidacionQLBeanLocal;
import gob.bcb.jee.siodex.QL.LogAuditoriaQLBeanLocal;
import gob.bcb.jee.siodex.controller.BaseBean;
import gob.bcb.jee.siodex.entities.Liquidacion;
import gob.bcb.jee.siodex.entities.LiquidacionEstado;
import gob.bcb.jee.siodex.entities.LiquidacionEstadoPK;
import gob.bcb.jee.siodex.entities.LogAuditoria;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

// The @Model stereotype is a convenience mechanism to make this a request-scoped bean that has an
// EL name
// Read more about the @Model stereotype in this FAQ:
// http://sfwk.org/Documentation/WhatIsThePurposeOfTheModelAnnotation
//@Model
@ManagedBean(name = "detalleObservController")
@ViewScoped
public class DetalleObservController extends BaseBean {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	static final Logger logger = Logger.getLogger(DetalleObservController.class);

	@Inject
	private LiquidacionQLBeanLocal liqQLBeanLocal;

	@Inject
	private LogAuditoriaQLBeanLocal logQLBeanLocal;

	@Inject
	private LiqEstadoQLBeanLocal liqEstadoQLBeanLocal;

	private List<LiquidacionEstado> liquidacionEstadoLista = new ArrayList<LiquidacionEstado>();

	private String titulo = "";
	private String codigo = "";
	private String observ = "";

	private String tituloError;
	private String mensajeError;
	private boolean mostrarError = false;

	private String contextPath;

	@PostConstruct
	public void inicio() {

		// obteniendo el path de la aplicacion
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		contextPath = request.getContextPath();

		titulo = (String) ((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).getAttribute("titulo");
		codigo = (String) ((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).getAttribute("codigo");

		logger.info("Objeto instanciado: " + codigo);

	}

	public String botonEnviar() {
		logger.info("Enviando...");

		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		String usuario = request.getUserPrincipal().getName();
		String ip = getVisitBean().getUsuario().getUsrIpasignado();

		try {
			LogAuditoria log = new LogAuditoria(0, "001100", usuario, ip, new Date());
			logQLBeanLocal.create(log);
			Integer cod = logQLBeanLocal.getCodigo();

			Liquidacion liq = liqQLBeanLocal.getLiquidacion(codigo);
			liq.setCveEstado("B");
			liqQLBeanLocal.edit(liq);

			LiquidacionEstado liqEstado = new LiquidacionEstado(new LiquidacionEstadoPK(codigo, "B"), cod, observ, "curiona", new Date());
			liqEstadoQLBeanLocal.create(liqEstado);

			mostrarError = true;
			tituloError = "MENSAJE";
			mensajeError = "Se enviaron las observaciones al estado de cuenta.";
		} catch (Exception e) {
			mostrarError = true;
			tituloError = "MENSAJE";
			mensajeError = "Se produjo un error al enviar las observaciones al estado de cuenta";
			logger.info("error al enviar las observaciones al estado de cuenta: " + e.getMessage());
			e.printStackTrace();
		}

		return "";
	}


	public String botonRetornar() throws IOException {

		HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);

		session.removeAttribute("vencimientosController");

		FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/vencimientos.jsf");

		return "";
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getObserv() {
		return observ;
	}

	public void setObserv(String observ) {
		this.observ = observ;
	}

	public String getTituloError() {
		return tituloError;
	}

	public void setTituloError(String tituloError) {
		this.tituloError = tituloError;
	}

	public String getMensajeError() {
		return mensajeError;
	}

	public void setMensajeError(String mensajeError) {
		this.mensajeError = mensajeError;
	}

	public boolean isMostrarError() {
		return mostrarError;
	}

	public void setMostrarError(boolean mostrarError) {
		this.mostrarError = mostrarError;
	}

	public List<LiquidacionEstado> getLiquidacionEstadoLista() {
		return liquidacionEstadoLista;
	}

	public void setLiquidacionEstadoLista(List<LiquidacionEstado> liquidacionEstadoLista) {
		this.liquidacionEstadoLista = liquidacionEstadoLista;
	}

}
