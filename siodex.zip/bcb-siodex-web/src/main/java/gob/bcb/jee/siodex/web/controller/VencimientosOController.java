package gob.bcb.jee.siodex.web.controller;

import gob.bcb.jee.siodex.QL.LiquidacionQLBeanLocal;
import gob.bcb.jee.siodex.QL.SolicitudQLBeanLocal;
import gob.bcb.jee.siodex.QL.VencimientoQLBeanLocal;
import gob.bcb.jee.siodex.WS.ServicioUtil;
import gob.bcb.jee.siodex.commons.Constants;
import gob.bcb.jee.siodex.controller.BaseBean;
import gob.bcb.jee.siodex.entities.Solicitud;
import gob.bcb.jee.siodex.entities.Vencimiento;
import gob.bcb.jee.siodex.exception.DataException;
import gob.bcb.jee.siodex.util.File;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

// The @Model stereotype is a convenience mechanism to make this a request-scoped bean that has an
// EL name
// Read more about the @Model stereotype in this FAQ:
// http://sfwk.org/Documentation/WhatIsThePurposeOfTheModelAnnotation
//@Model
@ManagedBean(name = "vencimientosOController")
@ViewScoped
public class VencimientosOController extends BaseBean {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	static final Logger logger = Logger.getLogger(VencimientosOController.class);

	@Inject
	private VencimientoQLBeanLocal vencimientoQLBeanLocal;
	@Inject
	private SolicitudQLBeanLocal solicitudQLBeanLocal;
	@Inject
	private ServicioUtil servicio;

	@Inject
	private LiquidacionQLBeanLocal liquidacionQLBeanLocal;
	private String nombre = "";

	private Vencimiento liq;

	private String contextPath;

	private List<Vencimiento> listaVen = new ArrayList<Vencimiento>();

	@PostConstruct
	public void inicio() throws Exception {
		logger.info("PostConstruct VencimientosOController - " + this.getClass().getName());
		recuperarParametros();
		// obteniendo el path de la aplicacion
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		String SIODEX_PARAM = (String) ((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false))
				.getAttribute("SIODEX_PARAM");
		
		String codEnt = getVisitBean().getParticipante().getCodPte();		
		logger.info("Opcion menu SIODEX_PARAM " + SIODEX_PARAM + " codEnt: " + codEnt);

		contextPath = request.getContextPath();

		liq = new Vencimiento();

		List<Vencimiento> vencimientoList = new ArrayList<Vencimiento>();

	
		if (SIODEX_PARAM.equals("GENERAR_OPERACION")) {
			listaVen = vencimientoQLBeanLocal.listaVencimiento("'A','S'", codEnt);
		} else {
			
			
			// ////////////////////////////////////////////////////////////
			// whf borrar
//			loaderQLBeanLocal.getCodigo();
//			mensajeQLBeanLocal.getCodigo();
//			 Vencimiento vencimientoPru = new Vencimiento("003427", "aaa",
//			 1, BigDecimal.valueOf(0), BigDecimal.valueOf(0),
//			 BigDecimal.valueOf(0),
//			 new Date(), "O", new Date(), "PPP", "RACR", "acreedor",
//			 "deudor", BigDecimal.valueOf(0), "usuario", null);
//			 vencimientoPru.setCveEstadoDescrip("Estado-");
//			 listaVen.add(vencimientoPru);
//			 if (SIODEX_PARAM.length() > 1) {
//			 logger.info("XXX: pruLocal. en vencontroller " +			 liquidacionQLBeanLocal.getLiquidacion("003019"));
//			 return;
//			 }

			// //////////////////////////////////////////////////////////////
			logger.info("Seleccion tipo : " + SIODEX_PARAM);
			if (SIODEX_PARAM.equals("NOTIFICAR_MSG_TGN")) {
				// es una operacion de tgn
				vencimientoList = vencimientoQLBeanLocal.listaVencimiento("'P','N'",Constants.COD_TGN);
				for (Vencimiento vencimiento : vencimientoList) {
					// si NOesta en la lista de reportados
					if (StringUtils.isBlank(vencimiento.getCveEstNotif()) || vencimiento.getCveEstNotif().equalsIgnoreCase("N")) {
						listaVen.add(vencimiento);
					}
				}
			} else if (SIODEX_PARAM.equals("NOTIFOBSERVADOS_MSG_TGN")) {
				// es una operacion de tgn
				vencimientoList = vencimientoQLBeanLocal.listaVencimiento("'P','B'", "B", Constants.COD_TGN);
				for (Vencimiento vencimiento : vencimientoList) {
					// se reporta si hubo una notificacion anteior
					if (!StringUtils.isBlank(vencimiento.getCveEstNotif()) && vencimiento.getCveEstNotif().equalsIgnoreCase("B")
							&& vencimiento.getLote() != null && vencimiento.getLote() > 0) {
						listaVen.add(vencimiento);
					}
				}
			} else if (SIODEX_PARAM.equals("AUTORIZADOTGN_MSG_TGN")) {
				// es una operacion de tgn
				vencimientoList = vencimientoQLBeanLocal.listaVencimiento("'A','S'", "A", Constants.COD_TGN);
				for (Vencimiento vencimiento : vencimientoList) {
					// se reporta si hubo una notificacion anteior
					if (!StringUtils.isBlank(vencimiento.getCveEstNotif()) && vencimiento.getCveEstNotif().equalsIgnoreCase("A")
							&& vencimiento.getLote() != null && vencimiento.getLote() > 0) {
						listaVen.add(vencimiento);
					}
				}
			} else if (SIODEX_PARAM.equals("AUTORIZAR_MSG_TGN")) {
				// el estado de la liquidacion es C cuando se genero la
				// operacion y el estado de la solicitud es C contabilizado				
				vencimientoList = vencimientoQLBeanLocal.listaVencimientoSinFechas("'C','O'", "A", Constants.COD_TGN);
				for (Vencimiento vencimiento : vencimientoList) {
					Solicitud solicitud = solicitudQLBeanLocal.getSolicitudByCodLiq(vencimiento.getLiqCodigo(), "C");
					if (solicitud != null){
						listaVen.add(vencimiento);
					}
					// **********************************************************
				}
				// whf ojoo por desa borrar				
//				List<Solicitud> solicitudLista = solicitudQLBeanLocal.listaSolicitud("C", Constants.COD_TGN, null);
//				for (Solicitud solicitud : solicitudLista) {
//					Vencimiento vencimiento = vencimientoQLBeanLocal.getVencimiento("", 0, solicitud.getLiqCodigo());
//					// el estado de la notificacion debe ser autorizado A
//					if ((vencimiento.getCveEstado().equals("O") || vencimiento.getCveEstado().equals("A"))
//							&& !StringUtils.isBlank(vencimiento.getCveEstNotif()) && vencimiento.getCveEstNotif().equals("A")) {
//						listaVen.add(vencimiento);
//					}
//				}
				
				// /////////////////////////////////////////////////////
				// whf ojoo por desa borrar
				// vencimientoList =
				// vencimientoQLBeanLocal.listaVencimiento("'C','A'",
				// Constants.COD_TGN);
				// for (Vencimiento vencimiento : vencimientoList) {
				// // se reporta si hubo una notificacion anteior
				// if (!StringUtils.isBlank(vencimiento.getCveEstNotif()) &&
				// vencimiento.getCveEstNotif().equalsIgnoreCase("A")
				// && vencimiento.getLote() != null && vencimiento.getLote()
				// > 0) {
				// listaVen.add(vencimiento);
				// }
				// }
				// /////////////////////////////////////////////////////
			}

		}

		logger.info("lista: " + (listaVen == null ? "NULL" : listaVen.size()));
	}

	public String botonDetalle() throws IOException {

		logger.info("detalle: " + liq.getPtmCodigo());
		String codigo = liq.getLiqCodigo();

		// cargando prestamo
		((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("codigo", codigo);

		FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/detalleVenO.jsf");

		return "/pages/detalleVenO";
	}

	public String abrirDetalleVerificar() throws IOException {
		logger.info("Abriendo detalle paraaaa: " + liq.getPtmCodigo());

		String codigo = liq.getLiqCodigo();
		File file = new File();
		file.setData(liq.getDocPdf()); // cargando el byte del archivo desde
										// bbdd
		file.setName("estado.pdf");
		if (liq.getDocPdf() != null) {
			file.setLength(liq.getDocPdf().length);
		} else {
			file.setLength(0);
		}

		// cargando prestamo
		((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("codigo", codigo);
		((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("file2", file);
		String retStr = "";

		HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);

		session.removeAttribute("detalleVenController");
		getVisitBean().setParametro("SIODEX_PARM_VERIFICAR", false);
		logger.info("XXX: visti parame " + getVisitBean().getParametro("SIODEX_PARAM"));
		if (getVisitBean().getParametro("SIODEX_PARAM").equals("NOTIFICAR_MSG_TGN")) {
			FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/detalleVen.jsf");
			retStr = "/pages/detalleVen";
		} else if (getVisitBean().getParametro("SIODEX_PARAM").equals("AUTORIZAR_MSG_TGN")
				|| getVisitBean().getParametro("SIODEX_PARAM").equals("AUTORIZADOTGN_MSG_TGN")) {
			FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/detalleVenA.jsf");
			retStr = "/pages/detalleVenA";
		} else {
			FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/detalleVen.jsf");
			retStr = "/pages/detalleVen";
		}
		return retStr;
	}

	/**
	 * Envia el mensaje de mensaje sobre vencimiento solo se realiza por un solo
	 * registro a diferencia del metodo notificar() que lo realiza en lote
	 * 
	 * @return
	 * @throws DataException 
	 * @throws IOException 
	 */
	//@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public String botonEnviarMensaje() throws DataException, IOException {
		logger.info("botonEnviarMensaje: " + liq.getPtmCodigo());
		
		/////////////////////
		// whf borrar
//		LogAuditoria logAuditoria = new LogAuditoria();
//		logAuditoria.setLogAuditoriaId(0);
//		logAuditoria.setCodUsuario("codUsuario codParticipante");
//		logAuditoria.setEstacion("estacion");
//		logAuditoria.setCodTransaccion("codTransaccion");
//		logAuditoria.setFechaHora(new Date());
//		
//		Liquidacion liquidacion = liquidacionQLBeanLocal.getLiquidacion(liq.getLiqCodigo());
//		liquidacion.setFechaHora(new Date());
//		liquidacion.setCveEstnotif("W");		
//		//liquidacionQLBeanLocal.edit(liquidacion);
//		if (liquidacion.getLiqCodigo() != null){
//			logger.info("XXX:GRRR0000000 ooooo");
//
//			//throw new DataException("error de prrrrrrviiiiiiir0000000");
//		}		
//		try{
//			liquidacion = liquidacionQLBeanLocal.cambioEstado(liquidacion, "", "X", logAuditoria);
//			logger.info("XXX:GRRRRRRRRRRRRRR!!");		
//		}catch (Exception e) {
//			// TODO: handle exception
//			logger.info("XXX:GRfasdf ooooo");
//			throw new DataException("GRfasdf ooooo");
//		}
//
//		try{
//			liquidacion = liquidacionQLBeanLocal.cambioEstado(liquidacion, "", "H", logAuditoria);
//			logger.info("XXX:GRRRRRRRRRRRRRR!!");		
//			if (liquidacion.getLiqCodigo() != null){
//				logger.info("XXX:GRRRRRRRRRRRRRR ooooo");
//				throw new DataException("error de prrrrrrviiiiiiir");
//			}			
//		}catch (Exception e) {
//			// TODO: handle exception
//			logger.info("XXX:GRfasdf oooo333o");
//			throw new DataException("GRfasdf ooo333oo");
//		}		
		
		//////////////////////////
		
		String codigo = liq.getLiqCodigo();

		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("SIODEX_PARAM", getVisitBean().getParametro("SIODEX_PARAM"));
		parametros.put("usuario", getVisitBean().getUsuario().getUsrLogin());
		parametros.put("estacion", getVisitBean().getUsuario().getUsrIpasignado());		
		
		String pagina = "";
		
		if (getVisitBean().getParametro("SIODEX_PARAM").equals("NOTIFICAR_MSG_TGN")) {
			parametros.put("tipooperacion", "NOTIFICAR_MSG_TGN_LIQ");
			pagina = "vencimientosTGNNotif.jsf";
		} else if (getVisitBean().getParametro("SIODEX_PARAM").equals("AUTORIZAR_MSG_TGN")) {
			parametros.put("tipooperacion", "AUTORIZAR_MSG_TGN_LIQ");
			pagina = "vencimientosTGNAuto.jsf";
		} else if (getVisitBean().getParametro("SIODEX_PARAM").equals("NOTIFOBSERVADOS_MSG_TGN")) {
			parametros.put("tipooperacion", "NOTIFOBSERVADOS_MSG_TGN_LIQ");
			pagina = "vencimientosTGNObserv.jsf";
		}

		parametros.put("codigoLiq", codigo);
		parametros.put("urlServ", urlServ());

		logger.info("Parametros enviados: " + ArrayUtils.toString(parametros));

		Map<String, Object> mapResult = servicio.procesarMensaje(parametros);

		String codResp = (String) mapResult.get("cod_resp");
		String respuesta = (String) mapResult.get("respuesta");
		logger.info("XXX: respuesta: " + respuesta);

		if (!StringUtils.isBlank(codResp) && codResp.equals("-1")) {
			FacesContext.getCurrentInstance().addMessage("listavenc", new FacesMessage(FacesMessage.SEVERITY_ERROR, respuesta, null));
		} else {
			FacesContext.getCurrentInstance().addMessage("listavenc", new FacesMessage(FacesMessage.SEVERITY_INFO, respuesta, null));
			FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/"+ pagina);			
		}

		return "";

	}

	public String notificar() {
		String tipoConsulta = (String) getVisitBean().getParametro("SIODEX_PARAM");
		Map<String, Object> parametros = new HashMap<String, Object>();

		parametros.put("SIODEX_PARAM", getVisitBean().getParametro("SIODEX_PARAM"));

		if (tipoConsulta.equals("NOTIFICAR_MSG_TGN")) {
			parametros.put("tipooperacion", "NOTIFICAR_MSG_TGN_LOTE");
		} else if (tipoConsulta.equals("NOTIFOBSERVADOS_MSG_TGN")) {
			parametros.put("tipooperacion", "NOTIFOBSERVADOS_MSG_TGN_LOTE");
		}

		// ////////////////////////////////////////////////////
		// whf borrar desa
		// if (tipoConsulta != null) {
		// liquidacionQLBeanLocal.getLiquidacion("003019");
		// return "";
		// }

		// ////////////////////////////////////////////////////
		parametros.put("urlServ", urlServ());
		Map<String, Object> mapResult = servicio.procesarMensaje(parametros);

		String codResp = (String) mapResult.get("cod_resp");
		String respuesta = (String) mapResult.get("respuesta");
		logger.info("XXX: respuesta: " + respuesta);

		if (!StringUtils.isBlank(codResp) && codResp.equals("-1")) {
			FacesContext.getCurrentInstance().addMessage("listavenc", new FacesMessage(FacesMessage.SEVERITY_ERROR, respuesta, null));
		} else {
			FacesContext.getCurrentInstance().addMessage("listavenc", new FacesMessage(FacesMessage.SEVERITY_INFO, respuesta, null));
		}
		return "";
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Vencimiento getLiq() {
		return liq;
	}

	public void setLiq(Vencimiento liq) {
		this.liq = liq;
	}

	public List<Vencimiento> getListaVen() {
		return listaVen;
	}

	public static String urlServ() {
		// retorna url de la dir ip mas el contexto
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		StringBuffer url = request.getRequestURL();
		String result = url.substring(0, url.indexOf(request.getContextPath()) + request.getContextPath().length());

		return result;
	}
}
