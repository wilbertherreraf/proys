package gob.bcb.jee.siodex.web.controller;

import gob.bcb.jee.siodex.QL.CoinQLBeanLocal;
import gob.bcb.jee.siodex.QL.MensajeDatosQLBeanLocal;
import gob.bcb.jee.siodex.QL.SolicitudQLBeanLocal;
import gob.bcb.jee.siodex.QL.VencimientoQLBeanLocal;
import gob.bcb.jee.siodex.controller.BaseBean;
import gob.bcb.jee.siodex.entities.ComisionBancaria;
import gob.bcb.jee.siodex.entities.Cuenta;
import gob.bcb.jee.siodex.entities.LiquidacionDet;
import gob.bcb.jee.siodex.entities.Mensaje;
import gob.bcb.jee.siodex.entities.MensajeDatos;
import gob.bcb.jee.siodex.entities.Solicitud;
import gob.bcb.jee.siodex.entities.Vencimiento;
import gob.bcb.jee.siodex.exception.DataException;
import gob.bcb.jee.siodex.pojos.VcDatosAdic;
import gob.bcb.jee.siodex.service.DeudaBeanLocal;
import gob.bcb.jee.siodex.service.MensajeSwiftBeanLocal;
import gob.bcb.jee.siodex.service.OperacionBeanLocal;
import gob.bcb.jee.siodex.util.CadenaEncDec;
import gob.bcb.jee.siodex.util.UtilsDate;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

// The @Model stereotype is a convenience mechanism to make this a request-scoped bean that has an
// EL name
// Read more about the @Model stereotype in this FAQ:
// http://sfwk.org/Documentation/WhatIsThePurposeOfTheModelAnnotation
//@Model
@ManagedBean(name = "detalleVenOController")
@ViewScoped
public class DetalleVenOController extends BaseBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	static final Logger logger = Logger.getLogger(DetalleVenOController.class);

	@PersistenceContext(unitName = "siodex")
	EntityManager em;

	@Inject
	private VencimientoQLBeanLocal vencimientoQLBeanLocal;

	@Inject
	private OperacionBeanLocal operacion;
	@Inject
	private CoinQLBeanLocal coinQLBeanLocal;
	@Inject
	private MensajeSwiftBeanLocal mensajeSwiftBeanLocal;
	@Inject
	private MensajeDatosQLBeanLocal mensajeDatosQLBeanLocal;
	@Inject
	private SolicitudQLBeanLocal solicitudQLBeanLocal;
	@Inject
	private DeudaBeanLocal deudaBeanLocal;
	
	private String codigo = "";
	private String titulo = "";
	private String codTipoOper = "";
	private String total = "";
	private String usuario = "";
	private String nti = "";
	private String observ = "";
	private BigDecimal equivalente = BigDecimal.valueOf(0.00);
	private BigDecimal comiPago = BigDecimal.valueOf(0.00);
	private BigDecimal swift = BigDecimal.valueOf(200.00);
	private BigDecimal utiles = BigDecimal.valueOf(40.00);
	private BigDecimal comiTotal = BigDecimal.valueOf(0.00);
	private BigDecimal pagoTotal = BigDecimal.valueOf(0.00);
	private BigDecimal tcOtro = BigDecimal.valueOf(0.00);
	private BigDecimal totalMo = BigDecimal.valueOf(0.00);

	private boolean mostrarTc = false;
	private boolean bloqueado = true;
	private boolean mostrarSwift = true;
	private boolean habilitaVerificar = false;
	private String tituloError;
	private String mensajeError;
	private boolean mostrarError = false;
	private boolean conSolicitud = false;

	private List<SelectItem> cuentasS = new ArrayList<SelectItem>();
	private Cuenta cuentaS = null;
	private String ctaS = "";

	private List<SelectItem> cuentasI = new ArrayList<SelectItem>();
	private Cuenta cuentaI = null;
	private String ctaI = "";

	private List<SelectItem> cuentasC = new ArrayList<SelectItem>();
	private Cuenta cuentaC = null;
	private String ctaC = "";

	private Vencimiento vencimiento = null;

	private List<LiquidacionDet> listaDet = new ArrayList<LiquidacionDet>();

	public List<LiquidacionDet> getListaDet() {
		return listaDet;
	}

	private LiquidacionDet liquidacionDetSelected;
	private String contextPath;

	private Cuenta cuentaObjDEUD;
	private VcDatosAdic vcDatosAdic;

	private List<Mensaje> mensajeLista = new ArrayList<Mensaje>();
	private Mensaje selectedMensaje;

	private String swiftTexto;

	private Integer nroPreliminares;

	@PostConstruct
	public void inicio() {
		logger.info("=============ooo00OOO00ooo===================");
		try {
			// obteniendo el path de la aplicacion
			HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
			contextPath = request.getContextPath();
			recuperarParametros();

			usuario = getVisitBean().getUsuario().getUsrLogin();
			String codEnt = getVisitBean().getParticipante().getCodPte();
			String ip = getVisitBean().getUsuario().getUsrIpasignado();

			logger.info("Par. SIODEX_PARAM= " + getVisitBean().getParametro("SIODEX_PARAM") + " usuario: " + usuario + " ==> codEnt: " + codEnt
					+ " ip " + ip);

			codigo = (String) ((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).getAttribute("codigo");
			logger.info("Objeto a instanciar: " + codigo);

			vencimiento = vencimientoQLBeanLocal.getVencimiento("", 0, codigo);
			vencimiento.setLogAuditoria(getLogAuditoriaFromVisit(), codEnt);

			vcDatosAdic = vencimiento.getVcDatosAdic();

			codTipoOper = vencimiento.getCodTipoOperacion();
			
			titulo = vencimiento.getAcreedor() + " - " + vencimiento.getRefAcre() + " - " + vencimiento.getPrestamo();

			logger.info("XXX: getParticipante().getCodPte " + getVisitBean().getParticipante().getCodPte() + " XX " + vencimiento.getCveEstado());
			if (vencimiento.getCveEstado().equals("O") || vencimiento.getCveEstado().equals("C") || vencimiento.getCveEstado().equals("S")) {
				// si el estado esta con operacion o contabilizado o con solicitud guardada solo se debe
				// recuperar datos
				// guardados
				actualizar();
			} else {

				if (getVisitBean().getParticipante().getCodPte().equals("900")
						&& (vencimiento.getCveEstado().equals("A") || vencimiento.getCveEstado().equals("P"))
						|| vencimiento.getCveEstado().equals("E")) {
					// solo se actualizará si el usuario es del BCB
					vencimiento.setFechaTc(vencimiento.getFechaVenc());
					//if (UtilsDate.compara(new Date(), vencimiento.getFechaVenc()) < 0) {
						// la fecha de venc es mayor a fecha hoy
						vencimiento.setFechaTc(new Date());
					//}
				}
				logger.info("Fecha de TC: " + UtilsDate.stringFromDate(vencimiento.getFechaTc(), "dd-MM-yyyy") + " Fecha Venc. "
						+ UtilsDate.stringFromDate(vencimiento.getFechaVenc(), "dd-MM-yyyy"));
				calcular(vencimiento.getFechaTc());
			}

			if (getVisitBean().getParametro("SIODEX_PARAM") != null) {
				habilitaVerificar = (vencimiento.getCveEstado().equals("P") && getVisitBean().getParametro("SIODEX_PARAM").equals("VERIFICAR_ESTCTA"))
						|| (vencimiento.getCveEstado().equals("V") && getVisitBean().getParametro("SIODEX_PARAM").equals("AUTORIZAR_ESTCTA"));
			}

		} catch (Exception e) {
			logger.error("Error al obtener vencimiento " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage("errorcito",
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Ocurrió un error: " + e.getMessage(), null));
		}
  	}

	public void calcular(Date fechaValor) throws DataException {
		logger.info("FecValor calculo " + fechaValor);

		vencimiento = vencimientoQLBeanLocal.calcularVencimiento(vencimiento, fechaValor, "", 0, codigo);
		// re calcular la comisiones

		actualizar();
	}

	public void actualizar() throws DataException {
		logger.info("actualizar datos liquidacion " + codigo);
		swiftTexto = "";
		listaDet = vencimiento.getLiquidacionDetLista();

		if (vencimiento.getAcreedor().startsWith("EXIMBANK") && !vencimiento.getAcreedor().contains("USA") && (listaDet.size() == 1)) {
			// monedas chinas koreanas el monto ingresa el usuario no se
			// recalcula el ven
			logger.info("==>[tipo] EXIMBANK..." + codigo);

		} else if (vencimiento.getAcreedor().equals("BID") && vencimiento.getRefAcre().contains("BL")) {
			logger.info("==>[tipo] BID-BL..." + codigo);
		} else if (vencimiento.getPtmCodigo().startsWith("B-H")) {
			logger.info("==>[tipo] enter BH..." + codigo);
		} else if (vencimiento.getPtmCodigo().startsWith("I-H")) {
			logger.info("==>[tipo] enter IH..." + codigo);
		} else if (vencimiento.getPtmCodigo().startsWith("I")) {
			logger.info("==>[tipo] enter I..." + codigo);
		} else if (codTipoOper.equals("14") || codTipoOper.equals("34") || codTipoOper.equals("35")) {
			logger.info("codTipoOper 14 o 34 o 35 ..." + codigo + " codTipoOper " + codTipoOper);

		} else {
			logger.info("==>[tipo] enter otros..." + codigo);
		}

		//rm se mostrará la comision swift en caso de que el tipo de operacion sea cobrar comisicon mensaje swift
		//mostrarSwift = (vencimiento.getCantMensSwift() > 0);
		mostrarSwift = vencimientoQLBeanLocal.isCobrarComMensajeSwit(codTipoOper);
		
		// se calcula las comisiones
		ComisionBancaria comisionBancaria = vencimiento.getComisionBancaria("COPA");
		if (comisionBancaria != null)
			comiPago = comisionBancaria.getMontoMN();

		comisionBancaria = vencimiento.getComisionBancaria("SWFT");
		if (comisionBancaria != null)
			swift = comisionBancaria.getMontoMN();

		comisionBancaria = vencimiento.getComisionBancaria("UTIL");
		if (comisionBancaria != null)
			utiles = comisionBancaria.getMontoMN();

		equivalente = vencimiento.getTotalBs();

		comiTotal = comiPago.add(swift).add(utiles);
		logger.info("XXX: equivalente " + equivalente + "  " + comiTotal);
		pagoTotal = equivalente.add(comiTotal);

		cuentaObjDEUD = vencimiento.getCuentaPrestamo("DEUD");
		cuentaS = vencimiento.getCuentaPrestamo("DEUD");
		cuentasS.add(new SelectItem(cuentaS.getCtaCodigo(), cuentaS.getCtaNumero()));
		ctaS = cuentaS.getCtaCodigo();

		if (vencimiento.getDeudor().equals("FNDR")) {
			cuentaI = vencimiento.getCuentaPrestamo("DEUI");
			cuentasI.add(new SelectItem(cuentaI.getCtaCodigo(), cuentaI.getCtaNumero()));
			ctaI = cuentaI.getCtaCodigo();
		}

		cuentaC = vencimiento.getCuentaPrestamo("DEUC");
		cuentasC.add(new SelectItem(cuentaC.getCtaCodigo(), cuentaC.getCtaNumero()));
		ctaC = cuentaC.getCtaCodigo();

		total = "Total Pago del " + DateFormat.getDateInstance().format(vencimiento.getFechaVenc()) + " en Bolivianos ";

		recuperarListaPreSwifts(vencimiento.getFechaPago());

		Solicitud solicitud = solicitudQLBeanLocal.getSolicitudByCodLiq(vencimiento.getLiqCodigo(), null);
		conSolicitud = (solicitud != null);
	}

	public String botonCancelar() throws IOException {

		FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/vencimientosO.jsf");

		return "";
	}

	public String actualizarFecValor() {

		try {
			logger.info("en actualizarFecValor " + codigo + " fecha " + UtilsDate.stringFromDate(vencimiento.getFechaTc(), "dd/MM/yyyy"));

			calcular(vencimiento.getFechaTc());
		} catch (DataException e) {
			logger.error("Error al obtener vencimiento " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage("errorcito",
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Ocurrió un error: " + e.getMessage(), null));
		}
		return "";
	}

	public String botonGuardarSolicitud() {
		try {
			logger.info("en botonGuardarSolicitud " + codigo);

			vencimiento.setComisionBancaria("COPA", comiPago);
			vencimiento.setComisionBancaria("SWFT", swift);
			vencimiento.setComisionBancaria("UTIL", utiles);

			// pre contabilizamos
			operacion.crearSolicitud(vencimiento, null);
			logger.info("fin generar solicitud " + vencimiento.getLiqCodigo());
			
			logger.info("llamando a registrar deuda " + vencimiento.getLiqCodigo());
			deudaBeanLocal.registrar(vencimiento, vencimiento.getLiqCodigo());
			
			mostrarError = true;
			tituloError = "MENSAJE";
			mensajeError = "La operación generó exitosamente la solicitud " + vencimiento.getLiqCodigo();

			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "La operación se generó exitosamente: ", null));

			Solicitud solicitud = solicitudQLBeanLocal.getSolicitudByCodLiq(vencimiento.getLiqCodigo(), "P");

			logger.info("codigo solicitud seleccionado para ver comprobante: " + solicitud.getSolCodigo());

			Integer codSol = solicitud.getSolCodigo();

			// cargando prestamo
			((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("codSol", codSol);

			FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/detalleComp.jsf");

			return "/pages/detalleComp";
		} catch (Exception e) {
			mostrarError = true;
			tituloError = "ERROR";
			mensajeError = "La operación generó ERROR: " + e.getMessage();
			logger.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "La operacion produjo un error: " + e.getMessage(), null));
			return "/pages/detalleVenO";
		}

	}

	public String botonGenerar() {
		try {
			logger.info("en botonGenerar " + codigo);
			// pre contabilizamos, armamos el swift y cambiamos el cambiamos el
			// estado
			operacion.generarOperacionEnMotor(vencimiento, vencimiento.getFechaPago());

			logger.info("fin generar operacion en moptor " + vencimiento.getLiqCodigo());
			mostrarError = true;
			tituloError = "MENSAJE";
			mensajeError = "La operación contable se generó exitosamente " + vencimiento.getLiqCodigo();
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "La operación se generó exitosamente: ", null));

			return "/";
		} catch (Exception e) {
			mostrarError = true;
			tituloError = "ERROR";
			mensajeError = "La operación generó ERROR: " + e.getMessage();
			logger.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "La operacion produjo un error: " + e.getMessage(), null));
			return "/pages/detalleVenO";
		}

	}

	public String botonRetornar() throws IOException {
		if (getVisitBean().getParametro("SIODEX_PARAM") == null) {
			return "/";
		}
		logger.info("En boton Retornar " + getVisitBean().getParametro("SIODEX_PARAM"));

		if (getVisitBean().getParametro("SIODEX_PARAM").equals("NOTIFICAR_MSG_TGN")) {
			FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/vencimientosTGNNotif.jsf");
		} else if (getVisitBean().getParametro("SIODEX_PARAM").equals("NOTIFOBSERVADOS_MSG_TGN")) {
			FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/vencimientosTGNObserv.jsf");
		} else if (getVisitBean().getParametro("SIODEX_PARAM").equals("VERIFICAR_ESTCTA")) {
			FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/vencimientos.jsf");
		} else if (getVisitBean().getParametro("SIODEX_PARAM").equals("AUTORIZAR_MSG_TGN")) {
			FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/vencimientosTGNAuto.jsf");
		} else if (getVisitBean().getParametro("SIODEX_PARAM").equals("AUTORIZADOTGN_MSG_TGN")) {
			FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/vencimientosTGNAutoXTG.jsf");
		} else if (getVisitBean().getParametro("SIODEX_PARAM").equals("AUTORIZAR_ESTCTA")) {
			FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/vencimientosA.jsf");
		} else if (getVisitBean().getParametro("SIODEX_PARAM").equals("HISTORICO_OPERACION")) {
			FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/vencimientosP.jsf");
		} else if (getVisitBean().getParametro("SIODEX_PARAM").equals("GENERAR_OPERACION")) {
			FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/vencimientosO.jsf");
		} else if (getVisitBean().getParametro("SIODEX_PARAM").equals("CONTABILIZAR_OPERACION")) {
			FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/operaciones.jsf");
		} else if (getVisitBean().getParametro("SIODEX_PARAM").equals("MODIFICAR_LIQUIDACION")) {
			FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/vencimientos_edit.jsf");
		}
		return "";
	}

	public String botonContinuar() throws IOException {
		logger.info("ir a verificar cuentas...");

		if (getVisitBean().getParametro("SIODEX_PARAM") == null) {
			return "";
		}

		if (vencimiento.getCveEstado().equals("P") && getVisitBean().getParametro("SIODEX_PARAM").equals("VERIFICAR_ESTCTA")) {
			// viene de pagina de ver detalle vencimiento y se presiona aceptar
			((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("titulo", titulo);
			((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("codigo", codigo);

			FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/detalleVerificar.jsf");
		}
		return "";
	}

	public String botonIrAObservacion() throws IOException {

		logger.info("ir a observacion...");

		((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("titulo", titulo);
		((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("codigo", codigo);

		FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/detalleObserv.jsf");

		return "";

	}

	public String botonAutorizar() throws IOException {

		logger.info("autorizando...");
		String resp = cambiarEstado(vencimiento, "A", "");

		if (resp != null) {
			FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/vencimientosA.jsf");
			return "";

		} else {
			return null;
		}

	}

	public String botonConfirmar() throws IOException {

		logger.info("botonConfirmar...");
		String resp = cambiarEstado(vencimiento, "F", "");
		if (resp != null) {
			FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/");
			return "";
		} else {
			return null;
		}

	}

	/**
	 * rechazo de una operacion
	 * 
	 * @return
	 * @throws IOException
	 */
	public String botonRechazar() throws IOException {

		logger.info("rechazando...");
		String resp = cambiarEstado(vencimiento, "P", "");
		if (resp != null) {
			FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/vencimientosA.jsf");
			return "";
		} else {
			return null;
		}

	}

	public String botonObservar() {

		logger.info("observando liq...");
		return cambiarEstado(vencimiento, "B", observ);
	}

	public String botonVerificar() throws IOException {

		logger.info("verificando...");
		String resp = cambiarEstado(vencimiento, "V", "");
		if (resp != null) {
			FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/vencimientos.jsf");
			return "";
		} else {
			return null;
		}

	}

	public String cambiarEstado(Vencimiento venc, String nuevoEstado, String observacion) {

		if (StringUtils.isBlank(nuevoEstado)) {
			nuevoEstado = "";
		}

		logger.info("Cambiando estado de " + venc.getLiqCodigo() + " a: " + nuevoEstado);
		// solo al camvbiar a verificado se guarda las comisiones
		try {
			vencimiento.setComisionBancaria("COPA", comiPago);
			vencimiento.setComisionBancaria("SWFT", swift);
			vencimiento.setComisionBancaria("UTIL", utiles);

			vencimiento = vencimientoQLBeanLocal.actualizarLiquidacion(vencimiento, observacion, nuevoEstado, "T");

			String tipocorreo = "";

			if (nuevoEstado.equals("A")) {
				tipocorreo = "PAGOAUTORIZADO";
			} else if (nuevoEstado.equals("B")) {
				tipocorreo = "VENCOBSERVADO";
			} else if (nuevoEstado.equals("C")) {
				tipocorreo = "LIQCONTABILIZADA";
			}

			if (!StringUtils.isBlank(tipocorreo)) {
				vencimientoQLBeanLocal.enviarCorreos(vencimiento, observacion, tipocorreo, "");
			}

			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_INFO, "Operacion realizada exitosamente " + vencimiento.getLiqCodigo(), null));
			return "";
		} catch (Exception e) {
			logger.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "La operacion produjo un error: " + e.getMessage(), null));
			return null;
		}

	}

	public String botonIrAComprobante() throws IOException {
		// viene de pagina de ver detalle vencimiento y se presiona aceptar
		((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("codSol", codigo);

		FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/detalleVerificar.jsf");

		return "";
	}

	public String botonGenerarMensSwiftFValor() {
		try {
			logger.info("en botonGenerarMensSwiftFValor " + codigo);

			vencimiento.setComisionBancaria("COPA", comiPago);
			vencimiento.setComisionBancaria("SWFT", swift);
			vencimiento.setComisionBancaria("UTIL", utiles);

			// registramos solo los mensajes swifts
			mensajeLista = operacion.registrarMensajeSwift(vencimiento, vencimiento.getFechaPago(), true, "E", false);

			mostrarError = true;
			tituloError = "MENSAJE";
			mensajeError = "La operación se generó exitosamente los mensajes swift fueron creados " + vencimiento.getCantMensSwift()
					+ " mensajes para liq. " + vencimiento.getLiqCodigo() + " a fecha valor "
					+ UtilsDate.stringFromDate(vencimiento.getFechaPago(), "dd/MM/yyyy");

			logger.info("fin botonGenerarMensSwiftFValor " + mensajeError);

			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, mensajeError, null));

			return "";
		} catch (Exception e) {
			// sessionContext.setRollbackOnly();
			mostrarError = true;
			tituloError = "ERROR";
			mensajeError = "La operación generó ERROR: " + e.getMessage();
			logger.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "La operacion produjo un error: " + e.getMessage(), null));
			return null;
		}

	}

	public void recuperarListaPreSwifts(Date fechaValor) throws DataException {
		logger.info("Recuperando mensajes swifts " + vencimiento.getLiqCodigo());
		mensajeLista.clear();
		nroPreliminares = 0;
		mensajeLista = operacion.registrarMensajeSwift(vencimiento, fechaValor, false, "PRELIMINAR", false);
		for (Mensaje mensaje : mensajeLista) {
			if (mensaje.getCveEstadoS().equals("PRELIMINAR") || mensaje.getCveEstadoS().equals("E")) {
				nroPreliminares++;
			}
		}
	}

	public String actualizarFecValorMenSwift() {

		try {
			logger.info("FecValorMenSwift " + vencimiento.getFechaPago());

			recuperarListaPreSwifts(vencimiento.getFechaPago());
		} catch (DataException e) {
			logger.error("Error al obtener vencimiento " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage("errorcito",
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Ocurrió un error: " + e.getMessage(), null));
		}
		return "";
	}

	public String verMensajeSwiftTexto() {

		logger.info("en verMensajeSwiftTexto " + (selectedMensaje == null));
		try {
			if (selectedMensaje != null) {
				logger.info("retornando swift en texto " + selectedMensaje.getMenCodigo());

				if (vencimiento.getReferencia() == null) {
					vencimiento.setReferencia("");
				}

				if (selectedMensaje.getCveEstadoS() != null && selectedMensaje.getCveEstadoS().equals("PRELIMINAR")) {

					logger.info("swift en texto PRELIMINAR " + selectedMensaje.getMenCodigo());

					Integer nroSwift = Integer.valueOf(selectedMensaje.getLiqDetalle());

					List<MensajeDatos> mensajeDatosList = mensajeSwiftBeanLocal.crearSwift(vencimiento, selectedMensaje, vencimiento.getReferencia(),
							nroSwift, selectedMensaje.getPtmCodigo(), selectedMensaje.getTraCodigo(), false);

					swiftTexto = mensajeSwiftBeanLocal.crearSwiftTexto(mensajeDatosList);
				} else {
					logger.info("swift en texto REGISTRADO " + selectedMensaje.getMenCodigo());

					List<MensajeDatos> mensajeDatosList = mensajeDatosQLBeanLocal.getDatos(selectedMensaje.getMenCodigo());
					swiftTexto = mensajeSwiftBeanLocal.crearSwiftTexto(mensajeDatosList);
				}
			}
		} catch (Exception e) {
			logger.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "La operacion produjo un error: " + e.getMessage(), null));
		}
		return "";
	}

	public String botonIrALiqDetalle() throws IOException {

		logger.info("codigo botonIrALiqDetalle: " + liquidacionDetSelected.getLiquidacionDetPK().getLiqCodigo());

		String coddetalle = liquidacionDetSelected.getLiquidacionDetPK().getLiqDetalle();

		// cargando prestamo
		((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("codigo", codigo);
		((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("coddetalle", coddetalle);

		FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/liquidaciondet_edit.jsf");

		return "/pages/liquidaciondet_edit";
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getTotal() {
		return total;
	}

	public void setTotal(String total) {
		this.total = total;
	}

	public BigDecimal getEquivalente() {
		return equivalente;
	}

	public void setEquivalente(BigDecimal equivalente) {
		this.equivalente = equivalente;
	}

	public BigDecimal getComiPago() {
		return comiPago;
	}

	public void setComiPago(BigDecimal comiPago) {
		this.comiPago = comiPago;
	}

	public BigDecimal getSwift() {
		return swift;
	}

	public void setSwift(BigDecimal swift) {
		this.swift = swift;
	}

	public BigDecimal getUtiles() {
		return utiles;
	}

	public void setUtiles(BigDecimal utiles) {
		this.utiles = utiles;
	}

	public BigDecimal getComiTotal() {
		return comiTotal;
	}

	public void setComiTotal(BigDecimal comiTotal) {
		this.comiTotal = comiTotal;
	}

	public BigDecimal getPagoTotal() {
		return pagoTotal;
	}

	public void setPagoTotal(BigDecimal pagoTotal) {
		this.pagoTotal = pagoTotal;
	}

	public String getTituloError() {
		return tituloError;
	}

	public void setTituloError(String tituloError) {
		this.tituloError = tituloError;
	}

	public String getMensajeError() {
		return mensajeError;
	}

	public void setMensajeError(String mensajeError) {
		this.mensajeError = mensajeError;
	}

	public boolean isMostrarError() {
		return mostrarError;
	}

	public void setMostrarError(boolean mostrarError) {
		this.mostrarError = mostrarError;
	}

	public Cuenta getCuentaS() {
		return cuentaS;
	}

	public void setCuentaS(Cuenta cuentaS) {
		this.cuentaS = cuentaS;
	}

	public List<SelectItem> getCuentasS() {
		return cuentasS;
	}

	public void setCuentasS(List<SelectItem> cuentasS) {
		this.cuentasS = cuentasS;
	}

	public Cuenta getCuentaI() {
		return cuentaI;
	}

	public void setCuentaI(Cuenta cuentaI) {
		this.cuentaI = cuentaI;
	}

	public List<SelectItem> getCuentasI() {
		return cuentasI;
	}

	public void setCuentasI(List<SelectItem> cuentasI) {
		this.cuentasI = cuentasI;
	}

	public List<SelectItem> getCuentasC() {
		return cuentasC;
	}

	public void setCuentasC(List<SelectItem> cuentasC) {
		this.cuentasC = cuentasC;
	}

	public Cuenta getCuentaC() {
		return cuentaC;
	}

	public void setCuentaC(Cuenta cuentaC) {
		this.cuentaC = cuentaC;
	}

	public String getCtaS() {
		return ctaS;
	}

	public void setCtaS(String ctaS) {
		this.ctaS = ctaS;
	}

	public String getCtaI() {
		return ctaI;
	}

	public void setCtaI(String ctaI) {
		this.ctaI = ctaI;
	}

	public String getCtaC() {
		return ctaC;
	}

	public void setCtaC(String ctaC) {
		this.ctaC = ctaC;
	}

	public String getNti() {
		return nti;
	}

	public void setNti(String nti) {
		this.nti = nti;
	}

	public BigDecimal getTcOtro() {
		return tcOtro;
	}

	public void setTcOtro(BigDecimal tcOtro) {
		this.tcOtro = tcOtro;
	}

	public BigDecimal getTotalMo() {
		return totalMo;
	}

	public void setTotalMo(BigDecimal totalMo) {
		this.totalMo = totalMo;
	}

	public boolean isMostrarTc() {
		return mostrarTc;
	}

	public void setMostrarTc(boolean mostrarTc) {
		this.mostrarTc = mostrarTc;
	}

	public boolean isBloqueado() {
		return bloqueado;
	}

	public void setBloqueado(boolean bloqueado) {
		this.bloqueado = bloqueado;
	}

	public boolean isMostrarSwift() {
		return mostrarSwift;
	}

	public void setMostrarSwift(boolean mostrarSwift) {
		this.mostrarSwift = mostrarSwift;
	}

	public Vencimiento getVencimiento() {
		return vencimiento;
	}

	public void setVencimiento(Vencimiento vencimiento) {
		this.vencimiento = vencimiento;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public Cuenta getCuentaObjDEUD() {
		return cuentaObjDEUD;
	}

	public void setCuentaObjDEUD(Cuenta cuentaObjDEUD) {
		this.cuentaObjDEUD = cuentaObjDEUD;
	}

	public String getObserv() {
		return observ;
	}

	public void setObserv(String observ) {
		this.observ = observ;
	}

	public boolean isHabilitaVerificar() {
		return habilitaVerificar;
	}

	public void setHabilitaVerificar(boolean habilitaVerificar) {
		this.habilitaVerificar = habilitaVerificar;
	}

	public VcDatosAdic getVcDatosAdic() {
		return vcDatosAdic;
	}

	public void setVcDatosAdic(VcDatosAdic vcDatosAdic) {
		this.vcDatosAdic = vcDatosAdic;
	}

	public List<Mensaje> getMensajeLista() {
		return mensajeLista;
	}

	public void setMensajeLista(List<Mensaje> mensajeLista) {
		this.mensajeLista = mensajeLista;
	}

	public Mensaje getSelectedMensaje() {
		return selectedMensaje;
	}

	public void setSelectedMensaje(Mensaje selectedMensaje) {
		this.selectedMensaje = selectedMensaje;
	}

	public void montoChanged(ValueChangeEvent event) throws DataException {

		logger.info("enter montochanged");
		String montoS = event.getNewValue().toString();
		logger.info("montoS: " + montoS);
		Double montoD = Double.parseDouble(montoS);
		logger.info("montoD: " + montoD);
		BigDecimal tcV = coinQLBeanLocal.getTC(vencimiento.getFechaTc(), "35");
		equivalente = BigDecimal.valueOf(montoD).multiply(tcV).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
		comiPago = vencimientoQLBeanLocal.calcularComisionCOPA(vencimiento, vencimiento.getFechaTc());

		comiTotal = comiPago.add(swift).add(utiles);
		pagoTotal = equivalente.add(comiTotal);

		vencimiento.setTotalUsd(BigDecimal.valueOf(montoD));
		logger.info("totalV: " + vencimiento.getTotalUsd());
	}

	public String getSwiftTexto() {
		return swiftTexto;
	}

	public void setSwiftTexto(String swiftTexto) {
		this.swiftTexto = swiftTexto;
	}

	public Integer getNroPreliminares() {
		return nroPreliminares;
	}

	public void setNroPreliminares(Integer nroPreliminares) {
		this.nroPreliminares = nroPreliminares;
	}

	public void mostrarReporteConfPago(ActionEvent event) {
		logger.info("VISTA UrlReporte codificado AAANTES");
	}

	public String getUrlReporteConfPago() {
		logger.info("VISTA en getUrlReporteConfPago");
		return urlReporte(urlServ(), "REPCONFIRM", codigo);
	}

	public static String urlReporte(String urlServ, String tipo, String codLiq) {
		Map<String, String> map = new LinkedHashMap<String, String>();
		map.put("cod", codLiq);
		map.put("tipo", tipo);

		String encode = CadenaEncDec.encode(map);
		String urlReporte = urlServ + "/reporte?codRepo=" + encode;
		logger.info("VISTA UrlReporte codificado [" + ArrayUtils.toString(map) + "] " + urlReporte);

		return urlReporte;
	}

	public static String urlServ() {
		// retorna url de la dir ip mas el contexto
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		StringBuffer url = request.getRequestURL();
		String result = url.substring(0, url.indexOf(request.getContextPath()) + request.getContextPath().length());

		return result;
	}

	public boolean isConSolicitud() {
		return conSolicitud;
	}

	public void setConSolicitud(boolean conSolicitud) {
		this.conSolicitud = conSolicitud;
	}

	public LiquidacionDet getLiquidacionDetSelected() {
		return liquidacionDetSelected;
	}

	public void setLiquidacionDetSelected(LiquidacionDet liquidacionDetSelected) {
		this.liquidacionDetSelected = liquidacionDetSelected;
	}
}
