package gob.bcb.jee.siodex.QL;

import java.sql.Connection;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.ejb.Stateless;

import org.apache.log4j.Logger;


@Stateless
public class ConexionSQLBean implements ConexionSQLBeanLocal
{

  @Resource(name = "java:jboss/datasources/sigcoinDS")
  javax.sql.DataSource dataSource;

  static final Logger logger = Logger.getLogger(ConexionSQLBean.class);
  
  /**
   * Default constructor.
   */
  public ConexionSQLBean()
  {
    // TODO Auto-generated constructor stub
  }

    /**
	 * Método que permite obtener una conexión al datasource definido.
	 */
  @Override
  public Connection getConexion() throws Exception
  {
    Connection connection = null;
    try
    {
      connection = dataSource.getConnection();
    }
    catch (SQLException e)
    {
    	// TODO Auto-generated catch block
    	System.out.println("Error de conexión");
    	logger.info("error SQL : " + e.getMessage());
    	e.printStackTrace();
    }
    catch (Exception e) 
    {
    	logger.info("error: " + e.getMessage());
		e.printStackTrace();
	}

    return connection;

  }
}
