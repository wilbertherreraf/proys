package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.Liquidacion;
import gob.bcb.jee.siodex.entities.LiquidacionDet;
import gob.bcb.jee.siodex.entities.PrestamoInstancia;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJBException;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

@Stateless
@LocalBean
public class PrestamoInstanciaQLBean extends DaoGeneric<PrestamoInstancia> implements PrestamoInstanciaQLBeanLocal {

	static final Logger logger = Logger.getLogger(PrestamoInstanciaQLBean.class);

	@PersistenceContext(unitName = "siodex")
	EntityManager em;

	/**
	 * Default constructor.
	 */

	public PrestamoInstanciaQLBean() {
		// TODO Auto-generated constructor stub
		super(PrestamoInstancia.class);	
		}

	
	@SuppressWarnings("unchecked")
	public List<PrestamoInstancia> listaInstancia(String prestamo, int tramo, String tipo) {

		List<PrestamoInstancia> lista = new ArrayList<PrestamoInstancia>();

		StringBuilder query = new StringBuilder();

		query.append("select p from PrestamoInstancia p where p.prestamoInstanciaPK.ptmCodigo = ? and p.prestamoInstanciaPK.traCodigo = ? and substr(p.prestamoInstanciaPK.cveTipoLiq,1,3) = ?");

		Query consulta = em.createQuery(query.toString());
		consulta.setParameter(1, prestamo);
		consulta.setParameter(2, tramo);
		consulta.setParameter(3, tipo);

		lista = consulta.getResultList();

		return lista;

	}


	@Override
	public void setEntityManager(EntityManager entityManager) {
		// TODO Auto-generated method stub

	}

	@Override
	public EntityManager getEntityManager() {
		// TODO Auto-generated method stub
		return em;
	}

}
