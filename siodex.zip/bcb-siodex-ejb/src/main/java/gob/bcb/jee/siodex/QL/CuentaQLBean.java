package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.commons.Constants;
import gob.bcb.jee.siodex.entities.Cuenta;
import gob.bcb.jee.siodex.entities.CuentaAcreedor;
import gob.bcb.jee.siodex.exception.DataException;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

@Stateless
@LocalBean
public class CuentaQLBean implements CuentaQLBeanLocal {

	static final Logger logger = Logger.getLogger(CuentaQLBean.class);

	@PersistenceContext(unitName = "siodex")
	EntityManager em;

	@Inject
	private CoinQLBeanLocal coinQLBeanLocal;

	/**
	 * Default constructor.
	 */
	public CuentaQLBean() {
		// TODO Auto-generated constructor stub
	}

	public Cuenta getCuenta(String codCuenta) throws DataException {
		List<Cuenta> cuentaLista = new ArrayList<Cuenta>();

		StringBuilder jsql = new StringBuilder();
		jsql.append("SELECT c.cta_codigo, c.cta_factura, c.cta_numero, c.cta_nombre, c.cta_nit, c.bco_codigo, b.bco_nombre,c.cta_afectable, c.codpart, c.cve_tipo_cta, ");
		jsql.append("c.cta_direccion, c.cta_plaza, c.cta_swift,b.bco_bic "); 
		jsql.append("FROM cuenta c, banco b ");
		jsql.append("WHERE c.bco_codigo = b.bco_codigo ");
		jsql.append("and b.cve_vigente = 1 and c.cve_vigente = 1 ");

		if (!StringUtils.isBlank(codCuenta)) {
			jsql.append("and c.cta_codigo = '" + codCuenta + "' ");
		}
		
		logger.info("==>Consulta lista Cuentas: " + jsql);

		Query query = em.createNativeQuery(jsql.toString());
		List lista = query.getResultList();
		Iterator it = lista.iterator();
		String ctaCodigo = "";
		try {
			while (it.hasNext()) {
				Object[] da = (Object[]) it.next();
				// logger.info("XXX: en arrrrrrrrray2222 " +
				// ArrayUtils.toString(da));
				Cuenta cta = new Cuenta();
				cta.setCtaCodigo((String) da[0]);
				cta.setCtaFactura((String) da[1]);
				cta.setCtaNumero((String) da[2]);
				cta.setCtaNombre((String) da[3]);
				cta.setCtaNit((String) da[4]);
				cta.setBcoCodigo((String) da[5]);
				cta.setBcoNombre((String) da[6]);
				cta.setCtaAfectable((String) da[7]);
				String codPart = (String) da[8];
				cta.setCodPart(codPart);
				String cveTipoCta = (String) da[9];
				cta.setCveTipoCta(cveTipoCta);
				
				cta.setCtaDireccion((String) da[10]);
				cta.setCtaPlaza((String) da[11]);
				cta.setCtaSwift((String) da[12]);
				cta.setBcoBic((String) da[13]);
				
				
				logger.info("CtaAfectable " + cta.getCtaAfectable() + "  getCveTitular " + cta.getCveTitular());
				
				Object[] mov = coinQLBeanLocal.getMovimiento((String) cta.getCtaAfectable());
				String cod_movimiento = (String) mov[0];
				String codMoneda = (String) mov[1];

				cta.setCodMovimiento(cod_movimiento);
				cta.setCodMoneda(codMoneda);

				cuentaLista.add(cta);
			}
		} catch (Exception e) {
			logger.error(
					"Error al recuperar lista cuentas " + codCuenta + " " + e.getMessage(), e);
			throw new DataException("Error al recuperar lista cuentas " + codCuenta + " " + e.getMessage());
		}

		if (cuentaLista.size() > 0){
			return cuentaLista.get(0);
		}
		return null;		
	}
	
	/**
	 * Método que permite obtener los datos de la cuenta para el préstamo, tramo
	 * y titular especificados.
	 * 
	 * @throws DataException
	 */
	public List<Cuenta> getCuentas(String ptmCodigo, Integer traCodigo, String titular, String codCuenta) throws DataException {
		List<Cuenta> cuentaLista = new ArrayList<Cuenta>();

		StringBuilder jsql = new StringBuilder();
		jsql.append("SELECT c.cta_codigo, c.cta_factura, c.cta_numero, c.cta_nombre, c.cta_nit, c.bco_codigo, b.bco_nombre,c.cta_afectable, c.codpart, c.cve_tipo_cta, ");
		jsql.append("c.cta_direccion, c.cta_plaza, c.cta_swift,p.cve_titular, b.bco_bic "); 
		jsql.append("FROM cuenta c, banco b, prestamo_cuenta p ");
		jsql.append("WHERE c.bco_codigo = b.bco_codigo ");
		jsql.append("and c.cta_codigo = p.cta_codigo ");
		jsql.append("and p.cve_en_uso = 1 ");		
		jsql.append("and b.cve_vigente = 1 and c.cve_vigente = 1 ");

		jsql.append("and p.ptm_codigo = '" + ptmCodigo + "' ");			
		jsql.append("and p.tra_codigo = " + traCodigo + " ");			
		
		if (!StringUtils.isBlank(titular)) {
			jsql.append("and p.cve_titular = '" + titular + "' ");
		}

		if (!StringUtils.isBlank(codCuenta)) {
			jsql.append("and c.cta_codigo = '" + codCuenta + "' ");
		}
		
		logger.info("==>Consulta lista Cuentas: " + jsql);

		Query query = em.createNativeQuery(jsql.toString());
		List lista = query.getResultList();
		Iterator it = lista.iterator();
		String ctaCodigo = "";
		try {
			while (it.hasNext()) {
				Object[] da = (Object[]) it.next();
				// logger.info("XXX: en arrrrrrrrray2222 " +
				// ArrayUtils.toString(da));
				Cuenta cta = new Cuenta();
				cta.setCtaCodigo((String) da[0]);
				cta.setCtaFactura((String) da[1]);
				cta.setCtaNumero((String) da[2]);
				cta.setCtaNombre((String) da[3]);
				cta.setCtaNit((String) da[4]);
				cta.setBcoCodigo((String) da[5]);
				cta.setBcoNombre((String) da[6]);
				cta.setCtaAfectable((String) da[7]);
				String codPart = (String) da[8];
				cta.setCodPart(codPart);
				String cveTipoCta = (String) da[9];
				cta.setCveTipoCta(cveTipoCta);
				
				cta.setCtaDireccion((String) da[10]);
				cta.setCtaPlaza((String) da[11]);
				cta.setCtaSwift((String) da[12]);
				cta.setCveTitular((String) da[13]);
				cta.setBcoBic((String) da[14]);
				
				cta.setPtmCodigo(ptmCodigo);
				cta.setTraCodigo(traCodigo);
				
				logger.info("CtaAfectable " + cta.getCtaAfectable() + "  getCveTitular " + cta.getCveTitular());
				
				Object[] mov = coinQLBeanLocal.getMovimiento((String) cta.getCtaAfectable());
				String cod_movimiento = (String) mov[0];
				String codMoneda = (String) mov[1];

				cta.setCodMovimiento(cod_movimiento);
				cta.setCodMoneda(codMoneda);

				cuentaLista.add(cta);
			}
		} catch (Exception e) {
			logger.error(
					"Error al recuperar lista cuentas " + ptmCodigo + "[" + traCodigo + "] con tipo cuenta " + titular + ": " + e.getMessage(), e);
			throw new DataException("Error al recuperar lista cuentas " + ptmCodigo + "[" + traCodigo + "] con tipo cuenta [" + ctaCodigo + "]"
					+ titular + ": " + e.getMessage());
		}

		if (lista.size() == 0) {
			// whf ojooo evaluar cada que se extrae a nulo
			throw new DataException("Cuentas tipo " + (titular == null ? "TODOS" : titular) + " para Prestamo: " + ptmCodigo + "[" + traCodigo
					+ "] inexistente en base BCB, comunique al administrador");
		}
		return cuentaLista;		
	}
	
	public Cuenta getCuenta(String ptmCodigo, Integer traCodigo, String titular, String codCuenta) throws DataException {

		List<Cuenta> cuentaLista = getCuentas(ptmCodigo, traCodigo, titular, codCuenta);
		if (cuentaLista.size() == 0) {
			// whf ojooo evaluar cada que se extrae a nulo
			throw new DataException("Cuenta tipo " + titular + " para Prestamo: " + ptmCodigo + "[" + traCodigo
					+ "] inexistente en base BCB, comunique al administrador");
		}

		return cuentaLista.get(0);
	}

	public List<Cuenta> cuentasPrestamo(String ptmCodigo, Integer traCodigo, String titular) throws DataException {
		List<Cuenta> cuentaLista = new ArrayList<Cuenta>();

		StringBuilder jsql = new StringBuilder();
		jsql.append("select c.cta_codigo, c.cta_factura, c.cta_numero, c.cta_nombre, c.cta_nit, c.bco_codigo, ");
		jsql.append("(select b.bco_nombre from banco b where b.bco_codigo = c.bco_codigo) bco_nombre, ");
		jsql.append("c.cta_afectable, c.codpart, c.cve_tipo_cta , ");
		jsql.append("p.top_codigo,  ");
		jsql.append("(select tope.top_nombre from tipo_operacion tope where tope.top_codigo = p.top_codigo) toper_descrip, ");
		jsql.append("pro.pro_codigo, pro.pro_nombre, pro.cve_tipo_liq tip_liq_esqcont, pl.cve_tipo_liq tip_liq_prestinst, pe.esq_codigo, pe.codlip, pc.cve_titular, ");
		jsql.append("pl.pin_prestamo, pl.pin_tramo, p.ptm_codigo, p.tra_codigo, ");
		jsql.append("(select tope.gen_menswift from tipo_operacion tope where tope.top_codigo = p.top_codigo) gen_menswift ");
		jsql.append("from prestamo p, proceso pro, toper_proceso tpr, proceso_esquema pe,prestamo_cuenta pc, cuenta c , prestamo_instancia pl  ");
		jsql.append("where pc.cta_codigo = c.cta_codigo ");
		jsql.append("and pe.pro_codigo = tpr.pro_codigo ");
		jsql.append("and pe.cve_tipo_cta = c.cve_tipo_cta ");
		jsql.append("and pe.pro_codigo = tpr.pro_codigo ");
		jsql.append("and pe.cve_tipo_cta = c.cve_tipo_cta ");
		jsql.append("and c.cve_vigente = 1 ");
		jsql.append("and pc.cve_en_uso = 1 ");
		jsql.append("and pe.codlip is not null ");
		jsql.append("and pro.pro_codigo = tpr.pro_codigo ");
		jsql.append("and pl.ptm_codigo =p.ptm_codigo ");
		jsql.append("and pl.tra_codigo = p.tra_codigo ");
//		jsql.append("and pl.cve_instancia = 'DMS1' ");
		jsql.append("and pc.ptm_codigo = p.ptm_codigo ");
		jsql.append("and pc.tra_codigo = p.tra_codigo ");
		jsql.append("and tpr.top_codigo  = p.top_codigo ");
		jsql.append("and p.ptm_codigo = '" + ptmCodigo + "' ");
		jsql.append("and p.tra_codigo = " + traCodigo + " ");

		if (!StringUtils.isBlank(titular)) {
			jsql.append("and pc.cve_titular = '" + titular + "' ");
		}

		logger.info("==>Consulta getCuenta: " + jsql);

		Query query = em.createNativeQuery(jsql.toString());
		List lista = query.getResultList();
		Iterator it = lista.iterator();
		String ctaCodigo = "";
		try {
			while (it.hasNext()) {
				Object[] da = (Object[]) it.next();

				Cuenta cta = new Cuenta();
				ctaCodigo = (String) da[0];
				cta.setCtaCodigo(ctaCodigo);
				cta.setCtaFactura((String) da[1]);
				cta.setCtaNumero((String) da[2]);
				cta.setCtaNombre((String) da[3]);
				cta.setCtaNit((String) da[4]);
				cta.setBcoCodigo((String) da[5]);
				cta.setBcoNombre((String) da[6]);
				cta.setCtaAfectable((String) da[7]);
				String codPart = (String) da[8];
				cta.setCodPart(codPart);
				String cveTipoCta = (String) da[9];
				cta.setCveTipoCta(cveTipoCta);

				cta.setTopCodigo((String) da[10]);
				cta.setTopCodigoDescrip((String) da[11]);
				cta.setProCodigo((String) da[12]);
				cta.setProNombre((String) da[13]);
				cta.setCveTipoLiq((String) da[14]);
				cta.setCveTipoLiqInstan((String) da[15]);
				cta.setEsqCodigo((String) da[16]);
				cta.setCodlip((String) da[17]);
				cta.setCveTitular((String) da[18]);
				cta.setPinPrestamo((String) da[19]);

				Short codTramo = (Short) da[20];
				Integer trancheNo = Integer.valueOf(codTramo);
				cta.setPinTramo(trancheNo);

				cta.setPtmCodigo((String) da[21]);
				cta.setTraCodigo(traCodigo);
				cta.setGenMenswift((String) da[23]);
				
				logger.info("CtaAfectable " + cta.getCtaAfectable() + "  getCveTitular " + cta.getCveTitular());
				
				Object[] mov = coinQLBeanLocal.getMovimiento((String) cta.getCtaAfectable());
				String cod_movimiento = (String) mov[0];
				String codMoneda = (String) mov[1];

				cta.setCodMovimiento(cod_movimiento);
				cta.setCodMoneda(codMoneda);

				// se setea nuevamente ya que existe condiciones para TGN
				String codigoLIP = codigoLIPParaCta(cta);
				cta.setCodlip(codigoLIP);
				cuentaLista.add(cta);
			}
		} catch (Exception e) {
			logger.error(
					"Error al recuperar datos de cuenta " + ptmCodigo + "[" + traCodigo + "] con tipo cuenta " + titular + ": " + e.getMessage(), e);
			throw new DataException("Error al recuperar datos de cuenta " + ptmCodigo + "[" + traCodigo + "] con tipo cuenta [" + ctaCodigo + "]"
					+ titular + ": " + e.getMessage());
		}

		if (lista.size() == 0) {
			// whf ojooo evaluar cada que se extrae a nulo
			throw new DataException("Cuenta tipo " + (titular == null ? "TODOS" : titular) + " para Prestamo: " + ptmCodigo + "[" + traCodigo
					+ "] inexistente en base BCB, comunique al administrador");
		}
		return cuentaLista;
	}

	public String codigoLIPParaCta(Cuenta cta) {
		String codLip = cta.getCodlip();
		String codParticipante = cta.getCodPart();
		String codMoneda = cta.getCodMoneda();

		if (StringUtils.isBlank(codParticipante)) {
			logger.info("Codigo codParticipante nulo no se cambia " + codLip);
			return codLip;
		}

		if (codLip.equals("I01") && codParticipante.equals(Constants.COD_TGN)) {
			// TGN
			codLip = "I03";
		}

		if (codLip.equals("I03") && codParticipante.equals(Constants.COD_TGN) && codMoneda.trim().equals("69")) {
			codLip = "I04";
		}

		if (codLip.equals("I06") && codParticipante.equals(Constants.COD_TGN)) {
			codLip = "I08";
		}

		if (codLip.equals("I08") && codParticipante.equals(Constants.COD_TGN) && codMoneda.trim().equals("69")) {
			codLip = "I09";
		}
		logger.info("Codigo cambiado a " + codLip);

		return codLip;
	}

	public CuentaAcreedor getCuentaAcreedor(String acr_codigo, String mon_swift) throws DataException {

		CuentaAcreedor cta = null;

		StringBuilder jsql = new StringBuilder();
		jsql.append("SELECT c.cct_codigo,c.bco_codigo,c.acr_codigo,c.cct_numero,c.cct_bic,c.cct_nombre,c.cct_direccion,c.cct_plaza,c.mon_swift,c.ref_codigo, ");
		jsql.append("b.bco_bic, b.bco_interm, b.bco_cuenta, b.bco_nombre, b.bco_plaza, ");
		jsql.append("(select ref_definicion from	referencia r where r.ref_codigo = c.ref_codigo)  ");		
		jsql.append("FROM banco b, cuenta_acreedor c ");
		jsql.append("WHERE b.bco_codigo = c.bco_codigo ");
		jsql.append("and b.cve_vigente = 1 ");
		jsql.append("and c.cve_vigente = 1 ");
		jsql.append("and c.acr_codigo = '" + acr_codigo + "' ");
		jsql.append("and c.mon_swift = '" + mon_swift + "' ");
		
		logger.info("Consulta nativa getCuenta: " + jsql);

		Query query = em.createNativeQuery(jsql.toString());
		List lista = query.getResultList();
		Iterator it = lista.iterator();

		try {
			while (it.hasNext()) {
				Object[] da = (Object[]) it.next();
				cta = new CuentaAcreedor();
				
				cta.setCctCodigo((String) da[0]);
				cta.setBcoCodigo((String) da[1]);
				cta.setAcrCodigo((String) da[2]);
				cta.setCctNumero((String) da[3]);
				cta.setCctBic((String) da[4]);
				cta.setCctNombre((String) da[5]);
				cta.setCctDireccion((String) da[6]);				
				cta.setCctPlaza((String) da[7]);
				cta.setMonSwift((String) da[8]);
				cta.setRefCodigo((String) da[9]);
				cta.setBcoBic((String) da[10]);
				cta.setBcoInterm((String) da[11]);
				cta.setBcoCuenta((String) da[12]);
				cta.setBcoNombre((String) da[13]);
				cta.setBcoPlaza((String) da[14]);
				cta.setRefDefinicion((String) da[15]);				
			}
		} catch (Exception e) {
			logger.error(
					"Error al recuperar datos de cuenta Acreedor " + acr_codigo + " moneda " + mon_swift + " ", e);
			throw new DataException("Error al recuperar datos de cuenta Acreedor " + acr_codigo + " moneda " + mon_swift + " "
					+ e.getMessage());
		}

		if (lista.size() > 1) {
			throw new DataException("Cuenta Acreedor tipo " + acr_codigo + " moneda " + mon_swift + " devuelve mas de un registro ");
		}

		return cta;
	}
}
