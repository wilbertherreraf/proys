package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.DeudorLiquidacion;

import java.util.List;

import javax.ejb.Local;

@Local
public interface DeudorLiquidacionQLBeanLocal {

	public List<DeudorLiquidacion> listaCorreos(String codInstitucion, boolean enviarAIFA);

	DeudorLiquidacion getByCodInstitucion(Integer codInstitucion);

	DeudorLiquidacion getByCodSigade(String deuCodigo);

}