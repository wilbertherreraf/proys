package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.*;
import gob.bcb.jee.siodex.exception.DataException;
import gob.bcb.jee.siodex.mail.Email;
import gob.bcb.jee.siodex.mail.MsgLogic;
import gob.bcb.jee.siodex.mefp.LiquidacionCuentas;
import gob.bcb.jee.siodex.mefp.LiquidacionCuentasPK;
import gob.bcb.jee.siodex.mefp.LiquidacionCuentasQLBeanLocal;
import gob.bcb.jee.siodex.pojos.VcDatosAdic;
import gob.bcb.jee.siodex.service.MensajeSwiftBeanLocal;
import gob.bcb.jee.siodex.util.UtilsDate;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;

@Stateless
@LocalBean
public class VencimientoQLBean implements VencimientoQLBeanLocal {

	static final Logger logger = Logger.getLogger(VencimientoQLBean.class);

	@PersistenceContext(unitName = "siodex")
	EntityManager em;

	@Inject
	private DAQLBeanLocal dAQLBeanLocal;
	@Inject
	private DA3QLBeanLocal dA3QLBeanLocal;
	@Inject
	private LiquidacionDetQLBeanLocal liquidacionDetQLBeanLocal;
	@Inject
	private LiquidacionQLBeanLocal liquidacionQLBeanLocal;
	@Inject
	private CoinQLBeanLocal coinQLBeanLocal;
	@Inject
	private LiqEstadoQLBeanLocal liqEstadoQLBeanLocal;
	@Inject
	private ComisionBancariaQLBeanLocal comisionBancariaQLBeanLocal;
	@Inject
	private CuentaQLBeanLocal cuentaQLBeanLocal;
	@Inject
	private LogAuditoriaQLBeanLocal logAuditoriaQLBeanLocal;
	@Inject
	private DeudorLiquidacionQLBeanLocal deudorLiquidacionQLBeanLocal;
	@Inject
	private MonedaQLBeanLocal monedaQLBeanLocal;

	@Inject
	private LiquidacionPagoQLBeanLocal liquidacionPagoQLBeanLocal;
	@Inject
	private ConsultasSdxQLBeanLocal consultasSdxQLBeanLocal;
	@Inject
	private MensajeSwiftBeanLocal mensajeSwiftBeanLocal;
	@Inject
	private MensajeQLBeanLocal mensajeQLBeanLocal;
	@Inject
	private LiquidacionCuentasQLBeanLocal liquidacionCuentasQLBeanLocal;

	@Inject
	private UtilConversionBeanLocal utilConversionBeanLocal;

	/**
	 * Default constructor.
	 */
	public VencimientoQLBean() {
		// TODO Auto-generated constructor stub
	}

	public List<Vencimiento> listaVencimiento(String estado, String codEnt) throws DataException {
		return listaVencimiento(estado, null, codEnt);
	}

	public List<Vencimiento> listaVencimiento(String estado, String estadoNotif, String codEnt, Date fechaVenc, Date fechaVencHasta) throws DataException {

		List<Liquidacion> lista = liquidacionQLBeanLocal.liquidacionesByEstadoNotif(estado, estadoNotif, fechaVenc, fechaVencHasta);
		logger.info("Liquids. recuperados por fechas: " + lista.size() + " en estado " + estado + " estadoNotif:" + estadoNotif);

		List<Vencimiento> listaV = listaVencimiento(estado, estadoNotif, codEnt, lista);
		return listaV;
	}

	public List<Vencimiento> listaVencimiento(String estado, String estadoNotif, String codEnt) throws DataException {
		Date fecha = UtilsDate.restarDias(new Date(), -7);
		// fecha = UtilsDate.restarDias(new Date(), -90);

		List<Liquidacion> lista = liquidacionQLBeanLocal.liquidacionesByEstadoNotif(estado, estadoNotif, fecha, null);

		logger.info("Liquids. recuperados: " + lista.size() + " en estado " + estado + " estadoNotif:" + estadoNotif);

		List<Vencimiento> listaV = listaVencimiento(estado, estadoNotif, codEnt, lista);
		return listaV;

	}

	public List<Vencimiento> listaVencimientoSinFechas(String estado, String estadoNotif, String codEnt) throws DataException {
		List<Liquidacion> lista = liquidacionQLBeanLocal.liquidacionesByEstadoNotif(estado, estadoNotif, null, null);

		logger.info("Liquids. listaVencimientoSinFechas : " + lista.size() + " en estado " + estado + " estadoNotif:" + estadoNotif);

		List<Vencimiento> listaV = listaVencimiento(estado, estadoNotif, codEnt, lista);
		return listaV;

	}

	public List<Vencimiento> listaVencimiento(String estado, String estadoNotif, String codEnt, List<Liquidacion> lista) throws DataException {
		if (StringUtils.isBlank(codEnt)) {
			logger.error("Codigo entidad invalido");
			throw new RuntimeException("Codigo entidad invalido");
		}

		List<Vencimiento> listaV = new ArrayList<Vencimiento>();
		DeudorLiquidacion deudorLiquidacion = deudorLiquidacionQLBeanLocal.getByCodInstitucion(Integer.valueOf(codEnt));

		if (deudorLiquidacion == null) {
			logger.error("Entidad inexistente " + codEnt);
			// whf ojooooo modificar pero comunicar al usuario depuracion de
			// datos
			// throw new DataException("Entidad inexistente " + codEnt);
		} else {
			for (Liquidacion liq : lista) {
				logger.info("DMS1 " + liq.getPtmCodigo());
				List<VcDatosAdic> vcDatosAdicLista = dAQLBeanLocal.obtenerResumenDatGrales(liq.getPtmCodigo(), liq.getTraCodigo());

				if (vcDatosAdicLista.size() > 0) {

					// existe el prestamo
					VcDatosAdic vcDatosAdic = vcDatosAdicLista.get(0);

					String codigoDeudorLitSIGADE = vcDatosAdic.getSiglaProv();
					if (codEnt.equals("900")) {
						// el susuario que consulta es del bcb se realizara la
						// consulta del codpartliquidacion en el metodo
						Vencimiento newVenc = getVencimiento(liq, vcDatosAdic, null);
						listaV.add(newVenc);

					} else if (codigoDeudorLitSIGADE.equalsIgnoreCase(deudorLiquidacion.getDeuCodigo())) {
						// el usuario que cnsulta no es del bcb , todas las
						// liquidaciones son de la entidad
						Vencimiento newVenc = getVencimiento(liq, vcDatosAdic, null);
						listaV.add(newVenc);
					}

				} else {
					logger.info("DMS3 " + liq.getPtmCodigo());
					vcDatosAdicLista = dA3QLBeanLocal.obtenerResumenDatGrales(liq.getPtmCodigo(), liq.getTraCodigo());

					if (vcDatosAdicLista.size() > 0) {

						// existe el prestamo
						VcDatosAdic vcDatosAdic = vcDatosAdicLista.get(0);

						String codigoDeudorLitSIGADE = vcDatosAdic.getSiglaProv();
						if (codEnt.equals("900")) {
							// el susuario que consulta es del bcb se realizara
							// la
							// consulta del codpartliquidacion en el metodo
							Vencimiento newVenc = getVencimiento(liq, vcDatosAdic, null);
							listaV.add(newVenc);

						} else if (codigoDeudorLitSIGADE.equalsIgnoreCase(deudorLiquidacion.getDeuCodigo())) {
							// el usuario que cnsulta no es del bcb , todas las
							// liquidaciones son de la entidad
							Vencimiento newVenc = getVencimiento(liq, vcDatosAdic, null);
							listaV.add(newVenc);
						}
					}
				}
			}
		}
		logger.info("Regs recuperados: " + listaV.size());
		return listaV;
	}

	/**
	 * consulta que debe ser usada para obtener datos detalle segun codigo de
	 * liq, no para uso en listas
	 */
	public Vencimiento getVencimiento(String ptmCodigo, int traCodigo, String liqCodigo) throws DataException {

		Vencimiento vencimiento = new Vencimiento();

		Liquidacion liq = liquidacionQLBeanLocal.getLiquidacion(liqCodigo);

		if (liq == null) {
			throw new DataException("Liquidacion inexistente cod.: " + liqCodigo);
		}

		List<VcDatosAdic> vcDatosAdicLista = dAQLBeanLocal.obtenerResumenDatGrales(liq.getPtmCodigo(), liq.getTraCodigo());

		if (vcDatosAdicLista.size() == 0) {
			logger.info("DMS3 " + liq.getPtmCodigo());
			vcDatosAdicLista = dA3QLBeanLocal.obtenerResumenDatGrales(liq.getPtmCodigo(), liq.getTraCodigo());
		}
		if (vcDatosAdicLista.size() > 0) {
			VcDatosAdic vcDatosAdic = vcDatosAdicLista.get(0);

			// en reunion con flecona 20140128 se decide que la moneda SDR tiene
			// un tratamiento como la moneda USD
			// y se muestra el valor calculado en sigade coin tabla liquidacion

			// ****** recuperamos datos grales
			vencimiento = getVencimiento(liq, vcDatosAdic, null);
			// ***************

			List<LiquidacionDet> liquidacionDetLista = liquidacionDetQLBeanLocal.listaLiquidacion(liq.getLiqCodigo());
			vencimiento.setLiquidacionDetLista(liquidacionDetLista);

			vencimiento = recuperarCuentasPrestamoYDetalles(vencimiento, null);

			Cuenta cuentaS = vencimiento.getCuentaPrestamo("DEUD");
			if (cuentaS == null) {
				throw new DataException("No se pudo encontrar la Cuenta Deudora para " + vencimiento.getPtmCodigo() + " tramo:" + vencimiento.getTraCodigo());
			}

			if (cuentaS.getCodMoneda() != null && StringUtils.isBlank(vencimiento.getMonedaCont())) {
				// si no esta definido lo inicializamos
				if (cuentaS.getCodMoneda().trim().equals("69")) {
					vencimiento.setMonedaCont(cuentaS.getCodMoneda().trim());
				} else {
					vencimiento.setMonedaCont("34");
				}
			}
			// el participante se extrae de la cuenta del deudor
			DeudorLiquidacion deudorLiquidacion = deudorLiquidacionQLBeanLocal.getByCodSigade(vcDatosAdic.getSiglaProv());
			vencimiento.setCodPartLiquidacion("");
			if (deudorLiquidacion.getGenLiq() != null) {
				vencimiento.setCodPartLiquidacion(String.valueOf(deudorLiquidacion.getGenLiq()));
			}

			vencimiento = recuperarComisionesBancarias(vencimiento);

			vencimiento.setCodTipoOperacion(cuentaS.getTopCodigo());

			vencimiento = recuperarLiquidacionPago(vencimiento);
			// para ver si es moneda SDR
			vencimiento = recuperarVencimientoSDR(vencimiento);

			vencimiento = calcularTotales(vencimiento);
			nroMensajesSwift(vencimiento);

		}
		return vencimiento;
	}

	/**
	 * metodo que recupera el vencimiento desde la tabla liquidacion y datos del
	 * DMS1
	 *
	 * @param liq
	 * @param vcDatosAdic
	 * @param codPartLiquidacion
	 * @return
	 * @throws DataException
	 */
	private Vencimiento getVencimiento(Liquidacion liq, VcDatosAdic vcDatosAdic, String codPartLiquidacion) throws DataException {

		String observacion = null;

		// si la liq. fue observada se obtiene la observacion
		LiquidacionEstado liquidacionEstado = liqEstadoQLBeanLocal.liqObservado(liq.getLiqCodigo(), "B");
		if (liquidacionEstado != null) {
			observacion = liquidacionEstado.getObservacion();
		}

		Vencimiento vencimiento = new Vencimiento();

		vencimiento.setLiqCodigo(liq.getLiqCodigo());
		vencimiento.setPtmCodigo(liq.getPtmCodigo());
		vencimiento.setTraCodigo(liq.getTraCodigo());
		vencimiento.setCapitalUsd(liq.getCapitalUsd());
		vencimiento.setInteresUsd(liq.getInteresUsd());
		vencimiento.setComisionUsd(liq.getComisionUsd());
		// por defecto inicializamos a fecha registrada en liquidacion
		vencimiento.setFechaTc(liq.getFechaTc());
		vencimiento.setCveEstado(liq.getCveEstado());

		vencimiento.setFechaVenc(liq.getFechaVenc());
		vencimiento.setPrestamo(vcDatosAdic.getProyecto());
		vencimiento.setRefAcre(vcDatosAdic.getRefAcreedor());
		vencimiento.setAcreedor(vcDatosAdic.getAcreedor());
		vencimiento.setDeudor(vcDatosAdic.getSiglaProv());
		vencimiento.setUsuario(liq.getUsrCodigo());
		vencimiento.setDocPdf(liq.getDocPdf());

		vencimiento.setVcDatosAdic(vcDatosAdic);

		vencimiento.setCveEstNotif(liq.getCveEstnotif());
		vencimiento.setLote(liq.getLote());
		vencimiento.setObservacion(observacion);
		vencimiento.setCodPartLiquidacion(liq.getCodPart());
		vencimiento.setReferencia(liq.getReferencia());
		vencimiento.setCantMensSwift(liq.getSwitfs());

		vencimiento.setMonedaCont(liq.getCodMoneda());
		if (!StringUtils.isBlank(vencimiento.getMonedaCont())) {
			if (vencimiento.getMonedaCont().equals("69")) {
				vencimiento.setMonedaContDesc("BS");
			} else if (vencimiento.getMonedaCont().equals("34")) {
				vencimiento.setMonedaContDesc("USD");
			}
		}

		vencimiento.setMonedaCont(liq.getCodMoneda());
		// tipo cambio del usd
		vencimiento.setTipoCambioCont(liq.getTipoCambio());

		// se inicializa por defecto a lo definido en SIGADE
		vencimiento.setMoneda(vcDatosAdic.getMonedaOrigen());

		if (!StringUtils.isBlank(liq.getMonSigade())) {
			vencimiento.setMoneda(liq.getMonSigade());
		}

		// total contable
		vencimiento.setTotal((liq.getMonto() == null ? BigDecimal.ZERO : liq.getMonto()));

		BigDecimal totalUsd = liq.getCapitalUsd().add(liq.getInteresUsd().add(liq.getComisionUsd()));
		vencimiento.setTotalUsd(totalUsd);

		String estadoDesc = consultasSdxQLBeanLocal.descripcionClave("cve_estadoliq", vencimiento.getCveEstado());
		vencimiento.setCveEstadoDescrip(estadoDesc);

		return vencimiento;
	}

	public Vencimiento recuperarLiquidacionPago(Vencimiento vencimiento) {

		// contablecontablecontablecontablecontablecontablecontablecontablecontable
		LiquidacionPago liquidacionPago = liquidacionPagoQLBeanLocal.getLiquidacionPago(vencimiento.getLiqCodigo(), "CAP");
		if (liquidacionPago != null) {
			vencimiento.setCapital(liquidacionPago.getValor());
		}

		liquidacionPago = liquidacionPagoQLBeanLocal.getLiquidacionPago(vencimiento.getLiqCodigo(), "INT");
		if (liquidacionPago != null) {
			vencimiento.setInteres(liquidacionPago.getValor());
		}
		liquidacionPago = liquidacionPagoQLBeanLocal.getLiquidacionPago(vencimiento.getLiqCodigo(), "COM");
		if (liquidacionPago != null) {
			vencimiento.setComision(liquidacionPago.getValor());
		}

		// BSBSBSBSBSBSBSBSBSBSBSBSBSBSBSBSBSBS
		liquidacionPago = liquidacionPagoQLBeanLocal.getLiquidacionPago(vencimiento.getLiqCodigo(), "CAPBS");
		if (liquidacionPago != null) {
			vencimiento.setCapitalBs(liquidacionPago.getValor());
		}

		liquidacionPago = liquidacionPagoQLBeanLocal.getLiquidacionPago(vencimiento.getLiqCodigo(), "INTBS");
		if (liquidacionPago != null) {
			vencimiento.setInteresBs(liquidacionPago.getValor());
		}
		liquidacionPago = liquidacionPagoQLBeanLocal.getLiquidacionPago(vencimiento.getLiqCodigo(), "COMBS");
		if (liquidacionPago != null) {
			vencimiento.setComisionBs(liquidacionPago.getValor());
		}

		liquidacionPago = liquidacionPagoQLBeanLocal.getLiquidacionPago(vencimiento.getLiqCodigo(), "BSTOT");
		if (liquidacionPago != null) {
			vencimiento.setTotalBs(liquidacionPago.getValor());
		}

		liquidacionPago = liquidacionPagoQLBeanLocal.getLiquidacionPago(vencimiento.getLiqCodigo(), "SUSTOT");
		if (liquidacionPago != null) {
			vencimiento.setTotalUsd(liquidacionPago.getValor());
		}

		// MOMOMOMOMOMOMOMOMOMOMOMOMOMO
		liquidacionPago = liquidacionPagoQLBeanLocal.getLiquidacionPago(vencimiento.getLiqCodigo(), "CAPMO");
		if (liquidacionPago != null) {
			vencimiento.setCapitalMO(liquidacionPago.getValor());
		}

		liquidacionPago = liquidacionPagoQLBeanLocal.getLiquidacionPago(vencimiento.getLiqCodigo(), "INTMO");
		if (liquidacionPago != null) {
			vencimiento.setInteresMO(liquidacionPago.getValor());
		}

		liquidacionPago = liquidacionPagoQLBeanLocal.getLiquidacionPago(vencimiento.getLiqCodigo(), "COMMO");
		if (liquidacionPago != null) {
			vencimiento.setComisionMO(liquidacionPago.getValor());
		}

		liquidacionPago = liquidacionPagoQLBeanLocal.getLiquidacionPago(vencimiento.getLiqCodigo(), "MOTOT");
		if (liquidacionPago != null) {
			vencimiento.setTotalMO(liquidacionPago.getValor());
		}

		return vencimiento;
	}

	public Vencimiento calcularVencimiento(Vencimiento vencimiento, Date fechaOperacion, String ptmCodigo, int traCodigo, String codLiquidacion) throws DataException {

		logger.info("Entrando a calcularVencimiento : " + codLiquidacion);

		List<LiquidacionDet> liquidacionDetLista = liquidacionDetQLBeanLocal.listaLiquidacion(codLiquidacion);
		List<LiquidacionDet> liquidacionDetListaVen = new ArrayList<LiquidacionDet>();

		vencimiento.setFechaTc(fechaOperacion);

		int nroMensSwift = nroMensajesSwift(vencimiento);

		vencimiento.setCantMensSwift(nroMensSwift);
		vencimiento = calcularVencimientoSDR(vencimiento);

		if (vencimiento.getMonSDR()) {
			return vencimiento;
		}

		vencimiento.inicializa();

		for (LiquidacionDet liquidacionDet : liquidacionDetLista) {
			logger.info("calcularVencimiento liquidacionDet : " + liquidacionDet.toString());
			LiquidacionDet liqDet = new LiquidacionDet(new LiquidacionDetPK(liquidacionDet.getLiquidacionDetPK().getLiqCodigo(), liquidacionDet.getLiquidacionDetPK()
					.getLiqDetalle()), liquidacionDet.getPinPrestamo(), liquidacionDet.getPinTramo(), liquidacionDet.getMonSigade(), liquidacionDet.getTipoCambio(),
					liquidacionDet.getCapitalMo(), liquidacionDet.getInteresMo(), liquidacionDet.getComisionMo(), liquidacionDet.getGlosa());

			Moneda monedaC = monedaQLBeanLocal.getMonedaCoin(liquidacionDet.getMonSigade());

			Map<String, Object> montoConvertido = conversion(liquidacionDet.getCapitalMo(), monedaC.getMonCoin(), vencimiento.getMonedaCont(), vencimiento.getFechaTc(), "69",
					liquidacionDet.getTipoCambio());

			// insertamos el tipo de cambio de la fecha de operacion para la
			// moneda origen
			BigDecimal tipoCambioMO = (BigDecimal) montoConvertido.get("tipocambiomo");
			liqDet.setTipoCambio(tipoCambioMO);

			tipoCambioMO = (BigDecimal) montoConvertido.get("tipocambiomoxbs");
			liqDet.setTipoCambiomo(tipoCambioMO);
			liquidacionDetListaVen.add(liqDet);

		}

		vencimiento.setLiquidacionDetLista(liquidacionDetListaVen);

		logger.info("fin actualizacion tipos cambio liqdetalle " + vencimiento.getLiqCodigo());

		List<Liquidacion> monedaMonto = consultasSdxQLBeanLocal.montosPorMonedas(vencimiento.getLiqCodigo());

		// flag ue indica si hay varias monedas
		boolean variasMonedas = (monedaMonto.size() > 1);

		vencimiento.setVariasMonedas(variasMonedas);

		for (Liquidacion liquidacion : monedaMonto) {
			BigDecimal tcDefecto = liquidacion.getTipoCambio();

			vencimiento.setMoneda(liquidacion.getMonSigade());

			Moneda monedaC = monedaQLBeanLocal.getMonedaCoin(liquidacion.getMonSigade());
			String monedaCoin = monedaC.getMonCoin();

			Map<String, Object> montoConvertido = conversion(liquidacion.getCapitalUsd(), monedaCoin, vencimiento.getMonedaCont(), vencimiento.getFechaTc(), "69", tcDefecto);

			BigDecimal capitalBS = (BigDecimal) montoConvertido.get("montobs");
			vencimiento.setCapitalBs(vencimiento.getCapitalBs().add(capitalBS));

			BigDecimal capitalSUS = (BigDecimal) montoConvertido.get("montosus");
			vencimiento.setCapitalUsd(vencimiento.getCapitalUsd().add(capitalSUS));

			montoConvertido = conversion(liquidacion.getInteresUsd(), monedaCoin, vencimiento.getMonedaCont(), vencimiento.getFechaTc(), "69", tcDefecto);

			BigDecimal interesBS = (BigDecimal) montoConvertido.get("montobs");
			vencimiento.setInteresBs(vencimiento.getInteresBs().add(interesBS));

			BigDecimal interesSUS = (BigDecimal) montoConvertido.get("montosus");
			vencimiento.setInteresUsd(vencimiento.getInteresUsd().add(interesSUS));

			montoConvertido = conversion(liquidacion.getComisionUsd(), monedaCoin, vencimiento.getMonedaCont(), vencimiento.getFechaTc(), "69", tcDefecto);

			BigDecimal comisionBS = (BigDecimal) montoConvertido.get("montobs");
			vencimiento.setComisionBs(vencimiento.getComisionBs().add(comisionBS));

			BigDecimal comisionSUS = (BigDecimal) montoConvertido.get("montosus");
			vencimiento.setComisionUsd(vencimiento.getComisionUsd().add(comisionSUS));

			BigDecimal totalMO = liquidacion.getMonto();

			montoConvertido = conversion(totalMO, monedaCoin, vencimiento.getMonedaCont(), vencimiento.getFechaTc(), "69", tcDefecto);

			BigDecimal totalBS = (BigDecimal) montoConvertido.get("montobs");
			BigDecimal totalSUS = (BigDecimal) montoConvertido.get("montosus");
			BigDecimal total = (BigDecimal) montoConvertido.get("monto");

			vencimiento.setTotalBs(vencimiento.getTotalBs().add(totalBS));
			vencimiento.setTotalUsd(vencimiento.getTotalUsd().add(totalSUS));
			vencimiento.setTotal(vencimiento.getTotal().add(total));

			vencimiento.setCapitalMO(vencimiento.getCapitalMO().add(liquidacion.getCapitalUsd()));
			vencimiento.setInteresMO(vencimiento.getInteresMO().add(liquidacion.getInteresUsd()));
			vencimiento.setComisionMO(vencimiento.getComisionMO().add(liquidacion.getComisionUsd()));

			vencimiento.setTotalMO(vencimiento.getTotalMO().add(totalMO));
		}

		if (variasMonedas) {
			vencimiento.setMoneda("USD");
		}

		logger.info("calcularVencimiento variasMonedas : " + variasMonedas + " " + vencimiento.getMoneda());

		if (vencimiento.getMonedaCont().trim().equals("69")) {
			// se recalcula si es UFV los tipos de cambio
			if (vencimiento.getMoneda().equals("XP2")) {

				BigDecimal tipoCambioDEUD = coinQLBeanLocal.getTC(vencimiento.getFechaTc(), "34");
				vencimiento.setTipoCambioCont(tipoCambioDEUD);
			} else {
				BigDecimal tipoCambioDEUD = coinQLBeanLocal.getTC(vencimiento.getFechaTc(), "35");
				vencimiento.setTipoCambioCont(tipoCambioDEUD);

			}

			if (!variasMonedas && (vencimiento.getMoneda().equals("BBS"))) {
				// si la moneda origen es bolivianos, ademas tiene una sola
				// moneda el tipo de cambio es el de compra
				BigDecimal tipoCambioDEUD = coinQLBeanLocal.getTC(vencimiento.getFechaTc(), "34");
				vencimiento.setTipoCambioCont(tipoCambioDEUD);
			}

		} else {

			BigDecimal tipoCambioDEUD = coinQLBeanLocal.getTC(vencimiento.getFechaTc(), "34");
			vencimiento.setTipoCambioCont(tipoCambioDEUD);

		}

		vencimiento = calcularTotales(vencimiento);

		vencimiento = calcularComisionesBancarias(vencimiento, vencimiento.getFechaTc());

		logger.info("==> Vencimiento recalculado==>: " + vencimiento.toString());

		return vencimiento;
	}

	private Vencimiento calcularTotales(Vencimiento vencimiento) throws DataException {
		// metodo para ejecutar despues que los montos se hayan calculado o
		// recuperado
		// actualizamos los valores contables
		if (!StringUtils.isBlank(vencimiento.getMonedaCont())) {
			if (vencimiento.getMonedaCont().trim().equals("69")) {
				vencimiento.setCapital(vencimiento.getCapitalBs());
				vencimiento.setInteres(vencimiento.getInteresBs());
				vencimiento.setComision(vencimiento.getComisionBs());

				vencimiento.setTotalBs(vencimiento.getTotal());
			} else {
				vencimiento.setCapital(vencimiento.getCapitalUsd());
				vencimiento.setInteres(vencimiento.getInteresUsd());
				vencimiento.setComision(vencimiento.getComisionUsd());

				vencimiento.setTotalUsd(vencimiento.getTotal());
			}
		}

		if (!StringUtils.isBlank(vencimiento.getMoneda()) && vencimiento.getMoneda().equals("USD")) {
			// (variasMonedas) true
			// diferentes monedas se setea la moneda origina a dolares o si es
			// moneda SDR
			vencimiento.setCapitalMO(vencimiento.getCapitalUsd());
			vencimiento.setInteresMO(vencimiento.getInteresUsd());
			vencimiento.setComisionMO(vencimiento.getComisionUsd());

			vencimiento.setTotalMO(vencimiento.getTotalUsd());
		}

		return vencimiento;
	}

	public Vencimiento recuperarVencimientoSDR(Vencimiento vencimiento) throws DataException {
		boolean existSDR = false;

		vencimiento.setMonSDR(existSDR);
		// / sdrsdr sdr sdr sdr sdr sdr sdr sdr sdr sdr sdr sdr sdr
		List<LiquidacionDet> liquidacionDetLista = vencimiento.getLiquidacionDetLista();

		for (LiquidacionDet liquidacionDet : liquidacionDetLista) {
			if (liquidacionDet.getMonSigade().equals("SDR")) {
				existSDR = true;
			}
		}

		if (!existSDR) {
			return vencimiento;
		}

		List<LiquidacionDet> liquidacionDetListaVen = new ArrayList<LiquidacionDet>();

		// se actualiza para objetivos de vista, en la vista se debe presentar
		// todo en usd
		List<Liquidacion> monedaMonto = consultasSdxQLBeanLocal.montosPorMonedas(vencimiento.getLiqCodigo());

		Liquidacion liquidacion = monedaMonto.get(0);

		LiquidacionDet liquidacionDet = liquidacionDetLista.get(0);

		liquidacionDet.setCapitalMo(liquidacion.getCapitalUsd());
		liquidacionDet.setInteresMo(liquidacion.getInteresUsd());
		liquidacionDet.setComisionMo(liquidacion.getComisionUsd());
		liquidacionDet.setMonSigade(liquidacion.getMonSigade());
		liquidacionDet.setTipoCambio(liquidacion.getTipoCambio());

		liquidacionDet.setTipoCambiomo(vencimiento.getTipoCambioCont());

		liquidacionDetListaVen.add(liquidacionDet);

		vencimiento.setLiquidacionDetLista(liquidacionDetListaVen);
		vencimiento.setMoneda("USD");
		vencimiento.setMonSDR(existSDR);

		return vencimiento;
	}

	public Vencimiento calcularVencimientoSDR(Vencimiento vencimiento) throws DataException {

		if (vencimiento.getMonSDR()) {
			vencimiento.setCapital(BigDecimal.ZERO);
			vencimiento.setInteres(BigDecimal.ZERO);
			vencimiento.setComision(BigDecimal.ZERO);

			vencimiento.setCapitalBs(BigDecimal.ZERO);
			vencimiento.setInteresBs(BigDecimal.ZERO);
			vencimiento.setComisionBs(BigDecimal.ZERO);

			vencimiento.setCapitalMO(BigDecimal.ZERO);
			vencimiento.setInteresMO(BigDecimal.ZERO);
			vencimiento.setComisionMO(BigDecimal.ZERO);

			vencimiento.setTotal(BigDecimal.ZERO);
			vencimiento.setTotalBs(BigDecimal.ZERO);
			vencimiento.setTotalUsd(BigDecimal.ZERO);
			vencimiento.setTotalMO(BigDecimal.ZERO);

			// no se actualiza valores usd

			Moneda monedaC = monedaQLBeanLocal.getMonedaCoin(vencimiento.getMoneda());

			Map<String, Object> montoConvertido = conversion(vencimiento.getCapitalUsd(), monedaC.getMonCoin(), vencimiento.getMonedaCont(), vencimiento.getFechaTc(), "69",
					BigDecimal.ONE);

			BigDecimal capitalBS = (BigDecimal) montoConvertido.get("montobs");
			vencimiento.setCapitalBs(capitalBS);

			montoConvertido = conversion(vencimiento.getInteresUsd(), monedaC.getMonCoin(), vencimiento.getMonedaCont(), vencimiento.getFechaTc(), "69", BigDecimal.ONE);

			BigDecimal interesBS = (BigDecimal) montoConvertido.get("montobs");
			vencimiento.setInteresBs(interesBS);

			montoConvertido = conversion(vencimiento.getComisionUsd(), monedaC.getMonCoin(), vencimiento.getMonedaCont(), vencimiento.getFechaTc(), "69", BigDecimal.ONE);

			BigDecimal comisionBS = (BigDecimal) montoConvertido.get("montobs");
			vencimiento.setComisionBs(comisionBS);

			montoConvertido = conversion(vencimiento.getTotalUsd(), monedaC.getMonCoin(), vencimiento.getMonedaCont(), vencimiento.getFechaTc(), "69", BigDecimal.ONE);

			BigDecimal totalBS = (BigDecimal) montoConvertido.get("montobs");
			BigDecimal total = (BigDecimal) montoConvertido.get("monto");

			vencimiento.setTotalBs(totalBS);
			vencimiento.setTotal(total);
			vencimiento.setVariasMonedas(false);

			if (vencimiento.getMonedaCont().trim().equals("69")) {
				// se recalcula si es UFV los tipos de cambio
				BigDecimal tipoCambioDEUD = coinQLBeanLocal.getTC(vencimiento.getFechaTc(), "35");
				vencimiento.setTipoCambioCont(tipoCambioDEUD);

			} else {

				BigDecimal tipoCambioDEUD = coinQLBeanLocal.getTC(vencimiento.getFechaTc(), "34");
				vencimiento.setTipoCambioCont(tipoCambioDEUD);

			}

			vencimiento = calcularTotales(vencimiento);

			vencimiento = calcularComisionesBancarias(vencimiento, vencimiento.getFechaTc());

			logger.info("==> Vencimiento recalculado==>: " + vencimiento.toString());
			// //////////////////////////////////////////////////////////////////////
		}

		return vencimiento;
	}

	public Vencimiento calcularComisionesBancarias(Vencimiento vencimiento, Date fecha) throws DataException {
		logger.info("Entrando a calcularComisionesBancarias : " + vencimiento.getLiqCodigo() + " fecha: " + fecha);

		// se calcula las comisiones se supone que en este estado no exist
		// comisiones es para uso de la vista

		// ComisionBancaria comisionBancaria =
		// comisionBancariaQLBeanLocal.calcularComision(fecha, vencimiento,
		// "COPA");
		BigDecimal comiPagoBS = calcularComisionCOPA(vencimiento, fecha);
		ComisionBancaria comisionBancaria = new ComisionBancaria(new ComisionBancariaPK(vencimiento.getLiqCodigo(), "COPA"), 0, comiPagoBS);

		vencimiento.setComisionBancaria(comisionBancaria);
		// //////////////////////// comision bancaria para mensajes switf
		String swiftistr = consultasSdxQLBeanLocal.getParametro("@gcom");
		BigDecimal swift = new BigDecimal(swiftistr.replace(",", "."));

		// rmq si en la tabla tipo_operacion el campo com_menswift (cobrar
		// comision mensaje swift)
		boolean cobrarComision = isCobrarComMensajeSwit(vencimiento.getCodTipoOperacion());

		if (vencimiento.getPtmCodigo().equals("950002") && vencimiento.getTraCodigo() == 2) {
			cobrarComision = false;
		}

		if (vencimiento.getCantMensSwift() == 0 && cobrarComision)
			swift = swift.multiply(new BigDecimal(1));
		else if (vencimiento.getCantMensSwift() > 0 && cobrarComision)
			swift = swift.multiply(new BigDecimal(vencimiento.getCantMensSwift()));

		if (!cobrarComision) {
			// si no se debe cobrar comisiones por swift
			if (vencimiento.getPtmCodigo().equals("950002") && vencimiento.getTraCodigo() == 2) {
				vencimiento.setCantMensSwift(3);
			} else {
				vencimiento.setCantMensSwift(0);
			}
			swift = new BigDecimal(0);
		}

		comisionBancaria = new ComisionBancaria(new ComisionBancariaPK(vencimiento.getLiqCodigo(), "SWFT"), 0, swift);
		vencimiento.setComisionBancaria(comisionBancaria);

		// //////////////////////////
		String utilesstr = consultasSdxQLBeanLocal.getParametro("@util");
		BigDecimal utiles = new BigDecimal(utilesstr.replace(",", "."));
		comisionBancaria = new ComisionBancaria(new ComisionBancariaPK(vencimiento.getLiqCodigo(), "UTIL"), 0, utiles);
		vencimiento.setComisionBancaria(comisionBancaria);

		logger.info("ComisionesBancarias : " + vencimiento.getComisionBancaria("COPA") + " \n " + vencimiento.getComisionBancaria("SWIFT") + " \n "
				+ vencimiento.getComisionBancaria("UTIL"));
		return vencimiento;
	}

	public Vencimiento guardarComisionesBancarias(Vencimiento vencimiento) throws DataException {
		logger.info("Entrando a guardarComisionesBancarias : " + vencimiento.getLiqCodigo());

		ComisionBancaria comisionBancaria = vencimiento.getComisionBancaria("COPA");
		vencimiento = guardarComisionBancaria(vencimiento, "COPA", comisionBancaria.getMontoMN());

		comisionBancaria = vencimiento.getComisionBancaria("SWFT");
		vencimiento = guardarComisionBancaria(vencimiento, "SWFT", comisionBancaria.getMontoMN());

		comisionBancaria = vencimiento.getComisionBancaria("UTIL");
		vencimiento = guardarComisionBancaria(vencimiento, "UTIL", comisionBancaria.getMontoMN());

		return vencimiento;
	}

	public Vencimiento guardarComisionBancaria(Vencimiento vencimiento, String tipoComi, BigDecimal monto) throws DataException {
		LogAuditoria logAuditoria = logAuditoriaQLBeanLocal.crearLog(vencimiento.getLogAuditoria().getCodUsuario(), "", vencimiento.getLogAuditoria().getEstacion(),
				vencimiento.getLiqCodigo());

		ComisionBancaria comisionBancaria = comisionBancariaQLBeanLocal.crearOactualizar(vencimiento.getLiqCodigo(), tipoComi, monto, logAuditoria);
		vencimiento.setComisionBancaria(comisionBancaria);

		logger.info("Comision Bancaria salvada para: " + vencimiento.getLiqCodigo() + " " + comisionBancaria.toString());

		return vencimiento;
	}

	public Vencimiento recuperarComisionesBancarias(Vencimiento vencimiento) throws DataException {
		// recuperamos las comisiones guardadas
		List<ComisionBancaria> comisionBancariaLista = comisionBancariaQLBeanLocal.getComisiones(vencimiento.getLiqCodigo());
		for (ComisionBancaria comisionBancaria : comisionBancariaLista) {
			vencimiento.setComisionBancaria(comisionBancaria);
		}

		return vencimiento;
	}

	public Vencimiento recuperarCuentasPrestamoYDetalles(Vencimiento vencimiento, String cveTitular) throws DataException {
		logger.info("Entrando a recuperarCuentasPrestamoYDetalles : " + vencimiento.getLiqCodigo());

		List<Cuenta> cuentaLista = cuentaQLBeanLocal.cuentasPrestamo(vencimiento.getPtmCodigo(), vencimiento.getTraCodigo(), cveTitular);

		for (Cuenta cuenta : cuentaLista) {
			vencimiento.setCuentaPrestamo(cuenta.getCveTitular(), cuenta);
		}

		return vencimiento;
	}

	public Vencimiento guardarCuentasLiq(Vencimiento vencimiento) throws DataException {
		logger.info("En guardarCuentasLiq: " + vencimiento.getLiqCodigo());

		LiquidacionCuentas liqC = null;

		Cuenta cuenta = vencimiento.getCuentaPrestamo("DEUD");
		if (cuenta != null) {
			liqC = new LiquidacionCuentas(new LiquidacionCuentasPK(vencimiento.getLiqCodigo(), "DEUD"), 1, cuenta.getCtaCodigo());
			liqC.setUsuario(vencimiento.getUsuario());
			// liqC.setValorAdic(cuenta.getCtaNumero());
			liquidacionCuentasQLBeanLocal.actualizar(liqC);
		}

		cuenta = vencimiento.getCuentaPrestamo("DEUC");
		if (cuenta != null) {
			liqC = new LiquidacionCuentas(new LiquidacionCuentasPK(vencimiento.getLiqCodigo(), "DEUC"), 1, cuenta.getCtaCodigo());
			liqC.setUsuario(vencimiento.getUsuario());
			// liqC.setValorAdic(cuenta.getCtaNumero());
			liquidacionCuentasQLBeanLocal.actualizar(liqC);
		}

		if (vencimiento.getDeudor().equals("FNDR")) {
			cuenta = vencimiento.getCuentaPrestamo("DEUI");
			if (cuenta != null) {
				liqC = new LiquidacionCuentas(new LiquidacionCuentasPK(vencimiento.getLiqCodigo(), "DEUI"), 1, cuenta.getCtaCodigo());
				liqC.setUsuario(vencimiento.getUsuario());
				liquidacionCuentasQLBeanLocal.actualizar(liqC);
			}
		}
		return vencimiento;
	}

	/**
	 * actualiza liquidacion y sus detalles del credito setun el tipo de
	 * actualizacion tipoAct: T: todo; L:solo liquidacion; E: solo el estado de
	 * la liquidacion
	 */
	public Vencimiento actualizarLiquidacion(Vencimiento vencimiento, String observacion, String nuevoEstado, String flagTipoActualiza) throws DataException {

		logger.info("==>Actualizando liquidacion nuevo estado [" + nuevoEstado + ", flagTipoActualiza:" + flagTipoActualiza + "]: " + vencimiento.toString());

		Liquidacion liquidacionOld = liquidacionQLBeanLocal.getLiquidacion(vencimiento.getLiqCodigo());

		String estadoAnt = liquidacionOld.getCveEstado();
		if (StringUtils.isBlank(nuevoEstado)) {
			nuevoEstado = "";
		}

		if ((nuevoEstado.equals("V") || nuevoEstado.equals("A")) && flagTipoActualiza != null && !flagTipoActualiza.equals("WS")) {
			// si se pasa a estado verificado o autorizado
			vencimiento = guardarCuentasLiq(vencimiento);
		}

		if (nuevoEstado.equals("Z") || nuevoEstado.equals("B")) {
			// se rechaza la liquidacion no se hace nada
			logger.info("liquidacion rechazada sin cambios: " + vencimiento.toString());
		} else {
			if (!vencimiento.getMonSDR()) {
				// si es moneda SDR no se actualiza datos de los montos de la
				// liq ya que estos nunca deben cambiar
				liquidacionOld.setCapitalUsd(vencimiento.getCapitalUsd());
				liquidacionOld.setInteresUsd(vencimiento.getInteresUsd());
				liquidacionOld.setComisionUsd(vencimiento.getComisionUsd());
				liquidacionOld.setFechaTc(vencimiento.getFechaTc());
			}

			liquidacionOld.setMonto(vencimiento.getTotal());
			liquidacionOld.setCodMoneda(vencimiento.getMonedaCont());
			liquidacionOld.setTipoCambio(vencimiento.getTipoCambioCont());
			liquidacionOld.setMonSigade(vencimiento.getMoneda());

			liquidacionOld.setTipoOper(vencimiento.getCodTipoOperacion());
			liquidacionOld.setCodPart(vencimiento.getCodPartLiquidacion());

			liquidacionOld.setReferencia(vencimiento.getReferencia());
			liquidacionOld.setSwitfs(vencimiento.getCantMensSwift());

			liquidacionOld.setLote(vencimiento.getLote());

			vencimiento = guardarComisionesBancarias(vencimiento);

			// actualizamos el tipo de cambio de liqquidacion_det
			if (!vencimiento.getMonSDR()) {
				actualizarLiquidacionDetalle(vencimiento, "", flagTipoActualiza);
			}

			// actualizamos datos del detalle del pago
			actualizarLiquidacionPago(vencimiento, "", flagTipoActualiza);

		}

		liquidacionOld.setCveEstnotif(vencimiento.getCveEstNotif());
		liquidacionOld.setUsrCodigo(vencimiento.getUsuario());
		liquidacionOld.setEstacion(vencimiento.getLogAuditoria().getEstacion());

		// lo ultimo que hacemos es cambiar de estado
		liquidacionOld = liquidacionQLBeanLocal.cambioEstado(liquidacionOld, observacion, nuevoEstado);

		vencimiento.setCveEstado(liquidacionOld.getCveEstado());

		if (!StringUtils.isBlank(observacion)) {
			vencimiento.setObservacion(observacion);
		}

		return vencimiento;
	}

	public void actualizarLiquidacionDetalle(Vencimiento vencimiento, String cveCodigopago, String tipoAct) throws DataException {

		List<LiquidacionDet> liquidacionDetLista = vencimiento.getLiquidacionDetLista();
		for (LiquidacionDet liquidacionDet : liquidacionDetLista) {
			liquidacionDetQLBeanLocal.actualizar(liquidacionDet);
		}

	}

	public void actualizarLiquidacionPago(Vencimiento vencimiento, String cveCodigopago, String tipoAct) throws DataException {
		logger.info("Actualizando datos detalle pago " + vencimiento.toString());
		LiquidacionPago liquidacionPago = null;
		Liquidacion liquidacion = liquidacionQLBeanLocal.getLiquidacion(vencimiento.getLiqCodigo());

		liquidacionPago = liquidacionPagoQLBeanLocal.actualizar(vencimiento.getLiqCodigo(), "CAP", vencimiento.getCapital(), vencimiento.getMonedaCont(), "1", null,
				vencimiento.getFechaTc(), vencimiento.getUsuario(), vencimiento.getLogAuditoria().getEstacion());

		liquidacionPago = liquidacionPagoQLBeanLocal.actualizar(vencimiento.getLiqCodigo(), "INT", vencimiento.getInteres(), vencimiento.getMonedaCont(), "1", null,
				vencimiento.getFechaTc(), vencimiento.getUsuario(), vencimiento.getLogAuditoria().getEstacion());

		liquidacionPago = liquidacionPagoQLBeanLocal.actualizar(vencimiento.getLiqCodigo(), "COM", vencimiento.getComision(), vencimiento.getMonedaCont(), "1", null,
				vencimiento.getFechaTc(), vencimiento.getUsuario(), vencimiento.getLogAuditoria().getEstacion());

		String monedaSUS = "34";
		if (vencimiento.getMonedaCont().trim().equals("69")) {
			monedaSUS = "35";
			if (vencimiento.getMoneda().equals("XP2")) {
				monedaSUS = "34";
			}
		}

		liquidacionPago = liquidacionPagoQLBeanLocal.actualizar(vencimiento.getLiqCodigo(), "CAPSUS", vencimiento.getCapitalUsd(), monedaSUS, "1", null, vencimiento.getFechaTc(),
				vencimiento.getUsuario(), vencimiento.getLogAuditoria().getEstacion());

		liquidacionPago = liquidacionPagoQLBeanLocal.actualizar(vencimiento.getLiqCodigo(), "INTSUS", vencimiento.getInteresUsd(), monedaSUS, "1", null, vencimiento.getFechaTc(),
				vencimiento.getUsuario(), vencimiento.getLogAuditoria().getEstacion());

		liquidacionPago = liquidacionPagoQLBeanLocal.actualizar(vencimiento.getLiqCodigo(), "COMSUS", vencimiento.getComisionUsd(), monedaSUS, "1", null, vencimiento.getFechaTc(),
				vencimiento.getUsuario(), vencimiento.getLogAuditoria().getEstacion());

		liquidacionPago = liquidacionPagoQLBeanLocal.actualizar(vencimiento.getLiqCodigo(), "SUSTOT", vencimiento.getTotalUsd(), monedaSUS, "1", null, vencimiento.getFechaTc(),
				vencimiento.getUsuario(), vencimiento.getLogAuditoria().getEstacion());

		//***L.O.C. 10/03/2017 Req. Ajustar montos para la generación correcta del Reporte de Confirmación de Pago
		BigDecimal sumaSUS = vencimiento.getCapitalUsd().add(vencimiento.getInteresUsd()).add(vencimiento.getComisionUsd());
		if(vencimiento.getMonedaCont().equals("69")){
			//BigDecimal nuevoValorSUSTOT = vencimiento.getTotalBs().divide(vencimiento.getTipoCambioCont()).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
			//Map<String, Object> montoConvertAsus = conversion(vencimiento.getTotalBs(), "69", "34", vencimiento.getFechaTc(), null, null);
			Map<String, Object> montoConvertAsus = UtilConversion.conversion(vencimiento.getTotalBs(), "69", "34", vencimiento.getFechaTc(),BigDecimal.ONE, "V", coinQLBeanLocal);
			BigDecimal montoSUSTOT = (BigDecimal) montoConvertAsus.get("montosus");
			liquidacionPago = liquidacionPagoQLBeanLocal.actualizar(vencimiento.getLiqCodigo(), "SUSTOT", montoSUSTOT, monedaSUS, "1", null, vencimiento.getFechaTc(),
					vencimiento.getUsuario(), vencimiento.getLogAuditoria().getEstacion());

			liquidacion.setMonto(vencimiento.getTotalBs());
			liquidacionQLBeanLocal.actualizaLiquidacion(liquidacion);

			ajustarMontos(sumaSUS, montoSUSTOT, vencimiento, "34", monedaSUS, "NO");
		}else {
			ajustarMontos(sumaSUS, BigDecimal.ZERO, vencimiento, "34", monedaSUS, "SI");
		}
		//***
		monedaSUS = "69";

		// //////////////////BSBSBSBSBS
		liquidacionPago = liquidacionPagoQLBeanLocal.actualizar(vencimiento.getLiqCodigo(), "CAPBS", vencimiento.getCapitalBs(), monedaSUS, "1", null, vencimiento.getFechaTc(),
				vencimiento.getUsuario(), vencimiento.getLogAuditoria().getEstacion());

		liquidacionPago = liquidacionPagoQLBeanLocal.actualizar(vencimiento.getLiqCodigo(), "INTBS", vencimiento.getInteresBs(), monedaSUS, "1", null, vencimiento.getFechaTc(),
				vencimiento.getUsuario(), vencimiento.getLogAuditoria().getEstacion());

		liquidacionPago = liquidacionPagoQLBeanLocal.actualizar(vencimiento.getLiqCodigo(), "COMBS", vencimiento.getComisionBs(), monedaSUS, "1", null, vencimiento.getFechaTc(),
				vencimiento.getUsuario(), vencimiento.getLogAuditoria().getEstacion());

		liquidacionPago = liquidacionPagoQLBeanLocal.actualizar(vencimiento.getLiqCodigo(), "BSTOT", vencimiento.getTotalBs(), monedaSUS, "1", null, vencimiento.getFechaTc(),
				vencimiento.getUsuario(), vencimiento.getLogAuditoria().getEstacion());

		//***L.O.C. 10/03/2017 Req. Ajustar montos para la generación correcta del Reporte de Confirmación de Pago
		//liquidacionPago = liquidacionPagoQLBeanLocal.actualizar(vencimiento.getLiqCodigo(), "BSTOT", vencimiento.getTotalBs(), monedaSUS, "1", null, vencimiento.getFechaTc(),
		BigDecimal sumaBS = vencimiento.getCapitalBs().add(vencimiento.getInteresBs()).add(vencimiento.getComisionBs());
		if(vencimiento.getMonedaCont().equals("34")) {
			Map<String, Object> montoConvert = conversion(vencimiento.getTotalUsd(), "34", "34", vencimiento.getFechaTc(), null, null);
			BigDecimal montoBSTOT = (BigDecimal) montoConvert.get("montobs");
			liquidacionPago = liquidacionPagoQLBeanLocal.actualizar(vencimiento.getLiqCodigo(), "BSTOT", montoBSTOT, monedaSUS, "1", null, vencimiento.getFechaTc(),
					vencimiento.getUsuario(), vencimiento.getLogAuditoria().getEstacion());

			liquidacion.setMonto(vencimiento.getTotalUsd());
			liquidacionQLBeanLocal.actualizaLiquidacion(liquidacion);

			ajustarMontos(sumaBS, montoBSTOT, vencimiento, "69", monedaSUS, "NO");
		} else{
			ajustarMontos(sumaBS, BigDecimal.ZERO, vencimiento, "69", monedaSUS, "SI");
		}
		//***

		// /////// moneda origen totales en moneda sigade
		monedaSUS = vencimiento.getMoneda();

		liquidacionPago = liquidacionPagoQLBeanLocal.actualizar(vencimiento.getLiqCodigo(), "CAPMO", vencimiento.getCapitalMO(), monedaSUS, "1", null, vencimiento.getFechaTc(),
				vencimiento.getUsuario(), vencimiento.getLogAuditoria().getEstacion());

	}

	//L.O.C. 10/03/2017 Req. Ajustar montos para la generación correcta del Reporte de Confirmación de Pago
	public void ajustarMontos(BigDecimal suma, BigDecimal nuevoValor, Vencimiento vencimiento, String moneda, String monedaSUS, String bandera) throws DataException {
		int resultadoComp;
		int resultCompInter;
		BigDecimal diferencia;
		BigDecimal nuevoCom;
		BigDecimal nuevoInter;
		LiquidacionPago liquidacionPago = null;
		Liquidacion liquidacion = liquidacionQLBeanLocal.getLiquidacion(vencimiento.getLiqCodigo());



		if(moneda.equals("69")) {
			if ( bandera.equals("SI")) {
				resultadoComp = suma.compareTo(vencimiento.getTotalBs());
			}else {
				resultadoComp = suma.compareTo(nuevoValor);
			}

			if (resultadoComp == 0) {

			} else {
				if (bandera.equals("SI")) {
					diferencia = vencimiento.getTotalBs().subtract(suma);
				}else {
					diferencia = nuevoValor.subtract(suma);
				}

					resultCompInter = vencimiento.getComisionBs().compareTo(new BigDecimal(0.00));

					if (resultCompInter == 0) {
						nuevoInter = vencimiento.getInteresBs().add(diferencia);
						liquidacionPago = liquidacionPagoQLBeanLocal.actualizar(vencimiento.getLiqCodigo(), "INTBS", nuevoInter, monedaSUS, "1", null, vencimiento.getFechaTc(),
								vencimiento.getUsuario(), vencimiento.getLogAuditoria().getEstacion());
					} else {
						nuevoCom = vencimiento.getComisionBs().add(diferencia);
						liquidacionPago = liquidacionPagoQLBeanLocal.actualizar(vencimiento.getLiqCodigo(), "COMBS", nuevoCom, monedaSUS, "1", null, vencimiento.getFechaTc(),
								vencimiento.getUsuario(), vencimiento.getLogAuditoria().getEstacion());
					}
			}
			monedaSUS = vencimiento.getMoneda();
			liquidacionPago = liquidacionPagoQLBeanLocal.actualizar(vencimiento.getLiqCodigo(), "COMMO", vencimiento.getComisionMO(), monedaSUS, "1", null, vencimiento.getFechaTc(),
					vencimiento.getUsuario(), vencimiento.getLogAuditoria().getEstacion());

			liquidacionPago = liquidacionPagoQLBeanLocal.actualizar(vencimiento.getLiqCodigo(), "MOTOT", vencimiento.getTotalMO(), monedaSUS, "1", null, vencimiento.getFechaTc(),
					vencimiento.getUsuario(), vencimiento.getLogAuditoria().getEstacion());

		}
		if(moneda.equals("34")){
			if (bandera.equals("SI")){
				resultadoComp = suma.compareTo(vencimiento.getTotalUsd());
			}else {
				resultadoComp = suma.compareTo(nuevoValor);
			}

			if (resultadoComp == 0){

			}else {
				if (bandera.equals("SI")) {
					diferencia = vencimiento.getTotalUsd().subtract(suma);
				}else {
					diferencia = nuevoValor.subtract(suma);
				}
				resultCompInter = vencimiento.getComisionUsd().compareTo(new BigDecimal(0.00));

				if (resultCompInter == 0) {
					nuevoInter = vencimiento.getInteresUsd().add(diferencia);
					liquidacionPago = liquidacionPagoQLBeanLocal.actualizar(vencimiento.getLiqCodigo(), "INTSUS", nuevoInter, monedaSUS, "1", null, vencimiento.getFechaTc(),
							vencimiento.getUsuario(), vencimiento.getLogAuditoria().getEstacion());
					liquidacionPago = liquidacionPagoQLBeanLocal.actualizar(vencimiento.getLiqCodigo(), "INT", nuevoInter, vencimiento.getMonedaCont(), "1", null,
							vencimiento.getFechaTc(), vencimiento.getUsuario(), vencimiento.getLogAuditoria().getEstacion());
					liquidacionPago = liquidacionPagoQLBeanLocal.actualizar(vencimiento.getLiqCodigo(), "INTMO", nuevoInter, vencimiento.getMoneda(), "1", null, vencimiento.getFechaTc(),
							vencimiento.getUsuario(), vencimiento.getLogAuditoria().getEstacion());

					liquidacion.setInteresUsd(nuevoInter);
					liquidacionQLBeanLocal.actualizaLiquidacion(liquidacion);

				} else {
					nuevoCom = vencimiento.getComisionUsd().add(diferencia);
					liquidacionPago = liquidacionPagoQLBeanLocal.actualizar(vencimiento.getLiqCodigo(), "COMSUS", nuevoCom, monedaSUS, "1", null, vencimiento.getFechaTc(),
							vencimiento.getUsuario(), vencimiento.getLogAuditoria().getEstacion());
					liquidacionPago = liquidacionPagoQLBeanLocal.actualizar(vencimiento.getLiqCodigo(), "COM", nuevoCom, vencimiento.getMonedaCont(), "1", null,
							vencimiento.getFechaTc(), vencimiento.getUsuario(), vencimiento.getLogAuditoria().getEstacion());
					liquidacionPago = liquidacionPagoQLBeanLocal.actualizar(vencimiento.getLiqCodigo(), "COMMO", nuevoCom, vencimiento.getMoneda(), "1", null, vencimiento.getFechaTc(),
							vencimiento.getUsuario(), vencimiento.getLogAuditoria().getEstacion());

					liquidacion.setComisionUsd(nuevoCom);
					liquidacionQLBeanLocal.actualizaLiquidacion(liquidacion);
				}
			}
		}
	}
	public void enviarCorreos(Vencimiento vencimiento, String observacion, String nuevoEstado, String flagTipoActualiza) throws DataException {
		logger.info("Enviando Correos para  " + nuevoEstado + " ent. " + vencimiento.getCodPartLiquidacion());
		// envio de correos al cambio de estados
		if (!StringUtils.isBlank(nuevoEstado)) {
			Email email = new Email();

			if (nuevoEstado.equals("PAGOAUTORIZADO")) {
				// los estados son diferentes y se esta autorizando el mismo
				List<DeudorLiquidacion> deudorLiquidacionList = deudorLiquidacionQLBeanLocal.listaCorreos("", false);

				List<String> correos = MsgLogic.listaDeCorreos(deudorLiquidacionList);

				Map<String, Object> params = new HashMap<String, Object>();
				params.put("vencimiento", vencimiento);
				String mensaje = email.armarMensaje(nuevoEstado, "", params, null, null);

				Object[] parameters = new Object[] { mensaje };

				MsgLogic.enviarMails(correos, "", "", "Aviso SIODEX: Pago Autorizado por " + vencimiento.getVcDatosAdic().getSiglaProv() + " Liq: " + vencimiento.getLiqCodigo()
						+ " - " + vencimiento.getPtmCodigo() + " [" + vencimiento.getTraCodigo() + "]", false, parameters);

			} else if (nuevoEstado.equals("VENCOBSERVADO")) {
				List<DeudorLiquidacion> deudorLiquidacionList = deudorLiquidacionQLBeanLocal.listaCorreos("", false);

				List<String> correos = MsgLogic.listaDeCorreos(deudorLiquidacionList);

				Map<String, Object> params = new HashMap<String, Object>();
				params.put("vencimiento", vencimiento);
				String mensaje = email.armarMensaje(nuevoEstado, "", params, null, null);

				Object[] parameters = new Object[] { mensaje };

				MsgLogic.enviarMails(
						correos,
						"",
						"",
						"Aviso SIODEX: Liquidacion Observada por " + vencimiento.getVcDatosAdic().getSiglaProv() + " Liq: " + vencimiento.getLiqCodigo() + " - "
								+ vencimiento.getPtmCodigo() + " [" + vencimiento.getTraCodigo() + "]", false, parameters);

			} else if (nuevoEstado.equals("LIQRECHAZADA")) {
				List<DeudorLiquidacion> deudorLiquidacionList = deudorLiquidacionQLBeanLocal.listaCorreos("", false);

				List<String> correos = MsgLogic.listaDeCorreos(deudorLiquidacionList);

				Map<String, Object> params = new HashMap<String, Object>();
				params.put("vencimiento", vencimiento);
				String mensaje = email.armarMensaje(nuevoEstado, "", params, null, null);

				Object[] parameters = new Object[] { mensaje };

				MsgLogic.enviarMails(
						correos,
						"",
						"",
						"Aviso SIODEX: Liquidacion Rechazada por " + vencimiento.getVcDatosAdic().getSiglaProv() + " Liq: " + vencimiento.getLiqCodigo() + " - "
								+ vencimiento.getPtmCodigo() + " [" + vencimiento.getTraCodigo() + "]", false, parameters);

			} else if (nuevoEstado.equals("LIQCONTABILIZADA")) {

				List<DeudorLiquidacion> deudorLiquidacionList = deudorLiquidacionQLBeanLocal.listaCorreos(vencimiento.getCodPartLiquidacion(), true);

				List<String> correos = MsgLogic.listaDeCorreos(deudorLiquidacionList);

				Map<String, Object> params = new HashMap<String, Object>();
				params.put("vencimiento", vencimiento);
				String mensaje = email.armarMensaje(nuevoEstado, "", params, null, null);

				Object[] parameters = new Object[] { mensaje };

				MsgLogic.enviarMails(correos, "", "", "Aviso SIODEX: Registro Contable Liq: " + vencimiento.getLiqCodigo() + " - " + vencimiento.getPtmCodigo() + " ["
						+ vencimiento.getTraCodigo() + "]", false, parameters);
			}

		}
	}

	public void enviarCorreos(Vencimiento vencimiento, String observacion, String nuevoEstado, String flagTipoActualiza, String flagErrorWS, String errorWS) throws DataException {
		logger.info("Enviando Correos para  " + nuevoEstado + " ent. " + vencimiento.getCodPartLiquidacion());
		// envio de correos al cambio de estados
		if (!StringUtils.isBlank(nuevoEstado)) {
			Email email = new Email();

			if (nuevoEstado.equals("LIQCONTABILIZADA")) {

				List<DeudorLiquidacion> deudorLiquidacionList = deudorLiquidacionQLBeanLocal.listaCorreos(vencimiento.getCodPartLiquidacion(), true);

				List<String> correos = MsgLogic.listaDeCorreos(deudorLiquidacionList);

				Map<String, Object> params = new HashMap<String, Object>();
				params.put("vencimiento", vencimiento);
				String mensaje = email.armarMensaje(nuevoEstado, "", params, flagErrorWS, errorWS);

				Object[] parameters = new Object[] { mensaje };

				if (flagErrorWS.equals("-1")) {
					MsgLogic.enviarMails(correos, "", "", "Aviso SIODEX: Registro Contable Liq: " + vencimiento.getLiqCodigo() + " - " + vencimiento.getPtmCodigo() + " ["
							+ vencimiento.getTraCodigo() + "] SIN NOTIFICACION", false, parameters);
				} else {
					MsgLogic.enviarMails(correos, "", "", "Aviso SIODEX: Registro Contable Liq: " + vencimiento.getLiqCodigo() + " - " + vencimiento.getPtmCodigo() + " ["
							+ vencimiento.getTraCodigo() + "]", false, parameters);
				}

			}

		}
	}

	/**
	 * retorna el tipo de operacion del prestamo, define el tipo de calculo de
	 * las comisiones bancarias
	 *
	 * @param vencimiento
	 * @return
	 */
	public String tipoPrestamoLiq(Vencimiento vencimiento) {

		String tipo = "";
		List<LiquidacionDet> listaDet = vencimiento.getLiquidacionDetLista();// liquidacionDetQLBeanLocal.listaLiquidacion(vencimiento.getLiqCodigo());

		if (vencimiento.getAcreedor().startsWith("EXIMBANK") && !vencimiento.getAcreedor().contains("USA") && (listaDet.size() == 1)) {
			tipo = "EX01";
		} else if (vencimiento.getAcreedor().equals("BID") && vencimiento.getRefAcre().contains("BL")) {
			tipo = "EX02";
		} else if (vencimiento.getPtmCodigo().startsWith("B-H") && (vencimiento.getMoneda().equals("BBS"))) {
			tipo = "LO01";
		} else if (vencimiento.getPtmCodigo().startsWith("I-H")) {
			tipo = "LO02";
		} else if (vencimiento.getPtmCodigo().startsWith("I")) {
			tipo = "LO03";
		} else if (vencimiento.getCodTipoOperacion().equals("14") || vencimiento.getCodTipoOperacion().equals("34")) {
			tipo = "EX03";
		} else if (!vencimiento.getCodTipoOperacion().equals("08") && (listaDet.size() == 1)) {
			tipo = "EX04";
		} else {
			tipo = "EX05";
		}

		return tipo;
	}

	/**
	 * numero de mensajes swift que se genera por el vencimiento
	 *
	 * @param vencimiento
	 * @return
	 */

	public int nroMensajesSwift(Vencimiento vencimiento) throws DataException {

		// el mensaje swift es solo para las siguientes tipos de operacion
		// (tabla tipo_operacion)
		// 01,04,07,08,09,10,11,12,14,15,17,19,20,21,22,24,32

		int nroMensSwift = 0;

		boolean m = isGenerarMensajeSwit(vencimiento.getCodTipoOperacion());

		if (m) {
			Date fechaValorMensSwift = new Date();
			// recupera la fecha del mensaje swift
			List<Mensaje> mensajelist = mensajeQLBeanLocal.mensajeByLiqcodigoMonSigade(vencimiento.getLiqCodigo(), null);
			if (mensajelist.size() > 0) {
				if (mensajelist.get(0).getCveEstadoS().equals("E") || mensajelist.get(0).getCveEstadoS().equals("V")) {
					fechaValorMensSwift = mensajelist.get(0).getFechaValor();
				}
			}
			for (Mensaje mensaje : mensajelist) {
				if (fechaValorMensSwift.compareTo(mensaje.getFechaValor()) == 0) {
					if (mensaje.getCveEstadoS().equals("E") || mensaje.getCveEstadoS().equals("V")) {
						// si se ha creado mensajes swift la fecha de TC serÃ¡
						// la
						// fecha del mensaje swift
						fechaValorMensSwift = mensaje.getFechaValor();
					}

				} else {
					// control de fechas en mensaje swift deben ser la misma
					// fecha
					// en todos
					throw new DataException("Inconsistencia en fecha mensaje swift fechas diferentes " + vencimiento.getPtmCodigo() + " tramo:" + vencimiento.getTraCodigo()
							+ " mensaje " + mensaje.getMenCodigo());
				}
			}

			vencimiento.setFechaPago(fechaValorMensSwift);

			if (mensajelist.size() > 0) {
				return mensajelist.size();
			}

			if (vencimiento.getCveEstado().equals("O") || vencimiento.getCveEstado().equals("C")) {
				// si el estado es con operacion o contabilizado no se cambia
				// nada
				return mensajelist.size();
			}

			String tipo = tipoPrestamoLiq(vencimiento);
			Cuenta cuenta = vencimiento.getCuentaPrestamo("DEUD");
			String genMenSwift = cuenta.getGenMenswift();

			if (tipo.equals("LO01") || tipo.equals("LO02")) {
				// locales de seguro
			} else {
				if (!StringUtils.isBlank(vencimiento.getMoneda()) && (vencimiento.getMoneda().equals("BBS") || vencimiento.getMoneda().equals("XP2"))) {
					// monedas locales de la liquidacion
				} else {
					// if (!StringUtils.isBlank(genMenSwift) &&
					// genMenSwift.equals("S")) {

					List<Datos> datos = mensajeSwiftBeanLocal.getPretamoEsquema(vencimiento.getPtmCodigo(), vencimiento.getTraCodigo());
					if (datos != null && datos.size() > 0) {
						// verificamos q tenga esquema swift
						// segun TEscobar en conversacion telefonica 20140127
						// define que cada moneda debe agruparse
						// por moneda, es decir una moneda un mensaje swift,
						// dejando para su anÃ¡lisis en su momento
						// casos especiales si hubiere
						List<Liquidacion> monedaMonto = consultasSdxQLBeanLocal.montosPorMonedas(vencimiento.getLiqCodigo());
						for (Liquidacion liquidacion : monedaMonto) {
							String monedaSIGADE = liquidacion.getMonSigade();
							BigDecimal montoMO = liquidacion.getMonto();

							if (monedaSIGADE.equals("BBS") || monedaSIGADE.equals("XP2")) {
								// ||
								// cuenta.getCveTipoLiq().trim().equals("LOCA")
								// no genera mensaje swift
							} else {
								if (montoMO.compareTo(BigDecimal.ZERO) != 0)

									nroMensSwift++;
							}
						}
					}

					// }
				}
			}
			logger.info("Numero de mensajes swift para liq " + vencimiento.getLiqCodigo() + " nro " + nroMensSwift + " tipo prestamo: " + cuenta.getTopCodigo());
		}

		return nroMensSwift;
	}

	/**
	 *
	 * @param monto
	 * @param monOrigen
	 *            moneda en el cual se expresa monto
	 * @param monDestino
	 *            moneda a la cual convertiremos, gralmente es sus o bols, es la
	 *            moneda de la cuenta a la cual de debitara
	 * @param fecha
	 * @return
	 * @throws DataException
	 */
	public Map<String, Object> conversion(BigDecimal monto, String monOrigen, String monDestino, Date fecha, String monDestinoConv000, BigDecimal tcDefecto) throws DataException {

		monDestino = monDestino.trim();
		monOrigen = monOrigen.trim();
		Map<String, Object> resp = new HashMap<String, Object>();
		BigDecimal tipoCambioSUS = null;

		// monto que se expresa en la cuenta a debitar
		BigDecimal montoConvCtaDEUC = null;

		String codmonedasus = null;

		// expresa el monto en bolivianos del monto original segun el tipo de la
		// cuenta
		BigDecimal montoBS = null;
		// expresa el monto en dolares del monto original segun el tipo de la
		// cuenta
		BigDecimal montoSUS = null;

		// expresa la cantidad de bolivianos por la venta de dolares
		// depende a la moneda de la cuenta
		BigDecimal ventaSUSExpEnBS = BigDecimal.ZERO.setScale(2, BigDecimal.ROUND_HALF_UP);

		BigDecimal diferencialVentaSUS = BigDecimal.ZERO.setScale(2, BigDecimal.ROUND_HALF_UP);
		BigDecimal tipoCambioMO = coinQLBeanLocal.getTC(fecha, monOrigen);
		// tipo de cambio mon origen por boliviano . valor extraido de coin
		BigDecimal tipoCambioMOxBS = BigDecimal.ZERO;
		logger.info("~~~~ Conversion ~~~~~");

		if (monDestino.trim().equals("69")) {
			// moneda cta del prestamo es en bols
			codmonedasus = "35";
			codmonedasus = "35";
			tipoCambioSUS = coinQLBeanLocal.getTC(fecha, "35");

			if (monOrigen.trim().equals("69")) {
				// el monto esta en bols
				// tipocambio debería de ser 1
				montoConvCtaDEUC = monto;
				BigDecimal tipoCambioCompra = coinQLBeanLocal.getTC(fecha, "34");
				montoSUS = montoConvCtaDEUC.divide(tipoCambioCompra, 2, RoundingMode.HALF_UP);
				// cero ya que no hay compra de dolar
				ventaSUSExpEnBS = BigDecimal.ZERO;
				diferencialVentaSUS = BigDecimal.ZERO;

				tipoCambioMO = BigDecimal.ONE.divide(tipoCambioCompra, 11, RoundingMode.HALF_UP);
				tipoCambioMOxBS = BigDecimal.ONE;

			} else if (monOrigen.equals("34")) {

				// moneda es dolar el tipo de cambio debe se el de venta ya que
				// se compra dolares del BCB
				montoConvCtaDEUC = monto.setScale(2, BigDecimal.ROUND_HALF_UP).multiply(tipoCambioSUS).setScale(2, BigDecimal.ROUND_HALF_UP);

				montoSUS = monto;

				// hay venta de dolar
				ventaSUSExpEnBS = montoConvCtaDEUC;

				BigDecimal tipoCambioCompra = coinQLBeanLocal.getTC(fecha, "34");
				// venta - compra de usd
				diferencialVentaSUS = ventaSUSExpEnBS.subtract(monto.setScale(2, BigDecimal.ROUND_HALF_UP).multiply(tipoCambioCompra).setScale(2, BigDecimal.ROUND_HALF_UP));

				tipoCambioMO = BigDecimal.ONE;
				tipoCambioMOxBS = tipoCambioSUS;

			} else if (monOrigen.equals("75")) {
				montoConvCtaDEUC = monto.setScale(2, BigDecimal.ROUND_HALF_UP).multiply(tipoCambioMO).setScale(2, BigDecimal.ROUND_HALF_UP);

				BigDecimal tipoCambioCompra = coinQLBeanLocal.getTC(fecha, "34");
				montoSUS = montoConvCtaDEUC.divide(tipoCambioCompra, 2, RoundingMode.HALF_UP);

				ventaSUSExpEnBS = BigDecimal.ZERO;
				diferencialVentaSUS = BigDecimal.ZERO;

				tipoCambioMOxBS = tipoCambioMO;
				tipoCambioMO = tipoCambioMO.divide(tipoCambioCompra, 11, RoundingMode.HALF_UP);

			} else if (monOrigen.equals("76")) {
				montoConvCtaDEUC = monto.setScale(2, BigDecimal.ROUND_HALF_UP).multiply(tipoCambioMO).setScale(2, BigDecimal.ROUND_HALF_UP);

				BigDecimal tipoCambioCompra = coinQLBeanLocal.getTC(fecha, "34");
				montoSUS = montoConvCtaDEUC.divide(tipoCambioCompra, 2, RoundingMode.HALF_UP);

				ventaSUSExpEnBS = BigDecimal.ZERO;
				diferencialVentaSUS = BigDecimal.ZERO;

				tipoCambioMOxBS = tipoCambioMO;
				tipoCambioMO = tipoCambioMO.divide(tipoCambioCompra, 11, RoundingMode.HALF_UP);

			} else if (monOrigen.equals("10") || monOrigen.equals("21")) {
				// chino se acepta el tipo de cambio de liq_detalle
				BigDecimal montoConvCtaDEUCTCcompra = monto.setScale(2, BigDecimal.ROUND_HALF_UP).multiply(tcDefecto).setScale(2, BigDecimal.ROUND_HALF_UP);

				// calculamos el monto de venta de dolar en bs
				ventaSUSExpEnBS = montoConvCtaDEUCTCcompra.setScale(2, BigDecimal.ROUND_HALF_UP).multiply(tipoCambioSUS).setScale(2, BigDecimal.ROUND_HALF_UP);

				montoConvCtaDEUC = ventaSUSExpEnBS;

				BigDecimal tipoCambioCompra = coinQLBeanLocal.getTC(fecha, "34");

				diferencialVentaSUS = ventaSUSExpEnBS.subtract(montoConvCtaDEUCTCcompra.setScale(2, BigDecimal.ROUND_HALF_UP).multiply(tipoCambioCompra)
						.setScale(2, BigDecimal.ROUND_HALF_UP));

				montoSUS = ventaSUSExpEnBS.divide(tipoCambioSUS, 2, RoundingMode.HALF_UP);

				tipoCambioMOxBS = tcDefecto.multiply(tipoCambioCompra).setScale(11, BigDecimal.ROUND_HALF_UP);
				tipoCambioMO = tcDefecto;

				Map<String, Object> montoConvertido = UtilConversion.conversion(monto, monOrigen, monDestino, fecha, BigDecimal.ONE, "V", coinQLBeanLocal);
				BigDecimal montoBoliv = (BigDecimal) montoConvertido.get("montobs");
				BigDecimal montoMO = (BigDecimal) montoConvertido.get("montomo");
				BigDecimal tipocambiomoxbs = (BigDecimal) montoConvertido.get("tipocambiomdest");
				BigDecimal montoADebitarSUS = (BigDecimal) montoConvertido.get("montosus");

				logger.info("==> montoBoliv " + montoBoliv + " montoMO: " + montoMO + " tipocambiomoxbs: " + tipocambiomoxbs + " " + " montoADebitarSUS: " + montoADebitarSUS);
				logger.info("==> montoConvCtaDEUCTCcompra " + montoConvCtaDEUCTCcompra + " tcDefecto: " + tcDefecto + " ventaSUSExpEnBS: " + ventaSUSExpEnBS + " " + " montoSUS: "
						+ montoSUS + " tipoCambioMOxBS: " + tipoCambioMOxBS);
			} else if (monOrigen.equals("50")) {
				// SDR
				// se trabaja con dolares
				BigDecimal montoUSDSDR = monto.setScale(2, BigDecimal.ROUND_HALF_UP).multiply(tcDefecto).setScale(2, BigDecimal.ROUND_HALF_UP);
				montoConvCtaDEUC = montoUSDSDR.setScale(2, BigDecimal.ROUND_HALF_UP).multiply(tipoCambioSUS).setScale(2, BigDecimal.ROUND_HALF_UP);

				montoSUS = montoUSDSDR;

				// hay venta de dolar
				ventaSUSExpEnBS = montoConvCtaDEUC;

				BigDecimal tipoCambioCompra = coinQLBeanLocal.getTC(fecha, "34");
				// venta - compra de usd
				diferencialVentaSUS = ventaSUSExpEnBS.subtract(montoUSDSDR.setScale(2, BigDecimal.ROUND_HALF_UP).multiply(tipoCambioCompra).setScale(2, BigDecimal.ROUND_HALF_UP));

				tipoCambioMOxBS = tipoCambioMO;
				tipoCambioMO = tcDefecto;
			} else {
				// convertimos a bs; ojo que el tipoCambioMO es a tc compra
				// segun bolsin
				BigDecimal montoConvCtaDEUCTCcompra = monto.setScale(2, BigDecimal.ROUND_HALF_UP).multiply(tipoCambioMO).setScale(2, BigDecimal.ROUND_HALF_UP);

				// convertimos a SUS por el tipo de cambio de compra
				BigDecimal tipoCambioCompra = coinQLBeanLocal.getTC(fecha, "34");

				// monto al tipo ce cambio de venta ya el montosus expresa
				// los bolivianos lo convertimos a dolar por el tc compra
				BigDecimal montoSUSCompra = montoConvCtaDEUCTCcompra.divide(tipoCambioCompra, 2, RoundingMode.HALF_UP);

				// calculamos el monto de venta de dolar en bs
				ventaSUSExpEnBS = montoSUSCompra.setScale(2, BigDecimal.ROUND_HALF_UP).multiply(tipoCambioSUS).setScale(2, BigDecimal.ROUND_HALF_UP);

				montoConvCtaDEUC = ventaSUSExpEnBS;

				montoSUS = ventaSUSExpEnBS.divide(tipoCambioSUS, 2, RoundingMode.HALF_UP);

				diferencialVentaSUS = ventaSUSExpEnBS.subtract(montoConvCtaDEUCTCcompra);

				tipoCambioMOxBS = tipoCambioMO;
				tipoCambioMO = tipoCambioMO.divide(tipoCambioCompra, 11, RoundingMode.HALF_UP);

			}

			montoBS = montoConvCtaDEUC;

		} else if (monDestino.equals("34")) {
			// la moneda de la cuenta es SUS de la cual se debitara
			codmonedasus = "34";
			tipoCambioSUS = coinQLBeanLocal.getTC(fecha, "34");

			if (monOrigen.equals("34")) {
				// la moneda es en dolares el tipo de cambio debe ser el de
				// compra
				montoConvCtaDEUC = monto;

				montoBS = montoConvCtaDEUC.setScale(2, BigDecimal.ROUND_HALF_UP).multiply(tipoCambioSUS).setScale(2, BigDecimal.ROUND_HALF_UP);
				tipoCambioMO = BigDecimal.ONE;
				tipoCambioMOxBS = tipoCambioSUS;

			} else if (monOrigen.trim().equals("50")) {
				montoConvCtaDEUC = monto.setScale(2, BigDecimal.ROUND_HALF_UP).multiply(tcDefecto).setScale(2, BigDecimal.ROUND_HALF_UP);

				montoBS = montoConvCtaDEUC.setScale(2, BigDecimal.ROUND_HALF_UP).multiply(tipoCambioSUS).setScale(2, BigDecimal.ROUND_HALF_UP);

				// tc del coin
				tipoCambioMOxBS = tipoCambioMO;

				tipoCambioMO = tcDefecto;
			} else if (monOrigen.equals("10") || monOrigen.trim().equals("21")) {

				montoConvCtaDEUC = monto.multiply(tcDefecto).setScale(2, BigDecimal.ROUND_HALF_UP);

				montoBS = montoConvCtaDEUC.multiply(tipoCambioSUS).setScale(2, BigDecimal.ROUND_HALF_UP);

				tipoCambioMO = tcDefecto;
				tipoCambioMOxBS = tipoCambioMO.multiply(tipoCambioSUS).setScale(2, BigDecimal.ROUND_HALF_UP);

				Map<String, Object> montoConvertido = UtilConversion.conversion(monto, monOrigen, monDestino, fecha, BigDecimal.ONE, "C", coinQLBeanLocal);
				BigDecimal montoBoliv = (BigDecimal) montoConvertido.get("montobs");
				BigDecimal montoMO = (BigDecimal) montoConvertido.get("montomo");
				BigDecimal tipocambiomoxbs = (BigDecimal) montoConvertido.get("tipocambiomdest");
				BigDecimal montoADebitarSUS = (BigDecimal) montoConvertido.get("montosus");

				logger.info("-->montoBoliv " + montoBoliv + " montoMO: " + montoMO + " tipocambiomoxbs: " + tipocambiomoxbs + " " + " montoADebitarSUS: " + montoADebitarSUS);
				logger.info("montoConvCtaDEUC: " + montoConvCtaDEUC + " tcDefecto: " + tcDefecto + " montoBS: " + montoBS + " " + " montoSUS: " + montoSUS + " tipoCambioMOxBS: "
						+ tipoCambioMOxBS + " tipoCambioMO: " + tipoCambioMO);

			} else if (monOrigen.trim().equals("69")) {

				// se debe convertir a dolar al tipo de cambio de compra
				montoConvCtaDEUC = monto.setScale(2, BigDecimal.ROUND_HALF_UP).divide(tipoCambioSUS, 2, RoundingMode.HALF_UP);

				montoBS = monto;

				tipoCambioMO = BigDecimal.ONE.divide(tipoCambioSUS, 11, RoundingMode.HALF_UP);
				tipoCambioMOxBS = BigDecimal.ONE;

			} else {
				// otra moneda se convierte a bs y posterior a ello se dolariza
				// se conv a bolivianos
				BigDecimal montoConvBS = monto.setScale(2, BigDecimal.ROUND_HALF_UP).multiply(tipoCambioMO).setScale(2, BigDecimal.ROUND_HALF_UP);

				montoConvCtaDEUC = montoConvBS.divide(tipoCambioSUS, 2, RoundingMode.HALF_UP);

				montoBS = montoConvBS;
				tipoCambioMOxBS = tipoCambioMO;
				tipoCambioMO = tipoCambioMO.divide(tipoCambioSUS, 11, RoundingMode.HALF_UP);
				// parche de un digito ya que el
				tipoCambioMO = tipoCambioMO.setScale(7, BigDecimal.ROUND_DOWN);

			}

			montoSUS = montoConvCtaDEUC;

		} else {
			// si la cuenta no es ni bol ni suys
			throw new DataException("conversion a cuenta moneda " + monDestino + " no implementada, la cuenta debe ser BS o SUS");
		}

		resp.put("tipocambiosus", tipoCambioSUS);
		resp.put("tipocambiomo", tipoCambioMO);
		resp.put("tipocambiomoxbs", tipoCambioMOxBS);
		resp.put("monto", montoConvCtaDEUC);
		resp.put("montobs", montoBS);
		resp.put("montosus", montoSUS);
		resp.put("montomo", monto);
		resp.put("codmonedasus", codmonedasus);
		resp.put("ventasus", ventaSUSExpEnBS);
		resp.put("difventasus", diferencialVentaSUS);

		logger.info("Conversion[" + monto + " (" + monOrigen + " -> " + monDestino + ")] a " + tipoCambioSUS + " tcDefecto: [" + tcDefecto + "] es=> " + ArrayUtils.toString(resp));

		return resp;
	}

	public BigDecimal calcularComisionCOPA(Vencimiento vencimiento, Date fechaTc) throws DataException {
		logger.info("Calculando comisionCOPA " + fechaTc + " liqCodigo " + vencimiento.getLiqCodigo());

		String comistr = consultasSdxQLBeanLocal.getParametro("@pdex");
		BigDecimal comi = new BigDecimal(comistr.replace(",", "."));

		BigDecimal sumaUSD = BigDecimal.ZERO;
		BigDecimal sumaBS = BigDecimal.ZERO;

		BigDecimal tipoCambioSUS = coinQLBeanLocal.getTC(fechaTc, "34");

		Cuenta cuentaCom = vencimiento.getCuentaPrestamo("DEUC");

		if (cuentaCom == null) {
			throw new DataException("No se pudo encontrar la Cuenta Deudora para " + vencimiento.getPtmCodigo() + " tramo:" + vencimiento.getTraCodigo());
		}

		if (cuentaCom.getCodMoneda() == null) {
			throw new DataException("Cuenta Deudora con cod moneda invalida para " + vencimiento.getPtmCodigo() + " tramo:" + vencimiento.getTraCodigo());

		}
		logger.info("XXX: moneda comis " + cuentaCom.toString());
		List<Liquidacion> monedaMonto = consultasSdxQLBeanLocal.montosPorMonedas(vencimiento.getLiqCodigo());

		for (Liquidacion liquidacion2 : monedaMonto) {
			BigDecimal comiPago = BigDecimal.ZERO;

			Moneda monedaC = monedaQLBeanLocal.getMonedaCoin(liquidacion2.getMonSigade());

			// aca obtenemos la moneda de la cta comision
			Map<String, Object> montoConvertido = conversion(liquidacion2.getMonto(), monedaC.getMonCoin().trim(), cuentaCom.getCodMoneda(), vencimiento.getFechaTc(), "69",
					liquidacion2.getTipoCambio());

			BigDecimal montoBS = (BigDecimal) montoConvertido.get("montobs");
			BigDecimal montoSUS = (BigDecimal) montoConvertido.get("montosus");

			if (monedaC.getMonCoin().trim().equals("69") || monedaC.getMonCoin().trim().equals("76")) {
				logger.info("XXX:Comision %(7)montoBS " + montoBS);
				sumaBS = sumaBS.add(montoBS);
			} else {
				// 0.007% comision en dolares
				logger.info("XXX:Comision %(7)montoSUS " + montoSUS);
				sumaUSD = sumaUSD.add(montoSUS);
			}
		}

		BigDecimal comiPagoBS = sumaBS.multiply(comi).divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
		BigDecimal comiPagoSUS = sumaUSD.multiply(comi).divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);

		comiPagoSUS = comiPagoSUS.multiply(tipoCambioSUS).setScale(2, BigDecimal.ROUND_HALF_UP);

		sumaBS = comiPagoSUS.add(comiPagoBS);
		logger.info("Comision %(" + comi + ") del total " + sumaBS);
		return sumaBS;
	}

	public static void main(String[] args) {
		System.out.println(System.getProperty("line.separator").length());
		System.out.println("/BNF/OUI 525/IO 2079658 IMFEES" + "\r\n" + "CUSTOMER 1367");
		Date fe = UtilsDate.dateFromString("01/01/2014", "dd/MM/yyyy");
		Date hoy = new Date();
		System.out.println(fe.compareTo(hoy));
		System.out.println(UtilsDate.compara(fe, hoy));
		fe = UtilsDate.dateFromString("01/12/2014", "dd/MM/yyyy");
		System.out.println(fe.compareTo(hoy));
		System.out.println(UtilsDate.compara(fe, hoy));
		fe = UtilsDate.dateFromString("09/03/2014", "dd/MM/yyyy");
		System.out.println(fe.compareTo(hoy));
		System.out.println(UtilsDate.compara(fe, hoy));
	}

	// rmq

	public Boolean isGenerarMensajeSwit(String topCodigo) {
		try {
			String genMensajeSwift = (String) em.createNativeQuery("SELECT gen_menswift FROM tipo_operacion WHERE top_codigo = :pTopCodigo").setParameter("pTopCodigo", topCodigo)
					.getSingleResult();

			if (genMensajeSwift.equals("S"))
				return true;

		} catch (Exception e) {
			logger.error("error al ejecutar consulta nativa: " + e.getMessage(), e);
		}
		return false;
	}

	public Boolean isCobrarComMensajeSwit(String topCodigo) {
		try {
			String genMensajeSwift = (String) em.createNativeQuery("SELECT com_menswift FROM tipo_operacion WHERE top_codigo = :pTopCodigo").setParameter("pTopCodigo", topCodigo)
					.getSingleResult();

			if (genMensajeSwift.equals("S"))
				return true;

		} catch (Exception e) {
			logger.error("error al ejecutar consulta nativa: " + e.getMessage(), e);
		}
		return false;
	}
	// rmq

}
