@javax.xml.bind.annotation.XmlSchema(namespace = "http://sigma.gob.bo/")
package gob.bcb.jee.siodex.WS.sigma;
