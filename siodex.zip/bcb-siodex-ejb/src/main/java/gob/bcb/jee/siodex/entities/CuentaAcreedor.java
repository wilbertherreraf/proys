package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import java.util.Date;

public class CuentaAcreedor implements Serializable {
	private String cctCodigo;
	private String bcoCodigo;
	private String acrCodigo;
	private String cctNumero;
	private String cctBic;
	private String cctNombre;
	private String cctPlaza;
	private String cctDireccion;	
	private Short cveVigente;
	private String monSwift;
	private String refCodigo;
	private String usrCodigo;
	private Date fechaHora;
	private String estacion;
	private String bcoBic;
	private String bcoInterm;
	private String bcoCuenta;
	private String bcoNombre;
	private String bcoPlaza;
	private String refDefinicion;
	
	public String getCctCodigo() {
		return cctCodigo;
	}
	public void setCctCodigo(String cctCodigo) {
		this.cctCodigo = cctCodigo;
	}
	public String getBcoCodigo() {
		return bcoCodigo;
	}
	public void setBcoCodigo(String bcoCodigo) {
		this.bcoCodigo = bcoCodigo;
	}
	public String getAcrCodigo() {
		return acrCodigo;
	}
	public void setAcrCodigo(String acrCodigo) {
		this.acrCodigo = acrCodigo;
	}
	public String getCctNumero() {
		return cctNumero;
	}
	public void setCctNumero(String cctNumero) {
		this.cctNumero = cctNumero;
	}
	public String getCctBic() {
		return cctBic;
	}
	public void setCctBic(String cctBic) {
		this.cctBic = cctBic;
	}
	public String getCctNombre() {
		return cctNombre;
	}
	public void setCctNombre(String cctNombre) {
		this.cctNombre = cctNombre;
	}
	public String getCctPlaza() {
		return cctPlaza;
	}
	public void setCctPlaza(String cctPlaza) {
		this.cctPlaza = cctPlaza;
	}
	public Short getCveVigente() {
		return cveVigente;
	}
	public void setCveVigente(Short cveVigente) {
		this.cveVigente = cveVigente;
	}
	public String getMonSwift() {
		return monSwift;
	}
	public void setMonSwift(String monSwift) {
		this.monSwift = monSwift;
	}
	public String getRefCodigo() {
		return refCodigo;
	}
	public void setRefCodigo(String refCodigo) {
		this.refCodigo = refCodigo;
	}
	public String getUsrCodigo() {
		return usrCodigo;
	}
	public void setUsrCodigo(String usrCodigo) {
		this.usrCodigo = usrCodigo;
	}
	public Date getFechaHora() {
		return fechaHora;
	}
	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}
	public String getEstacion() {
		return estacion;
	}
	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}
	public String getBcoBic() {
		return bcoBic;
	}
	public void setBcoBic(String bcoBic) {
		this.bcoBic = bcoBic;
	}
	public String getBcoInterm() {
		return bcoInterm;
	}
	public void setBcoInterm(String bcoInterm) {
		this.bcoInterm = bcoInterm;
	}
	public String getBcoCuenta() {
		return bcoCuenta;
	}
	public void setBcoCuenta(String bcoCuenta) {
		this.bcoCuenta = bcoCuenta;
	}
	public String getBcoNombre() {
		return bcoNombre;
	}
	public void setBcoNombre(String bcoNombre) {
		this.bcoNombre = bcoNombre;
	}
	public String getBcoPlaza() {
		return bcoPlaza;
	}
	public void setBcoPlaza(String bcoPlaza) {
		this.bcoPlaza = bcoPlaza;
	}
	public String getRefDefinicion() {
		return refDefinicion;
	}
	public void setRefDefinicion(String refDefinicion) {
		this.refDefinicion = refDefinicion;
	}
	public String getCctDireccion() {
		return cctDireccion;
	}
	public void setCctDireccion(String cctDireccion) {
		this.cctDireccion = cctDireccion;
	}
}
