package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.ComOpers;

import javax.ejb.Local;

@Local
public interface ComOpersQLBeanLocal {

	/**
	 * 
	 * @return
	 */
	void edit(ComOpers dso);
	void create(ComOpers dso);
	public ComOpers getCo(Integer codigo);
	
}
