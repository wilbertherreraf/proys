/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author CUriona
 */
@Embeddable
public class MensajeEstadoPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 6)
    @Column(name = "men_codigo", nullable = false, length = 6)
    private String menCodigo;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 1)
    @Column(name = "cve_estado_s", nullable = false, length = 1)
    private String cveEstadoS;

    public MensajeEstadoPK() {
    }

    public MensajeEstadoPK(String menCodigo, String cveEstadoS) {
        this.menCodigo = menCodigo;
        this.cveEstadoS = cveEstadoS;
    }

    public String getMenCodigo() {
        return menCodigo;
    }

    public void setMenCodigo(String menCodigo) {
        this.menCodigo = menCodigo;
    }

    public String getCveEstadoS() {
        return cveEstadoS;
    }

    public void setCveEstadoS(String cveEstadoS) {
        this.cveEstadoS = cveEstadoS;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (menCodigo != null ? menCodigo.hashCode() : 0);
        hash += (cveEstadoS != null ? cveEstadoS.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof MensajeEstadoPK)) {
            return false;
        }
        MensajeEstadoPK other = (MensajeEstadoPK) object;
        if ((this.menCodigo == null && other.menCodigo != null) || (this.menCodigo != null && !this.menCodigo.equals(other.menCodigo))) {
            return false;
        }
        if ((this.cveEstadoS == null && other.cveEstadoS != null) || (this.cveEstadoS != null && !this.cveEstadoS.equals(other.cveEstadoS))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gob.bcb.siodex.entities.MensajeEstadoPK[ menCodigo=" + menCodigo + ", cveEstadoS=" + cveEstadoS + " ]";
    }
    
}
