package gob.bcb.jee.siodex.WS;

import gob.bcb.jee.siodex.QL.VencimientoQLBean;
import gob.bcb.jee.siodex.QL.VencimientoQLBeanLocal;
import gob.bcb.jee.siodex.entities.ComisionBancaria;
import gob.bcb.jee.siodex.entities.Liquidacion;
import gob.bcb.jee.siodex.entities.LiquidacionDet;
import gob.bcb.jee.siodex.entities.Vencimiento;
import gob.bcb.jee.siodex.mefp.LiquidacionCuentas;
import gob.bcb.jee.siodex.util.UtilsDate;
import gob.bcb.jee.siodex.xml.LiquidacionDetalle;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.log4j.Logger;

import sun.util.logging.resources.logging;

public class ArmarXML {
	static final Logger logger = Logger.getLogger(ArmarXML.class);
	
	@Inject
	private VencimientoQLBeanLocal vencimientoQLBeanLocal;
	
	public static String xmlVencLiquidacionCab(Integer maxLote, int cont, String respuestaXML) {
		String fecha = UtilsDate.stringFromDate(new Date(), "yyyyMMdd");
		StringBuilder sb = new StringBuilder();
		sb.append("<?xml version='1.0' encoding='UTF-8'?>\n");
		sb.append("<respuesta>\n");
		sb.append("<id>").append(maxLote).append("</id>\n");
		sb.append("<fecha>").append(fecha).append("</fecha>\n");
		sb.append("<totalReg>").append(cont).append("</totalReg>\n");
		sb.append(respuestaXML);
		sb.append("</respuesta>\n");
		return sb.toString();
	}

	public static String xmlVencLiquidacionDet(Vencimiento vencimiento, List<LiquidacionDet> liquidacionDetLista, String urlReporte) {
		StringBuilder sb = new StringBuilder();
		sb.append("<vencimientos>\n");

		for (LiquidacionDet liquidacionDet : liquidacionDetLista) {
			
			BigDecimal tc = liquidacionDet.getTipoCambio().setScale(7, BigDecimal.ROUND_HALF_UP);
			
			BigDecimal totalUsd = liquidacionDet.getCapitalMo().add(liquidacionDet.getInteresMo()).add(liquidacionDet.getComisionMo());

			totalUsd = totalUsd.multiply(tc).setScale(2, BigDecimal.ROUND_HALF_UP);

			sb.append("<vencimiento>\n");
			sb.append("<codigo>").append(liquidacionDet.getLiquidacionDetPK().getLiqCodigo())
					.append(liquidacionDet.getLiquidacionDetPK().getLiqDetalle()).append("</codigo>\n");
			sb.append("<prestamo>").append(liquidacionDet.getPinPrestamo()).append("</prestamo>\n");
			sb.append("<tramo>").append(liquidacionDet.getPinTramo()).append("</tramo>\n");
			sb.append("<fechaVenc>").append(UtilsDate.stringFromDate(vencimiento.getFechaVenc(), "yyyyMMdd")).append("</fechaVenc>\n");
			sb.append("<capital>").append(liquidacionDet.getCapitalMo().setScale(2, BigDecimal.ROUND_HALF_UP)).append("</capital>\n");
			sb.append("<intereses>").append(liquidacionDet.getInteresMo().setScale(2, BigDecimal.ROUND_HALF_UP)).append("</intereses>\n");
			sb.append("<comisiones>").append(liquidacionDet.getComisionMo().setScale(2, BigDecimal.ROUND_HALF_UP)).append("</comisiones>\n");
			sb.append("<moneda>").append(liquidacionDet.getMonSigade()).append("</moneda>\n");
			sb.append("<montoUSD>").append(totalUsd.setScale(2, BigDecimal.ROUND_HALF_UP)).append("</montoUSD>\n");
			sb.append("<tipoCambio>").append(tc).append("</tipoCambio>\n");
			sb.append("<fechaTipoCambio>").append(UtilsDate.stringFromDate(vencimiento.getFechaTc(), "yyyyMMdd")).append("</fechaTipoCambio>\n");
			sb.append("<estado>").append(vencimiento.getCveEstNotif()).append("</estado>\n");
			sb.append("<urlReporte>").append(urlReporte).append("</urlReporte>\n");
			sb.append("</vencimiento>\n");
		}
		sb.append("</vencimientos>\n");

		return sb.toString();
	}

	// respuesta xml a consulta de pagos efectuados
	public static String xmlPagoCab(Vencimiento vencimiento, Liquidacion liquidacionBS,BigDecimal tcV, LiquidacionCuentas cope, LiquidacionCuentas lope,
			LiquidacionCuentas ccom, LiquidacionCuentas lcom, BigDecimal comisionBancariaCOPAMN, BigDecimal comisionBancariaSWFTMN,
			BigDecimal comisionBancariaUTILMN, String pagoDetallesXML, String urlReporte) {
		
		// para expresar el tipo de moneda del credito
		String moneda = "USD";
		if (vencimiento.getMonedaCont().trim().equals("69")){
			moneda = "BBS";
		}
		
		StringBuilder respuesta = new StringBuilder();
		
		tcV = tcV.setScale(7, BigDecimal.ROUND_HALF_UP);
		
		respuesta.append("<?xml version='1.0' encoding='UTF-8'?>\n");
		respuesta.append("<respuesta>\n");
		respuesta.append("<codigo>").append(vencimiento.getLiqCodigo()).append("</codigo>\n");
		respuesta.append("<prestamo>").append(vencimiento.getPtmCodigo()).append("</prestamo>\n");
		respuesta.append("<tramo>").append(vencimiento.getTraCodigo()).append("</tramo>\n");
		respuesta.append("<moneda>").append(moneda).append("</moneda>\n");
		respuesta.append("<tipoCambio>").append(vencimiento.getTipoCambioCont()).append("</tipoCambio>\n");
		respuesta.append("<fechaTipoCambio>").append(UtilsDate.stringFromDate(vencimiento.getFechaTc(), "yyyyMMdd")).append("</fechaTipoCambio>\n");
		respuesta.append("<capitalUSD>").append(vencimiento.getCapitalUsd().setScale(2, BigDecimal.ROUND_HALF_UP)).append("</capitalUSD>\n");
		respuesta.append("<interesesUSD>").append(vencimiento.getInteresUsd().setScale(2, BigDecimal.ROUND_HALF_UP)).append("</interesesUSD>\n");
		respuesta.append("<comisionesUSD>").append(vencimiento.getComisionUsd().setScale(2, BigDecimal.ROUND_HALF_UP)).append("</comisionesUSD>\n");
		respuesta.append("<capitalBS>").append(vencimiento.getCapitalBs()).append("</capitalBS>\n");
		respuesta.append("<interesesBS>").append(vencimiento.getInteresBs()).append("</interesesBS>\n");
		respuesta.append("<comisionesBS>").append(vencimiento.getComisionBs()).append("</comisionesBS>\n");
		respuesta.append("<cuentaServicio>").append(cope.getValorAdic()).append("</cuentaServicio>\n");
		respuesta.append("<libretaServicio>").append(lope.getValorAdic()).append("</libretaServicio>\n");
		respuesta.append("<cuentaComisiones>").append(ccom.getValorAdic()).append("</cuentaComisiones>\n");
		respuesta.append("<libretaComisiones>").append(lcom.getValorAdic()).append("</libretaComisiones>\n");
		respuesta.append("<montoComisiones>")
				.append(comisionBancariaCOPAMN.add(comisionBancariaSWFTMN).add(comisionBancariaUTILMN).setScale(2, BigDecimal.ROUND_HALF_UP))
				.append("</montoComisiones>\n");
		respuesta.append("<comisionPagoBS>").append(comisionBancariaCOPAMN.setScale(2, BigDecimal.ROUND_HALF_UP)).append("</comisionPagoBS>\n");
		respuesta.append("<gastoComunicacionBS>").append(comisionBancariaSWFTMN.setScale(2, BigDecimal.ROUND_HALF_UP))
				.append("</gastoComunicacionBS>\n");
		respuesta.append("<gastoAdministrativoBS>").append(comisionBancariaUTILMN.setScale(2, BigDecimal.ROUND_HALF_UP))
				.append("</gastoAdministrativoBS>\n");
		respuesta.append("<listaPagos>\n");
		respuesta.append(pagoDetallesXML);
		respuesta.append("</listaPagos>\n");
		respuesta.append("<urlReporte>").append(urlReporte).append("</urlReporte>\n");
		respuesta.append("</respuesta>\n");
		logger.info("=====================Detalle liquidacion==================");
		logger.info(respuesta.toString());
		logger.info("=====================Fin Detalle liquidacion==================");
		return respuesta.toString();
	}

	public static String xmlPagoDet(Liquidacion liquidacion, LiquidacionDet liquidacionDet, BigDecimal tcVenta) {
		StringBuilder sb = new StringBuilder();
		
		sb.append("<pago>\n");
		sb.append("<codigoDetalle>").append(liquidacionDet.getLiquidacionDetPK().getLiqDetalle()).append("</codigoDetalle>\n");
		sb.append("<moneda>").append(liquidacionDet.getMonSigade()).append("</moneda>\n");
		sb.append("<capitalMO>").append(liquidacionDet.getCapitalMo().setScale(2, BigDecimal.ROUND_HALF_UP)).append("</capitalMO>\n");
		sb.append("<interesesMO>").append(liquidacionDet.getInteresMo().setScale(2, BigDecimal.ROUND_HALF_UP)).append("</interesesMO>\n");
		sb.append("<comisionesMO>").append(liquidacionDet.getComisionMo().setScale(2, BigDecimal.ROUND_HALF_UP)).append("</comisionesMO>\n");
		sb.append("<tipoCambio>").append(liquidacionDet.getTipoCambio()).append("</tipoCambio>\n");
		sb.append("<fechaTipoCambio>").append(UtilsDate.stringFromDate(liquidacion.getFechaTc(), "yyyyMMdd")).append("</fechaTipoCambio>\n");

		// se multiplica el tipo de cambio por el monto origen
		BigDecimal capitalUSD = liquidacionDet.getTipoCambio().multiply(liquidacionDet.getCapitalMo().setScale(2, BigDecimal.ROUND_HALF_UP))
				.setScale(2, BigDecimal.ROUND_HALF_UP);
		BigDecimal interesesUSD = liquidacionDet.getTipoCambio().multiply(liquidacionDet.getInteresMo().setScale(2, BigDecimal.ROUND_HALF_UP))
				.setScale(2, BigDecimal.ROUND_HALF_UP);
		BigDecimal comisionesUSD = liquidacionDet.getTipoCambio().multiply(liquidacionDet.getComisionMo().setScale(2, BigDecimal.ROUND_HALF_UP))
				.setScale(2, BigDecimal.ROUND_HALF_UP);
		
		sb.append("<capitalUSD>").append(capitalUSD).append("</capitalUSD>\n");
		sb.append("<interesesUSD>").append(interesesUSD).append("</interesesUSD>\n");
		sb.append("<comisionesUSD>").append(comisionesUSD).append("</comisionesUSD>\n");

		sb.append("<capitalBS>").append(capitalUSD.multiply(tcVenta).setScale(2, BigDecimal.ROUND_HALF_UP)).append("</capitalBS>\n");
		sb.append("<interesesBS>").append(interesesUSD.multiply(tcVenta).setScale(2, BigDecimal.ROUND_HALF_UP)).append("</interesesBS>\n");
		sb.append("<comisionesBS>").append(comisionesUSD.multiply(tcVenta).setScale(2, BigDecimal.ROUND_HALF_UP)).append("</comisionesBS>\n");
		sb.append("</pago>\n");

		return sb.toString();
	}

	public static String xmlPagoDet2(Vencimiento vencimiento, LiquidacionDet liquidacionDetMO, LiquidacionDet liquidacionDetSUS,
			LiquidacionDet liquidacionDetBS, BigDecimal tcVenta) {
		StringBuilder sb = new StringBuilder();
		sb.append("<pago>\n");
		sb.append("<codigoDetalle>").append(liquidacionDetMO.getLiquidacionDetPK().getLiqDetalle()).append("</codigoDetalle>\n");
		sb.append("<moneda>").append(liquidacionDetMO.getMonSigade()).append("</moneda>\n");
		sb.append("<capitalMO>").append(liquidacionDetMO.getCapitalMo().setScale(2, BigDecimal.ROUND_HALF_UP)).append("</capitalMO>\n");
		sb.append("<interesesMO>").append(liquidacionDetMO.getInteresMo().setScale(2, BigDecimal.ROUND_HALF_UP)).append("</interesesMO>\n");
		sb.append("<comisionesMO>").append(liquidacionDetMO.getComisionMo().setScale(2, BigDecimal.ROUND_HALF_UP)).append("</comisionesMO>\n");

		sb.append("<tipoCambio>").append(liquidacionDetMO.getTipoCambio()).append("</tipoCambio>\n");
		sb.append("<fechaTipoCambio>").append(UtilsDate.stringFromDate(vencimiento.getFechaTc(), "yyyyMMdd")).append("</fechaTipoCambio>\n");

		sb.append("<capitalUSD>").append(liquidacionDetSUS.getCapitalMo()).append("</capitalUSD>\n");
		sb.append("<interesesUSD>").append(liquidacionDetSUS.getInteresMo()).append("</interesesUSD>\n");
		sb.append("<comisionesUSD>").append(liquidacionDetSUS.getComisionMo()).append("</comisionesUSD>\n");

		sb.append("<capitalBS>").append(liquidacionDetBS.getCapitalMo()).append("</capitalBS>\n");
		sb.append("<interesesBS>").append(liquidacionDetBS.getInteresMo()).append("</interesesBS>\n");
		sb.append("<comisionesBS>").append(liquidacionDetBS.getComisionMo()).append("</comisionesBS>\n");
		sb.append("</pago>\n");

		return sb.toString();
	}

	public static void main(String[] args) {
		LiquidacionDetalle liquidacionDetalle = new LiquidacionDetalle();
		liquidacionDetalle.setCodigo("asdf");
		liquidacionDetalle.setMoneda("UDS");
		liquidacionDetalle.setCapital(BigDecimal.valueOf(23.3));
		try {
			JAXBContext context = JAXBContext.newInstance(LiquidacionDetalle.class);
			Marshaller m = context.createMarshaller();
			m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			m.marshal(liquidacionDetalle, System.out);
		} catch (JAXBException jex) {
			System.out.println("JAXB Binding Exception");
			jex.printStackTrace();
		}

		BigDecimal a = new BigDecimal("-78948.035555");
		a = a.setScale(2, BigDecimal.ROUND_HALF_UP);
		BigDecimal b = new BigDecimal("-78948.04");
		System.out.println(a + " : " + b + " :" + b.divide(a).setScale(2, BigDecimal.ROUND_HALF_UP));
		if (a.compareTo(b.setScale(2)) == 0) {
			System.out.println("== " + a + " : " + b);
		} else {
			System.out.println("<> " + a + " : " + b);
		}

	}
}
