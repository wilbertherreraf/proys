package gob.bcb.jee.siodex.service;

import gob.bcb.jee.siodex.QL.*;
import gob.bcb.jee.siodex.entities.*;
import gob.bcb.jee.siodex.exception.DataException;
import org.apache.commons.lang.ArrayUtils;
import org.apache.log4j.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.List;

/**
 * Clase que contiene los metodos para crear los campos de un mensaje swift.
 *
 * @author C. Cecilia Uriona
 *
 */
@Stateless
public class DeudaBean implements DeudaBeanLocal {

	static final Logger logger = Logger.getLogger(DeudaBean.class);

	@PersistenceContext(unitName = "siodex")
	EntityManager em;

	@Inject
	private CoinQLBeanLocal coinQLBeanLocal;

	@Inject
	private DAQLBeanLocal dAQLBeanLocal;

	@Inject
	private DA3QLBeanLocal dA3QLBeanLocal;

	@Inject
	private LiquidacionQLBeanLocal liqQLBeanLocal;

	@Inject
	private LiquidacionDetQLBeanLocal liqDetQLBeanLocal;

	@Inject
	private TmpDeudaQLBeanLocal tmpDeudaQLBeanLocal;

	public static final String P_TIPO_OPERACION_INTERES = "21";
	public static final String P_TIPO_OPERACION_CAPITAL = "11";
	public static final String P_TIPO_OPERACION_COMISION = "31";


	private Integer continuar = 1;

	private TmpOperacionDeuda deuda = null;
	private Liquidacion liq = null;
	private List<LiquidacionDet> listaDet = null;

	public Integer registrar(Vencimiento vencimiento, String cod) throws DataException {

		logger.info("Creando el registro para el SIGADE: " + cod);

		String deuCodigo = "";
		String temp = "";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		BigDecimal tcE = coinQLBeanLocal.getTC(vencimiento.getFechaTc(), "53");
		BigDecimal tcD = coinQLBeanLocal.getTC(vencimiento.getFechaTc(), "50");

		liq = liqQLBeanLocal.getLiquidacion(cod);
		listaDet = vencimiento.getLiquidacionDetLista();
		temp = "S0" + (Integer.valueOf(cod)).toString();
		List<TmpOperacionDeuda> tmpOperacionDeudas = tmpDeudaQLBeanLocal.listaDeuda(temp);

		if (listaDet.size() > 0) {
			for (LiquidacionDet ll : listaDet) {
				if (ll.getMonSigade().equals("USD")) {
					if (ll.getCapitalMo().compareTo(BigDecimal.valueOf(0)) > 0) {
						// Verificamos si existe registrado para la liquidacion una deuda
						//Armamos el objeto de busqueda
						TmpOperacionDeuda operacionBusqueda = new TmpOperacionDeuda(new TmpOperacionDeudaPK("", temp));
						operacionBusqueda.setLoNo(ll.getPinPrestamo());
						operacionBusqueda.setTraNo(ll.getPinTramo());
						operacionBusqueda.setDCredVal(vencimiento.getFechaTc());
						operacionBusqueda.setCdTrnsTyp(P_TIPO_OPERACION_CAPITAL);
						TmpOperacionDeuda tmpOperacionEncontrada = obtenerObjetoTmpOperacionDeuda(tmpOperacionDeudas, operacionBusqueda, ll.getCapitalMo());

						if (tmpOperacionEncontrada == null) {
							deuCodigo = tmpDeudaQLBeanLocal.getCodigo();
							deuda = new TmpOperacionDeuda(new TmpOperacionDeudaPK(deuCodigo, temp));
						} else {
							deuda = tmpOperacionEncontrada;
						}
						deuCodigo = tmpDeudaQLBeanLocal.getCodigo();
						temp = "S0" + (Integer.valueOf(cod)).toString();
//						deuda = new TmpOperacionDeuda(new TmpOperacionDeudaPK(deuCodigo, temp));
						deuda.setLoNo(ll.getPinPrestamo());
						deuda.setTraNo(ll.getPinTramo());
						deuda.setDCredVal(vencimiento.getFechaTc());
						deuda.setCgTrnsTyp((short) 75);
						deuda.setCdTrnsTyp(P_TIPO_OPERACION_CAPITAL);
						deuda.setDSch(liq.getFechaVenc());
						deuda.setDDbrVal(vencimiento.getFechaTc());
						deuda.setCuEff(ll.getMonSigade());
						deuda.setAmtCuEff(ll.getCapitalMo());

						deuda.setAmtCuLocal(ll.getCapitalMo().multiply(vencimiento.getTipoCambioCont()).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP));
						deuda.setAmtCuBase(ll.getCapitalMo());
						// Obtiene la fecha programada del prestamo del sistema SIGADE.
						Object[] da = this.InteresesDms1(ll.getPinPrestamo(), ll.getPinTramo(), sdf.format(liq.getFechaVenc()), P_TIPO_OPERACION_CAPITAL);
						if (da != null) {
							BigDecimal amSch = (BigDecimal) da[1];
							deuda.setAmtSch(amSch);

							BigDecimal sid = (BigDecimal) da[0];
							Integer sdspId = sid.intValue();
							deuda.setSdspId(sdspId);
						} else {
							deuda.setAmtSch(BigDecimal.valueOf(0));
						}

						deuda.setAmtCuSdr(deuda.getAmtCuLocal().divide(tcD, 2, RoundingMode.HALF_UP));
						deuda.setAmtCuUsd(ll.getCapitalMo());
						deuda.setDLocalExchRte(vencimiento.getFechaTc());
						deuda.setCgMedium((short) 25);
						deuda.setCdMedium("1");

						deuda.setAmtCuEur(deuda.getAmtCuLocal().divide(tcE, 2, RoundingMode.HALF_UP));
						deuda.setAmtCuLo(ll.getCapitalMo());
						deuda.setDetCodigo("01");
						deuda.setAmtCuEffO(deuda.getAmtCuEff());
						deuda.setAmtCuLocalO(deuda.getAmtCuLocal());
						deuda.setAmtCuUsdO(deuda.getAmtCuUsd());
						logger.info("registro TmpOperacionDeuda creando: " + deuda.toString());
						// Inserta o Modifica liquidacion en tabla "TmpOperacionDeuda".
						if (tmpOperacionEncontrada == null) {
							tmpDeudaQLBeanLocal.create(deuda);
						} else {
							tmpDeudaQLBeanLocal.edit(deuda);
						}

						logger.info("Registrando capital para la liquidación: " + cod);
					}

					if (ll.getInteresMo().compareTo(BigDecimal.valueOf(0)) > 0) {
						temp = "S0" + (Integer.valueOf(cod)).toString();
						TmpOperacionDeuda operacionBusqueda = new TmpOperacionDeuda(new TmpOperacionDeudaPK("", temp));
						operacionBusqueda.setLoNo(ll.getPinPrestamo());
						operacionBusqueda.setTraNo(ll.getPinTramo());
						operacionBusqueda.setDCredVal(vencimiento.getFechaTc());
						operacionBusqueda.setCdTrnsTyp(P_TIPO_OPERACION_INTERES);
						TmpOperacionDeuda tmpOperacionEncontrada = obtenerObjetoTmpOperacionDeuda(tmpOperacionDeudas, operacionBusqueda, ll.getInteresMo());
						if (tmpOperacionEncontrada == null) {
							deuCodigo = tmpDeudaQLBeanLocal.getCodigo();
							deuda = new TmpOperacionDeuda(new TmpOperacionDeudaPK(deuCodigo, temp));
						} else {
							deuda = tmpOperacionEncontrada;
						}
						deuda.setLoNo(ll.getPinPrestamo());
						deuda.setTraNo(ll.getPinTramo());
						deuda.setDCredVal(vencimiento.getFechaTc());
						deuda.setCgTrnsTyp((short) 75);
						deuda.setCdTrnsTyp(P_TIPO_OPERACION_INTERES);
						deuda.setDSch(liq.getFechaVenc());
						deuda.setDDbrVal(vencimiento.getFechaTc());
						deuda.setCuEff(ll.getMonSigade());
						deuda.setAmtCuEff(ll.getInteresMo());
						deuda.setAmtCuLocal(ll.getInteresMo().multiply(vencimiento.getTipoCambioCont()).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP));
						deuda.setAmtCuBase(ll.getInteresMo());
						// Obtiene la fecha programada del prestamo del sistema SIGADE.
						Object[] da = this.InteresesDms1(ll.getPinPrestamo(), ll.getPinTramo(), sdf.format(liq.getFechaVenc()), P_TIPO_OPERACION_INTERES);
						if (da != null) {
							BigDecimal amSch = (BigDecimal) da[1];
							deuda.setAmtSch(amSch);

							BigDecimal sid = (BigDecimal) da[0];
							Integer sdspId = sid.intValue();
							deuda.setSdspId(sdspId);
						} else {
							deuda.setAmtSch(BigDecimal.valueOf(0));
						}

						deuda.setAmtCuSdr(deuda.getAmtCuLocal().divide(tcD, 2, RoundingMode.HALF_UP));
						deuda.setAmtCuUsd(ll.getInteresMo());
						deuda.setDLocalExchRte(vencimiento.getFechaTc());
						deuda.setCgMedium((short) 25);
						deuda.setCdMedium("1");

						deuda.setAmtCuEur(deuda.getAmtCuLocal().divide(tcE, 2, RoundingMode.HALF_UP));
						deuda.setAmtCuLo(ll.getInteresMo());
						deuda.setDetCodigo("01");
						deuda.setAmtCuEffO(deuda.getAmtCuEff());
						deuda.setAmtCuLocalO(deuda.getAmtCuLocal());
						deuda.setAmtCuUsdO(deuda.getAmtCuUsd());
						logger.info("registro TmpOperacionDeuda creando: " + deuda.toString());
						// Inserta o modifica liquidacion en tabla "TmpOperacionDeuda".
						if (tmpOperacionEncontrada == null) {
							tmpDeudaQLBeanLocal.create(deuda);
						} else {
							tmpDeudaQLBeanLocal.edit(deuda);
						}

						logger.info("Registrando interes para la liquidación: " + cod);
					}
					// COMPLETAR COMISIONES cambiar consulta
					if (ll.getComisionMo().compareTo(BigDecimal.valueOf(0)) > 0) {
						temp = "S0" + (Integer.valueOf(cod)).toString();
						TmpOperacionDeuda operacionBusqueda = new TmpOperacionDeuda(new TmpOperacionDeudaPK("", temp));
						operacionBusqueda.setLoNo(ll.getPinPrestamo());
						operacionBusqueda.setTraNo(ll.getPinTramo());
						operacionBusqueda.setDCredVal(vencimiento.getFechaTc());
						operacionBusqueda.setCdTrnsTyp(P_TIPO_OPERACION_COMISION);
						TmpOperacionDeuda tmpOperacionEncontrada = obtenerObjetoTmpOperacionDeuda(tmpOperacionDeudas, operacionBusqueda, ll.getCapitalMo());
						if (tmpOperacionEncontrada == null) {
							deuCodigo = tmpDeudaQLBeanLocal.getCodigo();
							deuda = new TmpOperacionDeuda(new TmpOperacionDeudaPK(deuCodigo, temp));
						} else {
							deuda = tmpOperacionEncontrada;
						}

						deuda.setLoNo(ll.getPinPrestamo());
						deuda.setTraNo(ll.getPinTramo());
						deuda.setDCredVal(vencimiento.getFechaTc());
						deuda.setCgTrnsTyp((short) 75);
						deuda.setCdTrnsTyp(P_TIPO_OPERACION_COMISION);
						deuda.setCgFeeTyp((short) 11);
						deuda.setCdFeeTyp("10");
						deuda.setDSch(liq.getFechaVenc());
						deuda.setDDbrVal(vencimiento.getFechaTc());
						deuda.setCuEff(ll.getMonSigade());
						deuda.setAmtCuEff(ll.getComisionMo());
						deuda.setAmtCuLocal(ll.getComisionMo().multiply(vencimiento.getTipoCambioCont()).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP));
						deuda.setAmtCuBase(ll.getCapitalMo());
						// Obtiene la fecha programada del prestamo del sistema SIGADE.
						Object[] da = this.ComisionesDms1(ll.getPinPrestamo(), ll.getPinTramo(), sdf.format(liq.getFechaVenc()), P_TIPO_OPERACION_COMISION);
						if (da != null) {
							BigDecimal amSch = (BigDecimal) da[1];
							deuda.setAmtSch(amSch);

							BigDecimal sid = (BigDecimal) da[0];
							Integer sdspId = sid.intValue();
							deuda.setSdspId(sdspId);
						} else {
							deuda.setAmtSch(BigDecimal.valueOf(0));
						}

						deuda.setAmtCuSdr(deuda.getAmtCuLocal().divide(tcD, 2, RoundingMode.HALF_UP));
						deuda.setAmtCuUsd(ll.getCapitalMo());
						deuda.setDLocalExchRte(vencimiento.getFechaTc());
						deuda.setCgMedium((short) 25);
						deuda.setCdMedium("1");

						deuda.setAmtCuEur(deuda.getAmtCuLocal().divide(tcE, 2, RoundingMode.HALF_UP));
						deuda.setAmtCuLo(ll.getCapitalMo());
						deuda.setDetCodigo("01");
						deuda.setAmtCuEffO(deuda.getAmtCuEff());
						deuda.setAmtCuLocalO(deuda.getAmtCuLocal());
						deuda.setAmtCuUsdO(deuda.getAmtCuUsd());
						logger.info("registro TmpOperacionDeuda creando: " + deuda.toString());
						// Inserta o modifica liquidación en tabla "TmpOperacionDeuda".
						if (tmpOperacionEncontrada == null) {
							tmpDeudaQLBeanLocal.create(deuda);
						} else {
							tmpDeudaQLBeanLocal.edit(deuda);
						}

						logger.info("Registrando comision para la liquidación: " + cod);
					}
				}
				logger.info("registro tmpDeudaQLBeanLocal creado: " + cod);
			}
		}

		return continuar;
	}

	public TmpOperacionDeuda obtenerObjetoTmpOperacionDeuda(List<TmpOperacionDeuda> tmpOperacionDeudas, TmpOperacionDeuda objetoBusqueda, BigDecimal capitalMo){
		TmpOperacionDeuda resultado = null;
		int contador = 0;
		for (TmpOperacionDeuda tmpOperacionDeuda : tmpOperacionDeudas) {
			if(tmpOperacionDeuda.getTmpOperacionDeudaPK().getOpeCodigo().equalsIgnoreCase(objetoBusqueda.getTmpOperacionDeudaPK().getOpeCodigo())){
				if(tmpOperacionDeuda.getLoNo().equalsIgnoreCase(objetoBusqueda.getLoNo()) && tmpOperacionDeuda.getTraNo() == objetoBusqueda.getTraNo()
						&& tmpOperacionDeuda.getDCredVal().equals(objetoBusqueda.getDCredVal()) && tmpOperacionDeuda.getCdTrnsTyp().equalsIgnoreCase(objetoBusqueda.getCdTrnsTyp())){
					// Obtenemos el objeto
					return tmpOperacionDeudas.get(contador);
				} else{
					contador ++;
				}
			} else {
				contador ++;
			}
		}
		return resultado;
	}


	/**
	 * Método que obtiene la fecha programada a pagar la liquidación del sistema SIGADE.
	 * @pIdPrestamo Identificador de prestamo (LO_NO).
	 * @pTramo Tramo de prestamo
	 * @pFecha Fecha de liquidación.
	 * @pTipoOperacion Tipo de operación (Capital/Interes).
	 */
	public Object[] InteresesDms1(String pIdPrestamo, int pTramo, String pFecha, String pTipoOperacion) {

		String tipoOperacion = pTipoOperacion.equalsIgnoreCase("11")? "Capital": "Interes";
		logger.info("Obteniendo datos de dms1 para vereificar si existen pagos programados con el presetamo: " + pIdPrestamo + " y con el tipo de operacion: " + tipoOperacion);
		// Instancia entidad de tipo "Object".
		Object[] vListaSchDebtServPmts = null;
		// Instacia formato de fecha
//		SimpleDateFormat vFormatoFecha = new SimpleDateFormat("dd/MM/yyyy");
//		// Instancia objeto de tipo "StringBuilder".
//		StringBuilder vQuery = new StringBuilder();
//		// Almacena y arma la consulta.
//		vQuery.append(" select min(d_sch) ");
//		vQuery.append(" from dmfas.sch_debt_serv_pmts ");
//		vQuery.append(" where amt > 0 ");
//		vQuery.append(" and amt_unpaid > 0 ");
//		vQuery.append(" and lo_no = '" + pIdPrestamo + "'");
//		vQuery.append(" and tra_no = " + pTramo );

		// Obtiene fecha programada del pretamo SIGADE.
//		Object vObjFechaSigade = dAQLBeanLocal.obtieneValorConsulta(vQuery.toString());

		// Verifica que contenga la fecha.
//		if(vObjFechaSigade != null){

			// Convierte fecha programada.
//			Date createDate = (Date)vObjFechaSigade;
			// Instancia objeto de tipo "StringBuilder".
			StringBuilder query = new StringBuilder();
			// Almacena y arma la consulta.
			query.append(" SELECT ");
			query.append(" s.sdsp_id, s.amt_unpaid, l.tranche_currency ");
			query.append(" FROM dmfas.sch_debt_serv_pmts s, dmfas.loan_tranche_summary l ");
			query.append(" WHERE s.lo_no = l.loan_id ");
			query.append(" AND s.tra_no = l.tranche_no ");
			query.append(" AND s.lo_no = '" + pIdPrestamo + "'");
			query.append(" AND s.tra_no = " + pTramo);
			query.append(" AND d_sch = (SELECT MIN(sd.D_SCH) FROM DMFAS.SCH_DEBT_SERV_PMTS sd WHERE sd.AMT > 0 ");
			query.append(" AND sd.AMT_UNPAID > 0 AND sd.LO_NO = '").append(pIdPrestamo).append("' AND sd.TRA_NO = ").append(pTramo).append(")");
			query.append(" AND cd_trns_typ = '" + pTipoOperacion + "'");

			// Obtiene registro de prestamo programado de SIGADE.
			vListaSchDebtServPmts = dAQLBeanLocal.nativo(query.toString());
			// Almacena la fecha programada por el sistema SIGADE.
			//deuda.setDSch(createDate);
			// Escribe en el log del sistema.
			logger.info("dmfas.sch_debt_serv_pmts: " + (vListaSchDebtServPmts == null ? "NULL" : ArrayUtils.toString(vListaSchDebtServPmts)));
//		}
		// Retorna registro de "SCH_DEBT_SERV_PMTS".
		return vListaSchDebtServPmts;
	}

	public Object[] InteresesDms3(String prestamo, int tramo, String fecha, String tipo) {

		Object[] datosA = null;

		StringBuilder query = new StringBuilder();
		query.append("");
		query.append(" SELECT ");
		query.append(" s.sdsp_id, s.amt_unpaid, l.tranche_currency ");
		query.append(" FROM dmfas.sch_debt_serv_pmts s, dmfas.loan_tranche_summary l ");
		query.append(" WHERE s.lo_no = l.loan_id ");
		query.append(" and s.tra_no = l.tranche_no ");
		query.append(" and s.lo_no = '" + prestamo + "'");
		query.append(" and s.tra_no = " + tramo);
		query.append(" and d_sch = to_date('" + fecha + "', 'yyyy-mm-dd')");
		query.append(" and cd_trns_typ = '" + tipo + "'");

		datosA = dA3QLBeanLocal.nativo(query.toString());

		logger.info("dmfas.sch_debt_serv_pmts: " + (datosA == null ? "NULL" : ArrayUtils.toString(datosA)));

		return datosA;
	}

	public Object[] ComisionesDms1(String prestamo, int tramo, String fecha, String tipo) {

		Object[] datosA = null;

		StringBuilder query = new StringBuilder();
		query.append("");
		query.append(" SELECT ");
		query.append(" s.scp_id, s.amt_unpaid, l.tranche_currency ");
		query.append(" FROM dmfas.sch_com_pmts s, dmfas.loan_tranche_summary l ");
		query.append(" WHERE s.lo_no = l.loan_id ");
		query.append(" and s.lo_no = '" + prestamo + "'");
		// Debemos agregar el tramo para las comisiones
		query.append(" and l.tranche_no = '" + tramo + "'");
		query.append(" and s.amt_unpaid > 0");
		query.append(" and d_sch = to_date('" + fecha + "', 'yyyy-mm-dd')");
		query.append(" and cd_trns_typ = '" + tipo + "'");

		datosA = dAQLBeanLocal.nativo(query.toString());

		logger.info("dmfas.sch_com_pmts: " + (datosA == null ? "NULL" : ArrayUtils.toString(datosA)));

		return datosA;
	}

	public Object[] ComisionesDms3(String prestamo, int tramo, String fecha, String tipo) {

		Object[] datosA = null;

		StringBuilder query = new StringBuilder();
		query.append("");
		query.append(" SELECT ");
		query.append(" scp_id, amt_unpaid ");
		query.append(" FROM dmfas.sch_com_pmts ");
		query.append(" WHERE lo_no = '" + prestamo + "'");
		query.append(" and d_sch = to_date('" + fecha + "', 'yyyy-mm-dd')");
		query.append(" and cd_trns_typ = '" + tipo + "'");

		datosA = dA3QLBeanLocal.nativo(query.toString());

		logger.info("dmfas.sch_com_pmts: " + (datosA == null ? "NULL" : ArrayUtils.toString(datosA)));

		return datosA;
	}


}
