package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.Loader;
import gob.bcb.jee.siodex.exception.DataException;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

@Stateless
@LocalBean
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class LoaderQLBean extends DaoGeneric<Loader> implements LoaderQLBeanLocal {

	static final Logger logger = Logger.getLogger(LoaderQLBean.class);

	@PersistenceContext(unitName = "portia")
	EntityManager em;

	/**
	 * Default constructor.
	 */
	public LoaderQLBean() {
		// TODO Auto-generated constructor stub
		super(Loader.class);
		logger.info("LoaderQLBean CREADO");
	}
	public Integer getCodigo() throws DataException {
		Loader loader = maxLoader();
		if (loader == null){
			logger.error("No se pudo recuperar nro swift");
			throw new DataException("No se pudo recuperar nro swift");
		}
 
		Integer codigo = loader.getIdLoader() + 1;
		logger.info("IdLoader : " + codigo);		
		return codigo;

	}
	public Loader maxLoader() {

		StringBuilder query = new StringBuilder();
		
	    query = query.append(" select re ");
	    query = query.append(" from Loader re ");
	    query = query.append(" where re.idLoader = (select max(r1.idLoader) from Loader r1) ");

		Query consulta = em.createQuery(query.toString());
		List lista =  consulta.getResultList();
		if (lista.size() > 0){
			return (Loader) lista.get(0); 
		}


		return null;		
	}
	
	public Integer maxNroSwift() {

			StringBuilder jsql = new StringBuilder();
			jsql.append("select max(l.numeroSwift) from Loader l");

			Query query = em.createQuery(jsql.toString());

			List result = query.getResultList();
			if (result.size() > 0) {
				Integer maximo = (Integer) result.get(0);
				maximo++;
				return (maximo == null ? Integer.valueOf(1) : maximo);
			}

			return Integer.valueOf(0);
	}	
	
	@Override
	public void setEntityManager(EntityManager entityManager) {
		// TODO Auto-generated method stub

	}

	@Override
	public EntityManager getEntityManager() {
		// TODO Auto-generated method stub
		return em;
	}

}
