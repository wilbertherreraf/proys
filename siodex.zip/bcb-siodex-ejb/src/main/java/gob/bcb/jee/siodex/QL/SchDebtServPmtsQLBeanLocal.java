package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.SchDebtServPmts;

import javax.ejb.Local;

@Local
public interface SchDebtServPmtsQLBeanLocal {

	/**
	 * 
	 * @return
	 */
	void edit(SchDebtServPmts dso);
	void create(SchDebtServPmts dso);
	public SchDebtServPmts getDso(Integer codigo);
	
}
