/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author CUriona
 */
@Embeddable
public class LiquidacionEstadoPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "liq_codigo", nullable = false)
    private String liqCodigo;
    @Basic(optional = false)
    @NotNull
    @Column(name = "cve_estado", nullable = false)
    private String cveEstado;

    public LiquidacionEstadoPK() {
    }

    public LiquidacionEstadoPK(String liqCodigo, String cveEstado) {
        this.liqCodigo = liqCodigo;
        this.cveEstado = cveEstado;
    }

    public String getLiqCodigo() {
        return liqCodigo;
    }

    public void setLiqCodigo(String liqCodigo) {
        this.liqCodigo = liqCodigo;
    }

    public String getCveEstado() {
        return cveEstado;
    }

    public void setCveEstado(String cveEstado) {
        this.cveEstado = cveEstado;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (liqCodigo != null ? liqCodigo.hashCode() : 0);
        hash += (cveEstado != null ? cveEstado.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof LiquidacionEstadoPK)) {
            return false;
        }
        LiquidacionEstadoPK other = (LiquidacionEstadoPK) object;
        if ((this.liqCodigo == null && other.liqCodigo != null) || (this.liqCodigo != null && !this.liqCodigo.equals(other.liqCodigo))) {
            return false;
        }
        if ((this.cveEstado == null && other.cveEstado != null) || (this.cveEstado != null && !this.cveEstado.equals(other.cveEstado))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gob.bcb.siodex.entities.LiquidacionEstadoPK[ liqCodigo=" + liqCodigo + ", cveEstado=" + cveEstado + " ]";
    }
    
}
