package gob.bcb.jee.siodex.QL;

import java.math.BigDecimal;
import java.util.List;

import gob.bcb.jee.siodex.entities.LogAuditoria;
import gob.bcb.jee.siodex.entities.SolDato;
import gob.bcb.jee.siodex.entities.Solicitud;
import gob.bcb.jee.siodex.exception.DataException;

import javax.ejb.Local;

@Local
public interface SolDatoQLBeanLocal {

	/**
	 * 
	 * @return
	 */
	void edit(SolDato solDato);
	void create(SolDato solDato);
	void remove(SolDato solDato);
	public List<SolDato> getDatos(Integer codigo);
	public SolDato getSolDato(Integer codigo, String codDato);
	SolDato actualiza(Integer codSol, String codDato, BigDecimal monto, LogAuditoria logAudit) throws DataException;
	String codigoDatoForCodLip(String codLip, String tipoDeuCom);
	SolDato actualizaCuentaMov(Solicitud soli, SolDato solDato);
	void eliminarDatosSolicitud(Integer codigo) throws DataException;
	
}
