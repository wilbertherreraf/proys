package gob.bcb.jee.siodex.QL;

import java.util.List;

import gob.bcb.jee.siodex.entities.TmpOperacionDeuda;

import javax.ejb.Local;

@Local
public interface TmpDeudaQLBeanLocal {

	/**
	 * 
	 * @return
	 */
	void edit(TmpOperacionDeuda deuda);
	void create(TmpOperacionDeuda deuda);
	public List<TmpOperacionDeuda> listaDeuda(String codigo);
	public TmpOperacionDeuda getDeuda(String codigo);
	public String getCodigo();
	
}
