package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.LogAuditoria;
import gob.bcb.jee.siodex.entities.Solicitud;
import gob.bcb.jee.siodex.exception.DataException;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.ejb.EJBException;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TemporalType;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

@Stateless
@LocalBean
public class SolicitudQLBean extends DaoGeneric<Solicitud> implements SolicitudQLBeanLocal {

	static final Logger logger = Logger.getLogger(SolicitudQLBean.class);

	@PersistenceContext(unitName = "siodex")
	EntityManager em;

	/**
	 * Default constructor.
	 */
	public SolicitudQLBean() {
		// TODO Auto-generated constructor stub
		super(Solicitud.class);
	}

	@SuppressWarnings("unchecked")
	public List<Solicitud> listaSolicitud(String estado, String codPart, Date fecha) {
		logger.info("XXX: en listaSolicitud " + estado + " codPart: " + codPart + " fecha:" + fecha);
		List<Solicitud> lista = new ArrayList<Solicitud>();

		StringBuilder query = new StringBuilder();
		query.append("select s from Solicitud s where s.cveEstado = :estado ");

		if (codPart != null) {
			query.append("and s.codPart = :codPart ");
		}

		if (fecha != null) {
			query.append("and s.fecha = :fecha ");
		}

		query.append("order by s.fecha ");

		logger.info("Lista solicitud para [" + estado + "," + codPart + "," + fecha + "]" + query.toString());
		Query consulta = em.createQuery(query.toString());
		consulta.setParameter("estado", estado);

		if (codPart != null) {
			consulta.setParameter("codPart", codPart);
		}

		if (fecha != null) {
			consulta.setParameter("fecha", fecha, TemporalType.DATE);
		}

		lista = consulta.getResultList();

		return lista;

	}

	@SuppressWarnings("unchecked")
	public List<Solicitud> listaSolicitudPendiente() {

		List<Solicitud> lista = new ArrayList<Solicitud>();
		StringBuilder query = new StringBuilder();

		query.append("select s from Solicitud s where s.cveEstado = 'P'");

		Query consulta = em.createQuery(query.toString());

		lista = consulta.getResultList();

		return lista;

	}

	public Solicitud getSolicitud(Integer codigo) {

		Solicitud solicitud = null;

		StringBuilder query = new StringBuilder();

		query.append("select s from Solicitud s where s.solCodigo = ?");

		logger.info("getSolicitud para [" + codigo + "]" + query.toString());

		Query consulta = em.createQuery(query.toString());
		consulta.setParameter(1, codigo);

		List lista = consulta.getResultList();

		if (lista.size() > 0) {
			return (Solicitud) lista.get(0);
		}
		return solicitud;

	}

	public Solicitud getSolicitudByCodLiq(String codLiquidacion, String estado) throws DataException {
		List<Solicitud> lista = getSolicitudesByCodLiq(codLiquidacion, estado);
		if (lista.size() > 0) {
			return lista.get(0);
		}
		return null;

	}

	public List<Solicitud> getSolicitudesByCodLiq(String codLiquidacion, String estado) throws DataException {

		List<Solicitud> lista = new ArrayList<Solicitud>();

		StringBuilder query = new StringBuilder();

		query.append("select s from Solicitud s where s.liqCodigo = :liqCodigo and s.cveEstado != 'Z' ");

		if (estado != null) {
			query.append("and s.cveEstado = :cveEstado ");
		}

		logger.info("getSolicitud para [" + codLiquidacion + " " + estado + "]" + query.toString());

		Query consulta = em.createQuery(query.toString());
		consulta.setParameter("liqCodigo", codLiquidacion);

		if (estado != null) {
			consulta.setParameter("cveEstado", estado);
		}

		lista = consulta.getResultList();
		if (lista.size() > 1) {
			throw new DataException("Liquidacion " + codLiquidacion + " con mas de una solicitud registradas, comunique al administrador");
		}

		return lista;

	}

	public Integer getCodigo() {

		Integer codigo = 0;
		StringBuilder query = new StringBuilder();

		query.append("select max(s.solCodigo) from Solicitud s");

		Query consulta = em.createQuery(query.toString());

		codigo = (Integer) consulta.getSingleResult();

		return codigo;

	}

	public Integer maxCodigoNuevo() {
		Integer solCodigo = getCodigo();
		if (solCodigo == null) {
			solCodigo = 0;
		}
		solCodigo++;
		return solCodigo;
	}

	public Solicitud cambioEstado(Solicitud solicitud, String observacion, String nuevoEstado) {
		logger.info("Ingresando a Cambio de estado Solicitud " + solicitud.toString() + " nuevo: " + nuevoEstado);
		solicitud.setFechaHora(new Date());
		solicitud.setCveEstado(nuevoEstado);
		edit(solicitud);

		Solicitud solicitudNew = getSolicitud(solicitud.getSolCodigo());
		logger.info("cambio de esta Solicitud " + solicitud.toString() + " exitoso a : " + nuevoEstado);
		return solicitudNew;
	}

	@Override
	public void setEntityManager(EntityManager entityManager) {
		// TODO Auto-generated method stub

	}

	@Override
	public EntityManager getEntityManager() {
		// TODO Auto-generated method stub
		return em;
	}

}
