/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.mefp;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.ejb.Timeout;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author CUriona
 */
@Entity
@Table(name = "liquidacion_cuentas")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "LiquidacionCuentas.findAll", query = "SELECT l FROM LiquidacionCuentas l")})
public class LiquidacionCuentas implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected LiquidacionCuentasPK liquidacionCuentasPK;
    @Basic(optional = false)
    @NotNull
    @Column(name = "log_auditoria_id")
    private int logAuditoriaId;
    @Column(name = "valor")
    private String valor;
    @Column(name = "valor_adic")
    private String valorAdic;

    @Column(name = "usuario")
    private String usuario;
    
    @Column(name = "fecha_hora")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaHora;
    
    public LiquidacionCuentas() {
    	
    }

    public LiquidacionCuentas(LiquidacionCuentasPK liquidacionCuentasPK) {
        this.liquidacionCuentasPK = liquidacionCuentasPK;
    }

    public LiquidacionCuentas(LiquidacionCuentasPK liquidacionCuentasPK, Integer logAuditoriaId, 
    		String valor) {
        this.liquidacionCuentasPK = liquidacionCuentasPK;
        this.logAuditoriaId = logAuditoriaId;
        this.valor = valor;
    }

    public LiquidacionCuentas(String liqCodigo, String cveCuenta) {
        this.liquidacionCuentasPK = new LiquidacionCuentasPK(liqCodigo, cveCuenta);
    }

    public LiquidacionCuentasPK getLiquidacionCuentasPK() {
        return liquidacionCuentasPK;
    }

    public void setLiquidacionCuentasPK(LiquidacionCuentasPK liquidacionCuentasPK) {
        this.liquidacionCuentasPK = liquidacionCuentasPK;
    }

	public int getLogAuditoriaId() {
		return logAuditoriaId;
	}

	public void setLogAuditoriaId(int logAuditoriaId) {
		this.logAuditoriaId = logAuditoriaId;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	@Override
    public int hashCode() {
        int hash = 0;
        hash += (liquidacionCuentasPK != null ? liquidacionCuentasPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof LiquidacionCuentas)) {
            return false;
        }
        LiquidacionCuentas other = (LiquidacionCuentas) object;
        if ((this.liquidacionCuentasPK == null && other.liquidacionCuentasPK != null) || (this.liquidacionCuentasPK != null && !this.liquidacionCuentasPK.equals(other.liquidacionCuentasPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gob.bcb.siodex.entities.LiquidacionCuentas[ liquidacionCuentasPK=" + liquidacionCuentasPK + " ]";
    }

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public Date getFechaHora() {
		return fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getValorAdic() {
		return valorAdic;
	}

	public void setValorAdic(String valorAdic) {
		this.valorAdic = valorAdic;
	}

}
