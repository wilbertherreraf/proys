@javax.xml.bind.annotation.XmlSchema(namespace = "http://mefp.gob.bo/itg")
package gob.bcb.jee.siodex.clientsigmaws.consultas;
