/*
 * Creado el 03-abr-2006
 *
 * TODO Para cambiar la plantilla de este archivo generado, vaya a
 * Ventana - Preferencias - Java - Estilo de c�digo - Plantillas de c�digo
 */
package gob.bcb.jee.siodex.util;

import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Writer;

/**
 * DOM2 utilites
 * Permite parsear un documento XML
 * @author Thomas.Diesler@jboss.org
 */
public final class DOM2Writer { 
	private boolean pretty = false;

	private int indent;

	public DOM2Writer() {
	}

	public DOM2Writer(boolean pretty) {
		this.pretty = pretty;
	}

	public String elementToString(Element element) {
		StringBuffer buffer = new StringBuffer();
		appendElement(buffer, element);
		return buffer.toString();
	}

	public void elementToWriter(Writer writer, Element element) {
		String xmlString = elementToString(element);
		PrintWriter pw = new PrintWriter(writer);
		pw.println(xmlString);
		pw.close();
	}

	public void elementToOutputStream(OutputStream out, Element element)
			throws IOException {
		String xmlString = elementToString(element);
		OutputStreamWriter osw = new OutputStreamWriter(out);
		osw.write(xmlString);
		osw.close();
	}

	private void appendElement(StringBuffer buffer, Element element) {
		if (pretty && indent > 0) {
			buffer.append("\n");
			for (int i = 0; i < indent; i++)
				buffer.append(" ");
		}

		indent++;

		String nodeName = element.getNodeName();
		buffer.append("<" + nodeName);
		appendAttributes(buffer, element);

		if (element.hasChildNodes()) {
			buffer.append(">");
		} else {
			buffer.append("/>");
		}

		boolean textBeforeClose = false;
		NodeList nodeList = element.getChildNodes();
		for (int i = 0; i < nodeList.getLength(); i++) {
			Node child = nodeList.item(i);
			short nodeType = child.getNodeType();
			if (nodeType == Node.ELEMENT_NODE) {
				appendElement(buffer, (Element) child);
				textBeforeClose = false;
			} else if (nodeType == Node.TEXT_NODE) {
				buffer.append(child.getNodeValue());
				textBeforeClose = true;
			}else if (nodeType == Node.CDATA_SECTION_NODE) {
				buffer.append("<![CDATA[" + normalizeString(child.getNodeValue(), false) + "]]>");
				textBeforeClose = true;
			}
		}
		if (pretty && indent > 0)
			indent--;

		if (pretty && !textBeforeClose) {
			if (element.hasChildNodes())
				buffer.append("\n");

			for (int i = 0; i < indent; i++)
				buffer.append(" ");
		}

		if (element.hasChildNodes())
			buffer.append("</" + nodeName + ">");
	}

	private void appendAttributes(StringBuffer buffer, Element element) {
		if (element.hasAttributes()) {
			NamedNodeMap attrMap = element.getAttributes();
			for (int i = 0; i < attrMap.getLength(); i++) {
				Node attr = attrMap.item(i);
				String nodeName = attr.getNodeName();
				String attrValue = attr.getNodeValue();
				buffer.append(" " + nodeName + "=\"" + attrValue + "\"");
			}
		}
	}
    public String normalizeString(String s, boolean isAttValue) {
    	String result = "";
        int len = (s != null) ? s.length() : 0;
        for (int i = 0; i < len; i++) {
            char c = s.charAt(i);
            result = result + normalizeString(c, isAttValue, true, true);
        }
        return result;
    } // normalizeAndPrint(String,boolean)

    /** Normalizes and print the given character. */
    protected String normalizeString(char c, boolean isAttValue, boolean fCanonical, boolean fXML11) {
    	String result = "";
        switch (c) {
            case '<': {
            	result = "&lt;";
                break;
            }
            case '>': {
            	result = "&gt;";
                break;
            }
            case '&': {
            	result = "&amp;";
                break;
            }
            case '"': {
                // A '"' that appears in character data
                // does not need to be escaped.
                if (isAttValue) {
                	result = "&quot;";
                }
                else {
                	result = "\"";
                }
                break;
            }
            case '\r': {
            	// If CR is part of the document's content, it
            	// must not be printed as a literal otherwise
            	// it would be normalized to LF when the document
            	// is reparsed.
            	result = "&#xD;";
            	break;
            }
            case '\n': {
                if (fCanonical) {
                	result = "&#xA;";
                    break;
                }
                // else, default print char
            }
/*            case '�': {	result = "&atilde;";
				break;
            }
            case '�': {	result = "&etilde;";
				break;
            }
            case '�': {	result = "&itilde;";
				break;
            }
            case '�': {	result = "&otilde;";
            			break;
            }
            case '�': {	result = "&utilde;";
				break;
            }*/
            default: {
            	// In XML 1.1, control chars in the ranges [#x1-#x1F, #x7F-#x9F] must be escaped.
            	//
            	// Escape space characters that would be normalized to #x20 in attribute values
            	// when the document is reparsed.
            	//
            	// Escape NEL (0x85) and LSEP (0x2028) that appear in content
            	// if the document is XML 1.1, since they would be normalized to LF
            	// when the document is reparsed.
            	if (fXML11 && ((c >= 0x01 && c <= 0x1F && c != 0x09 && c != 0x0A)
            	    || (c >= 0x7F && c <= 0x9F) || c == 0x2028)
            	    || isAttValue && (c == 0x09 || c == 0x0A)) {
            		result = "&#x";
            		result = result + Integer.toHexString(c).toUpperCase();
            		result = result + ";";
                }
                else {
                	result = String.valueOf(c);
                }
            }
        }
        return result;
    } // normalizeAndPrint(char,boolean)
}