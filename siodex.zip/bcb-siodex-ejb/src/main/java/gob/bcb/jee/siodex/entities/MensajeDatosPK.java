/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author CUriona
 */
@Embeddable
public class MensajeDatosPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "men_codigo", nullable = false)
    private String menCodigo;
    @Basic(optional = false)
    @NotNull
    @Column(name = "cam_bloque", nullable = false)
    private short camBloque;
    @Basic(optional = false)
    @NotNull
    @Column(name = "cam_codigo", nullable = false)
    private String camCodigo;

    public MensajeDatosPK() {
    }

    public MensajeDatosPK(String menCodigo, short camBloque, String camCodigo) {
        this.menCodigo = menCodigo;
        this.camBloque = camBloque;
        this.camCodigo = camCodigo;
    }

    public String getMenCodigo() {
        return menCodigo;
    }

    public void setMenCodigo(String menCodigo) {
        this.menCodigo = menCodigo;
    }

    public short getCamBloque() {
        return camBloque;
    }

    public void setCamBloque(short camBloque) {
        this.camBloque = camBloque;
    }

    public String getCamCodigo() {
        return camCodigo;
    }

    public void setCamCodigo(String camCodigo) {
        this.camCodigo = camCodigo;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (menCodigo != null ? menCodigo.hashCode() : 0);
        hash += (int) camBloque;
        hash += (camCodigo != null ? camCodigo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof MensajeDatosPK)) {
            return false;
        }
        MensajeDatosPK other = (MensajeDatosPK) object;
        if ((this.menCodigo == null && other.menCodigo != null) || (this.menCodigo != null && !this.menCodigo.equals(other.menCodigo))) {
            return false;
        }
        if (this.camBloque != other.camBloque) {
            return false;
        }
        if ((this.camCodigo == null && other.camCodigo != null) || (this.camCodigo != null && !this.camCodigo.equals(other.camCodigo))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gob.bcb.siodex.entities.MensajeDatosPK[ menCodigo=" + menCodigo + ", camBloque=" + camBloque + ", camCodigo=" + camCodigo + " ]";
    }
    
}
