/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author CUriona
 */
@Entity
@Table(name = "comision_bancaria")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ComisionBancaria.findAll", query = "SELECT c FROM ComisionBancaria c"),
    @NamedQuery(name = "ComisionBancaria.findByLiqCodigo", query = "SELECT c FROM ComisionBancaria c WHERE c.comisionBancariaPK.liqCodigo = :liqCodigo"),
    @NamedQuery(name = "ComisionBancaria.findByCveTipocomi", query = "SELECT c FROM ComisionBancaria c WHERE c.comisionBancariaPK.cveTipocomi = :cveTipocomi"),
    @NamedQuery(name = "ComisionBancaria.findByMontoMN", query = "SELECT c FROM ComisionBancaria c WHERE c.montoMN = :montoMN")})
public class ComisionBancaria implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected ComisionBancariaPK comisionBancariaPK;
    @Column(name = "log_auditoria_id")
    private Integer logAuditoriaId;
    @Column(name = "monto_mn", precision = 16, scale = 2)
    private BigDecimal montoMN;
//    @JoinColumn(name = "liq_codigo", referencedColumnName = "liq_codigo", nullable = false, insertable = false, updatable = false)
//    @ManyToOne(optional = false, fetch = FetchType.LAZY)
//    private Liquidacion liquidacion;

    public ComisionBancaria() {
    }

    public ComisionBancaria(ComisionBancariaPK comisionBancariaPK) {
        this.comisionBancariaPK = comisionBancariaPK;
    }

    public ComisionBancaria(ComisionBancariaPK comisionBancariaPK, Integer logAuditoriaId, BigDecimal montoMN) {
        this.comisionBancariaPK = comisionBancariaPK;
        this.logAuditoriaId = logAuditoriaId;
        this.montoMN = montoMN;
    }

    public ComisionBancaria(String liqCodigo, String cveTipocomi) {
        this.comisionBancariaPK = new ComisionBancariaPK(liqCodigo, cveTipocomi);
    }

    public ComisionBancariaPK getComisionBancariaPK() {
        return comisionBancariaPK;
    }

    public void setComisionBancariaPK(ComisionBancariaPK comisionBancariaPK) {
        this.comisionBancariaPK = comisionBancariaPK;
    }

    public BigDecimal getMontoMN() {
        return montoMN;
    }

    public void setMontoMN(BigDecimal montoMN) {
        this.montoMN = montoMN;
    }

    public Integer getLogAuditoriaId() {
		return logAuditoriaId;
	}

	public void setLogAuditoriaId(Integer logAuditoriaId) {
		this.logAuditoriaId = logAuditoriaId;
	}

//	public Liquidacion getLiquidacion() {
//        return liquidacion;
//    }
//
//    public void setLiquidacion(Liquidacion liquidacion) {
//        this.liquidacion = liquidacion;
//    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (comisionBancariaPK != null ? comisionBancariaPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ComisionBancaria)) {
            return false;
        }
        ComisionBancaria other = (ComisionBancaria) object;
        if ((this.comisionBancariaPK == null && other.comisionBancariaPK != null) || (this.comisionBancariaPK != null && !this.comisionBancariaPK.equals(other.comisionBancariaPK))) {
            return false;
        }
        return true;
    }

	@Override
	public String toString() {
		return "ComisionBancaria [comisionBancariaPK=" + comisionBancariaPK + ", logAuditoriaId=" + logAuditoriaId + ", montoMN=" + montoMN + "]";
	}
    
}
