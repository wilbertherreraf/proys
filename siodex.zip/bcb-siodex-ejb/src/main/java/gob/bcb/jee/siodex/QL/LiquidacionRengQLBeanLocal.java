package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.Renglon;

import java.util.List;

import javax.ejb.Local;

@Local
public interface LiquidacionRengQLBeanLocal {

	/**
	 * 
	 * @return
	 */
	public List<Renglon> listaLiquidacionReng(String codigo, String det, String tipo);
	public List<Renglon> listaLiquidacionReng1(String codigo, String det, String tipo);
	
}
