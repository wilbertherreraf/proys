/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author CUriona
 */
@Embeddable
public class ToperDatosPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "top_codigo", nullable = false)
    private String topCodigo;
    @Basic(optional = false)
    @NotNull
    @Column(name = "dato_adicional", nullable = false)
    private String datoAdicional;
        
    public ToperDatosPK() {
    }

    public ToperDatosPK(String topCodigo, String datoAdicional) {
        this.topCodigo = topCodigo;
        this.datoAdicional = datoAdicional;
    }

    public String getTopCodigo() {
		return topCodigo;
	}

	public void setTopCodigo(String topCodigo) {
		this.topCodigo = topCodigo;
	}

	public String getDatoAdicional() {
		return datoAdicional;
	}

	public void setDatoAdicional(String datoAdicional) {
		this.datoAdicional = datoAdicional;
	}

	@Override
    public int hashCode() {
        int hash = 0;
        hash += (topCodigo != null ? topCodigo.hashCode() : 0);
        hash += (datoAdicional != null ? datoAdicional.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ToperDatosPK)) {
            return false;
        }
        ToperDatosPK other = (ToperDatosPK) object;
        if ((this.topCodigo == null && other.topCodigo != null) || (this.topCodigo != null && !this.topCodigo.equals(other.topCodigo))) {
            return false;
        }
        if ((this.datoAdicional == null && other.datoAdicional != null) || (this.datoAdicional != null && !this.datoAdicional.equals(other.datoAdicional))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gob.bcb.siodex.entities.ToperDatosPK[ topCodigo=" + topCodigo + ", datoAdicional=" + datoAdicional + " ]";
    }
    
}