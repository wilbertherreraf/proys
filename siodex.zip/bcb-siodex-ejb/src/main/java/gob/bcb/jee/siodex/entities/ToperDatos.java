/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * 
 * @author CUriona
 */
@Entity
@Table(name = "toper_datos")
@XmlRootElement
@NamedQueries({ @NamedQuery(name = "ToperDatos.findAll", query = "SELECT d FROM ToperDatos d") })
public class ToperDatos implements Serializable {
	private static final long serialVersionUID = 1L;
	@EmbeddedId
	protected ToperDatosPK toperDatosPK;
	@Basic(optional = false)
	@NotNull
	@Column(name = "cve_tipo_dato", nullable = false)
	private String cveTipoDato;

	@Column(name = "cve_debe_haber")
	private String cveDebeHaber;
	@Column(name = "cod_moneda")
	private String codMoneda;
	@Column(name = "orden")
	private Integer orden;	
	@Column(name = "usr_codigo")
	private String usrCodigo;
	@Column(name = "fecha_hora")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fechaHora;
	@Column(name = "estacion")
	private String estacion;

	public ToperDatos() {
	}

	public ToperDatos(ToperDatosPK toperDatosPK) {
		this.toperDatosPK = toperDatosPK;
	}

	public ToperDatos(String toperCodigo, String datoAdicional) {
		this.toperDatosPK = new ToperDatosPK(toperCodigo, datoAdicional);
	}

	public ToperDatosPK getToperDatosPK() {
		return toperDatosPK;
	}

	public void setToperDatosPK(ToperDatosPK toperDatosPK) {
		this.toperDatosPK = toperDatosPK;
	}

	public String getCveTipoDato() {
		return cveTipoDato;
	}

	public void setCveTipoDato(String cveTipoDato) {
		this.cveTipoDato = cveTipoDato;
	}

	public String getCveDebeHaber() {
		return cveDebeHaber;
	}

	public void setCveDebeHaber(String cveDebeHaber) {
		this.cveDebeHaber = cveDebeHaber;
	}

	public String getCodMoneda() {
		return codMoneda;
	}

	public void setCodMoneda(String codMoneda) {
		this.codMoneda = codMoneda;
	}

	public String getUsrCodigo() {
		return usrCodigo;
	}

	public void setUsrCodigo(String usrCodigo) {
		this.usrCodigo = usrCodigo;
	}

	public Date getFechaHora() {
		return fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getEstacion() {
		return estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	@Override
	public String toString() {
		return "ToperDatos [toperDatosPK=" + toperDatosPK + ", cveTipoDato=" + cveTipoDato + ", cveDebeHaber=" + cveDebeHaber + ", codMoneda="
				+ codMoneda + ", usrCodigo=" + usrCodigo + ", fechaHora=" + fechaHora + ", estacion=" + estacion + "]";
	}

	public Integer getOrden() {
		return orden;
	}

	public void setOrden(Integer orden) {
		this.orden = orden;
	}

	
}