/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author CUriona
 */
@Entity
@Table(name = "tmp_operacion_deuda")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TmpOperacionDeuda.findAll", query = "SELECT t FROM TmpOperacionDeuda t"),
    @NamedQuery(name = "TmpOperacionDeuda.findByDeuCodigo", query = "SELECT t FROM TmpOperacionDeuda t WHERE t.tmpOperacionDeudaPK.deuCodigo = :deuCodigo"),
    @NamedQuery(name = "TmpOperacionDeuda.findByOpeCodigo", query = "SELECT t FROM TmpOperacionDeuda t WHERE t.tmpOperacionDeudaPK.opeCodigo = :opeCodigo")})
public class TmpOperacionDeuda implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected TmpOperacionDeudaPK tmpOperacionDeudaPK;
    @Column(name = "dso_id")
    private Integer dsoId;
    @Column(name = "lo_no")
    private String loNo;
    @Column(name = "tra_no")
    private Short traNo;
    @Column(name = "d_cred_val")
    @Temporal(TemporalType.DATE)
    private Date dCredVal;
    @Column(name = "cg_trns_typ")
    private Short cgTrnsTyp;
    @Column(name = "cd_trns_typ")
    private String cdTrnsTyp;
    @Column(name = "cg_fee_typ")
    private Short cgFeeTyp;
    @Column(name = "cd_fee_typ")
    private String cdFeeTyp;
    @Column(name = "d_sch")
    @Temporal(TemporalType.DATE)
    private Date dSch;
    @Column(name = "d_dbr_val")
    @Temporal(TemporalType.DATE)
    private Date dDbrVal;
    @Column(name = "cu_eff")
    private String cuEff;
    @Column(name = "amt_cu_eff", precision = 21, scale = 3)
    private BigDecimal amtCuEff;
    @Column(name = "amt_cu_local", precision = 21, scale = 3)
    private BigDecimal amtCuLocal;
    @Column(name = "amt_cu_base", precision = 21, scale = 3)
    private BigDecimal amtCuBase;
    @Column(name = "amt_sch", precision = 21, scale = 3)
    private BigDecimal amtSch;
    @Column(name = "amt_cu_sdr", precision = 21, scale = 3)
    private BigDecimal amtCuSdr;
    @Column(name = "amt_cu_usd", precision = 21, scale = 3)
    private BigDecimal amtCuUsd;
    @Column(name = "d_local_exch_rte")
    @Temporal(TemporalType.DATE)
    private Date dLocalExchRte;
    @Column(name = "cg_medium")
    private Short cgMedium;
    @Column(name = "cd_medium")
    private String cdMedium;
    @Column(name = "sdsp_id")
    private Integer sdspId;
    @Column(name = "amt_cu_eur", precision = 21, scale = 3)
    private BigDecimal amtCuEur;
    @Column(name = "amt_cu_lo", precision = 21, scale = 3)
    private BigDecimal amtCuLo;
    @Column(name = "det_codigo")
    private String detCodigo;
    @Column(name = "amt_cu_eff_o", precision = 21, scale = 3)
    private BigDecimal amtCuEffO;
    @Column(name = "amt_cu_local_o", precision = 21, scale = 3)
    private BigDecimal amtCuLocalO;
    @Column(name = "amt_cu_usd_o", precision = 21, scale = 3)
    private BigDecimal amtCuUsdO;
    @Column(name = "tipo_cambio", precision = 26, scale = 16)
    private BigDecimal tipoCambio;

    public TmpOperacionDeuda() {
    }

    public TmpOperacionDeuda(TmpOperacionDeudaPK tmpOperacionDeudaPK) {
        this.tmpOperacionDeudaPK = tmpOperacionDeudaPK;
    }

    public TmpOperacionDeuda(String deuCodigo, String opeCodigo) {
        this.tmpOperacionDeudaPK = new TmpOperacionDeudaPK(deuCodigo, opeCodigo);
    }

    public TmpOperacionDeudaPK getTmpOperacionDeudaPK() {
        return tmpOperacionDeudaPK;
    }

    public void setTmpOperacionDeudaPK(TmpOperacionDeudaPK tmpOperacionDeudaPK) {
        this.tmpOperacionDeudaPK = tmpOperacionDeudaPK;
    }

    public Integer getDsoId() {
        return dsoId;
    }

    public void setDsoId(Integer dsoId) {
        this.dsoId = dsoId;
    }

    public String getLoNo() {
        return loNo;
    }

    public void setLoNo(String loNo) {
        this.loNo = loNo;
    }

    public Short getTraNo() {
        return traNo;
    }

    public void setTraNo(int traNo) {
        this.traNo = (short) traNo;
    }

    public Date getDCredVal() {
        return dCredVal;
    }

    public void setDCredVal(Date dCredVal) {
        this.dCredVal = dCredVal;
    }

    public Short getCgTrnsTyp() {
        return cgTrnsTyp;
    }

    public void setCgTrnsTyp(Short cgTrnsTyp) {
        this.cgTrnsTyp = cgTrnsTyp;
    }

    public String getCdTrnsTyp() {
        return cdTrnsTyp;
    }

    public void setCdTrnsTyp(String cdTrnsTyp) {
        this.cdTrnsTyp = cdTrnsTyp;
    }

    public Short getCgFeeTyp() {
        return cgFeeTyp;
    }

    public void setCgFeeTyp(Short cgFeeTyp) {
        this.cgFeeTyp = cgFeeTyp;
    }

    public String getCdFeeTyp() {
        return cdFeeTyp;
    }

    public void setCdFeeTyp(String cdFeeTyp) {
        this.cdFeeTyp = cdFeeTyp;
    }

    public Date getDSch() {
        return dSch;
    }

    public void setDSch(Date dSch) {
        this.dSch = dSch;
    }

    public Date getDDbrVal() {
        return dDbrVal;
    }

    public void setDDbrVal(Date dDbrVal) {
        this.dDbrVal = dDbrVal;
    }

    public String getCuEff() {
        return cuEff;
    }

    public void setCuEff(String cuEff) {
        this.cuEff = cuEff;
    }

    public BigDecimal getAmtCuEff() {
        return amtCuEff;
    }

    public void setAmtCuEff(BigDecimal amtCuEff) {
        this.amtCuEff = amtCuEff;
    }

    public BigDecimal getAmtCuLocal() {
        return amtCuLocal;
    }

    public void setAmtCuLocal(BigDecimal amtCuLocal) {
        this.amtCuLocal = amtCuLocal;
    }

    public BigDecimal getAmtCuBase() {
        return amtCuBase;
    }

    public void setAmtCuBase(BigDecimal amtCuBase) {
        this.amtCuBase = amtCuBase;
    }

    public BigDecimal getAmtSch() {
        return amtSch;
    }

    public void setAmtSch(BigDecimal amtSch) {
        this.amtSch = amtSch;
    }

    public BigDecimal getAmtCuSdr() {
        return amtCuSdr;
    }

    public void setAmtCuSdr(BigDecimal amtCuSdr) {
        this.amtCuSdr = amtCuSdr;
    }

    public BigDecimal getAmtCuUsd() {
        return amtCuUsd;
    }

    public void setAmtCuUsd(BigDecimal amtCuUsd) {
        this.amtCuUsd = amtCuUsd;
    }

    public Date getDLocalExchRte() {
        return dLocalExchRte;
    }

    public void setDLocalExchRte(Date dLocalExchRte) {
        this.dLocalExchRte = dLocalExchRte;
    }

    public Short getCgMedium() {
        return cgMedium;
    }

    public void setCgMedium(Short cgMedium) {
        this.cgMedium = cgMedium;
    }

    public String getCdMedium() {
        return cdMedium;
    }

    public void setCdMedium(String cdMedium) {
        this.cdMedium = cdMedium;
    }

    public Integer getSdspId() {
        return sdspId;
    }

    public void setSdspId(Integer sdspId) {
        this.sdspId = sdspId;
    }

    public BigDecimal getAmtCuEur() {
        return amtCuEur;
    }

    public void setAmtCuEur(BigDecimal amtCuEur) {
        this.amtCuEur = amtCuEur;
    }

    public BigDecimal getAmtCuLo() {
        return amtCuLo;
    }

    public void setAmtCuLo(BigDecimal amtCuLo) {
        this.amtCuLo = amtCuLo;
    }

    public String getDetCodigo() {
        return detCodigo;
    }

    public void setDetCodigo(String detCodigo) {
        this.detCodigo = detCodigo;
    }

    public BigDecimal getAmtCuEffO() {
        return amtCuEffO;
    }

    public void setAmtCuEffO(BigDecimal amtCuEffO) {
        this.amtCuEffO = amtCuEffO;
    }

    public BigDecimal getAmtCuLocalO() {
        return amtCuLocalO;
    }

    public void setAmtCuLocalO(BigDecimal amtCuLocalO) {
        this.amtCuLocalO = amtCuLocalO;
    }

    public BigDecimal getAmtCuUsdO() {
        return amtCuUsdO;
    }

    public void setAmtCuUsdO(BigDecimal amtCuUsdO) {
        this.amtCuUsdO = amtCuUsdO;
    }

    public BigDecimal getTipoCambio() {
        return tipoCambio;
    }

    public void setTipoCambio(BigDecimal tipoCambio) {
        this.tipoCambio = tipoCambio;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (tmpOperacionDeudaPK != null ? tmpOperacionDeudaPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TmpOperacionDeuda)) {
            return false;
        }
        TmpOperacionDeuda other = (TmpOperacionDeuda) object;
        if ((this.tmpOperacionDeudaPK == null && other.tmpOperacionDeudaPK != null) || (this.tmpOperacionDeudaPK != null && !this.tmpOperacionDeudaPK.equals(other.tmpOperacionDeudaPK))) {
            return false;
        }
        return true;
    }

	@Override
	public String toString() {
		return "TmpOperacionDeuda [tmpOperacionDeudaPK=" + tmpOperacionDeudaPK + ", dsoId=" + dsoId + ", loNo=" + loNo + ", traNo=" + traNo
				+ ", dCredVal=" + dCredVal + ", cgTrnsTyp=" + cgTrnsTyp + ", cdTrnsTyp=" + cdTrnsTyp + ", cgFeeTyp=" + cgFeeTyp + ", cdFeeTyp="
				+ cdFeeTyp + ", dSch=" + dSch + ", dDbrVal=" + dDbrVal + ", cuEff=" + cuEff + ", amtCuEff=" + amtCuEff + ", amtCuLocal=" + amtCuLocal
				+ ", amtCuBase=" + amtCuBase + ", amtSch=" + amtSch + ", amtCuSdr=" + amtCuSdr + ", amtCuUsd=" + amtCuUsd + ", dLocalExchRte="
				+ dLocalExchRte + ", cgMedium=" + cgMedium + ", cdMedium=" + cdMedium + ", sdspId=" + sdspId + ", amtCuEur=" + amtCuEur
				+ ", amtCuLo=" + amtCuLo + ", detCodigo=" + detCodigo + ", amtCuEffO=" + amtCuEffO + ", amtCuLocalO=" + amtCuLocalO + ", amtCuUsdO="
				+ amtCuUsdO + ", tipoCambio=" + tipoCambio + "]";
	}

 
}