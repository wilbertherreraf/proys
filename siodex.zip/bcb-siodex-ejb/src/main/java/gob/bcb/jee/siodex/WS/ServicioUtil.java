package gob.bcb.jee.siodex.WS;

import gob.bcb.jee.siodex.QL.CuentaQLBeanLocal;
import gob.bcb.jee.siodex.QL.DeudorLiquidacionQLBeanLocal;
import gob.bcb.jee.siodex.QL.LiquidacionQLBeanLocal;
import gob.bcb.jee.siodex.QL.MonedaQLBeanLocal;
import gob.bcb.jee.siodex.QL.SolicitudQLBeanLocal;
import gob.bcb.jee.siodex.QL.VencimientoQLBeanLocal;
import gob.bcb.jee.siodex.clientsigmaws.ClientTGNWSHandler;
import gob.bcb.jee.siodex.clientsigmaws.MensajeVenc;
import gob.bcb.jee.siodex.commons.ConfigurationServ;
import gob.bcb.jee.siodex.commons.Constants;
import gob.bcb.jee.siodex.entities.ComisionBancaria;
import gob.bcb.jee.siodex.entities.Cuenta;
import gob.bcb.jee.siodex.entities.Liquidacion;
import gob.bcb.jee.siodex.entities.LiquidacionDet;
import gob.bcb.jee.siodex.entities.Moneda;
import gob.bcb.jee.siodex.entities.Solicitud;
import gob.bcb.jee.siodex.entities.Vencimiento;
import gob.bcb.jee.siodex.exception.DataException;
import gob.bcb.jee.siodex.exception.FirmaException;
import gob.bcb.jee.siodex.exception.VerificaException;
import gob.bcb.jee.siodex.exception.XMLException;
import gob.bcb.jee.siodex.mefp.LiquidacionCuentas;
import gob.bcb.jee.siodex.mefp.LiquidacionCuentasPK;
import gob.bcb.jee.siodex.mefp.LiquidacionCuentasQLBeanLocal;
import gob.bcb.jee.siodex.util.CadenaEncDec;
import gob.bcb.jee.siodex.util.UtilesSiodex;
import gob.bcb.jee.siodex.util.XMLTools;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJBException;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.xml.soap.SOAPException;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Clase utilitaria para el servicio web del SIODEX.
 * 
 * @author wherrera
 * 
 */

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class ServicioUtil {
	static final Logger logger = Logger.getLogger(ServicioUtil.class);

	@PersistenceContext(unitName = "siodex")
	EntityManager entityManager;

	@Resource
	SessionContext sessionContext;

	@Inject
	private LiquidacionCuentasQLBeanLocal liquidacionCuentasQLBeanLocal;

	@Inject
	private VencimientoQLBeanLocal vencimientoQLBeanLocal;
	@Inject
	private LiquidacionQLBeanLocal liquidacionQLBeanLocal;
	@Inject
	private DeudorLiquidacionQLBeanLocal deudorLiquidacionQLBeanLocal;
	@Inject
	private SolicitudQLBeanLocal solicitudQLBeanLocal;
	@Inject
	private MonedaQLBeanLocal monedaQLBeanLocal;
	@Inject
	private CuentaQLBeanLocal cuentaQLBeanLocal;
	static {
		logger.info("Inicializando contexto de seguridad para firmas");
		org.apache.xml.security.Init.init();
		
		ConfigurationServ.init();
	}

	@PostConstruct
	public void init() {

	}

	/**
	 * 
	 * @param mensaje
	 * @param estadoLiq
	 *            debe estar en formato lista ej: 'P', 'O','C'
	 * @return
	 * @throws DataException
	 * @throws FirmaException
	 */
	public String consultaVencimientos(String tipoVenc, String estadoLiq, String urlServ, String codigoLiq, String codUsuario, String estacion)
			throws DataException, FirmaException {

		logger.info("WS: Ingresando a  consultaVencimientos codigoLiq [" + codigoLiq + "] tipo: " + tipoVenc + " estadoLiq: " + estadoLiq);
		StringBuilder respuestaXML = new StringBuilder();
		// es una consulta sobre un lote nuevo
		// 237 codigo de TGN
		Integer maxLote = 0;
		maxLote = liquidacionQLBeanLocal.maxLote();

		if (tipoVenc.equals("NOTIFICAR_MSG_TGN_LOTE") || tipoVenc.equals("NOTIFICAR_MSG_TGN_LIQ")|| tipoVenc.equals("NOTIFOBSERVADOS_MSG_TGN_LIQ")) {
			// si es consulta de publicados se genera uno nuevo
			maxLote++;
		}

		logger.info("Nro lote nuevo " + maxLote);
		int cont = 0;
		boolean isVencSolo = false;
		String urlReporte = null;

		// obtenemos los prestamos publicados u observados
		List<Vencimiento> vencimientolista = new ArrayList<Vencimiento>();
		if (!StringUtils.isBlank(codigoLiq)) {
			// notificacion de una sola liquidacion y no por lote
			Vencimiento vencimiento = vencimientoQLBeanLocal.getVencimiento(null, 0, codigoLiq);
			vencimiento = vencimientoQLBeanLocal.calcularVencimiento(vencimiento, vencimiento.getFechaTc(), "", 0, vencimiento.getLiqCodigo());
			vencimientolista.add(vencimiento);
			isVencSolo = true;
		} else {
			// por lote desde la vista se elimina dicha opcin
			if (tipoVenc.equals("NOTIFICAR_MSG_TGN_LOTE")) {
				vencimientolista = vencimientoQLBeanLocal.listaVencimiento(estadoLiq, Constants.COD_TGN);
			} else if (tipoVenc.equals("NOTIFOBSERVADOS_MSG_TGN_LOTE")) {
				vencimientolista = vencimientoQLBeanLocal.listaVencimiento("P", "B", Constants.COD_TGN);
			}
		}

		for (Vencimiento vencimiento : vencimientolista) {
			// se verifica el estado notificacion que no haya sido reportado y
			// lote o esta en estado observado
			if (!isVencSolo) {
				// NO se calculo
				vencimiento = vencimientoQLBeanLocal.calcularVencimiento(vencimiento, vencimiento.getFechaTc(), "", 0, vencimiento.getLiqCodigo());
			}

			List<LiquidacionDet> listaDet = vencimiento.getLiquidacionDetLista(); // liquidacionDetQLBeanLocal.listaLiquidacion(vencimiento.getLiqCodigo());

			if (listaDet == null || listaDet.size() == 0) {
				continue;
			}

			vencimiento.crearLogAuditoria(codUsuario, "900", estacion, vencimiento.getLiqCodigo());

			urlReporte = "";
			String xmlDetalle = "";

			if (vencimiento.getDocPdf() != null) {
				// reporte pdf de notificacion
				urlReporte = urlReporte(urlServ, "REPDB", vencimiento.getLiqCodigo());
			}

			if (tipoVenc.equals("NOTIFICAR_MSG_TGN_LOTE") || tipoVenc.equals("NOTIFICAR_MSG_TGN_LIQ")) {
				// es notificacion nueva
				if (StringUtils.isBlank(vencimiento.getCveEstNotif())) {
					// cambiamos el estado a notificado
					vencimiento.setCveEstNotif("N");
					vencimiento.setLote(maxLote);
					xmlDetalle = ArmarXML.xmlVencLiquidacionDet(vencimiento, listaDet, urlReporte);
				} else {
					if (tipoVenc.equals("NOTIFICAR_MSG_TGN_LIQ") && vencimiento.getCveEstNotif().equalsIgnoreCase("N")
							&& vencimiento.getLote() != null && vencimiento.getLote() > 0) {
						// si es individual y ya fue notificado
						// cambiamos el estado a modificado solo para envio del
						// mensaje
						vencimiento.setCveEstNotif("M");
						vencimiento.setLote(maxLote);
						xmlDetalle = ArmarXML.xmlVencLiquidacionDet(vencimiento, listaDet, urlReporte);
						// cambiamos al estado Notificado
						vencimiento.setCveEstNotif("N");
					}
				}
			} else if (tipoVenc.equals("NOTIFOBSERVADOS_MSG_TGN_LOTE") || tipoVenc.equals("NOTIFOBSERVADOS_MSG_TGN_LIQ")) {
				// el tipo de liq es observado
				if (!StringUtils.isBlank(vencimiento.getCveEstNotif()) && vencimiento.getCveEstNotif().equalsIgnoreCase("B")
						&& vencimiento.getLote() != null && vencimiento.getLote() > 0) {
					// la liq ya fue notificada y este esta observado
					// cambiamos el estado a Corregido solo para envbio
					vencimiento.setCveEstNotif("C");
					vencimiento.setLote(maxLote);
					xmlDetalle = ArmarXML.xmlVencLiquidacionDet(vencimiento, listaDet, urlReporte);
					// cambiamos a notificado para salvarlo posteriormente
					vencimiento.setCveEstNotif("N");
				}
			} else {
				throw new RuntimeException("Opcion no implementada");
			}

			if (!StringUtils.isBlank(xmlDetalle)) {
				logger.info("Detalle de Vencimientos  " + xmlDetalle);
				respuestaXML.append(xmlDetalle);
				cont = cont + listaDet.size();
			}

			// actualizamos datos de la liquidacion
			vencimientoQLBeanLocal.actualizarLiquidacion(vencimiento, "", "", "T");
		}

		if (cont == 0) {
			throw new DataException("No existen vencimientos a notificar, revise el estado de los mismos");
		}

		String mensajeConsulta = ArmarXML.xmlVencLiquidacionCab(maxLote, cont, respuestaXML.toString());

		return mensajeConsulta;
	}

	/**
	 * procesa un mensaje XML que contiene UNA LISTA de liquidaciones, se lo desparsea y cambia su estado como autorizado
	 * @param mensajeXML
	 * @return
	 * @throws SOAPException
	 * @throws XMLException
	 * @throws VerificaException
	 * @throws DataException
	 * @throws FirmaException
	 */
	public String vencimientosAutorizados(String mensajeXML) throws SOAPException, XMLException, VerificaException, DataException, FirmaException {
		logger.info("VencimientosAutorizados mensaje recibido:\n" + mensajeXML);
		Integer log = 1;
		String respuesta = "";

		// String salida =
		// Utils.readFileAsString("e://listaPagosAutorizados.xml");
		// logger.info("salida: " + salida);
		Document document = XmlUtil.stringXMLToDocument(mensajeXML);

		// borrar
		FirmaDig firmaDig = new FirmaDig();
		firmaDig.verify(document, null);
		int contRengs = 0;
		Node nodeTGN;
		NodeList nodeList = document.getElementsByTagName("Autorizado");

		Map<String, Object> valoresXMLTGN = new HashMap<String, Object>();
		List<MensajeVenc> mensajeVencList = new ArrayList<MensajeVenc>();

		for (int j = 0; j < nodeList.getLength(); j++) {
			nodeTGN = nodeList.item(j);
			String nodeAsStringTGN = XMLTools.nodeToXML(nodeTGN);
			String cod = XMLTools.getXMLTagValue(nodeAsStringTGN, "codigo");
			String prestamo = XMLTools.getXMLTagValue(nodeAsStringTGN, "prestamo");
			// String tramo = XMLTools.getXMLTagValue(nodeAsStringTGN, "tramo");
			String estado = XMLTools.getXMLTagValue(nodeAsStringTGN, "estado");
			String observacion = XMLTools.getXMLTagValue(nodeAsStringTGN, "observacion");
			String cuentaServicio = XMLTools.getXMLTagValue(nodeAsStringTGN, "cuentaServicio");
			String libretaServicio = XMLTools.getXMLTagValue(nodeAsStringTGN, "libretaServicio");
			String cuentaComisiones = XMLTools.getXMLTagValue(nodeAsStringTGN, "cuentaComisiones");
			String libretaComisiones = XMLTools.getXMLTagValue(nodeAsStringTGN, "libretaComisiones");

			if (StringUtils.isBlank(cod) || StringUtils.isBlank(prestamo) || StringUtils.isBlank(estado) || StringUtils.isBlank(cuentaServicio)
					|| StringUtils.isBlank(libretaServicio) || StringUtils.isBlank(cuentaComisiones) || StringUtils.isBlank(libretaComisiones)) {
				throw new DataException("Mensaje con valor o parametro incorrecto, revise los datos");
			}
			if (StringUtils.isBlank(estado) || (!estado.equalsIgnoreCase("A") && !estado.equalsIgnoreCase("R"))) {
				// si el estado de la liq no esta en autorizado o rechazado
				// lanzamos
				// exception
				throw new DataException("Liquidacion " + cod + " con parametro de estado incorrecto: " + estado);
			}

			// armamos un mapa para obtener codigos de liq unicos
			if (valoresXMLTGN.containsKey(cod)) {
				throw new DataException("Liquidacion " + cod + " duplicada ");
			}
			// en el xml no viene el tramo solo el prestamo
			Integer codTramo = Integer.valueOf(0);
			Liquidacion liquidacion = new Liquidacion(cod, prestamo, codTramo, estado, "TGN", new Date(), "WSTGN");
			liquidacion.setCveEstnotif(estado);

 			logger.info("ciclo de recuperacion de datos del mensaje XML terminado " + liquidacion.getLiqCodigo() + " recuperado");
			
			MensajeVenc mensajeVenc = new MensajeVenc();
			mensajeVenc.setCodLiq(cod);
			mensajeVenc.setLiquidacion(liquidacion);
			mensajeVenc.setObservacion(observacion);

			Vencimiento vencimiento = vencimientoQLBeanLocal.getVencimiento(null, 0, liquidacion.getLiqCodigo());

			//validacion de estados
			logger.info("ciclo de recuperacion de datos del mensaje XML terminado " + liquidacion.getLiqCodigo() + " recuperado");
			
			if (!vencimiento.getCveEstado().equalsIgnoreCase("P") && !vencimiento.getCveEstado().equalsIgnoreCase("B")) {
				throw new DataException("Liquidacion " + vencimiento.getLiqCodigo() + " con estado incorrecto " + vencimiento.getCveEstado()
						+ ", posiblemente ya fue procesado o rechazado");
			}

			if (StringUtils.isBlank(vencimiento.getCveEstNotif())) {
				throw new DataException("Liquidacion " + vencimiento.getLiqCodigo() + " sin envio de notificacion registrada en el BCB");
			}

			if (!vencimiento.getCveEstNotif().equalsIgnoreCase("N") || (vencimiento.getLote() == null || vencimiento.getLote() == 0)) {
				throw new DataException("Liquidacion " + vencimiento.getLiqCodigo()
						+ " en estado de notificacion incorrecto, comuniquese con el adm del sistema en el BCB ");
			}			
			vencimiento.crearLogAuditoria("TGN", "900", "WSTGN", vencimiento.getLiqCodigo());
			//validacion de cuentas
			
			Cuenta cuentaDEUD = cuentaQLBeanLocal.getCuenta(vencimiento.getPtmCodigo(), vencimiento.getTraCodigo(), "DEUD", null);
			// comparamos la cuenta los primeros 4 digitos

			if (!cuentaServicio.startsWith(cuentaDEUD.getCtaNumero().trim())) {
				throw new DataException("Cuenta de Servicios " + cuentaServicio + " inexistente en BCB, Liquidacion "
						+ vencimiento.getLiqCodigo() + " ");
			}
			
			LiquidacionCuentas liqC = new LiquidacionCuentas(new LiquidacionCuentasPK(cod, "DEUD"), log, cuentaDEUD.getCtaCodigo());
			liqC.setValorAdic(cuentaServicio);
			
			liquidacionCuentasQLBeanLocal.actualizar(liqC);
			vencimiento.setCuentaPrestamo(cuentaDEUD.getCveTitular(), cuentaDEUD);
			
			mensajeVenc.getLiquidacionCuentasTgnList().add(liqC);
		
			liqC = new LiquidacionCuentas(new LiquidacionCuentasPK(cod, "LOPE"), log, libretaServicio);
			liqC.setValorAdic(libretaServicio);
			mensajeVenc.getLiquidacionCuentasTgnList().add(liqC);
			
			liquidacionCuentasQLBeanLocal.actualizar(liqC);
			
			Cuenta cuentaDEUC = cuentaQLBeanLocal.getCuenta(vencimiento.getPtmCodigo(), vencimiento.getTraCodigo(), "DEUC", null);
			
			// actualizacion de cuentas yu libretas comisiones
			
			// comparamos la cuenta los primeros 4 digitos

			if (!cuentaComisiones.startsWith(cuentaDEUC.getCtaNumero().trim())) {
				throw new DataException("Cuenta de Comisiones " + cuentaComisiones + " inexistente en BCB, Liquidacion "
						+ vencimiento.getLiqCodigo() + " ");
			}
			
			liqC = new LiquidacionCuentas(new LiquidacionCuentasPK(cod, "DEUC"), vencimiento.getLogAuditoria().getLogAuditoriaId(), cuentaDEUC.getCtaCodigo());
			liqC.setValorAdic(cuentaComisiones);
			
			liquidacionCuentasQLBeanLocal.actualizar(liqC);
			vencimiento.setCuentaPrestamo(cuentaDEUC.getCveTitular(), cuentaDEUC);
			
			mensajeVenc.getLiquidacionCuentasTgnList().add(liqC);
			
			liqC = new LiquidacionCuentas(new LiquidacionCuentasPK(cod, "LCOM"), vencimiento.getLogAuditoria().getLogAuditoriaId(), libretaComisiones);
			liqC.setValorAdic(libretaComisiones);
			liquidacionCuentasQLBeanLocal.actualizar(liqC);
			
			mensajeVenc.getLiquidacionCuentasTgnList().add(liqC);

			logger.info("Datos de cuenta validados y registrados " + vencimiento.getLiqCodigo());
			
			// nuevos estados de notificacion
			if (liquidacion.getCveEstnotif().equalsIgnoreCase("R")) {
				vencimiento.setCveEstNotif("R");
				vencimiento = vencimientoQLBeanLocal.actualizarLiquidacion(vencimiento, mensajeVenc.getObservacion(), "Z", "WS");
				
			} else if (liquidacion.getCveEstnotif().equalsIgnoreCase("A")) {
				vencimiento = vencimientoQLBeanLocal.calcularVencimiento(vencimiento, new Date(), "", 0, vencimiento.getLiqCodigo());				
				vencimiento.setCveEstNotif("A");
				vencimiento = vencimientoQLBeanLocal.actualizarLiquidacion(vencimiento, mensajeVenc.getObservacion(), "A", "WS");
				
			} else {
				throw new DataException("Estado incorrecto " + liquidacion.getLiqCodigo() + " debe ser R(echazado) o A(utorizado)");
			}
			
			logger.info("==D WS: Datos validados y registrados: " + vencimiento.toString());
			
			
			mensajeVenc.setVencimiento(vencimiento);
			mensajeVencList.add(mensajeVenc);
			valoresXMLTGN.put(cod, cod);

			contRengs++;			
		}
		
		
		if (contRengs > 0) {
			
			for (MensajeVenc mensajeVenc : mensajeVencList) {
				Liquidacion liquidacion = mensajeVenc.getLiquidacion();
				Vencimiento vencimiento =  mensajeVenc.getVencimiento();
				
				if (liquidacion.getCveEstnotif().equalsIgnoreCase("R")) {
					vencimientoQLBeanLocal.enviarCorreos(vencimiento, mensajeVenc.getObservacion(), "LIQRECHAZADA", "WS");
				} else if (liquidacion.getCveEstnotif().equalsIgnoreCase("A")) {
					vencimientoQLBeanLocal.enviarCorreos(vencimiento, mensajeVenc.getObservacion(), "PAGOAUTORIZADO", "WS");					
				}
			}
		}
		
		Document doc1 = UtilesSiodex.generaDocXMLRespuesta(0, "1", "Consulta realizada existosamente, con " + contRengs
				+ " liquidaciones registradas");

		respuesta = XMLTools.DocumentToString(doc1);
		
		return respuesta;
	}

	public String vencimientosObservados(String mensajeXML) throws SOAPException, XMLException, VerificaException, DataException, FirmaException {
		logger.info("VencimientosObservados mensaje recibido:\n" + mensajeXML);
		String respuesta = "";

		Document document = XmlUtil.stringXMLToDocument(mensajeXML);

		FirmaDig firmaDig = new FirmaDig();
		firmaDig.verify(document, null);

		int contRengs = 0;
		Node nodeTGN;
		NodeList nodeList = document.getElementsByTagName("Observado");

		Map<String, String> observaciones = new HashMap<String, String>();
		for (int j = 0; j < nodeList.getLength(); j++) {
			nodeTGN = nodeList.item(j);
			String nodeAsStringTGN = XMLTools.nodeToXML(nodeTGN);
			String codigo = XMLTools.getXMLTagValue(nodeAsStringTGN, "codigo");
			XMLTools.getXMLTagValue(nodeAsStringTGN, "prestamo");
			XMLTools.getXMLTagValue(nodeAsStringTGN, "tramo");
			String observacion = XMLTools.getXMLTagValue(nodeAsStringTGN, "observacion");

			if (StringUtils.isBlank(codigo)) {
				throw new DataException("Liquidacion con parametro codigo liq valor nulo");
			}

			String codLiquidacion = codigo.substring(0, 6);
			Integer codTramo = Integer.valueOf(codigo.substring(6));

			if (observaciones.containsKey(codLiquidacion)) {
				String obs = observaciones.get(codLiquidacion);
				obs = obs.concat("| [" + codTramo + "]").concat(observacion);
				observaciones.put(codLiquidacion, obs);
			} else {
				observaciones.put(codLiquidacion, observacion);
			}

		}

		logger.info("Fin ciclo de recuperacion de datos");
		List<MensajeVenc> mensajeVencList = new ArrayList<MensajeVenc>();
		for (Iterator<?> i = observaciones.keySet().iterator(); i.hasNext();) {

			String codLiquidacion = (String) i.next();
			String observacion = observaciones.get(codLiquidacion);

			logger.info("Registrando Observacion: " + codLiquidacion + " - " + observacion);

			Vencimiento vencimiento = vencimientoQLBeanLocal.getVencimiento(null, 0, codLiquidacion);
			// si el estado es diferente a publicado o en observacion no se
			// recibe
			
			vencimiento.crearLogAuditoria("TGN", "900", "WSTGN", vencimiento.getLiqCodigo());
			
			if (!vencimiento.getCveEstado().equalsIgnoreCase("P")) {
				throw new DataException("Liquidacion " + vencimiento.getLiqCodigo() + " con estado incorrecto " + vencimiento.getCveEstado()
						+ ", posiblemente ya fue procesado o rechazado");
			}

			// si el estado de la notificacion es nulo o blanco o no esta en
			// estado notificado
			if (StringUtils.isBlank(vencimiento.getCveEstNotif()) || !vencimiento.getCveEstNotif().equalsIgnoreCase("N")) {
				throw new DataException("Liquidacion " + vencimiento.getLiqCodigo() + " con estado de notificacion incorrecto "
						+ vencimiento.getCveEstNotif() + ", posiblemente ya fue reportado");
			}
			
			vencimiento.setCveEstNotif("B");
			
			vencimiento = vencimientoQLBeanLocal.actualizarLiquidacion(vencimiento, observacion, "B", "WS");

			MensajeVenc mensajeVenc = new MensajeVenc();
			mensajeVenc.setCodLiq(codLiquidacion);
			mensajeVenc.setObservacion(observacion);
			mensajeVenc.setVencimiento(vencimiento);
			mensajeVencList.add(mensajeVenc);
			contRengs++;
		}
		
		logger.info("Fin ciclo de actualizacion de datos");
		
		Document doc1 = UtilesSiodex.generaDocXMLRespuesta(0, "1", "Consulta realizada existosamente, con " + contRengs
				+ " liquidaciones registradas");

		respuesta = XMLTools.DocumentToString(doc1);
		if (contRengs > 0) {
			for (MensajeVenc mensajeVenc : mensajeVencList) {
				Vencimiento vencimiento =  mensajeVenc.getVencimiento();
				
				vencimientoQLBeanLocal.enviarCorreos(vencimiento, mensajeVenc.getObservacion(), "VENCOBSERVADO", "WS");
				
			}
		}

		return respuesta;
	}

	public String enviarVencAutorizado(String codLiq, String tipoEnvio, String urlServ) throws DataException, FirmaException {
		logger.info("Ingresando a  enviarVencAutorizado " + codLiq);
		String xmlPago;
		StringBuilder respuestaXML = new StringBuilder();

		Vencimiento vencimiento = vencimientoQLBeanLocal.getVencimiento("", 0, codLiq);
		
		// el estado de la liquidacion debe ser O con operacion y debe existir
		// una solicitud creada con estado C contabilizado

		if (!vencimiento.getCveEstado().equalsIgnoreCase("C")) {
			throw new DataException("Liquidacion con estado incorrecto " + vencimiento.getCveEstado() + " debe ser 'C'");
		}

		if (!vencimiento.getCveEstNotif().equalsIgnoreCase("A")) {
//			throw new DataException("Liquidacion con estado [" + vencimiento.getCveEstNotif() + "] no autorizado por TGN");
		}
		Solicitud solicitud = solicitudQLBeanLocal.getSolicitudByCodLiq(vencimiento.getLiqCodigo(), "C");

		if (solicitud == null) {
			throw new DataException("Liquidacion " + vencimiento.getLiqCodigo() + " no tiene operacion-solicitud aprobada");
		}

		logger.info("solcitud encontrada: " + solicitud.toString());

		BigDecimal tipoCambTGN = vencimiento.getTipoCambioCont();

		logger.info("XXX: tipoCambTGN222 =  " + tipoCambTGN);

		List<LiquidacionDet> listaDet = vencimiento.getLiquidacionDetLista();

		for (LiquidacionDet liquidacionDet : listaDet) {
			logger.info("XXX: liquidacionDet " + liquidacionDet.getLiquidacionDetPK().getLiqDetalle());

			Moneda monedaC = monedaQLBeanLocal.getMonedaCoin(liquidacionDet.getMonSigade());
			
			Map<String, Object> montoConvertido = vencimientoQLBeanLocal.conversion(liquidacionDet.getCapitalMo(), monedaC.getMonCoin(),
					vencimiento.getMonedaCont(), vencimiento.getFechaTc(), "69", liquidacionDet.getTipoCambio());

			// para los montos del prestamo expresado en dolares 
			LiquidacionDet liquidacionDetSUS = new LiquidacionDet();
			// para los montos del prestamo expresado en bolivianos
			LiquidacionDet liquidacionDetBS = new LiquidacionDet();

			BigDecimal montosus = (BigDecimal) montoConvertido.get("montosus");
			BigDecimal montobs = (BigDecimal) montoConvertido.get("montobs");

			liquidacionDetSUS.setCapitalMo(montosus);
			liquidacionDetBS.setCapitalMo(montobs);

			montoConvertido = vencimientoQLBeanLocal.conversion(liquidacionDet.getInteresMo(), monedaC.getMonCoin(), vencimiento.getMonedaCont(),
					vencimiento.getFechaTc(), "69", liquidacionDet.getTipoCambio());

			montosus = (BigDecimal) montoConvertido.get("montosus");
			montobs = (BigDecimal) montoConvertido.get("montobs");

			liquidacionDetSUS.setInteresMo(montosus);
			liquidacionDetBS.setInteresMo(montobs);

			montoConvertido = vencimientoQLBeanLocal.conversion(liquidacionDet.getComisionMo(), monedaC.getMonCoin(), vencimiento.getMonedaCont(),
					vencimiento.getFechaTc(), "69",liquidacionDet.getTipoCambio());

			montosus = (BigDecimal) montoConvertido.get("montosus");
			montobs = (BigDecimal) montoConvertido.get("montobs");

			liquidacionDetSUS.setComisionMo(montosus);
			liquidacionDetBS.setComisionMo(montobs);

			// aqui setear tipo cambio a dolares
			xmlPago = ArmarXML.xmlPagoDet2(vencimiento, liquidacionDet, liquidacionDetSUS, liquidacionDetBS, tipoCambTGN);
			respuestaXML.append(xmlPago);
			logger.info("xmlPago Detalle " + xmlPago);
		}

		ComisionBancaria comisionBancariaCOPA = vencimiento.getComisionBancaria("COPA");

		BigDecimal comisionBancariaCOPAMN = BigDecimal.ZERO;
		if (comisionBancariaCOPA != null) {
			comisionBancariaCOPAMN = comisionBancariaCOPA.getMontoMN();
		}

		ComisionBancaria comisionBancariaSWFT = vencimiento.getComisionBancaria("SWFT");
		BigDecimal comisionBancariaSWFTMN = BigDecimal.ZERO;
		if (comisionBancariaSWFT != null) {
			comisionBancariaSWFTMN = comisionBancariaSWFT.getMontoMN();
		}

		ComisionBancaria comisionBancariaUTIL = vencimiento.getComisionBancaria("UTIL");
		BigDecimal comisionBancariaUTILMN = BigDecimal.ZERO;
		if (comisionBancariaUTIL != null) {
			comisionBancariaUTILMN = comisionBancariaUTIL.getMontoMN();
		}

		LiquidacionCuentas cope = liquidacionCuentasQLBeanLocal.getCuenta(vencimiento.getLiqCodigo(), "DEUD");
		if (cope == null) {
			throw new DataException("Cuenta de operaciones no se pudo encontrar " + vencimiento.getLiqCodigo());
		}
		LiquidacionCuentas lope = liquidacionCuentasQLBeanLocal.getCuenta(vencimiento.getLiqCodigo(), "LOPE");
		if (lope == null) {
			throw new DataException("Libreta de operaciones no se pudo encontrar " + vencimiento.getLiqCodigo());
		}

		LiquidacionCuentas ccom = liquidacionCuentasQLBeanLocal.getCuenta(vencimiento.getLiqCodigo(), "DEUC");
		if (ccom == null) {
			throw new DataException("cuenta de comisiones no se pudo encontrar " + vencimiento.getLiqCodigo());
		}

		LiquidacionCuentas lcom = liquidacionCuentasQLBeanLocal.getCuenta(vencimiento.getLiqCodigo(), "LCOM");
		if (lcom == null) {
			throw new DataException("Libreta de comisiones no se pudo encontrar " + vencimiento.getLiqCodigo());
		}

		String urlReporte = "";
		if (vencimiento.getDocPdf() != null) {

			urlReporte = urlReporte(urlServ, "REPCONFIRM", vencimiento.getLiqCodigo());
		}

		logger.info("Cuentas y libretas validadas " + vencimiento.getLiqCodigo());

		// convertimos los totales de la liq en bolivianos
		Liquidacion liquidacionBS = new Liquidacion();

		liquidacionBS.setCapitalUsd(vencimiento.getCapitalBs());
		liquidacionBS.setInteresUsd(vencimiento.getInteresBs());
		liquidacionBS.setComisionUsd(vencimiento.getComisionBs());

		Liquidacion liquidacionOld = liquidacionQLBeanLocal.getLiquidacion(vencimiento.getLiqCodigo());
		
		// liq confirmado
		liquidacionOld.setCveEstnotif("C");
		liquidacionOld.setUsrCodigo("TGN");
		liquidacionOld.setEstacion("WSTGN");
		liquidacionOld = liquidacionQLBeanLocal.cambioEstado(liquidacionOld, "", liquidacionOld.getCveEstado());

		String mensajeXML = ArmarXML.xmlPagoCab(vencimiento, liquidacionBS, tipoCambTGN, cope, lope, ccom, lcom, comisionBancariaCOPAMN,
				comisionBancariaSWFTMN, comisionBancariaUTILMN, respuestaXML.toString(), urlReporte);
		return mensajeXML;
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public Map<String, Object> procesarMensaje(Map<String, Object> parametros) {

		Map<String, Object> mapResult = new HashMap<String, Object>();
		String Id_error = null, des_error = null;
		String respuesta = null;
		String tipoOperacion = null;
		String SIODEX_PARAM = null;
		boolean firmarRespuesta = true;
		try {
			tipoOperacion = (String) parametros.get("tipooperacion");
			String urlServ = (String) parametros.get("urlServ");
			String codUsuario = (String) parametros.get("usuario");
			String estacion = (String) parametros.get("estacion");
			String tipoEnvio = (String) parametros.get("tipoEnvio");
			logger.info("~~~=========ooo000OInicio WS BCB[" + tipoOperacion + "]==========~~~ ");
			if (StringUtils.isBlank(tipoOperacion)) {
				throw new RuntimeException("parametro tipooperacion no definido, avise a sistemas");
			}

			SIODEX_PARAM = (String) parametros.get("SIODEX_PARAM");
			// userTransaction.begin();
			if (tipoOperacion.equals("NOTIFICAR_MSG_TGN_LOTE")) {
				firmarRespuesta = false;
				// consulta de liq publicadas
				String mensajeXML = consultaVencimientos(tipoOperacion, "P", urlServ, null, codUsuario, estacion);
				FirmaDig firmaDig = new FirmaDig();
				String msgXMLFirmado = firmaDig.firmarMensaje("", mensajeXML);
				// se envia el mensaje xml al tgn
				String respXMLTGN = ClientTGNWSHandler.exeRecepcionvencimientos(msgXMLFirmado);
				respuesta = respXMLTGN;
			} else if (tipoOperacion.equals("NOTIFICAR_MSG_TGN_LIQ")) {
				firmarRespuesta = false;
				String codigoLiq = (String) parametros.get("codigoLiq");
				// consulta de liq publicadas
				String mensajeXML = consultaVencimientos(tipoOperacion, "P", urlServ, codigoLiq, codUsuario, estacion);
				FirmaDig firmaDig = new FirmaDig();
				String msgXMLFirmado = firmaDig.firmarMensaje("", mensajeXML);
				// se envia el mensaje xml al tgn
				String respXMLTGN = ClientTGNWSHandler.exeRecepcionvencimientos(msgXMLFirmado);
				respuesta = respXMLTGN;
			} else if (tipoOperacion.equals("AUTORIZAR_MSG_TGN_LIQ")) {
				firmarRespuesta = false;
				String codigoLiq = (String) parametros.get("codigoLiq");
				// tipoEnvio sin uso define el tipo del calculo si es por
				// tramito o por el total
				// codigoLiq = "003019";
				String mensajeXML = enviarVencAutorizado(codigoLiq, tipoEnvio, urlServ);
				FirmaDig firmaDig = new FirmaDig();
				String msgXMLFirmado = firmaDig.firmarMensaje("", mensajeXML);

				if (msgXMLFirmado != null) {
					// throw new
					// RuntimeException("eeeeeeeerrrrrrrrrrrrrorrrrrrrrrrrrrrr");
				}

				// mensajeXML = "aaaaaaaaaa";
				// se envia el mensaje xml de los confirmados al tgn
				String respXMLTGN = ClientTGNWSHandler.exeRecepcionConfirmacion(msgXMLFirmado);

				respuesta = respXMLTGN;
			} else if (tipoOperacion.equals("NOTIFOBSERVADOS_MSG_TGN_LOTE")) {
				firmarRespuesta = false;
				String mensajeXML = consultaVencimientos(tipoOperacion, "P", urlServ, null, codUsuario, estacion);
				// se envia el mensaje xml al tgn
				FirmaDig firmaDig = new FirmaDig();
				String msgXMLFirmado = firmaDig.firmarMensaje("", mensajeXML);
				String respXMLTGN = ClientTGNWSHandler.exeRecepcionCorrecciones(msgXMLFirmado);
				respuesta = respXMLTGN;

			} else if (tipoOperacion.equals("NOTIFOBSERVADOS_MSG_TGN_LIQ")) {
				firmarRespuesta = false;
				String codigoLiq = (String) parametros.get("codigoLiq");
				String mensajeXML = consultaVencimientos(tipoOperacion, "P", urlServ, codigoLiq, codUsuario, estacion);
				// se envia el mensaje xml al tgn
				FirmaDig firmaDig = new FirmaDig();
				String msgXMLFirmado = firmaDig.firmarMensaje("", mensajeXML);
				String respXMLTGN = ClientTGNWSHandler.exeRecepcionCorrecciones(msgXMLFirmado);
				respuesta = respXMLTGN;

			} else if (tipoOperacion.equals("PROCESARVENCAUTORIZADOS")) {

				String mensaje = (String) parametros.get("mensaje");
				// String a =
				// "<respuesta><ID>5</ID><Fecha>20131127</Fecha><totalReg>5</totalReg><Autorizados><Autorizado><codigo>003751</codigo><prestamo>123000</prestamo><estado>A</estado><observacion/><cuentaServicio>5970034001</cuentaServicio><libretaServicio>00990201009</libretaServicio><cuentaComisiones>3987069001</cuentaComisiones><libretaComisiones>00990201001</libretaComisiones></Autorizado><Autorizado><codigo>003764</codigo><prestamo>130000A</prestamo><estado>A</estado><observacion/><cuentaServicio>5970034001</cuentaServicio><libretaServicio>00990201009</libretaServicio><cuentaComisiones>3987069001</cuentaComisiones><libretaComisiones>00990201001</libretaComisiones></Autorizado><Autorizado><codigo>003766</codigo><prestamo>130000</prestamo><estado>A</estado><observacion/><cuentaServicio>5970034001</cuentaServicio><libretaServicio>00990201009</libretaServicio><cuentaComisiones>3987069001</cuentaComisiones><libretaComisiones>00990201001</libretaComisiones></Autorizado><Autorizado><codigo>003775</codigo><prestamo>B-H-143</prestamo><estado>A</estado><observacion/><cuentaServicio>3987069001</cuentaServicio><libretaServicio>00990201001</libretaServicio><cuentaComisiones>3987069001</cuentaComisiones><libretaComisiones>00990201001</libretaComisiones></Autorizado><Autorizado><codigo>003842</codigo><prestamo>1005000</prestamo><estado>A</estado><observacion/><cuentaServicio>5970034001</cuentaServicio><libretaServicio>00990201009</libretaServicio><cuentaComisiones>3987069001</cuentaComisiones><libretaComisiones>00990201001</libretaComisiones></Autorizado></Autorizados></respuesta>";
				// borrar
				// respuesta = vencimientosAutorizados(a);
				respuesta = vencimientosAutorizados(mensaje);
				// String a =
				// "<respuesta><ID>5</ID><Fecha>20131127</Fecha><totalReg>5</totalReg><Autorizados><Autorizado><codigo>003751</codigo><prestamo>123000</prestamo><estado>A</estado><observacion/><cuentaServicio>5970034001</cuentaServicio><libretaServicio>00990201009</libretaServicio><cuentaComisiones>3987069001</cuentaComisiones><libretaComisiones>00990201001</libretaComisiones></Autorizado><Autorizado><codigo>003764</codigo><prestamo>130000A</prestamo><estado>A</estado><observacion/><cuentaServicio>5970034001</cuentaServicio><libretaServicio>00990201009</libretaServicio><cuentaComisiones>3987069001</cuentaComisiones><libretaComisiones>00990201001</libretaComisiones></Autorizado><Autorizado><codigo>003766</codigo><prestamo>130000</prestamo><estado>A</estado><observacion/><cuentaServicio>5970034001</cuentaServicio><libretaServicio>00990201009</libretaServicio><cuentaComisiones>3987069001</cuentaComisiones><libretaComisiones>00990201001</libretaComisiones></Autorizado><Autorizado><codigo>003775</codigo><prestamo>B-H-143</prestamo><estado>A</estado><observacion/><cuentaServicio>3987069001</cuentaServicio><libretaServicio>00990201001</libretaServicio><cuentaComisiones>3987069001</cuentaComisiones><libretaComisiones>00990201001</libretaComisiones></Autorizado><Autorizado><codigo>003842</codigo><prestamo>1005000</prestamo><estado>A</estado><observacion/><cuentaServicio>5970034001</cuentaServicio><libretaServicio>00990201009</libretaServicio><cuentaComisiones>3987069001</cuentaComisiones><libretaComisiones>00990201001</libretaComisiones></Autorizado></Autorizados></respuesta>";
				// respuesta = vencimientosAutorizados(a);

			} else if (tipoOperacion.equals("PROCESARVENCOBSERVADOS")) {

				String mensaje = (String) parametros.get("mensaje");
				respuesta = vencimientosObservados(mensaje);

			} else {
				throw new RuntimeException("Opcion no implementada");
			}

			Id_error = "0";// e.getMessage().substring(0, 4);
			des_error = "Operacion efectuada exitosamente";

			if (firmarRespuesta) {
				FirmaDig firmaDig = new FirmaDig();
				respuesta = firmaDig.firmarMensaje("", respuesta);
			}
		} catch (DataException e) {
			Id_error = "-1";// e.getMessage().substring(0, 4);
			des_error = e.getMessage();
			logger.error(e.getMessage(), e);
			sessionContext.setRollbackOnly();
		} catch (EJBException e) {
			logger.error("Persistencia: " + e.getMessage(), e);
			StringBuilder sb = new StringBuilder();
			int count = 0;
			for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
				if (cause instanceof SQLException) {
					count++;
					sb.append(cause.getMessage());
					sb.append(" , ");
				}
			}
			des_error = (count > 0 ? sb.toString().replace(", null ,", "") : e.getMessage().replace(", null ,", ""));
			Id_error = "-1";
			sessionContext.setRollbackOnly();
		} catch (PersistenceException e) {
			logger.error("Persistencia: " + e.getMessage(), e);
			StringBuilder sb = new StringBuilder();
			int count = 0;
			for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
				if (cause instanceof SQLException) {
					count++;
					sb.append(cause.getMessage());
					sb.append(" , ");
				}
			}
			des_error = (count > 0 ? sb.toString().replace(", null ,", "") : e.getMessage().replace(", null ,", ""));
			Id_error = "-1";
			sessionContext.setRollbackOnly();
		} catch (NullPointerException e) {
			Id_error = "-1";// e.getMessage().substring(0, 4);
			des_error = e.getMessage();
			logger.error(e.getMessage(), e);
			sessionContext.setRollbackOnly();
		} catch (FirmaException e) {
			Id_error = "-1";// e.getMessage().substring(0, 4);
			des_error = e.getMessage();
			logger.error(e.getMessage(), e);
			sessionContext.setRollbackOnly();
		} catch (SOAPException e) {
			Id_error = "-1";// e.getMessage().substring(0, 4);
			des_error = e.getMessage();
			logger.error(e.getMessage(), e);
			sessionContext.setRollbackOnly();
		} catch (XMLException e) {
			Id_error = "-1";// e.getMessage().substring(0, 4);
			des_error = e.getMessage();
			logger.error(e.getMessage(), e);
			sessionContext.setRollbackOnly();
		} catch (VerificaException e) {
			Id_error = "-1";// e.getMessage().substring(0, 4);
			des_error = e.getMessage();
			logger.error(e.getMessage(), e);
			sessionContext.setRollbackOnly();
		} catch (RuntimeException e) {
			Id_error = "-1";// e.getMessage().substring(0, 4);
			des_error = e.getMessage();
			logger.error(e.getMessage(), e);
			sessionContext.setRollbackOnly();
		} catch (Exception e) {
			Id_error = "-1";// e.getMessage().substring(0, 4);
			des_error = e.getMessage();
			logger.error(e.getMessage(), e);
			sessionContext.setRollbackOnly();
		} catch (Throwable e) {
			Id_error = "-1";// e.getMessage().substring(0, 4);
			des_error = e.getMessage();
			logger.error(e.getMessage(), e);
			sessionContext.setRollbackOnly();
		} finally {
			logger.info("Error: [" + Id_error + "] " + des_error);
			try {
				if (Id_error == null || des_error == null || des_error.trim().isEmpty()) {
					logger.warn("El sistema retorna ningÃƒÂºn mensaje de respuesta de las operaciones");
					Id_error = "-1";
					des_error = "Error interno: no existe una respuesta del servicio ni mensaje de excepcion, comunique a sistemas";
				}
				if (Id_error.equals("-1")) {
					respuesta = des_error;
				}

				if (Id_error.equals("-1") && firmarRespuesta) {
					Document doc1 = UtilesSiodex.generaDocXMLRespuesta(0, Id_error, des_error);
					respuesta = XMLTools.DocumentToString(doc1);
					FirmaDig firmaDig = new FirmaDig();
					respuesta = firmaDig.firmarMensaje("", respuesta);
				}
				mapResult.put("cod_resp", Id_error);
			} catch (Exception e) {
				logger.fatal("Error al finalizar(0) proceso :" + e.getMessage());
			} catch (Throwable e) {
				logger.fatal("Error al finalizar(1) proceso :" + e.getMessage());
			}
		}
		mapResult.put("respuesta", respuesta);
		mapResult.put("des_error", des_error);
		logger.info("=========ooOO0Respuesta0OOoo========== ");
		logger.info(respuesta);
		logger.info("~~~=========ooo000OFin WS BCB[" + tipoOperacion + "]==========~~~ ");
		return mapResult;
	}

	public static String urlReporte(String urlServ, String tipo, String codLiq) {
		Map<String, String> map = new LinkedHashMap<String, String>();
		map.put("cod", codLiq);
		map.put("tipo", tipo);

		String encode = CadenaEncDec.encode(map);
		String urlReporte = urlServ + "/reporte?codRepo=" + encode;
		logger.info("UrlReporte codificado [" + ArrayUtils.toString(map) + "] " + urlReporte);

		return urlReporte;
	}

	static StringBuilder cadenapru = new StringBuilder();
	static {

		cadenapru.append("<respuesta>                                                     ");
		cadenapru.append("	<ID>1</ID>                                                  ");
		cadenapru.append("	<Fecha>20130717</Fecha>                                     ");
		cadenapru.append("	<totalReg>2</totalReg>                                      ");
		cadenapru.append("	<Autorizados>                                               ");
		cadenapru.append("		<Autorizado>                                            ");
		cadenapru.append("			<codigo>00336501</codigo>                           ");
		cadenapru.append("			<prestamo>17000</prestamo>                         ");
		cadenapru.append("			<tramo>1</tramo>                                    ");
		cadenapru.append("			<estado>A</estado>                                  ");
		cadenapru.append("			<observacion>NINGUNA</observacion>                  ");
		cadenapru.append("			<cuentaServicio>3987069001</cuentaServicio>         ");
		cadenapru.append("			<libretaServicio>00890508003</libretaServicio>      ");
		cadenapru.append("			<cuentaComisiones>3987069001</cuentaComisiones>     ");
		cadenapru.append("			<libretaComisiones>00660104201</libretaComisiones>  ");
		cadenapru.append("		</Autorizado>                                           ");
		cadenapru.append("		<Autorizado>                                            ");
		cadenapru.append("			<codigo>00336801</codigo>                           ");
		cadenapru.append("			<prestamo>1040005</prestamo>                         ");
		cadenapru.append("			<tramo>1</tramo>                                    ");
		cadenapru.append("			<estado>A</estado>                                  ");
		cadenapru.append("			<observacion>NINGUNA</observacion>                  ");
		cadenapru.append("			<cuentaServicio>3987069001</cuentaServicio>         ");
		cadenapru.append("			<libretaServicio>00410101101</libretaServicio>      ");
		cadenapru.append("			<cuentaComisiones>3987069001</cuentaComisiones>     ");
		cadenapru.append("			<libretaComisiones>00810104301</libretaComisiones>  ");
		cadenapru.append("		</Autorizado>                                           ");
		cadenapru.append("	</Autorizados>                                              ");
		cadenapru.append("</respuesta> 													");
	}
}
