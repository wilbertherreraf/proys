package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.exception.DataException;

import javax.ejb.Local;

/**
 * Created by eborda on 16/02/2017.
 */
@Local
public interface ReferenciaQLBeanLocal {
    /**
     *
     * @return
     */


    Object[] nativo(String query);

    Object[] getRefDefinicion(String refCodigo) throws DataException;
}
