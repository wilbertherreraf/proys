package gob.bcb.jee.siodex.WS;

import gob.bcb.core.seguridad.commons.xml.BcbXmlSignature;
import gob.bcb.core.seguridad.commons.xml.BcbXmlUtils;
import gob.bcb.core.seguridad.commons.xml.KeyStoreInfo;
import gob.bcb.jee.siodex.commons.ConfigurationServ;
import gob.bcb.jee.siodex.commons.Constants;
import gob.bcb.jee.siodex.exception.FirmaException;
import gob.bcb.jee.siodex.exception.VerificaException;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.apache.xml.security.exceptions.XMLSecurityException;
import org.apache.xml.security.signature.XMLSignature;
import org.apache.xml.security.signature.XMLSignatureException;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

public class FirmaDig {
	static final Logger logger = Logger.getLogger(FirmaDig.class);

	public String firmarMensaje(String rutaBase, String mensaje) throws FirmaException {
		logger.info("Firmando mensaje ... \n " + mensaje);

		// Firmar el documento digitalmente
		if (!rutaBase.endsWith(File.separator)) {
			rutaBase = rutaBase + File.separator;
		}

		String keystoreType = "JKS";
		String keystoreFile = ConfigurationServ.getConfigProperty(Constants.PROP_BCB_KEY_STORE_FILE); // "/opt/certificados/sigmaSiodex/cecilia.jks";
		String keystorePass = ConfigurationServ.getConfigProperty(Constants.PROP_BCB_KEY_STORE_PASS); // "12345678";
		String privateKeyAlias = ConfigurationServ.getConfigProperty(Constants.PROP_BCB_PRIVATE_KEY_ALIAS);// "bcb";
		String privateKeyPass = ConfigurationServ.getConfigProperty(Constants.PROP_BCB_PRIVATE_KEY_PASS); // "12345678";
		String certificateAlias = ConfigurationServ.getConfigProperty(Constants.PROP_BCB_CERTIFICATE_ALIAS); // "bcb";
		try {
			KeyStoreInfo generalPrivateKey = new KeyStoreInfo(keystoreType, keystoreFile, keystorePass, privateKeyAlias, privateKeyPass,
					certificateAlias);

			Document document = XmlUtil.getDomFromString(mensaje);

			BcbXmlSignature signer = BcbXmlSignature.Factory.getDafaultSignature();

			Document signEnveloping = null;

			signEnveloping = signer.signEnveloping(document, generalPrivateKey, "900");

			String mensajeFirmado = null;

			mensajeFirmado = XmlUtil.getStringFromDom(signEnveloping);
			logger.info("Mensaje firmado exitÃƒÂ³samente");
			return mensajeFirmado;
		} catch (ParserConfigurationException e) {
			logger.error("Error al fimar XML: " + e.getMessage(), e);
			throw new FirmaException("Error al fimar XML: " + e.getMessage());
		} catch (SAXException e) {
			logger.error("Error al fimar XML: " + e.getMessage(), e);
			throw new FirmaException("Error al fimar XML: " + e.getMessage());
		} catch (IOException e) {
			logger.error("Error al fimar XML: " + e.getMessage(), e);
			throw new FirmaException("Error al fimar XML: " + e.getMessage());
		} catch (TransformerException e) {
			logger.error("Error al fimar XML: " + e.getMessage(), e);
			throw new FirmaException("Error al fimar XML: " + e.getMessage());
		} catch (Exception e) {
			logger.error("Error al fimar XML: " + e.getMessage(), e);
			throw new FirmaException("Error al fimar XML: " + e.getMessage());
		}

	}

	public boolean verify(Document xmlFile, KeyStoreInfo ksi) throws VerificaException {
		String keystoreType = "JKS";
		String keystoreFile = ConfigurationServ.getConfigProperty(Constants.PROP_TGN_KEY_STORE_FILE); // "/opt/certificados/sigmaSiodex/client.jks";
		String keystorePass = ConfigurationServ.getConfigProperty(Constants.PROP_TGN_KEY_STORE_PASS); // "123456";
		String privateKeyAlias = ConfigurationServ.getConfigProperty(Constants.PROP_TGN_PRIVATE_KEY_ALIAS);// "client";
		String privateKeyPass = ConfigurationServ.getConfigProperty(Constants.PROP_TGN_PRIVATE_KEY_PASS); // "123456";
		String certificateAlias = ConfigurationServ.getConfigProperty(Constants.PROP_TGN_CERTIFICATE_ALIAS); // "server";

		logger.info("verificando mensaje " + xmlFile.getDocumentElement().getTagName());
		ksi = new KeyStoreInfo(keystoreType, keystoreFile, keystorePass, privateKeyAlias, privateKeyPass, certificateAlias);
		boolean verification = false;

		try {
			Element nscontext = BcbXmlUtils.createDSctx(xmlFile, "ds", org.apache.xml.security.utils.Constants.SignatureSpecNS);
			Element sigElement;

			sigElement = (Element) XPathAPI.selectSingleNode(xmlFile, "//ds:Signature[1]", nscontext);
			XMLSignature signature = new XMLSignature(sigElement, null);

			PublicKey publicKey = getPublicKey(ksi);

			if (publicKey != null) {
				verification = signature.checkSignatureValue(publicKey);
			}
			logger.info("The XML signature in file " + xmlFile.getDocumentElement().getTagName() + " is "
					+ (verification ? "valid (good)" : "invalid !!!!! (bad)"));
			if (!verification) {
				throw new XMLSignatureException("Firma invalida");
			}
			return verification;
		} catch (TransformerException e) {
			logger.error("Error al Verificar fima digital: " + e.getMessage(), e);
			throw new VerificaException("Error al Verificar fima digital: " + e.getMessage());
		} catch (KeyStoreException e) {
			logger.error("Error al Verificar fima digital: " + e.getMessage(), e);
			throw new VerificaException("Error al Verificar fima digital: " + e.getMessage());
		} catch (NoSuchAlgorithmException e) {
			logger.error("Error al Verificar fima digital: " + e.getMessage(), e);
			throw new VerificaException("Error al Verificar fima digital: " + e.getMessage());
		} catch (CertificateException e) {
			logger.error("Error al Verificar fima digital: " + e.getMessage(), e);
			throw new VerificaException("Error al Verificar fima digital: " + e.getMessage());
		} catch (IOException e) {
			logger.error("Error al Verificar fima digital: " + e.getMessage(), e);
			throw new VerificaException("Error al Verificar fima digital: " + e.getMessage());
		} catch (XMLSignatureException e) {
			logger.error("Error al Verificar fima digital: " + e.getMessage(), e);
			throw new VerificaException("Error al Verificar fima digital: " + e.getMessage());
		} catch (XMLSecurityException e) {
			logger.error("Error al Verificar fima digital: " + e.getMessage(), e);
			throw new VerificaException("Error al Verificar fima digital: " + e.getMessage());
		}
	}

	private PublicKey getPublicKey(KeyStoreInfo ksi) throws KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException {
		KeyStore ks = KeyStore.getInstance(ksi.getKeystoreType());
		FileInputStream fis = new FileInputStream(ksi.getKeystoreFile());
		ks.load(fis, ksi.getKeystorePass().toCharArray());
		X509Certificate cert = (X509Certificate) ks.getCertificate(ksi.getCertificateAlias());

		return cert.getPublicKey();
	}

}