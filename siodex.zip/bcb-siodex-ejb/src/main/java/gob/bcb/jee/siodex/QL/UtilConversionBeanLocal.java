package gob.bcb.jee.siodex.QL;

import javax.ejb.Local;

@Local
public interface UtilConversionBeanLocal {

}
