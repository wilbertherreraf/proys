package gob.bcb.jee.siodex.util;

import gob.bcb.jee.siodex.exception.InternaException;
import gob.bcb.jee.siodex.exception.MsgErr;
import gob.bcb.jee.siodex.mefp.LiquidacionCuentasQLBean;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.log4j.Logger;

public class UtilsFile {
	static final Logger log = Logger.getLogger(UtilsFile.class);
    /**
     * Metodo para convertir de InputStream to String
     * @param in Entrada de tipo InputStream
     * @throws java.io.IOException Lanza una excepcion de tipo IO
     * @return Cadena XML
     */
    public static String isToString (InputStream in) throws IOException {
        StringBuffer out = new StringBuffer();
        byte[] b = new byte[4096];
        for (int n; (n = in.read(b)) != -1;) {
            out.append(new String(b, 0, n));
        }
        return out.toString();
    }

    /**
     * Metodo para registrar un archivo de salida
     * @param mensaje Cadena de caracteres (string) que se desea grabar como archivo
     * @param path Cadena que representa el directorio donde se grabara el string
     * @throws InternaException Excepción de tipo INTERNO
     */    
    public void grabaEnArchivo(String mensaje, String path) throws InternaException{
        try{
            FileOutputStream archResp = new FileOutputStream(path);
            byte buffer[] = mensaje.getBytes("ISO-8859-1");
            archResp.write(buffer);
            archResp.close();
        }catch (IOException exE){
            InternaException dataEx = new InternaException(MsgErr.getMessage("I012"));
            log.info("Error: " + exE.getMessage());
            dataEx.initCause(exE.getCause());
            dataEx.setStackTrace(exE.getStackTrace());
            throw dataEx;
        }
    }
    
}
