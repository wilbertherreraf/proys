package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.LoanTrancheSummary;
import gob.bcb.jee.siodex.exception.DataException;
import gob.bcb.jee.siodex.pojos.VcDatosAdic;

import java.util.List;

import javax.ejb.Local;

@Local
public interface DAQLBeanLocal {

	/**
	 * 
	 * @return
	 */
	Object[] nativo(String query);
	Object obtieneValorConsulta(String query);
	Integer nativoSimple(String query);
	public List<LoanTrancheSummary> prestamosByEntidad(String codEntidad);
	public List<VcDatosAdic> obtenerResumenDatGrales(String prestamo, Integer tramo)throws DataException ;
}
