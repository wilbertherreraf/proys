package gob.bcb.jee.siodex.service;

import java.util.Date;
import java.util.List;

import gob.bcb.contabilidad.pojo.RastroContablePojo;

import javax.ejb.Local;

@Local
public interface ConsultaBeanLocal {

	/**
	 * 
	 * @param men
	 * @return
	 * @throws Exception 
	 */
	public List<RastroContablePojo> obtenerRastroContable(Date fecha) throws Exception;
	// whf 01
	public RastroContablePojo obtenerRastroContable(Date fecha, Integer nroOperacion) throws Exception;
	
}
