package gob.bcb.jee.siodex.QL;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import gob.bcb.jee.siodex.entities.LiquidacionPago;
import gob.bcb.jee.siodex.entities.LiquidacionPagoPK;

@Stateless
@LocalBean
public class LiquidacionPagoQLBean extends DaoGeneric<LiquidacionPago> implements LiquidacionPagoQLBeanLocal {
	static final Logger logger = Logger.getLogger(LiquidacionPagoQLBean.class);

	@PersistenceContext(unitName = "siodex")
	EntityManager em;

	public LiquidacionPagoQLBean() {
		super(LiquidacionPago.class);
	}

	public LiquidacionPago getLiquidacionPago(String codigo, String cveCodigopago) {

		LiquidacionPago liqEstado = null;

		StringBuilder query = new StringBuilder();

		query.append("select l from LiquidacionPago l where l.id.liqCodigo = :liqCodigo and l.id.cveCodigopago = :cveCodigopago ");

		Query consulta = em.createQuery(query.toString());
		consulta.setParameter("liqCodigo", codigo);
		consulta.setParameter("cveCodigopago", cveCodigopago);

		List lista = consulta.getResultList();
		if (lista.size() > 0) {
			return (LiquidacionPago) lista.get(0);
		}

		return liqEstado;

	}

	public LiquidacionPago actualizar(String liqCodigo, String cveCodigopago, BigDecimal valor,String codMoneda, String cveTipodetpago, 
			Date fechaCont, Date fechaReg, String usrCodigo, String estacion) {

		LiquidacionPagoPK liquidacionPagoPK = new LiquidacionPagoPK();
		liquidacionPagoPK.setLiqCodigo(liqCodigo);
		liquidacionPagoPK.setCveCodigopago(cveCodigopago);
		
		
		LiquidacionPago liquidacionPagoNew = new LiquidacionPago();
		liquidacionPagoNew.setId(liquidacionPagoPK);
		
		liquidacionPagoNew.setValor(valor);
		liquidacionPagoNew.setCodMoneda(codMoneda);
		liquidacionPagoNew.setCveTipodetpago(cveTipodetpago);
		liquidacionPagoNew.setFechaReg(fechaReg);
		liquidacionPagoNew.setFechaCont(fechaCont);

		liquidacionPagoNew.setEstacion(estacion);

		liquidacionPagoNew.setUsrCodigo(usrCodigo);
		
		
		return actualizar(liquidacionPagoNew);
	}

	public LiquidacionPago actualizar(LiquidacionPago liquidacionPago) {
		LiquidacionPago liquidacionPagoNew = getLiquidacionPago(liquidacionPago.getId().getLiqCodigo(), liquidacionPago.getId().getCveCodigopago());

		if (liquidacionPagoNew == null) {
			liquidacionPago.setFechaHora(new Date());
			create(liquidacionPago);
		} else {
			liquidacionPago.setFechaHora(new Date());			
			edit(liquidacionPago);
		}

		
		return liquidacionPago;
	}

	@Override
	public void setEntityManager(EntityManager entityManager) {

	}

	@Override
	public EntityManager getEntityManager() {
		// TODO Auto-generated method stub
		return em;
	}

}
