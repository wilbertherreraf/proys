package gob.bcb.jee.siodex.entities;

import gob.bcb.jee.siodex.pojos.VcDatosAdic;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

/**
 * 
 * @author CUriona
 */

@SuppressWarnings("serial")
public class Vencimiento implements java.io.Serializable {
	static final Logger logger = Logger.getLogger(Vencimiento.class);
	private String liqCodigo;
	private String ptmCodigo;
	private int traCodigo;
	// datos contables
	private BigDecimal capital;
	private BigDecimal interes;
	private BigDecimal comision;
	private BigDecimal total;
	/**
	 * moneda en la cual se contabiliza 69 o 34
	 */
	private String monedaCont;	
	private String monedaContDesc;	
	
	private BigDecimal capitalMO;
	private BigDecimal interesMO;
	private BigDecimal comisionMO;	
	private BigDecimal capitalUsd;
	private BigDecimal interesUsd;
	private BigDecimal comisionUsd;
	private BigDecimal capitalBs;
	private BigDecimal interesBs;
	private BigDecimal comisionBs;	
	/**
	 * fecha de tipo de cambio de la liquidacion
	 */
	private Date fechaTc;
	private Date fechaPago;	
	/**
	 * fecha de tipo de calculo de la operacion gralmente es la de hoy
	 */
	private String cveEstado;
	private String cveEstadoDescrip;
	private String cveEstNotif;
	private String cveEstNotifDescrip;
	private Integer lote;
	private Date fechaVenc;
	private String codTipoOperacion;	
	private String prestamo;
	private String refAcre;
	private String acreedor;
	private String deudor;
	private String referencia;	
	
	/**
	 * moneda sigade
	 */
	private String moneda;
	/**
	 * tipo cambio contable que representa con el cual se expresa el total de la transacc debería ser valor de moneda 69 o 34
	 */
	private BigDecimal tipoCambioCont;	

	private boolean variasMonedas = false;
	private Integer cantMensSwift = 0;	
	private BigDecimal totalMO;	
	private BigDecimal totalUsd;
	private BigDecimal totalBs;	
	
	private String usuario;
	//codigo de la institucion participante de la liquidacion
	// codigo de la inst. deudora que pertenece la liquidacion
	private String codPartLiquidacion;
	private String codPartLiquidacionDesc;	
	private String observacion;
	
	private LogAuditoria logAuditoria = new LogAuditoria();
	private byte[] docPdf;
	private Map<String, ComisionBancaria> comisionesBancarias = new HashMap<String, ComisionBancaria>();
	private Map<String, Cuenta> cuentasPrestamo = new HashMap<String, Cuenta>();

	private Boolean actualizado = false;
	private Boolean monSDR = false;
	private List<LiquidacionDet> liquidacionDetLista = new ArrayList<LiquidacionDet>();
	private VcDatosAdic vcDatosAdic;
	public Vencimiento() {
		inicializa();
		vcDatosAdic = new VcDatosAdic();
	}

	public Vencimiento(String liqCodigo, String ptmCodigo, int traCodigo, BigDecimal capitalUsd, BigDecimal interesUsd, BigDecimal comisionUsd,
			Date fechaTc, String cveEstado, Date fechaVenc, String prestamo, String refAcre, String acreedor, String deudor, BigDecimal totalUsd,
			String usuario, byte[] docPdf) {
		this();
		this.liqCodigo = liqCodigo;
		this.ptmCodigo = ptmCodigo;
		this.traCodigo = traCodigo;
		this.capitalUsd = capitalUsd;
		this.interesUsd = interesUsd;
		this.comisionUsd = comisionUsd;
		this.fechaTc = fechaTc;
		// por defecto inicializamos a fecha registrada en liquidacion
		//this.fechaOperacion = fechaTc;
		this.cveEstado = cveEstado;
		this.fechaVenc = fechaVenc;
		this.prestamo = prestamo;
		this.refAcre = refAcre;
		this.acreedor = acreedor;
		this.deudor = deudor;
		this.totalUsd = totalUsd;
		this.usuario = usuario;
		this.docPdf = docPdf;
	}

	public void inicializa(){
		setCapital(BigDecimal.ZERO);
		setInteres(BigDecimal.ZERO);
		setComision(BigDecimal.ZERO);

		setCapitalBs(BigDecimal.ZERO);
		setInteresBs(BigDecimal.ZERO);
		setComisionBs(BigDecimal.ZERO);

		setCapitalUsd(BigDecimal.ZERO);
		setInteresUsd(BigDecimal.ZERO);
		setComisionUsd(BigDecimal.ZERO);

		setCapitalMO(BigDecimal.ZERO);
		setInteresMO(BigDecimal.ZERO);
		setComisionMO(BigDecimal.ZERO);

		setTotal(BigDecimal.ZERO);
		setTotalBs(BigDecimal.ZERO);
		setTotalUsd(BigDecimal.ZERO);
		setTotalMO(BigDecimal.ZERO);
		
	}
	public String getLiqCodigo() {
		return liqCodigo;
	}

	public void setLiqCodigo(String liqCodigo) {
		this.liqCodigo = liqCodigo;
	}

	public String getPtmCodigo() {
		return ptmCodigo;
	}

	public void setPtmCodigo(String ptmCodigo) {
		this.ptmCodigo = ptmCodigo;
	}

	public int getTraCodigo() {
		return traCodigo;
	}

	public void setTraCodigo(int traCodigo) {
		this.traCodigo = traCodigo;
	}

	public BigDecimal getCapitalUsd() {
		return capitalUsd;
	}

	public void setCapitalUsd(BigDecimal capitalUsd) {
		this.capitalUsd = capitalUsd;
	}

	public BigDecimal getInteresUsd() {
		return interesUsd;
	}

	public void setInteresUsd(BigDecimal interesUsd) {
		this.interesUsd = interesUsd;
	}

	public BigDecimal getComisionUsd() {
		return comisionUsd;
	}

	public void setComisionUsd(BigDecimal comisionUsd) {
		this.comisionUsd = comisionUsd;
	}

	public Date getFechaTc() {
		return fechaTc;
	}

	public void setFechaTc(Date fechaTc) {
		this.fechaTc = fechaTc;
	}

	public String getCveEstado() {
		return cveEstado;
	}

	public void setCveEstado(String cveEstado) {
		this.cveEstado = cveEstado;
	}

	public Date getFechaVenc() {
		return fechaVenc;
	}

	public void setFechaVenc(Date fechaVenc) {
		this.fechaVenc = fechaVenc;
	}

	public String getPrestamo() {
		return prestamo;
	}

	public void setPrestamo(String prestamo) {
		this.prestamo = prestamo;
	}

	public String getRefAcre() {
		return refAcre;
	}

	public void setRefAcre(String refAcre) {
		this.refAcre = refAcre;
	}

	public String getAcreedor() {
		return acreedor;
	}

	public void setAcreedor(String acreedor) {
		this.acreedor = acreedor;
	}

	public String getDeudor() {
		return deudor;
	}

	public void setDeudor(String deudor) {
		this.deudor = deudor;
	}

	public BigDecimal getTotalUsd() {
		return totalUsd;
	}

	public void setTotalUsd(BigDecimal totalUsd) {
		this.totalUsd = totalUsd;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public byte[] getDocPdf() {
		return docPdf;
	}

	public void setDocPdf(byte[] docPdf) {
		this.docPdf = docPdf;
	}

	public String getCveEstadoDescrip() {
		return cveEstadoDescrip;
	}

	public void setCveEstadoDescrip(String cveEstadoDescrip) {
		this.cveEstadoDescrip = cveEstadoDescrip;
	}

	public String getCveEstNotif() {
		return cveEstNotif;
	}

	public void setCveEstNotif(String cveEstNotif) {
		this.cveEstNotif = cveEstNotif;
	}

	public String getCveEstNotifDescrip() {
		return cveEstNotifDescrip;
	}

	public void setCveEstNotifDescrip(String cveEstNotifDescrip) {
		this.cveEstNotifDescrip = cveEstNotifDescrip;
	}

	public Integer getLote() {
		return lote;
	}

	public void setLote(Integer lote) {
		this.lote = lote;
	}

	public String getObservacion() {
		return observacion;
	}

	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}

	public String getCodPartLiquidacion() {
		return codPartLiquidacion;
	}

	public void setCodPartLiquidacion(String codPartLiquidacion) {
		this.codPartLiquidacion = codPartLiquidacion;
	}

	/**
	 * retorna el log auditoria actualizado
	 * 
	 * @return
	 */
	public LogAuditoria getLogAuditoria() {
		logAuditoria.setCodTransaccion(liqCodigo);
		logAuditoria.setLogAuditoriaId(0);
		logAuditoria.setFechaHora(new Date());
		return logAuditoria;
	}

	public void crearLogAuditoria(String codUsuario, String codParticipante, String estacion, String codTransaccion) {
		this.usuario = codUsuario;

		LogAuditoria logAuditoria = new LogAuditoria();
		logAuditoria.setLogAuditoriaId(0);
		logAuditoria.setCodUsuario(codUsuario);
		logAuditoria.setEstacion(estacion);
		logAuditoria.setCodTransaccion(codTransaccion);
		logAuditoria.setFechaHora(new Date());

		this.logAuditoria = logAuditoria;
	}

	/**
	 * SETEA logauditoria y cod participante generalmente proveniente de la
	 * vista recuperado de visit
	 * 
	 * @param logAuditoria
	 * @param codParticipante
	 */
	public void setLogAuditoria(LogAuditoria logAuditoria, String codParticipante) {
		this.logAuditoria = logAuditoria;
		this.usuario = logAuditoria.getCodUsuario();
	}

	public Map<String, ComisionBancaria> getComisionesBancarias() {
		return comisionesBancarias;
	}

	public void setComisionesBancarias(Map<String, ComisionBancaria> comisionesBancarias) {
		this.comisionesBancarias = comisionesBancarias;
	}

	public void setComisionBancaria(ComisionBancaria ComisionBancaria) {
		if (comisionesBancarias == null) {
			comisionesBancarias = new HashMap<String, ComisionBancaria>();
		}
		comisionesBancarias.put(ComisionBancaria.getComisionBancariaPK().getCveTipocomi(), ComisionBancaria);
	}
	public void setComisionBancaria(String cveTipocomi, BigDecimal monto) {
		
		ComisionBancaria comisionBancaria = getComisionBancaria(cveTipocomi);
		
		if (comisionBancaria == null){
			comisionBancaria = new ComisionBancaria(new ComisionBancariaPK(getLiqCodigo(), cveTipocomi), 0, monto);			
		}
		setComisionBancaria(comisionBancaria);
	}
	
	public ComisionBancaria getComisionBancaria(String cveTipocomi) {
		if (!comisionesBancarias.containsKey(cveTipocomi)) {
			return null;
		}
		return comisionesBancarias.get(cveTipocomi);

	}

	public void setCuentaPrestamo(String titular, Cuenta cuenta) {
		cuentasPrestamo.put(titular, cuenta);
	}

	public Cuenta getCuentaPrestamo(String titular) {
		if (!cuentasPrestamo.containsKey(titular)) {
			return null;
		}
		return cuentasPrestamo.get(titular);
	}

	public BigDecimal getComisionBancariaTotalBs() {
		BigDecimal total = BigDecimal.ZERO;
		for (Iterator<?> i = comisionesBancarias.keySet().iterator(); i.hasNext();) {
			String key = (String) i.next();
			ComisionBancaria comisionBancaria = comisionesBancarias.get(key);
			logger.info("Comision bancaria [" + comisionBancaria.getComisionBancariaPK().getLiqCodigo() + ", "
					+ comisionBancaria.getComisionBancariaPK().getCveTipocomi() + "]=" + comisionBancaria.getMontoMN());
			total = total.add(comisionBancaria.getMontoMN());
		}
		return total;
	}
	/**
	 * calcula el equivalente en bs del total de la liquidacion (k + i + c) respecto al tipo cambio de venta de la fecha de operacion
	 * @return
	 */
	public BigDecimal sumaLiqTotalBs(BigDecimal tc) {
		BigDecimal total = BigDecimal.ZERO;
		total = getTotalUsd().multiply(tc).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
		return total;
	}

	public Boolean getActualizado() {
		return actualizado;
	}

	public void setActualizado(Boolean actualizado) {
		this.actualizado = actualizado;
	}

	public BigDecimal getCapitalBs() {
		return capitalBs;
	}

	public void setCapitalBs(BigDecimal capitalBs) {
		this.capitalBs = capitalBs;
	}

	public BigDecimal getInteresBs() {
		return interesBs;
	}

	public void setInteresBs(BigDecimal interesBs) {
		this.interesBs = interesBs;
	}

	public BigDecimal getComisionBs() {
		return comisionBs;
	}

	public void setComisionBs(BigDecimal comisionBs) {
		this.comisionBs = comisionBs;
	}

	public BigDecimal getTotalBs() {
		return totalBs;
	}

	public void setTotalBs(BigDecimal totalBs) {
		this.totalBs = totalBs;
	}

	public BigDecimal getCapitalMO() {
		return capitalMO;
	}

	public void setCapitalMO(BigDecimal capitalMO) {
		this.capitalMO = capitalMO;
	}

	public BigDecimal getInteresMO() {
		return interesMO;
	}

	public void setInteresMO(BigDecimal interesMO) {
		this.interesMO = interesMO;
	}

	public BigDecimal getComisionMO() {
		return comisionMO;
	}

	public void setComisionMO(BigDecimal comisionMO) {
		this.comisionMO = comisionMO;
	}

	public BigDecimal getTotalMO() {
		return totalMO;
	}

	public void setTotalMO(BigDecimal totalMO) {
		this.totalMO = totalMO;
	}

	public String getMoneda() {
		return moneda;
	}

	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	public boolean isVariasMonedas() {
		return variasMonedas;
	}

	public void setVariasMonedas(boolean variasMonedas) {
		this.variasMonedas = variasMonedas;
	}

	public String getCodTipoOperacion() {
		return codTipoOperacion;
	}

	public void setCodTipoOperacion(String codTipoOperacion) {
		this.codTipoOperacion = codTipoOperacion;
	}

	public Integer getCantMensSwift() {
		return cantMensSwift;
	}

	public void setCantMensSwift(Integer cantMensSwift) {
		this.cantMensSwift = cantMensSwift;
	}

	public List<LiquidacionDet> getLiquidacionDetLista() {
		return liquidacionDetLista;
	}

	public void setLiquidacionDetLista(List<LiquidacionDet> liquidacionDetLista) {
		this.liquidacionDetLista = liquidacionDetLista;
	}
	
	public BigDecimal getTipoCambioCont() {
		return tipoCambioCont;
	}

	public void setTipoCambioCont(BigDecimal tipoCambioCont) {
		this.tipoCambioCont = tipoCambioCont;
	}

	public String getMonedaCont() {
		return monedaCont;
	}

	public void setMonedaCont(String monedaCont) {
		this.monedaCont = monedaCont;
	}

	public BigDecimal getCapital() {
		return capital;
	}

	public void setCapital(BigDecimal capital) {
		this.capital = capital;
	}

	public BigDecimal getInteres() {
		return interes;
	}

	public void setInteres(BigDecimal interes) {
		this.interes = interes;
	}

	public BigDecimal getComision() {
		return comision;
	}

	public void setComision(BigDecimal comision) {
		this.comision = comision;
	}

	public BigDecimal getTotal() {
		return total;
	}

	public void setTotal(BigDecimal total) {
		this.total = total;
	}

	public String getMonedaContDesc() {
		return monedaContDesc;
	}

	public void setMonedaContDesc(String monedaContDesc) {
		this.monedaContDesc = monedaContDesc;
	}

	public String getReferencia() {
		return referencia;
	}

	public void setReferencia(String referencia) {
		this.referencia = referencia;
	}

	public Boolean getMonSDR() {
		return monSDR;
	}

	public void setMonSDR(Boolean monSDR) {
		this.monSDR = monSDR;
	}

	public Date getFechaPago() {
		return fechaPago;
	}

	public void setFechaPago(Date fechaPago) {
		this.fechaPago = fechaPago;
	}

	public String getCodPartLiquidacionDesc() {
		return codPartLiquidacionDesc;
	}

	public void setCodPartLiquidacionDesc(String codPartLiquidacionDesc) {
		this.codPartLiquidacionDesc = codPartLiquidacionDesc;
	}

	public VcDatosAdic getVcDatosAdic() {
		return vcDatosAdic;
	}

	public void setVcDatosAdic(VcDatosAdic vcDatosAdic) {
		this.vcDatosAdic = vcDatosAdic;
	}
	
	public BigDecimal totalComisionBancaria(){
		BigDecimal total = BigDecimal.ZERO;
		ComisionBancaria comisionBancaria = getComisionBancaria("COPA");
		
		BigDecimal comiPago = comisionBancaria.getMontoMN();

		comisionBancaria = getComisionBancaria("SWFT");
		BigDecimal swift = comisionBancaria.getMontoMN();

		comisionBancaria = getComisionBancaria("UTIL");
		BigDecimal utiles = comisionBancaria.getMontoMN();
		total = comiPago.add(swift).add(utiles);
		
		return total;
	}

	@Override
	public String toString() {
		return "Vencimiento [liqCodigo=" + liqCodigo + ", ptmCodigo=" + ptmCodigo + ", traCodigo=" + traCodigo + ", capital=" + capital
				+ ", interes=" + interes + ", comision=" + comision + ", total=" + total + ", monedaCont=" + monedaCont + ", monedaContDesc="
				+ monedaContDesc + ", capitalMO=" + capitalMO + ", interesMO=" + interesMO + ", comisionMO=" + comisionMO + ", capitalUsd="
				+ capitalUsd + ", interesUsd=" + interesUsd + ", comisionUsd=" + comisionUsd + ", capitalBs=" + capitalBs + ", interesBs="
				+ interesBs + ", comisionBs=" + comisionBs + ", fechaTc=" + fechaTc + ", fechaPago=" + fechaPago + ", cveEstado=" + cveEstado
				+ ", cveEstadoDescrip=" + cveEstadoDescrip + ", cveEstNotif=" + cveEstNotif + ", cveEstNotifDescrip=" + cveEstNotifDescrip
				+ ", lote=" + lote + ", fechaVenc=" + fechaVenc + ", codTipoOperacion=" + codTipoOperacion + ", prestamo=" + prestamo + ", refAcre="
				+ refAcre + ", acreedor=" + acreedor + ", deudor=" + deudor + ", referencia=" + referencia + ", moneda=" + moneda
				+ ", tipoCambioCont=" + tipoCambioCont + ", variasMonedas=" + variasMonedas + ", cantMensSwift=" + cantMensSwift + ", totalMO="
				+ totalMO + ", totalUsd=" + totalUsd + ", totalBs=" + totalBs + ", usuario=" + usuario + ", codPartLiquidacion=" + codPartLiquidacion
				+ ", codPartLiquidacionDesc=" + codPartLiquidacionDesc + ", observacion=" + observacion + ", logAuditoria=" + logAuditoria
				+ ", docPdf=" + (docPdf != null) + ", comisionesBancarias=" + comisionesBancarias + ", cuentasPrestamo=" + cuentasPrestamo
				+ ", actualizado=" + actualizado + ", monSDR=" + monSDR + ", liquidacionDetLista=" + liquidacionDetLista + ", vcDatosAdic="
				+ vcDatosAdic + "]";
	}

	
}
