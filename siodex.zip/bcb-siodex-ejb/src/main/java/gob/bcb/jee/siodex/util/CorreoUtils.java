package gob.bcb.jee.siodex.util;

/**
 *
 * @author wilherrera
 */
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class CorreoUtils {
	private static final Log log = LogFactory.getLog(CorreoUtils.class);
	private Properties props;
	private String smtpHost = "10.2.11.27";
	private int smtpPort = 25;

	public CorreoUtils() {
	}

	public CorreoUtils(String smtpHost, int smtpPort) {
		this.smtpHost = smtpHost;
		this.smtpPort = smtpPort;
	}

	public void enviaAlServidorSMTP(String from, String to, String subject, String content) {
		try {
			initProperties();
			Session session = Session.getInstance(props);

			// Construct the message
			Message msg = new MimeMessage(session);
			msg.setFrom(new InternetAddress(from));
			msg.setRecipient(Message.RecipientType.TO, new InternetAddress(to));
			msg.setSubject(subject);
			msg.setText(content);

			// Send the message
			Transport.send(msg);
		} catch (AddressException add) {
			log.error("Error en enviaAlServidorSMTP " + add.getMessage(), add);
		} catch (MessagingException mes) {
			log.error("Error en mensaje SMTP " + mes.getMessage(), mes);
		}
	}

	private void initProperties() {
		// Create a mail session
		props = new Properties();
		props.put("mail.smtp.host", smtpHost);
		props.put("mail.smtp.port", "" + smtpPort);
	}

	/**
	 * @return the smtpHost
	 */
	public String getSmtpHost() {
		return smtpHost;
	}

	/**
	 * @param smtpHost
	 *            the smtpHost to set
	 */
	public void setSmtpHost(String smtpHost) {
		this.smtpHost = smtpHost;
	}

	/**
	 * @return the smtpPort
	 */
	public int getSmtpPort() {
		return smtpPort;
	}

	/**
	 * @param smtpPort
	 *            the smtpPort to set
	 */
	public void setSmtpPort(int smtpPort) {
		this.smtpPort = smtpPort;
	}
}
