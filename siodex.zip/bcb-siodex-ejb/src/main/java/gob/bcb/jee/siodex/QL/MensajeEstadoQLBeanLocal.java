package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.MensajeEstado;

import javax.ejb.Local;

@Local
public interface MensajeEstadoQLBeanLocal {

	/**
	 * 
	 * @return
	 */
	void edit(MensajeEstado menEstado);
	void create(MensajeEstado menEstado);
	void remove(MensajeEstado menEstado);
	public MensajeEstado getMenEstado(String codigo, String estado);
	
}
