package gob.bcb.jee.siodex.QL;

import java.math.BigDecimal;
import java.util.Date;

import gob.bcb.jee.siodex.entities.LiquidacionPago;

import javax.ejb.Local;

@Local
public interface LiquidacionPagoQLBeanLocal {
	void edit(LiquidacionPago liqEstado);
	void create(LiquidacionPago liqEstado);
	void remove(LiquidacionPago liqEstado);
	LiquidacionPago actualizar(LiquidacionPago liquidacionPago);
	LiquidacionPago actualizar(String liqCodigo, String cveCodigopago, BigDecimal valor, String codMoneda, String cveTipodetpago, Date fechaCont,
			Date fechaReg, String usrCodigo, String estacion);
	LiquidacionPago getLiquidacionPago(String codigo, String cveCodigopago);

}