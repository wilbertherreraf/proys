/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * 
 * @author CUriona
 */
@Entity
@Table(name = "liquidacion")
@XmlRootElement
@NamedQueries({ @NamedQuery(name = "Liquidacion.findAll", query = "SELECT l FROM Liquidacion l"),
		@NamedQuery(name = "Liquidacion.findByLiqCodigo", query = "SELECT l FROM Liquidacion l WHERE l.liqCodigo = :liqCodigo"),
		@NamedQuery(name = "Liquidacion.findByPtmCodigo", query = "SELECT l FROM Liquidacion l WHERE l.ptmCodigo = :ptmCodigo"),
		@NamedQuery(name = "Liquidacion.findByTraCodigo", query = "SELECT l FROM Liquidacion l WHERE l.traCodigo = :traCodigo"),
		@NamedQuery(name = "Liquidacion.findByCapitalUsd", query = "SELECT l FROM Liquidacion l WHERE l.capitalUsd = :capitalUsd"),
		@NamedQuery(name = "Liquidacion.findByInteresUsd", query = "SELECT l FROM Liquidacion l WHERE l.interesUsd = :interesUsd"),
		@NamedQuery(name = "Liquidacion.findByComisionUsd", query = "SELECT l FROM Liquidacion l WHERE l.comisionUsd = :comisionUsd"),
		@NamedQuery(name = "Liquidacion.findByFechaTc", query = "SELECT l FROM Liquidacion l WHERE l.fechaTc = :fechaTc"),
		@NamedQuery(name = "Liquidacion.findByCveEstado", query = "SELECT l FROM Liquidacion l WHERE l.cveEstado = :cveEstado"),
		@NamedQuery(name = "Liquidacion.findByUsrCodigo", query = "SELECT l FROM Liquidacion l WHERE l.usrCodigo = :usrCodigo"),
		@NamedQuery(name = "Liquidacion.findByFechaHora", query = "SELECT l FROM Liquidacion l WHERE l.fechaHora = :fechaHora"),
		@NamedQuery(name = "Liquidacion.findByEstacion", query = "SELECT l FROM Liquidacion l WHERE l.estacion = :estacion"),
		@NamedQuery(name = "Liquidacion.findByFechaCorte", query = "SELECT l FROM Liquidacion l WHERE l.fechaCorte = :fechaCorte"),
		@NamedQuery(name = "Liquidacion.findByFechaVenc", query = "SELECT l FROM Liquidacion l WHERE l.fechaVenc = :fechaVenc"),
		@NamedQuery(name = "Liquidacion.findByPreliminar", query = "SELECT l FROM Liquidacion l WHERE l.preliminar = :preliminar"),
		@NamedQuery(name = "Liquidacion.findByFechaCorteAnt", query = "SELECT l FROM Liquidacion l WHERE l.fechaCorteAnt = :fechaCorteAnt") })
public class Liquidacion implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@Basic(optional = false)
	@NotNull
	@Column(name = "liq_codigo")
	private String liqCodigo;
	@Basic(optional = false)
	@NotNull
	@Column(name = "ptm_codigo")
	private String ptmCodigo;
	@Basic(optional = false)
	@NotNull
	@Column(name = "tra_codigo")
	private Integer traCodigo;
	// @Max(value=?) @Min(value=?)//if you know range of your decimal fields
	// consider using these annotations to enforce field validation
	@Column(name = "capital_usd", precision = 16, scale = 2)
	private BigDecimal capitalUsd;
	@Column(name = "interes_usd", precision = 16, scale = 2)
	private BigDecimal interesUsd;
	@Column(name = "comision_usd", precision = 16, scale = 2)
	private BigDecimal comisionUsd;
	@Column(name = "fecha_tc")
	@Temporal(TemporalType.DATE)
	private Date fechaTc;
	@Basic(optional = false)
	@NotNull
	@Column(name = "cve_estado", nullable = false)
	private String cveEstado;
	@Column(name = "cve_estnotif")
	private String cveEstnotif;
	@Column(name = "lote")
	private Integer lote;

	@Column(name = "monto")
	private BigDecimal monto;
	@Column(name = "cod_moneda")
	private String codMoneda;
	@Column(name = "tipo_cambio")
	private BigDecimal tipoCambio;
	@Column(name = "mon_sigade")
	private String monSigade;
	
	@Column(name = "tipo_oper")
	private String tipoOper;
	@Column(name = "cod_part")
	private String codPart;

	@Column(name = "referencia")
	private String referencia;
	
	@Column(name = "switfs")
	private Integer switfs;
	
	@Basic(optional = false)
	@Column(name = "usr_codigo", nullable = false)
	private String usrCodigo;
	@Basic(optional = false)
	@NotNull
	@Column(name = "fecha_hora", nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date fechaHora;
	@Basic(optional = false)
	@NotNull
	@Column(name = "estacion", nullable = false)
	private String estacion;
	@Column(name = "fecha_corte")
	@Temporal(TemporalType.DATE)
	private Date fechaCorte;
	@Column(name = "fecha_venc")
	@Temporal(TemporalType.DATE)
	private Date fechaVenc;
	@Column(name = "preliminar")
	private Short preliminar;
	@Column(name = "fecha_corte_ant")
	@Temporal(TemporalType.DATE)
	private Date fechaCorteAnt;
	@Column(name = "doc_pdf")
	@Lob
	@Basic(fetch = FetchType.LAZY)
	private byte[] docPdf;

	public Liquidacion() {
	}

	public Liquidacion(String liqCodigo) {
		this.liqCodigo = liqCodigo;
	}

	public Liquidacion(String liqCodigo, String ptmCodigo, Integer traCodigo, String cveEstado, String usrCodigo, Date fechaHora, String estacion) {
		this.liqCodigo = liqCodigo;
		this.ptmCodigo = ptmCodigo;
		this.traCodigo = traCodigo;
		this.cveEstado = cveEstado;
		this.usrCodigo = usrCodigo;
		this.fechaHora = fechaHora;
		this.estacion = estacion;
	}

	public String getLiqCodigo() {
		return liqCodigo;
	}

	public void setLiqCodigo(String liqCodigo) {
		this.liqCodigo = liqCodigo;
	}

	public String getPtmCodigo() {
		return ptmCodigo;
	}

	public void setPtmCodigo(String ptmCodigo) {
		this.ptmCodigo = ptmCodigo;
	}

	public Integer getTraCodigo() {
		return traCodigo;
	}

	public void setTraCodigo(Integer traCodigo) {
		this.traCodigo = traCodigo;
	}

	public BigDecimal getCapitalUsd() {
		return capitalUsd;
	}

	public void setCapitalUsd(BigDecimal capitalUsd) {
		this.capitalUsd = capitalUsd;
	}

	public BigDecimal getInteresUsd() {
		return interesUsd;
	}

	public void setInteresUsd(BigDecimal interesUsd) {
		this.interesUsd = interesUsd;
	}

	public BigDecimal getComisionUsd() {
		return comisionUsd;
	}

	public void setComisionUsd(BigDecimal comisionUsd) {
		this.comisionUsd = comisionUsd;
	}

	public Date getFechaTc() {
		return fechaTc;
	}

	public void setFechaTc(Date fechaTc) {
		this.fechaTc = fechaTc;
	}

	public String getCveEstado() {
		return cveEstado;
	}

	public void setCveEstado(String cveEstado) {
		this.cveEstado = cveEstado;
	}

	public String getUsrCodigo() {
		return usrCodigo;
	}

	public void setUsrCodigo(String usrCodigo) {
		this.usrCodigo = usrCodigo;
	}

	public Date getFechaHora() {
		return fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getEstacion() {
		return estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaCorte() {
		return fechaCorte;
	}

	public void setFechaCorte(Date fechaCorte) {
		this.fechaCorte = fechaCorte;
	}

	public Date getFechaVenc() {
		return fechaVenc;
	}

	public void setFechaVenc(Date fechaVenc) {
		this.fechaVenc = fechaVenc;
	}

	public Short getPreliminar() {
		return preliminar;
	}

	public void setPreliminar(Short preliminar) {
		this.preliminar = preliminar;
	}

	public Date getFechaCorteAnt() {
		return fechaCorteAnt;
	}

	public void setFechaCorteAnt(Date fechaCorteAnt) {
		this.fechaCorteAnt = fechaCorteAnt;
	}

	public byte[] getDocPdf() {
		return docPdf;
	}

	public void setDocPdf(byte[] docPdf) {
		this.docPdf = docPdf;
	}

	public String getCveEstnotif() {
		return cveEstnotif;
	}

	public void setCveEstnotif(String cveEstnotif) {
		this.cveEstnotif = cveEstnotif;
	}

	public Integer getLote() {
		return lote;
	}

	public void setLote(Integer lote) {
		this.lote = lote;
	}

//	
//	public BigDecimal getMontoMo() {
//		return montoMo;
//	}
//
//	public void setMontoMo(BigDecimal montoMo) {
//		this.montoMo = montoMo;
//	}
//
//	public String getCodMonMo() {
//		return codMonMo;
//	}
//
//	public void setCodMonMo(String codMonMo) {
//		this.codMonMo = codMonMo;
//	}
//
//	public BigDecimal getTipoCambMo() {
//		return tipoCambMo;
//	}
//
//	public void setTipoCambMo(BigDecimal tipoCambMo) {
//		this.tipoCambMo = tipoCambMo;
//	}
//
//	public BigDecimal getMontoCont() {
//		return montoCont;
//	}
//
//	public void setMontoCont(BigDecimal montoCont) {
//		this.montoCont = montoCont;
//	}
//
//	public String getCodMonCont() {
//		return codMonCont;
//	}
//
//	public void setCodMonCont(String codMonCont) {
//		this.codMonCont = codMonCont;
//	}
//
//	public BigDecimal getTipoCambCont() {
//		return tipoCambCont;
//	}
//
//	public void setTipoCambCont(BigDecimal tipoCambCont) {
//		this.tipoCambCont = tipoCambCont;
//	}

	public String getTipoOper() {
		return tipoOper;
	}

	public void setTipoOper(String tipoOper) {
		this.tipoOper = tipoOper;
	}

	public String getCodPart() {
		return codPart;
	}

	public void setCodPart(String codPart) {
		this.codPart = codPart;
	}

	public BigDecimal getMonto() {
		return monto;
	}

	public void setMonto(BigDecimal monto) {
		this.monto = monto;
	}

	public String getCodMoneda() {
		return codMoneda;
	}

	public void setCodMoneda(String codMoneda) {
		this.codMoneda = codMoneda;
	}

	public BigDecimal getTipoCambio() {
		return tipoCambio;
	}

	public void setTipoCambio(BigDecimal tipoCambio) {
		this.tipoCambio = tipoCambio;
	}

	public String getMonSigade() {
		return monSigade;
	}

	public void setMonSigade(String monSigade) {
		this.monSigade = monSigade;
	}

	public String getReferencia() {
		return referencia;
	}

	public void setReferencia(String referencia) {
		this.referencia = referencia;
	}

	public Integer getSwitfs() {
		return switfs;
	}

	public void setSwitfs(Integer switfs) {
		this.switfs = switfs;
	}

	@Override
	public String toString() {
		return "Liquidacion [liqCodigo=" + liqCodigo + ", ptmCodigo=" + ptmCodigo + ", traCodigo=" + traCodigo + ", capitalUsd=" + capitalUsd
				+ ", interesUsd=" + interesUsd + ", comisionUsd=" + comisionUsd + ", fechaTc=" + fechaTc + ", cveEstado=" + cveEstado
				+ ", cveEstnotif=" + cveEstnotif + ", lote=" + lote + ", monto=" + monto + ", codMoneda=" + codMoneda + ", tipoCambio=" + tipoCambio
				+ ", monSigade=" + monSigade + ", tipoOper=" + tipoOper + ", codPart=" + codPart + ", referencia=" + referencia + ", switfs="
				+ switfs + ", usrCodigo=" + usrCodigo + ", fechaHora=" + fechaHora + ", estacion=" + estacion + ", fechaCorte=" + fechaCorte
				+ ", fechaVenc=" + fechaVenc + ", preliminar=" + preliminar + ", fechaCorteAnt=" + fechaCorteAnt + ", docPdf="
				+ (docPdf != null) + "]";
	}

}
