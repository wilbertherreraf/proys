package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.PrestamoInstancia;

import java.util.List;

import javax.ejb.Local;

@Local
public interface PrestamoInstanciaQLBeanLocal extends DAO<PrestamoInstancia>{

	/**
	 * 
	 * @return
	 */
	public List<PrestamoInstancia> listaInstancia(String prestamo, int tramo, String tipo);
	
}
