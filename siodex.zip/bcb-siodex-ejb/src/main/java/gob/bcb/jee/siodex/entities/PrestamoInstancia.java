/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author CUriona
 */
@Entity
@Table(name = "prestamo_instancia")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "PrestamoInstancia.findAll", query = "SELECT p FROM PrestamoInstancia p")})
public class PrestamoInstancia implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected PrestamoInstanciaPK prestamoInstanciaPK;
    @Basic(optional = false)
    @NotNull
    @Column(name = "cve_instancia", nullable = false)
    private String cveInstancia;
    @Basic(optional = false)
    @NotNull
    @Column(name = "pin_prestamo", nullable = false)
    private String pinPrestamo;
    @Column(name = "pin_tramo")
    private Integer pinTramo;

    public PrestamoInstancia() {
    	
    }

    public PrestamoInstancia(PrestamoInstanciaPK prestamoInstanciaPK) {
        this.prestamoInstanciaPK = prestamoInstanciaPK;
    }

    public PrestamoInstancia(PrestamoInstanciaPK prestamoInstanciaPK, String cveInstancia, String pinPrestamo, Integer pinTramo) {
        this.prestamoInstanciaPK = prestamoInstanciaPK;
        this.cveInstancia = cveInstancia;
        this.pinPrestamo = pinPrestamo;
        this.pinTramo = pinTramo;
    }

    public PrestamoInstancia(String ptmCodigo, String cveTipoLiq, int traCodigo) {
        this.prestamoInstanciaPK = new PrestamoInstanciaPK(ptmCodigo, cveTipoLiq, traCodigo);
    }

    public PrestamoInstanciaPK getPrestamoInstanciaPK() {
        return prestamoInstanciaPK;
    }

    public void setPrestamoInstanciaPK(PrestamoInstanciaPK prestamoInstanciaPK) {
        this.prestamoInstanciaPK = prestamoInstanciaPK;
    }

    public String getCveInstancia() {
		return cveInstancia;
	}

	public void setCveInstancia(String cveInstancia) {
		this.cveInstancia = cveInstancia;
	}

	public String getPinPrestamo() {
        return pinPrestamo;
    }

    public void setPinPrestamo(String pinPrestamo) {
        this.pinPrestamo = pinPrestamo;
    }

    public Integer getPinTramo() {
        return pinTramo;
    }

    public void setPinTramo(Integer pinTramo) {
        this.pinTramo = pinTramo;
    }



	@Override
	public String toString() {
		return "LiquidacionDet [prestamoInstanciaPK=" + prestamoInstanciaPK + ", cveInstancia=" + cveInstancia + ", pinPrestamo=" + pinPrestamo + ", pinTramo=" + pinTramo ;
	}

}
