package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the liquidacion_pago database table.
 * 
 */
@Embeddable
public class LiquidacionPagoPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="liq_codigo")
	private String liqCodigo;

	@Column(name="cve_codigopago")
	private String cveCodigopago;

    public LiquidacionPagoPK() {
    }
	public String getLiqCodigo() {
		return this.liqCodigo;
	}
	public void setLiqCodigo(String liqCodigo) {
		this.liqCodigo = liqCodigo;
	}
	public String getCveCodigopago() {
		return this.cveCodigopago;
	}
	public void setCveCodigopago(String cveCodigopago) {
		this.cveCodigopago = cveCodigopago;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof LiquidacionPagoPK)) {
			return false;
		}
		LiquidacionPagoPK castOther = (LiquidacionPagoPK)other;
		return 
			this.liqCodigo.equals(castOther.liqCodigo)
			&& this.cveCodigopago.equals(castOther.cveCodigopago);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.liqCodigo.hashCode();
		hash = hash * prime + this.cveCodigopago.hashCode();
		
		return hash;
    }
}