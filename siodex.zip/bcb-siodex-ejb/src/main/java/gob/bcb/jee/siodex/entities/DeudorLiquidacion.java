/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Blob;
import java.util.Date;
import java.util.List;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author CUriona
 */
@Entity
@Table(name = "deudor_liquidacion")

public class DeudorLiquidacion implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "deu_codigo", nullable = false)
    private String deuCodigo;
    @Column(name = "gen_liq")
    private Integer genLiq;
    @Column(name = "pub_liq")
    private Integer pubLiq;
    @Column(name = "cve_vigente")
    private Integer cveVigente;
    @Column(name = "deu_email")
    private String deuEmail;
    @Column(name = "usr_codigo")
    private String usrCodigo;    
    @Column(name = "fecha_hora")
    @Temporal(TemporalType.TIMESTAMP)    
    private Date fechaHora;
    @Column(name = "estacion")
    private String estacion;

	public DeudorLiquidacion() {
    }

    public String getDeuCodigo() {
		return deuCodigo;
	}

	public void setDeuCodigo(String deuCodigo) {
		this.deuCodigo = deuCodigo;
	}

	public Integer getGenLiq() {
		return genLiq;
	}

	public void setGenLiq(Integer genLiq) {
		this.genLiq = genLiq;
	}

	public Integer getPubLiq() {
		return pubLiq;
	}

	public void setPubLiq(Integer pubLiq) {
		this.pubLiq = pubLiq;
	}

	public Integer getCveVigente() {
		return cveVigente;
	}

	public void setCveVigente(Integer cveVigente) {
		this.cveVigente = cveVigente;
	}

	public String getDeuEmail() {
		return deuEmail;
	}

	public void setDeuEmail(String deuEmail) {
		this.deuEmail = deuEmail;
	}

	public String getUsrCodigo() {
		return usrCodigo;
	}

	public void setUsrCodigo(String usrCodigo) {
		this.usrCodigo = usrCodigo;
	}

	public Date getFechaHora() {
		return fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getEstacion() {
		return estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}
}
