package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.DebtServOpers;

import javax.ejb.Local;

@Local
public interface DebtServOpersQLBeanLocal {

	/**
	 * 
	 * @return
	 */
	void edit(DebtServOpers dso);
	void create(DebtServOpers dso);
	public DebtServOpers getDso(Integer codigo);
	
}
