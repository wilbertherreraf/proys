package gob.bcb.jee.siodex.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class UtilsProperties {
	public static Properties loadFileMsgProperties(String pathFile) {
		Properties properties = new Properties();
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(new File(pathFile));
			properties.load(fis);
		} catch (FileNotFoundException e) {
			throw new RuntimeException("Archivo de propiedades " + pathFile + " inexistente", e);
		} catch (IOException e) {
			throw new RuntimeException(e);
		} finally {
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException e) {
					// ignore
				}
			}
		}

		return properties;
	}
	public static Properties loadFilePropertiesFromClass(String nameFile) {
		InputStream in = ClassLoader.getSystemResourceAsStream(nameFile);
		Properties properties = new Properties();

		try {
			properties.load(in);
		} catch (FileNotFoundException e) {
			throw new RuntimeException("Archivo de propiedades " + nameFile + " inexistente", e);
		} catch (IOException e) {
			throw new RuntimeException(e);
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					// ignore
				}
			}
		}

		return properties;
	}	
}
