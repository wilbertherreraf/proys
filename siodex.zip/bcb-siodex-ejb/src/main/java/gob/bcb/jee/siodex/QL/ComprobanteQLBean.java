package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.ClaveValor;
import gob.bcb.jee.siodex.entities.Comprobante;
import gob.bcb.jee.siodex.entities.SolDato;
import gob.bcb.jee.siodex.entities.Solicitud;
import gob.bcb.jee.siodex.exception.DataException;
import gob.bcb.jee.siodex.util.UtilsDate;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.ejb.EJBException;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

@Stateless
@LocalBean
public class ComprobanteQLBean implements ComprobanteQLBeanLocal {

	static final Logger logger = Logger.getLogger(ComprobanteQLBean.class);

	@PersistenceContext(unitName = "siodex")
	EntityManager em;

	@Inject
	private CoinQLBeanLocal coinQLBeanLocal;

	@Inject
	private SolicitudQLBeanLocal solicitudQLBeanLocal;

	@Inject
	private SolDatoQLBeanLocal solDatoQLBeanLocal;
	@Inject
	private ConsultasSdxQLBeanLocal consultasSdxQLBeanLocal;

	/**
	 * Default constructor.
	 */
	public ComprobanteQLBean() {
		// TODO Auto-generated constructor stub
	}

	public List<Comprobante> listaComprobante(Integer codigo) throws DataException {
		logger.info("Obteniendo lista de renglones para PRE - comprobante " + codigo);

		List<Comprobante> listaC = new ArrayList<Comprobante>();
		List<SolDato> lista = solDatoQLBeanLocal.getDatos(codigo);
		Solicitud soli = solicitudQLBeanLocal.getSolicitud(codigo);

		String glosaT = "";
		String glosaC = "";
		String glosaF = "";
		String glosaM = "";
		String glosaD = "";

		SolDato solDato = solDatoQLBeanLocal.getSolDato(codigo, "GLOSA_TRANSFERENCIA");
		if (solDato != null) {
			glosaT = solDato.getDatoTexto();
		}

		solDato = solDatoQLBeanLocal.getSolDato(codigo, "GLOSA_FNDR");
		if (solDato != null) {
			glosaF = solDato.getDatoTexto();
		}
		
		solDato = solDatoQLBeanLocal.getSolDato(codigo, "GLOSA_COMISION");
		if (solDato != null) {
			glosaC = solDato.getDatoTexto();
		}

		solDato = solDatoQLBeanLocal.getSolDato(codigo, "GLOSA_MDRICUTBS");
		if (solDato != null) {
			glosaM = solDato.getDatoTexto();
		}
		
		solDato = solDatoQLBeanLocal.getSolDato(codigo, "GLOSA_MDRICUTUSD");
		if (solDato != null) {
			glosaM = solDato.getDatoTexto();
		}
		
		solDato = solDatoQLBeanLocal.getSolDato(codigo, "GLOSA_DIFCUTBS");
		if (solDato != null) {
			glosaD = solDato.getDatoTexto();
		}
		
		solDato = solDatoQLBeanLocal.getSolDato(codigo, "GLOSA_DIFCUTUSD");
		if (solDato != null) {
			glosaD = solDato.getDatoTexto();
		}
		
		int cont = 1;
		for (SolDato dato : lista) {

			String movimiento = "";
			String renglon = String.valueOf(cont);
			Comprobante reng = null;
			String glosa = null;

			BigDecimal montoMn = BigDecimal.valueOf(0.00);
			
			if (dato.getDatoNumero() != null && !StringUtils.isBlank(dato.getCveDh())) {
				if (dato.getSolDatoPK().getCodDato().equals("TOTTRANS")) {
					glosa = glosaT;

				} else if (dato.getSolDatoPK().getCodDato().equals("TOTFNDR")) {
					glosa = glosaF;
					
				} else if (dato.getSolDatoPK().getCodDato().equals("MONTOTOTCOMISIONES") || dato.getSolDatoPK().getCodDato().equals("MONTOTOTUSDCOMISIONES")) {
					glosa = glosaC;
				} else if (dato.getSolDatoPK().getCodDato().equals("MONTOMDRICUTBS") || dato.getSolDatoPK().getCodDato().equals("MONTOMDRICUTUSD")) {
					glosa = glosaM;
				} else if (dato.getSolDatoPK().getCodDato().equals("MONTODIFCUTBS") || dato.getSolDatoPK().getCodDato().equals("MONTODIFCUTUSD")) {
					glosa = glosaD;
				} 
				
				if (!StringUtils.isBlank(dato.getCuentaMov())) {
					Object[] da = coinQLBeanLocal.getCuentaMovimiento(dato.getCuentaMov());
					movimiento = (String) da[1];
					
					montoMn = dato.getDatoNumero().multiply(dato.getTipoCambio()).setScale(2, BigDecimal.ROUND_HALF_UP);

					reng = new Comprobante(codigo, renglon, dato.getCuentaMov(), movimiento, dato.getCodMoneda(), dato.getCveDh(), dato.getTipoCambio(), dato.getDatoNumero(), montoMn,
							glosa);

					logger.info("Renglon comprobante " + reng.toString());
					listaC.add(reng);

					cont++;					
				} else {
					logger.error("Cuenta no encontrada para " + dato.getSolDatoPK().getCodDato());					
				}
			}

		}
		logger.info("renglones comprobante " + listaC.size());
		return listaC;
	}

	/**
	 * retorna los renglones adicionales qu no tienen debe o haber
	 * 
	 * @param codigo
	 * @return
	 * @throws DataException
	 */
	public List<Comprobante> listaComprobanteAdic(Integer codigo) throws DataException {
		logger.info("Obteniendo lista de renglones Adic para PRE - comprobante " + codigo);

		List<Comprobante> listaC = new ArrayList<Comprobante>();
		List<SolDato> lista = solDatoQLBeanLocal.getDatos(codigo);
		Solicitud soli = solicitudQLBeanLocal.getSolicitud(codigo);

		int cont = 1;
		for (SolDato dato : lista) {
			String movimiento = "";
			String codDato = dato.getSolDatoPK().getCodDato();
			String cuenta = codDato;
			String renglon = String.valueOf(cont);
			String moneda = dato.getCodMoneda();
			String debeHaber = dato.getCveDh();
			Comprobante reng = null;
			String glosa = null;

			BigDecimal montoMn = BigDecimal.valueOf(0.00);

			if (StringUtils.isBlank(dato.getCveDh())) {
				if (StringUtils.isBlank(dato.getDatoTexto()) && dato.getDatoNumero() == null) {
					;
					;
				} else {
					reng = new Comprobante(codigo, renglon, cuenta, movimiento, moneda, debeHaber, dato.getTipoCambio(), dato.getDatoNumero(),
							montoMn, glosa);

					logger.info("Renglon Adic comprobante " + reng.toString());
					listaC.add(reng);
					cont++;
				}
			}
		}

		logger.info("renglones Adic comprobante " + listaC.size());
		return listaC;
	}

	public void ajustarComprobante(Integer codigo) throws DataException {
		logger.info("Ajustar comprobante si diff > 0.04 ******** " + codigo);
		
		SolDato solDato = solDatoQLBeanLocal.getSolDato(codigo, "TOTTRANS");
		BigDecimal monto = solDato.getDatoNumero();
		solDato.setDatoNumero(monto.add(new BigDecimal(0.01)));
		solDatoQLBeanLocal.edit(solDato);
	}
	
}
