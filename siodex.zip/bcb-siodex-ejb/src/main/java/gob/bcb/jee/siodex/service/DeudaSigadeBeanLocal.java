package gob.bcb.jee.siodex.service;

import javax.ejb.Local;

@Local
public interface DeudaSigadeBeanLocal {

	/**
	 * 
	 * @param men
	 * @return
	 */
	public Integer registrarSigade(String codigo);
	
}
