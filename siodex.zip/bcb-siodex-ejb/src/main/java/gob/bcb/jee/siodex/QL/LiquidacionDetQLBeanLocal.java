package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.LiquidacionDet;

import java.util.List;

import javax.ejb.Local;

@Local
public interface LiquidacionDetQLBeanLocal extends DAO<LiquidacionDet>{

	/**
	 * 
	 * @return
	 */
	public List<LiquidacionDet> listaLiquidacion(String codigo);
	public LiquidacionDet getLiquidacion(String codigo, String det);
	LiquidacionDet getLiquidacionInstancia(String codigo, String prestamo, int tramo);
	LiquidacionDet actualizar(LiquidacionDet liquidacionDet);
	
}
