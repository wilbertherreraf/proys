/*
 * Creado el 23-mar-2006
 *
 * TODO Para cambiar la plantilla de este archivo generado, vaya a
 * Ventana - Preferencias - Java - Estilo de c�digo - Plantillas de c�digo
 */
package gob.bcb.jee.siodex.util;

/**
 * @author WHerrera
 *
 * Clase con un conjunto de metodos utilitarios para el procesamiento de
 * cadenas o documentos XML
 */
import org.apache.log4j.Logger;
import org.w3c.dom.Document;

import gob.bcb.jee.siodex.QL.DAQLBean;
import gob.bcb.jee.siodex.exception.InternaException;
import gob.bcb.jee.siodex.exception.MsgErr;
import gob.bcb.jee.siodex.exception.MyDefaultHandler;
import gob.bcb.jee.siodex.exception.XMLException;

import java.io.*;
import javax.xml.parsers.*;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import org.xml.sax.SAXException;
import org.xml.sax.InputSource;
import org.xml.sax.SAXParseException;

import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.FileInputStream;
import gob.bcb.jee.siodex.exception.MyErrorHandler;;

public final class XMLTools {
	static final Logger log = Logger.getLogger(XMLTools.class);
	/**
	 * Obtiene el valor de un tag
	 *
	 * @param xmlString
	 *            Cadena XML
	 * @return Nombre del tag
	 * @throws XMLException
	 *             Si hay un error, lanza una excepci�n de tipo XML
	 */
	public static String getXMLTagValue(String xmlString, String section) throws XMLException {
		String subCadena, subcad2, subcad3 = null;
		int indice1, indice2;
		if (xmlString.length() == 0) {
			XMLException xmlex = new XMLException(MsgErr.getMessage("X008"));
			throw xmlex;
		}
		
		if (xmlString.contains("<" + section + "/>")){
			return "";
		}
		
		String beginTagToSearch = "<" + section;
		indice1 = xmlString.indexOf(beginTagToSearch);
		if (indice1 == -1) {
			XMLException xmlex = new XMLException(MsgErr.getMessage("X009", section));
			throw xmlex;
		}
		subcad2 = xmlString.substring(indice1);
		indice2 = subcad2.indexOf(">");
		subcad3 = subcad2.substring(0, indice2 + 1);

		// System.out.println(subcad2 + " "+ subcad3);
		String endTagToSearch = "</" + section + ">";

		// Look for the first occurrence of begin tag
		int index = xmlString.indexOf(subcad3);
		int lastIndex = xmlString.indexOf(endTagToSearch);

		if (index == -1 || lastIndex == -1) {
			XMLException xmlex = new XMLException(MsgErr.getMessage("X009", section));
			throw xmlex;
		}
		subCadena = xmlString.substring((index + subcad3.length()), lastIndex);
		return subCadena.trim();
	}

	/**
	 * Obtiene el valor de un tag de un documento
	 *
	 * @param xml
	 *            Documento XML
	 * @return Nombre del tag
	 * @throws XMLException
	 *             Si hay un error, lanza una excepci�n de tipo XML
	 */
	public static String getTagValueFromDoc(Document xml, String tag) throws XMLException {
		String nodeAsString = "";
		String docXMLAsString = "";
		try {
			docXMLAsString = xmlToString(xml);
			nodeAsString = getXMLTagValue(docXMLAsString, tag);
		} catch (Exception e) {
			XMLException xmlex = new XMLException(MsgErr.getMessage("X012", e.getMessage()));
			throw xmlex;
		}
		return nodeAsString;
	}

	/**
	 * Obtiene el valor de un tag de un documento XML
	 *
	 * @param xml
	 *            Documento XML
	 * @return Nombre del tag
	 * @throws XMLException
	 *             Si hay un error, lanza una excepci�n de tipo XML
	 */
	public static String returnValueOfTag(Document xml, String tag) throws XMLException {
		Node node;
		NodeList nodeList;
		String nodeAsString = "";
		try {
			nodeList = xml.getElementsByTagName(tag);
			if (nodeList.getLength() > 0) {
				node = nodeList.item(0);
				nodeAsString = getXMLTagValue(xmlToString(xml), tag);
			}
		} catch (Exception e) {
			// Lanzamiento de Excepcion
			XMLException xmlEx = new XMLException(MsgErr.getMessage("X012", e.getMessage()));
			throw xmlEx;
		}
		return nodeAsString;
	}

	/**
	 * Convierte una Variable de tipo Document a String
	 *
	 * @param xml
	 *            Documento XML
	 * @return Cadena XML
	 */
	public static String DocumentToString(Document xml) {
		Element element = xml.getDocumentElement();
		DOM2Writer dom2Writer = new DOM2Writer();
		return dom2Writer.elementToString(element);

	}

	/**
	 * Devuelve una cadena XML formada de un nodo m�s su tag correspondiente
	 *
	 * @param node
	 *            Nodo a extraer su contenido
	 * @return Cadena que contiene el contenido del nodo
	 * @throws XMLException
	 *             Si hay un error, lanza una excepci�n de tipo XML
	 */
	public static String nodeToXML(org.w3c.dom.Node node) {
		String nodeAsString = "";
		Element elem = null;
		if (node == null) {
			return "";
		} else {
			elem = (Element) node;
			DOM2Writer dom2Writer = new DOM2Writer();
			nodeAsString = dom2Writer.elementToString(elem);
		}
		return nodeAsString;
	}

	/**
	 * Convierte una cadena XML a tipo Element, basicamente, parsea un bloque
	 * texto XML.
	 */
	public static Element stringToElement(String nodeAsString) throws XMLException {
		Document xml = null;
		Element element = null;
		xml = stringXMLToDocument(nodeAsString);
		element = xml.getDocumentElement();
		return element;
	}

	/**
	 * Convierte una variable Document(Una estructura org.XML ) dentro una
	 * cadena.
	 */
	public static String xmlToString(Document xml) throws XMLException {
		String xmlAsString = "";
		if (xml == null) {
			XMLException xmlEx = new XMLException(MsgErr.getMessage("X008"));
			throw xmlEx;
		}
		DOM2Writer dom2Writer = new DOM2Writer();
		// xmlAsString = org.apache.axis.utils.XMLUtils.DocumentToString(xml);
		xmlAsString = dom2Writer.elementToString(xml.getDocumentElement());
		return xmlAsString;
	}

	/**
	 * Convierte una variable tipo Document a una variable tipo Element,
	 */
	public static String returnElement(Document xml) throws XMLException {
		String xmlAsString = null;
		try {
			if (xml == null) {
				xmlAsString = "";
			} else {
				// xmlAsString =
				// org.apache.axis.utils.XMLUtils.getInnerXMLString(xml.getDocumentElement());
				DOM2Writer dom2Writer = new DOM2Writer();
				xmlAsString = dom2Writer.elementToString(xml.getDocumentElement());
			}
		} catch (Exception e) {
			// Lanzamiento de Excepcion
			XMLException xmlEx = new XMLException(MsgErr.getMessage("X001"));
			throw xmlEx;
		}
		return xmlAsString;
	}

	/**
	 * Recibe una mensaje en formato XML, ya sea dentro un archivo o una Cadena,
	 * para luego parsearlo. Internamente se graba en las tablas descritas en
	 * los nodos del mensaje
	 */
	public static Document fileXMLToDoc(String path) throws XMLException {
		Document doc = null;
		DocumentBuilderFactory dbf = null;
		try {
			dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = dbf.newDocumentBuilder();
			builder.setErrorHandler(new MyErrorHandler());
			dbf.setNamespaceAware(true);
			InputSource is = new InputSource(path);
			doc = builder.parse(is);
		} catch (UTFDataFormatException ioE) {
			// Lanzamiento de Excepcion
			XMLException internaEx = new XMLException(MsgErr.getMessage("X025"));
			internaEx.initCause(ioE.getCause());
			internaEx.setStackTrace(ioE.getStackTrace());
			throw internaEx;
		} catch (ParserConfigurationException parE) {
			// Lanzamiento de Excepcion
			XMLException xmlEx = new XMLException(MsgErr.getMessage("X001"));
			xmlEx.setStackTrace(parE.getStackTrace());
			throw xmlEx;
		} catch (SAXParseException saxPE) {
			// Lanzamiento de Excepcion
			XMLException xmlEx = new XMLException(MsgErr.getMessage("X002"));
			xmlEx.setStackTrace(saxPE.getStackTrace());
			throw xmlEx;
		} catch (SAXException saxE) {
			// Lanzamiento de Excepcion
			XMLException xmlEx = new XMLException(MsgErr.getMessage("X002"));
			xmlEx.setStackTrace(saxE.getStackTrace());
			throw xmlEx;
		} catch (IOException ioE) {
			// Lanzamiento de Excepcion
			XMLException xmlEx = new XMLException(MsgErr.getMessage("X003"));
			xmlEx.setStackTrace(ioE.getStackTrace());
			throw xmlEx;
		} catch (Exception ex) {
			// Lanzamiento de Excepcion
			XMLException xmlEx = new XMLException(MsgErr.getMessage("X012", ex.getMessage()));
			xmlEx.setStackTrace(ex.getStackTrace());
			throw xmlEx;
		}
		return doc;
	}

	/**
	 * Convierte un caden XML a una variable de tipo Document
	 */
	/*
	 * public static Document stringXMLToDoc(String mensajeXML) throws
	 * XMLException { Document doc = null; DocumentBuilderFactory dbf = null;
	 * int indice1 = mensajeXML.indexOf("<?xml version="); if (indice1 == -1) {
	 * mensajeXML = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>" +
	 * mensajeXML; } try { dbf = DocumentBuilderFactory.newInstance();
	 * DocumentBuilder builder = dbf.newDocumentBuilder();
	 * builder.setErrorHandler(new MyErrorHandler());
	 * dbf.setNamespaceAware(true); doc = builder.parse(new
	 * ByteArrayInputStream(mensajeXML.getBytes("ISO-8859-1"))); }catch
	 * (UTFDataFormatException ioE){ //Lanzamiento de Excepcion XMLException
	 * internaEx = new XMLException(MsgErr.getMessage("X025"));
	 * internaEx.initCause(ioE.getCause());
	 * internaEx.setStackTrace(ioE.getStackTrace()); throw internaEx; } catch
	 * (ParserConfigurationException parE) { //Lanzamiento de Excepcion
	 * XMLException xmlEx = new XMLException(MsgErr.getMessage("X001"));
	 * xmlEx.setStackTrace(parE.getStackTrace()); throw xmlEx; } catch
	 * (SAXParseException saxPE) { //Lanzamiento de Excepcion XMLException xmlEx
	 * = new XMLException(MsgErr.getMessage("X002"));
	 * xmlEx.setStackTrace(saxPE.getStackTrace()); throw xmlEx; } catch
	 * (SAXException saxE) { //Lanzamiento de Excepcion XMLException xmlEx = new
	 * XMLException(MsgErr.getMessage("X002"));
	 * xmlEx.setStackTrace(saxE.getStackTrace()); throw xmlEx; } catch
	 * (IOException ioE) { //Lanzamiento de Excepcion XMLException xmlEx = new
	 * XMLException(MsgErr.getMessage("X003"));
	 * xmlEx.setStackTrace(ioE.getStackTrace()); throw xmlEx; } catch (Exception
	 * ex) { //Lanzamiento de Excepcion XMLException xmlEx = new
	 * XMLException(MsgErr.getMessage("X012"));
	 * xmlEx.setStackTrace(ex.getStackTrace()); throw xmlEx; } return doc; }
	 */
	/**
	 * Convierte un caden XML a una variable de tipo Document
	 */
	public static Document stringXMLToDocument(String mensajeXML) throws XMLException {
		Document doc = null;
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			factory.setNamespaceAware(true);
			DocumentBuilder builder = factory.newDocumentBuilder();
			// doc = builder.parse(new InputSource(new
			// StringReader(mensajeXML)));
			doc = builder.parse(new ByteArrayInputStream(mensajeXML.getBytes("ISO-8859-1")));
		} catch (UTFDataFormatException ioE) {
			// Lanzamiento de Excepcion
			XMLException internaEx = new XMLException(MsgErr.getMessage("X025"));
			internaEx.initCause(ioE.getCause());
			internaEx.setStackTrace(ioE.getStackTrace());
			throw internaEx;
		} catch (ParserConfigurationException parE) {
			// Lanzamiento de Excepcion
			XMLException xmlEx = new XMLException(MsgErr.getMessage("X001"));
			xmlEx.setStackTrace(parE.getStackTrace());
			throw xmlEx;
		} catch (SAXParseException saxPE) {
			// Lanzamiento de Excepcion
			XMLException xmlEx = new XMLException(MsgErr.getMessage("X002"));
			xmlEx.setStackTrace(saxPE.getStackTrace());
			throw xmlEx;
		} catch (SAXException saxE) {
			// Lanzamiento de Excepcion
			XMLException xmlEx = new XMLException(MsgErr.getMessage("X002"));
			xmlEx.setStackTrace(saxE.getStackTrace());
			throw xmlEx;
		} catch (IOException ioE) {
			// Lanzamiento de Excepcion
			XMLException xmlEx = new XMLException(MsgErr.getMessage("X003"));
			xmlEx.setStackTrace(ioE.getStackTrace());
			throw xmlEx;
		} catch (Exception ex) {
			// Lanzamiento de Excepcion
			XMLException xmlEx = new XMLException(MsgErr.getMessage("X012", ex.getMessage()));
			xmlEx.setStackTrace(ex.getStackTrace());
			throw xmlEx;
		}
		return doc;
	}

	/**
	 * Salva persistentemente una cadena dentro un archivo
	 */
	public static void guardarArchivo(String path, String cadena) throws InternaException {
		try {
			File archivo = new File(path);
			FileWriter out = new FileWriter(archivo);
			out.write(cadena);
			out.close();
		} catch (IOException e) {
			InternaException intEx = new InternaException(MsgErr.getMessage("I012"));
			intEx.setStackTrace(e.getStackTrace());
			throw intEx;
		}
	}

	/**
	 * Renombra un archivo
	 */
	private boolean renameFile(File from_file, File to_file) throws InternaException {
		try {
			Throwable last_error = null;
			for (int i = 0; i < 5; i++) {
				if (i > 0) {
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
					}
					System.out.println("Falla al renombrar archivo '" + from_file.toString() + "' , reintentando ...");
				}
				if (from_file.renameTo(to_file)) {
					return (true);
				} else {
					// can't rename across file systems under Linux - try
					// copy+delete
					FileInputStream fis = null;
					FileOutputStream fos = null;
					try {
						fis = new FileInputStream(from_file);
						fos = new FileOutputStream(to_file);
						byte[] buffer = new byte[65536];
						while (true) {
							int len = fis.read(buffer);
							if (len <= 0) {
								break;
							}
							fos.write(buffer, 0, len);
						}
						fos.close();
						fos = null;
						fis.close();
						fis = null;
						from_file.delete();
						return (true);
					} catch (Throwable e) {
						last_error = e;
					} finally {
						if (fis != null) {
							try {
								fis.close();
							} catch (Throwable e) {
							}
						}
						if (fos != null) {
							try {
								fos.close();
							} catch (Throwable e) {
							}
						}
					}
				}
			}
			System.out.println("Falla al renombrar '" + from_file.toString() + "' a ' " + to_file.toString() + "'");
			if (last_error != null) {
				InternaException intEx = new InternaException(MsgErr.getMessage("I012"));
				throw intEx;
			}
		} catch (Throwable e) {
			System.out.println("Error: " + e.getMessage());
			InternaException intEx = new InternaException(MsgErr.getMessage("I012"));
			intEx.initCause(e.getCause());
			intEx.setStackTrace(e.getStackTrace());
			throw intEx;
		}
		return (false);
	}

	/**
	 * Metodo para validar con un esquema XSD (nuevo!!!)
	 *
	 * @param cadenaXML
	 *            Una cadena XML
	 * @param archXSD
	 *            El path del archivo esquema XSD
	 * @throws transferencia.XMLException
	 *             Lanza una excepcion de tipo XML
	 * @return Un documento XML
	 */
	public static void validarConEsquema(String cadenaXML, String archXSD) throws XMLException {
		try {
			XMLReader reader = XMLReaderFactory.createXMLReader("org.apache.xerces.parsers.SAXParser");
			reader.setFeature("http://xml.org/sax/features/validation", true);
			reader.setFeature("http://apache.org/xml/features/validation/schema", true);
			reader.setProperty("http://apache.org/xml/properties/schema/external-noNamespaceSchemaLocation", archXSD);
			MyDefaultHandler handler = new MyDefaultHandler();
			reader.setContentHandler(handler);
			reader.setErrorHandler(handler);
			InputSource is = new InputSource(new StringReader(cadenaXML));
			is.setEncoding("ISO-8859-1");
			reader.parse(is);
			// reader.parse(new InputSource(new StringReader(cadenaXML)));
		} catch (UTFDataFormatException ioE) {
			// Lanzamiento de Excepcion
			XMLException internaEx = new XMLException(MsgErr.getMessage("X025"));
			internaEx.initCause(ioE.getCause());
			internaEx.setStackTrace(ioE.getStackTrace());
			throw internaEx;
		} catch (SAXException sax) {
			XMLException xmlex = new XMLException("X007 - Documento XML no valido: " + sax.getMessage());
			throw xmlex;
		} catch (IOException exc) {
			XMLException xmlex = new XMLException("I018 - Error Interno: el archivo XSD para la validacion del mensaje XML"
					+ " no pudo ser hubicado en la ruta especificada.");
			throw xmlex;
		}
	}

	/**
	 * Recupera el contenido de un Archivo
	 */
	public static String getContentFromFile(String pathFileXML) throws InternaException {
		try {
			InputStream in = new BufferedInputStream(new FileInputStream(pathFileXML));
			ByteArrayOutputStream baos = new ByteArrayOutputStream(in.available());

			byte[] b = new byte[in.available()];
			int len = 0;

			String d = "";
			while ((len = in.read(b)) != -1) {
				baos.write(b, 0, len);
			}

			return new String(baos.toByteArray());

		} catch (FileNotFoundException shouldnt_happen) {
			InternaException xmlex = new InternaException(MsgErr.getMessage("I014", pathFileXML));
			throw xmlex;
		} catch (IOException iox) {
			InternaException xmlex = new InternaException(MsgErr.getMessage("I015", iox.getMessage()));
			throw xmlex;
		}
	}
	public static void main(String[] args) {
		String nodeAsStringTGN = "<respuesta><ID>1</ID><Fecha>20131028</Fecha><totalReg>2</totalReg><Autorizados><Autorizado><codigo>003359</codigo><prestamo/><estado>A</estado><observacion/><cuentaServicio>5970034001</cuentaServicio><libretaServicio>00990201009</libretaServicio><cuentaComisiones>3987069001</cuentaComisiones><libretaComisiones>00990201001</libretaComisiones></Autorizado><Autorizado><codigo>003365</codigo><prestamo>17000</prestamo><estado>A</estado><observacion/><cuentaServicio>5970034001</cuentaServicio><libretaServicio>00990201009</libretaServicio><cuentaComisiones>3987069001</cuentaComisiones><libretaComisiones>00990201001</libretaComisiones></Autorizado></Autorizados></respuesta>";
		String cod;
		try {
			cod = XMLTools.getXMLTagValue(nodeAsStringTGN, "prestamo");
			System.out.println(cod);			
		} catch (XMLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}