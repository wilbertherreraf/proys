/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author CUriona
 */
@Entity
@Table(name = "mensaje_datos")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "MensajeDatos.findAll", query = "SELECT m FROM MensajeDatos m"),
    @NamedQuery(name = "MensajeDatos.findByMenCodigo", query = "SELECT m FROM MensajeDatos m WHERE m.mensajeDatosPK.menCodigo = :menCodigo"),
    @NamedQuery(name = "MensajeDatos.findByCamBloque", query = "SELECT m FROM MensajeDatos m WHERE m.mensajeDatosPK.camBloque = :camBloque"),
    @NamedQuery(name = "MensajeDatos.findByCamCodigo", query = "SELECT m FROM MensajeDatos m WHERE m.mensajeDatosPK.camCodigo = :camCodigo"),
    @NamedQuery(name = "MensajeDatos.findByMdtValor", query = "SELECT m FROM MensajeDatos m WHERE m.mdtValor = :mdtValor")})
public class MensajeDatos implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected MensajeDatosPK mensajeDatosPK;
    @Basic(optional = false)
    @NotNull
    @Column(name = "mdt_valor", nullable = false)
    private String mdtValor;
//    @JoinColumn(name = "men_codigo", referencedColumnName = "men_codigo", nullable = false, insertable = false, updatable = false)
//    @ManyToOne(optional = false, fetch = FetchType.LAZY)
//    private Mensaje mensaje;
    /*@JoinColumns({
        @JoinColumn(name = "cam_bloque", referencedColumnName = "cam_bloque", nullable = false, insertable = false, updatable = false),
        @JoinColumn(name = "cam_codigo", referencedColumnName = "cam_codigo", nullable = false, insertable = false, updatable = false)})
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Campos campos;*/

    public MensajeDatos() {
    }

    public MensajeDatos(MensajeDatosPK mensajeDatosPK) {
        this.mensajeDatosPK = mensajeDatosPK;
    }

    public MensajeDatos(MensajeDatosPK mensajeDatosPK, String mdtValor) {
        this.mensajeDatosPK = mensajeDatosPK;
        this.mdtValor = mdtValor;
    }

    public MensajeDatos(String menCodigo, short camBloque, String camCodigo) {
        this.mensajeDatosPK = new MensajeDatosPK(menCodigo, camBloque, camCodigo);
    }

    public MensajeDatosPK getMensajeDatosPK() {
        return mensajeDatosPK;
    }

    public void setMensajeDatosPK(MensajeDatosPK mensajeDatosPK) {
        this.mensajeDatosPK = mensajeDatosPK;
    }

    public String getMdtValor() {
        return mdtValor;
    }

    public void setMdtValor(String mdtValor) {
        this.mdtValor = mdtValor;
    }

//    public Mensaje getMensaje() {
//        return mensaje;
//    }
//
//    public void setMensaje(Mensaje mensaje) {
//        this.mensaje = mensaje;
//    }

    /*public Campos getCampos() {
        return campos;
    }

    public void setCampos(Campos campos) {
        this.campos = campos;
    }*/

	@Override
	public String toString() {
		return "MensajeDatos [mensajeDatosPK=" + mensajeDatosPK + ", mdtValor=" + mdtValor + "]";
	}


    
}
