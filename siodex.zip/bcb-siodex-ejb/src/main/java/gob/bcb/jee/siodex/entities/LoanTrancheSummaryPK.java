/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author CUriona
 */
@Embeddable
public class LoanTrancheSummaryPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 15)
    @Column(name = "LOAN_ID")
    private String loanId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "TRANCHE_NO")
    private int trancheNo;

    public LoanTrancheSummaryPK() {
    }

    public LoanTrancheSummaryPK(String loanId, int trancheNo) {
        this.loanId = loanId;
        this.trancheNo = trancheNo;
    }

    public String getLoanId() {
        return loanId;
    }

    public void setLoanId(String loanId) {
        this.loanId = loanId;
    }

    public int getTrancheNo() {
        return trancheNo;
    }

    public void setTrancheNo(int trancheNo) {
        this.trancheNo = trancheNo;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (loanId != null ? loanId.hashCode() : 0);
        hash += (int) trancheNo;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof LoanTrancheSummaryPK)) {
            return false;
        }
        LoanTrancheSummaryPK other = (LoanTrancheSummaryPK) object;
        if ((this.loanId == null && other.loanId != null) || (this.loanId != null && !this.loanId.equals(other.loanId))) {
            return false;
        }
        if (this.trancheNo != other.trancheNo) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gob.bcb.siodex.entities.LoanTrancheSummaryPK[ loanId=" + loanId + ", trancheNo=" + trancheNo + " ]";
    }
    
}
