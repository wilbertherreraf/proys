/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author CUriona
 */
@Entity
@Table(name = "REPORTES.VC_DATOS_ADIC")
public class DatosAdicionales implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected DatosAdicionalesPK datosAdicionalesPK;
    @Size(max = 20)
    @Column(name = "SIGLA_PROV")
    private String siglaProv;
    @Size(max = 60)
    @Column(name = "PROVEEDOR")
    private String proveedor;

    public DatosAdicionales() {
    }

    public DatosAdicionales(DatosAdicionalesPK datosAdicionalesPK) {
        this.datosAdicionalesPK = datosAdicionalesPK;
    }

    public DatosAdicionales(DatosAdicionalesPK datosAdicionalesPK, String siglaProv, String proveedor) {
        this.datosAdicionalesPK = datosAdicionalesPK;
        this.setSiglaProv(siglaProv);
        this.setProveedor(proveedor);
    }

    public DatosAdicionales(String loNo, short traNo) {
        this.datosAdicionalesPK = new DatosAdicionalesPK(loNo, traNo);
    }

    public DatosAdicionalesPK getDatosAdicionalesPK() {
        return datosAdicionalesPK;
    }

    public void setDatosAdicionalesPK(DatosAdicionalesPK datosAdicionalesPK) {
        this.datosAdicionalesPK = datosAdicionalesPK;
    }

    public String getSiglaProv() {
		return siglaProv;
	}

	public void setSiglaProv(String siglaProv) {
		this.siglaProv = siglaProv;
	}

	public String getProveedor() {
		return proveedor;
	}

	public void setProveedor(String proveedor) {
		this.proveedor = proveedor;
	}

	@Override
    public int hashCode() {
        int hash = 0;
        hash += (datosAdicionalesPK != null ? datosAdicionalesPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof DatosAdicionales)) {
            return false;
        }
        DatosAdicionales other = (DatosAdicionales) object;
        if ((this.datosAdicionalesPK == null && other.datosAdicionalesPK != null) || (this.datosAdicionalesPK != null && !this.datosAdicionalesPK.equals(other.datosAdicionalesPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gob.bcb.siodex.entities.DatosAdicionales[ datosAdicionalesPK=" + datosAdicionalesPK + " ]";
    }
    
}
