package gob.bcb.jee.siodex.service;

import gob.bcb.jee.siodex.QL.*;
import gob.bcb.jee.siodex.entities.ComOpers;
import gob.bcb.jee.siodex.entities.DebtServOpers;
import gob.bcb.jee.siodex.entities.SchDebtServPmts;
import gob.bcb.jee.siodex.entities.TmpOperacionDeuda;
import org.apache.log4j.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


/**
 * Clase que contiene los metodos para crear los campos de un mensaje swift.
 *
 * @author C. Cecilia Uriona
 *
 */
@Stateless
public class DeudaSigadeBean implements DeudaSigadeBeanLocal {

	static final Logger logger = Logger.getLogger(DeudaSigadeBean.class);

	@PersistenceContext(unitName = "dms1")
	//@PersistenceContext(unitName = "siodex")
			EntityManager em;

	@Inject
	private TmpDeudaQLBeanLocal deudaBeanLocal;

	@Inject
	private DebtServOpersQLBeanLocal dsoQLBeanLocal;

	@Inject
	private SchDebtServPmtsQLBeanLocal sdspQLBeanLocal;

	@Inject
	private ComOpersQLBeanLocal coQLBeanLocal;

	@Inject
	private DAQLBeanLocal dAQLBeanLocal;

	private Integer continuar = 1;

	private DebtServOpers vObjDebtServOpers = null;

	private SchDebtServPmts schDebtServPmts = null;

	private ComOpers coop = null;

	/**
	 * Método que registra en base de datos DMS1 del sistema SIGADE.
	 * @pCodigoOperacion Codigo de operación.
	 */
	public Integer registrarSigade(String pCodigoOperacion) {
		// Escribe en el log del sistema codigo de liquidación.
		logger.info("Creando el registro para el SIGADE: ");
		logger.info("registros deuda: " + pCodigoOperacion);

		// Concatena codigo de liquidación.
//		String vCodigoOperacion = "S" + pCodigoOperacion.substring(1);
		String vCodigoOperacion = "S" + pCodigoOperacion;

		// Obtiene lista de operaciones de liquidación (Capital, interes y comisiones).
		List<TmpOperacionDeuda> vListaTmpOperacionDeuda  = deudaBeanLocal.listaDeuda(vCodigoOperacion);

		// Recorre lista de tipo "TmpOperacionDeuda".
		for (TmpOperacionDeuda vObjTmpOperacionDeuda : vListaTmpOperacionDeuda) {

			// Verifica codigo de transacción Capital.
			if (vObjTmpOperacionDeuda.getCdTrnsTyp().equals("11")) {

				// Registra capital en "Debt_Serv_Opers".
				continuar = registrarIntereses(vObjTmpOperacionDeuda);
			}

			// Verifica que la insercion fue correcta.
			if (continuar == 1) {
				// Verifica codigo de transaccion Interes.
				if (vObjTmpOperacionDeuda.getCdTrnsTyp().equals("21")) {

					// Registra interes en "Debt_Serv_Opers".
					continuar = registrarIntereses(vObjTmpOperacionDeuda);
				}

				// Verifica que la insercion fue correcta.
				if (continuar == 1) {
					// Verifica codigo de transacción Comisión.
					if (vObjTmpOperacionDeuda.getCdTrnsTyp().equals("31")) {

						// Registra comision en "Debt_Serv_Opers".
						continuar = registrarComisiones(vObjTmpOperacionDeuda);
					}
				}
			}
		}
		// Retorna resultado.
		return continuar;
	}


	/**
	 * Método que registra en base de datos DMS1 del sistema SIGADE.
	 * @pObjOperacionDeuda Entidad de tipo "TmpOperacionDeuda".
	 */
	private Integer registrarIntereses(TmpOperacionDeuda pObjOperacionDeuda) {

		// Escribe en el log del sistema.
		logger.info("Creando el registro capital/interes: ");
		logger.info("registro capital/interes: " + pObjOperacionDeuda.getTmpOperacionDeudaPK().getDeuCodigo());

		try {
			// Instancia objeto de tipo "SimpleDateFormat".
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

			// Obtiene identificador de ultimo registro a insertar.
			Integer vDsoId = SequenciaDSODms1();

			// Verifica que el identificador sea mayor a cero.
			if (vDsoId > 0) {

				// Verifica si el identificador "SdspId" es mayor a cero.
				if(pObjOperacionDeuda.getSdspId() > 0)
				{
					// Almacena variables en el objeto a insertar.
					vObjDebtServOpers = new DebtServOpers(vDsoId);
					vObjDebtServOpers.setLoNo(pObjOperacionDeuda.getLoNo());
					vObjDebtServOpers.setTraNo(pObjOperacionDeuda.getTraNo());
					vObjDebtServOpers.setdCredVal(pObjOperacionDeuda.getDCredVal());
					vObjDebtServOpers.setdDbrVal(pObjOperacionDeuda.getDDbrVal());
					vObjDebtServOpers.setCgTrnsTyp(pObjOperacionDeuda.getCgTrnsTyp());
					vObjDebtServOpers.setCdTrnsTyp(pObjOperacionDeuda.getCdTrnsTyp());
					Integer idp = DSOIdDms1(pObjOperacionDeuda.getLoNo(), pObjOperacionDeuda.getTraNo(), sdf.format(pObjOperacionDeuda.getDDbrVal()), pObjOperacionDeuda.getCgTrnsTyp(), pObjOperacionDeuda.getCdTrnsTyp());
					vObjDebtServOpers.setDsoIdp(idp);
					vObjDebtServOpers.setdSch(pObjOperacionDeuda.getDSch());
					vObjDebtServOpers.setCuEff(pObjOperacionDeuda.getCuEff());
					vObjDebtServOpers.setAmtCuEff(pObjOperacionDeuda.getAmtCuEff());
					vObjDebtServOpers.setAmtCuLocal(pObjOperacionDeuda.getAmtCuLocal());
					vObjDebtServOpers.setAmtCuBase(pObjOperacionDeuda.getAmtCuBase());
					vObjDebtServOpers.setAmtSch(pObjOperacionDeuda.getAmtSch());
					vObjDebtServOpers.setAmtCuLo(pObjOperacionDeuda.getAmtCuLo());
					vObjDebtServOpers.setAmtCuSdr(pObjOperacionDeuda.getAmtCuSdr());
					vObjDebtServOpers.setAmtCusd(pObjOperacionDeuda.getAmtCuUsd());
					vObjDebtServOpers.setdLocalExchRte(pObjOperacionDeuda.getDLocalExchRte());
					vObjDebtServOpers.setCgMedium(pObjOperacionDeuda.getCgMedium());
					vObjDebtServOpers.setCdMedium(pObjOperacionDeuda.getCdMedium());
					vObjDebtServOpers.setRef("SIODEX");
					vObjDebtServOpers.setSdspId(pObjOperacionDeuda.getSdspId());
					vObjDebtServOpers.setdEntry(new Date());
					vObjDebtServOpers.setAmtCuEur(pObjOperacionDeuda.getAmtCuEur());
					vObjDebtServOpers.setCgPaymentStatus(243);
					vObjDebtServOpers.setCdPaymentStatus("0");

					// Inserta objeto de tipo "vObjDebtServOpers".
					dsoQLBeanLocal.create(vObjDebtServOpers);

				}
			}
		}
		catch (Exception e) {
			// Asigna valor de insercion incorrecta.
			continuar = 0;
			// Escribe en el log del sistema.
			logger.info("Error al generar registro capital/interes en el SIGADE: " + e.getMessage());
			logger.info("error en registro capital/interes sigade: " + e.getMessage());
			e.printStackTrace();
		}
		// Retorna resultado de la inserción.
		return continuar;
	}

	/**
	 * Método que modifica en base de datos DMS1 del sistema SIGADE.
	 * @pObjOperacionDeuda Entidad de tipo "TmpOperacionDeuda".
	 */
	private Integer modificarSchDebtServPmts(TmpOperacionDeuda pObjOperacionDeuda) {
		// Escribe en el log del sistema.
		logger.info("Modificacion de registro capital/interes: ");
		logger.info("Modificacion capital/interes: " + pObjOperacionDeuda.getTmpOperacionDeudaPK().getDeuCodigo());

		try {
			// Verifica que el identificador sea mayor a cero.
			if (pObjOperacionDeuda.getSdspId() > 0) {
				// Inicializa objeto de tipo "SchDebtServPmts".
				schDebtServPmts = new SchDebtServPmts();
				// Asigna identeificador.
				schDebtServPmts.setSdspId(pObjOperacionDeuda.getSdspId());
				// Asigna valor cero para la operación (Capital/Interes).
				schDebtServPmts.setAmtUnpaid(BigDecimal.ZERO);
				// Modifica el registro instanciado.
				sdspQLBeanLocal.edit(schDebtServPmts);
			}
		}
		catch (Exception e) {
			// Asigna valor de modificación incorrecta.
			continuar = 0;
			// Escribe en el log del sistema.
			logger.info("Error al generar registro capital/interes en el SIGADE: "+ e.getMessage());
			logger.info("error en registro capital/interes sigade: " + e.getMessage());
			e.printStackTrace();
		}
		// Retorna resultado de la inserción.
		return continuar;
	}

	private Integer registrarComisiones(TmpOperacionDeuda deuda) {

		logger.info("Creando el registro comisiones: ");
		logger.info("registro comisiones: " + deuda.getTmpOperacionDeudaPK().getDeuCodigo());

		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Integer coopId = SequenciaCODms1();
			if (coopId > 0) {
				coop = new ComOpers(coopId);
				coop.setLoNo(deuda.getLoNo());
				coop.setdDbrVal(deuda.getDDbrVal());
				coop.setCgTrnsTyp(deuda.getCgTrnsTyp());
				coop.setCdTrnsTyp(deuda.getCdTrnsTyp());
				Integer idp = COIdDms1(deuda.getLoNo(), sdf.format(deuda.getDDbrVal()), deuda.getCgTrnsTyp(), deuda.getCdTrnsTyp(),
						deuda.getCgFeeTyp(), deuda.getCdFeeTyp());
				coop.setCoopIdp(idp);
				coop.setCgFeeTyp(deuda.getCgFeeTyp());
				coop.setCdFeeTyp(deuda.getCdFeeTyp());
				coop.setdSch(deuda.getDSch());
				coop.setdCredVal(deuda.getDCredVal());
				coop.setCuEff(deuda.getCuEff());
				coop.setAmtCuEff(deuda.getAmtCuEff());
				coop.setAmtCuLocal(deuda.getAmtCuLocal());
				coop.setAmtCuBase(deuda.getAmtCuBase());
				coop.setAmtCuSdr(deuda.getAmtCuSdr());
				coop.setAmtCuUsd(deuda.getAmtCuUsd());
				coop.setdLocalExchRte(deuda.getDLocalExchRte());
				coop.setCgMedium(deuda.getCgMedium());
				coop.setCdMedium(deuda.getCdMedium());
				coop.setRef("SIODEX");
				coop.setScpId(deuda.getSdspId());
				coop.setTraLoNo(deuda.getLoNo());
				coop.setTraNo(deuda.getTraNo());
				coop.setdEntry(new Date());
				coop.setAmtSch(deuda.getAmtSch());
				coop.setAmtCuEur(deuda.getAmtCuEur());
				coop.setCgPaymentStatus(243);
				coop.setCdPaymentStatus("0");

				coQLBeanLocal.create(coop);
			}
		}

		catch (Exception e) {
			continuar = 0;
			logger.info("Error al generar registro comisiones en el SIGADE: "
					+ e.getMessage());
			logger.info("error en registro comisiones sigade: " + e.getMessage());
			e.printStackTrace();
		}

		return continuar;
	}

	private Integer SequenciaDSODms1() {

		Integer dso = 0;

		StringBuilder query = new StringBuilder();
		query.append("");
		query.append(" SELECT ");
		query.append(" dmfas.seq_debtservoper.nextval ");
		query.append(" FROM dual ");

		dso = dAQLBeanLocal.nativoSimple(query.toString());

		logger.info("Object: " + dso.toString());
		logger.info("seq: " + (dso == null ? "NULL" : dso.toString()));

		return dso;
	}

	private Integer SequenciaCODms1() {

		Integer coop = 0;

		StringBuilder query = new StringBuilder();
		query.append("");
		query.append(" SELECT max(coop_id)");
		query.append(" FROM dmfas.com_opers ");

		coop = dAQLBeanLocal.nativoSimple(query.toString());

		if (coop != null) {
			coop ++;
		}

		logger.info("Object: " + coop.toString());
		logger.info("seqC: " + (coop == null ? "NULL" : coop.toString()));

		return coop;
	}

	private Integer DSOIdDms1(String ptm, int tra, String fecha, int grupo, String tipo) {

		Integer idp = 0;

		StringBuilder query = new StringBuilder();
		query.append("");
		query.append(" SELECT decode(max(dso_idp),null,0, max(dso_idp))");
		query.append(" from	dmfas.debt_serv_opers");
		query.append(" where lo_no = '" + ptm + "'");
		query.append(" and	tra_no = " + tra);
		query.append(" and	d_dbr_val = to_date('" + fecha + "', 'yyyy-mm-dd')");
		query.append(" and	cg_trns_typ = " + grupo);
		query.append(" and	cd_trns_typ = '" + tipo + "'");

		idp = dAQLBeanLocal.nativoSimple(query.toString());

		if (idp != null) {
			idp ++;
		}

		logger.info("Object: " + idp.toString());
		logger.info("idp: " + (idp == null ? "NULL" : idp.toString()));

		return idp;
	}

	private Integer COIdDms1(String ptm, String fecha, int grupo, String tipo, int grupo1, String tipo1) {

		Integer idp = 0;

		StringBuilder query = new StringBuilder();
		query.append("");
		query.append(" SELECT decode(max(coop_idp),null,0, max(coop_idp))");
		query.append(" from	dmfas.com_opers");
		query.append(" where lo_no = '" + ptm + "'");
		query.append(" and	d_dbr_val = to_date('" + fecha + "', 'yyyy-mm-dd')");
		query.append(" and	cg_trns_typ = " + grupo);
		query.append(" and	cd_trns_typ = '" + tipo + "'");
		query.append(" and	cg_fee_typ = " + grupo1);
		query.append(" and	cd_fee_typ = '" + tipo1 + "'");

		idp = dAQLBeanLocal.nativoSimple(query.toString());

		if (idp != null) {
			idp ++;
		}

		logger.info("Object: " + idp.toString());
		logger.info("idp: " + (idp == null ? "NULL" : idp.toString()));

		return idp;
	}

}
