/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author CUriona
 */
@Entity
@Table(name = "mensaje_estado")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "MensajeEstado.findAll", query = "SELECT m FROM MensajeEstado m"),
    @NamedQuery(name = "MensajeEstado.findByLiqCodigo", query = "SELECT m FROM MensajeEstado m WHERE m.mensajeEstadoPK.menCodigo = :menCodigo"),
    @NamedQuery(name = "MensajeEstado.findByCveEstado", query = "SELECT m FROM MensajeEstado m WHERE m.mensajeEstadoPK.cveEstadoS = :cveEstadoS")})
public class MensajeEstado implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected MensajeEstadoPK mensajeEstadoPK;
    @Size(max = 1024)
    @Column(name = "observacion", length = 1024)
    private String observacion;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 16)
    @Column(name = "usr_codigo", nullable = false, length = 16)
    private String usrCodigo;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fecha_hora", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaHora;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 30)
    @Column(name = "estacion", nullable = false, length = 30)
    private String estacion;
    @JoinColumn(name = "men_codigo", referencedColumnName = "men_codigo", nullable = false, insertable = false, updatable = false)
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Mensaje mensaje;

    public MensajeEstado() {
    }

    public MensajeEstado(MensajeEstadoPK mensajeEstadoPK) {
        this.mensajeEstadoPK = mensajeEstadoPK;
    }

    public MensajeEstado(MensajeEstadoPK mensajeEstadoPK, String usrCodigo, Date fechaHora, String estacion) {
        this.mensajeEstadoPK = mensajeEstadoPK;
        this.usrCodigo = usrCodigo;
        this.fechaHora = fechaHora;
        this.estacion = estacion;
    }

    public MensajeEstado(MensajeEstadoPK mensajeEstadoPK, String observacion, String usrCodigo, Date fechaHora, String estacion) {
        this.mensajeEstadoPK = mensajeEstadoPK;
        this.observacion = observacion;
        this.usrCodigo = usrCodigo;
        this.fechaHora = fechaHora;
        this.estacion = estacion;
    }
    
    public MensajeEstado(String menCodigo, String cveEstadoS) {
        this.mensajeEstadoPK = new MensajeEstadoPK(menCodigo, cveEstadoS);
    }

    public MensajeEstadoPK getMensajeEstadoPK() {
        return mensajeEstadoPK;
    }

    public void setMensajeEstadoPK(MensajeEstadoPK mensajeEstadoPK) {
        this.mensajeEstadoPK = mensajeEstadoPK;
    }

    public String getObservacion() {
        return observacion;
    }

    public void setObservacion(String observacion) {
        this.observacion = observacion;
    }

    public String getUsrCodigo() {
        return usrCodigo;
    }

    public void setUsuario(String usrCodigo) {
        this.usrCodigo = usrCodigo;
    }

    public Date getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(Date fechaHora) {
        this.fechaHora = fechaHora;
    }

	public String getEstacion() {
		return estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Mensaje getMensaje() {
        return mensaje;
    }

    public void setMensaje(Mensaje mensaje) {
        this.mensaje = mensaje;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (mensajeEstadoPK != null ? mensajeEstadoPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof MensajeEstado)) {
            return false;
        }
        MensajeEstado other = (MensajeEstado) object;
        if ((this.mensajeEstadoPK == null && other.mensajeEstadoPK != null) || (this.mensajeEstadoPK != null && !this.mensajeEstadoPK.equals(other.mensajeEstadoPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gob.bcb.siodex.entities.MensajeEstado[ mensajeEstadoPK=" + mensajeEstadoPK + " ]";
    }
    
}
