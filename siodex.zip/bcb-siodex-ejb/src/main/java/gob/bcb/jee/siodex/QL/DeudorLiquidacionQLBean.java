package gob.bcb.jee.siodex.QL;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TemporalType;

import org.apache.log4j.Logger;

import gob.bcb.jee.siodex.entities.ComisionBancaria;
import gob.bcb.jee.siodex.entities.DeudorLiquidacion;

@Stateless
@LocalBean
public class DeudorLiquidacionQLBean extends DaoGeneric<DeudorLiquidacion> implements DeudorLiquidacionQLBeanLocal {
	static final Logger logger = Logger.getLogger(DeudorLiquidacionQLBean.class);

	@PersistenceContext(unitName = "siodex")
	EntityManager em;

	public DeudorLiquidacionQLBean() {
		super(DeudorLiquidacion.class);
	}
	
	/* (non-Javadoc)
	 * @see gob.bcb.jee.siodex.QL.DeudorLiquidacionQLBeanLocal#listaCorreos(java.lang.String, boolean)
	 */
	@Override
	public List<DeudorLiquidacion> listaCorreos(String codInstitucion, boolean enviarAIFA){
		List<DeudorLiquidacion> lista = new ArrayList<DeudorLiquidacion>();

		StringBuilder jsql = new StringBuilder();
		jsql.append("select d from DeudorLiquidacion d where d.cveVigente = 1 ");

		if (enviarAIFA) {
			jsql.append("and d.genLiq in (" + codInstitucion + ",900) ");
		} else {
			jsql.append("and d.genLiq = 900 ");
		}

		Query consulta = em.createQuery(jsql.toString());

		lista = consulta.getResultList();

		return lista;		
	}
	public DeudorLiquidacion getByCodInstitucion(Integer codInstitucion){
		StringBuilder query = new StringBuilder();

		query.append("select d from DeudorLiquidacion d where d.cveVigente = 1 ");
		query.append("and d.genLiq = :codInstitucion ");
		
		Query consulta = em.createQuery(query.toString());
		consulta.setParameter("codInstitucion", codInstitucion);

		logger.info("Ejecutado getByCodInstitucion: " + query.toString() + "; para " + codInstitucion);
		List lista = consulta.getResultList();
		if (lista.size() > 0){
			return (DeudorLiquidacion) lista.get(0);
		}
		return null;

	}
	public DeudorLiquidacion getByCodSigade(String deuCodigo){
		StringBuilder query = new StringBuilder();

		query.append("select d from DeudorLiquidacion d ");
		query.append("where d.deuCodigo = :deuCodigo ");
		
		Query consulta = em.createQuery(query.toString());
		consulta.setParameter("deuCodigo", deuCodigo);

		//logger.info("Ejecutado getByCodSigade " + query.toString() + " para " + deuCodigo);
		List lista = consulta.getResultList();
		if (lista.size() > 0){
			return (DeudorLiquidacion) lista.get(0);
		}
		return null;

	}	
	@Override
	public void setEntityManager(EntityManager entityManager) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public EntityManager getEntityManager() {
		// TODO Auto-generated method stub
		return em;
	}
}
