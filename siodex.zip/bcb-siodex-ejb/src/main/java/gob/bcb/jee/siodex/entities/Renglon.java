/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author CUriona
 */

@SuppressWarnings("serial")
public class Renglon implements java.io.Serializable {
	private String liqCodigo;
	private String liqDetalle;
	private String liqRenglon;
    private String cveConcepto;
    private Date fechaValor;
    private BigDecimal montoMo;
    private String tipoTasa;
    private BigDecimal tasa;
    private Integer dias;
    private BigDecimal calculoMo;
    private String tipoLiq;
    private BigDecimal centavos;
    private Date fechaVenc;
    private Integer anio;
    private Integer imprimir;
    private Boolean verFecha;

    public Renglon() {
    	
    }

    public Renglon(String liqCodigo, String liqDetalle, String liqRenglon,
			String cveConcepto, Date fechaValor, BigDecimal montoMo,
			BigDecimal tasa, Integer dias,
			BigDecimal calculoMo, String tipoLiq, 
			Date fechaVenc, Integer anio, Integer imprimir) {
		super();
		this.liqCodigo = liqCodigo;
		this.liqDetalle = liqDetalle;
		this.liqRenglon = liqRenglon;
		this.cveConcepto = cveConcepto;
		this.fechaValor = fechaValor;
		this.montoMo = montoMo;
		this.tasa = tasa;
		this.dias = dias;
		this.calculoMo = calculoMo;
		this.tipoLiq = tipoLiq;
		this.fechaVenc = fechaVenc;
		this.anio = anio;
		this.imprimir = imprimir;
	}

	public String getLiqCodigo() {
		return liqCodigo;
	}

	public void setLiqCodigo(String liqCodigo) {
		this.liqCodigo = liqCodigo;
	}

	public String getLiqDetalle() {
		return liqDetalle;
	}

	public void setLiqDetalle(String liqDetalle) {
		this.liqDetalle = liqDetalle;
	}

	public String getLiqRenglon() {
		return liqRenglon;
	}

	public void setLiqRenglon(String liqRenglon) {
		this.liqRenglon = liqRenglon;
	}

	public String getCveConcepto() {
        return cveConcepto;
    }

    public void setCveConcepto(String cveConcepto) {
        this.cveConcepto = cveConcepto;
    }

    public Date getFechaValor() {
        return fechaValor;
    }

    public void setFechaValor(Date fechaValor) {
        this.fechaValor = fechaValor;
    }

    public BigDecimal getMontoMo() {
        return montoMo;
    }

    public void setMontoMo(BigDecimal montoMo) {
        this.montoMo = montoMo;
    }

    public String getTipoTasa() {
        return tipoTasa;
    }

    public void setTipoTasa(String tipoTasa) {
        this.tipoTasa = tipoTasa;
    }

    public BigDecimal getTasa() {
        return tasa;
    }

    public void setTasa(BigDecimal tasa) {
        this.tasa = tasa;
    }

    public Integer getDias() {
        return dias;
    }

    public void setDias(Integer dias) {
        this.dias = dias;
    }

    public BigDecimal getCalculoMo() {
        return calculoMo;
    }

    public void setCalculoMo(BigDecimal calculoMo) {
        this.calculoMo = calculoMo;
    }

    public String getTipoLiq() {
        return tipoLiq;
    }

    public void setTipoLiq(String tipoLiq) {
        this.tipoLiq = tipoLiq;
    }

    public BigDecimal getCentavos() {
        return centavos;
    }

    public void setCentavos(BigDecimal centavos) {
        this.centavos = centavos;
    }

    public Date getFechaVenc() {
        return fechaVenc;
    }

    public void setFechaVenc(Date fechaVenc) {
        this.fechaVenc = fechaVenc;
    }

    public Integer getAnio() {
        return anio;
    }

    public void setAnio(Integer anio) {
        this.anio = anio;
    }

    public Integer getImprimir() {
        return imprimir;
    }

    public void setImprimir(Integer imprimir) {
        this.imprimir = imprimir;
    }

	public Boolean getVerFecha() {
		return verFecha;
	}

	public void setVerFecha(Boolean verFecha) {
		this.verFecha = verFecha;
	}

    
}