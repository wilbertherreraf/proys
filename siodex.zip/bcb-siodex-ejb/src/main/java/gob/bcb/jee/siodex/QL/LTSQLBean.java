package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.LoanTrancheSummary;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJBException;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

@Stateless
@LocalBean
public class LTSQLBean implements LTSQLBeanLocal {

	static final Logger logger = Logger.getLogger(LTSQLBean.class);

	@PersistenceContext(unitName = "dms1")
	// @PersistenceContext(unitName = "siodex")
	EntityManager em;

	/**
	 * Default constructor.
	 */
	public LTSQLBean() {
		// TODO Auto-generated constructor stub
	}

	public LoanTrancheSummary listaLoanTrancheSummary(String loanId, int trancheNo) {

		List<LoanTrancheSummary> lista = new ArrayList<LoanTrancheSummary>();

		StringBuilder query = new StringBuilder();

		query.append("select l from LoanTrancheSummary l ");
		query.append("where l.loanTrancheSummaryPK.loanId = ? ");
		query.append("and l.loanTrancheSummaryPK.trancheNo = ?");

		Query consulta = em.createQuery(query.toString());

		consulta.setParameter(1, loanId);
		consulta.setParameter(2, trancheNo);

		lista = consulta.getResultList();

		if (lista.size() > 0){
			return lista.get(0);
		}
		return null;

	}
	
	public List<LoanTrancheSummary> listaLoanTrancheSummary0(String loanId, int trancheNo) {

		List<LoanTrancheSummary> lista = new ArrayList<LoanTrancheSummary>();

		StringBuilder query = new StringBuilder();

		query.append("select l from LoanTrancheSummary l ");
		query.append("where l.loanTrancheSummaryPK.loanId = ? ");
		query.append("and l.loanTrancheSummaryPK.trancheNo = ?");

		Query consulta = em.createQuery(query.toString());

		consulta.setParameter(1, loanId);
		consulta.setParameter(2, trancheNo);

		lista = consulta.getResultList();

		return lista;

	}

}
