/**
 * dataException.java
 *
 * Creado el 9 de junio de 2003, 09:14 AM
 */
package gob.bcb.jee.siodex.exception;

import javax.ejb.ApplicationException;

/**
 * Crea una nueva instancia de <code>dataException</code> sin el detalle de mensaje.
 */
@ApplicationException(rollback = true)
public class DataException extends java.lang.Exception {

	/**
	 * Crea una nueva instancia de <code>dataException</code> sin el detalle de mensaje.
	 */
	public DataException() {
	}
	/**
	 * Construye una isntancia de <code>dataException</code> especificando el detalle del mensaje.
	 * @param msg detalle del mensaje.
	 */
	public DataException(String msg) {
		super(msg);
	}
}
