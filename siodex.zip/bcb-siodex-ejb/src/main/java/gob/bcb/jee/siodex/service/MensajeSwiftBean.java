package gob.bcb.jee.siodex.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import gob.bcb.jee.siodex.QL.BancoQLBeanLocal;
import gob.bcb.jee.siodex.QL.CoinQLBeanLocal;
import gob.bcb.jee.siodex.QL.ConsultasSdxQLBeanLocal;
import gob.bcb.jee.siodex.QL.CuentaQLBeanLocal;
import gob.bcb.jee.siodex.QL.MensajeDatosQLBeanLocal;
import gob.bcb.jee.siodex.QL.MonedaQLBeanLocal;
import gob.bcb.jee.siodex.QL.ReferenciaQLBeanLocal;
import gob.bcb.jee.siodex.entities.Cuenta;
import gob.bcb.jee.siodex.entities.CuentaAcreedor;
import gob.bcb.jee.siodex.entities.Datos;
import gob.bcb.jee.siodex.entities.Mensaje;
import gob.bcb.jee.siodex.entities.MensajeDatos;
import gob.bcb.jee.siodex.entities.MensajeDatosPK;
import gob.bcb.jee.siodex.entities.Moneda;
import gob.bcb.jee.siodex.entities.Vencimiento;
import gob.bcb.jee.siodex.exception.DataException;
import gob.bcb.jee.siodex.util.MensSwiftUtiles;
import gob.bcb.jee.siodex.util.UtilsDate;

//import org.joda.time.DateTime;

/**
 * Clase que contiene los metodos para crear los campos de un mensaje swift.
 * 
 * @author C. Cecilia Uriona
 * 
 */
@Stateless
public class MensajeSwiftBean implements MensajeSwiftBeanLocal {
	static final Logger logger = Logger.getLogger(MensajeSwiftBean.class);
	static final String EOL = "\r\n";
	@PersistenceContext(unitName = "siodex")
	EntityManager em;

	@Inject
	private MensajeDatosQLBeanLocal mensajeDatosQLBeanLocal;
	@Inject
	private CuentaQLBeanLocal cuentaQLBeanLocal;
	@Inject
	private BancoQLBeanLocal bancoQLBeanLocal;
	@Inject
	private ConsultasSdxQLBeanLocal consultasSdxQLBeanLocal;
	@Inject
	private CoinQLBeanLocal coinQLBeanLocal;
	@Inject
	private MonedaQLBeanLocal monedaQLBeanLocal;
	@Inject
	private ReferenciaQLBeanLocal referenciaQLBeanLocal;
	private String acreedor = "";
	private String refAcre = "";
	private String codMov;
	private BigDecimal tipoCambio;

	public List<MensajeDatos> crearSwift(Vencimiento vencimiento, Mensaje men, String ref, Integer nro, String ptm, Integer tramo, boolean conDocMov)
			throws DataException {
		List<MensajeDatos> mensajeDatoslist = new ArrayList<MensajeDatos>();

		logger.info("creando mensaje: " + men.getMenSwift() + " codliq: " + vencimiento.getLiqCodigo());

		refAcre = vencimiento.getRefAcre();// llts.getCreditorRef();
		acreedor = vencimiento.getAcreedor();// llts.getCreditorName();
		if(!conDocMov){
			codMov = "";
		}
		tipoCambio = vencimiento.getTipoCambioCont();
		String valor = "";

		List<Datos> datosList = getPretamoEsquema(vencimiento.getPtmCodigo(), vencimiento.getTraCodigo());

		if (datosList == null || datosList.size() == 0) {
			logger.error("Datos para mensaje swift inexistentes para prest: " + vencimiento.getPtmCodigo() + " tramo: " + vencimiento.getTraCodigo());
			throw new DataException("Datos esquema mensaje swift inexistentes prest: " + vencimiento.getPtmCodigo() + " tramo: "
					+ vencimiento.getTraCodigo());
		}

		for (Datos datos : datosList) {
			valor = getCampo(datos.getCamCodigo(), datos.getCamDefinicion(), men, ref, nro, vencimiento.getPtmCodigo(), vencimiento.getTraCodigo());
			if (!StringUtils.isBlank(valor)) {
				MensajeDatosPK mensajeDatosPK = new MensajeDatosPK();
				mensajeDatosPK.setCamBloque((short) datos.getCamBloque());
				mensajeDatosPK.setCamCodigo(datos.getCamCodigo());
				mensajeDatosPK.setMenCodigo(men.getMenCodigo());

				MensajeDatos mensajeDatos = new MensajeDatos();
				mensajeDatos.setMensajeDatosPK(mensajeDatosPK);
				mensajeDatos.setMdtValor(valor);

				// logger.info("Datos Mensaje : " + mensajeDatos.toString());
				mensajeDatoslist.add(mensajeDatos);
			}
		}

		if (mensajeDatoslist.size() == 0) {
			logger.error("Datos para mensaje swift sin registros: " + vencimiento.getPtmCodigo() + " tramo: " + vencimiento.getTraCodigo()
					+ " verifique parametrizacion ");
			throw new DataException("Datos para mensaje swift sin registros: " + vencimiento.getPtmCodigo() + " tramo: " + vencimiento.getTraCodigo()
					+ " verifique parametrizacion ");
		}
		logger.info("Datos Mensaje : " + ArrayUtils.toString(mensajeDatoslist));
		logger.info("Mensaje SWIFT para prest: " + vencimiento.getPtmCodigo() + " tramo: " + vencimiento.getTraCodigo() + " codliq: "
				+ vencimiento.getLiqCodigo());

		return mensajeDatoslist;
	}

	@Override
	public List<MensajeDatos> crearSwift(Vencimiento vencimiento, Mensaje men, String ref, Integer nro, String ptm, Integer tramo, String codMov) throws DataException {
		this.codMov = codMov;
		boolean conDocMov = true;
		return crearSwift(vencimiento,men,ref,nro,ptm,tramo,conDocMov);
	}


	public List<Datos> getPretamoEsquema(String ptm, Integer tramo) throws DataException {
		List<Datos> datosList = new ArrayList<Datos>();

		StringBuilder query = new StringBuilder();

		query.append(" select e.mes_codigo, e.cam_codigo ,e.cam_bloque, c.cam_definicion, c.cam_nombre ");
		query.append("from prestamo_esquema p, mesq_campos e, campos c ");
		query.append("where p.mes_codigo = e.mes_codigo ");
		query.append("and e.cam_codigo = c.cam_codigo ");
		query.append("and e.cam_bloque = c.cam_bloque ");
		query.append("and e.cve_vigente = 1 ");
		query.append("and p.cve_vigente = 1 ");
		query.append("and p.ptm_codigo = '" + ptm + "' ");
		query.append("and p.tra_codigo = " + tramo + " ");

		logger.info("consulta esquema " + query.toString());
		Query queryNat = em.createNativeQuery(query.toString());

		List lista = queryNat.getResultList();
		Iterator it = lista.iterator();

		try {
			while (it.hasNext()) {
				Object[] da = (Object[]) it.next();
				Datos datos = new Datos();
				datos.setMesCodigo((String) da[0]);
				datos.setCamCodigo((String) da[1]);
				datos.setCamBloque((Short) da[2]);
				datos.setCamDefinicion((String) da[3]);
				datos.setCamNombre((String) da[4]);

				datosList.add(datos);
			}
		} catch (Exception e) {
			throw new DataException("Error al recuperar datos de esquema swift " + ptm + "[" + tramo + "] " + e.getMessage());
		}

		return datosList;
	}

	private String getEsquema(String ptm, Integer tramo) throws DataException {
		String esq = "";

		StringBuilder query = new StringBuilder();

		query.append(" select p.mes_codigo ");
		query.append("from prestamo_esquema p ");
		query.append("where p.cve_vigente = 1 ");
		query.append("and p.ptm_codigo = '" + ptm + "' ");
		query.append("and p.tra_codigo = " + tramo + " ");

		logger.info("************************consulta esquema " + query.toString());
		
		Query queryNat = em.createNativeQuery(query.toString());
		try{
			esq = (String) queryNat.getSingleResult();
		}catch (NullPointerException e) {			
			throw new DataException("Error al recuperar codidog MT " + ptm + "[" + tramo + "] " + e.getMessage() + ", verifique en la tabla prestamo_esquema que la misma exista");			
		}catch (Exception e) {
			throw new DataException("Error al recuperar codidog MT " + ptm + "[" + tramo + "] " + e.getMessage() + ", verifique en la tabla prestamo_esquema que la misma exista");			
		}
		
		String codMT = esq.trim().substring(0, 3);
		
		return codMT;
	}
	
	public void actualizaCampo(Mensaje men, String campo, String ref, String ptm, Integer tramo) throws DataException {
		logger.info("Actualizando campo " + campo + " para " + men.getMenCodigo());
		String valor = getCampo(campo, "", men, ref, 0, ptm, tramo);

		MensajeDatos mensajeDatos = mensajeDatosQLBeanLocal.getDato(men.getMenCodigo(), campo);
		mensajeDatos.setMdtValor(valor);
		mensajeDatosQLBeanLocal.edit(mensajeDatos);
		logger.info("Actualizado campo " + campo + " para " + men.getMenCodigo() + " valores " + mensajeDatos.toString());
	}

	private String getCampo(String campo, String def, Mensaje men, String ref, Integer nro00, String ptm, Integer tramo) throws DataException {
		String valor = "";

		if (campo.equals("0A") || campo.equals("0B") || campo.equals("0C") || campo.equals("0D") || campo.equals("0E") || campo.equals("0F")
				|| campo.equals("0I")) {

			valor = consultasSdxQLBeanLocal.getParametro(def);
		} else if (campo.equals("0G")) {
			//valor = "103";	
			valor = this.getEsquema(ptm, tramo);
		} else if (campo.equals("108")) {
			valor = "AUT";
		} else if (campo.equals("0H")) {
			valor = get0H(ptm, tramo, men.getMonSwift());
		} else if (campo.equals(":20")) {
			valor = get20(men.getUsrCodigo(), men.getMenSwift());
		} else if (campo.equals(":21")) {
			valor = "NONREF";
		} else if (campo.equals(":23B")) {
			valor = "CRED";
		} else if(campo.equals(":25")){
			valor = get25(codMov);
		} else if (campo.equals(":32A")) {
			valor = get32A(men.getFechaValor(), men.getMonSwift(), men.getMontoMo());
		} else if (campo.equals(":50A")) {
			valor = "BCEBBOLP";
		} else if (campo.equals(":50K")) {
			valor = get50K(ptm, tramo);
		} if(campo.equals(":52A")){
			valor = get52A(ptm, tramo, men.getMonSwift());
		} else if (campo.equals(":52D")) {
			valor = get52D(ptm, tramo);
		} else if (campo.equals(":53B")) {
			valor = get53B(ptm, tramo, men.getMonSwift());
		} else if (campo.equals(":56A")) {
			if (refAcre.contains("SF")) {
				acreedor = "BID-SF";
			}
			valor = get56A(acreedor, men.getMonSwift());
		} else if (campo.equals(":57A")) {
			if (refAcre.contains("SF")) {
				acreedor = "BID-SF";
			}
			valor = get57A(acreedor, men.getMonSwift());
		} else if (campo.equals(":57D")) {
			if (refAcre.contains("SF")) {
				acreedor = "BID-SF";
			}
			valor = get57D(acreedor, men.getMonSwift());
		} else if (campo.equals(":58D")) {
			if (refAcre.contains("SF")) {
				acreedor = "BID-SF";
			}
			valor = get58D(acreedor, men.getMonSwift());
		} else if (campo.equals(":58A")) {
			if (refAcre.contains("SF")) {
				acreedor = "BID-SF";
			}
			valor = get58A(acreedor, men.getMonSwift());
		} else if (campo.equals(":59")) {
			if (refAcre.contains("SF")) {
				acreedor = "BID-SF";
			}
			valor = get59(acreedor, men.getMonSwift());
		} else if (campo.equals(":59A")) {
			if (refAcre.contains("SF")) {
				acreedor = "BID-SF";
			}
			valor = get59A(acreedor, men.getMonSwift());
		} else if (campo.equals(":71A")) {
			valor = "OUR";
		} else if (campo.equals(":72")) {
			if(StringUtils.isEmpty(codMov)){
				valor = get72(acreedor, men.getMonSwift(), men.getFechaVencimiento(), men.getPtmCodigo(), men.getTraCodigo(), ref);
			} else{
				valor = get72OpInt(refAcre,men.getCapitalMo().add(men.getInteresMo()).toString());
			}
		}

		return valor;
	}

	private String get0H(String ptm, Integer tra, String codMonedaSwift) throws DataException {
		String valor = "";
		String bic = "";

		int cont = 0;
		Moneda monedaC = null;

		monedaC = monedaQLBeanLocal.getMonedaCoin(codMonedaSwift);

		// PARCHE WHF 20150901: para pagos en USD se cambia de banquero solo
		// para pagos,
		// provisionalmente se excluye la moneda USD para cobros y se selecciona
		// la cuenta parametrizada en claves

		if (monedaC.getMonCoin().trim().equals("34")) {
			String codCuenta = consultasSdxQLBeanLocal.descripcionClave("cve_ctamoneda", monedaC.getMonCoin().trim());
			if (StringUtils.isBlank(codCuenta)) {
				logger.error("Cuenta no parametrizada en claves cve_ctamoneda moneda: " + monedaC.getMonCoin());
				throw new DataException("Cuenta no parametrizada en claves cve_ctamoneda moneda: " + monedaC.getMonCoin());
			}
 
			Cuenta cuenta2 = cuentaQLBeanLocal.getCuenta(codCuenta);
			if (!StringUtils.isBlank(cuenta2.getBcoBic())) {
				if (!StringUtils.isBlank(cuenta2.getCveTipoCta()) && cuenta2.getCveTipoCta().trim().equals("0010")) {
					// la cuenta debe ser del exterior
					logger.info("XXX: MONEDAAAAAAAAA " + cuenta2.getCodMoneda() + "  " + monedaC.getMonCoin().trim());
					if (!StringUtils.isBlank(cuenta2.getCodMoneda())) {
						if (cuenta2.getCodMoneda().trim().equals(monedaC.getMonCoin().trim())) {
							bic = cuenta2.getBcoBic();

							cont++;
						}
					}

				}
			}
		} else if(monedaC.getMonCoin().trim().equals("69")){
			String codBanco = consultasSdxQLBeanLocal.descripcionClave("cve_bcomoneda", monedaC.getMonSigade().trim());
			if(!StringUtils.isEmpty(codBanco)){
				Object[] banco = bancoQLBeanLocal.getBanco(codBanco);
				if(banco.length > 0){
					bic = banco[1].toString();
				}

			}

		} else {
			List<Cuenta> cuentaLista = cuentaQLBeanLocal.getCuentas(ptm, tra, null, null);
			for (Cuenta cuenta2 : cuentaLista) {
				if (!StringUtils.isBlank(cuenta2.getBcoBic())) {
					if (!StringUtils.isBlank(cuenta2.getCveTipoCta()) && cuenta2.getCveTipoCta().trim().equals("0010")) {
						// la cuenta debe ser del exterior
						logger.info("XXX: MONEDAAAAAAAAA " + cuenta2.getCodMoneda() + "  " + monedaC.getMonCoin().trim());
						if (!StringUtils.isBlank(cuenta2.getCodMoneda())) {
							if (cuenta2.getCodMoneda().trim().equals(monedaC.getMonCoin().trim())) {
								bic = cuenta2.getBcoBic();

								cont++;
							}
						}

					}
				}
			}
		}

		if (StringUtils.isBlank(bic)) {
			logger.error("Banco bic Swift inexistente para " + ptm + "[" + tra + "] moneda " + codMonedaSwift);
			throw new RuntimeException("Banco bic Swift inexistente para " + ptm + "[" + tra + "] moneda " + codMonedaSwift);
		}
		if (cont > 1) {
			logger.error("Cuenta Externa Swift para " + ptm + "[" + tra + "] moneda " + codMonedaSwift + " con mas de una cuenta parametrizada");
			throw new RuntimeException("Cuenta Externa Swift para " + ptm + "[" + tra + "] moneda " + codMonedaSwift
					+ " con mas de una cuenta parametrizada");
		}

		if (bic.length() == 11)
			valor = bic.substring(0, 8) + "X" + bic.substring(8);
		else
			valor = bic;

		return valor;
	}

	private String get20(String usuario, Integer nroSwift) {
		String valor = "";
		Date fecha = new Date();
		String ini = "";

		String query = " select usr_swift" + " from usuario " + " where usr_coin = '" + usuario + "'";

		String da = this.QueryNativoSimple(query);
		if (da != null) {
			ini = da;
		} else {

			logger.error("Error iniciales de usuario " + usuario + " inexistente, registre en tabla usuario");
			throw new RuntimeException("Error iniciales de usuario " + usuario + " inexistente, registre en tabla usuario");
		}

		String corr = String.format("%04d", nroSwift);
		String fechaLit = UtilsDate.stringFromDate(fecha, "ddMMyy");
		valor = corr + "/" + fechaLit + "/" + ini;

		logger.info("valor campo 20 " + valor);
		return valor;
	}

	private String get25(String cuenta){
		String valor = "";
		try {
			Object[] cuentaDatos = coinQLBeanLocal.getCuentaDatos(cuenta);
			for (int i = 0; i < cuentaDatos.length; i++) {
				if(i == 0){
					valor = cuentaDatos[i].toString().trim();
				} else{
					valor+= "." + cuentaDatos[i].toString().trim();
				}
			}
		} catch (DataException e) {
			logger.info(e.getMessage());
		}
		return valor;
	}


	private String get32A(Date fecha, String mon, BigDecimal monto) {
		String valor = "";

		if(!StringUtils.isEmpty(codMov)){
			try {
				Moneda monedaCoin = monedaQLBeanLocal.getMonedaCoin(mon);
				mon = monedaCoin.getMonSwift();
			} catch (DataException e) {
				e.printStackTrace();
			}
		}
		BigDecimal monto1 = monto.divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);

		String montoLiteral = String.format("%.2f", monto1);

		String mm = montoLiteral.replace('.', ',');

		int pos = 0;
		pos = mm.indexOf(',');

		if (pos > -1) {
			mm = mm.substring(0, pos + 3);
			if (mon.equals("JPY")) {
				mm = mm.substring(0, pos + 1);
			}
		}

		String fechaLit = UtilsDate.stringFromDate(fecha, "yyMMdd");
		valor = fechaLit + mon + mm;

		return valor;
	}

	private String get50K(String ptm, Integer tra) throws DataException {
		String valor = "";
		String cta = "";
		String persona = "";
		String direccion = "";
		String plaza = "";
		Cuenta cuenta = cuentaQLBeanLocal.getCuenta(ptm, tra, "DEUD", null);

		cta = cuenta.getCtaSwift();
		persona = cuenta.getCtaFactura();
		direccion = cuenta.getCtaDireccion();
		plaza = cuenta.getCtaPlaza();

		valor = "/" + cta + EOL + cortarTexto(persona) + EOL + direccion + EOL + plaza;
		return valor;
	}


	private String get52A(String ptm, Integer tra, String codMonedaSwift) throws DataException {
		String valor = "";
		String bic = "";

		int cont = 0;
		Moneda monedaC = null;

		monedaC = monedaQLBeanLocal.getMonedaCoin(codMonedaSwift);


		if(monedaC.getMonCoin().trim().equals("69")){
			String codBanco = consultasSdxQLBeanLocal.descripcionClave("cve_bcomoneda", monedaC.getMonSigade().trim());
			if(!StringUtils.isEmpty(codBanco)){
				Object[] banco = bancoQLBeanLocal.getBanco(codBanco);
				if(banco.length > 0){
					bic = banco[1].toString();
				}

			}

		}

		if (StringUtils.isBlank(bic)) {
			logger.error("Banco bic Swift inexistente para " + ptm + "[" + tra + "] moneda " + codMonedaSwift);
			throw new RuntimeException("Banco bic Swift inexistente para " + ptm + "[" + tra + "] moneda " + codMonedaSwift);
		}
		if (cont > 1) {
			logger.error("Cuenta Externa Swift para " + ptm + "[" + tra + "] moneda " + codMonedaSwift + " con mas de una cuenta parametrizada");
			throw new RuntimeException("Cuenta Externa Swift para " + ptm + "[" + tra + "] moneda " + codMonedaSwift
					+ " con mas de una cuenta parametrizada");
		}


		valor = bic;


		return valor;
	}

	private String get52D(String ptm, Integer tra) throws DataException {
		String nombre = "";
		String plaza = "";
		String valor = "";
		Cuenta cuenta = cuentaQLBeanLocal.getCuenta(ptm, tra, "DEUD", null);

		if (cuenta != null) {
			// logger.info("resultado" + da.toString());
			nombre = cuenta.getCtaFactura();
			plaza = cuenta.getCtaPlaza();
		}

		valor = cortarTexto(nombre) + EOL + plaza;
		return valor;
	}

	private String get53B(String ptm, Integer tra, String codMonedaSwift) throws DataException {
		String valor = "";
		String cuenta = "";

		int cont = 0;
		Moneda monedaC = monedaQLBeanLocal.getMonedaCoin(codMonedaSwift);
		// PARCHE WHF 20150901: para pagos en USD se cambia de banquero solo
		// para pagos,
		// provisionalmente se excluye la moneda USD para pagos y se selecciona
		// la cuenta parametrizada en claves

		if (monedaC.getMonCoin().trim().equals("34")) {
			String codCuenta = consultasSdxQLBeanLocal.descripcionClave("cve_ctamoneda", monedaC.getMonCoin().trim());
			if (StringUtils.isBlank(codCuenta)) {
				logger.error("Cuenta no parametrizada en claves cve_ctamoneda moneda: " + monedaC.getMonCoin());
				throw new DataException("Cuenta no parametrizada en claves cve_ctamoneda moneda: " + monedaC.getMonCoin());
			}

			Cuenta cuenta2 = cuentaQLBeanLocal.getCuenta(codCuenta);
			if (!StringUtils.isBlank(cuenta2.getBcoBic())) {
				if (!StringUtils.isBlank(cuenta2.getCveTipoCta()) && cuenta2.getCveTipoCta().trim().equals("0010")) {
					// la cuenta debe ser del exterior
					logger.info("XXX: MONEDAAAAAAAAA " + cuenta2.getCodMoneda() + "  " + monedaC.getMonCoin().trim());
					if (!StringUtils.isBlank(cuenta2.getCodMoneda())) {
						if (cuenta2.getCodMoneda().trim().equals(monedaC.getMonCoin().trim())) {
							cuenta = cuenta2.getCtaSwift();

							cont++;
						}
					}

				}
			}
		} else {
			List<Cuenta> cuentaLista = cuentaQLBeanLocal.getCuentas(ptm, tra, null, null);
			for (Cuenta cuenta2 : cuentaLista) {
				if (!StringUtils.isBlank(cuenta2.getCtaSwift())) {
					if (!StringUtils.isBlank(cuenta2.getCveTipoCta()) && cuenta2.getCveTipoCta().trim().equals("0010")) {
						// la cuenta debe ser del exterior
						if (!StringUtils.isBlank(cuenta2.getCodMoneda())) {
							if (cuenta2.getCodMoneda().trim().equals(monedaC.getMonCoin().trim())) {
								cuenta = cuenta2.getCtaSwift();
								cont++;
							}
						}

					}
				}
			}
		}
		if (StringUtils.isBlank(cuenta)) {
			logger.error("Cuenta Externa Swift inexistente para " + ptm + "[" + tra + "] moneda " + codMonedaSwift);
			throw new RuntimeException("Cuenta Externa Swift inexistente para " + ptm + "[" + tra + "] moneda " + codMonedaSwift);
		}
		if (cont > 1) {
			logger.error("Cuenta Externa Swift para " + ptm + "[" + tra + "] moneda " + codMonedaSwift + " con mas de una cuenta parametrizada");
			throw new RuntimeException("Cuenta Externa Swift para " + ptm + "[" + tra + "] moneda " + codMonedaSwift
					+ " con mas de una cuenta parametrizada");
		}

		valor = "/" + cuenta;

		return valor;
	}

	private String get56A(String acre, String mon) throws DataException {
		String valor = "";
		CuentaAcreedor cuentaAcreedor = cuentaQLBeanLocal.getCuentaAcreedor(acre, mon);
		if (cuentaAcreedor != null) {
			valor = cuentaAcreedor.getBcoInterm();
		}

		return valor;
	}

	private String get57A(String acre, String mon) throws DataException {
		String valor = "";
		CuentaAcreedor cuentaAcreedor = cuentaQLBeanLocal.getCuentaAcreedor(acre, mon);
		if (cuentaAcreedor != null) {
			valor = cuentaAcreedor.getBcoBic();
		}

		return valor;
	}

	private String get57D(String acre, String mon) throws DataException {
		String valor = "";
		String cta = "";
		String benef = "";
		String plaza = "";
		CuentaAcreedor cuentaAcreedor = cuentaQLBeanLocal.getCuentaAcreedor(acre, mon);
		if (cuentaAcreedor != null) {
			cta = cuentaAcreedor.getBcoCuenta();
			benef = cuentaAcreedor.getBcoNombre();
			plaza = cuentaAcreedor.getBcoPlaza();
		}

		if (!StringUtils.isBlank(plaza)) {
			valor = "//" + cta + EOL + cortarTexto(benef) + EOL + plaza;
		} else {
			valor = "/" + cta + EOL + cortarTexto(benef);
		}

		return valor;
	}
	
	private String get58A(String acre, String mon) throws DataException {
		String valor = "";
		String cta = "";
		String bic = "";
		CuentaAcreedor cuentaAcreedor = cuentaQLBeanLocal.getCuentaAcreedor(acre, mon);
		if (cuentaAcreedor != null) {
			cta = cuentaAcreedor.getCctNumero();
			bic = cuentaAcreedor.getCctBic();
		}

		valor = "/" + cta + EOL + bic;

		return valor;
	}

	private String get58D(String acre, String mon) throws DataException {
		String valor = "";
		String cta = "";
		String benef = "";
		String plaza = "";
		CuentaAcreedor cuentaAcreedor = cuentaQLBeanLocal.getCuentaAcreedor(acre, mon);
		if (cuentaAcreedor != null) {
			cta = cuentaAcreedor.getCctNumero();
			benef = cuentaAcreedor.getCctNombre();
			plaza = cuentaAcreedor.getCctPlaza();
		}

		if (!StringUtils.isBlank(plaza)) {
			valor = "/" + cta + EOL + cortarTexto(benef) + EOL + plaza;
		} else {
			valor = "/" + cta + EOL + cortarTexto(benef);
		}

		return valor;
	}

	private String get59(String acre, String mon) throws DataException {
		String valor = "";
		String cta = "";
		String benef = "";
		String direccion = "";		
		String plaza = "";
		CuentaAcreedor cuentaAcreedor = cuentaQLBeanLocal.getCuentaAcreedor(acre, mon);
		if (cuentaAcreedor != null) {
			cta = StringUtils.trimToEmpty(cuentaAcreedor.getCctNumero());
			benef = StringUtils.trimToEmpty(cuentaAcreedor.getCctNombre());
			direccion = StringUtils.trimToEmpty(cuentaAcreedor.getCctDireccion());
			plaza = StringUtils.trimToEmpty(cuentaAcreedor.getCctPlaza());
		}

		if (StringUtils.isBlank(cta) || StringUtils.isBlank(benef) || StringUtils.isBlank(direccion)){
			throw new RuntimeException("Swift campo 59, cuenta, nombre de beneficiario o dirección invalida acreedor: " + acre + " moneda: "  + mon);			
		}
		// whf : 20170905 se agrega la direccion del beneficiario, solo se dispone de 3 lineas la 1 es para la cuenta
		valor = "/" + cta + EOL;
		String nameAndLocation = StringUtils.trimToEmpty(direccion) + ", ";
		nameAndLocation = nameAndLocation + StringUtils.trimToEmpty(plaza);

		nameAndLocation = StringUtils.trimToEmpty(nameAndLocation);
		
		nameAndLocation = StringUtils.trimToEmpty(nameAndLocation);
		
		List<String> lines0 = MensSwiftUtiles.splitInLines(benef, 3, " ", "", 0);
		List<String> lines1 = MensSwiftUtiles.splitInLines(nameAndLocation, 2, " ", "", 0);

		List<String> lines = new ArrayList<String>();
		lines.addAll(lines0);
		lines.addAll(lines1);

		// total de lineas restantes para nombre y direccion 
		final int totallineas = 3;
		for (int i = 1 ; i <= lines.size(); i++) {
			valor = valor.concat(lines.get(i - 1));
			if (i >= totallineas)
				break;

			if (i < lines.size())
				valor = valor.concat(EOL);
		}
		
		return valor;
	}

	private String get59A(String acre, String mon) throws DataException {
		String valor = "";
		String cta = "";
		String bic = "";

		CuentaAcreedor cuentaAcreedor = cuentaQLBeanLocal.getCuentaAcreedor(acre, mon);
		if (cuentaAcreedor != null) {
			cta = cuentaAcreedor.getCctNumero();
			bic = cuentaAcreedor.getCctBic();
		}

		valor = "/" + cta + EOL + bic;

		return valor;
	}

	private String get72(String acre, String mon, Date fechaV, String ptm, int tra, String ref) throws DataException {
		String valor = "";
		String glosa = "";
		String refDefinicion = "";

		CuentaAcreedor cuentaAcreedor = cuentaQLBeanLocal.getCuentaAcreedor(acre, mon);
		if (cuentaAcreedor != null) {
			refDefinicion = cuentaAcreedor.getRefDefinicion();

		}

		if (!StringUtils.isBlank(refDefinicion)) {

			String ln = EOL;
			String tagi = "";
			String tagf = "";
			int pos = 0;

			glosa = getValorDef(refDefinicion, fechaV, ptm, tra, ref).trim();
			if (glosa.length() > 35) {
				pos = glosa.indexOf(ln);
				if (pos > 0) {
					tagi = glosa.substring(0, pos);
					tagf = glosa.substring(pos + 2);
				} else {
					tagi = glosa;
					tagf = "";
				}
				if (tagi.length() > 35) {
					tagi = this.cortarTexto1(tagi);
				}
				glosa = tagi + ln + tagf;
			}
		} else {
			logger.error("Error al obtener referencia " + ptm + "[" + tra + "] " + acre);
			throw new RuntimeException("Error al obtener referencia " + ptm + "[" + tra + "] " + acre);
		}

		valor = glosa;

		return valor;
	}

	private String get72OpInt(String codAcre, String mon) throws DataException {
		String valor = "";
		// Obtenemos los valores para operaciones internas
		Object[] refDef = referenciaQLBeanLocal.getRefDefinicion("26");

		String[] split = refDef[1].toString().split("/");
		for (int i = 0; i < split.length; i++) {
			if(i == 0){
				// Valor LNID
				valor = "/" + split[i] + "/" + codAcre;
			}
			if (!"0642".equalsIgnoreCase(codMov)) {
				// Verificamos si es 0642
				if (i == 1) {
					// Valor OCMT
					valor += EOL + "/" + split[i] + "/USD" + mon.replace('.',',') + EOL;
				} else if(i == 2) {
					DecimalFormat f = new DecimalFormat("##.00");  // this will helps you to always keeps in two decimal places
					String tipoCam = f.format(tipoCambio);

					valor += "/" + split[i] + "/" + tipoCam.replace('.',',');
				}
			}

		}
		return valor;
	}


	private String getValorDef(String def, Date fecha, String ptm, int tra, String ref) {
		int pos = 0;
		int hasta = 0;
		String tag = "";
		String variable = "";
		String valor = "";
		String reemp = "";

		tag = def;
		pos = tag.indexOf('\'');
		hasta = tag.indexOf('\'', pos + 1);
		do {
			variable = tag.substring(pos + 1, hasta);
			if (variable.equals("FVCTO")) {
				valor = DateFormat.getDateInstance().format(fecha);
			} else {
				if (variable.equals("LF")) {
					valor = EOL;
				} else {
					if (variable.equals("REF")) {
						valor = ref;
					} else {
						if (variable.equals("REFA")) {
							valor = refAcre;
						}
					}
				}
			}

			reemp = "'" + variable + "'";
			logger.info("XXX: MMMMMMMM && " + tag + " && " + reemp + " && " + valor + " && " + variable);
			tag = tag.replace(reemp, valor);
			pos = tag.indexOf('\'');
			hasta = tag.indexOf('\'', pos + 1);
		} while (hasta > 0);

		return tag;
	}

	private String cortarTexto(String textoOri) {
		String concCortado = "";
		Boolean cortado = false;
		int i = 34;
		int j;
		String texto = "";
		String ln = EOL;

		if (textoOri != null && textoOri.trim().length() > 35) {
			texto = textoOri;
			do {
				if (textoOri.charAt(i) == ' ') {
					texto = textoOri.substring(0, i) + ln + textoOri.substring(i + 1);
					cortado = true;
				}
				i--;
			} while (!cortado);

			concCortado = texto;
			logger.info("Cortado: " + concCortado);
			j = texto.indexOf(ln);
			texto = concCortado.substring(j + ln.length());
			logger.info("texto: " + texto);
			if (texto.length() > 35) {
				cortado = false;
				i = 34;
				do {
					if (texto.charAt(i) == ' ' || texto.charAt(i) == '.' || texto.charAt(i) == ',') {
						texto = texto.substring(0, i) + ln + texto.substring(i + 1);
						cortado = true;
					}
					i--;
				} while (!cortado);
				concCortado = concCortado.substring(0, j + ln.length()) + texto;
				logger.info("Cortado: " + concCortado);
			}
		} else {
			concCortado = textoOri;
		}

		return concCortado;
	}

	private String cortarTexto1(String textoOri) {
		Boolean cortado = false;
		int i = 34;
		String texto = "";
		String ln = EOL;

		if (textoOri != null && textoOri.trim().length() > 35) {
			texto = textoOri;
			do {
				if (textoOri.charAt(i) == ' ' || textoOri.charAt(i) == ',') {
					texto = textoOri.substring(0, i) + ln + textoOri.substring(i + 1);
					logger.info("texto: " + texto);
					cortado = true;
				}
				i--;
			} while (!cortado);
		}

		return texto;
	}

	/**
	 * retorna el mensaje swift a partir del mensaje en base de datos
	 */
	public String crearSwiftTexto(String codigo) {

		String texto = "";

		for (int i = 1; i <= 4; i++) {
			texto = texto + bloqueInicio(i) + bloqueValor(codigo, (short) i) + bloqueFin(i);
		}

		return texto;
	}

	/**
	 * retorna el mensaje swift a de una lista de datos
	 */
	public String crearSwiftTexto(List<MensajeDatos> mensajeDatoslist) {
		List<MensajeDatos> mensajeDatoslist1 = new ArrayList<MensajeDatos>();
		List<MensajeDatos> mensajeDatoslist2 = new ArrayList<MensajeDatos>();
		List<MensajeDatos> mensajeDatoslist3 = new ArrayList<MensajeDatos>();
		List<MensajeDatos> mensajeDatoslist4 = new ArrayList<MensajeDatos>();
		String texto = "";
		for (MensajeDatos mensajeDatos : mensajeDatoslist) {
			short bloque = mensajeDatos.getMensajeDatosPK().getCamBloque();
			if (bloque == 1) {
				mensajeDatoslist1.add(mensajeDatos);
			} else if (bloque == 2) {
				mensajeDatoslist2.add(mensajeDatos);
			} else if (bloque == 3) {
				mensajeDatoslist3.add(mensajeDatos);
			} else if (bloque == 4) {
				mensajeDatoslist4.add(mensajeDatos);
			}
		}
		texto = texto + bloqueInicio(1) + bloqueValor(mensajeDatoslist1) + bloqueFin(1);
		texto = texto + bloqueInicio(2) + bloqueValor(mensajeDatoslist2) + bloqueFin(2);
		texto = texto + bloqueInicio(3) + bloqueValor(mensajeDatoslist3) + bloqueFin(3);
		texto = texto + bloqueInicio(4) + bloqueValor(mensajeDatoslist4) + bloqueFin(4);
		return texto;
	}

	private String bloqueInicio(int bloque) {

		String texto = "";

		texto = "{" + bloque + ":";
		if (bloque == 4) {
			texto = texto + EOL;
		}

		return texto;
	}

	private String bloqueValor(String codigo, short bloque) {

		String texto = "";

		List<MensajeDatos> mensajeDatoslist = mensajeDatosQLBeanLocal.getDatosByBloque(codigo, bloque);
		if (mensajeDatoslist.size() > 0) {
			texto = bloqueValor(mensajeDatoslist);
		} else {
			logger.error("Datos del mensaje " + codigo + " bloque " + bloque + " inexistente");
			throw new RuntimeException("Datos del mensaje " + codigo + " bloque " + bloque + " inexistente");
		}

		return texto;
	}

	private String bloqueValor(List<MensajeDatos> mensajeDatoslist) {

		String texto = "";
		String campo = "";
		String valor = "";

		for (MensajeDatos mensajeDatos2 : mensajeDatoslist) {
			campo = mensajeDatos2.getMensajeDatosPK().getCamCodigo();
			valor = mensajeDatos2.getMdtValor();

			if (campo.equals(":32A") || campo.equals(":33B")) {
				valor = valor.replace('.', ',');
			}
			texto = texto + campoInicio(campo) + valor + campoFin(campo);
		}

		return texto;
	}

	private String campoInicio(String campo) {

		String texto = "";

		char c = campo.charAt(0);
		switch (c) {
		case '0':
			texto = "";
			break;
		case ':':
			texto = campo + ":";
			break;
		default:
			texto = "{" + campo + ":";
			break;
		}

		return texto;
	}

	private String campoFin(String campo) {

		String texto = "";

		char c = campo.charAt(0);
		switch (c) {
		case '0':
			texto = "";
			break;
		case ':':
			texto = EOL;
			break;
		default:
			texto = "}";
		}

		return texto;
	}

	private String bloqueFin(int bloque) {

		String texto = "";

		if (bloque == 4) {
			texto = "-}";
		} else {
			texto = "}";
		}

		return texto;
	}

	private String QueryNativoSimple(String consulta) {
		try {

			String cc = null;

			StringBuilder query = new StringBuilder();
			query.append(consulta);

			logger.info("MENSAJE SWIFT query: " + query);

			cc = (String) em.createNativeQuery(query.toString()).getSingleResult();

			return cc;

		} catch (NoResultException e) {
			// TODO: handle exception
			return null;
		}

	}
}
