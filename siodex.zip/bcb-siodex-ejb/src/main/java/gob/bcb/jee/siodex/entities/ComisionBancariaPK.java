/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author CUriona
 */
@Embeddable
public class ComisionBancariaPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "liq_codigo", nullable = false)
    private String liqCodigo;
    @Basic(optional = false)
    @NotNull
    @Column(name = "cve_tipocomi", nullable = false)
    private String cveTipocomi;

    public ComisionBancariaPK() {
    }

    public ComisionBancariaPK(String liqCodigo, String cveTipocomi) {
        this.liqCodigo = liqCodigo;
        this.cveTipocomi = cveTipocomi;
    }

    public String getLiqCodigo() {
        return liqCodigo;
    }

    public void setLiqCodigo(String liqCodigo) {
        this.liqCodigo = liqCodigo;
    }

    public String getCveTipocomi() {
        return cveTipocomi;
    }

    public void setCveTipocomi(String cveTipocomi) {
        this.cveTipocomi = cveTipocomi;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (liqCodigo != null ? liqCodigo.hashCode() : 0);
        hash += (cveTipocomi != null ? cveTipocomi.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ComisionBancariaPK)) {
            return false;
        }
        ComisionBancariaPK other = (ComisionBancariaPK) object;
        if ((this.liqCodigo == null && other.liqCodigo != null) || (this.liqCodigo != null && !this.liqCodigo.equals(other.liqCodigo))) {
            return false;
        }
        if ((this.cveTipocomi == null && other.cveTipocomi != null) || (this.cveTipocomi != null && !this.cveTipocomi.equals(other.cveTipocomi))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gob.bcb.siodex.entities.ComisionBancariaPK[ liqCodigo=" + liqCodigo + ", cveEstado=" + cveTipocomi + " ]";
    }
    
}
