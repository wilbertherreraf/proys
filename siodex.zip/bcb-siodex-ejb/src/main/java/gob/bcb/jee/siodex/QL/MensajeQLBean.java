package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.Loader;
import gob.bcb.jee.siodex.entities.Mensaje;
import gob.bcb.jee.siodex.exception.DataException;
import gob.bcb.jee.siodex.service.MensajeSwiftBeanLocal;
import gob.bcb.jee.siodex.util.UtilsDate;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

@Stateless
@LocalBean
public class MensajeQLBean extends DaoGeneric<Mensaje> implements MensajeQLBeanLocal {

	static final Logger logger = Logger.getLogger(MensajeQLBean.class);

	@PersistenceContext(unitName = "siodex")
	EntityManager entityManager;

	@Inject
	private LoaderQLBeanLocal loaderQLBeanLocal;
	@Inject
	private MensajeSwiftBeanLocal mensajeSwiftBeanLocal;

	/**
	 * Default constructor.
	 */
	public MensajeQLBean() {
		// TODO Auto-generated constructor stub
		super(Mensaje.class);
	}

	@SuppressWarnings("unchecked")
	public List<Mensaje> listaMensaje() {

		List<Mensaje> lista = new ArrayList<Mensaje>();

		StringBuilder query = new StringBuilder();

		query.append("select m from Mensaje m where m.cveEstadoS = 'E' order by m.fechaValor");

		Query consulta = entityManager.createQuery(query.toString());

		lista = consulta.getResultList();

		return lista;

	}

	@SuppressWarnings("unchecked")
	public List<Mensaje> listaMensajeOtros(String estado) {

		List<Mensaje> lista = new ArrayList<Mensaje>();

		StringBuilder query = new StringBuilder();

		query.append("select m from Mensaje m where m.cveEstadoS = :cveEstadoS order by m.fechaValor");

		Query consulta = entityManager.createQuery(query.toString());

		consulta.setParameter("cveEstadoS", estado);

		lista = consulta.getResultList();

		return lista;

	}

	public Mensaje getMensaje(String menCodigo) {

		Mensaje mensaje = null;

		StringBuilder query = new StringBuilder();

		query.append("select m from Mensaje m where m.menCodigo = :menCodigo ");

		Query consulta = entityManager.createQuery(query.toString());
		consulta.setParameter("menCodigo", menCodigo);

		List lista = consulta.getResultList();
		if (lista.size() > 0) {
			return (Mensaje) lista.get(0);
		}

		return mensaje;

	}

	public String getCodigo() {

		String codigo = "";
		String cod = "";

		StringBuilder query = new StringBuilder();

		query.append("select max(m.menCodigo) from Mensaje m");

		Query consulta = entityManager.createQuery(query.toString());
		logger.info("Consulta : " + query.toString());

		cod = (String) consulta.getSingleResult();
		Integer cc = Integer.valueOf(cod) + 1;

		codigo = String.format("%06d", cc);

		logger.info("menCodigo: " + codigo);

		return codigo;

	}

	/**
	 * crea o actualiza el mensaje, crear el registro loader flagCreaLoader =
	 * 'E' se crea el registro mensaje
	 */
	public Mensaje registrarMensSwift(Mensaje mensaje, String flagCreaLoader) throws DataException {
		logger.info("Ingresando a Mensaje(registrarMensSwift): " + mensaje.toString());

		// verificamos que no se duplique mensajes
		List<Mensaje> mensajelist = mensajeByLiqcodigoMonSigade(mensaje.getLiqCodigo(), mensaje.getMonSwift());

		if (mensajelist.size() == 0) {
			// no existe el registro se crea
			String menCodigo = getCodigo();

			mensaje.setFechaHora(new Date());
			mensaje.setMenCodigo(menCodigo);
			
			if (flagCreaLoader != null && flagCreaLoader.equals("E")) {
				create(mensaje);
			}

			return mensaje;
		} else {
			// se actualiza
			Mensaje mensajeOld = mensajelist.get(0);
			if (mensajeOld.getMenCodigo().equals(mensaje.getMenCodigo())) {
				// existe el mensaje
				mensajeOld.setFechaHora(new Date());
				
				edit(mensaje);

				return mensaje;

			} else {
				logger.error("Control de duplicados: liquidacion " + mensaje.getLiqCodigo() + " de moneda " + mensaje.getMonSwift()
						+ " ya tiene registro en mensaje swift con codigo " + mensajeOld.getMenCodigo());
				throw new RuntimeException("Control de duplicados: liquidacion " + mensaje.getLiqCodigo() + " de moneda " + mensaje.getMonSwift()
						+ " ya tiene registro en mensaje swift con codigo " + mensajeOld.getMenCodigo());
			}
		}
	}

	public Mensaje creaLoaderActualizaMensaje(Mensaje mensaje) throws DataException {
		Integer codSwift = loaderQLBeanLocal.maxNroSwift();
		Integer idLoader = loaderQLBeanLocal.getCodigo();

		logger.info("numero SWIFT obtenito: " + codSwift);

		mensaje.setFechaHora(new Date());
		mensaje.setMenSwift(codSwift);

		Loader loader = new Loader(idLoader, 0, 0, codSwift, '1', "SIODEX", mensaje.getEstacion(), new Date(), mensaje.getUsrCodigo());
		logger.info("registro Swift en PORTIA a crear: " + loader.toString());
		loaderQLBeanLocal.create(loader);

		return mensaje;
	}

	public Mensaje guardarArchivoSwift(Mensaje mensaje, String usuario, String estacion) throws DataException {

		if (mensaje == null) {
			throw new RuntimeException("parametro mensaje swift nulo");
		}
		logger.info("guardarArchivoSwift " + mensaje.toString());

		if (StringUtils.isBlank(mensaje.getCveEstadoS()) || !mensaje.getCveEstadoS().equals("E")) {
			throw new RuntimeException("El mensaje swift " + mensaje.getMenCodigo() + " con estado incorrecto o ya fue procesado");
		}

		Integer codSwift = loaderQLBeanLocal.maxNroSwift();
		Integer idLoader = loaderQLBeanLocal.getCodigo();
		
		logger.info("numero SWIFT obtenito: " + codSwift);
		
		mensaje.setMenSwift(codSwift);

		mensajeSwiftBeanLocal.actualizaCampo(mensaje,":20", "", mensaje.getPtmCodigo(), mensaje.getTraCodigo());
		
		mensaje.setCveEstadoS("V");
		
		mensaje.setEstacion(estacion);		
		mensaje = registrarMensSwift(mensaje, "V");

		String menSwift = mensajeSwiftBeanLocal.crearSwiftTexto(mensaje.getMenCodigo());

		if (StringUtils.isBlank(menSwift)) {
			throw new RuntimeException("El mensaje swift " + mensaje.getMenCodigo() + " NO PUDO ser generado");
		}
	
		//posterior a obtener el texto del swift creamos en portia
		// asi reducimos los errores
		/**************** creamos el loader en portia****************/
		Loader loader = new Loader(idLoader, 0, 0, codSwift, '1', "SIODEX", mensaje.getEstacion(), new Date(), mensaje.getUsrCodigo());
		
		logger.info("registro Swift en PORTIA a crear: " + loader.toString());		
		loaderQLBeanLocal.create(loader);

		String nomArchivoSwift = "m"+ UtilsDate.stringFromDate(new Date(), "yyyy")  + String.format("%04d", mensaje.getMenSwift())  + ".dos";

		// Dirección en producción para la generacion de mensajes swift
		String fileName = "/opt/aplicaciones/siodex/" + nomArchivoSwift;
		//Generación de mensajes swift desarrollo
//		String fileName = "D:/configuracionesSiodex/certificados/swift/" + nomArchivoSwift;
		logger.info("====Mensaje Swift para : " + mensaje.toString());
		logger.info(menSwift);
		logger.info("====OOOOOOOOO==========");
		
		try {
			BufferedWriter men = new BufferedWriter(new FileWriter(fileName));

			men.write(menSwift);
			men.close();
			logger.info("==Archivo Backup creado: " + fileName);

			fileName = "/opt/aplicaciones/siodex/swiftwindows/" + nomArchivoSwift;
//			fileName = "D:/configuracionesSiodex/certificados/swift/" + nomArchivoSwift;
			BufferedWriter men1 = new BufferedWriter(new FileWriter(fileName));

			men1.write(menSwift);
			men1.close();
			logger.info("==Archivo Swift creado: " + fileName);
		} catch (Exception e) {
			logger.error("Error al grabar archivo[" + nomArchivoSwift + "] Mensaje Swift: " + mensaje.getMenCodigo() + " Error: " + e.getMessage(), e);
			throw new RuntimeException("Error al grabar archivo[" + nomArchivoSwift + "] Mensaje Swift: " + mensaje.getMenCodigo() + " Error: "
					+ e.getMessage());
		}


		logger.info("Mensaje swift creado y cambiado a estado Enviado " + mensaje.toString());
		
		return mensaje;
	}

	public List<Mensaje> mensajeByLiqcodigoMonSigade(String liqCodigo, String monSwift) {

		List<Mensaje> mensajelist = new ArrayList<Mensaje>();

		StringBuilder query = new StringBuilder();

		query.append("select m from Mensaje m where m.liqCodigo = :liqCodigo and m.cveEstadoS != 'Z' ");

		if (monSwift != null) {
			query.append("and m.monSwift = :monSwift ");
		}

		Query consulta = entityManager.createQuery(query.toString());

		logger.info("Consulta de mensajeByLiqcodigoMonSigade[" + liqCodigo + "," + monSwift + "] " + query.toString());

		consulta.setParameter("liqCodigo", liqCodigo);
		if (monSwift != null) {
			consulta.setParameter("monSwift", monSwift);
		}

		mensajelist = consulta.getResultList();

		if (monSwift != null && mensajelist.size() > 1) {
			logger.error("Error al recuperar mensaje SWIFT " + mensajelist.size() + " registros vigentes para una moneda [" + liqCodigo + ","
					+ monSwift + "] ");
			throw new RuntimeException("Error al recuperara mensaje SWIFT mas de un registro vigente [" + liqCodigo + "," + monSwift + "] ");
		}

		return mensajelist;

	}

	@Override
	public void setEntityManager(EntityManager entityManager) {
		// TODO Auto-generated method stub

	}

	@Override
	public EntityManager getEntityManager() {
		return entityManager;
	}
}
