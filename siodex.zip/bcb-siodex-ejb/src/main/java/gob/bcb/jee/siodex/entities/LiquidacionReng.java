/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author CUriona
 */
@Entity
@Table(name = "liquidacion_reng")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "LiquidacionReng.findAll", query = "SELECT l FROM LiquidacionReng l"),
    @NamedQuery(name = "LiquidacionReng.findByLiqCodigo", query = "SELECT l FROM LiquidacionReng l WHERE l.liquidacionRengPK.liqCodigo = :liqCodigo"),
    @NamedQuery(name = "LiquidacionReng.findByLiqDetalle", query = "SELECT l FROM LiquidacionReng l WHERE l.liquidacionRengPK.liqDetalle = :liqDetalle"),
    @NamedQuery(name = "LiquidacionReng.findByLiqRenglon", query = "SELECT l FROM LiquidacionReng l WHERE l.liquidacionRengPK.liqRenglon = :liqRenglon"),
    @NamedQuery(name = "LiquidacionReng.findByCveConcepto", query = "SELECT l FROM LiquidacionReng l WHERE l.cveConcepto = :cveConcepto"),
    @NamedQuery(name = "LiquidacionReng.findByFechaValor", query = "SELECT l FROM LiquidacionReng l WHERE l.fechaValor = :fechaValor"),
    @NamedQuery(name = "LiquidacionReng.findByMontoMo", query = "SELECT l FROM LiquidacionReng l WHERE l.montoMo = :montoMo"),
    @NamedQuery(name = "LiquidacionReng.findByTipoTasa", query = "SELECT l FROM LiquidacionReng l WHERE l.tipoTasa = :tipoTasa"),
    @NamedQuery(name = "LiquidacionReng.findByTasa", query = "SELECT l FROM LiquidacionReng l WHERE l.tasa = :tasa"),
    @NamedQuery(name = "LiquidacionReng.findByDias", query = "SELECT l FROM LiquidacionReng l WHERE l.dias = :dias"),
    @NamedQuery(name = "LiquidacionReng.findByCalculoMo", query = "SELECT l FROM LiquidacionReng l WHERE l.calculoMo = :calculoMo"),
    @NamedQuery(name = "LiquidacionReng.findByTipoLiq", query = "SELECT l FROM LiquidacionReng l WHERE l.tipoLiq = :tipoLiq"),
    @NamedQuery(name = "LiquidacionReng.findByCentavos", query = "SELECT l FROM LiquidacionReng l WHERE l.centavos = :centavos"),
    @NamedQuery(name = "LiquidacionReng.findByFechaVenc", query = "SELECT l FROM LiquidacionReng l WHERE l.fechaVenc = :fechaVenc"),
    @NamedQuery(name = "LiquidacionReng.findByAnio", query = "SELECT l FROM LiquidacionReng l WHERE l.anio = :anio"),
    @NamedQuery(name = "LiquidacionReng.findByImprimir", query = "SELECT l FROM LiquidacionReng l WHERE l.imprimir = :imprimir")})
public class LiquidacionReng implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected LiquidacionRengPK liquidacionRengPK;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 32)
    @Column(name = "cve_concepto", nullable = false, length = 32)
    private String cveConcepto;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fecha_valor", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date fechaValor;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Basic(optional = false)
    @NotNull
    @Column(name = "monto_mo", nullable = false, precision = 16, scale = 2)
    private BigDecimal montoMo;
    @Size(max = 32)
    @Column(name = "tipo_tasa", length = 32)
    private String tipoTasa;
    @Column(name = "tasa", precision = 8, scale = 5)
    private BigDecimal tasa;
    @Column(name = "dias")
    private Integer dias;
    @Column(name = "calculo_mo", precision = 16, scale = 2)
    private BigDecimal calculoMo;
    @Size(max = 1)
    @Column(name = "tipo_liq", length = 1)
    private String tipoLiq;
    @Column(name = "centavos", precision = 8, scale = 2)
    private BigDecimal centavos;
    @Column(name = "fecha_venc")
    @Temporal(TemporalType.DATE)
    private Date fechaVenc;
    @Column(name = "anio")
    private Integer anio;
    @Column(name = "imprimir")
    private Integer imprimir;
    @JoinColumns({
        @JoinColumn(name = "liq_codigo", referencedColumnName = "liq_codigo", nullable = false, insertable = false, updatable = false),
        @JoinColumn(name = "liq_detalle", referencedColumnName = "liq_detalle", nullable = false, insertable = false, updatable = false)})
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private LiquidacionDet liquidacionDet;

    public LiquidacionReng() {
    }

    public LiquidacionReng(LiquidacionRengPK liquidacionRengPK) {
        this.liquidacionRengPK = liquidacionRengPK;
    }

    public LiquidacionReng(LiquidacionRengPK liquidacionRengPK, String cveConcepto, Date fechaValor, BigDecimal montoMo) {
        this.liquidacionRengPK = liquidacionRengPK;
        this.cveConcepto = cveConcepto;
        this.fechaValor = fechaValor;
        this.montoMo = montoMo;
    }

    public LiquidacionReng(String liqCodigo, String liqDetalle, String liqRenglon) {
        this.liquidacionRengPK = new LiquidacionRengPK(liqCodigo, liqDetalle, liqRenglon);
    }

    public LiquidacionRengPK getLiquidacionRengPK() {
        return liquidacionRengPK;
    }

    public void setLiquidacionRengPK(LiquidacionRengPK liquidacionRengPK) {
        this.liquidacionRengPK = liquidacionRengPK;
    }

    public String getCveConcepto() {
        return cveConcepto;
    }

    public void setCveConcepto(String cveConcepto) {
        this.cveConcepto = cveConcepto;
    }

    public Date getFechaValor() {
        return fechaValor;
    }

    public void setFechaValor(Date fechaValor) {
        this.fechaValor = fechaValor;
    }

    public BigDecimal getMontoMo() {
        return montoMo;
    }

    public void setMontoMo(BigDecimal montoMo) {
        this.montoMo = montoMo;
    }

    public String getTipoTasa() {
        return tipoTasa;
    }

    public void setTipoTasa(String tipoTasa) {
        this.tipoTasa = tipoTasa;
    }

    public BigDecimal getTasa() {
        return tasa;
    }

    public void setTasa(BigDecimal tasa) {
        this.tasa = tasa;
    }

    public Integer getDias() {
        return dias;
    }

    public void setDias(Integer dias) {
        this.dias = dias;
    }

    public BigDecimal getCalculoMo() {
        return calculoMo;
    }

    public void setCalculoMo(BigDecimal calculoMo) {
        this.calculoMo = calculoMo;
    }

    public String getTipoLiq() {
        return tipoLiq;
    }

    public void setTipoLiq(String tipoLiq) {
        this.tipoLiq = tipoLiq;
    }

    public BigDecimal getCentavos() {
        return centavos;
    }

    public void setCentavos(BigDecimal centavos) {
        this.centavos = centavos;
    }

    public Date getFechaVenc() {
        return fechaVenc;
    }

    public void setFechaVenc(Date fechaVenc) {
        this.fechaVenc = fechaVenc;
    }

    public Integer getAnio() {
        return anio;
    }

    public void setAnio(Integer anio) {
        this.anio = anio;
    }

    public Integer getImprimir() {
        return imprimir;
    }

    public void setImprimir(Integer imprimir) {
        this.imprimir = imprimir;
    }

    public LiquidacionDet getLiquidacionDet() {
        return liquidacionDet;
    }

    public void setLiquidacionDet(LiquidacionDet liquidacionDet) {
        this.liquidacionDet = liquidacionDet;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (liquidacionRengPK != null ? liquidacionRengPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof LiquidacionReng)) {
            return false;
        }
        LiquidacionReng other = (LiquidacionReng) object;
        if ((this.liquidacionRengPK == null && other.liquidacionRengPK != null) || (this.liquidacionRengPK != null && !this.liquidacionRengPK.equals(other.liquidacionRengPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gob.bcb.siodex.entities.LiquidacionReng[ liquidacionRengPK=" + liquidacionRengPK + " ]";
    }
    
}