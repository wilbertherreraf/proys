package gob.bcb.jee.siodex.clientsigmaws;

import gob.bcb.jee.siodex.entities.Liquidacion;
import gob.bcb.jee.siodex.entities.Vencimiento;
import gob.bcb.jee.siodex.mefp.LiquidacionCuentas;

import java.util.ArrayList;
import java.util.List;

public class MensajeVenc {
	private String codLiq;
	private Liquidacion liquidacion;
	private Vencimiento vencimiento;	
	private String observacion;	
	private List<LiquidacionCuentas> liquidacionCuentasTgnList = new ArrayList<LiquidacionCuentas>();

	public String getCodLiq() {
		return codLiq;
	}

	public void setCodLiq(String codLiq) {
		this.codLiq = codLiq;
	}

	public Liquidacion getLiquidacion() {
		return liquidacion;
	}

	public void setLiquidacion(Liquidacion liquidacion) {
		this.liquidacion = liquidacion;
	}


	public List<LiquidacionCuentas> getLiquidacionCuentasTgnList() {
		return liquidacionCuentasTgnList;
	}

	public void setLiquidacionCuentasTgnList(List<LiquidacionCuentas> liquidacionCuentasTgnList) {
		this.liquidacionCuentasTgnList = liquidacionCuentasTgnList;
	}

	public String getObservacion() {
		return observacion;
	}

	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}

	public Vencimiento getVencimiento() {
		return vencimiento;
	}

	public void setVencimiento(Vencimiento vencimiento) {
		this.vencimiento = vencimiento;
	}

}
