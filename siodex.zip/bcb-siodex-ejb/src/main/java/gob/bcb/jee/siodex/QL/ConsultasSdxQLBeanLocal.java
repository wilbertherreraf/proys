package gob.bcb.jee.siodex.QL;

import java.math.BigDecimal;
import java.util.List;

import gob.bcb.jee.siodex.entities.ClaveValor;
import gob.bcb.jee.siodex.entities.Liquidacion;
import gob.bcb.jee.siodex.exception.DataException;

import javax.ejb.Local;

@Local
public interface ConsultasSdxQLBeanLocal {
	public String getParametro(String param) ;

	String tipoOperacionPrestamo(String prestamo, Integer tramo);

	String getCodigoLip(String proc, String cuenta) throws DataException;

	String descripcionClave(String clave, String valorClave);
	
	String getLiquidacionBID1020(String liqCodigo) throws DataException;

	List<Liquidacion> montosPorMonedas(String liqCodigo) throws DataException;
	
	List<Liquidacion> montosPorMonedasDiff(String liqCodigo) throws DataException;
	
	List<Liquidacion> montosDiff(String liqCodigo) throws DataException;

	BigDecimal montoPorMoneda(String liqCodigo, String monedaSIGADE) throws DataException;

	ClaveValor clavesValorByCVVNombre(String cve_codigo, String cvv_nombre);
}
