package gob.bcb.jee.siodex.QL;

import java.util.List;

import gob.bcb.jee.siodex.entities.ToperDatos;

import javax.ejb.Local;

@Local
public interface ToperDatosQLBeanLocal {

	/**
	 * 
	 * @return
	 */
	public List<ToperDatos> getDatos(String codigo);
	
}
