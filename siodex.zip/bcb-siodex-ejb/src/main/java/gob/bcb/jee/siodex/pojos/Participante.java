package gob.bcb.jee.siodex.pojos;
public class Participante {
	private String codPte;
	private String nombrePte;
	public String getCodPte() {
		return codPte;
	}
	public void setCodPte(String codPte) {
		this.codPte = codPte;
	}
	public String getNombrePte() {
		return nombrePte;
	}
	public void setNombrePte(String nombrePte) {
		this.nombrePte = nombrePte;
	}


}
