package gob.bcb.jee.siodex.service;

import gob.bcb.jee.siodex.QL.DAO;
import gob.bcb.jee.siodex.exception.DataException;

import javax.ejb.Local;

@Local
public interface GenerarOperacionLocal {

	public void calcular() throws DataException;

	public String generar()throws DataException;

}