package gob.bcb.jee.siodex.QL;

import java.util.List;

import gob.bcb.jee.siodex.entities.Liquidacion;
import gob.bcb.jee.siodex.entities.Mensaje;
import gob.bcb.jee.siodex.exception.DataException;

import javax.ejb.Local;

@Local
public interface MensajeQLBeanLocal  extends DAO<Mensaje> {

	/**
	 * 
	 * @return
	 */
	public List<Mensaje> listaMensaje();
	public List<Mensaje> listaMensajeOtros(String estado);
	public Mensaje getMensaje(String codigo);
	public String getCodigo();
	
	Mensaje registrarMensSwift(Mensaje mensaje, String flagCreaLoader) throws DataException;
	List<Mensaje> mensajeByLiqcodigoMonSigade(String liqCodigo, String monSwift);
	Mensaje guardarArchivoSwift(Mensaje mensaje, String usuario, String estacion) throws DataException;
	
}
