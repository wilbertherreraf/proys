/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author CUriona
 */
@Entity
@Table(name = "liquidacion_det")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "LiquidacionDet.findAll", query = "SELECT l FROM LiquidacionDet l"),
    @NamedQuery(name = "LiquidacionDet.findByLiqCodigo", query = "SELECT l FROM LiquidacionDet l WHERE l.liquidacionDetPK.liqCodigo = :liqCodigo"),
    @NamedQuery(name = "LiquidacionDet.findByLiqDetalle", query = "SELECT l FROM LiquidacionDet l WHERE l.liquidacionDetPK.liqDetalle = :liqDetalle"),
    @NamedQuery(name = "LiquidacionDet.findByPinPrestamo", query = "SELECT l FROM LiquidacionDet l WHERE l.pinPrestamo = :pinPrestamo"),
    @NamedQuery(name = "LiquidacionDet.findByPinTramo", query = "SELECT l FROM LiquidacionDet l WHERE l.pinTramo = :pinTramo"),
    @NamedQuery(name = "LiquidacionDet.findByMonSigade", query = "SELECT l FROM LiquidacionDet l WHERE l.monSigade = :monSigade"),
    @NamedQuery(name = "LiquidacionDet.findByTipoCambio", query = "SELECT l FROM LiquidacionDet l WHERE l.tipoCambio = :tipoCambio"),
    @NamedQuery(name = "LiquidacionDet.findByCapitalMo", query = "SELECT l FROM LiquidacionDet l WHERE l.capitalMo = :capitalMo"),
    @NamedQuery(name = "LiquidacionDet.findByInteresMo", query = "SELECT l FROM LiquidacionDet l WHERE l.interesMo = :interesMo"),
    @NamedQuery(name = "LiquidacionDet.findByComisionMo", query = "SELECT l FROM LiquidacionDet l WHERE l.comisionMo = :comisionMo"),
    @NamedQuery(name = "LiquidacionDet.findByGlosa", query = "SELECT l FROM LiquidacionDet l WHERE l.glosa = :glosa")})
public class LiquidacionDet implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected LiquidacionDetPK liquidacionDetPK;
    @Basic(optional = false)
    @NotNull
    @Column(name = "pin_prestamo", nullable = false)
    private String pinPrestamo;
    @Column(name = "pin_tramo")
    private Integer pinTramo;
    @Basic(optional = false)
    @NotNull
    @Column(name = "mon_sigade", nullable = false)
    private String monSigade;
    @Basic(optional = false)
    @NotNull
    @Column(name = "tipo_cambio", nullable = false, precision = 15, scale = 11)
    private BigDecimal tipoCambio;
    @Column(name = "tipo_cambiomo", nullable = false, precision = 15, scale = 11)
    private BigDecimal tipoCambiomo;    
    @Column(name = "capital_mo", precision = 16, scale = 2)
    private BigDecimal capitalMo;
    @Column(name = "interes_mo", precision = 16, scale = 2)
    private BigDecimal interesMo;
    @Column(name = "comision_mo", precision = 16, scale = 2)
    private BigDecimal comisionMo;
    @Column(name = "glosa")
    private String glosa;
    
//    @OneToMany(cascade = CascadeType.ALL, mappedBy = "liquidacionDet", fetch = FetchType.LAZY)
//    private List<LiquidacionReng> liquidacionRengList;
    /*@OneToMany(cascade = CascadeType.ALL, mappedBy = "liquidacionDet", fetch = FetchType.LAZY)
    private List<LiquidacionDatos> liquidacionDatosList;*/
//    @JoinColumn(name = "liq_codigo", referencedColumnName = "liq_codigo", nullable = false, insertable = false, updatable = false)
//    @ManyToOne(optional = false, fetch = FetchType.LAZY)
//    private Liquidacion liquidacion;

    public LiquidacionDet() {
    	
    }

    public LiquidacionDet(LiquidacionDetPK liquidacionDetPK) {
        this.liquidacionDetPK = liquidacionDetPK;
    }

    public LiquidacionDet(LiquidacionDetPK liquidacionDetPK, String pinPrestamo, Integer pinTramo, String monSigade, BigDecimal tipoCambio,
    		BigDecimal capitalMo, BigDecimal interesMo, BigDecimal comisionMo, String glosa) {
        this.liquidacionDetPK = liquidacionDetPK;
        this.pinPrestamo = pinPrestamo;
        this.pinTramo = pinTramo;
        this.monSigade = monSigade;
        this.tipoCambio = tipoCambio;
        this.capitalMo = capitalMo;
        this.interesMo = interesMo;
        this.comisionMo = comisionMo;
        this.glosa = glosa;
    }

    public LiquidacionDet(String liqCodigo, String liqDetalle) {
        this.liquidacionDetPK = new LiquidacionDetPK(liqCodigo, liqDetalle);
    }

    public LiquidacionDetPK getLiquidacionDetPK() {
        return liquidacionDetPK;
    }

    public void setLiquidacionDetPK(LiquidacionDetPK liquidacionDetPK) {
        this.liquidacionDetPK = liquidacionDetPK;
    }

    public String getPinPrestamo() {
        return pinPrestamo;
    }

    public void setPinPrestamo(String pinPrestamo) {
        this.pinPrestamo = pinPrestamo;
    }

    public Integer getPinTramo() {
        return pinTramo;
    }

    public void setPinTramo(Integer pinTramo) {
        this.pinTramo = pinTramo;
    }

    public String getMonSigade() {
        return monSigade;
    }

    public void setMonSigade(String monSigade) {
        this.monSigade = monSigade;
    }

    public BigDecimal getTipoCambio() {
        return tipoCambio;
    }

    public void setTipoCambio(BigDecimal tipoCambio) {
        this.tipoCambio = tipoCambio;
    }

    public BigDecimal getCapitalMo() {
        return capitalMo;
    }

    public void setCapitalMo(BigDecimal capitalMo) {
        this.capitalMo = capitalMo;
    }

    public BigDecimal getInteresMo() {
        return interesMo;
    }

    public void setInteresMo(BigDecimal interesMo) {
        this.interesMo = interesMo;
    }

    public BigDecimal getComisionMo() {
        return comisionMo;
    }

    public void setComisionMo(BigDecimal comisionMo) {
        this.comisionMo = comisionMo;
    }

    public String getGlosa() {
        return glosa;
    }

    public void setGlosa(String glosa) {
        this.glosa = glosa;
    }
//
//    @XmlTransient
//    public List<LiquidacionReng> getLiquidacionRengList() {
//        return liquidacionRengList;
//    }
//
//    public void setLiquidacionRengList(List<LiquidacionReng> liquidacionRengList) {
//        this.liquidacionRengList = liquidacionRengList;
//    }

    /*@XmlTransient
    public List<LiquidacionDatos> getLiquidacionDatosList() {
        return liquidacionDatosList;
    }

    public void setLiquidacionDatosList(List<LiquidacionDatos> liquidacionDatosList) {
        this.liquidacionDatosList = liquidacionDatosList;
    }*/

//    public Liquidacion getLiquidacion() {
//        return liquidacion;
//    }
//
//    public void setLiquidacion(Liquidacion liquidacion) {
//        this.liquidacion = liquidacion;
//    }

	@Override
	public String toString() {
		return "LiquidacionDet [liquidacionDetPK=" + liquidacionDetPK + ", pinPrestamo=" + pinPrestamo + ", pinTramo=" + pinTramo + ", monSigade="
				+ monSigade + ", tipoCambio=" + tipoCambio + ", capitalMo=" + capitalMo + ", interesMo=" + interesMo + ", comisionMo=" + comisionMo
				+ ", glosa=" + glosa ;
	}

	public BigDecimal getTipoCambiomo() {
		return tipoCambiomo;
	}

	public void setTipoCambiomo(BigDecimal tipoCambiomo) {
		this.tipoCambiomo = tipoCambiomo;
	}
}
