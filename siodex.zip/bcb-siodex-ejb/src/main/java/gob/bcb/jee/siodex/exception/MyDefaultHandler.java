/*
 * Creado el 21-04-2006

 *
 * TODO Para cambiar la plantilla de este archivo generado, vaya a
 * Ventana - Preferencias - Java - Estilo de c�digo - Plantillas de c�digo
 */
package gob.bcb.jee.siodex.exception;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * @author Administrador
 *
 * TODO Para cambiar la plantilla de este comentario generado, vaya a
 * Ventana - Preferencias - Java - Estilo de cdigo - Plantillas de cdigo
 */
public class MyDefaultHandler extends DefaultHandler {
      /**
       * Clase de manejo de errores en SAX
       * @param e Excepcion
       * @throws org.xml.sax.SAXException Excepcion de SAX
       */
      public void warning(SAXParseException e) throws SAXException {
          throw new SAXException(getMessage("ATENCION", e));
      }

      /**
       * Clase de manejo de errores SAX
       */
      public void error(SAXParseException e) throws SAXException {
          throw new SAXException(getMessage("ERROR", e));
      }

      /**
       * Clase de manejo de errores SAX
       */
      public void fatalError(SAXParseException e) throws SAXException {
          throw new SAXException(getMessage("ERROR FATAL", e));
      }

      /**
       * Clase de manejo de errores SAX
       */
      private String getMessage(String level, SAXParseException e) {
          return (level + "(Linea:" + e.getLineNumber() + ") " + e.getMessage());
      }
  }

