package gob.bcb.jee.siodex.commons;

public interface Constants {
	static final String PROP_BCB_KEY_STORE_FILE = "bcb.keystoreFile";
	static final String PROP_BCB_KEY_STORE_PASS = "bcb.keystorePass";
	static final String PROP_BCB_PRIVATE_KEY_ALIAS = "bcb.privateKeyAlias";
	static final String PROP_BCB_PRIVATE_KEY_PASS = "bcb.privateKeyPass";
	static final String PROP_BCB_CERTIFICATE_ALIAS = "bcb.certificateAlias";
	
	static final String PROP_TGN_KEY_STORE_FILE = "tgn.keystoreFile";
	static final String PROP_TGN_KEY_STORE_PASS = "tgn.keystorePass";
	static final String PROP_TGN_PRIVATE_KEY_ALIAS = "tgn.privateKeyAlias";
	static final String PROP_TGN_PRIVATE_KEY_PASS = "tgn.privateKeyPass";
	static final String PROP_TGN_CERTIFICATE_ALIAS = "tgn.certificateAlias";

	/**
	 * Formato fecha en la base de datos
	 */
	static final String FORMAT_DATE_DB = "dd/MM/yyyy";
	
	/**
	 * Formato de fecha hora para datos que requieran hora
	 */
	static final String FORMAT_DATE_TIME = "yyyy-MM-dd HH:mm:ss:SSS";
	static final String COD_TGN = "237";
	static final String COD_BCB = "900";	
}
