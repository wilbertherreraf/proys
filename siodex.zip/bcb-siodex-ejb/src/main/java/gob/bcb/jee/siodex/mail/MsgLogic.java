package gob.bcb.jee.siodex.mail;


import gob.bcb.jee.siodex.entities.DeudorLiquidacion;
import gob.bcb.jee.siodex.util.CorreoUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

public class MsgLogic {
	public static final String ln = System.getProperty("line.separator");
	static final Logger log = Logger.getLogger(MsgLogic.class);	
	private final static String AVISO_SOL_BOLSIN_RECIBIDO[] = {
			"Bols�n BCB: {0}",
			"Cliente: {0} \r" + ln + "Cuenta en Moneda Nacional(BS):{1} " + "." + "\n" + "Cuenta en Moneda Extranjera(SUS):{2} " + " ." + "\n"
					+ "Monto Solicitado(SUS):[{3} " + "]" + "\n" + "Tipo de Cambio (BS):[{4} " + "]" + "\n" + "Monto Solicitado(BS):[{5} " + "]"
					+ "\n" + "---------------------------------------------------------" + ln
					+ "Favor confirmar y reservar fondos respondiendo este mail a jsherrera@bcb.gob.bo y cvalencia@bcb.gob.bo " + ln + ln
					+ "Atte. \n\nDepartamento de Operaciones Cambiarias" };

	private final static String AVISO_SOL_VENTADIRECTA[] = {
			"Operaciones Cambiarias: {0}",
			"Solicitante: {0} \r" + ln + "Monto Solicitado(SUS):[{1} " + "]" + "\n" + "Tipo de Cambio (BS):[{2} " + "]" + "\n"
					+ "Monto Moneda Nacional(BS):[{3} " + "]" + "\n" + "Cod solicitud:[{4} " + "] \r" + ln
					+ "---------------------------------------------------------" + ln + "." };

	private final static String ENCABEZADO = "Estimado(a) usuario(a),\n\n"
			+ "Le comunicamos que en el sistema SIOC del Banco Central de Bolivia \nse registr� una operaci�n de Bols�n \n"
			+ "\n---------------------------------------------------------\n";
	private final static String ENCABEZADOGRAL = "Estimado(a) usuario(a),\n\n"
			+ "Le comunicamos que en el sistema SIOC del Banco Central de Bolivia \nse registr� una operaci�n \n"
			+ "\n---------------------------------------------------------\n";
	private final static String ENTIDAD = "Entidad: {0}\n";
	private final static String ACTIVIDAD = "Actividad: {0}\n";

	public static String IP_SMTP = "10.2.11.27";
	public static int PORT_SMTP =  25;

	public static void enviarMails(EntityManager em, String tipo, String codInstitucion, String accion, boolean enviarAIFA, Object... parameters) {
		List<String> correos = listaDeCorreos(em, tipo, codInstitucion, accion, enviarAIFA);

		CorreoUtils correoUtils = new CorreoUtils(IP_SMTP, PORT_SMTP);
		StringBuilder mensaje = new StringBuilder();
		
		mensaje.append(parameters[0]);


		String correoremitente = "flecona@bcb.gob.bo";
		for (String email : correos) {
			try {
				if (email != null && !email.trim().isEmpty()) {
					correoUtils.enviaAlServidorSMTP(correoremitente, email, accion, mensaje.toString());
				}
				log.info("Mensaje de correo enviado " + tipo + " destinatario " + email);
			} catch (Exception e1) {
				// no sucede nada solo se verifica que haya el log
				log.error("Error al enviar mail " + e1.getMessage(), e1);
			}
		}
	}
	public static void enviarMails(List<String> correos , String tipo, String codInstitucion, String accion, boolean enviarAIFA, Object... parameters) {

		CorreoUtils correoUtils = new CorreoUtils(IP_SMTP, PORT_SMTP);
		StringBuilder mensaje = new StringBuilder();
		
		mensaje.append(parameters[0]);


		String correoremitente = "flecona@bcb.gob.bo";
		for (String email : correos) {
			try {
				if (email != null && !email.trim().isEmpty()) {
					correoUtils.enviaAlServidorSMTP(correoremitente, email, accion, mensaje.toString());
				}
				log.info("Mensaje de correo enviado " + tipo + " destinatario " + email);
			} catch (Exception e1) {
				// no sucede nada solo se verifica que haya el log
				log.error("Error al enviar mail " + e1.getMessage(), e1);
			}
		}
	}

	public static List<String> listaDeCorreos(EntityManager em, String tipo, String codInstitucion, String accion, boolean enviarAIFA) {
		// se modifica el valor de enviarAIFA para asegurar que haya el valor
		// institucion
		// sera verdadero si se especifique que se envie y ademas exista una
		// institucion
	
		enviarAIFA = enviarAIFA && codInstitucion != null && !codInstitucion.trim().isEmpty();

		List<String> correos = new ArrayList<String>();

		StringBuilder jsql = new StringBuilder();
		jsql.append("select d " + "from DeudorLiquidacion d " + " where d.cveVigente = 1 ");

		if (enviarAIFA) {
			jsql.append("and d.genLiq in (" + codInstitucion + ",900) ");
		} else {
			jsql.append("and d.genLiq = 900 ");
		}
	
		log.info("Consulta: " + jsql.toString());
		
		String usrEmail = "";
		Query query = em.createQuery(jsql.toString());

		List<DeudorLiquidacion> resultado = query.getResultList();
		log.info("Consulta: " + resultado.size());
		
		if (resultado.size() > 0) {
			for (DeudorLiquidacion item : resultado) {
				usrEmail = item.getDeuEmail();
				if (!StringUtils.isEmpty(usrEmail)) {
					correos.addAll(Arrays.asList(usrEmail.split(",")));					
					//correos.add(usrEmail);
				}
			}
		}

		log.info("correos para " + tipo + " destinatarios registrados " + correos.toString());
		return correos;
	}
	public static List<String> listaDeCorreos(List<DeudorLiquidacion> deudorLiquidacionList) {
		List<String> correos = new ArrayList<String>();
		String usrEmail = "";
		for (DeudorLiquidacion deudorLiquidacion : deudorLiquidacionList) {
			usrEmail = deudorLiquidacion.getDeuEmail();
			if (!StringUtils.isEmpty(usrEmail)) {
				correos.addAll(Arrays.asList(usrEmail.split(",")));					
			}			
		}
		log.info("correos destinatarios registrados " + correos.toString());
		return correos;		
	}
	public static void main(String[] args) {
		String horaAdjudAuto = "10:52";

		String[] horaAAuto = StringUtils.split(horaAdjudAuto, ":");
		System.out.println(horaAAuto[0] + " " + horaAAuto[1]);

		Map<String, String> msgRepuesta = new HashMap<String, String>();
		msgRepuesta.put("ad", "dddff aasdf  afasdf");
		msgRepuesta.put("adderr", "fertwqersfg");
		msgRepuesta.put("frtg", "kdid a�asdkfp ffff");
		System.out.println(ArrayUtils.toString(msgRepuesta));
		StringBuffer sbf = new StringBuffer("This is the first line.");
		sbf.append(System.getProperty("line.separator"));
		sbf.append("This is second line.");
		
	}
}
