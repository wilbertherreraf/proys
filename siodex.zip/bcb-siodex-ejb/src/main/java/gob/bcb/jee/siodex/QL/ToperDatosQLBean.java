package gob.bcb.jee.siodex.QL;

import java.util.ArrayList;
import java.util.List;

import gob.bcb.jee.siodex.entities.ToperDatos;

import javax.ejb.EJBException;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

@Stateless
@LocalBean
public class ToperDatosQLBean implements ToperDatosQLBeanLocal {

	static final Logger logger = Logger.getLogger(ToperDatosQLBean.class);

	@PersistenceContext(unitName = "siodex")
	EntityManager em;

	/**
	 * Default constructor.
	 */
	public ToperDatosQLBean() {
		// TODO Auto-generated constructor stub
	}

	@SuppressWarnings("unchecked")
	public List<ToperDatos> getDatos(String codigo) {

		List<ToperDatos> lista = new ArrayList<ToperDatos>();
		StringBuilder query = new StringBuilder();

		query.append("select d from ToperDatos d where d.toperDatosPK.topCodigo = ? order by d.orden");
		
		logger.info("Recuperando registros de tipo de operacion para " + codigo + " => " + query.toString());
		
		Query consulta = em.createQuery(query.toString());
		consulta.setParameter(1, codigo);

		lista = consulta.getResultList();

		return lista;

	}

}
