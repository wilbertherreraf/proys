package gob.bcb.jee.siodex.WS.sigma;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the clientewssigamsiodex package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _AlertaPagoProcesado_QNAME = new QName("http://sigma.gob.bo/", "alertaPagoProcesado");
    private final static QName _AlertaConsultaVencimiento_QNAME = new QName("http://sigma.gob.bo/", "alertaConsultaVencimiento");
    private final static QName _ConsultaVencimientosObservados_QNAME = new QName("http://sigma.gob.bo/", "consultaVencimientosObservados");
    private final static QName _AlertaConsultaVencimientoResponse_QNAME = new QName("http://sigma.gob.bo/", "alertaConsultaVencimientoResponse");
    private final static QName _ConsultaVencimientosObservadosResponse_QNAME = new QName("http://sigma.gob.bo/", "consultaVencimientosObservadosResponse");
    private final static QName _ListaPagosAutorizados_QNAME = new QName("http://sigma.gob.bo/", "listaPagosAutorizados");
    private final static QName _AlertaPagoProcesadoResponse_QNAME = new QName("http://sigma.gob.bo/", "alertaPagoProcesadoResponse");
    private final static QName _ListaPagosAutorizadosResponse_QNAME = new QName("http://sigma.gob.bo/", "listaPagosAutorizadosResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: clientewssigamsiodex
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link Respuesta }
     * 
     */
    public Respuesta createRespuesta() {
        return new Respuesta();
    }

    /**
     * Create an instance of {@link AlertaPagoProcesado }
     * 
     */
    public AlertaPagoProcesado createAlertaPagoProcesado() {
        return new AlertaPagoProcesado();
    }

    /**
     * Create an instance of {@link ConsultaVencimientosObservados }
     * 
     */
    public ConsultaVencimientosObservados createConsultaVencimientosObservados() {
        return new ConsultaVencimientosObservados();
    }

    /**
     * Create an instance of {@link ListaPagosAutorizadosResponse }
     * 
     */
    public ListaPagosAutorizadosResponse createListaPagosAutorizadosResponse() {
        return new ListaPagosAutorizadosResponse();
    }

    /**
     * Create an instance of {@link ConsultaVencimientosObservadosResponse }
     * 
     */
    public ConsultaVencimientosObservadosResponse createConsultaVencimientosObservadosResponse() {
        return new ConsultaVencimientosObservadosResponse();
    }

    /**
     * Create an instance of {@link AlertaConsultaVencimiento }
     * 
     */
    public AlertaConsultaVencimiento createAlertaConsultaVencimiento() {
        return new AlertaConsultaVencimiento();
    }

    /**
     * Create an instance of {@link ListaPagosAutorizados }
     * 
     */
    public ListaPagosAutorizados createListaPagosAutorizados() {
        return new ListaPagosAutorizados();
    }

    /**
     * Create an instance of {@link AlertaPagoProcesadoResponse }
     * 
     */
    public AlertaPagoProcesadoResponse createAlertaPagoProcesadoResponse() {
        return new AlertaPagoProcesadoResponse();
    }

    /**
     * Create an instance of {@link AlertaConsultaVencimientoResponse }
     * 
     */
    public AlertaConsultaVencimientoResponse createAlertaConsultaVencimientoResponse() {
        return new AlertaConsultaVencimientoResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AlertaPagoProcesado }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sigma.gob.bo/", name = "alertaPagoProcesado")
    public JAXBElement<AlertaPagoProcesado> createAlertaPagoProcesado(AlertaPagoProcesado value) {
        return new JAXBElement<AlertaPagoProcesado>(_AlertaPagoProcesado_QNAME, AlertaPagoProcesado.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AlertaConsultaVencimiento }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sigma.gob.bo/", name = "alertaConsultaVencimiento")
    public JAXBElement<AlertaConsultaVencimiento> createAlertaConsultaVencimiento(AlertaConsultaVencimiento value) {
        return new JAXBElement<AlertaConsultaVencimiento>(_AlertaConsultaVencimiento_QNAME, AlertaConsultaVencimiento.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConsultaVencimientosObservados }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sigma.gob.bo/", name = "consultaVencimientosObservados")
    public JAXBElement<ConsultaVencimientosObservados> createConsultaVencimientosObservados(ConsultaVencimientosObservados value) {
        return new JAXBElement<ConsultaVencimientosObservados>(_ConsultaVencimientosObservados_QNAME, ConsultaVencimientosObservados.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AlertaConsultaVencimientoResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sigma.gob.bo/", name = "alertaConsultaVencimientoResponse")
    public JAXBElement<AlertaConsultaVencimientoResponse> createAlertaConsultaVencimientoResponse(AlertaConsultaVencimientoResponse value) {
        return new JAXBElement<AlertaConsultaVencimientoResponse>(_AlertaConsultaVencimientoResponse_QNAME, AlertaConsultaVencimientoResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConsultaVencimientosObservadosResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sigma.gob.bo/", name = "consultaVencimientosObservadosResponse")
    public JAXBElement<ConsultaVencimientosObservadosResponse> createConsultaVencimientosObservadosResponse(ConsultaVencimientosObservadosResponse value) {
        return new JAXBElement<ConsultaVencimientosObservadosResponse>(_ConsultaVencimientosObservadosResponse_QNAME, ConsultaVencimientosObservadosResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListaPagosAutorizados }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sigma.gob.bo/", name = "listaPagosAutorizados")
    public JAXBElement<ListaPagosAutorizados> createListaPagosAutorizados(ListaPagosAutorizados value) {
        return new JAXBElement<ListaPagosAutorizados>(_ListaPagosAutorizados_QNAME, ListaPagosAutorizados.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AlertaPagoProcesadoResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sigma.gob.bo/", name = "alertaPagoProcesadoResponse")
    public JAXBElement<AlertaPagoProcesadoResponse> createAlertaPagoProcesadoResponse(AlertaPagoProcesadoResponse value) {
        return new JAXBElement<AlertaPagoProcesadoResponse>(_AlertaPagoProcesadoResponse_QNAME, AlertaPagoProcesadoResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListaPagosAutorizadosResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sigma.gob.bo/", name = "listaPagosAutorizadosResponse")
    public JAXBElement<ListaPagosAutorizadosResponse> createListaPagosAutorizadosResponse(ListaPagosAutorizadosResponse value) {
        return new JAXBElement<ListaPagosAutorizadosResponse>(_ListaPagosAutorizadosResponse_QNAME, ListaPagosAutorizadosResponse.class, null, value);
    }

}
