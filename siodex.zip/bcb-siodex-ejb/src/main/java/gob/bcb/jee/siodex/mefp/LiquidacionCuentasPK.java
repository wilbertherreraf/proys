/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.mefp;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author CUriona
 */
@Embeddable
public class LiquidacionCuentasPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 6)
    @Column(name = "liq_codigo", nullable = false, length = 6)
    private String liqCodigo;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2)
    @Column(name = "cve_cuenta", nullable = false, length = 4)
    private String cveCuenta;

    public LiquidacionCuentasPK() {
    }

    public LiquidacionCuentasPK(String liqCodigo, String cveCuenta) {
        this.liqCodigo = liqCodigo;
        this.cveCuenta = cveCuenta;
    }

    public String getLiqCodigo() {
        return liqCodigo;
    }

    public void setLiqCodigo(String liqCodigo) {
        this.liqCodigo = liqCodigo;
    }

    public String getCveCuenta() {
        return cveCuenta;
    }

    public void setCveCuenta(String cveCuenta) {
        this.cveCuenta = cveCuenta;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (liqCodigo != null ? liqCodigo.hashCode() : 0);
        hash += (cveCuenta != null ? cveCuenta.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof LiquidacionCuentasPK)) {
            return false;
        }
        LiquidacionCuentasPK other = (LiquidacionCuentasPK) object;
        if ((this.liqCodigo == null && other.liqCodigo != null) || (this.liqCodigo != null && !this.liqCodigo.equals(other.liqCodigo))) {
            return false;
        }
        if ((this.cveCuenta == null && other.cveCuenta != null) || (this.cveCuenta != null && !this.cveCuenta.equals(other.cveCuenta))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gob.bcb.siodex.entities.LiquidacionCuentasPK[ liqCodigo=" + liqCodigo + ", liqDetalle=" + cveCuenta + " ]";
    }
    
}
