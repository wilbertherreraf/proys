package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.Vencimiento;
import gob.bcb.jee.siodex.exception.DataException;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.ejb.Local;

@Local
public interface VencimientoQLBeanLocal {

	/**
	 * 
	 * @return
	 */
	public List<Vencimiento> listaVencimiento(String estado, String codEnt) throws DataException;
	public List<Vencimiento> listaVencimientoSinFechas(String estado, String estadoNotif, String codEnt) throws DataException;
	public Vencimiento getVencimiento(String ptmCodigo, int traCodigo, String liqCodigo) throws DataException;

	List<Vencimiento> listaVencimiento(String estado, String estadoNotif, String codEnt) throws DataException;

	Vencimiento guardarComisionesBancarias(Vencimiento vencimiento) throws DataException;

	Vencimiento calcularComisionesBancarias(Vencimiento vencimiento, Date fecha) throws DataException;

	Vencimiento recuperarComisionesBancarias(Vencimiento vencimiento) throws DataException;

	/**
	 * Calcula el total de la liquidacion datos de comis, kap, int y totales en
	 * mon SUS, bol y mon origen, los totales sirven para el calculo de la
	 * comision bancaria
	 * 
	 * @param vencimiento
	 * @param fechaOperacion
	 * @param ptmCodigo
	 * @param traCodigo
	 * @param codigo
	 * @return
	 * @throws DataException
	 */
	Vencimiento calcularVencimiento(Vencimiento vencimiento, Date fechaOperacion, String ptmCodigo, int traCodigo, String codigo)
			throws DataException;

	String tipoPrestamoLiq(Vencimiento vencimiento);

	int nroMensajesSwift(Vencimiento vencimiento) throws DataException;

	Vencimiento guardarComisionBancaria(Vencimiento vencimiento, String tipoComi, BigDecimal monto) throws DataException;

	//Map<String, Object> conversion(BigDecimal monto, String monOrigen, String monDestino, Date fecha, String monDestinoConv) throws DataException;

	Vencimiento actualizarLiquidacion(Vencimiento vencimiento, String observacion, String nuevoEstado, String tipoAct) throws DataException;

	Vencimiento recuperarCuentasPrestamoYDetalles(Vencimiento vencimiento, String cveTitular) throws DataException;

	Map<String, Object> conversion(BigDecimal monto, String monOrigen, String monDestino, Date fecha, String monDestinoConv, BigDecimal tcDefecto)
			throws DataException;

//	Vencimiento crearLogAuditoria(Vencimiento vencimiento, String codUsuario, String codParticipante, String estacion, String codTransaccion);

	void enviarCorreos(Vencimiento vencimiento, String observacion, String nuevoEstado, String flagTipoActualiza) throws DataException;
	
	public void enviarCorreos(Vencimiento vencimiento, String observacion, String nuevoEstado, String flagTipoActualiza, String flagErrorWS, String errorWS) throws DataException;

	BigDecimal calcularComisionCOPA(Vencimiento vencimiento, Date fechaTc) throws DataException;

	List<Vencimiento> listaVencimiento(String estado, String estadoNotif, String codEnt, Date fechaVenc, Date fechaVencHasta) throws DataException;
	
    public Boolean isGenerarMensajeSwit(String topCodigo);
	
	public Boolean isCobrarComMensajeSwit(String topCodigo);
}
