package gob.bcb.jee.siodex.service;

import gob.bcb.jee.siodex.QL.*;
import gob.bcb.jee.siodex.commons.Constants;
import gob.bcb.jee.siodex.entities.*;
import gob.bcb.jee.siodex.exception.DataException;
import gob.bcb.jee.siodex.mefp.LiquidacionCuentas;
import gob.bcb.jee.siodex.mefp.LiquidacionCuentasQLBeanLocal;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Clase que contiene los metodos para crear los campos de un mensaje swift.
 * 
 * @author C. Cecilia Uriona
 * 
 */
@Stateless
public class OperacionBean implements OperacionBeanLocal {

	static final Logger logger = Logger.getLogger(OperacionBean.class);

	@PersistenceContext(unitName = "siodex")
	EntityManager em;

	@Inject
	private ToperDatosQLBeanLocal toperDatosQLBeanLocal;
	@Inject
	private SolicitudQLBeanLocal solicitudQLBeanLocal;
	@Inject
	private SolDatoQLBeanLocal solDatoQLBeanLocal;
	@Inject
	private CuentaQLBeanLocal cuentaQLBeanLocal;
	@Inject
	private MensajeQLBeanLocal mensajeQLBeanLocal;
	@Inject
	private MensajeSwiftBeanLocal mensajeSwiftBeanLocal;
	@Inject
	private MensajeDatosQLBeanLocal mensajeDatosQLBeanLocal;
	@Inject
	private LiquidacionQLBeanLocal liquidacionQLBeanLocal;
	@Inject
	private VencimientoQLBeanLocal vencimientoQLBeanLocal;
	@Inject
	private LiquidacionCalculosQLBeanLocal liquidacionCalculosQLBeanLocal;
	@Inject
	private MonedaQLBeanLocal monedaQLBeanLocal;
	@Inject
	private ConsultasSdxQLBeanLocal consultasSdxQLBeanLocal;
	@Inject
	private CoinQLBeanLocal coinQLBeanLocal;
	@Inject
	private ComprobanteBeanLocal comprobanteBeanLocal;
	@Inject
	private LiquidacionCuentasQLBeanLocal liquidacionCuentasQLBeanLocal;
	@Inject
	private DeudaBeanLocal deudaBeanLocal;
	@Inject
	private PrestamoInstanciaQLBeanLocal prestamoInstanciaQLBeanLocal;
	@Inject
	private ComprobanteQLBeanLocal comprobQLBeanLocal;
	private String codParticipante = "";
	private String nti = "";
	private Mensaje mensajeOpInternas = new Mensaje();
	private List<Comprobante> comprobantes = new ArrayList<Comprobante>();



	public void crearSolicitud(Vencimiento vencimiento, String varAuxiliar) throws DataException {
		logger.info("ingresando a crearSolicitud... " + vencimiento.getLiqCodigo());
		vencimiento = vencimientoQLBeanLocal.actualizarLiquidacion(vencimiento, "", "", "L");

		if (!vencimiento.getCveEstado().equals("A") && !vencimiento.getCveEstado().equals("S")) {
			// diferente a autorizado
			throw new DataException("liquidacion en estado incorrecto no puede generarse operacion");
		}

		String codLiquidacion = vencimiento.getLiqCodigo();
		logger.info("entando a operacion contabilizar creando operacion codigo liq: " + codLiquidacion + " \n " + vencimiento.toString());

		Cuenta cuentaObjDEUD = vencimiento.getCuentaPrestamo("DEUD");
		logger.info("Cta contable " + cuentaObjDEUD.toString());

		Cuenta cuentaObjDEUC = vencimiento.getCuentaPrestamo("DEUC");
		
		String codTipoOperacion = vencimiento.getCodTipoOperacion();

		String codProcesoContable = cuentaObjDEUD.getProCodigo();

		String codLip = cuentaObjDEUD.getCodlip();
		logger.info("Codigo de proceso contable " + codProcesoContable + " codLip " + codLip);

		// whf ojooo algunos cuentas no tienen part afecta?
		codParticipante = cuentaObjDEUD.getCodPart();

		if (StringUtils.isBlank(codParticipante)) {
			throw new DataException("Codigo de participante nulo o invalido, verifique datos de cuenta deudor" + cuentaObjDEUD.getCtaCodigo());
		}

		String glosa = "";
		if (vencimiento.getCantMensSwift() == 0) {
			logger.info("pago local: ");

			glosa = glosaGeneral(vencimiento, "LOCAL");
		} else {
			logger.info("pago exterior: ");
			glosa = glosaGeneral(vencimiento, "EXTERNA");
		}

		LogAuditoria log = vencimiento.getLogAuditoria(); // logQLBeanLocal.crearLog(vencimiento.getUsuario(),
															// men.getUsrCodigo(),
															// men.getEstacion(),
															// "002100");
		// /////////////////////////////////////
		// captura de montos dolarizados
		// convertimos los montos a dolares según el tipo de moneda
		// P = pendiente

		Solicitud solicitud = solicitudQLBeanLocal.getSolicitudByCodLiq(vencimiento.getLiqCodigo(), null);

		if (solicitud == null) {
			Integer solCodigo = solicitudQLBeanLocal.maxCodigoNuevo();

			solicitud = new Solicitud(solCodigo, log.getLogAuditoriaId(), codLip, codParticipante, glosa, new Date(), codLiquidacion, "P",
					cuentaObjDEUD.getCodMoneda(), null, null);
			
			solicitud.setUsrCodigo(vencimiento.getUsuario());
			solicitud.setFechaHora(new Date());
			solicitud.setEstacion(vencimiento.getLogAuditoria().getEstacion());
			// ////////////////////////////////////////////////////
			logger.info("solicitud a crear: " + solicitud.toString());
			solicitudQLBeanLocal.create(solicitud);

		} else {
			if (!solicitud.getCveEstado().equals("P")) {
				throw new DataException("La liquidacion " + vencimiento.getLiqCodigo() + " con estado incorrecto[codSolicitud: "
						+ solicitud.getSolCodigo() + " ] , no puede continuar ");
			}
			solicitud.setCodLip(codLip);
			solicitud.setCodPart(codParticipante);
			solicitud.setFecha(new Date());
			solicitud.setMoneda(cuentaObjDEUD.getCodMoneda());
			solicitud.setGlosa(glosa);
			solicitud.setLogAuditoriaId(log.getLogAuditoriaId());
			solicitud.setUsrCodigo(vencimiento.getUsuario());
			solicitud.setFechaHora(new Date());
			solicitud.setEstacion(vencimiento.getLogAuditoria().getEstacion());

			logger.info("solicitud a actualizar: " + solicitud.toString());

			solicitudQLBeanLocal.edit(solicitud);

		}

		solicitud = solicitudQLBeanLocal.getSolicitudByCodLiq(vencimiento.getLiqCodigo(), "P");

		solDatoQLBeanLocal.eliminarDatosSolicitud(solicitud.getSolCodigo());

		List<ToperDatos> datosA = toperDatosQLBeanLocal.getDatos(codTipoOperacion);

		if (datosA == null || datosA.size() == 0) {
			throw new DataException("no existen datos en Toper_Datos detalle para tipo de operacion " + codTipoOperacion);
		}

		nti = codLiquidacion;

		Liquidacion liquidacion = liquidacionQLBeanLocal.getLiquidacion(vencimiento.getLiqCodigo());

		boolean esMonedas = false;
		int orden = 1;

		for (ToperDatos toperDatos : datosA) {
			logger.info("ToperDatos: " + toperDatos.toString());

			SolDato solDato = null;

			if (toperDatos.getCveTipoDato().equals("N")) {
				if (toperDatos.getToperDatosPK().getDatoAdicional().equals("MONTOUSD")) {
					// si es monedas, se evalua en el sgte ciclo
					esMonedas = true;

					// //////////////////////
					List<Liquidacion> monedaMonto = consultasSdxQLBeanLocal.montosPorMonedas(liquidacion.getLiqCodigo());
					if (vencimiento.getCodTipoOperacion().equals("22")) {
						monedaMonto = consultasSdxQLBeanLocal.montosPorMonedas(consultasSdxQLBeanLocal.getLiquidacionBID1020(vencimiento.getLiqCodigo()));
					}
					for (Liquidacion liquidacion2 : monedaMonto) {
						// se extrae la moneda contable de moneda sigade
						Moneda monedaC = monedaQLBeanLocal.getMoneda(liquidacion2.getCodMoneda());

						String monedaSIGADE = liquidacion2.getMonSigade();

						BigDecimal valorN = liquidacion2.getMonto();
						if (codTipoOperacion.equals("21")) {
							BigDecimal montoExt = BigDecimal.ZERO;
							SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
							logger.info("**************************************** ext varios tramos - igualar moneda: ");
							List <PrestamoInstancia> instancias = prestamoInstanciaQLBeanLocal.listaInstancia(vencimiento.getPtmCodigo(), vencimiento.getTraCodigo(), "EXT");
							for (PrestamoInstancia instancia : instancias) {
								logger.info("**************************************** instancia: " + instancia.getPinPrestamo() + " , " + instancia.getPinTramo());
								Object[] da = deudaBeanLocal.InteresesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(vencimiento.getFechaVenc()), "11");
								if (da != null) {
									if (((String) da[2]).equals(liquidacion2.getMonSigade())) {
										montoExt = montoExt.add((BigDecimal) da[1]);
										logger.info("**************************************** montoExt: " + montoExt);
									}
								}
								da = deudaBeanLocal.InteresesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(vencimiento.getFechaVenc()), "21");
								if (da != null) {
									if (((String) da[2]).equals(liquidacion2.getMonSigade())) {
										montoExt = montoExt.add((BigDecimal) da[1]);
										logger.info("**************************************** montoExt: " + montoExt);
									}
								}
								da = deudaBeanLocal.ComisionesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(vencimiento.getFechaVenc()), "11");
								if (da != null) {
									if (((String) da[2]).equals(liquidacion2.getMonSigade())) {
										montoExt = montoExt.add((BigDecimal) da[1]);
										logger.info("**************************************** montoExt: " + montoExt);
									}
								}
							}
							valorN = montoExt;
						}

						logger.info("monto monedas:[" + codLiquidacion + "] " + monedaSIGADE);
						// se evalua si es al exterior
						if (!monedaSIGADE.equals("BBS") && !monedaSIGADE.equals("XP2")) {
							if (valorN != null && valorN.compareTo(BigDecimal.ZERO) != 0) {
								
								Moneda monedaCCC = monedaQLBeanLocal.getMoneda(liquidacion2.getCodMoneda());
								logger.info("XXX:   monedaCCC " + monedaCCC.getMonCoin() + " " + monedaCCC.getMonSigade());
								SolDato solDatoNew = solDatoQLBeanLocal.getSolDato(solicitud.getSolCodigo(), "MONTO" + monedaCCC.getMonSigade());
								if (solDatoNew != null) {
									solDatoNew.setCveDh("H");
									solDatoNew.setCodMoneda(liquidacion2.getCodMoneda());
									solDatoNew.setDatoNumero(valorN);
									solDatoNew.setLogAuditoriaId(log.getLogAuditoriaId());

									BigDecimal tipoCambio = coinQLBeanLocal.getTC(liquidacion.getFechaTc(), liquidacion2.getCodMoneda());
									solDatoNew.setTipoCambio(tipoCambio);

									solDatoNew = solDatoQLBeanLocal.actualizaCuentaMov(solicitud, solDatoNew);
									solDatoNew.setOrden(orden);

									// //////////////////////////////
									if (monedaSIGADE.equals("KRW") || monedaSIGADE.equals("RMY")) {
										monedaCCC = monedaQLBeanLocal.getMonedaCoin(monedaSIGADE);
										
										Map<String, Object> montoConvertido = vencimientoQLBeanLocal.conversion(liquidacion2.getMonto(),
												monedaCCC.getMonCoin(), "34", vencimiento.getFechaTc(), "69", liquidacion2.getTipoCambio());
										BigDecimal montoSUS = (BigDecimal) montoConvertido.get("montosus");
										logger.info("XXX: CHINO!!!!!!  " + montoSUS + "  "  + monedaSIGADE + "  " + monedaCCC.getMonCoin());
										solDatoNew.setDatoNumero(montoSUS);

									}
									logger.info("3.Creando reg. detalle : " + solDatoNew.toString());
									solDatoQLBeanLocal.edit(solDatoNew);

								} else {
									solDato = new SolDato(new SolDatoPK(solicitud.getSolCodigo(), "MONTO" + monedaCCC.getMonSigade()), log.getLogAuditoriaId(),
											valorN, null);
									solDato.setCveDh("H");
									solDato.setCodMoneda(liquidacion2.getCodMoneda());

									BigDecimal tipoCambio = coinQLBeanLocal.getTC(liquidacion.getFechaTc(), liquidacion2.getCodMoneda());
									solDato.setTipoCambio(tipoCambio);

									solDato = solDatoQLBeanLocal.actualizaCuentaMov(solicitud, solDato);
									solDato.setOrden(orden);
									// //////////////////////////////
									if (monedaSIGADE.equals("KRW") || monedaSIGADE.equals("RMY")) {
										monedaCCC = monedaQLBeanLocal.getMonedaCoin(monedaSIGADE);

										Map<String, Object> montoConvertido = vencimientoQLBeanLocal.conversion(liquidacion2.getMonto(),
												monedaCCC.getMonCoin(), "34", vencimiento.getFechaTc(), "69", liquidacion2.getTipoCambio());
										BigDecimal montoSUS = (BigDecimal) montoConvertido.get("montosus");
										
										logger.info("XXX: CHINO!!!!!!  " + montoSUS + "  "  + monedaSIGADE + "  " + monedaCCC.getMonCoin());										
										solDato.setDatoNumero(montoSUS);

									}

									logger.info("4.Creando reg. detalle : " + solDato.toString());
									solDatoQLBeanLocal.create(solDato);
								}
							}
						}
						orden++;
					}
					// /////////////////////
					// continuamos con el siguiente item
					continue;
				}

				solDato = liquidacionCalculosQLBeanLocal.calculoConceptoMonto(vencimiento, liquidacion, toperDatos.getToperDatosPK()
						.getDatoAdicional(), "codMensaje", "");

				solDato.setOrden(orden);

				if (solDato.getDatoNumero() != null && solDato.getDatoNumero().compareTo(BigDecimal.ZERO) != 0) {
					SolDatoPK solDatoPK = new SolDatoPK(solicitud.getSolCodigo(), toperDatos.getToperDatosPK().getDatoAdicional());
					
					if (toperDatos.getToperDatosPK().getDatoAdicional().equals("MONTOTOTCOMISIONES") && solDato.getCodMoneda().trim().equals("34")) {
						solDatoPK.setCodDato("MONTOTOTUSDCOMISIONES");
					}
					
					solDato.setSolDatoPK(solDatoPK);
					solDato.setLogAuditoriaId(log.getLogAuditoriaId());

					solDato.setCveDh(toperDatos.getCveDebeHaber());

					if (!StringUtils.isBlank(toperDatos.getCodMoneda())) {
						// si es diferente de nulo el valor parametrizado es el
						// que manda
						solDato.setCodMoneda(toperDatos.getCodMoneda());
					}
					solDato = solDatoQLBeanLocal.actualizaCuentaMov(solicitud, solDato);
					logger.info("Creando reg. detalle : " + solDato.toString());
					solDatoQLBeanLocal.create(solDato);
				}
			} else {
				String valorC = getValorC(vencimiento, cuentaObjDEUD, cuentaObjDEUC, toperDatos.getToperDatosPK().getDatoAdicional(),
						vencimiento.getPtmCodigo(), vencimiento.getTraCodigo(), codLip, codTipoOperacion);

				if (valorC != null) {
					solDato = new SolDato(new SolDatoPK(solicitud.getSolCodigo(), toperDatos.getToperDatosPK().getDatoAdicional()),
							log.getLogAuditoriaId(), null, valorC);

					logger.info("2.Creando reg. detalle : " + solDato.toString());
					solDatoQLBeanLocal.create(solDato);

				}
			} // end dato texto
			orden++;
		} // end for datos

		List<SolDato> listaDato = solDatoQLBeanLocal.getDatos(solicitud.getSolCodigo());
		if (listaDato.size() == 0) {
			throw new DataException("no existen datos solicitud registrados " + solicitud.getSolCodigo());
		}
		
		/***********************************************/
		/* MODIFICACION FNDR: SEPARAR MONTOS           */
		/* XPERTIC   02-02-2016                        */
		if (vencimiento.getDeudor().equals("FNDR")) {
			BigDecimal monFndr = BigDecimal.ZERO;
			BigDecimal monCap = BigDecimal.ZERO;
			for (SolDato dato : listaDato) {
				if (dato.getSolDatoPK().getCodDato().equals("TOTFNDR")) {
					monFndr = dato.getDatoNumero();
				}
			}
			
			for (SolDato dato : listaDato) {
				if (dato.getSolDatoPK().getCodDato().equals("TOTTRANS")) {
					monCap = dato.getDatoNumero().subtract(monFndr);
					dato.setDatoNumero(monCap);
					solDatoQLBeanLocal.edit(dato);
				}
			}
		}
		/***********************************************/
		
		/***********************************************/
		/* MODIFICACION DIFERENCIAL                    */
		/* XPERTIC   18-03-2016                        */

			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			BigDecimal monDiff = BigDecimal.ZERO;
			BigDecimal capital = BigDecimal.ZERO;
			BigDecimal interes = BigDecimal.ZERO;
			BigDecimal comision = BigDecimal.ZERO;
			BigDecimal montoE = BigDecimal.ZERO;
			for (SolDato dato : listaDato) {
				if (dato.getSolDatoPK().getCodDato().equals("MONTODIFCUTBS")) {
					monDiff = dato.getDatoNumero();
					if (!monDiff.equals(BigDecimal.ZERO)) {
						if (liquidacion.getTipoOper().equals("12")) {
							logger.info("**************************************** diff varios tramos: ");
							List <PrestamoInstancia> instancias = prestamoInstanciaQLBeanLocal.listaInstancia(liquidacion.getPtmCodigo(), liquidacion.getTraCodigo(), "EXT");
							for (PrestamoInstancia instancia : instancias) {
								logger.info("**************************************** instancia: " + instancia.getPinPrestamo() + " , " + instancia.getPinTramo());
								Object[] da = deudaBeanLocal.InteresesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "11");
								if (da != null) {
									capital = capital.add((BigDecimal) da[1]);
									logger.info("**************************************** capital: " + capital);
								}
								da = deudaBeanLocal.InteresesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "21");
								if (da != null) {
									interes = interes.add((BigDecimal) da[1]);
									logger.info("**************************************** interes: " + interes);
								}
								da = deudaBeanLocal.ComisionesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "11");
								if (da != null) {
									comision = comision.add((BigDecimal) da[1]);
									logger.info("**************************************** comision: " + comision);
								}
							}
						} else {
							Object[] da = deudaBeanLocal.InteresesDms1(liquidacion.getPtmCodigo(), liquidacion.getTraCodigo(), sdf.format(liquidacion.getFechaVenc()), "11");
							if (da != null) {
								capital = (BigDecimal) da[1];
								logger.info("**************************************** capital: " + capital);
							}
							da = deudaBeanLocal.InteresesDms1(liquidacion.getPtmCodigo(), liquidacion.getTraCodigo(), sdf.format(liquidacion.getFechaVenc()), "21");
							if (da != null) {
								interes = (BigDecimal) da[1];
								logger.info("**************************************** interes: " + interes);
							}
							da = deudaBeanLocal.ComisionesDms1(liquidacion.getPtmCodigo(), liquidacion.getTraCodigo(), sdf.format(liquidacion.getFechaVenc()), "11");
							if (da != null) {
								comision = (BigDecimal) da[1];
								logger.info("**************************************** comision: " + comision);
							}
						}
					}
				}
			}
			
			if (!monDiff.equals(BigDecimal.ZERO)) {
				if (!liquidacion.getTipoOper().equals("22")) {
					for (SolDato dato : listaDato) {
						if (dato.getSolDatoPK().getCodDato().equals("MONTOEUR")) {
							montoE = capital.add(interes).add(comision);
							dato.setDatoNumero(montoE);
							solDatoQLBeanLocal.edit(dato);
						}
					}
					
					for (SolDato dato : listaDato) {
						if (dato.getSolDatoPK().getCodDato().equals("MONTOUSD")) {
							montoE = capital.add(interes).add(comision);
							dato.setDatoNumero(montoE);
							solDatoQLBeanLocal.edit(dato);
						}
					}
					
					for (SolDato dato : listaDato) {
						if (dato.getSolDatoPK().getCodDato().equals("MONTOHIPCIIMAS")) {
							if (liquidacion.getMonSigade().equals("XP2")) {
								montoE = capital.add(interes).add(comision);
								dato.setDatoNumero(montoE);
								solDatoQLBeanLocal.edit(dato);
							} else {
								Map<String, Object> montoConvertido = vencimientoQLBeanLocal.conversion(dato.getDatoNumero(), "76",
										"69", liquidacion.getFechaTc(), "69", BigDecimal.ZERO);
						
								montoE = (BigDecimal) montoConvertido.get("montobs");
								BigDecimal tipoCambio = coinQLBeanLocal.getTC(liquidacion.getFechaTc(), "76");
								BigDecimal monto = (montoE.subtract(monDiff)).divide(tipoCambio, 2, RoundingMode.HALF_UP);
								dato.setDatoNumero(monto);
								solDatoQLBeanLocal.edit(dato);
							}
						}
					}
				}
			}
		/***********************************************/
		
		BigDecimal monDebe = BigDecimal.ZERO;
		BigDecimal monHaber = BigDecimal.ZERO;
		BigDecimal monto = BigDecimal.ZERO;

		for (SolDato dato : listaDato) {
			if (dato.getDatoNumero() != null && dato.getDatoNumero().compareTo(BigDecimal.ZERO) != 0) {

				if (!StringUtils.isBlank(dato.getCveDh())) {

					monto = dato.getDatoNumero().multiply(dato.getTipoCambio()).setScale(2, BigDecimal.ROUND_HALF_UP);

					logger.info(dato.getSolDatoPK().getCodDato() + " ==> [" + dato.getCveDh() + "] " + dato.getDatoNumero() + " (Mon. "
							+ dato.getCodMoneda() + ") tc: " + dato.getTipoCambio() + " Cta. " + dato.getCuentaMov() + " Monto MN = " + monto);

					if (dato.getCveDh().equals("D")) {
						monDebe = monDebe.add(monto);
					} else if (dato.getCveDh().equals("H")) {
						monHaber = monHaber.add(monto);
					}
				}

			}
		}
		
		if (vencimiento.getCveEstado().equals("A") || vencimiento.getCveEstado().equals("S") ){
			// se cambia el estado a S: Liq con solcitud guardada
			vencimiento = vencimientoQLBeanLocal.actualizarLiquidacion(vencimiento, "", "S", "T");			
		}

		logger.info("Total Debe: " + monDebe + " Haber: " + monHaber + " Dif. " + monDebe.subtract(monHaber));

		/************ registro en motor contable *******************************************/
		/*
		 * Map<String, Object> mapaResult = new HashMap<String, Object>();
		 * mapaResult = comprobanteBeanLocal.generarOperacionContable(solicitud,
		 * "SIODEX", solicitud.getUsrCodigo(), solicitud.getEstacion());
		 * 
		 * Integer comprobID = (Integer) mapaResult.get("comprobID");
		 * logger.info("comprobID: " + comprobID); solicitud.setCveEstado("O");
		 * solicitud.setComprobId(comprobID);
		 * solicitudQLBeanLocal.edit(solicitud);
		 */
	}

	public void generarOperacionEnMotor(Vencimiento vencimiento, Date fechaValor) throws DataException {

		Solicitud solicitud = solicitudQLBeanLocal.getSolicitudByCodLiq(vencimiento.getLiqCodigo(), "P");

		if (solicitud == null) {
			throw new DataException("Liquidacion " + vencimiento.getLiqCodigo()
					+ " no tiene operacion-solicitud Creada, guarde los datos para continuar");
		}

		boolean cuentasOpInternas = false;
		solicitud.setUsrCodigo(vencimiento.getUsuario());
		solicitud.setFechaHora(new Date());
		solicitud.setEstacion(vencimiento.getLogAuditoria().getEstacion());

		logger.info("En generarOperacionEnMotor solcitud encontrada: " + solicitud.toString());

		/************ registro en motor contable *******************************************/
		Map<String, Object> mapaResult = new HashMap<String, Object>();
		mapaResult = comprobanteBeanLocal.generarOperacionContable(solicitud, "SIODEX", solicitud.getUsrCodigo(), solicitud.getEstacion());

		Integer comprobID = (Integer) mapaResult.get("comprobID");
		logger.info("comprobID: " + comprobID);
		solicitud.setCveEstado("O");
		solicitud.setComprobId(comprobID);
		solicitudQLBeanLocal.edit(solicitud);

		if(vencimiento.getCantMensSwift() == 0){
			String ctasBidOpInternas = consultasSdxQLBeanLocal.getParametro("CTAS_BID_OP_INTERNAS");

			comprobantes = comprobQLBeanLocal.listaComprobante(solicitud.getSolCodigo());
			String[] ctasMonedas = null;
			if (ctasBidOpInternas != null && !ctasBidOpInternas.isEmpty()) {
				ctasMonedas = ctasBidOpInternas.split(";");
			}

			for (Comprobante comprobante1 : comprobantes) {
				for (String ctasMoneda : ctasMonedas) {
					if(comprobante1.getCuentaMov().equalsIgnoreCase(ctasMoneda.split(":")[0])){
						// Creamos el mensaje para las operaciones 0640 y 0642
						// Verificamos si ya se creo el mensaje
						List<Mensaje> mensajeListaPre = mensajeQLBeanLocal.mensajeByLiqcodigoMonSigade(vencimiento.getLiqCodigo(),
								comprobante1.getMoneda());
						cuentasOpInternas = true;
						if(mensajeListaPre.size() == 0){

							mensajeOpInternas = new Mensaje("", 0, vencimiento.getPtmCodigo(), vencimiento.getTraCodigo(), comprobante1.getMontoMn(),
									"E", "BBS", "DMS1", vencimiento.getCapitalUsd(), vencimiento.getInteresUsd(),
									vencimiento.getComisionUsd(), vencimiento.getFechaTc(), vencimiento.getFechaVenc(), vencimiento.getUsuario(), new Date(), vencimiento.getLogAuditoria().getEstacion());


						}

					}
				}
			}
		}

		// se le envia actualizaLiq = false ya que la liq fue actulizada
		registrarMensajeSwift(vencimiento, fechaValor, false, "E", cuentasOpInternas);

		vencimiento = vencimientoQLBeanLocal.actualizarLiquidacion(vencimiento, "", "O", "T");
		logger.info("==>Fin generarOperacionEnMotor solcitud : " + solicitud.toString());
	}

	private String getValorC(Vencimiento vencimiento, Cuenta cuenta, Cuenta cuentaComis, String campo, String prestamo, Integer tramo, String codLip,
			String codTipoOperac) throws DataException {
		String valor = null;

		if (campo.equals("GLOSA_TRANSFERENCIA")) {
			valor = armarGlosaCta(vencimiento, cuenta, campo);
		} else if (campo.equals("GLOSA_FNDR")) {
			Cuenta cuentaObjDEUI = vencimiento.getCuentaPrestamo("DEUI");
			valor = armarGlosaCta(vencimiento, cuentaObjDEUI, campo);
		} else if (campo.equals("GLOSA_COMISION")) {
			valor = armarGlosaCta(vencimiento, cuentaComis, campo);
		} else if (campo.equals("GLOSA_MDRICUTBS") || campo.equals("GLOSA_MDRICUTUSD")) {
			valor = "ALIVIO MDRI";
			if (!StringUtils.isBlank(codTipoOperac) && codTipoOperac.trim().equals("27")) {
				Cuenta cuentaObjMDRI = cuentaQLBeanLocal.getCuenta(prestamo, tramo, "MDRI", null);
				if (cuentaObjMDRI != null) {
					valor = armarGlosaCta(vencimiento, cuentaObjMDRI, campo);
				}
			}
		} else if (campo.equals("GLOSA_DIFCUTBS")) {
			if (!StringUtils.isBlank(codTipoOperac) && (codTipoOperac.trim().equals("10") || codTipoOperac.trim().equals("12") || codTipoOperac.trim().equals("29"))) {
				Cuenta cuentaObjDIFF = cuentaQLBeanLocal.getCuenta(prestamo, tramo, "DIFF", null);
				if (cuentaObjDIFF != null) {
					valor = armarGlosaCta(vencimiento, cuentaObjDIFF, campo);
				}
			}
		} else if (campo.equals("GLOSA_DIFCUTUSD")) {
			valor = "";
		} else if (campo.equals("BENEFICIARIO")) {
			valor = cuenta.getCtaFactura();
		} else if (campo.equals("NIT")) {
			valor = cuenta.getCtaNit();
		} else if (campo.equals("CONCEPTOSIGMA")) {
			if (codParticipante.equals(Constants.COD_TGN)) {
				String nroCuenta = cuenta.getCtaNumero();
				if (nroCuenta.trim().equals("3987") || nroCuenta.trim().equals("5970")) {
					valor = "NTI";
				} else {
					valor = "DEV";
				}
			}
		} else if (campo.equals("NRODOCSIGMA") && codParticipante.trim().equals(Constants.COD_TGN)) {
			valor = nti;
		}

		return valor;
	}

	private String getValorDef(Vencimiento vencimiento, String def) {
		String valor = "";

		if (def.equals("FVCTO")) {
			valor = DateFormat.getDateInstance().format(vencimiento.getFechaVenc());
		} else if (def.equals("FVALOR")) {
			valor = DateFormat.getDateInstance().format(vencimiento.getFechaTc());
		} else if (def.equals("ACREE")) {
			valor = vencimiento.getAcreedor();
		} else if (def.equals("REFA")) {
			valor = vencimiento.getRefAcre();
		} else if (def.equals("DEUDOR")) {
			valor = vencimiento.getDeudor();
		} else if (def.equals("CAP")) {
			if (vencimiento.getCapitalMO().compareTo(BigDecimal.valueOf(0)) > 0) {
				valor = "CAPITAL " + getValorDef(vencimiento, "MON") + " " + formatearMonto(vencimiento.getCapitalMO());
			} else {
				valor = "";
			}
		} else if (def.equals("INT")) {
			if (vencimiento.getInteresMO().compareTo(BigDecimal.valueOf(0)) > 0) {
				valor = "INTERESES " + getValorDef(vencimiento, "MON") + " " + formatearMonto(vencimiento.getInteresMO());
			} else {
				valor = "";
			}
		} else if (def.equals("COMI")) {
			if (vencimiento.getComisionMO().compareTo(BigDecimal.valueOf(0)) > 0) {
				valor = "COMISIONES " + getValorDef(vencimiento, "MON") + " " + formatearMonto(vencimiento.getComisionMO());
			} else {
				valor = "";
			}
		} else if (def.equals("MON")) {
			// para mostrar en la glosa
			String mSigade = vencimiento.getMoneda();
			if (mSigade.equals("BBS")) {
				mSigade = "BS";
			} else if (mSigade.equals("XP2")) {
				mSigade = "UFV";
			}

			valor = mSigade;

		}

		return valor;
	}

	private String formatearMonto(BigDecimal monto) {
		String montoLiteral0 = String.format("%.2f", monto);
		String pd = ".";
		String psm = ",";
		if (montoLiteral0.indexOf(",") > 0) {
			pd = ",";
			psm = ".";
		}

		String montoLiteral = String.format("%,.2f", monto);

		String mm = montoLiteral.replace(pd.charAt(0), '$');
		String mm0 = mm.replace(psm.charAt(0), '#');

		mm = mm0.replace('$', ',');
		mm0 = mm.replace('#', '.');

		String montoT = mm0;

		return montoT;
	}

	private String armarGlosaCta(Vencimiento vencimiento, Cuenta cuenta, String tipo) throws DataException {
		String glosa = "";
		String nro = "";
		String nombre = "";

		if (tipo.equals("GLOSA_TRANSFERENCIA")) {
			glosa = "CTA. ";
			nro = cuenta.getCtaNumero();
			nombre = cuenta.getCtaNombre();

			glosa = glosa + nro + " " + nombre;

			if (codParticipante.trim().equals(Constants.COD_TGN)) {
				LiquidacionCuentas liquidacionCuentas = liquidacionCuentasQLBeanLocal.getCuenta(vencimiento.getLiqCodigo(), "LOPE");
				if (liquidacionCuentas == null) {
					logger.error("Libreta de operaciones inexistente para " + vencimiento.getLiqCodigo());
					// throw new
					// DataException("Libreta de operaciones inexistente " +
					// vencimiento.getLiqCodigo());

				} else {
					glosa = glosa + " LIB. " + liquidacionCuentas.getValor();
				}

			}
		} else if (tipo.equals("GLOSA_FNDR")) {
			if (vencimiento.getDeudor().equals("FNDR")) {
				glosa = "CTA. ";
				nro = cuenta.getCtaNumero();
				nombre = cuenta.getCtaNombre();
	
				glosa = glosa + nro + " " + nombre;
	
				if (codParticipante.trim().equals(Constants.COD_TGN)) {
					LiquidacionCuentas liquidacionCuentas = liquidacionCuentasQLBeanLocal.getCuenta(vencimiento.getLiqCodigo(), "LOPE");
					if (liquidacionCuentas == null) {
						logger.error("Libreta de operaciones inexistente para " + vencimiento.getLiqCodigo());
						// throw new
						// DataException("Libreta de operaciones inexistente " +
						// vencimiento.getLiqCodigo());
	
					} else {
						glosa = glosa + " LIB. " + liquidacionCuentas.getValor();
					}
	
				}
			}
		} else if (tipo.equals("GLOSA_COMISION")) {
			glosa = "CTA. ";
			nro = cuenta.getCtaNumero();
			nombre = cuenta.getCtaNombre();

			glosa = glosa + nro + " " + nombre;
			if (codParticipante.trim().equals(Constants.COD_TGN)) {
				LiquidacionCuentas liquidacionCuentas = liquidacionCuentasQLBeanLocal.getCuenta(vencimiento.getLiqCodigo(), "LCOM");
				if (liquidacionCuentas == null) {
					logger.error("Libreta de comisiones inexistente para " + vencimiento.getLiqCodigo());
					// throw new
					// DataException("Libreta de operaciones inexistente " +
					// vencimiento.getLiqCodigo());
				} else {
					glosa = glosa + " LIB. " + liquidacionCuentas.getValor();
				}

			}
			glosa = glosa + " REF.: COMISIONES BANCARIAS";

		} else if (tipo.equals("GLOSA_MDRICUTBS") || tipo.equals("GLOSA_DIFCUTBS")) {
			glosa = "LIB. ";
			nro = cuenta.getCtaNumero();
			nombre = cuenta.getCtaNombre();

			glosa = glosa + nro + " " + nombre;

		}

		if (codParticipante.trim().equals("950")) {
			glosa = "";
		}
		logger.info("glosa part. " + codParticipante + " tipo " + tipo + " liq. " + vencimiento.getLiqCodigo() + " " + glosa);
		return glosa;
	}

	/**
	 * registra en base de datos los mensajes swifts actualizaLiq = true si se
	 * crea
	 */
	public List<Mensaje> registrarMensajeSwift(Vencimiento vencimiento, Date fechaValor, boolean actualizaLiq, String tipoCreacion, boolean cuentasOpInternas)
			throws DataException {
		int contarSwifts = 1;
		List<Mensaje> mensajeLista = new ArrayList<Mensaje>();
		
		if (vencimiento.getCantMensSwift() > 0) {
			// Generamos el mesaje swift para operaciones externas
			if (vencimiento.getCveEstado().equals("O") || vencimiento.getCveEstado().equals("C")) {
				logger.info("liquidacion en estado con operacion o contabilizaado " + vencimiento.getLiqCodigo() + " NO SE GENERA SWIFTS");
				;
				;
				mensajeLista = mensajeQLBeanLocal.mensajeByLiqcodigoMonSigade(vencimiento.getLiqCodigo(), null);

			} else {

				List<Liquidacion> monedaMonto = consultasSdxQLBeanLocal.montosPorMonedas(vencimiento.getLiqCodigo());
				
				if (vencimiento.getCodTipoOperacion().equals("22")) {
					monedaMonto = consultasSdxQLBeanLocal.montosPorMonedas(consultasSdxQLBeanLocal.getLiquidacionBID1020(vencimiento.getLiqCodigo()));
				}
				
				for (Liquidacion liquidacion2 : monedaMonto) {

					logger.info("Mens swift liquidacionDet " + liquidacion2.getMonSigade());

					if (liquidacion2.getMonSigade().equals("BBS") || liquidacion2.getMonSigade().equals("XP2")) {
						// no hacemos nadini
						;
						;
					} else {
						logger.info("Mens swift " + liquidacion2.getMonSigade());

						List<Mensaje> mensajeListaPre = mensajeQLBeanLocal.mensajeByLiqcodigoMonSigade(vencimiento.getLiqCodigo(),
								liquidacion2.getMonSigade());

						if (mensajeListaPre.size() == 0) {
							// no existe registro del mensaje

							String cveEstadoMen = "E";
							// es estado es P Preliminar
							if (tipoCreacion.equals("PRELIMINAR")) {
								cveEstadoMen = tipoCreacion;
							}
							
							/***********************************************/
							/* MODIFICACION DIFERENCIAL                    */
							/* XPERTIC   18-03-2016                        */
							if (vencimiento.getCodTipoOperacion().equals("10") || vencimiento.getCodTipoOperacion().equals("12") || vencimiento.getCodTipoOperacion().equals("21")) {
								SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
								BigDecimal capital = BigDecimal.ZERO;
								BigDecimal interes = BigDecimal.ZERO;
								BigDecimal comision = BigDecimal.ZERO;

								if (vencimiento.getCodTipoOperacion().equals("12")) {
									logger.info("**************************************** diff varios tramos: ");
									List <PrestamoInstancia> instancias = prestamoInstanciaQLBeanLocal.listaInstancia(vencimiento.getPtmCodigo(), vencimiento.getTraCodigo(), "EXT");
									for (PrestamoInstancia instancia : instancias) {
										logger.info("**************************************** instancia: " + instancia.getPinPrestamo() + " , " + instancia.getPinTramo());
										Object[] da = deudaBeanLocal.InteresesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(vencimiento.getFechaVenc()), "11");
										if (da != null) {
											capital = capital.add((BigDecimal) da[1]);
											logger.info("**************************************** capital: " + capital);
										}
										da = deudaBeanLocal.InteresesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(vencimiento.getFechaVenc()), "21");
										if (da != null) {
											interes = interes.add((BigDecimal) da[1]);
											logger.info("**************************************** interes: " + interes);
										}
										da = deudaBeanLocal.ComisionesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(vencimiento.getFechaVenc()), "11");
										if (da != null) {
											comision = comision.add((BigDecimal) da[1]);
											logger.info("**************************************** comision: " + comision);
										}
									}
								} else if (vencimiento.getCodTipoOperacion().equals("21")) {
									logger.info("**************************************** ext varios tramos - igualar moneda: ");
									List <PrestamoInstancia> instancias = prestamoInstanciaQLBeanLocal.listaInstancia(vencimiento.getPtmCodigo(), vencimiento.getTraCodigo(), "EXT");
									for (PrestamoInstancia instancia : instancias) {
										logger.info("**************************************** instancia: " + instancia.getPinPrestamo() + " , " + instancia.getPinTramo());
										Object[] da = deudaBeanLocal.InteresesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(vencimiento.getFechaVenc()), "11");
										if (da != null) {
											if (((String) da[2]).equals(liquidacion2.getMonSigade())) {
												capital = capital.add((BigDecimal) da[1]);
												logger.info("**************************************** capital: " + capital);
											}
										}
										da = deudaBeanLocal.InteresesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(vencimiento.getFechaVenc()), "21");
										if (da != null) {
											if (((String) da[2]).equals(liquidacion2.getMonSigade())) {
												interes = interes.add((BigDecimal) da[1]);
												logger.info("**************************************** interes: " + interes);
											}
										}
										da = deudaBeanLocal.ComisionesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(vencimiento.getFechaVenc()), "11");
										if (da != null) {
											if (((String) da[2]).equals(liquidacion2.getMonSigade())) {
												comision = comision.add((BigDecimal) da[1]);
												logger.info("**************************************** comision: " + comision);
											}
										}
									}
								} else {
									Object[] da = deudaBeanLocal.InteresesDms1(vencimiento.getPtmCodigo(), vencimiento.getTraCodigo(), sdf.format(vencimiento.getFechaVenc()), "11");
									if (da != null) {
										capital = (BigDecimal) da[1];
										logger.info("**************************************** swift capital: " + capital);
									}
									da = deudaBeanLocal.InteresesDms1(vencimiento.getPtmCodigo(), vencimiento.getTraCodigo(), sdf.format(vencimiento.getFechaVenc()), "21");
									if (da != null) {
										interes = (BigDecimal) da[1];
										logger.info("**************************************** swift interes: " + interes);
									}
									da = deudaBeanLocal.ComisionesDms1(vencimiento.getPtmCodigo(), vencimiento.getTraCodigo(), sdf.format(vencimiento.getFechaVenc()), "11");
									if (da != null) {
										comision = (BigDecimal) da[1];
										logger.info("**************************************** swift comision: " + comision);
									}
								}
								
								liquidacion2.setCapitalUsd(capital);
								liquidacion2.setInteresUsd(interes);
								liquidacion2.setComisionUsd(comision);
								liquidacion2.setMonto(capital.add(interes).add(comision));
							}
								
							/***********************************************/
								
							Mensaje mensaje = new Mensaje("", 0, vencimiento.getPtmCodigo(), vencimiento.getTraCodigo(), liquidacion2.getMonto(),
									cveEstadoMen, liquidacion2.getMonSigade(), "DMS1", liquidacion2.getCapitalUsd(), liquidacion2.getInteresUsd(),
									liquidacion2.getComisionUsd(), fechaValor, vencimiento.getFechaVenc(), vencimiento.getLogAuditoria()
											.getCodUsuario(), new Date(), vencimiento.getLogAuditoria().getEstacion());

							if (liquidacion2.getMonSigade().equals("KRW") || liquidacion2.getMonSigade().equals("RMY")) {

								Moneda monedaCCC = monedaQLBeanLocal.getMonedaCoin(liquidacion2.getMonSigade());
								Map<String, Object> montoConvertido = vencimientoQLBeanLocal.conversion(liquidacion2.getMonto(),
										monedaCCC.getMonCoin(), "34", vencimiento.getFechaTc(), "69", liquidacion2.getTipoCambio());
								BigDecimal montoSUS = (BigDecimal) montoConvertido.get("montosus");

								mensaje.setMontoMo(montoSUS);
								mensaje.setMonSwift("USD");
							}
							logger.info("XXX: nodedita : ::: " + mensaje.getMonSwift());
							mensaje.setLiqCodigo(vencimiento.getLiqCodigo());

							// no puede ser el detcodigo ya que se agrupa
							String nroSwitLit = String.format("%02d", contarSwifts);
							mensaje.setLiqDetalle(nroSwitLit);
							mensaje.setMenSwift(0);
							mensaje = mensajeQLBeanLocal.registrarMensSwift(mensaje, cveEstadoMen);

							if (cveEstadoMen.equals("E")) {
								// se crea / elabora en base el mensaje
								List<MensajeDatos> mensajeDatosList = mensajeSwiftBeanLocal.crearSwift(vencimiento, mensaje,
										vencimiento.getReferencia(), contarSwifts, mensaje.getPtmCodigo(), mensaje.getTraCodigo(), false);

								mensajeDatosList = mensajeDatosQLBeanLocal.crearMensajeDatos(mensajeDatosList);
							}

							mensajeLista.add(mensaje);
						} else {
							Mensaje mensaje = mensajeListaPre.get(0);
							if (mensaje.getCveEstadoS().equals("E")) {
								// se debe actualizar

								mensaje.setMontoMo(liquidacion2.getMonto());
								mensaje.setCapitalMo(liquidacion2.getCapitalUsd());
								mensaje.setInteresMo(liquidacion2.getInteresUsd());
								mensaje.setComisionMo(liquidacion2.getComisionUsd());
								mensaje.setFechaValor(fechaValor);
								mensaje.setFechaVencimiento(vencimiento.getFechaVenc());
								// mensaje.setUsrCodigo(vencimiento.getLogAuditoria().getCodUsuario());

								if (liquidacion2.getMonSigade().equals("KRW") || liquidacion2.getMonSigade().equals("RMY")) {

									Moneda monedaCCC = monedaQLBeanLocal.getMonedaCoin(liquidacion2.getMonSigade());
									Map<String, Object> montoConvertido = vencimientoQLBeanLocal.conversion(liquidacion2.getMonto(),
											monedaCCC.getMonCoin(), "34", vencimiento.getFechaTc(), "69", liquidacion2.getTipoCambio());
									BigDecimal montoSUS = (BigDecimal) montoConvertido.get("montosus");

									mensaje.setMontoMo(montoSUS);
									mensaje.setMonSwift("USD");
								}

								logger.info("actualizando mensaje swift " + mensaje.toString());
								mensaje = mensajeQLBeanLocal.registrarMensSwift(mensaje, "E");

								List<MensajeDatos> mensajeDatosList = mensajeSwiftBeanLocal.crearSwift(vencimiento, mensaje,
										vencimiento.getReferencia(), 0, mensaje.getPtmCodigo(), mensaje.getTraCodigo(), false);

								mensajeDatosList = mensajeDatosQLBeanLocal.crearMensajeDatos(mensajeDatosList);
							}
							mensajeLista.add(mensaje);
						}
						contarSwifts++;
					}
				}

			}

			if (actualizaLiq) {
				// se actualiza la liquidacion
				vencimiento.setCantMensSwift(mensajeLista.size());
				vencimiento = vencimientoQLBeanLocal.actualizarLiquidacion(vencimiento, "", "", "L");
			}

			logger.info("Fin registro swifts " + vencimiento.getLiqCodigo());
		} else{
			// Generamos el mesaje swift para operaciones internas


			if (vencimiento.getCveEstado().equals("O") || vencimiento.getCveEstado().equals("C")) {
				logger.info("liquidacion en estado con operacion o contabilizaado " + vencimiento.getLiqCodigo() + " NO SE GENERA SWIFTS");
				mensajeLista = mensajeQLBeanLocal.mensajeByLiqcodigoMonSigade(vencimiento.getLiqCodigo(), null);
			} else{
				// Verificamos si existe la cuenta 0640 o la 0642
				if(cuentasOpInternas){
					// Verificamos si existe el mensaje swift

					mensajeOpInternas.setLiqCodigo(vencimiento.getLiqCodigo());

					logger.info("actualizando mensaje swift " + mensajeOpInternas.toString());
					mensajeOpInternas = mensajeQLBeanLocal.registrarMensSwift(mensajeOpInternas, "E");

					List<MensajeDatos> mensajeDatosList = mensajeSwiftBeanLocal.crearSwift(vencimiento, mensajeOpInternas,
							vencimiento.getReferencia(), 0, mensajeOpInternas.getPtmCodigo(), mensajeOpInternas.getTraCodigo(), true);

					mensajeDatosList = mensajeDatosQLBeanLocal.crearMensajeDatos(mensajeDatosList);


				}
			}

		}


		return mensajeLista;
	}

	public String glosaGeneral(Vencimiento vencimiento, String tipoGlosa) {
		String glosa = "";
		if (tipoGlosa.equals("LOCAL")) {
			logger.info("pago local: ");
			glosa = "PAGO PRÉSTAMO " + vencimiento.getAcreedor() + " " + vencimiento.getRefAcre();
		} else {
			logger.info("pago exterior: ");
			glosa = "PAGO A " + vencimiento.getAcreedor() + " PRÉSTAMO " + vencimiento.getRefAcre();
		}
		String parteNTI = "";
		if (codParticipante.trim().equals(Constants.COD_TGN)) {
			parteNTI = " NTI. " + vencimiento.getLiqCodigo();
		}
		glosa = glosa + " VCTO. " + this.getValorDef(vencimiento, "FVCTO") + " POR CUENTA DE " + this.getValorDef(vencimiento, "DEUDOR")
				+ " ," + parteNTI + " VALOR " + this.getValorDef(vencimiento, "FVALOR") + " " + this.getValorDef(vencimiento, "CAP") + " "
				+ this.getValorDef(vencimiento, "INT") + " " + this.getValorDef(vencimiento, "COMI");

		return glosa;
	}

	public static void main(String[] args) {
		int pos = 0;
		int ll = 0;
		int sep = 0;
		BigDecimal monto = new BigDecimal("52365255369.368");
		String valor = monto.toString();
		String montoT = "";

		valor = valor.replace('.', ',');
		pos = valor.indexOf(',');
		if (pos > -1) {
			if (valor.length() > 6) {
				valor = valor.substring(0, pos + 3);
				ll = pos - 1;
				sep = ll - 3;
				if (sep > -1) {
					montoT = valor.substring(0, sep + 1) + "." + valor.substring(sep + 1);
					valor = montoT;
					ll = sep;
					sep = ll - 3;
					if (sep > -1)
						montoT = valor.substring(0, sep + 1) + "." + valor.substring(sep + 1);
				}
			} else {
				montoT = valor;
			}
		}
		System.out.println(montoT);
		String montoLiteral0 = String.format("%.2f", monto);
		String pd = ".";
		String psm = ",";
		if (montoLiteral0.indexOf(",") > 0) {
			pd = ",";
			psm = ".";
		} else
			System.out.println("noooooo");

		String montoLiteral = String.format("%,.2f", monto);

		System.out.println(montoLiteral);
		String mm = montoLiteral.replace(pd.charAt(0), '$');
		String mm0 = mm.replace(psm.charAt(0), '#');
		System.out.println(mm0);
		mm = mm0.replace('$', ',');
		mm0 = mm.replace('#', '.');
		System.out.println(mm0);
	}

}
