package gob.bcb.jee.siodex.QL;

import java.util.List;

import gob.bcb.jee.siodex.entities.Moneda;
import gob.bcb.jee.siodex.exception.DataException;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

@Stateless
@LocalBean
//public class MonedaQLBean extends DaoGeneric<Moneda> implements MonedaQLBeanLocal {
public class MonedaQLBean implements MonedaQLBeanLocal {	
	static final Logger logger = Logger.getLogger(MonedaQLBean.class);

	@PersistenceContext(unitName = "siodex")
	EntityManager em;
	
			
	public MonedaQLBean() {

	}

	public Moneda getMonedaCoin(String monSigade) throws DataException {
		StringBuilder query = new StringBuilder();

		if (StringUtils.isBlank(monSigade)){
			logger.error("Error al consultar monedas parametro de consulta nulo");
			throw new DataException("Error al consultar monedas parametro de consulta nulo");			
		}
		
		if (monSigade.equals("UFV")){
			monSigade = "XP2";
		} else if (monSigade.equals("BS")){
			monSigade = "BBS";
		}
		
		query.append("select l from Moneda l where l.monSigade = :monSigade");
		
		logger.info("Consulta moneda Sigade " + monSigade + " " + query.toString());
		
		Query consulta = em.createQuery(query.toString());
		consulta.setParameter("monSigade", monSigade);
		
		List lista = consulta.getResultList();
		if (lista.size() > 0) {
			return (Moneda) lista.get(0);
		} else {
			logger.error("Error moneda Sigade " + monSigade + " no registrado en tabla monedas SIODEX");
			throw new DataException("Error moneda Sigade " + monSigade + " no registrado en tabla monedas SIODEX");			
		}
	}
	
	public Moneda getMoneda(String monSigade) throws DataException {
		StringBuilder query = new StringBuilder();

		if (StringUtils.isBlank(monSigade)){
			logger.error("Error al consultar monedas parametro de consulta nulo");
			throw new DataException("Error al consultar monedas parametro de consulta nulo");			
		}
		
		query.append("select l from Moneda l where l.monCoin = :monSigade");
		
		logger.info("Consulta moneda monCoin " + monSigade + " " + query.toString());
		
		Query consulta = em.createQuery(query.toString());
		consulta.setParameter("monSigade", monSigade);
		
		List lista = consulta.getResultList();
		if (lista.size() > 0) {
			return (Moneda) lista.get(0);
		} else {
			logger.error("Error moneda Sigade " + monSigade + " no registrado en tabla monedas SIODEX");
			throw new DataException("Error moneda Sigade " + monSigade + " no registrado en tabla monedas SIODEX");			
		}
	}
}
