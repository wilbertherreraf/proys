package gob.bcb.jee.siodex.util;

import java.io.UnsupportedEncodingException;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.xml.security.exceptions.Base64DecodingException;

public class CadenaEncDec {
	static final Logger logger = Logger.getLogger(CadenaEncDec.class);
	/** The encoding used to represent characters as bytes. */
	public static final String ENCODING = "UTF-8";
	private static String characterEncoding = ENCODING;

	public static String encode(Map<String, String> params) {
		String result = "";
		for (Iterator<?> i = params.keySet().iterator(); i.hasNext();) {
			String key = (String) i.next();
			String value = params.get(key);
			result = result + key + "=" + value + "&";
		}
		result = result.substring(0, result.length() - 1);
		// result = Base64.encodeBytes(result.getBytes(), Base64.GZIP |
		// Base64.DONT_BREAK_LINES);
		result = Base64.encodeBytes(result.getBytes(), Base64.DONT_BREAK_LINES);
		// result =
		// org.apache.xml.security.utils.Base64.encode(result.getBytes());
		return result;
	}

	public static Map<String, String> decode(String text) throws Base64DecodingException {
		// byte[] valueDecoded= Base64.decode(bytesEncoded);
		byte[] decoded = Base64.decode(text);
		String params = new String(decoded);
		Map<String, String> map = new LinkedHashMap<String, String>();
		for (String keyValue : params.split(" *& *")) {
			String[] pairs = keyValue.split(" *= *", 2);
			map.put(pairs[0], pairs.length == 1 ? "" : pairs[1]);
		}
		return map;
	}

	public static void main(String[] args) throws Base64DecodingException, UnsupportedEncodingException {
		Map<String, String> map = new LinkedHashMap<String, String>();
		
		
		map = new LinkedHashMap<String, String>();
		String cod = "003826";
		map = new LinkedHashMap<String, String>();
		map.put("cod", cod);
		map.put("tipo", "REPDB");
		System.out.println(cod + " " + CadenaEncDec.encode(map));		
		
		map = new LinkedHashMap<String, String>();
		cod = "003901";
		map = new LinkedHashMap<String, String>();
		map.put("cod", cod);
		map.put("tipo", "REPDB");
		System.out.println(cod + " " + CadenaEncDec.encode(map));		
		
		
		map = new LinkedHashMap<String, String>();
		cod = "003852";
		map = new LinkedHashMap<String, String>();
		map.put("cod", cod);
		map.put("tipo", "REPDB");
		System.out.println(cod + " " + CadenaEncDec.encode(map));		
		map = new LinkedHashMap<String, String>();
		cod = "003770";
		map = new LinkedHashMap<String, String>();
		map.put("cod", cod);
		map.put("tipo", "REPDB");
		System.out.println(cod + " " + CadenaEncDec.encode(map));		
		map = new LinkedHashMap<String, String>();
		cod = "003750";		
		map.put("cod", cod);
		map.put("tipo", "REPDB");
		System.out.println(cod + " " + CadenaEncDec.encode(map));
		map = new LinkedHashMap<String, String>();
		cod = "003738";		
		map.put("cod", cod);
		map.put("tipo", "REPDB");
		System.out.println(cod + " " + CadenaEncDec.encode(map));
		map = new LinkedHashMap<String, String>();
		cod = "003838";		
		map.put("cod", cod);
		map.put("tipo", "REPDB");
		System.out.println(cod + " " + CadenaEncDec.encode(map));
		map = new LinkedHashMap<String, String>();
		cod = "003879";		
		map.put("cod", cod);
		map.put("tipo", "REPDB");
		System.out.println(cod + " " + CadenaEncDec.encode(map));

		map = new LinkedHashMap<String, String>();
		cod = "003855";		
		map.put("cod", cod);
		map.put("tipo", "REPDB");
		System.out.println(cod + " " + CadenaEncDec.encode(map));

		
		// ///////////////////////////////////
		// String bytesEncoded =
		// org.apache.xml.security.utils.Base64.encode("cadenita".getBytes());
		// System.out.println("cad ocultado " + new String(bytesEncoded ));
		//
		// // Decrypt data on other side, by processing encoded data
		// byte[] valueDecoded= Base64.decode(bytesEncoded);
		// System.out.println("sin ocultar " + new String(valueDecoded));
		// //////////////////////////////////

		String s = CadenaEncDec.encode(map);
		System.out.println("Original String: " + s);
		System.out.println("Decode String: " + CadenaEncDec.decode(s));

		// String f = "http://192.168.1.28:8080/bcb-siodex-web/pages/ven.jsf";
		// System.out.println(f.lastIndexOf("bcb-siodex-web"));
		// String cad = f.substring(0, f.lastIndexOf("bcb-siodex-web") +
		// "bcb-siodex-web".length());
		// System.out.println(cad');

		// String orig = "k1=wetr&";
		//
		// //encoding byte array into base 64
		// //byte[] encoded = Base64.encode(orig.getBytes());
		//
		// String enco = Base64.encode(orig.getBytes());
		// System.out.println("Original String: " + orig );
		// System.out.println("Encoded String: " + enco );
		// byte[] decoded = Base64.decode(enco.getBytes());
		// System.out.println("Base 64 Decoded  String : " + new
		// String(decoded));
		// //System.out.println("Base64 Encoded String : " + new
		// String(encoded));
		//
		// decoding byte array into base64
		// byte[] decoded = Base64.decodeBase64(encoded);
		// System.out.println("Base 64 Decoded  String : " + new
		// String(decoded));

	}
}
