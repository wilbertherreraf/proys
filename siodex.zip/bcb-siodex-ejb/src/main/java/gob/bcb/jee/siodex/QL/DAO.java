package gob.bcb.jee.siodex.QL;

import java.util.List;

import javax.persistence.EntityManager;

public interface DAO<T> {

	public void create(T entity);

	public void edit(T entity);

	public void remove(T entity);

	public T find(Object id);

	public List<T> findAll();

	public List<T> findRange(int[] range);

	public int count();

	public EntityManager getEntityManager();

	public void setEntityManager(EntityManager entityManager);

	public void commit() throws Exception;

//	public UserTransaction getUserTransaction();
//
//	public void setUserTransaction(UserTransaction userTransaction);

}