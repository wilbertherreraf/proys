package gob.bcb.jee.siodex.commons;

import gob.bcb.jee.siodex.util.UtilsProperties;

import java.io.File;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;

public class ConfigurationServ {
	private static String serviceName;
	static final Logger log = Logger.getLogger(ConfigurationServ.class);

	private static final String name = "configsiodex.properties";
	private static Properties config;
	private static String home;
	private static Map<String, String> paramsSystem = new ConcurrentHashMap<String, String>();
	private static boolean configInitialized = false;

	public static void init() {
		if (!configInitialized) {

			log.info("Inicializando objetos de configuracin ConfigurationServ");
			Locale locale = new Locale("en","EN");
			ResourceBundle resource = ResourceBundle.getBundle("service",locale);
			
			//Properties properties = UtilsProperties.loadFilePropertiesFromClass("service.properties");
			String pathHome = resource.getString("path.home");; //properties.getProperty("path.home");

			if (pathHome == null) {
				throw new RuntimeException("Parametro [path.home] requerido no esta definido en service.properties");
			}
			log.info("Path de directorio de configuracion " + pathHome);

			ConfigurationServ.setHomeProperty(pathHome);

			if (!isConfigured()){
				throw new RuntimeException("Archivo de parametrización " + ConfigurationServ.getConfigurationHome() + "/" + name + " inexistente");
			}
			log.info("Archivo de configuracion seteado " + ConfigurationServ.getConfigurationHome() + "/" + name);
			
			config = UtilsProperties.loadFileMsgProperties(ConfigurationServ.getConfigurationHome() + "/" + name);

			configInitialized = true;
			log.info("Inicializado objetos de configuracin ConfigurationServ ... hecho");
		}
	}

	public static boolean isConfigured() {
		if (home == null)
			return false;
		log.info("Config filename: " + name);
		File config = new File(home, name);
		return config.exists();
	}

	public static String getConfigurationHome() {
		return home;
	}

	public static Properties getConfig() {
		return config;
	}

	public boolean isConfigInitialized() {
		return configInitialized;
	}

	public static void setHomeProperty(String home) {
		if (home == null) {
			throw new IllegalStateException("Valor de variable HOME nulo");
		}

		File h = new File(home);
		if (h.exists() && !h.isDirectory()) {
			throw new IllegalStateException(home + " no es un directorio");
		} else if (!h.exists()) {
			throw new RuntimeException(home + " no existe directorio");
		}
		log.info("Configuration.home seteado a " + home);
		ConfigurationServ.home = home;
	}

	public static String getConfigProperty(String claveProp) {
		String propResult = null;

		propResult = getConfig().getProperty(claveProp);
		return propResult;
	}

	public static void setServiceName(String serviceName) {
		ConfigurationServ.serviceName = serviceName;
	}

	public static String getServiceName() {
		return serviceName;
	}

	public static void setParamsSystem(String key, String value) {
		if (ConfigurationServ.paramsSystem == null)
			ConfigurationServ.paramsSystem = new ConcurrentHashMap<String, String>();
		getParamsSystem().put(key, value);
	}

	public static Map<String, String> getParamsSystem() {
		return paramsSystem;
	}

}
