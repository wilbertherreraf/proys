/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author CUriona
 */
@Entity
@Table(name = "liquidacion_estado")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "LiquidacionEstado.findAll", query = "SELECT l FROM LiquidacionEstado l"),
    @NamedQuery(name = "LiquidacionEstado.findByLiqCodigo", query = "SELECT l FROM LiquidacionEstado l WHERE l.liquidacionEstadoPK.liqCodigo = :liqCodigo"),
    @NamedQuery(name = "LiquidacionEstado.findByCveEstado", query = "SELECT l FROM LiquidacionEstado l WHERE l.liquidacionEstadoPK.cveEstado = :cveEstado"),
    @NamedQuery(name = "LiquidacionEstado.findByObservacion", query = "SELECT l FROM LiquidacionEstado l WHERE l.observacion = :observacion"),
    @NamedQuery(name = "LiquidacionEstado.findByUsuario", query = "SELECT l FROM LiquidacionEstado l WHERE l.usuario = :usuario"),
    @NamedQuery(name = "LiquidacionEstado.findByFechaHora", query = "SELECT l FROM LiquidacionEstado l WHERE l.fechaHora = :fechaHora")})
public class LiquidacionEstado implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected LiquidacionEstadoPK liquidacionEstadoPK;
    @NotNull
    @Column(name = "log_auditoria_id", nullable = false)
    private int logAuditoriaId;
    @Column(name = "observacion")
    private String observacion;
    @NotNull
    @Column(name = "usuario")
    private String usuario;
    @NotNull
    @Column(name = "fecha_hora", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaHora;
    @JoinColumn(name = "liq_codigo", referencedColumnName = "liq_codigo", nullable = false, insertable = false, updatable = false)
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Liquidacion liquidacion;

    public LiquidacionEstado() {
    }

    public LiquidacionEstado(LiquidacionEstadoPK liquidacionEstadoPK) {
        this.liquidacionEstadoPK = liquidacionEstadoPK;
    }

    public LiquidacionEstado(LiquidacionEstadoPK liquidacionEstadoPK, Integer logAuditoriaId, String usuario, Date fechaHora) {
        this.liquidacionEstadoPK = liquidacionEstadoPK;
        this.logAuditoriaId = logAuditoriaId;
        this.usuario = usuario;
        this.fechaHora = fechaHora;
    }

    public LiquidacionEstado(LiquidacionEstadoPK liquidacionEstadoPK, Integer logAuditoriaId, String observacion, String usuario, Date fechaHora) {
        this.liquidacionEstadoPK = liquidacionEstadoPK;
        this.logAuditoriaId = logAuditoriaId;
        this.observacion = observacion;
        this.usuario = usuario;
        this.fechaHora = fechaHora;
    }
    
    public LiquidacionEstado(String opeCodigo, String cveEstado) {
        this.liquidacionEstadoPK = new LiquidacionEstadoPK(opeCodigo, cveEstado);
    }

    public LiquidacionEstadoPK getLiquidacionEstadoPK() {
        return liquidacionEstadoPK;
    }

    public void setLiquidacionEstadoPK(LiquidacionEstadoPK liquidacionEstadoPK) {
        this.liquidacionEstadoPK = liquidacionEstadoPK;
    }

    public String getObservacion() {
        return observacion;
    }

    public void setObservacion(String observacion) {
        this.observacion = observacion;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public Date getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(Date fechaHora) {
        this.fechaHora = fechaHora;
    }
    
    public int getLogAuditoriaId() {
		return logAuditoriaId;
	}

	public void setLogAuditoriaId(int logAuditoriaId) {
		this.logAuditoriaId = logAuditoriaId;
	}

	public Liquidacion getLiquidacion() {
        return liquidacion;
    }

    public void setLiquidacion(Liquidacion liquidacion) {
        this.liquidacion = liquidacion;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (liquidacionEstadoPK != null ? liquidacionEstadoPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof LiquidacionEstado)) {
            return false;
        }
        LiquidacionEstado other = (LiquidacionEstado) object;
        if ((this.liquidacionEstadoPK == null && other.liquidacionEstadoPK != null) || (this.liquidacionEstadoPK != null && !this.liquidacionEstadoPK.equals(other.liquidacionEstadoPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gob.bcb.siodex.entities.LiquidacionEstado[ liquidacionEstadoPK=" + liquidacionEstadoPK + " ]";
    }
    
}
