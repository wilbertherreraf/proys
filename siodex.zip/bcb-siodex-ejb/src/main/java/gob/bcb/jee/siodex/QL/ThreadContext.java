package gob.bcb.jee.siodex.QL;

import org.apache.log4j.Logger;

public class ThreadContext {
	static final Logger logger = Logger.getLogger(ThreadContext.class);	
	private String userId;
	private Long transactionId;

	private static ThreadLocal threadLocal = new ThreadLocal() {
		protected ThreadContext initialValue() {
			logger.info("En initialValue()");
			return new ThreadContext();
		}

	};

	public static ThreadContext get()  {
		logger.info("ThreadContext get()");
		if (threadLocal.get() == null){
			logger.error("Cannot find proxy: set 'exposeProxy' property on Advised to make it available");
			return null;
		}
		return (ThreadContext) threadLocal.get();
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}

	public String toString() {
		return "userId:" + userId + ",transactionId:" + transactionId;
	}
}
