package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the clave_valor database table.
 * 
 */
@Embeddable
public class ClaveValorPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="cve_codigo")
	private String cveCodigo;

	@Column(name="cvv_codigo")
	private String cvvCodigo;

    public ClaveValorPK() {
    }
	public String getCveCodigo() {
		return this.cveCodigo;
	}
	public void setCveCodigo(String cveCodigo) {
		this.cveCodigo = cveCodigo;
	}
	public String getCvvCodigo() {
		return this.cvvCodigo;
	}
	public void setCvvCodigo(String cvvCodigo) {
		this.cvvCodigo = cvvCodigo;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof ClaveValorPK)) {
			return false;
		}
		ClaveValorPK castOther = (ClaveValorPK)other;
		return 
			this.cveCodigo.equals(castOther.cveCodigo)
			&& this.cvvCodigo.equals(castOther.cvvCodigo);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.cveCodigo.hashCode();
		hash = hash * prime + this.cvvCodigo.hashCode();
		
		return hash;
    }
}