package gob.bcb.jee.siodex.WS;

import gob.bcb.core.commons.XmlUtils;
import gob.bcb.jee.siodex.exception.XMLException;
import gob.bcb.jee.siodex.util.XMLTools;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

public class RespuestaTGN {
	static final Logger logger = Logger.getLogger(RespuestaTGN.class);	
	private String codError;
	private String descError;
	private Document document;
	
	public void procesar(String mensajeXML) throws XMLException{
		//document = XMLTools.stringXMLToDocument(mensajeXML);
		try {
			document = XmlUtils.getDomFromString(mensajeXML);
		} catch (ParserConfigurationException e) {
			logger.error("Error al recuperar mensaje XML: " + e.getMessage(), e);
			throw new XMLException("Error al recuperar mensaje XML: " + e.getMessage());
		} catch (SAXException e) {
			logger.error("Error al recuperar mensaje XML: " + e.getMessage(), e);
			throw new XMLException("Error al recuperar mensaje XML: " + e.getMessage());
		} catch (IOException e) {
			logger.error("Error al recuperar mensaje XML: " + e.getMessage(), e);
			throw new XMLException("Error al recuperar mensaje XML: " + e.getMessage());
		}
		codError = XMLTools.getXMLTagValue(mensajeXML, "error");		
		descError = XMLTools.getXMLTagValue(mensajeXML, "desError");
	}
	
	public String getCodError() {
		return codError;
	}
	public void setCodError(String codError) {
		this.codError = codError;
	}
	public String getDescError() {
		return descError;
	}
	public void setDescError(String descError) {
		this.descError = descError;
	}

	public Document getDocument() {
		return document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}

	@Override
	public String toString() {
		return "RespuestaTGN [codError=" + codError + ", descError=" + descError + ", document=" + document + "]";
	}
	
}
