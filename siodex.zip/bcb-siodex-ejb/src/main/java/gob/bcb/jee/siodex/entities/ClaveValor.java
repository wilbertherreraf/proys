package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the clave_valor database table.
 * 
 */
@Entity
@Table(name="clave_valor")
public class ClaveValor implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private ClaveValorPK id;

	@Column(name="cve_vigente")
	private short cveVigente;

	@Column(name="cvv_nombre")
	private String cvvNombre;

	@Column(name="cvv_tipo")
	private String cvvTipo;

	private String estacion;

	@Column(name="fecha_hora")
	private Timestamp fechaHora;

	@Column(name="usr_codigo")
	private String usrCodigo;

	//uni-directional many-to-one association to Clave
    @ManyToOne
	@JoinColumn(name="cve_codigo", nullable=false, insertable=false, updatable=false)
	private Clave clave;

    public ClaveValor() {
    }

	public ClaveValorPK getId() {
		return this.id;
	}

	public void setId(ClaveValorPK id) {
		this.id = id;
	}
	
	public short getCveVigente() {
		return this.cveVigente;
	}

	public void setCveVigente(short cveVigente) {
		this.cveVigente = cveVigente;
	}

	public String getCvvNombre() {
		return this.cvvNombre;
	}

	public void setCvvNombre(String cvvNombre) {
		this.cvvNombre = cvvNombre;
	}

	public String getCvvTipo() {
		return this.cvvTipo;
	}

	public void setCvvTipo(String cvvTipo) {
		this.cvvTipo = cvvTipo;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Timestamp getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Timestamp fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getUsrCodigo() {
		return this.usrCodigo;
	}

	public void setUsrCodigo(String usrCodigo) {
		this.usrCodigo = usrCodigo;
	}

	public Clave getClave() {
		return this.clave;
	}

	public void setClave(Clave clave) {
		this.clave = clave;
	}
	
}