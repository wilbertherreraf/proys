package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.exception.DataException;
import gob.bcb.jee.siodex.util.UtilsDate;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

@Stateless
@LocalBean
public class CoinQLBean implements CoinQLBeanLocal {

	static final Logger logger = Logger.getLogger(CoinQLBean.class);

	@PersistenceContext(unitName = "coin")
	EntityManager em;

	/**
	 * Default constructor.
	 */
	public CoinQLBean() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Método que permite obtener un registro de una consulta a una tabla del
	 * COIN.
	 */
	@Override
	public Object[] nativo(String query) {

		Object[] datos = null;

		try {
			logger.info("Consulta nativa en Contbcb: " + query);
			datos = (Object[]) em.createNativeQuery(query).getSingleResult();
		} catch (Exception e) {
			logger.error("error al ejecutar consulta nativa: " + e.getMessage(), e);
		}

		return datos;

	}

	/**
	 * Método que permite obtener un dato numérico de una consulta a una tabla
	 * del COIN.
	 */
	public BigDecimal nativoSimple(String query) {

		BigDecimal datos = BigDecimal.valueOf(0.00);

		try {
			logger.info("query a ejecutar: " + query);
			datos = (BigDecimal) em.createNativeQuery(query).getSingleResult();
		} catch (Exception e) {
			logger.error("error al ejecutar consulta nativa: " + e.getMessage(), e);
		}

		return datos;

	}

	public BigDecimal getTC(Date fecha, String mon) throws DataException {
		if (fecha == null) {
			throw new DataException("Error al obetener Tipo cambio Parametro fecha nulo; moneda:" + mon + "]");
		}
		Calendar fechaAl = GregorianCalendar.getInstance();
		fechaAl.setTime(fecha);
		String strFecha = " mdy(" + (fechaAl.get(Calendar.MONTH) + 1) + "," + fechaAl.get(Calendar.DAY_OF_MONTH) + "," + fechaAl.get(Calendar.YEAR)
				+ ") ";

		String consulta = "";
		BigDecimal tc = BigDecimal.valueOf(0.00);

		consulta = "select factor " + "from factor_conv_mn " + "where cod_moneda = '" + mon + "' " + "and fecha_dia = " + strFecha + " ";

		StringBuilder query = new StringBuilder();
		query.append(consulta);

		try {

			BigDecimal cc = (BigDecimal) em.createNativeQuery(consulta).getSingleResult();
			
			if (cc != null && cc.compareTo(BigDecimal.ZERO) > 0) {
				tc = cc;
			} else {
				logger.error("Tipo de cambio inexistente [fecha:" + fecha + ", moneda:" + mon + "]");
				throw new DataException("Tipo de cambio inexistente [fecha:" + UtilsDate.stringFromDate(fecha, "dd/MM/yyyy") + ", moneda:" + mon
						+ "]");
			}
		} catch (javax.persistence.NoResultException e) {
			throw new DataException("Tipo de cambio inexistente [fecha:" + UtilsDate.stringFromDate(fecha, "dd/MM/yyyy") + ", moneda:" + mon + "]");
		} catch (Exception e) {
			throw new DataException("Tipo de cambio inexistente [fecha:" + UtilsDate.stringFromDate(fecha, "dd/MM/yyyy") + ", moneda:" + mon + "]");
		}

		return tc.setScale(7, BigDecimal.ROUND_HALF_UP);
	}

	public Object[] getMovimiento(String afectable) throws DataException {
		String query = "select cod_movimiento, cod_moneda " + "from cuenta_afectable " + "where nro_afectable = '" + afectable + "' ";

		Object[] datos = nativo(query);

		if (datos == null) {
			logger.error("Cuenta afectable inexistente en contbcb para :" + afectable);
			throw new DataException("Cuenta afectable inexistente en contbcb para :" + afectable);
		}

		return datos;
	}

	public Map<String, Object> cuentaAfectable(String afectable) throws DataException {
		Map<String, Object> result = new HashMap<String, Object>();
		
		String jSql = "select cod_movimiento, cod_moneda " + "from cuenta_afectable " + "where nro_afectable = '" + afectable + "' ";
		try {
			Query query = em.createNativeQuery(jSql);
			logger.info(jSql);
			List<Object[]> resultado = query.getResultList();
			if (resultado.size() > 0) {
				for (Object[] item : resultado) {
					String cod_movimiento = (String) item[0];
					result.put("cod_movimiento", cod_movimiento);
					String cod_moneda = (String) item[1];
					result.put("cod_moneda", cod_moneda);					
				}
			}
		} catch (Exception e) {
			StringBuilder sb = new StringBuilder();
			int count = 0;
			for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
				if (cause instanceof SQLException) {
					count++;
					sb.append(cause.getMessage());
					sb.append(" , ");
				}
			}
			logger.error("Error al ejecutar consulta " + e.getMessage(), e);
			throw new DataException((count > 0 ? sb.toString().replace(", null ,", "") : e.getMessage().replace(", null ,", "")));
		}
		return result;
	}

	public Object[] getCuentaMovimiento(String cuenta) throws DataException {
		Object[] datos = null;

		StringBuilder query = new StringBuilder();
		query.append("");
		query.append(" SELECT ");
		query.append(" cod_movimiento, ");
		query.append(" nom_movimiento ");
		query.append(" FROM cuenta_movimiento ");
		query.append(" WHERE cod_movimiento = '" + cuenta + "'");

		datos = nativo(query.toString());
		if (datos == null) {
			logger.error("Cuenta de movimiento inexistente para :" + cuenta);
			throw new DataException("Cuenta de movimiento inexistente para :" + cuenta);
		}

		return datos;

	}

	@Override
	public Object[] getCuentaDatos(String cuenta) throws DataException {
		Object[] datos = null;

		StringBuilder query = new StringBuilder();
		query.append("");
		query.append(" SELECT ");
		query.append(" mt.cod_mayor, ");
		query.append(" mt.cod_tipo_cuenta, ");
		query.append(" ca.cod_movimiento ");
		query.append(" FROM cuenta_afectable ca ");
		query.append(" INNER JOIN cuenta_movimiento cm ");
		query.append(" ON ca.cod_movimiento = cm.cod_movimiento ");
		query.append(" INNER JOIN d_conta.mayor_tipo mt ");
		query.append(" ON mt.cod_tipo_cuenta = cm.cod_tipo_cuenta ");
		query.append(" WHERE cm.cod_movimiento = '" + cuenta + "'");

		datos = nativo(query.toString());
		if (datos == null) {
			logger.error("Cuenta de movimiento inexistente para :" + cuenta);
			throw new DataException("Cuenta de movimiento inexistente para :" + cuenta);
		}

		return datos;
	}


}
