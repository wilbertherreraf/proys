/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author CUriona
 */
@Entity
@Table(name = "DEBT_SERV_OPERS")
@XmlRootElement

public class DebtServOpers implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@NotNull
	@Column(name = "dso_id", nullable = false)
	private Integer dsoId;

	@Size(min = 1, max = 15)
	@Column(name = "lo_no", nullable = false, length = 15)
	private String loNo;

	@Column(name = "tra_no", nullable = false)
	private int traNo;

	@Column(name = "d_cred_val")
	@Temporal(TemporalType.DATE)
	private Date dCredVal;

	@Column(name = "cg_trns_typ", nullable = false)
	private int cgTrnsTyp;

	@Column(name = "cd_trns_typ", nullable = false, length = 10)
	private String cdTrnsTyp;

	@Column(name = "dso_idp", nullable = false)
	private int dsoIdp;

	@Column(name = "d_sch")
	@Temporal(TemporalType.DATE)
	private Date dSch;

	@Column(name = "d_dbr_val")
	@Temporal(TemporalType.DATE)
	private Date dDbrVal;

	@Column(name = "cu_eff", nullable = false, length = 3)
	private String cuEff;

	@Column(name = "amt_cu_eff", precision = 21, scale = 3)
	private BigDecimal amtCuEff;

	@Column(name = "amt_cu_local", precision = 21, scale = 3)
	private BigDecimal amtCuLocal;

	@Column(name = "amt_cu_base", precision = 21, scale = 3)
	private BigDecimal amtCuBase;

	@Column(name = "amt_sch", precision = 21, scale = 3)
	private BigDecimal amtSch;

	@Column(name = "amt_cu_sdr", precision = 21, scale = 3)
	private BigDecimal amtCuSdr;

	@Column(name = "amt_cu_usd", precision = 21, scale = 3)
	private BigDecimal amtCusd;

	@Column(name = "d_local_exch_rte")
	@Temporal(TemporalType.DATE)
	private Date dLocalExchRte;

	@Column(name = "cg_medium", nullable = false)
	private int cgMedium;

	@Column(name = "cd_medium", nullable = false, length = 10)
	private String cdMedium;

	@Column(name = "cu_exch_pool", length = 3)
	private String cuExchPool;

	@Column(name = "ref", length = 20)
	private String ref;

	@Column(name = "remarks", length = 240)
	private String remarks;

	@Column(name = "sdsp_id")
	private Integer sdspId;

	@Column(name = "pmt_ord_no", nullable = false, length = 10)
	private String pmtOrdNo;

	@Column(name = "bup_id")
	private Integer bupId;

	@Column(name = "baup_id")
	private Integer baupId;

	@Column(name = "d_entry")
	@Temporal(TemporalType.DATE)
	private Date dEntry;

	@Column(name = "bla_no", length = 20)
	private String blaNo;

	@Column(name = "pod_id")
	private Integer podId;

	@Column(name = "amt_cu_eur", precision = 21, scale = 3)
	private BigDecimal amtCuEur;

	@Column(name = "amt_cu_ca", precision = 21, scale = 3)
	private BigDecimal amtCuCa;

	@Column(name = "amt_cu_lo", precision = 21, scale = 3)
	private BigDecimal amtCuLo;

	@Column(name = "cg_payment_status", nullable = false)
	private int cgPaymentStatus;

	@Column(name = "cd_payment_status", nullable = false, length = 10)
	private String cdPaymentStatus;

	public DebtServOpers()
	{
		super();
	}

	public DebtServOpers(Integer dsoId) {
		this.dsoId = dsoId;
	}

	public Integer getDsoId() {
		return dsoId;
	}

	public void setDsoId(Integer dsoId) {
		this.dsoId = dsoId;
	}

	public String getLoNo() {
		return loNo;
	}

	public void setLoNo(String loNo) {
		this.loNo = loNo;
	}

	public int getTraNo() {
		return traNo;
	}

	public void setTraNo(int traNo) {
		this.traNo = traNo;
	}

	public Date getdCredVal() {
		return dCredVal;
	}

	public void setdCredVal(Date dCredVal) {
		this.dCredVal = dCredVal;
	}

	public int getCgTrnsTyp() {
		return cgTrnsTyp;
	}

	public void setCgTrnsTyp(int cgTrnsTyp) {
		this.cgTrnsTyp = cgTrnsTyp;
	}

	public String getCdTrnsTyp() {
		return cdTrnsTyp;
	}

	public void setCdTrnsTyp(String cdTrnsTyp) {
		this.cdTrnsTyp = cdTrnsTyp;
	}

	public int getDsoIdp() {
		return dsoIdp;
	}

	public void setDsoIdp(int dsoIdp) {
		this.dsoIdp = dsoIdp;
	}

	public Date getdSch() {
		return dSch;
	}

	public void setdSch(Date dSch) {
		this.dSch = dSch;
	}

	public Date getdDbrVal() {
		return dDbrVal;
	}

	public void setdDbrVal(Date dDbrVal) {
		this.dDbrVal = dDbrVal;
	}

	public String getCuEff() {
		return cuEff;
	}

	public void setCuEff(String cuEff) {
		this.cuEff = cuEff;
	}

	public BigDecimal getAmtCuEff() {
		return amtCuEff;
	}

	public void setAmtCuEff(BigDecimal amtCuEff) {
		this.amtCuEff = amtCuEff;
	}

	public BigDecimal getAmtCuLocal() {
		return amtCuLocal;
	}

	public void setAmtCuLocal(BigDecimal amtCuLocal) {
		this.amtCuLocal = amtCuLocal;
	}

	public BigDecimal getAmtCuBase() {
		return amtCuBase;
	}

	public void setAmtCuBase(BigDecimal amtCuBase) {
		this.amtCuBase = amtCuBase;
	}

	public BigDecimal getAmtSch() {
		return amtSch;
	}

	public void setAmtSch(BigDecimal amtSch) {
		this.amtSch = amtSch;
	}

	public BigDecimal getAmtCuSdr() {
		return amtCuSdr;
	}

	public void setAmtCuSdr(BigDecimal amtCuSdr) {
		this.amtCuSdr = amtCuSdr;
	}

	public BigDecimal getAmtCusd() {
		return amtCusd;
	}

	public void setAmtCusd(BigDecimal amtCusd) {
		this.amtCusd = amtCusd;
	}

	public Date getdLocalExchRte() {
		return dLocalExchRte;
	}

	public void setdLocalExchRte(Date dLocalExchRte) {
		this.dLocalExchRte = dLocalExchRte;
	}

	public int getCgMedium() {
		return cgMedium;
	}

	public void setCgMedium(int cgMedium) {
		this.cgMedium = cgMedium;
	}

	public String getCdMedium() {
		return cdMedium;
	}

	public void setCdMedium(String cdMedium) {
		this.cdMedium = cdMedium;
	}

	public String getCuExchPool() {
		return cuExchPool;
	}

	public void setCuExchPool(String cuExchPool) {
		this.cuExchPool = cuExchPool;
	}

	public String getRef() {
		return ref;
	}

	public void setRef(String ref) {
		this.ref = ref;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Integer getSdspId() {
		return sdspId;
	}

	public void setSdspId(Integer sdspId) {
		this.sdspId = sdspId;
	}

	public String getPmtOrdNo() {
		return pmtOrdNo;
	}

	public void setPmtOrdNo(String pmtOrdNo) {
		this.pmtOrdNo = pmtOrdNo;
	}

	public Integer getBupId() {
		return bupId;
	}

	public void setBupId(Integer bupId) {
		this.bupId = bupId;
	}

	public Integer getBaupId() {
		return baupId;
	}

	public void setBaupId(Integer baupId) {
		this.baupId = baupId;
	}

	public Date getdEntry() {
		return dEntry;
	}

	public void setdEntry(Date dEntry) {
		this.dEntry = dEntry;
	}

	public String getBlaNo() {
		return blaNo;
	}

	public void setBlaNo(String blaNo) {
		this.blaNo = blaNo;
	}

	public Integer getPodId() {
		return podId;
	}

	public void setPodId(Integer podId) {
		this.podId = podId;
	}

	public BigDecimal getAmtCuEur() {
		return amtCuEur;
	}

	public void setAmtCuEur(BigDecimal amtCuEur) {
		this.amtCuEur = amtCuEur;
	}

	public BigDecimal getAmtCuCa() {
		return amtCuCa;
	}

	public void setAmtCuCa(BigDecimal amtCuCa) {
		this.amtCuCa = amtCuCa;
	}

	public BigDecimal getAmtCuLo() {
		return amtCuLo;
	}

	public void setAmtCuLo(BigDecimal amtCuLo) {
		this.amtCuLo = amtCuLo;
	}

	public int getCgPaymentStatus() {
		return cgPaymentStatus;
	}

	public void setCgPaymentStatus(int cgPaymentStatus) {
		this.cgPaymentStatus = cgPaymentStatus;
	}

	public String getCdPaymentStatus() {
		return cdPaymentStatus;
	}

	public void setCdPaymentStatus(String cdPaymentStatus) {
		this.cdPaymentStatus = cdPaymentStatus;
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (dsoId != null ? dsoId.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		// TODO: Warning - this method won't work in the case the id fields are not set
		if (!(object instanceof DebtServOpers)) {
			return false;
		}
		DebtServOpers other = (DebtServOpers) object;
		if ((this.dsoId == null && other.dsoId != null) || (this.dsoId != null && !this.dsoId.equals(other.dsoId))) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "gob.bcb.siodex.entities.DebtServOpers[ dsoId=" + dsoId + " ]";
	}

}
