package gob.bcb.jee.siodex.entities;

import java.math.BigDecimal;
import java.sql.Blob;
import java.util.Date;

/**
 *
 * @author CUriona
 */

@SuppressWarnings("serial")
public class Comprobante implements java.io.Serializable {
    private Integer solCodigo;
    private String solRenglon;
    private String cuentaMov;
    private String nombreMov;
    private String moneda;
    private String debeHaber;
    private BigDecimal tipoCambio;
    private BigDecimal montoMo;
    private BigDecimal montoMn;
    private String glosa;
    
    public Comprobante() {
    }

	public Comprobante(Integer solCodigo, String solRenglon, String cuentaMov,
			String nombreMov, String moneda, String debeHaber,
			BigDecimal tipoCambio, BigDecimal montoMo, BigDecimal montoMn,
			String glosa) {
		super();
		this.solCodigo = solCodigo;
		this.solRenglon = solRenglon;
		this.cuentaMov = cuentaMov;
		this.nombreMov = nombreMov;
		this.moneda = moneda;
		this.debeHaber = debeHaber;
		this.tipoCambio = tipoCambio;
		this.montoMo = montoMo;
		this.montoMn = montoMn;
		this.glosa = glosa;
	}

	public Integer getSolCodigo() {
		return solCodigo;
	}

	public void setSolCodigo(Integer solCodigo) {
		this.solCodigo = solCodigo;
	}

	public String getSolRenglon() {
		return solRenglon;
	}

	public void setSolRenglon(String solRenglon) {
		this.solRenglon = solRenglon;
	}

	public String getCuentaMov() {
		return cuentaMov;
	}

	public void setCuentaMov(String cuentaMov) {
		this.cuentaMov = cuentaMov;
	}

	public String getNombreMov() {
		return nombreMov;
	}

	public void setNombreMov(String nombreMov) {
		this.nombreMov = nombreMov;
	}

	public String getMoneda() {
		return moneda;
	}

	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	public String getDebeHaber() {
		return debeHaber;
	}

	public void setDebeHaber(String debeHaber) {
		this.debeHaber = debeHaber;
	}

	public BigDecimal getTipoCambio() {
		return tipoCambio;
	}

	public void setTipoCambio(BigDecimal tipoCambio) {
		this.tipoCambio = tipoCambio;
	}

	public BigDecimal getMontoMo() {
		return montoMo;
	}

	public void setMontoMo(BigDecimal montoMo) {
		this.montoMo = montoMo;
	}

	public BigDecimal getMontoMn() {
		return montoMn;
	}

	public void setMontoMn(BigDecimal montoMn) {
		this.montoMn = montoMn;
	}

	public String getGlosa() {
		return glosa;
	}

	public void setGlosa(String glosa) {
		this.glosa = glosa;
	}

	@Override
	public String toString() {
		return "Comprobante [solCodigo=" + solCodigo + ", solRenglon=" + solRenglon + ", cuentaMov=" + cuentaMov + ", nombreMov=" + nombreMov
				+ ", moneda=" + moneda + ", debeHaber=" + debeHaber + ", tipoCambio=" + tipoCambio + ", montoMo=" + montoMo + ", montoMn=" + montoMn
				+ ", glosa=" + glosa + "]";
	}

}
