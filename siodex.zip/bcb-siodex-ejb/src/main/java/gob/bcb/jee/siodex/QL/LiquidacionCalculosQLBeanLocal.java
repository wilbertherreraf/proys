package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.Liquidacion;
import gob.bcb.jee.siodex.entities.SolDato;
import gob.bcb.jee.siodex.entities.Vencimiento;
import gob.bcb.jee.siodex.exception.DataException;

import java.math.BigDecimal;
import java.util.Map;

import javax.ejb.Local;

@Local
public interface LiquidacionCalculosQLBeanLocal {

	SolDato calculoConceptoMonto(Vencimiento vencimiento, Liquidacion liquidacion, String campo, String codMensaje, String codMonedaSIGADE)
			throws DataException;

}