package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the liquidacion_pago database table.
 * 
 */
@Entity
@Table(name="liquidacion_pago")
public class LiquidacionPago implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private LiquidacionPagoPK id;

	@Column(name="cod_moneda")
	private String codMoneda;

	@Column(name="cve_tipodetpago")
	private String cveTipodetpago;

	private String estacion;

	@Temporal(TemporalType.DATE)
	@Column(name="fecha_cont")
	private Date fechaCont;

    @Temporal(TemporalType.TIMESTAMP)
	@Column(name="fecha_hora")
	private Date fechaHora;

    @Temporal(TemporalType.DATE)
	@Column(name="fecha_reg")
	private Date fechaReg;

	@Column(name="usr_codigo")
	private String usrCodigo;

	@Column(name="valor")
	private BigDecimal valor;

    public LiquidacionPago() {
    }

	public LiquidacionPagoPK getId() {
		return this.id;
	}

	public void setId(LiquidacionPagoPK id) {
		this.id = id;
	}
	
	public String getCodMoneda() {
		return this.codMoneda;
	}

	public void setCodMoneda(String codMoneda) {
		this.codMoneda = codMoneda;
	}

	public String getCveTipodetpago() {
		return this.cveTipodetpago;
	}

	public void setCveTipodetpago(String cveTipodetpago) {
		this.cveTipodetpago = cveTipodetpago;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaCont() {
		return this.fechaCont;
	}

	public void setFechaCont(Date fechaCont) {
		this.fechaCont = fechaCont;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public Date getFechaReg() {
		return this.fechaReg;
	}

	public void setFechaReg(Date fechaReg) {
		this.fechaReg = fechaReg;
	}

	public String getUsrCodigo() {
		return this.usrCodigo;
	}

	public void setUsrCodigo(String usrCodigo) {
		this.usrCodigo = usrCodigo;
	}

	public BigDecimal getValor() {
		return this.valor;
	}

	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}

}