/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-web-seguridad
 * gob.bcb.web.seguridad.common.Email
 * 06/12/2011 - 15:53:22
 * Creado por Gustavo Flores
 */
package gob.bcb.jee.siodex.mail;

import gob.bcb.jee.siodex.entities.Cuenta;
import gob.bcb.jee.siodex.entities.Vencimiento;

import java.util.Map;

import org.apache.log4j.Logger;

/**
 * 
 * @author Gustavo Flores
 */
public class Email {

	static final Logger logger = Logger.getLogger(Email.class);

	public String armarMensaje(String tipo, String prestamo, Map<String, Object> params, String flagError, String errorWS) {
		StringBuffer mensaje = new StringBuffer();
		if (tipo.equals("VENCOBSERVADO")) {
			Vencimiento vencimiento = (Vencimiento) params.get("vencimiento");

			mensaje.append("Se ha recibido un mensaje de Liquidación Observada para el préstamo:").append("\r\n");
			mensaje.append("----------------------------------------").append("\r\n");
			mensaje.append("Cod Prestamo y Tramo: " + vencimiento.getPtmCodigo() + " [" + vencimiento.getTraCodigo() + "]").append("\r\n");
			mensaje.append("Liquidacion: " + vencimiento.getLiqCodigo()).append("\r\n");
			mensaje.append("Deudor: " + vencimiento.getVcDatosAdic().getSiglaProv() + " " + vencimiento.getVcDatosAdic().getProveedor()).append(
					"\r\n");
			mensaje.append("Acreedor: " + vencimiento.getAcreedor()).append("\r\n");
			mensaje.append("Préstamo: " + vencimiento.getRefAcre()).append("\r\n");
			mensaje.append("Observacion: " + vencimiento.getObservacion() + " \r\n");

		} else if (tipo.equals("LIQRECHAZADA")) {
			Vencimiento vencimiento = (Vencimiento) params.get("vencimiento");

			mensaje.append("Se ha recibido un mensaje de Liquidacion Rechazada para el pr&eacute;stamo:").append("\r\n");
			mensaje.append("----------------------------------------").append("\r\n");
			mensaje.append("Cod Prestamo y Tramo: " + vencimiento.getPtmCodigo() + " [" + vencimiento.getTraCodigo() + "]").append("\r\n");
			mensaje.append("Liquidacion: " + vencimiento.getLiqCodigo()).append("\r\n");
			mensaje.append("Deudor: " + vencimiento.getVcDatosAdic().getSiglaProv() + " " + vencimiento.getVcDatosAdic().getProveedor()).append(
					"\r\n");
			mensaje.append("Acreedor: " + vencimiento.getAcreedor()).append("\r\n");
			mensaje.append("Préstamo: " + vencimiento.getRefAcre()).append("\r\n");
			mensaje.append("Observacion: " + vencimiento.getObservacion()).append("\r\n");

		} else if (tipo.equals("PAGOAUTORIZADO")) {
			Vencimiento vencimiento = (Vencimiento) params.get("vencimiento");

			mensaje.append("Se ha realizado una operacion de Autorización de Pago por parte del Deudor para el préstamo:").append("\r\n");
			mensaje.append("----------------------------------------").append("\r\n");
			mensaje.append("Cod Prestamo y Tramo: " + vencimiento.getPtmCodigo() + " [" + vencimiento.getTraCodigo() + "]").append("\r\n");
			mensaje.append("Liquidacion: " + vencimiento.getLiqCodigo()).append("\r\n");
			mensaje.append("Deudor: " + vencimiento.getVcDatosAdic().getSiglaProv() + " " + vencimiento.getVcDatosAdic().getProveedor()).append(
					"\r\n");
			mensaje.append("Acreedor: " + vencimiento.getAcreedor()).append("\r\n");
			mensaje.append("Préstamo: " + vencimiento.getRefAcre()).append("\r\n");
			Cuenta cuentaS = vencimiento.getCuentaPrestamo("DEUD");			
			if (cuentaS != null){
				mensaje.append("Nro Cuenta: " + cuentaS.getCtaNumero()).append("\r\n");
				mensaje.append("Nombre Cta: " + cuentaS.getCtaNombre()).append("\r\n");			
			}
			mensaje.append("Cobro Servicio de Deuda: " + vencimiento.getTotal() + " [" + vencimiento.getMonedaContDesc() + "]").append("\r\n");

		} else if (tipo.equals("LIQCONTABILIZADA")) {
			Vencimiento vencimiento = (Vencimiento) params.get("vencimiento");

			mensaje.append("Se ha realizado una operacion de Registro Contable por parte del BCB para el préstamo:").append("\r\n");
			mensaje.append("----------------------------------------").append("\r\n");
			mensaje.append("Cod Prestamo y Tramo: " + vencimiento.getPtmCodigo() + " [" + vencimiento.getTraCodigo() + "]").append("\r\n");
			mensaje.append("Liquidacion: " + vencimiento.getLiqCodigo()).append("\r\n");
			mensaje.append("Deudor: " + vencimiento.getVcDatosAdic().getSiglaProv() + " " + vencimiento.getVcDatosAdic().getProveedor()).append(
					"\r\n");
			mensaje.append("Acreedor: " + vencimiento.getAcreedor()).append("\r\n");
			mensaje.append("Préstamo: " + vencimiento.getRefAcre()).append("\r\n");
			mensaje.append("Cobro Servicio de Deuda: " + vencimiento.getTotal() + " [" + vencimiento.getMonedaContDesc() + "]").append("\r\n");
			mensaje.append("Comisiones Bancarias: " + vencimiento.totalComisionBancaria()).append(" [BS]\r\n");
			mensaje.append("Cuenta Servicio: " + vencimiento.getCuentaPrestamo("DEUD").getCtaNumero() + " ").append("\r\n");
			mensaje.append("Cuenta Comision: " + vencimiento.getCuentaPrestamo("DEUC").getCtaNumero() + " ").append("\r\n");
			mensaje.append("Tipo de cambio: " + vencimiento.getTipoCambioCont() ).append("\r\n");
			//rmq
			if(flagError.equals("-1")){
				mensaje.append("----------------------------------------\r\n");
				mensaje.append("Observación. Se realizó el Registro Contable, pero ocurrió un\r\n");
				mensaje.append("error al enviar la confirmación al Servidor Web del TGN. \r\n");
				mensaje.append("Por favor comuníquese con el administrador del BCB\r\n");
				
				mensaje.append("Error: "+errorWS+"\r\n");
				mensaje.append("----------------------------------------\r\n");
			}
			//-----

		}
		
		
		mensaje.append("----------------------------------------\r\n");
		mensaje.append("Nota. Mensaje generado automáticamente por el sistema SIODEX.\r\n");
		return mensaje.toString();
	}
}
