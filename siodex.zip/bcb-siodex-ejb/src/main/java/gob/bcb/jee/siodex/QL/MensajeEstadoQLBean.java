package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.MensajeEstado;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;


@Stateless
@LocalBean
public class MensajeEstadoQLBean extends DaoGeneric<MensajeEstado> implements MensajeEstadoQLBeanLocal {

	static final Logger logger = Logger.getLogger(MensajeEstadoQLBean.class);

	@PersistenceContext(unitName = "siodex")
	EntityManager em;

	/**
	 * Default constructor.
	 */
	public MensajeEstadoQLBean() {
		// TODO Auto-generated constructor stub
		super(MensajeEstado.class);
	}

	/**
	 * Método que permite obtener el registro de un estado de una liquidación.
	 */
	public MensajeEstado getMenEstado(String codigo, String estado) {

		MensajeEstado menEstado = null;

			StringBuilder query = new StringBuilder();

			query.append("select m from MensajeEstado m where m.mensajeEstadoPK.menCodigo = ? and m.mensajeEstadoPK.cveEstado = ?");

			Query consulta = em.createQuery(query.toString());
			consulta.setParameter(1, codigo);
			consulta.setParameter(2, estado);

			menEstado = (MensajeEstado) consulta.getSingleResult();

		List lista = consulta.getResultList();
		if (lista.size() > 0) {
			return (MensajeEstado) lista.get(0);
		}


		return menEstado;

	}

	@Override
	public void setEntityManager(EntityManager entityManager) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public EntityManager getEntityManager() {
		// TODO Auto-generated method stub
		return em;
	}

}
