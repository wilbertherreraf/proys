package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.ClaveValor;
import gob.bcb.jee.siodex.entities.ClaveValorPK;
import gob.bcb.jee.siodex.entities.Liquidacion;
import gob.bcb.jee.siodex.entities.Moneda;
import gob.bcb.jee.siodex.exception.DataException;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

@Stateless
@LocalBean
public class ConsultasSdxQLBean implements ConsultasSdxQLBeanLocal {
	static final Logger logger = Logger.getLogger(ConsultasSdxQLBean.class);
	@PersistenceContext(unitName = "siodex")
	EntityManager em;

	@Inject
	private LiquidacionQLBeanLocal liquidacionQLBeanLocal;
	@Inject
	private MonedaQLBeanLocal monedaQLBeanLocal;

	public String getParametro(String param) {
		String valor = "";
		String pp = "";

		String query = " select par_valor " + "from	parametro " + "where par_codigo = '" + param + "'";

		String da = this.QueryNativoSimple(query);
		if (da != null) {
			pp = da;
		}

		valor = pp;

		return valor;
	}

	public String tipoOperacionPrestamo(String prestamo, Integer tramo) {
		String oper = "";

		String query = "select top_codigo " + "from	prestamo " + "where ptm_codigo = '" + prestamo + "' " + "and tra_codigo = " + tramo;
		logger.info("query a ejecutar: " + query);
		String da = this.QueryNativoSimple(query);
		if (da != null) {
			oper = da;
		}

		return oper;
	}

	public String getCodigoLip(String proc, String cuenta) throws DataException {
		String lip = "";

		String query = "select p.codlip " + "from proceso_esquema p, cuenta c " + "where p.cve_tipo_cta = c.cve_tipo_cta " + "and p.pro_codigo = '"
				+ proc + "' " + "and c.cta_codigo = '" + cuenta + "' ";
		logger.info("query a ejecutar: " + query);
		String da = this.QueryNativoSimple(query);

		if (StringUtils.isBlank(da)) {
			throw new DataException("Codigo de proceso lip no parametrizado en proceso_esquema para cuenta " + cuenta);
		}

		lip = da;

		return lip;
	}

	private String QueryNativoSimple(String consulta) {

		String cc = null;

		StringBuilder query = new StringBuilder();
		query.append(consulta);

		try {
			//logger.info("query a ejecutar: " + query);
			cc = (String) em.createNativeQuery(query.toString()).getSingleResult();
		} catch (Exception e) {
			logger.error("error en : QueryNativoSimple " + e.getMessage(), e);
		}
		//logger.info("resultado: " + (cc == null ? "NULL" : cc.toString()));

		return cc;

	}

	public String descripcionClave(String clave, String valorClave) {
		String oper = "";

		String query = "select cvv_nombre from clave_valor  where cve_codigo = '" + clave + "' " + " and cvv_codigo = '" + valorClave + "'";

		String da = this.QueryNativoSimple(query);
		if (StringUtils.isBlank(da)) {
			oper = "";
		} else {
			oper = da;
		}

		return oper;
	}

	public String getLiquidacionBID1020(String liqCodigo) throws DataException {
		String codigo = "";

		String query = "select l.liq_codigo " + "from liquidacion l " + "where l.ptm_codigo = '950002' " 
				+ "and l.tra_codigo = 3 and l.cve_estado <> 'Z' ";
		logger.info("query a ejecutar: " + query);
		String da = this.QueryNativoSimple(query);

		if (StringUtils.isBlank(da)) {
			throw new DataException("No existe liquidaciones generadas para las monedas");
		}

		codigo = da;

		return codigo;
	}
	
	public List<Liquidacion> montosPorMonedas(String liqCodigo) throws DataException {
		List<Liquidacion> liquidacionLista = new ArrayList<Liquidacion>();
		// para verificar quye haya un tipo de cambio por moneda
		Map<String, BigDecimal> ctrlMonedas = new HashMap<String, BigDecimal>();

		// si es moneda SDR se trabaja con los los montos de USD de liquidacion
		boolean isSDR = false;

		StringBuilder jsql = new StringBuilder();
		jsql.append("select ld.mon_sigade, ");
		jsql.append("ld.tipo_cambio, ");
		jsql.append("sum(ld.capital_mo ) sum_cap, ");
		jsql.append("sum(ld.interes_mo ) sum_int, ");
		jsql.append("sum(ld.comision_mo ) sum_com, ");
		jsql.append("sum(ld.capital_mo + ld.interes_mo + ld.comision_mo) ");
		jsql.append("from liquidacion_det ld ");
		jsql.append(" where ld.liq_codigo = '" + liqCodigo + "' ");
		jsql.append(" group by 1, 2 ");

		logger.info("montosPorMonedas " + liqCodigo + " " + jsql.toString());

		Query query = em.createNativeQuery(jsql.toString());
		List phones = query.getResultList();
		Iterator it = phones.iterator();

		try {

			while (it.hasNext()) {
				Object[] result = (Object[]) it.next();
				String mon_sigade = (String) result[0];
				BigDecimal tc = (BigDecimal) result[1];
				BigDecimal cap = (BigDecimal) result[2];
				BigDecimal inte = (BigDecimal) result[3];
				BigDecimal com = (BigDecimal) result[4];
				BigDecimal monto = (BigDecimal) result[5];

				Liquidacion liquidacion = new Liquidacion();
				liquidacion.setMonSigade(mon_sigade);
				liquidacion.setCapitalUsd(cap);
				liquidacion.setInteresUsd(inte);
				liquidacion.setComisionUsd(com);
				liquidacion.setMonto(monto);
				liquidacion.setTipoCambio(tc);

				if (!ctrlMonedas.containsKey(mon_sigade)) {
					ctrlMonedas.put(mon_sigade, tc);
				} else {
					logger.error("Tipo de cambio moneda " + mon_sigade + " con diferentes valores, verifique los tipos de cambio.");
					throw new DataException("Tipo de cambio moneda " + mon_sigade + " con diferentes valores, verifique los tipos de cambio.");
				}

				Moneda monedaC = monedaQLBeanLocal.getMonedaCoin(mon_sigade);
				// moneda contable 
				liquidacion.setCodMoneda(monedaC.getMonCoin());
				if (mon_sigade.trim().equals("KRW") || mon_sigade.trim().equals("RMY")) {
					// yuanes o koreanos
					liquidacion.setCodMoneda("34");
				}
				liquidacionLista.add(liquidacion);
			}
		} catch (Exception e) {
			logger.error("Error al sumar monedas: " + e.getMessage());
			throw new DataException("Error al sumar monedas: " + e.getMessage());
		}

		isSDR = ctrlMonedas.containsKey("SDR");

		if (isSDR && liquidacionLista.size() > 1) {
			logger.error("moneda SDR mezclada con otras monedas, la liquidacion debe ser solo de monedas SDR.");
			throw new DataException("moneda SDR mezclada con otras monedas, la liquidacion debe ser solo de monedas SDR.");
		}

		if (isSDR) {
			logger.info("MONEDA SDR " + liqCodigo + " recuperamos totales de liquidacion");
			liquidacionLista.clear();
			Liquidacion liq = liquidacionQLBeanLocal.getLiquidacion(liqCodigo);

			Liquidacion liquidacion = new Liquidacion();
			liquidacion.setMonSigade("USD");
			liquidacion.setCapitalUsd(liq.getCapitalUsd());
			liquidacion.setInteresUsd(liq.getInteresUsd());
			liquidacion.setComisionUsd(liq.getComisionUsd());

			BigDecimal totalUsd = liq.getCapitalUsd().add(liq.getInteresUsd().add(liq.getComisionUsd()));
			liquidacion.setMonto(totalUsd);

			liquidacion.setTipoCambio(BigDecimal.ONE);
			liquidacion.setCodMoneda("34");

			liquidacionLista.add(liquidacion);
		}

		logger.info("Ressultado montosPorMonedas " + liqCodigo + " " + ArrayUtils.toString(liquidacionLista));
		return liquidacionLista;
	}

	public List<Liquidacion> montosPorMonedasDiff(String liqCodigo) throws DataException {
		List<Liquidacion> liquidacionLista = new ArrayList<Liquidacion>();
		// para verificar quye haya un tipo de cambio por moneda
		Map<String, BigDecimal> ctrlMonedas = new HashMap<String, BigDecimal>();

		StringBuilder jsql = new StringBuilder();
		jsql.append("select ld.mon_sigade, ");
		jsql.append("ld.tipo_cambio, ");
		jsql.append("sum(ld.capital_mo ) sum_cap, ");
		jsql.append("sum(ld.interes_mo ) sum_int, ");
		jsql.append("sum(ld.comision_mo ) sum_com, ");
		jsql.append("sum(ld.capital_mo + ld.interes_mo + ld.comision_mo) ");
		jsql.append("from liquidacion_det ld ");
		jsql.append(" where ld.liq_codigo = '" + liqCodigo + "' ");
		jsql.append(" and ld.pin_prestamo not like 'D%' ");
		jsql.append(" group by 1, 2 ");

		logger.info("montosPorMonedas " + liqCodigo + " " + jsql.toString());

		Query query = em.createNativeQuery(jsql.toString());
		List phones = query.getResultList();
		Iterator it = phones.iterator();

		try {

			while (it.hasNext()) {
				Object[] result = (Object[]) it.next();
				String mon_sigade = (String) result[0];
				BigDecimal tc = (BigDecimal) result[1];
				BigDecimal cap = (BigDecimal) result[2];
				BigDecimal inte = (BigDecimal) result[3];
				BigDecimal com = (BigDecimal) result[4];
				BigDecimal monto = (BigDecimal) result[5];

				Liquidacion liquidacion = new Liquidacion();
				liquidacion.setMonSigade(mon_sigade);
				liquidacion.setCapitalUsd(cap);
				liquidacion.setInteresUsd(inte);
				liquidacion.setComisionUsd(com);
				liquidacion.setMonto(monto);
				liquidacion.setTipoCambio(tc);

				if (!ctrlMonedas.containsKey(mon_sigade)) {
					ctrlMonedas.put(mon_sigade, tc);
				} else {
					logger.error("Tipo de cambio moneda " + mon_sigade + " con diferentes valores, verifique los tipos de cambio.");
					throw new DataException("Tipo de cambio moneda " + mon_sigade + " con diferentes valores, verifique los tipos de cambio.");
				}

				Moneda monedaC = monedaQLBeanLocal.getMonedaCoin(mon_sigade);
				// moneda contable 
				liquidacion.setCodMoneda(monedaC.getMonCoin());
				liquidacionLista.add(liquidacion);
			}
		} catch (Exception e) {
			logger.error("Error al sumar monedas: " + e.getMessage());
			throw new DataException("Error al sumar monedas: " + e.getMessage());
		}

		logger.info("Ressultado montosPorMonedas " + liqCodigo + " " + ArrayUtils.toString(liquidacionLista));
		
		return liquidacionLista;
	}
	
	public List<Liquidacion> montosDiff(String liqCodigo) throws DataException {
		List<Liquidacion> liquidacionLista = new ArrayList<Liquidacion>();
		// para verificar quye haya un tipo de cambio por moneda
		Map<String, BigDecimal> ctrlMonedas = new HashMap<String, BigDecimal>();

		StringBuilder jsql = new StringBuilder();
		jsql.append("select ld.mon_sigade, ");
		jsql.append("ld.tipo_cambio, ");
		jsql.append("sum(ld.capital_mo ) sum_cap, ");
		jsql.append("sum(ld.interes_mo ) sum_int, ");
		jsql.append("sum(ld.comision_mo ) sum_com, ");
		jsql.append("sum(ld.capital_mo + ld.interes_mo + ld.comision_mo) ");
		jsql.append("from liquidacion_det ld ");
		jsql.append(" where ld.liq_codigo = '" + liqCodigo + "' ");
		jsql.append(" and ld.pin_prestamo like 'D%' ");
		jsql.append(" group by 1, 2 ");

		logger.info("montosPorMonedas " + liqCodigo + " " + jsql.toString());

		Query query = em.createNativeQuery(jsql.toString());
		List phones = query.getResultList();
		Iterator it = phones.iterator();

		try {

			while (it.hasNext()) {
				Object[] result = (Object[]) it.next();
				String mon_sigade = (String) result[0];
				BigDecimal tc = (BigDecimal) result[1];
				BigDecimal cap = (BigDecimal) result[2];
				BigDecimal inte = (BigDecimal) result[3];
				BigDecimal com = (BigDecimal) result[4];
				BigDecimal monto = (BigDecimal) result[5];

				Liquidacion liquidacion = new Liquidacion();
				liquidacion.setMonSigade(mon_sigade);
				liquidacion.setCapitalUsd(cap);
				liquidacion.setInteresUsd(inte);
				liquidacion.setComisionUsd(com);
				liquidacion.setMonto(monto);
				liquidacion.setTipoCambio(tc);

				if (!ctrlMonedas.containsKey(mon_sigade)) {
					ctrlMonedas.put(mon_sigade, tc);
				} else {
					logger.error("Tipo de cambio moneda " + mon_sigade + " con diferentes valores, verifique los tipos de cambio.");
					throw new DataException("Tipo de cambio moneda " + mon_sigade + " con diferentes valores, verifique los tipos de cambio.");
				}

				Moneda monedaC = monedaQLBeanLocal.getMonedaCoin(mon_sigade);
				// moneda contable 
				liquidacion.setCodMoneda(monedaC.getMonCoin());
				liquidacionLista.add(liquidacion);
			}
		} catch (Exception e) {
			logger.error("Error al sumar monedas: " + e.getMessage());
			throw new DataException("Error al sumar monedas: " + e.getMessage());
		}

		logger.info("Ressultado montosPorMonedas " + liqCodigo + " " + ArrayUtils.toString(liquidacionLista));
		
		return liquidacionLista;
	}
	
	public BigDecimal montoPorMoneda(String liqCodigo, String monedaSIGADE) throws DataException {
		List<Liquidacion> liquidacionLista = montosPorMonedas(liqCodigo);
		BigDecimal monto = BigDecimal.ZERO;
		for (Liquidacion liquidacion : liquidacionLista) {
			if (liquidacion.getMonSigade().equals(monedaSIGADE)) {
				monto = liquidacion.getMonto();
				break;
			}
		}
		return monto;
	}

	public ClaveValor clavesValorByCVVNombre(String cve_codigo, String cvv_nombre) {
		ClaveValor claveValor = null;

		String jSql = "select cve_codigo, cvv_codigo, cvv_nombre, cvv_tipo from clave_valor " + "where cve_codigo = '" + cve_codigo
				+ "' and cve_vigente = 1 and cvv_nombre = '" + cvv_nombre + "'";

		Query query = em.createNativeQuery(jSql.toString());
		List phones = query.getResultList();
		Iterator it = phones.iterator();

		while (it.hasNext()) {

			Object[] result = (Object[]) it.next();
			String cvv_codigo= (String) result[1];
			String cvv_tipo= (String) result[3];
			
			ClaveValorPK claveValorPK = new ClaveValorPK(); 
			claveValorPK.setCveCodigo(cve_codigo);
			claveValorPK.setCvvCodigo(cvv_codigo);

			claveValor = new ClaveValor();
			
			claveValor.setId(claveValorPK);
			claveValor.setCvvNombre(cvv_nombre);
			claveValor.setCvvTipo(cvv_tipo);
			
		}

		return claveValor;
	}

}
