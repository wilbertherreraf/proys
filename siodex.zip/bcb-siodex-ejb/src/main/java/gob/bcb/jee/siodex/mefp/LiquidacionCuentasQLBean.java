package gob.bcb.jee.siodex.mefp;

import java.util.Date;
import java.util.List;

import gob.bcb.jee.siodex.QL.DaoGeneric;

import javax.annotation.PostConstruct;
import javax.ejb.EJBException;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

@Stateless
@LocalBean
public class LiquidacionCuentasQLBean extends DaoGeneric<LiquidacionCuentas> implements LiquidacionCuentasQLBeanLocal {

	static final Logger logger = Logger.getLogger(LiquidacionCuentasQLBean.class);

	@PersistenceContext(unitName = "siodex")
	EntityManager em;

	/**
	 * Default constructor.
	 */
	public LiquidacionCuentasQLBean() {
		super(LiquidacionCuentas.class);
	}

	@PostConstruct
	public void despues() {
		logger.info("XXX:emememememememememem" + (em == null));
		setEntityManager(em);
	}

	/**
	 * Método que permite obtener la lista de cuentas enviadas por el TGN para
	 * el proceso de una operación.
	 */

	@SuppressWarnings("unchecked")
	public List<LiquidacionCuentas> getCuentas(String codigo) {

		List<LiquidacionCuentas> cuentas = null;

		StringBuilder query = new StringBuilder();

		query.append("select c from LiquidacionCuentas c where c.liquidacionCuentasPK.liqCodigo = ?");

		Query consulta = em.createQuery(query.toString());
		consulta.setParameter(1, codigo);

		cuentas = consulta.getResultList();

		return cuentas;

	}

	/**
	 * Método que permite obtener una cuenta específica con la que se procesó
	 * una operación.
	 */

	public LiquidacionCuentas getCuenta(String codigo, String tipo) {

		LiquidacionCuentas cuenta = null;

		StringBuilder query = new StringBuilder();

		query.append("select c from LiquidacionCuentas c where c.liquidacionCuentasPK.liqCodigo = :codigo ");
		query.append("and c.liquidacionCuentasPK.cveCuenta = :tipo");

		logger.info("Consulta Obetniendo Cuenta para [" + codigo + ", " + tipo+ "] " + query.toString());
		Query consulta = em.createQuery(query.toString());
		consulta.setParameter("codigo", codigo);
		consulta.setParameter("tipo", tipo);

		List lista = consulta.getResultList();
		if (lista.size() > 0){
			return (LiquidacionCuentas) lista.get(0);
		}

		return cuenta;

	}
	
	public LiquidacionCuentas actualizar(LiquidacionCuentas liquidacionCuentas) {
		LiquidacionCuentas liquidacionCuentasOld = getCuenta(liquidacionCuentas.getLiquidacionCuentasPK()
				.getLiqCodigo(), liquidacionCuentas.getLiquidacionCuentasPK().getCveCuenta());
		
		if (liquidacionCuentasOld == null) {
			liquidacionCuentas.setFechaHora(new Date());
			create(liquidacionCuentas);

		} else {
			liquidacionCuentasOld.setFechaHora(new Date());
			edit(liquidacionCuentasOld);
		}
		
		liquidacionCuentasOld = getCuenta(liquidacionCuentas.getLiquidacionCuentasPK()
				.getLiqCodigo(), liquidacionCuentas.getLiquidacionCuentasPK().getCveCuenta());
		
		return liquidacionCuentasOld;
	}
	
	@Override
	public void setEntityManager(EntityManager entityManager) {
		// TODO Auto-generated method stub

	}

	@Override
	public EntityManager getEntityManager() {
		return em;
	}
}
