package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.Datos;
import gob.bcb.jee.siodex.entities.MensajeDatos;
import gob.bcb.jee.siodex.entities.MensajeDatosPK;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

@Stateless
@LocalBean
public class MensajeDatosQLBean extends DaoGeneric<MensajeDatos> implements MensajeDatosQLBeanLocal {

	static final Logger logger = Logger.getLogger(MensajeDatosQLBean.class);

	@PersistenceContext(unitName = "siodex")
	EntityManager em;

	/**
	 * Default constructor.
	 */
	public MensajeDatosQLBean() {
		// TODO Auto-generated constructor stub
		super(MensajeDatos.class);
	}

	public List<MensajeDatos> getDatos(String codigo) {

		List<MensajeDatos> datos = null;

		StringBuilder query = new StringBuilder();

		query.append("select d from MensajeDatos d where d.mensajeDatosPK.menCodigo = ?");
		logger.info("Consulta MensajeDatos " + query.toString());

		Query consulta = em.createQuery(query.toString());
		consulta.setParameter(1, codigo);

		datos = (List<MensajeDatos>) consulta.getResultList();

		return datos;

	}

	public List<MensajeDatos> getDatosByBloque(String menCodigo, short camBloque) {

		List<MensajeDatos> datos = null;

		StringBuilder query = new StringBuilder();

		query.append("select d from MensajeDatos d where d.mensajeDatosPK.menCodigo = :menCodigo and d.mensajeDatosPK.camBloque = :camBloque ");
		logger.info("Consulta MensajeDatos [" + menCodigo + ", " + camBloque + "]" + query.toString());

		Query consulta = em.createQuery(query.toString());
		consulta.setParameter("menCodigo", menCodigo);
		consulta.setParameter("camBloque", camBloque);

		datos = (List<MensajeDatos>) consulta.getResultList();

		return datos;
	}

	public MensajeDatos getDato(String codigo, String campo) {

		MensajeDatos dato = null;

		StringBuilder query = new StringBuilder();

		query.append("select d from MensajeDatos d where d.mensajeDatosPK.menCodigo = ? and d.mensajeDatosPK.camCodigo = ?");
		logger.info("Consulta MensajeDatos [" + codigo + ", " + campo + "]" + query.toString());

		Query consulta = em.createQuery(query.toString());
		consulta.setParameter(1, codigo);
		consulta.setParameter(2, campo);

		List lista = consulta.getResultList();
		if (lista.size() > 0) {
			return (MensajeDatos) lista.get(0);
		}

		return dato;

	}

	public List<Datos> getDatosVer(String codigo) {

		List<Datos> datosVer = new ArrayList<Datos>();

		short bloque = 4;

		List<MensajeDatos> datos = getDatosByBloque(codigo, bloque);

		String nombre = "";

		for (MensajeDatos dat : datos) {
			nombre = "";
			
			String qq = " select cam_nombre, cam_bloque  " + " from campos " + " where cam_codigo = '" + dat.getMensajeDatosPK().getCamCodigo()
					+ "' and cam_bloque = " + dat.getMensajeDatosPK().getCamBloque() + " ";
			
			logger.info("Consulta campo: " + qq);
			
			Query query = em.createNativeQuery(qq);
			List lista = query.getResultList();
			Iterator it = lista.iterator();

			while (it.hasNext()) {
				Object[] da = (Object[]) it.next();
				nombre = (String) da[0];
			}

			Datos dd = new Datos(dat.getMensajeDatosPK().getMenCodigo(), dat.getMensajeDatosPK().getCamBloque(), dat.getMensajeDatosPK()
					.getCamCodigo(), dat.getMdtValor(), nombre);

			datosVer.add(dd);
		}

		return datosVer;
	}

	public List<MensajeDatos> crearMensajeDatos(List<MensajeDatos> mensajeDatoslist) {
		
		List<MensajeDatos> mensajeDatosList = new ArrayList<MensajeDatos>();
		
		for (MensajeDatos mensajeDatos : mensajeDatoslist) {
			MensajeDatos mensajeDatosOld = getDato(mensajeDatos.getMensajeDatosPK().getMenCodigo(),mensajeDatos.getMensajeDatosPK().getCamCodigo());
			if (mensajeDatosOld == null){
				create(mensajeDatos);
				mensajeDatosList.add(mensajeDatos);				
				logger.info("Registro creado datos: " + mensajeDatos.toString());
			}else {
				mensajeDatosOld.setMdtValor(mensajeDatos.getMdtValor());
				edit(mensajeDatosOld);
				mensajeDatosList.add(mensajeDatosOld);
				logger.info("Registro creado datos: " + mensajeDatosOld.toString());				
			}
		}

		return mensajeDatosList;
	}


	@Override
	public void setEntityManager(EntityManager entityManager) {
		// TODO Auto-generated method stub

	}

	@Override
	public EntityManager getEntityManager() {
		// TODO Auto-generated method stub
		return em;
	}
}
