/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author CUriona
 */
@Embeddable
public class LiquidacionRengPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 6)
    @Column(name = "liq_codigo", nullable = false, length = 6)
    private String liqCodigo;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2)
    @Column(name = "liq_detalle", nullable = false, length = 2)
    private String liqDetalle;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2)
    @Column(name = "liq_renglon", nullable = false, length = 2)
    private String liqRenglon;

    public LiquidacionRengPK() {
    }

    public LiquidacionRengPK(String liqCodigo, String liqDetalle, String liqRenglon) {
        this.liqCodigo = liqCodigo;
        this.liqDetalle = liqDetalle;
        this.liqRenglon = liqRenglon;
    }

    public String getLiqCodigo() {
        return liqCodigo;
    }

    public void setLiqCodigo(String liqCodigo) {
        this.liqCodigo = liqCodigo;
    }

    public String getLiqDetalle() {
        return liqDetalle;
    }

    public void setLiqDetalle(String liqDetalle) {
        this.liqDetalle = liqDetalle;
    }

    public String getLiqRenglon() {
        return liqRenglon;
    }

    public void setLiqRenglon(String liqRenglon) {
        this.liqRenglon = liqRenglon;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (liqCodigo != null ? liqCodigo.hashCode() : 0);
        hash += (liqDetalle != null ? liqDetalle.hashCode() : 0);
        hash += (liqRenglon != null ? liqRenglon.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof LiquidacionRengPK)) {
            return false;
        }
        LiquidacionRengPK other = (LiquidacionRengPK) object;
        if ((this.liqCodigo == null && other.liqCodigo != null) || (this.liqCodigo != null && !this.liqCodigo.equals(other.liqCodigo))) {
            return false;
        }
        if ((this.liqDetalle == null && other.liqDetalle != null) || (this.liqDetalle != null && !this.liqDetalle.equals(other.liqDetalle))) {
            return false;
        }
        if ((this.liqRenglon == null && other.liqRenglon != null) || (this.liqRenglon != null && !this.liqRenglon.equals(other.liqRenglon))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gob.bcb.siodex.entities.LiquidacionRengPK[ liqCodigo=" + liqCodigo + ", liqDetalle=" + liqDetalle + ", liqRenglon=" + liqRenglon + " ]";
    }
    
}