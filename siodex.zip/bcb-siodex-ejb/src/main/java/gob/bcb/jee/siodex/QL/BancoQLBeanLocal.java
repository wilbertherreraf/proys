package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.exception.DataException;

import javax.ejb.Local;

/**
 * Created by eborda on 16/02/2017.
 */
@Local
public interface BancoQLBeanLocal {

    /**
     *
     * @return
     */


    Object[] nativo(String query);

    Object[] getBanco(String bcoCodigo) throws DataException;
}
