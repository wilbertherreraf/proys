/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 * 
 * @author CUriona
 */
@Entity
@Table(name = "sol_dato")
@XmlRootElement
@NamedQueries({ @NamedQuery(name = "SolDato.findAll", query = "SELECT s FROM SolDato s"),
		@NamedQuery(name = "SolDato.findBySolCodigo", query = "SELECT s FROM SolDato s WHERE s.solDatoPK.solCodigo = :solCodigo"),
		@NamedQuery(name = "SolDato.findByCodDato", query = "SELECT s FROM SolDato s WHERE s.solDatoPK.codDato = :codDato"),
		@NamedQuery(name = "SolDato.findByDatoNumero", query = "SELECT s FROM SolDato s WHERE s.datoNumero = :datoNumero"),
		@NamedQuery(name = "SolDato.findByDatoTexto", query = "SELECT s FROM SolDato s WHERE s.datoTexto = :datoTexto") })
public class SolDato implements Serializable {
	private static final long serialVersionUID = 1L;
	@EmbeddedId
	protected SolDatoPK solDatoPK;
	@Basic(optional = false)
	@NotNull
	@Column(name = "log_auditoria_id", nullable = false)
	private int logAuditoriaId;
	@Column(name = "dato_numero", precision = 16, scale = 2)
	private BigDecimal datoNumero;
	@Column(name = "dato_texto")
	private String datoTexto;
	@Column(name = "cod_moneda")
	private String codMoneda;
	@Column(name = "tipo_cambio")
	private BigDecimal tipoCambio;
	@Column(name = "cve_dh")
	private String cveDh;
	@Column(name = "cuenta_mov")
	private String cuentaMov;
	@Column(name = "orden")
	private Integer orden;
	// @JoinColumn(name = "sol_codigo", referencedColumnName = "sol_codigo",
	// nullable = false, insertable = false, updatable = false)
	// @ManyToOne(optional = false, fetch = FetchType.LAZY)
	// private Solicitud solicitud;

	public SolDato() {
	}

	public SolDato(SolDatoPK solDatoPK) {
		this.solDatoPK = solDatoPK;
	}

	public SolDato(SolDatoPK solDatoPK, Integer logAuditoriaId, BigDecimal datoNumero, String datoTexto) {
		super();
		this.solDatoPK = solDatoPK;
		this.logAuditoriaId = logAuditoriaId;
		this.datoNumero = datoNumero;
		this.datoTexto = datoTexto;
	}

	public SolDato(Integer solCodigo, String codDato) {
		this.solDatoPK = new SolDatoPK(solCodigo, codDato);
	}

	public SolDatoPK getSolDatoPK() {
		return solDatoPK;
	}

	public void setSolDatoPK(SolDatoPK solDatoPK) {
		this.solDatoPK = solDatoPK;
	}

	public BigDecimal getDatoNumero() {
		return datoNumero;
	}

	public void setDatoNumero(BigDecimal datoNumero) {
		this.datoNumero = datoNumero;
	}

	public String getDatoTexto() {
		return datoTexto;
	}

	public void setDatoTexto(String datoTexto) {
		this.datoTexto = datoTexto;
	}

	public int getLogAuditoriaId() {
		return logAuditoriaId;
	}

	public void setLogAuditoriaId(int logAuditoriaId) {
		this.logAuditoriaId = logAuditoriaId;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	// public Solicitud getSolicitud() {
	// return solicitud;
	// }
	//
	// public void setSolicitud(Solicitud solicitud) {
	// this.solicitud = solicitud;
	// }

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (solDatoPK != null ? solDatoPK.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		// TODO: Warning - this method won't work in the case the id fields are
		// not set
		if (!(object instanceof SolDato)) {
			return false;
		}
		SolDato other = (SolDato) object;
		if ((this.solDatoPK == null && other.solDatoPK != null) || (this.solDatoPK != null && !this.solDatoPK.equals(other.solDatoPK))) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "SolDato [solDatoPK=" + solDatoPK + ", logAuditoriaId=" + logAuditoriaId + ", datoNumero=" + datoNumero + ", datoTexto=" + datoTexto
				+ "]";
	}

	public String getCodMoneda() {
		return codMoneda;
	}

	public void setCodMoneda(String codMoneda) {
		this.codMoneda = codMoneda;
	}

	public BigDecimal getTipoCambio() {
		return tipoCambio;
	}

	public void setTipoCambio(BigDecimal tipoCambio) {
		this.tipoCambio = tipoCambio;
	}

	public String getCveDh() {
		return cveDh;
	}

	public void setCveDh(String cveDh) {
		this.cveDh = cveDh;
	}

	public String getCuentaMov() {
		return cuentaMov;
	}

	public void setCuentaMov(String cuentaMov) {
		this.cuentaMov = cuentaMov;
	}

	public Integer getOrden() {
		return orden;
	}

	public void setOrden(Integer orden) {
		this.orden = orden;
	}

}