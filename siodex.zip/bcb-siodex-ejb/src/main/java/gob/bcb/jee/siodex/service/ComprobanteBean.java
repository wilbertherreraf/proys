package gob.bcb.jee.siodex.service;

import gob.bcb.contabilidad.pojo.RastroContablePojo;

import gob.bcb.contabilidad.service.OperacionesContabilidadSrvBeanRemote;
import gob.bcb.contabilidad.util.ContabilidadException;
import gob.bcb.jee.siodex.QL.LiquidacionQLBeanLocal;
import gob.bcb.jee.siodex.QL.SolDatoQLBeanLocal;
import gob.bcb.jee.siodex.QL.SolicitudQLBeanLocal;
import gob.bcb.jee.siodex.QL.VencimientoQLBeanLocal;
import gob.bcb.jee.siodex.entities.Liquidacion;
import gob.bcb.jee.siodex.entities.SolDato;
import gob.bcb.jee.siodex.entities.Solicitud;
import gob.bcb.jee.siodex.entities.Vencimiento;
import gob.bcb.jee.siodex.exception.DataException;
import gob.bcb.jee.siodex.util.Util;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

/**
 * Clase que contiene los metodos para crear los campos de un mensaje swift.
 * 
 * @author C. Cecilia Uriona
 * 
 */
@Stateless
public class ComprobanteBean implements ComprobanteBeanLocal {

	static final Logger logger = Logger.getLogger(ComprobanteBean.class);

	@PersistenceContext(unitName = "siodex")
	EntityManager em;

	@Inject
	private DeudaSigadeBeanLocal deudaSigadeBeanLocal;

	@Inject
	private SolicitudQLBeanLocal solQLBeanLocal;

	@Inject
	private SolDatoQLBeanLocal solDatoQLBeanLocal;

	@Inject
	private Util util;

	@Inject
	private ConsultaBeanLocal consultaBean;
	@Inject
	private LiquidacionQLBeanLocal liquidacionQLBeanLocal;
	@Inject
	private VencimientoQLBeanLocal vencimientoQLBeanLocal;

	public Map<String, Object> contabilizarSolo(Solicitud sol, String usuario, String ip) throws DataException {

		Map<String, Object> mapaResult = new HashMap<String, Object>();
		try {
			logger.info("Creando el comprobante sol.: " + sol.getSolCodigo());
			if (sol == null || sol.getSolCodigo() == null) {
				logger.error("Solicitud con datos nulos, avise al administrador");
				throw new DataException("Solicitud con datos nulos, avise al administrador");
			}

			Solicitud solicitudOld = solQLBeanLocal.getSolicitud(sol.getSolCodigo());
			if (solicitudOld == null) {
				logger.error("Solicitud inexistente " + sol.getSolCodigo());
				throw new DataException("Solicitud inexistente " + sol.getSolCodigo());
			}

			if (StringUtils.isBlank(solicitudOld.getCveEstado()) || !solicitudOld.getCveEstado().trim().equalsIgnoreCase("O")) {
				logger.error("Solicitud con estado [" + solicitudOld.getSolCodigo() + "] invalido");
				throw new DataException("Solicitud con estado [" + solicitudOld.getSolCodigo() + "] invalido");
			}

			Vencimiento vencimiento = vencimientoQLBeanLocal.getVencimiento("", 0, solicitudOld.getLiqCodigo());

			Liquidacion liq = liquidacionQLBeanLocal.getLiquidacion(solicitudOld.getLiqCodigo());

			if (!liq.getCveEstado().equals("O")) {
				// diferente a autorizado
				throw new DataException("liquidacion [" + liq.getLiqCodigo() + "] en estado [" + liq.getCveEstado()
						+ "] incorrecto no puede contabilizarse");
			}

			solicitudOld.setUsrCodigo(usuario);
			solicitudOld.setFechaHora(new Date());
			solicitudOld.setEstacion(ip);

			logger.info("Solicitud a contabilizar " + solicitudOld.toString());

			// obteniendo objeto del servicio
			logger.info("Antes de consultar rastros " + solicitudOld.getSolCodigo());
			RastroContablePojo rastroContablePojo = consultaBean.obtenerRastroContable(solicitudOld.getFecha(), solicitudOld.getComprobId());

			if (rastroContablePojo == null) {
				// la solicitud ya fue registrada
				logger.error("Solicitud " + solicitudOld.getSolCodigo() + " NO fue registrada en el sistema contable");
				throw new RuntimeException("Solicitud " + solicitudOld.getSolCodigo() + " NO fue registrada en el sistema contable");
			}

			logger.info("Antes generarOperacionContable solicitud " + solicitudOld.getSolCodigo());
			// mapaResult = generarOperacionContable(solicitudOld, "SIODEX",
			// usuario, ip);

			Integer comprobID = solicitudOld.getComprobId();

			logger.info("Antes de contabilizar " + solicitudOld.getSolCodigo() + " comprobID: " + comprobID);
			mapaResult = contabilizarEnMotor(comprobID, "SIODEX", usuario, ip);

			solicitudOld.setComprobId(comprobID);

			logger.info("comprobando el registro cntable " + solicitudOld.getSolCodigo());
			rastroContablePojo = consultaBean.obtenerRastroContable(solicitudOld.getFecha(), solicitudOld.getComprobId());

			if (rastroContablePojo == null) {
				// la solicitud ya fue registrada
				logger.error("ERROOOOOOOOR!!! Comprobacion de Solicitud contabilizada " + solicitudOld.getSolCodigo() + " inexistente en motor:"
						+ solicitudOld.getComprobId());
				throw new RuntimeException("ERROR!!! Solicitud " + solicitudOld.getSolCodigo() + " inexistente en motor:"
						+ solicitudOld.getComprobId() + " comunique a sistemas");
			}
			logger.info("==>> DATOS COMPROBANTE: " + rastroContablePojo.toString());

			mapaResult.put("nroComprobCoin", rastroContablePojo.getNroComprobCoin());
			mapaResult.put("comprobId", rastroContablePojo.getComprobId());
			mapaResult.put("nroOperacion", rastroContablePojo.getNroOperacion());

			
			// whf ojooo por ahora no se registra en sigade
			Integer continuar = deudaSigadeBeanLocal.registrarSigade(solicitudOld.getLiqCodigo());

			solQLBeanLocal.cambioEstado(solicitudOld, "", "C");

			liq.setUsrCodigo(usuario);
			liq.setEstacion(ip);
			liq = liquidacionQLBeanLocal.cambioEstado(liq, "NROCOMPROB=" + rastroContablePojo.getNroComprobCoin(), "C");

			//luego de contabilizar debe enviar WS al TGN y despues enviar mail
			/*try {
				vencimientoQLBeanLocal.enviarCorreos(vencimiento, "", "LIQCONTABILIZADA", "WS");
			} catch (Exception e) {
				logger.warn("Error al enviar correos pero la operacion fue cntabilzada " + e.getMessage(), e);
			}
			logger.info("Proceso contabilizacion finalizado : " + comprobID);
			*/
			return mapaResult;
		} catch (ContabilidadException e) {
			logger.error("Error Motor Contable ContabilidadException " + e.getMessage(), e);
			throw new DataException("Error Motor Contable ContabilidadException " + e.getMessage());
		} catch (Exception e) {
			logger.error("Error Motor Contable Exception " + e.getMessage(), e);
			throw new DataException("Error Motor Contable Exception " + e.getMessage());
		} catch (Throwable e) {
			logger.error("Error Motor Contable: se produjo Throwable al Registrar Op. Contable " + e.getMessage(), e);
			throw new DataException("Error Motor Contable: se produjo Throwable al Registrar Op. Contable " + e.getMessage());
		}

	}

	/**
	 * Metodo que permite el registro de una operacion en servicio de
	 * COntabilidad
	 * 
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> generarOperacionContable(Solicitud solicitudOld, String codAplicacion, String codUsuario, String host)
			throws DataException {

		logger.info("Generarndo operacion contable " + solicitudOld.getSolCodigo());
		// ///////////////////////////////////////////////////////////
		Map<String, Object> mapaRequest = new HashMap<String, Object>();

		mapaRequest.put("codOperacion", solicitudOld.getCodLip());
		mapaRequest.put("codParticipanteOrigen", solicitudOld.getCodPart());
		mapaRequest.put("nroCorrelativo", solicitudOld.getSolCodigo().toString());
		mapaRequest.put("glosa", solicitudOld.getGlosa());
		mapaRequest.put("fecha", solicitudOld.getFecha());
		mapaRequest.put("codMonedaOrigen", solicitudOld.getMoneda());
		mapaRequest.put("codParticipanteDestino", solicitudOld.getCodPartDes());
		mapaRequest.put("codMonedaDestino", solicitudOld.getMonedaDes());

		List<SolDato> listaDato = solDatoQLBeanLocal.getDatos(solicitudOld.getSolCodigo());

		for (SolDato dato : listaDato) {
			if (dato.getDatoNumero() != null && dato.getDatoNumero().compareTo(BigDecimal.ZERO) != 0) {
				mapaRequest.put(dato.getSolDatoPK().getCodDato(), dato.getDatoNumero());
			} else {
				if (dato.getDatoTexto() != null) {
					mapaRequest.put(dato.getSolDatoPK().getCodDato(), dato.getDatoTexto());
				}
			}
		}

		Map<String, Object> mapaResult = new HashMap<String, Object>();

		try {
			// obteniendo objeto del servicio
			OperacionesContabilidadSrvBeanRemote operacionesContabilidadSrvBeanRemote = util.consumirEJB(OperacionesContabilidadSrvBeanRemote.class);

			logger.info("Registro Datos Mapa enviados:: " + ArrayUtils.toString(mapaRequest) + " codAplicacion: " + codAplicacion + " codUsuario: "
					+ codUsuario + " host: " + host);

			// llamando al servicio de contabilidad
			// mapa, codAplicacion, codUsiario, host

			// DEVUELVE:
			// comprobID(Integer)
			// tipoContabilidad si se trata de contabilidad en Linea (L) o
			// Asincrona (A)
			// continuar (Integer) codMensaje descMensaje

			mapaResult = operacionesContabilidadSrvBeanRemote.registrarOperacion(mapaRequest, codAplicacion, codUsuario, host);

			if (mapaResult == null) {
				logger.error("registrarOperacion: no devolvió ningun resultado para " + ArrayUtils.toString(mapaRequest));
				throw new Exception("registrarOperacion: no devolvió ningun resultado para " + ArrayUtils.toString(mapaRequest));
			}

			if (mapaResult.size() == 0) {
				logger.error("registrarOperacion: no devolvió ningun resultado para " + ArrayUtils.toString(mapaRequest));
				throw new Exception("ERROR mapa repuesta nula para: " + ArrayUtils.toString(mapaRequest));
			}

			logger.info("Operacion (registrarOperacion) Solicitud ejecutada Respuesta:: " + ArrayUtils.toString(mapaResult));

			if (!mapaResult.containsKey("continuar")) {
				logger.error("registrarOperacion: no devolvió ningun Codigo de resultado para " + ArrayUtils.toString(mapaRequest));
				throw new Exception("ERROR para request: " + ArrayUtils.toString(mapaRequest));
			}

			// si hubo un error al registrar no devuelve un comprobID
			if (!mapaResult.containsKey("comprobID")) {
				logger.error("registrarOperacion: no devolvió comprobID de resultado para " + ArrayUtils.toString(mapaResult));
				throw new Exception("no devolvió comprobID de resultado para " + ArrayUtils.toString(mapaResult));
			}

			Integer continuar = (Integer) mapaResult.get("continuar");
			if (continuar.compareTo(Integer.valueOf(1)) != 0) {
				String codError = (String) mapaResult.get("codMensaje");
				String descError = (String) mapaResult.get("descMensaje");
				logger.error("[" + codError + "] " + descError);
				throw new Exception("[" + codError + "] " + descError);
			}

			return mapaResult;
		} catch (ContabilidadException e) {
			logger.error("Error Motor Contable ContabilidadException " + e.getMessage(), e);
			throw new DataException("Error Motor Contable ContabilidadException " + e.getMessage());
		} catch (Exception e) {
			logger.error("Error Motor Contable Exception " + e.getMessage(), e);
			throw new DataException("Error Motor Contable Exception " + e.getMessage());
		} catch (Throwable e) {
			logger.error("Error Motor Contable: se produjo Throwable al Registrar Op. Contable " + e.getMessage(), e);
			throw new DataException("Error Motor Contable: se produjo Throwable al Registrar Op. Contable " + e.getMessage());
		}

	}

	private Map<String, Object> contabilizarEnMotor(Integer comprobID, String codAplicacion, String codUsuario, String host) throws Exception {
		logger.info("Ingresando a Contabilizar :: " + comprobID);
		Map<String, Object> mapaResult = new HashMap<String, Object>();

		try {
			// obteniendo objeto del servicio
			OperacionesContabilidadSrvBeanRemote operacionesContabilidadSrvBeanRemote = util.consumirEJB(OperacionesContabilidadSrvBeanRemote.class);

			// devuelve continuar, codMensaje ,
			mapaResult = operacionesContabilidadSrvBeanRemote.contabilizarRastroContable(comprobID, codUsuario, host);

			if (mapaResult == null) {
				logger.error("contabilizarRastroContable: no devolvió ningun resultado para comprobID " + comprobID);
				throw new Exception("contabilizarRastroContable: no devolvió ningun resultado para comprobID " + comprobID);
			}
			if (mapaResult.size() == 0) {
				logger.error("contabilizarRastroContable: no devolvió ningun resultado para comprobID " + comprobID);
				throw new Exception("contabilizarRastroContable: no devolvió ningun resultado para comprobID " + comprobID);
			}

			logger.info("respuesta motor " + ArrayUtils.toString(mapaResult));

			if (!mapaResult.containsKey("continuar")) {
				logger.error("contabilizarRastroContable: no devolvió ningun Codigo de resultado para " + ArrayUtils.toString(mapaResult));
				throw new Exception("contabilizarRastroContable: no devolvió ningun Codigo de resultado para " + ArrayUtils.toString(mapaResult));
			}

			Integer continuar = (Integer) mapaResult.get("continuar");
			if (continuar.compareTo(Integer.valueOf(1)) != 0) {
				String codError = (String) mapaResult.get("codMensaje");
				String descError = (String) mapaResult.get("descMensaje");
				logger.error("Error Motor Contable(contabilizarRastroContable): se produjo error [" + codError + "] " + descError);
				throw new Exception("[" + codError + "] " + descError);
			}

			logger.info("OPERACION CONTABILIZADA!!! " + ArrayUtils.toString(mapaResult));

			return mapaResult;
		} catch (ContabilidadException e) {
			logger.error("Error Motor Contable ContabilidadException " + e.getMessage(), e);
			throw new Exception("Error Motor Contable ContabilidadException " + e.getMessage());
		} catch (Exception e) {
			logger.error("Error Motor Contable Exception " + e.getMessage(), e);
			throw new Exception("Error Motor Contable Exception " + e.getMessage());
		} catch (Throwable e) {
			logger.error("Error Motor Contable: se produjo Throwable al Registrar Op. Contable " + e.getMessage(), e);
			throw new Exception("Error Motor Contable: se produjo Throwable al Registrar Op. Contable " + e.getMessage());
		}
	}

	public Map<String, Object> contabilizarUno(RastroContablePojo rastro, String codUsuario, String host) throws Exception {

		Map<String, Object> mapaResult = new HashMap<String, Object>();

		Integer comprobID = rastro.getComprobId();

		Solicitud solicitudOld = solQLBeanLocal.getSolicitud(rastro.getNroOperacion());

		mapaResult = contabilizarEnMotor(comprobID, "SIODEX", codUsuario, host);

		Integer continuar = deudaSigadeBeanLocal.registrarSigade(solicitudOld.getSolCodigo().toString());

		if (continuar == 1) {
			solQLBeanLocal.cambioEstado(solicitudOld, "", "C");
		} else {
			logger.error("error al registrar en sigade " + solicitudOld.getSolCodigo());
			throw new DataException("error al registrar en sigade " + solicitudOld.getSolCodigo());
		}

		return mapaResult;
	}

	public Map<String, Object> contabilizar(List<Solicitud> lista, String usuario, String ip) throws DataException {
		Map<String, Object> mapaResult = new HashMap<String, Object>();
		Integer continuar = 0;
		try {
			String codError = null;
			String descError = null;
			logger.info("contabilizar lista...");

			for (Solicitud sol : lista) {
				logger.info("registrar solicitud: " + sol.getSolCodigo());
				Map<String, Object> mapa = new HashMap<String, Object>();

				mapa.put("codOperacion", sol.getCodLip());
				mapa.put("codParticipanteOrigen", sol.getCodPart());
				mapa.put("nroCorrelativo", sol.getSolCodigo().toString());
				mapa.put("glosa", sol.getGlosa());
				mapa.put("fecha", sol.getFecha());
				mapa.put("codMonedaOrigen", sol.getMoneda());
				mapa.put("codParticipanteDestino", sol.getCodPartDes());
				mapa.put("codMonedaDestino", sol.getMonedaDes());
				List<SolDato> listaDato = solDatoQLBeanLocal.getDatos(sol.getSolCodigo());
				for (SolDato dato : listaDato) {
					if (dato.getDatoNumero() != null)
						mapa.put(dato.getSolDatoPK().getCodDato(), dato.getDatoNumero());
					else
						mapa.put(dato.getSolDatoPK().getCodDato(), dato.getDatoTexto());
				}

				mapaResult = generarOperacionContable(sol, "SIODEX", usuario, ip);

				continuar = (Integer) mapaResult.get("continuar");
				codError = (String) mapaResult.get("codMensaje");
				descError = (String) mapaResult.get("descMensaje");

				logger.info("continuar: " + continuar + ", codError: " + codError + ", descError: " + descError);

				if (continuar == 1) {
					logger.info("Registro realizada exitosamente: ");
					logger.info("Código: " + codError + " Descripción: " + descError);

					// obtener el ID del comprobante
					Integer comprobID = (Integer) mapaResult.get("comprobID");

					// obteniendo objeto del servicio
					OperacionesContabilidadSrvBeanRemote operacionesContabilidadSrvBeanRemote = util
							.consumirEJB(OperacionesContabilidadSrvBeanRemote.class);

					logger.info("contabilizar: " + comprobID);
					mapaResult = operacionesContabilidadSrvBeanRemote.contabilizarRastroContable(comprobID, usuario, ip);

					logger.info("Mapa: " + mapaResult);

					continuar = (Integer) mapaResult.get("continuar");
					codError = (String) mapaResult.get("codMensaje");
					descError = (String) mapaResult.get("descMensaje");

					logger.info("continuar: " + continuar + ", codError: " + codError + ", descError: " + descError);

					if (continuar == 1) {

						continuar = deudaSigadeBeanLocal.registrarSigade(sol.getLiqCodigo());

						if (continuar == 1) {
							sol.setCveEstado("C");
							solQLBeanLocal.edit(sol);
							// solQLBeanLocal.cambioEstado(solicitudOld, "",
							// "C");
							logger.info("Contabilización realizada exitosamente: ");
							logger.info("Código: " + codError + " Descripción: " + descError);
						} else {
							logger.info("5Error al insertar registro sigade: ");
							logger.info("Código: " + codError + " Descripción: " + descError);
							logger.info("error al insertar registro sigade: " + codError + ", " + descError);
						}
					} else {
						logger.info("3Error al realizar contabilización: ");
						logger.info("Código: " + codError + " Descripción: " + descError);
						logger.info("error del motor de contabilizacion: " + codError + ", " + descError);
					}
				} else {
					logger.info("4Error al registrar solicitud: ");
					logger.info("Código: " + codError + " Descripción: " + descError);
					logger.info("error al registrar la solicitud: " + codError + ", " + descError);
				}
			}
		} catch (ContabilidadException e) {
			logger.error("Error Motor Contable ContabilidadException " + e.getMessage(), e);
			throw new DataException("Error Motor Contable ContabilidadException " + e.getMessage());
		} catch (Exception e) {
			logger.error("Error Motor Contable Exception " + e.getMessage(), e);
			throw new DataException("Error Motor Contable Exception " + e.getMessage());
		} catch (Throwable e) {
			logger.error("Error Motor Contable: se produjo Throwable al Registrar Op. Contable " + e.getMessage(), e);
			throw new DataException("Error Motor Contable: se produjo Throwable al Registrar Op. Contable " + e.getMessage());
		}
		logger.info("Continuar: " + continuar);
		return mapaResult;
	}

}
