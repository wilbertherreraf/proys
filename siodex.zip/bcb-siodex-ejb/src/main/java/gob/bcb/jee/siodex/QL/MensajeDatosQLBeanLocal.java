package gob.bcb.jee.siodex.QL;

import java.util.List;

import gob.bcb.jee.siodex.entities.MensajeDatos;
import gob.bcb.jee.siodex.entities.Datos;

import javax.ejb.Local;

@Local
public interface MensajeDatosQLBeanLocal {

	/**
	 * 
	 * @return
	 */
	void edit(MensajeDatos datos);
	void create(MensajeDatos datos);
	public List<MensajeDatos> getDatos(String codigo);
	public MensajeDatos getDato(String codigo, String campo);
	public List<Datos> getDatosVer(String codigo);
	List<MensajeDatos> crearMensajeDatos(List<MensajeDatos> mensajeDatoslist) ;
	List<MensajeDatos> getDatosByBloque(String menCodigo, short camBloque);
	
}
