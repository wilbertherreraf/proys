package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.exception.DataException;
import org.apache.log4j.Logger;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Created by eborda on 16/02/2017.
 */
@Stateless
@LocalBean
public class ReferenciaQLBean implements ReferenciaQLBeanLocal {


    static final Logger logger = Logger.getLogger(ReferenciaQLBean.class);

    @PersistenceContext(unitName = "siodex")
    EntityManager em;

    /**
     * Default constructor.
     */
    public ReferenciaQLBean() {
        // TODO Auto-generated constructor stub
    }

    @Override
    public Object[] nativo(String query) {
        Object[] datos = null;

        try {
            logger.info("Consulta nativa en Siodex: " + query);
            datos = (Object[]) em.createNativeQuery(query).getSingleResult();
        } catch (Exception e) {
            logger.error("error al ejecutar consulta nativa: " + e.getMessage(), e);
        }

        return datos;
    }

    @Override
    public Object[] getRefDefinicion(String refCodigo) throws DataException {
        String query = "SELECT ref_codigo, ref_definicion FROM referencia " + "WHERE ref_codigo = '" + refCodigo + "' ";

        Object[] datos = nativo(query);

        if (datos == null) {
            logger.error("Referencia inexistente en Siodex para :" + refCodigo);
            throw new DataException("Referencia inexistente en Siodex para :" + refCodigo);
        }

        return datos;
    }
}
