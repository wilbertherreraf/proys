package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.ComisionBancaria;
import gob.bcb.jee.siodex.entities.Cuenta;
import gob.bcb.jee.siodex.entities.Liquidacion;
import gob.bcb.jee.siodex.entities.LiquidacionDet;
import gob.bcb.jee.siodex.entities.Moneda;
import gob.bcb.jee.siodex.entities.PrestamoInstancia;
import gob.bcb.jee.siodex.entities.SolDato;
import gob.bcb.jee.siodex.entities.SolDatoPK;
import gob.bcb.jee.siodex.entities.Vencimiento;
import gob.bcb.jee.siodex.exception.DataException;
import gob.bcb.jee.siodex.service.DeudaBeanLocal;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

@Stateless
@LocalBean
public class LiquidacionCalculosQLBean implements LiquidacionCalculosQLBeanLocal {
	static final Logger logger = Logger.getLogger(LiquidacionCalculosQLBean.class);

	@PersistenceContext(unitName = "siodex")
	EntityManager em;

	@Inject
	private VencimientoQLBeanLocal vencimientoQLBeanLocal;
	@Inject
	private MonedaQLBeanLocal monedaQLBeanLocal;
	@Inject
	private CoinQLBeanLocal coinQLBeanLocal;
	@Inject
	private ComisionBancariaQLBeanLocal comisionBancariaQLBeanLocal;
	@Inject
	private ConsultasSdxQLBeanLocal consultasSdxQLBeanLocal;
	@Inject
	private DeudaBeanLocal deudaBeanLocal;
	@Inject
	private PrestamoInstanciaQLBeanLocal prestamoInstanciaQLBeanLocal;
	@Inject
	private LiquidacionQLBeanLocal liquidacionQLBeanLocal;
	@Inject
	private LiquidacionDetQLBeanLocal liquidacionDetQLBeanLocal;

	/**
	 * Default constructor.
	 */
	public LiquidacionCalculosQLBean() {
	}

	/**
	 * TOTTRANS MONTO TOTAL DE LA TRANSFERENCIA
	 * 
	 * @param vencimiento
	 * @param liquidacion
	 * @return
	 */
	public BigDecimal totTrans(Liquidacion liquidacion) {
		return liquidacion.getMonto();
	}

	/**
	 * TOTFNDR MONTO INTERESES Y COMISIONES
	 * 
	 * @param vencimiento
	 * @param liquidacion
	 * @return
	 */
	public BigDecimal totFndr(Liquidacion liquidacion) {
		return ((liquidacion.getInteresUsd().add(liquidacion.getComisionUsd())).multiply(liquidacion.getTipoCambio())).setScale(2, BigDecimal.ROUND_HALF_UP);
	}

	/**
	 * MONTOMONEDA va a una CTA_FONDOS_VISTA_XXXX, total de la moneda origen
	 * 
	 * MONTOEUR MONTO ASOCIADO A LA CUENTA MADRID EUR CTA
	 * ES2990299029960000000107 MONTOJPY MONTO ASOCIADO A LA CUENTA TOKIO -
	 * 653-0402206 MONTOSEK MONTO ASOCIADO A LA CUENTA BIS 0D BCB MONTOUSD MONTO
	 * ASOCIADO A LA CUENTA NEW YORK - CTA. 3544020682001 y otros
	 * 
	 * @param vencimiento
	 * @param liquidacion
	 * @return
	 * @throws DataException
	 */
	public Liquidacion montoPorMoneda(List<Liquidacion> monedaMonto, String monedaSIGADE) throws DataException {
		Liquidacion liquidacion = null;
		for (Liquidacion liquidacion2 : monedaMonto) {
			if (liquidacion2.getMonSigade().equals(monedaSIGADE)) {
				liquidacion = liquidacion2;
				break;
			}
		}
		return liquidacion;

	}

	/**
	 * retorna el total en moneda USD
	 * 
	 * @param liqCodigo
	 * @param monedaSigade
	 * @return
	 * @throws DataException
	 */
	public BigDecimal montoOrigInt(String liqCodigo, String monedaSigade) throws DataException {

		return consultasSdxQLBeanLocal.montoPorMoneda(liqCodigo, monedaSigade);
	}

	public BigDecimal montoORGINTFF(Liquidacion liquidacion) throws DataException {
		BigDecimal monto = consultasSdxQLBeanLocal.montoPorMoneda(liquidacion.getLiqCodigo(), "USD").multiply(liquidacion.getTipoCambio()).setScale(2, BigDecimal.ROUND_HALF_UP);

		return monto;
	}

	public BigDecimal montoHIPIC(Liquidacion liquidacion) throws DataException {
		BigDecimal monto = consultasSdxQLBeanLocal.montoPorMoneda(liquidacion.getLiqCodigo(), "USD");

		return monto;
	}

	public BigDecimal montoHIPICII(Liquidacion liquidacion) throws DataException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		BigDecimal monto = BigDecimal.ZERO;
		BigDecimal capital = BigDecimal.ZERO;
		BigDecimal interes = BigDecimal.ZERO;
		BigDecimal comision = BigDecimal.ZERO;

		if (liquidacion.getTipoOper().equals("16")) {
			logger.info("**************************************** prestamo: " + liquidacion.getPtmCodigo() + " , " + liquidacion.getTraCodigo());
			List<PrestamoInstancia> instancias = prestamoInstanciaQLBeanLocal.listaInstancia(liquidacion.getPtmCodigo(), liquidacion.getTraCodigo(), "HIP");
			for (PrestamoInstancia instancia : instancias) {
				logger.info("**************************************** instancia: " + instancia.getPinPrestamo() + " , " + instancia.getPinTramo() + " , "
						+ instancia.getCveInstancia());
				if (instancia.getCveInstancia().equals("DMS1")) {
					Object[] da = deudaBeanLocal.InteresesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "11");
					if (da != null) {
						capital = capital.add((BigDecimal) da[1]);
						logger.info("**************************************** capital: " + capital);
					}
					da = deudaBeanLocal.InteresesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "21");
					if (da != null) {
						interes = interes.add((BigDecimal) da[1]);
						logger.info("**************************************** interes: " + interes);
					}
					da = deudaBeanLocal.ComisionesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "11");
					if (da != null) {
						comision = comision.add((BigDecimal) da[1]);
						logger.info("**************************************** comision: " + comision);
					}
				} else {
					Object[] da = deudaBeanLocal.InteresesDms3(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "11");
					if (da != null) {
						capital = capital.add((BigDecimal) da[1]);
						logger.info("**************************************** capital: " + capital);
					}
					da = deudaBeanLocal.InteresesDms3(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "21");
					if (da != null) {
						interes = interes.add((BigDecimal) da[1]);
						logger.info("**************************************** interes: " + interes);
					}
					da = deudaBeanLocal.ComisionesDms3(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "11");
					if (da != null) {
						comision = comision.add((BigDecimal) da[1]);
						logger.info("**************************************** comision: " + comision);
					}
				}
			}
			monto = capital.add(interes).add(comision);
		} else if (liquidacion.getTipoOper().equals("18")) {
			// solo capital
			logger.info("**************************************** prestamo: " + liquidacion.getPtmCodigo() + " , " + liquidacion.getTraCodigo());
			List<PrestamoInstancia> instancias = prestamoInstanciaQLBeanLocal.listaInstancia(liquidacion.getPtmCodigo(), liquidacion.getTraCodigo(), "HIP");
			for (PrestamoInstancia instancia : instancias) {
				logger.info("**************************************** instancia: " + instancia.getPinPrestamo() + " , " + instancia.getPinTramo() + " , "
						+ instancia.getCveInstancia());
				if (instancia.getCveInstancia().equals("DMS1")) {
					Object[] da = deudaBeanLocal.InteresesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "11");
					if (da != null) {
						capital = capital.add((BigDecimal) da[1]);
						logger.info("**************************************** capital: " + capital);
					}
				} else {
					Object[] da = deudaBeanLocal.InteresesDms3(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "11");
					if (da != null) {
						capital = capital.add((BigDecimal) da[1]);
						logger.info("**************************************** capital: " + capital);
					}
				}
			}
			monto = capital.add(interes).add(comision);
		} else if (liquidacion.getTipoOper().equals("23")) {
			// sólo capital
			Map<String, Object> montoConvertido = vencimientoQLBeanLocal.conversion(liquidacion.getCapitalUsd(), liquidacion.getCodMoneda(), liquidacion.getCodMoneda(),
					liquidacion.getFechaTc(), "69", BigDecimal.ZERO);

			monto = (BigDecimal) montoConvertido.get("montobs");
		} else {
			monto = consultasSdxQLBeanLocal.montoPorMoneda(liquidacion.getLiqCodigo(), "BBS");
		}

		return monto;
	}

	public BigDecimal montoHIPICII_o_MAS(Liquidacion liquidacion) throws DataException {
		// BigDecimal monto = consultasSdxQLBeanLocal.montoPorMoneda(liqCodigo,
		// "XP2");
		BigDecimal montoBS = BigDecimal.ZERO;
		if (liquidacion.getCodMoneda().equals("34")) {
			montoBS = liquidacion.getMonto().multiply(liquidacion.getTipoCambio()).setScale(2, BigDecimal.ROUND_HALF_UP);
		} else {
			montoBS = liquidacion.getMonto();
		}
		logger.info("**************************************** montoBS: " + montoBS);
		BigDecimal tipoCambio = coinQLBeanLocal.getTC(liquidacion.getFechaTc(), "76");
		BigDecimal monto = montoBS.divide(tipoCambio, 2, RoundingMode.HALF_UP);
		logger.info("**************************************** montoHIPICII_o_MAS: " + monto);
		return monto;
	}

	public BigDecimal montoMDRICUTBs(Liquidacion liquidacion) throws DataException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		BigDecimal monto = BigDecimal.ZERO;
		BigDecimal montoMo = BigDecimal.ZERO;
		BigDecimal capital = BigDecimal.ZERO;
		BigDecimal interes = BigDecimal.ZERO;
		BigDecimal comision = BigDecimal.ZERO;

		if (liquidacion.getTipoOper().equals("09")) {
			List<PrestamoInstancia> instancias = prestamoInstanciaQLBeanLocal.listaInstancia(liquidacion.getPtmCodigo(), liquidacion.getTraCodigo(), "MDR");
			for (PrestamoInstancia instancia : instancias) {
				logger.info("**************************************** instancia: " + instancia.getPinPrestamo() + " , " + instancia.getPinTramo());
				LiquidacionDet liqDet = liquidacionDetQLBeanLocal.getLiquidacionInstancia(liquidacion.getLiqCodigo(), instancia.getPinPrestamo(), instancia.getPinTramo());
				Moneda monedaC = monedaQLBeanLocal.getMonedaCoin(liqDet.getMonSigade());
				if (liqDet.getMonSigade().equals("USD")) {
					montoMo = liqDet.getInteresMo().add(liqDet.getComisionMo());
				} else {
					montoMo = liqDet.getCapitalMo().add(liqDet.getInteresMo()).add(liqDet.getComisionMo());
				}
				Map<String, Object> montoConvertido = vencimientoQLBeanLocal.conversion(montoMo, monedaC.getMonCoin(), "69", liquidacion.getFechaTc(), "69", BigDecimal.ZERO);
				monto = monto.add((BigDecimal) montoConvertido.get("montobs"));
			}

		} else if (liquidacion.getTipoOper().equals("16")) {
			List<PrestamoInstancia> instancias = prestamoInstanciaQLBeanLocal.listaInstancia(liquidacion.getPtmCodigo(), liquidacion.getTraCodigo(), "HIP");
			for (PrestamoInstancia instancia : instancias) {
				if (instancia.getCveInstancia().equals("DMS1")) {
					Object[] da = deudaBeanLocal.InteresesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "11");
					if (da != null) {
						capital = capital.add((BigDecimal) da[1]);
						logger.info("**************************************** capital: " + capital);
					}
					da = deudaBeanLocal.InteresesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "21");
					if (da != null) {
						interes = interes.add((BigDecimal) da[1]);
						logger.info("**************************************** interes: " + interes);
					}
					da = deudaBeanLocal.ComisionesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "11");
					if (da != null) {
						comision = comision.add((BigDecimal) da[1]);
						logger.info("**************************************** comision: " + comision);
					}
				} else {
					Object[] da = deudaBeanLocal.InteresesDms3(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "11");
					if (da != null) {
						capital = capital.add((BigDecimal) da[1]);
						logger.info("**************************************** capital: " + capital);
					}
					da = deudaBeanLocal.InteresesDms3(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "21");
					if (da != null) {
						interes = interes.add((BigDecimal) da[1]);
						logger.info("**************************************** interes: " + interes);
					}
					da = deudaBeanLocal.ComisionesDms3(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "11");
					if (da != null) {
						comision = comision.add((BigDecimal) da[1]);
						logger.info("**************************************** comision: " + comision);
					}
				}
			}

			BigDecimal montoHipc = capital.add(interes).add(comision);

			Map<String, Object> montoConvertido = vencimientoQLBeanLocal.conversion(liquidacion.getMonto(), liquidacion.getCodMoneda(), liquidacion.getCodMoneda(),
					liquidacion.getFechaTc(), "69", BigDecimal.ZERO);

			monto = ((BigDecimal) montoConvertido.get("montobs")).subtract(montoHipc);

		} else if (liquidacion.getTipoOper().equals("18")) {
			// solo capital
			List<PrestamoInstancia> instancias = prestamoInstanciaQLBeanLocal.listaInstancia(liquidacion.getPtmCodigo(), liquidacion.getTraCodigo(), "HIP");
			for (PrestamoInstancia instancia : instancias) {
				if (instancia.getCveInstancia().equals("DMS1")) {
					Object[] da = deudaBeanLocal.InteresesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "11");
					if (da != null) {
						capital = capital.add((BigDecimal) da[1]);
						logger.info("**************************************** capital: " + capital);
					}
				} else {
					Object[] da = deudaBeanLocal.InteresesDms3(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "11");
					if (da != null) {
						capital = capital.add((BigDecimal) da[1]);
						logger.info("**************************************** capital: " + capital);
					}
				}
			}

			BigDecimal montoHipc = capital.add(interes).add(comision);

			Map<String, Object> montoConvertido = vencimientoQLBeanLocal.conversion(liquidacion.getMonto(), liquidacion.getCodMoneda(), liquidacion.getCodMoneda(),
					liquidacion.getFechaTc(), "69", BigDecimal.ZERO);

			monto = ((BigDecimal) montoConvertido.get("montobs")).subtract(montoHipc);

		} else if (liquidacion.getTipoOper().equals("21")) {
			String moneda = "";
			Moneda monedaC = null;
			List<PrestamoInstancia> instancias = prestamoInstanciaQLBeanLocal.listaInstancia(liquidacion.getPtmCodigo(), liquidacion.getTraCodigo(), "EXT");
			for (PrestamoInstancia instancia : instancias) {
				if (instancia.getCveInstancia().equals("DMS1")) {
					Object[] da = deudaBeanLocal.InteresesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "11");
					if (da != null) {
						moneda = (String) da[2];
						monedaC = monedaQLBeanLocal.getMonedaCoin(moneda);
						Map<String, Object> montoUsd = vencimientoQLBeanLocal.conversion((BigDecimal) da[1], monedaC.getMonCoin(), "69", liquidacion.getFechaTc(), "69",
								BigDecimal.ZERO);
						capital = capital.add((BigDecimal) montoUsd.get("montobs"));
						logger.info("**************************************** capital: " + capital + "  moneda: " + moneda);
					}
					da = deudaBeanLocal.InteresesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "21");
					if (da != null) {
						moneda = (String) da[2];
						monedaC = monedaQLBeanLocal.getMonedaCoin(moneda);
						Map<String, Object> montoUsd = vencimientoQLBeanLocal.conversion((BigDecimal) da[1], monedaC.getMonCoin(), "69", liquidacion.getFechaTc(), "69",
								BigDecimal.ZERO);
						interes = interes.add((BigDecimal) montoUsd.get("montobs"));
						logger.info("**************************************** interes: " + interes + "  moneda: " + moneda);
					}
					da = deudaBeanLocal.ComisionesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "11");
					if (da != null) {
						moneda = (String) da[2];
						Map<String, Object> montoUsd = vencimientoQLBeanLocal.conversion((BigDecimal) da[1], monedaC.getMonCoin(), "69", liquidacion.getFechaTc(), "69",
								BigDecimal.ZERO);
						comision = comision.add((BigDecimal) montoUsd.get("montobs"));
						logger.info("**************************************** comision: " + comision + "  moneda: " + moneda);
					}
				} else {
					Object[] da = deudaBeanLocal.InteresesDms3(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "11");
					if (da != null) {
						moneda = (String) da[2];
						monedaC = monedaQLBeanLocal.getMonedaCoin(moneda);
						Map<String, Object> montoUsd = vencimientoQLBeanLocal.conversion((BigDecimal) da[1], monedaC.getMonCoin(), "69", liquidacion.getFechaTc(), "69",
								BigDecimal.ZERO);
						capital = capital.add((BigDecimal) montoUsd.get("montobs"));
						logger.info("**************************************** capital: " + capital + "  moneda: " + moneda);
					}
					da = deudaBeanLocal.InteresesDms3(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "21");
					if (da != null) {
						moneda = (String) da[2];
						monedaC = monedaQLBeanLocal.getMonedaCoin(moneda);
						Map<String, Object> montoUsd = vencimientoQLBeanLocal.conversion((BigDecimal) da[1], monedaC.getMonCoin(), "69", liquidacion.getFechaTc(), "69",
								BigDecimal.ZERO);
						interes = interes.add((BigDecimal) montoUsd.get("montobs"));
						logger.info("**************************************** interes: " + interes + "  moneda: " + moneda);
					}
					da = deudaBeanLocal.ComisionesDms3(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "11");
					if (da != null) {
						moneda = (String) da[2];
						Map<String, Object> montoUsd = vencimientoQLBeanLocal.conversion((BigDecimal) da[1], monedaC.getMonCoin(), "69", liquidacion.getFechaTc(), "69",
								BigDecimal.ZERO);
						comision = comision.add((BigDecimal) montoUsd.get("montobs"));
						logger.info("**************************************** comision: " + comision + "  moneda: " + moneda);
					}
				}
			}

			BigDecimal montoMdri = capital.add(interes).add(comision);

			Map<String, Object> montoConvertido = vencimientoQLBeanLocal.conversion(liquidacion.getMonto(), liquidacion.getCodMoneda(), "69", liquidacion.getFechaTc(), "69",
					BigDecimal.ZERO);

			monto = ((BigDecimal) montoConvertido.get("montobs")).subtract(montoMdri);

		} else {
			Map<String, Object> montoConvertido = vencimientoQLBeanLocal.conversion(liquidacion.getMonto(), liquidacion.getCodMoneda(), liquidacion.getCodMoneda(),
					liquidacion.getFechaTc(), "69", BigDecimal.ZERO);

			monto = (BigDecimal) montoConvertido.get("montobs");
		}

		return monto;
	}

	public BigDecimal montoMDRICUTUsd(Liquidacion liquidacion) throws DataException {
		// Solo interes
		BigDecimal monto = liquidacion.getInteresUsd();

		return monto;
	}

	public BigDecimal montoDIFCUTBs(Liquidacion liquidacion) throws DataException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		BigDecimal capital = BigDecimal.ZERO;
		BigDecimal interes = BigDecimal.ZERO;
		BigDecimal comision = BigDecimal.ZERO;

		if (liquidacion.getTipoOper().equals("12")) {
			logger.info("**************************************** diff varios tramos: ");
			List<PrestamoInstancia> instancias = prestamoInstanciaQLBeanLocal.listaInstancia(liquidacion.getPtmCodigo(), liquidacion.getTraCodigo(), "EXT");
			for (PrestamoInstancia instancia : instancias) {
				logger.info("**************************************** instancia: " + instancia.getPinPrestamo() + " , " + instancia.getPinTramo());
				Object[] da = deudaBeanLocal.InteresesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "11");
				if (da != null) {
					capital = capital.add((BigDecimal) da[1]);
					logger.info("**************************************** capital: " + capital);
				}
				da = deudaBeanLocal.InteresesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "21");
				if (da != null) {
					interes = interes.add((BigDecimal) da[1]);
					logger.info("**************************************** interes: " + interes);
				}
				da = deudaBeanLocal.ComisionesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "11");
				if (da != null) {
					comision = comision.add((BigDecimal) da[1]);
					logger.info("**************************************** comision: " + comision);
				}
			}
		} else {
			Object[] da = deudaBeanLocal.InteresesDms1(liquidacion.getPtmCodigo(), liquidacion.getTraCodigo(), sdf.format(liquidacion.getFechaVenc()), "11");
			if (da != null) {
				capital = (BigDecimal) da[1];
				logger.info("**************************************** capital: " + capital);
			}
			da = deudaBeanLocal.InteresesDms1(liquidacion.getPtmCodigo(), liquidacion.getTraCodigo(), sdf.format(liquidacion.getFechaVenc()), "21");
			if (da != null) {
				interes = (BigDecimal) da[1];
				logger.info("**************************************** interes: " + interes);
			}
			da = deudaBeanLocal.ComisionesDms1(liquidacion.getPtmCodigo(), liquidacion.getTraCodigo(), sdf.format(liquidacion.getFechaVenc()), "11");
			if (da != null) {
				comision = (BigDecimal) da[1];
				logger.info("**************************************** comision: " + comision);
			}
		}

		Moneda monedaC = monedaQLBeanLocal.getMonedaCoin(liquidacion.getMonSigade());

		Map<String, Object> montoDiff = vencimientoQLBeanLocal.conversion(capital.add(interes).add(comision), monedaC.getMonCoin(), "69", liquidacion.getFechaTc(), "69",
				BigDecimal.ZERO);

		Map<String, Object> montoConvertido = vencimientoQLBeanLocal.conversion(liquidacion.getMonto(), liquidacion.getCodMoneda(), liquidacion.getCodMoneda(),
				liquidacion.getFechaTc(), "69", BigDecimal.ZERO);

		BigDecimal monto = ((BigDecimal) montoConvertido.get("montobs")).subtract((BigDecimal) montoDiff.get("montobs"));

		return monto;
	}

	public BigDecimal montoDIFCUTUsd(Liquidacion liquidacion) throws DataException {

		BigDecimal monto = BigDecimal.ZERO;

		if (liquidacion.getTipoOper().equals("22")) {
			List<Liquidacion> monedaMonto = consultasSdxQLBeanLocal.montosPorMonedas(consultasSdxQLBeanLocal.getLiquidacionBID1020(liquidacion.getLiqCodigo()));
			for (Liquidacion liquidacion2 : monedaMonto) {

				BigDecimal montoMO = liquidacion2.getMonto();

				Moneda monedaC = monedaQLBeanLocal.getMonedaCoin(liquidacion2.getMonSigade());
				BigDecimal tcDefecto = liquidacion2.getTipoCambio();
				Map<String, Object> montoConvertido = vencimientoQLBeanLocal.conversion(montoMO, monedaC.getMonCoin(), "34", liquidacion.getFechaTc(), "69", tcDefecto);

				BigDecimal montosus = (BigDecimal) montoConvertido.get("montosus");

				monto = monto.add(montosus);

			}
			monto = liquidacion.getMonto().subtract(monto);
		}

		return monto;
	}

	public BigDecimal montoVentaUSD(Liquidacion liquidacion) throws DataException {
		// total de la obligacion * tcventa
		logger.info("::En montoVentaUSD Tipo oper: " + liquidacion.getTipoOper());
		Map<String, BigDecimal> conceptoMonto = calculoPorMoneda(liquidacion);
		BigDecimal monto = (BigDecimal) conceptoMonto.get("ventasus");

		// parche para diferencial
		if (liquidacion.getTipoOper().equals("10") || liquidacion.getTipoOper().equals("12") || liquidacion.getTipoOper().equals("21")) {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			BigDecimal capital = BigDecimal.ZERO;
			BigDecimal interes = BigDecimal.ZERO;
			BigDecimal comision = BigDecimal.ZERO;
			if (liquidacion.getTipoOper().equals("12")) {
				logger.info("**************************************** diff varios tramos: ");
				List<PrestamoInstancia> instancias = prestamoInstanciaQLBeanLocal.listaInstancia(liquidacion.getPtmCodigo(), liquidacion.getTraCodigo(), "EXT");
				for (PrestamoInstancia instancia : instancias) {
					logger.info("**************************************** instancia: " + instancia.getPinPrestamo() + " , " + instancia.getPinTramo());
					Object[] da = deudaBeanLocal.InteresesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "11");
					if (da != null) {
						capital = capital.add((BigDecimal) da[1]);
						logger.info("**************************************** capital: " + capital);
					}
					da = deudaBeanLocal.InteresesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "21");
					if (da != null) {
						interes = interes.add((BigDecimal) da[1]);
						logger.info("**************************************** interes: " + interes);
					}
					da = deudaBeanLocal.ComisionesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "11");
					if (da != null) {
						comision = comision.add((BigDecimal) da[1]);
						logger.info("**************************************** comision: " + comision);
					}
				}
			} else if (liquidacion.getTipoOper().equals("21")) {
				logger.info("**************************************** ext varios tramos - diferencial: ");
				List<PrestamoInstancia> instancias = prestamoInstanciaQLBeanLocal.listaInstancia(liquidacion.getPtmCodigo(), liquidacion.getTraCodigo(), "EXT");
				for (PrestamoInstancia instancia : instancias) {
					logger.info("**************************************** instancia: " + instancia.getPinPrestamo() + " , " + instancia.getPinTramo());
					Object[] da = deudaBeanLocal.InteresesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "11");
					Moneda monedaC = monedaQLBeanLocal.getMonedaCoin((String) da[2]);
					if (da != null) {
						Map<String, Object> montoSus = vencimientoQLBeanLocal.conversion((BigDecimal) da[1], monedaC.getMonCoin(), "34", liquidacion.getFechaTc(), "69",
								BigDecimal.ZERO);

						monto = (BigDecimal) montoSus.get("montosus");
						capital = capital.add(monto);
					}
					da = deudaBeanLocal.InteresesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "21");
					monedaC = monedaQLBeanLocal.getMonedaCoin((String) da[2]);
					if (da != null) {
						Map<String, Object> montoSus = vencimientoQLBeanLocal.conversion((BigDecimal) da[1], monedaC.getMonCoin(), "34", liquidacion.getFechaTc(), "69",
								BigDecimal.ZERO);

						monto = (BigDecimal) montoSus.get("montosus");
						interes = interes.add(monto);
					}
					da = deudaBeanLocal.ComisionesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "11");
					if (da != null) {
						Map<String, Object> montoSus = vencimientoQLBeanLocal.conversion((BigDecimal) da[1], monedaC.getMonCoin(), "34", liquidacion.getFechaTc(), "69",
								BigDecimal.ZERO);

						monto = (BigDecimal) montoSus.get("montosus");
						comision = comision.add(monto);
					}
				}
			} else {
				Object[] da = deudaBeanLocal.InteresesDms1(liquidacion.getPtmCodigo(), liquidacion.getTraCodigo(), sdf.format(liquidacion.getFechaVenc()), "11");
				if (da != null) {
					capital = (BigDecimal) da[1];
					logger.info("**************************************** venta capital: " + capital);
				}
				da = deudaBeanLocal.InteresesDms1(liquidacion.getPtmCodigo(), liquidacion.getTraCodigo(), sdf.format(liquidacion.getFechaVenc()), "21");
				if (da != null) {
					interes = (BigDecimal) da[1];
					logger.info("**************************************** venta interes: " + interes);
				}
				da = deudaBeanLocal.ComisionesDms1(liquidacion.getPtmCodigo(), liquidacion.getTraCodigo(), sdf.format(liquidacion.getFechaVenc()), "11");
				if (da != null) {
					comision = (BigDecimal) da[1];
					logger.info("**************************************** venta comision: " + comision);
				}
			}

			Moneda monedaC = monedaQLBeanLocal.getMonedaCoin(liquidacion.getMonSigade());

			Map<String, Object> montoDiff = vencimientoQLBeanLocal.conversion(capital.add(interes).add(comision), monedaC.getMonCoin(), "69", liquidacion.getFechaTc(), "69",
					BigDecimal.ZERO);

			monto = (BigDecimal) montoDiff.get("ventasus");
		}

		return monto;
	}

	public BigDecimal montoDifCambVentaUSD(Liquidacion liquidacion) throws DataException {
		Map<String, BigDecimal> conceptoMonto = calculoPorMoneda(liquidacion);
		BigDecimal monto = (BigDecimal) conceptoMonto.get("difventasus");
		BigDecimal diffVenta = BigDecimal.ZERO;
		// parche para monedas chinas y koreanas
		if (liquidacion.getMonSigade() != null && (liquidacion.getMonSigade().equals("KRW") || liquidacion.getMonSigade().equals("RMY"))) {
			List<Liquidacion> monedaMonto = consultasSdxQLBeanLocal.montosPorMonedas(liquidacion.getLiqCodigo());
			for (Liquidacion liquidacion2 : monedaMonto) {

				BigDecimal montoMO = liquidacion2.getMonto();

				Moneda monedaC = monedaQLBeanLocal.getMonedaCoin(liquidacion.getMonSigade());
				BigDecimal tcDefecto = liquidacion2.getTipoCambio();
				Map<String, Object> montoConvertido = vencimientoQLBeanLocal.conversion(montoMO, monedaC.getMonCoin(), liquidacion.getCodMoneda(), liquidacion.getFechaTc(), "69",
						tcDefecto);

				BigDecimal montoDifcamb = (BigDecimal) montoConvertido.get("difventasus");

				// sumamos las diferencias cambiarias
				diffVenta = diffVenta.add(montoDifcamb);
			}
			monto = diffVenta;
		}
		
		// parche para diferencial
		if (liquidacion.getTipoOper().equals("10") || liquidacion.getTipoOper().equals("12") || liquidacion.getTipoOper().equals("21")) {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			BigDecimal capital = BigDecimal.ZERO;
			BigDecimal interes = BigDecimal.ZERO;
			BigDecimal comision = BigDecimal.ZERO;
			if (liquidacion.getTipoOper().equals("12")) {
				logger.info("**************************************** diff varios tramos: ");
				List<PrestamoInstancia> instancias = prestamoInstanciaQLBeanLocal.listaInstancia(liquidacion.getPtmCodigo(), liquidacion.getTraCodigo(), "EXT");
				for (PrestamoInstancia instancia : instancias) {
					logger.info("**************************************** instancia: " + instancia.getPinPrestamo() + " , " + instancia.getPinTramo());
					Object[] da = deudaBeanLocal.InteresesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "11");
					if (da != null) {
						capital = capital.add((BigDecimal) da[1]);
						logger.info("**************************************** capital: " + capital);
					}
					da = deudaBeanLocal.InteresesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "21");
					if (da != null) {
						interes = interes.add((BigDecimal) da[1]);
						logger.info("**************************************** interes: " + interes);
					}
					da = deudaBeanLocal.ComisionesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "11");
					if (da != null) {
						comision = comision.add((BigDecimal) da[1]);
						logger.info("**************************************** comision: " + comision);
					}
				}
			} else if (liquidacion.getTipoOper().equals("21")) {
				logger.info("**************************************** ext varios tramos - diferencial: ");
				List<PrestamoInstancia> instancias = prestamoInstanciaQLBeanLocal.listaInstancia(liquidacion.getPtmCodigo(), liquidacion.getTraCodigo(), "EXT");
				for (PrestamoInstancia instancia : instancias) {
					logger.info("**************************************** instancia: " + instancia.getPinPrestamo() + " , " + instancia.getPinTramo());
					Object[] da = deudaBeanLocal.InteresesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "11");
					Moneda monedaC = monedaQLBeanLocal.getMonedaCoin((String) da[2]);
					if (da != null) {
						Map<String, Object> montoSus = vencimientoQLBeanLocal.conversion((BigDecimal) da[1], monedaC.getMonCoin(), "34", liquidacion.getFechaTc(), "69",
								BigDecimal.ZERO);

						monto = (BigDecimal) montoSus.get("montosus");
						capital = capital.add(monto);
					}
					da = deudaBeanLocal.InteresesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "21");
					monedaC = monedaQLBeanLocal.getMonedaCoin((String) da[2]);
					if (da != null) {
						Map<String, Object> montoSus = vencimientoQLBeanLocal.conversion((BigDecimal) da[1], monedaC.getMonCoin(), "34", liquidacion.getFechaTc(), "69",
								BigDecimal.ZERO);

						monto = (BigDecimal) montoSus.get("montosus");
						interes = interes.add(monto);
					}
					da = deudaBeanLocal.ComisionesDms1(instancia.getPinPrestamo(), instancia.getPinTramo(), sdf.format(liquidacion.getFechaVenc()), "11");
					if (da != null) {
						Map<String, Object> montoSus = vencimientoQLBeanLocal.conversion((BigDecimal) da[1], monedaC.getMonCoin(), "34", liquidacion.getFechaTc(), "69",
								BigDecimal.ZERO);

						monto = (BigDecimal) montoSus.get("montosus");
						comision = comision.add(monto);
					}
				}
			} else {
				Object[] da = deudaBeanLocal.InteresesDms1(liquidacion.getPtmCodigo(), liquidacion.getTraCodigo(), sdf.format(liquidacion.getFechaVenc()), "11");
				if (da != null) {
					capital = (BigDecimal) da[1];
					logger.info("**************************************** diff capital: " + capital);
				}
				da = deudaBeanLocal.InteresesDms1(liquidacion.getPtmCodigo(), liquidacion.getTraCodigo(), sdf.format(liquidacion.getFechaVenc()), "21");
				if (da != null) {
					interes = (BigDecimal) da[1];
					logger.info("**************************************** diff interes: " + interes);
				}
				da = deudaBeanLocal.ComisionesDms1(liquidacion.getPtmCodigo(), liquidacion.getTraCodigo(), sdf.format(liquidacion.getFechaVenc()), "11");
				if (da != null) {
					comision = (BigDecimal) da[1];
					logger.info("**************************************** diff comision: " + comision);
				}
			}

			Moneda monedaC = monedaQLBeanLocal.getMonedaCoin(liquidacion.getMonSigade());

			Map<String, Object> montoDiff = vencimientoQLBeanLocal.conversion(capital.add(interes).add(comision), monedaC.getMonCoin(), "69", liquidacion.getFechaTc(), "69",
					BigDecimal.ZERO);

			diffVenta = (BigDecimal) montoDiff.get("difventasus");

			monto = diffVenta;
		}
		logger.info("En montoDifCambVentaUSD " + monto);
		return monto;
	}

	/**
	 * Suma las moneda origen por moneda
	 * 
	 * @param liquidacion
	 * @return
	 * @throws DataException
	 */
	public Map<String, BigDecimal> calculoPorMoneda(Liquidacion liquidacion) throws DataException {
		Map<String, BigDecimal> conceptoMonto = new HashMap<String, BigDecimal>();

		BigDecimal ventaUSD = BigDecimal.ZERO;
		BigDecimal diffVenta = BigDecimal.ZERO;
		List<Liquidacion> monedaMonto = consultasSdxQLBeanLocal.montosPorMonedas(liquidacion.getLiqCodigo());
		List<LiquidacionDet> liquidacionDetLista = liquidacionDetQLBeanLocal.listaLiquidacion(liquidacion.getLiqCodigo());

		for (Liquidacion liquidacion2 : monedaMonto) {

			String monedaSIGADE = liquidacion2.getMonSigade();
			BigDecimal montoMO = liquidacion2.getMonto();

			Moneda monedaC = monedaQLBeanLocal.getMonedaCoin(monedaSIGADE);

			BigDecimal tcDefecto = liquidacion.getTipoCambio();
			Map<String, Object> montoConvertido = vencimientoQLBeanLocal.conversion(montoMO, monedaC.getMonCoin(), liquidacion.getCodMoneda(), liquidacion.getFechaTc(), "69",
					tcDefecto);

			BigDecimal montoDifcamb = (BigDecimal) montoConvertido.get("difventasus");
			BigDecimal ventasus = (BigDecimal) montoConvertido.get("ventasus");

			ventaUSD = ventaUSD.add(ventasus);
			// sumamos las diferencias cambiarias
			diffVenta = diffVenta.add(montoDifcamb);
			//logger.info("################# " + monedaC.getMonCoin() + " " + monedaC.getMonNombre());

			for (LiquidacionDet liquidacionDet : liquidacionDetLista) {
			
				if (liquidacionDet.getMonSigade().trim().equals("KRW") || liquidacionDet.getMonSigade().trim().equals("RMY")) {
					tcDefecto = liquidacionDet.getTipoCambiomo();
					monedaC = monedaQLBeanLocal.getMonedaCoin(liquidacionDet.getMonSigade().trim());
					
					logger.info(":::conversion " + montoMO + " " + monedaC.getMonCoin() + " => " + liquidacion.getCodMoneda() + " " + liquidacion.getFechaTc() + " tcDefecto: " + tcDefecto);
					Map<String, Object> montoConvertido0 = UtilConversion.conversion(montoMO, monedaC.getMonCoin(), liquidacion.getCodMoneda(), liquidacion.getFechaTc(), tcDefecto, "V",
							coinQLBeanLocal);
				
					BigDecimal montoBoliv = (BigDecimal) montoConvertido0.get("montobs");
					BigDecimal montoMO0 = (BigDecimal) montoConvertido0.get("montomo");
					BigDecimal tipocambiomoxbs = (BigDecimal) montoConvertido0.get("tipocambiomdest");
					BigDecimal montosus = (BigDecimal) montoConvertido0.get("montosus");
					BigDecimal ventasusexpenbs = (BigDecimal) montoConvertido0.get("ventasusexpenbs");
					BigDecimal difventasus = (BigDecimal) montoConvertido0.get("difventasus");
					BigDecimal tipocambiomo = (BigDecimal) montoConvertido0.get("tipocambiomo");

					logger.info("==OOOOO> montoBoliv " + montoBoliv + " montoMO: " + montoMO + " montoMO: " + montoMO0 + " tipocambiomoxbs: " + tipocambiomoxbs + " " + " tipocambiomo: "
							+ tipocambiomo + " tcDefecto: " + tcDefecto + " montosus: " + montosus + " ventasusexpenbs:" + ventasusexpenbs + " difventasus: " + difventasus);
					ventaUSD = ventasusexpenbs;
					break;
				}
			}
		}
		logger.info(":::ventaUSD " + ventaUSD + " difventasus " + diffVenta);
		conceptoMonto.put("difventasus", diffVenta);
		conceptoMonto.put("ventasus", ventaUSD);
		return conceptoMonto;
	}

	public SolDato calculoConceptoMonto(Vencimiento vencimiento, Liquidacion liquidacion, String campo, String codMensaje, String codMonedaSIGADE) throws DataException {
		SolDato solDato = new SolDato();
		BigDecimal valor = BigDecimal.valueOf(0);

		String cveDH = "";
		String codMoneda = "";

		Map<String, BigDecimal> comisionesMonto = comisionBancariaQLBeanLocal.getComisiones(liquidacion);

		if (campo.equals("TOTTRANS")) {
			valor = totTrans(liquidacion);
			codMoneda = vencimiento.getMonedaCont();

		} else if (campo.equals("TOTFNDR")) {
			if (vencimiento.getDeudor().equals("FNDR")) {
				valor = totFndr(liquidacion);
				codMoneda = vencimiento.getMonedaCont();
			}

		} else if (campo.equals("MONTOUSD")) {
			List<Liquidacion> monedaMonto = consultasSdxQLBeanLocal.montosPorMonedas(vencimiento.getLiqCodigo());

			Liquidacion liquidacion2 = montoPorMoneda(monedaMonto, "USD");
			valor = liquidacion2.getMonto();
			codMoneda = "34";

		} else if (campo.equals("MONTO" + codMonedaSIGADE)) {
			List<Liquidacion> monedaMonto = consultasSdxQLBeanLocal.montosPorMonedas(vencimiento.getLiqCodigo());

			Liquidacion liquidacion2 = montoPorMoneda(monedaMonto, codMonedaSIGADE);
			valor = liquidacion2.getMonto();
			codMoneda = liquidacion2.getCodMoneda();

		} else if (campo.equals("MONTOORGINT")) {
			BigDecimal monto = BigDecimal.ZERO;
			if (liquidacion.getTipoOper().equals("09")) {
				List<PrestamoInstancia> instancias = prestamoInstanciaQLBeanLocal.listaInstancia(liquidacion.getPtmCodigo(), liquidacion.getTraCodigo(), "LOC");
				for (PrestamoInstancia instancia : instancias) {
					logger.info("**************************************** instancia: " + instancia.getPinPrestamo() + " , " + instancia.getPinTramo());
					LiquidacionDet liqDet = liquidacionDetQLBeanLocal.getLiquidacionInstancia(liquidacion.getLiqCodigo(), instancia.getPinPrestamo(), instancia.getPinTramo());
					monto = monto.add(liqDet.getCapitalMo()).add(liqDet.getInteresMo()).add(liqDet.getComisionMo());
				}
				valor = monto;
			} else {
				List<Liquidacion> monedaMonto = consultasSdxQLBeanLocal.montosPorMonedas(vencimiento.getLiqCodigo());

				// moneda mvdol
				Liquidacion liquidacion2 = montoPorMoneda(monedaMonto, "USD");
				valor = liquidacion2.getMonto();
			}
			codMoneda = "75";

		} else if (campo.equals("MONTOORGINTFF")) {
			valor = montoORGINTFF(liquidacion);
			codMoneda = "69";

		} else if (campo.equals("MONTOORGINTBS")) {
			// no hay prametrizado

		} else if (campo.equals("MONTOHIPCII")) {
			valor = montoHIPICII(liquidacion);
			codMoneda = "69";

		} else if (campo.equals("MONTOHIPC")) {
			valor = montoHIPIC(liquidacion);
			codMoneda = "34";

		} else if (campo.equals("MONTOHIPCIIMAS")) {
			valor = montoHIPICII_o_MAS(liquidacion);
			codMoneda = "76";

		} else if (campo.equals("MONTOMDRICUTBS")) {
			valor = montoMDRICUTBs(liquidacion);
			codMoneda = "69";

		} else if (campo.equals("MONTOMDRICUTUSD")) {
			valor = montoMDRICUTUsd(liquidacion);
			codMoneda = "34";

		} else if (campo.equals("MONTODIFCUTBS")) {
			valor = montoDIFCUTBs(liquidacion);
			codMoneda = "69";

		} else if (campo.equals("MONTODIFCUTUSD")) {
			valor = montoDIFCUTUsd(liquidacion);
			codMoneda = "34";

		} else if (campo.equals("MONTOVENTAUSD")) {
			valor = montoVentaUSD(liquidacion);
			codMoneda = "69";
			logger.info("XXX>>>>>>>>>>>>>>>>>>: campo [" + campo + "," + valor + "]");			

		} else if (campo.equals("MONTODIFCAMBVENDIV")) {
			valor = montoDifCambVentaUSD(liquidacion);
			codMoneda = "69";

		} else if (campo.equals("PRECIO_UNITARIO")) {
			valor = coinQLBeanLocal.getTC(liquidacion.getFechaTc(), "35");

			// ////////////////////////////
		} else if (campo.equals("MONTOTOTCOMISIONES")) {
			// el valor de MONTOTOTCOMISIONES en la tabla comisiones_bancarias
			// esta en MN se convierte a la moneda comision
			BigDecimal montoBS = comisionesMonto.get(campo);
			Cuenta cuentaCom = vencimiento.getCuentaPrestamo("DEUC");

			Map<String, Object> montoConvertido = vencimientoQLBeanLocal.conversion(montoBS, "69", cuentaCom.getCodMoneda(), vencimiento.getFechaTc(), "69",
					liquidacion.getTipoCambio());

			BigDecimal montoMO = (BigDecimal) montoConvertido.get("monto");
			valor = montoMO;
			codMoneda = cuentaCom.getCodMoneda();

		} else if (campo.equals("MONTOTOTCOMPAGDEUEXT")) {
			valor = comisionesMonto.get(campo);
			codMoneda = "69";
		} else if (campo.equals("MONTOCOMPAGDEUEXT")) {
			valor = comisionesMonto.get(campo);
			codMoneda = "69";

		} else if (campo.equals("MONTOCOMPAGDEUEXTIVA")) {
			valor = comisionesMonto.get(campo);
			codMoneda = "69";

		} else if (campo.equals("MONTOTOTGASTOCOM")) {
			valor = comisionesMonto.get(campo);
			codMoneda = "69";

		} else if (campo.equals("MONTOGASTOCOM")) {
			valor = comisionesMonto.get(campo);
			codMoneda = "69";

		} else if (campo.equals("MONTOGASTOCOMIVA")) {
			valor = comisionesMonto.get(campo);
			codMoneda = "69";

		} else if (campo.equals("MONTOTOTGASTOADM")) {
			valor = comisionesMonto.get(campo);
			codMoneda = "69";

		} else if (campo.equals("MONTOGASTOADM")) {
			valor = comisionesMonto.get(campo);
			codMoneda = "69";

		} else if (campo.equals("MONTOGASTOADMIVA")) {
			valor = comisionesMonto.get(campo);
			codMoneda = "69";

		} else if (campo.equals("MONTOIVA")) {
			valor = comisionesMonto.get(campo);
			codMoneda = "69";

		}

		BigDecimal tipoCambio = BigDecimal.ZERO;
		if (!StringUtils.isBlank(codMoneda)) {
			tipoCambio = coinQLBeanLocal.getTC(liquidacion.getFechaTc(), codMoneda);
		}

		solDato.setDatoNumero(valor);
		solDato.setCveDh(cveDH);
		solDato.setCodMoneda(codMoneda);
		solDato.setTipoCambio(tipoCambio);

		logger.info("XXX: campo [" + campo + "," + valor + "]");
		return solDato;
	}

	public static void main(String[] args) {
		Map<String, HashMap<String, BigDecimal>> a = new HashMap<String, HashMap<String, BigDecimal>>();
		Map<String, BigDecimal> b = new HashMap<String, BigDecimal>();
		b.put("a", BigDecimal.TEN);
		b.put("b", BigDecimal.ONE);
		b.put("c", BigDecimal.ONE);

		a.put("uno", (HashMap<String, BigDecimal>) b);

		b = new HashMap<String, BigDecimal>();
		b.put("a", BigDecimal.ZERO);
		b.put("b", BigDecimal.valueOf(100));
		a.put("dos", (HashMap<String, BigDecimal>) b);

		System.out.println(ArrayUtils.toString(a));
		System.out.println(a.get("uno").get("c"));
	}
}
