package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.exception.DataException;

import java.math.BigDecimal;
import java.util.Date;

import javax.ejb.Local;

@Local
public interface CoinQLBeanLocal {

	/**
	 * 
	 * @return
	 */
	Object[] nativo(String query);
	
	BigDecimal nativoSimple(String query);
	BigDecimal getTC(Date fecha, String mon) throws DataException;

	Object[] getMovimiento(String afectable) throws DataException;

	Object[] getCuentaMovimiento(String cuenta) throws DataException;

	Object[] getCuentaDatos(String cuenta) throws DataException;

}
