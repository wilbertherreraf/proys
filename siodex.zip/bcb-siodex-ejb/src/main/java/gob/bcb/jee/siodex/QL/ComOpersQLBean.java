package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.ComOpers;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

@Stateless
@LocalBean
@TransactionManagement(TransactionManagementType.CONTAINER)
public class ComOpersQLBean extends DaoGeneric<ComOpers> implements ComOpersQLBeanLocal {

	static final Logger logger = Logger.getLogger(DebtServOpersQLBean.class);

	@PersistenceContext(unitName = "dms1")
	//@PersistenceContext(unitName = "siodex")
	EntityManager em;

	/**
	 * Default constructor.
	 */
	public ComOpersQLBean() {
		super(ComOpers.class);
	}

	public ComOpers getCo(Integer codigo) {

		ComOpers co = null;

		StringBuilder query = new StringBuilder();

		query.append("select c from ComOpers c where c.coopId = ?");

		Query consulta = em.createQuery(query.toString());
		consulta.setParameter(1, codigo);

		List lista = consulta.getResultList();
		if (lista.size() > 0) {
			return (ComOpers) lista.get(0);
		}

		return co;

	}

	@Override
	public void setEntityManager(EntityManager entityManager) {
		// TODO Auto-generated method stub

	}

	@Override
	public EntityManager getEntityManager() {
		// TODO Auto-generated method stub
		return em;
	}

}
