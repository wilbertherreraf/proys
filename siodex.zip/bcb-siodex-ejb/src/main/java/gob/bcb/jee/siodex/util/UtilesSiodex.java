package gob.bcb.jee.siodex.util;

import gob.bcb.jee.siodex.exception.MsgErr;
import gob.bcb.jee.siodex.exception.XMLException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class UtilesSiodex {
    /**
     * Metodo que permite generar un documento XML de respuesta
     * @param nro_oper Numero de la operación
     * @param cod_error Codigo del Error
     * @param des_error Descripcion del error
     * @param comprobante Cadena que representa el numero de comprobante COIN
     * @return Documento XML de respuesta de tipo Document
     * @param docOrig Documento XML original a ser añadido en la respuesta (tipo Document)
     * @throws XMLException Excepcion de tipo XML
     */    
    public static Document generaDocXMLRespuesta(long nro_corr, String cod_error, String des_error) throws XMLException{
        Document docRes=null;
    	//org.apache.xerces.dom3.Document3 docRes=null; 
        Element raiz, elemento=null;
        try{
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance ();
            DocumentBuilder db = dbf.newDocumentBuilder ();
            //docRes = (Document3)db.newDocument ();
            docRes = db.newDocument ();
            
            raiz = docRes.createElement("respuesta");
            
//            elemento = docRes.createElement ("res");
//            elemento.appendChild (docRes.createTextNode (String.valueOf(nro_corr)));
//            raiz.appendChild (elemento);
            
            elemento = docRes.createElement ("error");
            elemento.appendChild (docRes.createTextNode (cod_error));
            raiz.appendChild (elemento);
            
            elemento = docRes.createElement ("desError");
            elemento.appendChild (docRes.createTextNode (des_error));
            raiz.appendChild (elemento);
            
            docRes.appendChild (raiz);
            
        }catch(Exception e){
            XMLException xmlex = new XMLException(MsgErr.getMessage("X010"));
            throw xmlex;
        }
        return docRes;
    }
}
