/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author CUriona
 */
@Embeddable
public class LiquidacionDetPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "liq_codigo", nullable = false)
    private String liqCodigo;
    @Basic(optional = false)
    @NotNull
    @Column(name = "liq_detalle", nullable = false)
    private String liqDetalle;

    public LiquidacionDetPK() {
    }

    public LiquidacionDetPK(String liqCodigo, String liqDetalle) {
        this.liqCodigo = liqCodigo;
        this.liqDetalle = liqDetalle;
    }

    public String getLiqCodigo() {
        return liqCodigo;
    }

    public void setLiqCodigo(String liqCodigo) {
        this.liqCodigo = liqCodigo;
    }

    public String getLiqDetalle() {
        return liqDetalle;
    }

    public void setLiqDetalle(String liqDetalle) {
        this.liqDetalle = liqDetalle;
    }

	@Override
	public String toString() {
		return "LiquidacionDetPK [liqCodigo=" + liqCodigo + ", liqDetalle=" + liqDetalle + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((liqCodigo == null) ? 0 : liqCodigo.hashCode());
		result = prime * result + ((liqDetalle == null) ? 0 : liqDetalle.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LiquidacionDetPK other = (LiquidacionDetPK) obj;
		if (liqCodigo == null) {
			if (other.liqCodigo != null)
				return false;
		} else if (!liqCodigo.equals(other.liqCodigo))
			return false;
		if (liqDetalle == null) {
			if (other.liqDetalle != null)
				return false;
		} else if (!liqDetalle.equals(other.liqDetalle))
			return false;
		return true;
	}
    
}
