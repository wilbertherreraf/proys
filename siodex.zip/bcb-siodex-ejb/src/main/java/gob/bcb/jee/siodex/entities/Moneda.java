package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "moneda")
public class Moneda implements Serializable {
    private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "mon_coin")
	private String monCoin;
	@Column(name = "mon_sigade")
	private String monSigade;
	@Column(name = "mon_nombre")
	private String monNombre;
	@Column(name = "usr_codigo")
	private String usrCodigo;
	@Column(name = "fecha_hora")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fechaHora;
	@Column(name = "estacion")
	private String estacion;
	@Column(name = "mon_swift")
	private String monSwift;
	@Column(name = "des_swift")
	private String desSwift;

	public Moneda() {
		// TODO Auto-generated constructor stub
	}

	public String getMonCoin() {
		return monCoin;
	}

	public void setMonCoin(String monCoin) {
		this.monCoin = monCoin;
	}

	public String getMonSigade() {
		return monSigade;
	}

	public void setMonSigade(String monSigade) {
		this.monSigade = monSigade;
	}

	public String getMonNombre() {
		return monNombre;
	}

	public void setMonNombre(String monNombre) {
		this.monNombre = monNombre;
	}

	public String getUsrCodigo() {
		return usrCodigo;
	}

	public void setUsrCodigo(String usrCodigo) {
		this.usrCodigo = usrCodigo;
	}

	public Date getFechaHora() {
		return fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getEstacion() {
		return estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public String getMonSwift() {
		return monSwift;
	}

	public void setMonSwift(String monSwift) {
		this.monSwift = monSwift;
	}

	public String getDesSwift() {
		return desSwift;
	}

	public void setDesSwift(String desSwift) {
		this.desSwift = desSwift;
	}

}
