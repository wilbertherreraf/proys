/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author CUriona
 */
@Entity
@Table(name = "mensaje")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Mensaje.findAll", query = "SELECT m FROM Mensaje m"),
    @NamedQuery(name = "Mensaje.findByMenCodigo", query = "SELECT m FROM Mensaje m WHERE m.menCodigo = :menCodigo"),
    @NamedQuery(name = "Mensaje.findByMenSwift", query = "SELECT m FROM Mensaje m WHERE m.menSwift = :menSwift"),
    @NamedQuery(name = "Mensaje.findByPtmCodigo", query = "SELECT m FROM Mensaje m WHERE m.ptmCodigo = :ptmCodigo"),
    @NamedQuery(name = "Mensaje.findByTraCodigo", query = "SELECT m FROM Mensaje m WHERE m.traCodigo = :traCodigo"),
    @NamedQuery(name = "Mensaje.findByMontoMo", query = "SELECT m FROM Mensaje m WHERE m.montoMo = :montoMo"),
    @NamedQuery(name = "Mensaje.findByCveEstadoS", query = "SELECT m FROM Mensaje m WHERE m.cveEstadoS = :cveEstadoS"),
    @NamedQuery(name = "Mensaje.findByMonSwift", query = "SELECT m FROM Mensaje m WHERE m.monSwift = :monSwift"),
    @NamedQuery(name = "Mensaje.findByOpeCodigo", query = "SELECT m FROM Mensaje m WHERE m.opeCodigo = :opeCodigo"),
    @NamedQuery(name = "Mensaje.findByDetCodigo", query = "SELECT m FROM Mensaje m WHERE m.detCodigo = :detCodigo"),
    @NamedQuery(name = "Mensaje.findByCapitalMo", query = "SELECT m FROM Mensaje m WHERE m.capitalMo = :capitalMo"),
    @NamedQuery(name = "Mensaje.findByInteresMo", query = "SELECT m FROM Mensaje m WHERE m.interesMo = :interesMo"),
    @NamedQuery(name = "Mensaje.findByComisionMo", query = "SELECT m FROM Mensaje m WHERE m.comisionMo = :comisionMo"),
    @NamedQuery(name = "Mensaje.findByFechaValor", query = "SELECT m FROM Mensaje m WHERE m.fechaValor = :fechaValor"),
    @NamedQuery(name = "Mensaje.findByFechaVencimiento", query = "SELECT m FROM Mensaje m WHERE m.fechaVencimiento = :fechaVencimiento"),
    @NamedQuery(name = "Mensaje.findByUsrCodigo", query = "SELECT m FROM Mensaje m WHERE m.usrCodigo = :usrCodigo"),
    @NamedQuery(name = "Mensaje.findByFechaHora", query = "SELECT m FROM Mensaje m WHERE m.fechaHora = :fechaHora"),
    @NamedQuery(name = "Mensaje.findByEstacion", query = "SELECT m FROM Mensaje m WHERE m.estacion = :estacion")})
public class Mensaje implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "men_codigo", nullable = false)
    private String menCodigo;
    @Basic(optional = false)
    @NotNull
    @Column(name = "men_swift", nullable = false)
    private int menSwift;
    @Column(name = "ptm_codigo")
    private String ptmCodigo;
    @Column(name = "tra_codigo")
    private Integer traCodigo;
    @Basic(optional = false)
    @NotNull
    @Column(name = "monto_mo", nullable = false, precision = 12, scale = 2)
    private BigDecimal montoMo;
    @Basic(optional = false)
    @NotNull
    @Column(name = "cve_estado_s", nullable = false)
    private String cveEstadoS;
    @Basic(optional = false)
    @NotNull
    @Column(name = "mon_swift", nullable = false)
    private String monSwift;
    @Column(name = "ope_codigo")
    private String opeCodigo;
    @Column(name = "det_codigo")
    private String detCodigo;
    @Column(name = "capital_mo", precision = 12, scale = 2)
    private BigDecimal capitalMo;
    @Column(name = "interes_mo", precision = 12, scale = 2)
    private BigDecimal interesMo;
    @Column(name = "comision_mo", precision = 12, scale = 2)
    private BigDecimal comisionMo;
    @Column(name = "fecha_valor")
    @Temporal(TemporalType.DATE)
    private Date fechaValor;
    @Column(name = "fecha_vencimiento")
    @Temporal(TemporalType.DATE)
    private Date fechaVencimiento;
    @Column(name = "liq_codigo")
    private String liqCodigo;
    @Column(name = "liq_detalle")
    private String liqDetalle;
    
    @Basic(optional = false)
    @Column(name = "usr_codigo")
    private String usrCodigo;
    @Basic(optional = false)
    @Column(name = "fecha_hora")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaHora;
    @Column(name = "estacion")
    private String estacion;
    /*@OneToMany(cascade = CascadeType.ALL, mappedBy = "mensaje", fetch = FetchType.LAZY)
    private List<MensajeDetalle> mensajeDetalleList;*/
//    @OneToMany(cascade = CascadeType.ALL, mappedBy = "mensaje", fetch = FetchType.LAZY)
//    private List<MensajeDatos> mensajeDatosList;

    public Mensaje() {
    }

    public Mensaje(String menCodigo) {
        this.menCodigo = menCodigo;
    }

    public Mensaje(String menCodigo, int menSwift, String ptmCodigo, Integer traCodigo, BigDecimal montoMo, String cveEstadoS, 
    		String monSwift, String opeCodigo, BigDecimal capitalMo, BigDecimal interesMo, BigDecimal comisionMo, Date fechaValor, 
    		Date fechaVencimiento, String usrCodigo, Date fechaHora, String estacion) {
    	this.menCodigo = menCodigo;
        this.menSwift = menSwift;
        this.ptmCodigo = ptmCodigo;
        this.traCodigo = traCodigo;
        this.montoMo = montoMo;
        this.cveEstadoS = cveEstadoS;
        this.monSwift = monSwift;
        this.opeCodigo = opeCodigo;
        this.capitalMo = capitalMo;
        this.interesMo = interesMo;
        this.comisionMo = comisionMo;
        this.fechaValor = fechaValor;
        this.fechaVencimiento  = fechaVencimiento;
        this.usrCodigo = usrCodigo;
        this.fechaHora = fechaHora;
        this.estacion = estacion;
    }
    
    public Mensaje(String menCodigo, int menSwift, BigDecimal montoMo, String cveEstadoS, String monSwift, String usrCodigo, 
    		Date fechaHora, String estacion) {
        this.menCodigo = menCodigo;
        this.menSwift = menSwift;
        this.montoMo = montoMo;
        this.cveEstadoS = cveEstadoS;
        this.monSwift = monSwift;
        this.usrCodigo = usrCodigo;
        this.fechaHora = fechaHora;
        this.estacion = estacion;
    }

    public String getMenCodigo() {
        return menCodigo;
    }

    public void setMenCodigo(String menCodigo) {
        this.menCodigo = menCodigo;
    }

    public int getMenSwift() {
        return menSwift;
    }

    public void setMenSwift(int menSwift) {
        this.menSwift = menSwift;
    }

    public String getPtmCodigo() {
        return ptmCodigo;
    }

    public void setPtmCodigo(String ptmCodigo) {
        this.ptmCodigo = ptmCodigo;
    }

    public Integer getTraCodigo() {
        return traCodigo;
    }

    public void setTraCodigo(Integer traCodigo) {
        this.traCodigo = traCodigo;
    }

    public BigDecimal getMontoMo() {
        return montoMo;
    }

    public void setMontoMo(BigDecimal montoMo) {
        this.montoMo = montoMo;
    }

    public String getCveEstadoS() {
        return cveEstadoS;
    }

    public void setCveEstadoS(String cveEstadoS) {
        this.cveEstadoS = cveEstadoS;
    }

    public String getMonSwift() {
        return monSwift;
    }

    public void setMonSwift(String monSwift) {
        this.monSwift = monSwift;
    }

    public String getOpeCodigo() {
        return opeCodigo;
    }

    public void setOpeCodigo(String opeCodigo) {
        this.opeCodigo = opeCodigo;
    }

    public String getDetCodigo() {
        return detCodigo;
    }

    public void setDetCodigo(String detCodigo) {
        this.detCodigo = detCodigo;
    }

    public BigDecimal getCapitalMo() {
        return capitalMo;
    }

    public void setCapitalMo(BigDecimal capitalMo) {
        this.capitalMo = capitalMo;
    }

    public BigDecimal getInteresMo() {
        return interesMo;
    }

    public void setInteresMo(BigDecimal interesMo) {
        this.interesMo = interesMo;
    }

    public BigDecimal getComisionMo() {
        return comisionMo;
    }

    public void setComisionMo(BigDecimal comisionMo) {
        this.comisionMo = comisionMo;
    }

    public Date getFechaValor() {
        return fechaValor;
    }

    public void setFechaValor(Date fechaValor) {
        this.fechaValor = fechaValor;
    }

    public Date getFechaVencimiento() {
        return fechaVencimiento;
    }

    public void setFechaVencimiento(Date fechaVencimiento) {
        this.fechaVencimiento = fechaVencimiento;
    }

    public String getUsrCodigo() {
        return usrCodigo;
    }

    public void setUsrCodigo(String usrCodigo) {
        this.usrCodigo = usrCodigo;
    }

    public Date getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(Date fechaHora) {
        this.fechaHora = fechaHora;
    }

    public String getEstacion() {
        return estacion;
    }

    public void setEstacion(String estacion) {
        this.estacion = estacion;
    }

    /*@XmlTransient
    public List<MensajeDetalle> getMensajeDetalleList() {
        return mensajeDetalleList;
    }

    public void setMensajeDetalleList(List<MensajeDetalle> mensajeDetalleList) {
        this.mensajeDetalleList = mensajeDetalleList;
    }*/

//    @XmlTransient
//    public List<MensajeDatos> getMensajeDatosList() {
//        return mensajeDatosList;
//    }
//
//    public void setMensajeDatosList(List<MensajeDatos> mensajeDatosList) {
//        this.mensajeDatosList = mensajeDatosList;
//    }
//
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (menCodigo != null ? menCodigo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Mensaje)) {
            return false;
        }
        Mensaje other = (Mensaje) object;
        if ((this.menCodigo == null && other.menCodigo != null) || (this.menCodigo != null && !this.menCodigo.equals(other.menCodigo))) {
            return false;
        }
        return true;
    }

	public String getLiqCodigo() {
		return liqCodigo;
	}

	public void setLiqCodigo(String liqCodigo) {
		this.liqCodigo = liqCodigo;
	}

	public String getLiqDetalle() {
		return liqDetalle;
	}

	public void setLiqDetalle(String liqDetalle) {
		this.liqDetalle = liqDetalle;
	}

	@Override
	public String toString() {
		return "Mensaje [menCodigo=" + menCodigo + ", menSwift=" + menSwift + ", ptmCodigo=" + ptmCodigo + ", traCodigo=" + traCodigo + ", montoMo="
				+ montoMo + ", cveEstadoS=" + cveEstadoS + ", monSwift=" + monSwift + ", opeCodigo=" + opeCodigo + ", detCodigo=" + detCodigo
				+ ", capitalMo=" + capitalMo + ", interesMo=" + interesMo + ", comisionMo=" + comisionMo + ", fechaValor=" + fechaValor
				+ ", fechaVencimiento=" + fechaVencimiento + ", liqCodigo=" + liqCodigo + ", liqDetalle=" + liqDetalle + ", usrCodigo=" + usrCodigo
				+ ", fechaHora=" + fechaHora + ", estacion=" + estacion + "]";
	}

    
}
