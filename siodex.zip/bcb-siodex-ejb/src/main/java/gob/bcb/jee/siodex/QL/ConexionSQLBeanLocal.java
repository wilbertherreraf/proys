package gob.bcb.jee.siodex.QL;

import java.sql.Connection;

import javax.ejb.Local;

@Local
public interface ConexionSQLBeanLocal
{
  public Connection getConexion() throws Exception;
}
