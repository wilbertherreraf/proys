package gob.bcb.jee.siodex.QL;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import gob.bcb.jee.siodex.entities.TmpOperacionDeuda;

import javax.ejb.EJBException;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;


@Stateless
@LocalBean
public class TmpDeudaQLBean extends DaoGeneric<TmpOperacionDeuda> implements TmpDeudaQLBeanLocal {

	static final Logger logger = Logger.getLogger(TmpDeudaQLBean.class);

	@PersistenceContext(unitName = "siodex")
	EntityManager em;

	/**
	 * Default constructor.
	 */
	public TmpDeudaQLBean() {
		// TODO Auto-generated constructor stub
		super(TmpOperacionDeuda.class);
	}

	@SuppressWarnings("unchecked")
	public List<TmpOperacionDeuda> listaDeuda(String codigo) {

		List<TmpOperacionDeuda> lista = new ArrayList<TmpOperacionDeuda>();

		try {

			StringBuilder query = new StringBuilder();

			query.append("select d from TmpOperacionDeuda d where d.tmpOperacionDeudaPK.opeCodigo = ?");

			Query consulta = em.createQuery(query.toString());

			consulta.setParameter(1, codigo);

			lista = consulta.getResultList();

		} catch (EJBException e) {
			logger.info("error EJB: " + e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			logger.info("error: " + e.getMessage());
			e.printStackTrace();
		}

		return lista;

	}

	public TmpOperacionDeuda getDeuda(String codigo) {

		TmpOperacionDeuda deuda = null;

			StringBuilder query = new StringBuilder();

			query.append("select d from TmpOperacionDeuda d where d.tmpOperacionDeudaPK.deuCodigo = ?");

			Query consulta = em.createQuery(query.toString());
			consulta.setParameter(1, codigo);

		List lista = consulta.getResultList();
		if (lista.size() > 0) {
			return (TmpOperacionDeuda) lista.get(0);
		}


		return deuda;

	}

	public String getCodigo() {

		String codigo = "";
		String cod = "";

			StringBuilder query = new StringBuilder();

			query.append("select max(d.tmpOperacionDeudaPK.deuCodigo) from TmpOperacionDeuda d");

			Query consulta = em.createQuery(query.toString());

			cod = (String) consulta.getSingleResult();
			Integer cc = Integer.valueOf(cod) + 1;
			codigo = "0" + cc.toString();

			logger.info("deuda: " + codigo);

		return codigo;

	}

	@Override
	public void setEntityManager(EntityManager entityManager) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public EntityManager getEntityManager() {
		// TODO Auto-generated method stub
		return em;
	}

}
