package gob.bcb.jee.siodex.util;

import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

public class MensSwiftUtiles {
	public static int MAX_LINE_CHARS = 35;
	public static String EOF = "@EOF@";
	
	 public static int validarConcepto(String concepto) {
		int valid = 0;
        int i = 0;

        do {
               char c = concepto.charAt(i);

               if (Character.isDigit(c))
                      valid++;
           else if (Character.isUpperCase(c)) {
                      if (c != 'Á' && c != 'É' && c != 'Í' && c != 'Ó' && c != 'Ú' && c != 'Ñ')
                             valid++;
                      else
                             valid = -1;
               } else if (Character.isLowerCase(c)) {
                      if (c != 'á' && c != 'é' && c != 'í' && c != 'ó' && c != 'ú' && c != 'ñ')
                             valid++;
                      else
                             valid = -1;
               } else if (c == '/' || c == '(' || c == ')' || c == '?' || c == '+' || c == '-' || c == '.' || c == ',' || c == ':' || c == '\''
                             || c == ' ')
                      valid++;
               else
                      valid = -1;
               i++;
        } while (valid > 0 && i < concepto.length());

        return valid;

       }

	public static String formatoLinea(String textoOri, int numLinea, String cadenaInicio, boolean conCadInicio) {
		int cantCarateres = 34;

		textoOri = (!StringUtils.isBlank(textoOri) ? textoOri.trim() : "");
		textoOri = (textoOri.startsWith("//") ? textoOri.replaceFirst("//", "") : textoOri);
		textoOri = (textoOri.startsWith("-") ? textoOri.replaceFirst("-", "") : textoOri);

		String cadInicio = "";
		if (numLinea > 1 && conCadInicio) {
			cadInicio = cadenaInicio;
		}
		if (textoOri.trim().length() == 0) {
			return "";
		}

		if (cantCarateres >= textoOri.length()) {
			return (cadInicio + textoOri + '\r' + '\n');

		}
		numLinea++;
		String linea35 = textoOri.substring(0, cantCarateres);

		// verificamos que haya una caracter vacio para tomar desde ahi la
		// nueval linea
		int posVacio = linea35.lastIndexOf(' ');
		String nuevaLinea35 = "";
		if (posVacio <= 0) {
			// no hya caracter vacio se corta a 34 caracteres
			nuevaLinea35 = textoOri.substring(0, cantCarateres);
		} else {
			nuevaLinea35 = textoOri.substring(0, posVacio);
		}

		// resto de la cadena
		textoOri = textoOri.substring(nuevaLinea35.length());

		nuevaLinea35 = nuevaLinea35 + '\r' + '\n';

		return cadInicio + nuevaLinea35 + formatoLinea(textoOri, numLinea, cadenaInicio, conCadInicio);
	}

	public static String cortarTexto(String textoOri, String cadenaInicio, boolean conCadInicio) {
		if (StringUtils.isBlank(textoOri)) {
			return textoOri;
		}

		try {
			// String lines1[] = null;
			List<String> cadEspliteado = new ArrayList<String>();
			String lines[] = textoOri.split("\\r\\n");

			for (int i = 0; i < lines.length; i++) {
				String linesSub[] = lines[i].split("//");
				for (int j = 0; j < linesSub.length; j++) {
					if (!StringUtils.isBlank(linesSub[j]))
						cadEspliteado.add(linesSub[j]);
				}
			}

			String cadenaNew = "";
			int tam = 1;
			for (String cadenalinea : cadEspliteado) {
				if (!StringUtils.isBlank(cadenalinea)) {
					String nCadena = formatoLinea(cadenalinea, tam, cadenaInicio, conCadInicio);
					tam++;
					cadenaNew = cadenaNew + (nCadena);
				}
			}
			return cadenaNew.trim();
		} catch (NullPointerException e) {
			throw new RuntimeException("Error al cortar texto " + e.getMessage(), e);
		} catch (Exception e) {
			throw new RuntimeException("Error al cortar texto " + e.getMessage(), e);
		}
	}

	/**
	 * divide una cadena en lineas menores a 35 caracteres 
	 * @param valor
	 * @param linesMax lineas maximo del resultado
	 * @param suffix cadena de separacion por linea
	 * @param cadenaInicio 
	 * @param startLine
	 * @return
	 */
	public static List<String> splitInLines(String valor, int linesMax, String suffix, String cadenaInicio, int startLine) {
		String frase = "";
		List<String> result = new ArrayList<String>();
		cadenaInicio = StringUtils.trimToEmpty(cadenaInicio);
		int line = 0;
		String prefijo = "";
		
		valor = StringUtils.trimToEmpty(valor);
		valor = MensSwiftUtiles.reemplazarCaracteresInvalidos(valor);
		valor = StringUtils.replaceChars(valor, "\r\n", "  ");		
		valor = StringUtils.replace(valor, "//", " ");
		do {
			valor = StringUtils.trimToEmpty(valor);			
			if (line >= startLine && StringUtils.isNotBlank(valor)) {
				prefijo = cadenaInicio;
			} else {
				prefijo = "";
			}
			valor = prefijo.concat(valor);
			//System.out.println("frase " + frase + " %% " + frase.length() + " valor: "  + valor);
			frase = UtilsGeneric.truncate(valor, MAX_LINE_CHARS, EOF, true);
			frase = StringUtils.trimToEmpty(frase);
			
			if (StringUtils.isNotBlank(frase)) {
				int lastSpace = frase.lastIndexOf(EOF);
				//System.out.println(lastSpace + ">> " +frase + " :: " + frase.length() + " ??[" + valor + "] $$ " + valor.length());

				frase = frase.substring(0,lastSpace);
				valor = valor.substring(frase.length());
				
				frase = (frase.startsWith("-") ? frase.replaceFirst("-", "") : frase);
				//System.out.println(frase + " <::> " + valor );
				//System.out.println(frase + " :: " + frase.length() + " ?? " + valor );
				frase = StringUtils.trimToEmpty(frase);
				result.add(frase);				
				line++;
				//System.out.println(prefijo.concat(frase) + " :: " + prefijo.concat(frase).length());
			}
		} while (valor.length() > 0 && result.size() < linesMax);
		
		return result;
	}

	public static String newStringFromBytes(byte[] bytes, String charsetName) {
		try {
			return new String(bytes, charsetName);
		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException("Impossible failure: Charset.forName(\"" + charsetName + "\") returns invalid name.");

		}
	}
	
	public static String charsInvalids = "ÁÉÍÓÚÑáéíóúñ?\"";
	public static String charsValids =   "AEIOUNaeioun  ";

	public static String reemplazarCaracteresInvalidos(String valor) {
		valor = StringUtils.trimToEmpty(valor);
		if (StringUtils.isBlank(valor)) {
			return valor;
		}
		String nuevovalor = StringUtils.replaceChars(valor, charsInvalids, charsValids);
		return nuevovalor;
	}

	public static final Charset UTF8_CHARSET = Charset.forName("UTF-8");

}
