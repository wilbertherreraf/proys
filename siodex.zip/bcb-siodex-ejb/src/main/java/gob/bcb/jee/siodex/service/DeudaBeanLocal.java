package gob.bcb.jee.siodex.service;

import gob.bcb.jee.siodex.entities.Vencimiento;
import gob.bcb.jee.siodex.exception.DataException;

import javax.ejb.Local;

@Local
public interface DeudaBeanLocal {

	/**
	 * 
	 * @param men
	 * @return
	 * @throws DataException 
	 */
	Integer registrar(Vencimiento vencimiento, String cod) throws DataException;
	
	Object[] InteresesDms1(String prestamo, int tramo, String fecha, String tipo);
	
	Object[] InteresesDms3(String prestamo, int tramo, String fecha, String tipo);
	
	Object[] ComisionesDms1(String prestamo, int tramo, String fecha, String tipo);
	
	Object[] ComisionesDms3(String prestamo, int tramo, String fecha, String tipo);
	
}
