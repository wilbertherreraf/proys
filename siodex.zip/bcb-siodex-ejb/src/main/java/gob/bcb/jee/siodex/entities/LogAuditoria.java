/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Blob;
import java.util.Date;
import java.util.List;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author CUriona
 */
@Entity
@Table(name = "log_auditoria")
@XmlRootElement
@NamedQueries({
	@NamedQuery(name = "LogAuditoria.findAll", query = "SELECT l FROM LogAuditoria l")})

public class LogAuditoria implements Serializable {
	
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "log_auditoria_id", nullable = false)
    private Integer logAuditoriaId;
    @Column(name = "cod_transaccion")
    private String codTransaccion;
    @Column(name = "cod_usuario")
    private String codUsuario;
    @Column(name = "estacion")
    private String estacion;
    @Column(name = "fecha_hora")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaHora;
    
    public LogAuditoria() {
    }

    public LogAuditoria(Integer logAuditoriaId) {
        this.logAuditoriaId = logAuditoriaId;
    }
    
	public LogAuditoria(Integer logAuditoriaId, String codTransaccion,
			String codUsuario, String estacion, Date fechaHora) {
		super();
		this.logAuditoriaId = logAuditoriaId;
		this.codTransaccion = codTransaccion;
		this.codUsuario = codUsuario;
		this.estacion = estacion;
		this.fechaHora = fechaHora;
	}

	public Integer getLogAuditoriaId() {
		return logAuditoriaId;
	}

	public void setLogAuditoriaId(Integer logAuditoriaId) {
		this.logAuditoriaId = logAuditoriaId;
	}

	public String getCodTransaccion() {
		return codTransaccion;
	}

	public void setCodTransaccion(String codTransaccion) {
		this.codTransaccion = codTransaccion;
	}

	public String getCodUsuario() {
		return codUsuario;
	}

	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}

	public String getEstacion() {
		return estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	@Override
	public String toString() {
		return "LogAuditoria [logAuditoriaId=" + logAuditoriaId + ", codTransaccion=" + codTransaccion + ", codUsuario=" + codUsuario + ", estacion="
				+ estacion + ", fechaHora=" + fechaHora + "]";
	}

    
}
