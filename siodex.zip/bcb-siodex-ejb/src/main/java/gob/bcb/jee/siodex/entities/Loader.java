/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Blob;
import java.util.Date;
import java.util.List;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author CUriona
 */
@Entity
@Table(name = "loader")
@XmlRootElement
@NamedQueries({
	@NamedQuery(name = "Loader.findAll", query = "SELECT l FROM Loader l"),
    @NamedQuery(name = "Loader.findByIdLoader", query = "SELECT l FROM Loader l WHERE l.idLoader = :id")})

public class Loader implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "id_loader", nullable = false)
    private Integer idLoader;
    @Basic(optional = false)
    @NotNull
    @Column(name = "id_base", nullable = false)
    private int idBase;
    @Basic(optional = false)
    @NotNull
    @Column(name = "id_portia", nullable = false)
    private Integer idPortia;
    @Basic(optional = false)
    @NotNull
    @Column(name = "numero_swift", nullable = false)
    private Integer numeroSwift;
    @NotNull
    @Column(name = "estado", nullable = false)
    private char estado;
    @NotNull
    @Column(name = "descrip", nullable = false)
    private String descrip;
    @Column(name = "estacion")
    private String estacion;
    @Column(name = "fecha_hora")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaHora;
    @NotNull
    @Column(name = "usuario")
    private String usuario;

    
    public Loader() {
    }

    public Loader(Integer idLoader) {
        this.idLoader = idLoader;
    }
    
	public Loader(Integer idLoader, int idBase, Integer idPortia,
			Integer numeroSwift, char estado, String descrip, String estacion,
			Date fechaHora, String usuario) {
		super();
		this.idLoader = idLoader;
		this.idBase = idBase;
		this.idPortia = idPortia;
		this.numeroSwift = numeroSwift;
		this.estado = estado;
		this.descrip = descrip;
		this.estacion = estacion;
		this.fechaHora = fechaHora;
		this.usuario = usuario;
	}

	public Integer getIdLoader() {
		return idLoader;
	}

	public void setIdLoader(Integer idLoader) {
		this.idLoader = idLoader;
	}

	public int getIdBase() {
		return idBase;
	}

	public void setIdBase(int idBase) {
		this.idBase = idBase;
	}

	public Integer getIdPortia() {
		return idPortia;
	}

	public void setIdPortia(Integer idPortia) {
		this.idPortia = idPortia;
	}

	public Integer getNumeroSwift() {
		return numeroSwift;
	}

	public void setNumeroSwift(Integer numeroSwift) {
		this.numeroSwift = numeroSwift;
	}

	public char getEstado() {
		return estado;
	}

	public void setEstado(char estado) {
		this.estado = estado;
	}

	public String getDescrip() {
		return descrip;
	}

	public void setDescrip(String descrip) {
		this.descrip = descrip;
	}

	public String getEstacion() {
		return estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "Loader [idLoader=" + idLoader + ", idBase=" + idBase + ", idPortia=" + idPortia + ", numeroSwift=" + numeroSwift + ", estado="
				+ estado + ", descrip=" + descrip + ", estacion=" + estacion + ", fechaHora=" + fechaHora + ", usuario=" + usuario + "]";
	}

    
}
