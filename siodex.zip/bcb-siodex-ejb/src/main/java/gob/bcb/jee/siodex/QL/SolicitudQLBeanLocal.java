package gob.bcb.jee.siodex.QL;

import java.util.Date;
import java.util.List;

import gob.bcb.jee.siodex.entities.Solicitud;
import gob.bcb.jee.siodex.exception.DataException;

import javax.ejb.Local;

@Local
public interface SolicitudQLBeanLocal {

	/**
	 * 
	 * @return
	 */
	void edit(Solicitud solicitud);
	void create(Solicitud solicitud);
	public List<Solicitud> listaSolicitud(String estado, String codPart, Date fecha);
	public List<Solicitud> listaSolicitudPendiente();
	public Solicitud getSolicitud(Integer codigo);
	public Solicitud getSolicitudByCodLiq(String codLiquidacion, String estado) throws DataException;
	public Integer getCodigo();
	Integer maxCodigoNuevo();
	Solicitud cambioEstado(Solicitud solicitud, String observacion, String nuevoEstado);
	List<Solicitud> getSolicitudesByCodLiq(String codLiquidacion, String estado) throws DataException;
	
}
