package gob.bcb.jee.siodex.service;

import java.util.List;
import java.util.Map;

import gob.bcb.contabilidad.pojo.RastroContablePojo;
import gob.bcb.jee.siodex.entities.Solicitud;
import gob.bcb.jee.siodex.exception.DataException;

import javax.ejb.Local;

@Local
public interface ComprobanteBeanLocal {

	/**
	 * 
	 * @param men
	 * @return
	 * @throws DataException 
	 */
	public Map<String, Object> contabilizar(List<Solicitud> lista, String usuario, String ip) throws DataException;
	
	public Map<String, Object> contabilizarSolo(Solicitud sol, String usuario, String ip) throws RuntimeException, Exception;
	
	public Map<String, Object> contabilizarUno(RastroContablePojo rastro, String usuario, String ip) throws Exception;

	Map<String, Object> generarOperacionContable(Solicitud solicitudOld, String codAplicacion, String codUsuario, String host) throws DataException;
}
