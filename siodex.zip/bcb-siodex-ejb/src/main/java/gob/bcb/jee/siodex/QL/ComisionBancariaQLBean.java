package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.ComisionBancaria;
import gob.bcb.jee.siodex.entities.ComisionBancariaPK;
import gob.bcb.jee.siodex.entities.Liquidacion;
import gob.bcb.jee.siodex.entities.LogAuditoria;
import gob.bcb.jee.siodex.entities.Moneda;
import gob.bcb.jee.siodex.entities.Vencimiento;
import gob.bcb.jee.siodex.exception.DataException;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.commons.lang.ArrayUtils;
import org.apache.log4j.Logger;

@Stateless
@LocalBean
public class ComisionBancariaQLBean extends DaoGeneric<ComisionBancaria> implements ComisionBancariaQLBeanLocal {

	static final Logger logger = Logger.getLogger(ComisionBancariaQLBean.class);

	@PersistenceContext(unitName = "siodex")
	EntityManager em;

	@Inject
	private ConsultasSdxQLBeanLocal consultasSdxQLBeanLocal;
	@Inject
	private CoinQLBeanLocal coinQLBeanLocal;
	@Inject
	private MonedaQLBeanLocal monedaQLBeanLocal;

	/**
	 * Default constructor.
	 */
	public ComisionBancariaQLBean() {
		super(ComisionBancaria.class);
	}

	/**
	 * Método que permite obtener la lista de comisiones bancarias generadas
	 * para una liquidación.
	 */

	public List<ComisionBancaria> getComisiones(String codigo) {

		List<ComisionBancaria> comis = null;
		StringBuilder query = new StringBuilder();

		query.append("select c from ComisionBancaria c where c.comisionBancariaPK.liqCodigo = ?");

		Query consulta = em.createQuery(query.toString());
		consulta.setParameter(1, codigo);
		logger.info("Comisiones para [" + codigo + "]" + query.toString());
		comis = consulta.getResultList();

		return comis;

	}

	public ComisionBancaria getComisionByCodTipo(String codigo, String tipoComision) {

		ComisionBancaria comis = null;
		StringBuilder query = new StringBuilder();

		query.append("select c from ComisionBancaria c where c.comisionBancariaPK.liqCodigo = :codigo ");
		query.append("and c.comisionBancariaPK.cveTipocomi = :tipoComision ");
		Query consulta = em.createQuery(query.toString());
		consulta.setParameter("codigo", codigo);
		consulta.setParameter("tipoComision", tipoComision);
		logger.info("Ejecutado comisiones " + query.toString() + " para " + codigo + ":" + tipoComision);
		List lista = consulta.getResultList();

		if (lista.size() > 0) {
			return (ComisionBancaria) lista.get(0);
		}
		return comis;

	}


	public ComisionBancaria crearOactualizar(String codLiq, String tipoComi, BigDecimal monto, LogAuditoria log) {
		logger.info("ingresando a crearOactualizar: " + codLiq + " cveTipocomi " + tipoComi + " monto: " + monto + " " + log.toString());
		ComisionBancaria comisionBancaria = new ComisionBancaria(new ComisionBancariaPK(codLiq, tipoComi), log.getLogAuditoriaId(), monto);
		return crearOactualizar(comisionBancaria);
	}

	public ComisionBancaria crearOactualizar(ComisionBancaria comisionBancaria) {
		ComisionBancaria comisBancariaOld = getComisionByCodTipo(comisionBancaria.getComisionBancariaPK().getLiqCodigo(), comisionBancaria
				.getComisionBancariaPK().getCveTipocomi());

		if (comisBancariaOld == null) {
			// creamos el registro
			create(comisionBancaria);
		} else {
			comisBancariaOld.setMontoMN(comisionBancaria.getMontoMN());
			comisBancariaOld.setLogAuditoriaId(comisionBancaria.getLogAuditoriaId());
			edit(comisBancariaOld);
		}

		comisBancariaOld = getComisionByCodTipo(comisionBancaria.getComisionBancariaPK().getLiqCodigo(), comisionBancaria.getComisionBancariaPK()
				.getCveTipocomi());
		return comisBancariaOld;
	}

	public Map<String, BigDecimal> getComisiones(Liquidacion liquidacion) {
		List<ComisionBancaria> comis = getComisiones(liquidacion.getLiqCodigo());
		Map<String, BigDecimal> conceptoMonto = new HashMap<String, BigDecimal>();

		logger.info("recuperando comisiones: " + liquidacion.getLiqCodigo());

		BigDecimal comiPago = BigDecimal.valueOf(0.00);
		BigDecimal comiPagoI = BigDecimal.valueOf(0.00);
		BigDecimal comiPagoR = BigDecimal.valueOf(0.00);
		
		String ivastr = consultasSdxQLBeanLocal.getParametro("@iva");
		BigDecimal iva = new BigDecimal(ivastr.replace(",", "."));
		
		BigDecimal swift = BigDecimal.valueOf(0.00);
		BigDecimal swiftR = BigDecimal.valueOf(0.00);
		BigDecimal swiftI = BigDecimal.valueOf(0.00);

		BigDecimal utiles = BigDecimal.valueOf(0.00);
		BigDecimal utilesI = BigDecimal.valueOf(0.00);
		BigDecimal utilesR = BigDecimal.valueOf(0.00);

		for (ComisionBancaria cc : comis) {
			logger.info("Comision recuperada : " + cc.toString());
			if (cc.getComisionBancariaPK().getCveTipocomi().equals("COPA")) {
				comiPago = cc.getMontoMN();
				comiPagoI = comiPago.multiply(iva).divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
				comiPagoR = comiPago.subtract(comiPagoI);
			} else if (cc.getComisionBancariaPK().getCveTipocomi().equals("SWFT")) {
				swift = cc.getMontoMN();
				swiftI = swift.multiply(iva).divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
				swiftR = swift.subtract(swiftI);
			} else if (cc.getComisionBancariaPK().getCveTipocomi().equals("UTIL")) {
				utiles = cc.getMontoMN();
				utilesI = utiles.multiply(iva).divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
				utilesR = utiles.subtract(utilesI);
			}
		}

		BigDecimal totComi = comiPago.add(swift).add(utiles);
		BigDecimal montoIva = comiPagoI.add(swiftI).add(utilesI);

		conceptoMonto.put("MONTOTOTCOMISIONES", totComi);
		
		conceptoMonto.put("MONTOTOTCOMPAGDEUEXT", comiPago);
		conceptoMonto.put("MONTOCOMPAGDEUEXT", comiPagoR);
		conceptoMonto.put("MONTOCOMPAGDEUEXTIVA", comiPagoI);

		conceptoMonto.put("MONTOTOTGASTOCOM", swift);
		conceptoMonto.put("MONTOGASTOCOM", swiftR);
		conceptoMonto.put("MONTOGASTOCOMIVA", swiftI);

		conceptoMonto.put("MONTOTOTGASTOADM", utiles);
		conceptoMonto.put("MONTOGASTOADM", utilesR);
		conceptoMonto.put("MONTOGASTOADMIVA", utilesI);

		conceptoMonto.put("MONTOIVA", montoIva);

		return conceptoMonto;
	}
	
	@Override
	public void setEntityManager(EntityManager entityManager) {

	}

	@Override
	public EntityManager getEntityManager() {
		return em;
	}

}
