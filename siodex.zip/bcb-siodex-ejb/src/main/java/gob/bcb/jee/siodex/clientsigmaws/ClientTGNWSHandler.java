package gob.bcb.jee.siodex.clientsigmaws;

import gob.bcb.jee.siodex.WS.RespuestaTGN;

import gob.bcb.jee.siodex.clientsigmaws.consultas.WsSiodexWeb;
import gob.bcb.jee.siodex.clientsigmaws.consultas.SiodexWS;
import gob.bcb.jee.siodex.exception.DataException;
import gob.bcb.jee.siodex.exception.XMLException;

import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPException;
import javax.xml.ws.WebServiceException;
import javax.xml.ws.soap.SOAPFaultException;

import org.apache.log4j.Logger;

public class ClientTGNWSHandler {
	private static Logger log = Logger.getLogger(ClientTGNWSHandler.class);

	private static final QName SERVICE_NAME = new QName("http://mefp.gob.bo/itg", "SiodexWS");

	// ///////////////////////////////////////////////////////////////////////////////////////////
	public static String exeRecepcionvencimientos(String mensaje) throws SOAPException, XMLException, DataException {
		URL wsdlURL = SiodexWS.WSDL_LOCATION;

		String msgXMLRespuesta = null;
		try {
			log.info("Invoking exeRecepcionvencimientos... con mensaje XML: \n" + mensaje);
			SiodexWS ss = new SiodexWS(wsdlURL, SERVICE_NAME);
			WsSiodexWeb port = ss.getSiodexWSPort();
			msgXMLRespuesta = port.recepcionVencimientos(mensaje);
		} catch (SOAPFaultException e) {
			log.error("Error al consultar TGN WS SIGMA.Recepcionvencimientos con mensaje: " + e.getMessage(), e);
			throw new SOAPException("Error al consultar WS TGN SIGMA.Recepcionvencimientos con mensaje: " + e.getMessage(), e);
		} catch (WebServiceException e) {
			log.error("Error al ejecutar consulta WS TGN con mensaje: " + e.getMessage());
			throw new SOAPException("Error al ejecutar consulta WS TGN con mensaje: " + e.getMessage(), e);
		} catch (NullPointerException e) {
			log.error("Error al consultar TGN WS SIGMA.Recepcionvencimientos con mensaje: " + e.getMessage(), e);
			throw new SOAPException("Error al consultar WS TGN SIGMA.Recepcionvencimientos con mensaje: " + e.getMessage(), e);
		} catch (Exception e) {
			log.error("Exception : Error al consultar TGN WS SIGMA.Recepcionvencimientos con mensaje: " + e.getMessage(), e);
			throw new SOAPException("Error al consultar WS TGN SIGMA.Recepcionvencimientos con mensaje: " + e.getMessage(), e);
		}

		log.info("=======>>XMLRespuesta[exeRecepcionvencimientos]<<==========");
		log.info(msgXMLRespuesta);
		log.info("=======>>XMLRespuesta<<==========");

		RespuestaTGN respuestaTGN = new RespuestaTGN();
		respuestaTGN.procesar(msgXMLRespuesta);
		if (!respuestaTGN.getCodError().equals("1")) {
			throw new DataException("Error en Servicio TGN con mensaje: " + respuestaTGN.getDescError());
		}
		return respuestaTGN.getDescError();
	}

	public static String exeRecepcionCorrecciones(String mensaje) throws SOAPException, XMLException, DataException {
		URL wsdlURL = SiodexWS.WSDL_LOCATION;

		String msgXMLRespuesta = null;
		try {
			log.info("Invoking exeRecepcionCorrecciones... con mensaje XML: \n" + mensaje);
			SiodexWS ss = new SiodexWS(wsdlURL, SERVICE_NAME);
			WsSiodexWeb port = ss.getSiodexWSPort();
			msgXMLRespuesta = port.recepcionCorrecciones(mensaje);
		} catch (SOAPFaultException e) {
			log.error("Error al consultar TGN WS SIGMA.RecepcionCorrecciones con mensaje: " + e.getMessage(), e);
			throw new SOAPException("Error al consultar WS TGN SIGMA.RecepcionCorrecciones con mensaje: " + e.getMessage());
		} catch (WebServiceException e) {
			log.error("Error al ejecutar consulta WS TGN con mensaje: " + e.getMessage());
			throw new SOAPException("Error al ejecutar consulta WS TGN con mensaje: " + e.getMessage());
		} catch (NullPointerException e) {
			log.error("Error al consultar TGN WS SIGMA.RecepcionCorrecciones con mensaje: " + e.getMessage(), e);
			throw new SOAPException("Error al consultar WS TGN SIGMA.RecepcionCorrecciones con mensaje: " + e.getMessage());
		} catch (Exception e) {
			log.error("Error al consultar TGN WS SIGMA.RecepcionCorrecciones con mensaje: " + e.getMessage(), e);
			throw new SOAPException("Error al consultar WS TGN SIGMA.RecepcionCorrecciones con mensaje: " + e.getMessage());
		}

		log.info("=======>>XMLRespuesta[exeRecepcionCorrecciones]<<==========");
		log.info(msgXMLRespuesta);
		log.info("===========================================");
		RespuestaTGN respuestaTGN = new RespuestaTGN();
		respuestaTGN.procesar(msgXMLRespuesta);
		if (!respuestaTGN.getCodError().equals("1")) {
			throw new DataException("Error en Servicio TGN con mensaje: " + respuestaTGN.getDescError());
		}
		return respuestaTGN.getDescError();
	}

	public static String exeRecepcionConfirmacion(String mensaje) throws SOAPException, XMLException, DataException {
		URL wsdlURL = SiodexWS.WSDL_LOCATION;

		String msgXMLRespuesta = null;
		try {
			log.info("Invoking exeRecepcionConfirmacion... con mensaje XML: \n" + mensaje);
			SiodexWS ss = new SiodexWS(wsdlURL, SERVICE_NAME);
			WsSiodexWeb port = ss.getSiodexWSPort();
			msgXMLRespuesta = port.recepcionConfirmacion(mensaje);
		} catch (SOAPFaultException e) {
			log.error("Error al consultar TGN WS SIGMA.RecepcionConfirmacion con mensaje: " + e.getMessage(), e);
			throw new SOAPException("Error al consultar WS TGN SIGMA.RecepcionConfirmacion con mensaje: " + e.getMessage());
		} catch (WebServiceException e) {
			log.error("Error al ejecutar consulta WS TGN con mensaje: " + e.getMessage());
			throw new SOAPException("Error al ejecutar consulta WS TGN con mensaje: " + e.getMessage());
		} catch (NullPointerException e) {
			log.error("Error al consultar TGN WS SIGMA.RecepcionConfirmacion con mensaje: " + e.getMessage(), e);
			throw new SOAPException("Error al consultar WS TGN SIGMA.RecepcionConfirmacion con mensaje: " + e.getMessage());
		} catch (Exception e) {
			log.error("Error al consultar TGN WS SIGMA.RecepcionConfirmacion con mensaje: " + e.getMessage(), e);
			throw new SOAPException("Error al consultar WS TGN SIGMA.RecepcionConfirmacion con mensaje: " + e.getMessage());
		}

		log.info("=======>>XMLRespuesta[exeRecepcionConfirmacion]<<==========");
		log.info(msgXMLRespuesta);
		log.info("===========================================");
		RespuestaTGN respuestaTGN = new RespuestaTGN();
		respuestaTGN.procesar(msgXMLRespuesta);
		if (!respuestaTGN.getCodError().equals("1")) {
			throw new DataException("Error en Servicio TGN con mensaje: " + respuestaTGN.getDescError());
		}
		return respuestaTGN.getDescError();
	}

	// //////////////////////////////////////////////////////////////////////////////////////////
}
