package gob.bcb.jee.siodex.pojos;

import java.math.BigDecimal;
import java.util.Date;

public class VcDatosAdic {
	private String loNo;
	private Integer traNo;
	private String moneda;
	private Date fechaDeFirma;
	private String duracion;
	private String proyecto;
	private String ley;
	private String monedaOrigen;
	private BigDecimal monto;
	private String refAcreedor;
	private String finex;
	private String tipoAcreedor;
	private String pais;
	private String acreedor;
	private String tipoInstAcre;
	private String grupoAcreedor;
	private String acreedorPais;
	private String sectorEconomico;
	private String ubicacion;
	private String tipoInst;
	private String siglaProv;
	private String proveedor;
	private String ejecutor;
	private String tipoDeudor;
	private String grupoProv;
	private String categoriaInteres;
	private String interes;
	private BigDecimal tasa;
	private String termCredito;
	private String situacion;
	private String fuente;
	private String fuente1;
	private String plazo;
	private Integer anos;

	public VcDatosAdic(){
		
	}
	public VcDatosAdic(String loNo, Integer traNo, String moneda, Date fechaDeFirma, String duracion, String proyecto, String ley,
			String monedaOrigen, BigDecimal monto, String refAcreedor, String finex, String tipoAcreedor, String pais, String acreedor,
			String tipoInstAcre, String grupoAcreedor, String acreedorPais, String sectorEconomico, String ubicacion, String tipoInst,
			String siglaProv, String proveedor, String ejecutor, String tipoDeudor, String grupoProv, String categoriaInteres, String interes,
			BigDecimal tasa, String termCredito, String situacion, String fuente, String fuente1, String plazo, Integer anos) {
		super();
		this.loNo = loNo;
		this.traNo = traNo;
		this.moneda = moneda;
		this.fechaDeFirma = fechaDeFirma;
		this.duracion = duracion;
		this.proyecto = proyecto;
		this.ley = ley;
		this.monedaOrigen = monedaOrigen;
		this.monto = monto;
		this.refAcreedor = refAcreedor;
		this.finex = finex;
		this.tipoAcreedor = tipoAcreedor;
		this.pais = pais;
		this.acreedor = acreedor;
		this.tipoInstAcre = tipoInstAcre;
		this.grupoAcreedor = grupoAcreedor;
		this.acreedorPais = acreedorPais;
		this.sectorEconomico = sectorEconomico;
		this.ubicacion = ubicacion;
		this.tipoInst = tipoInst;
		this.siglaProv = siglaProv;
		this.proveedor = proveedor;
		this.ejecutor = ejecutor;
		this.tipoDeudor = tipoDeudor;
		this.grupoProv = grupoProv;
		this.categoriaInteres = categoriaInteres;
		this.interes = interes;
		this.tasa = tasa;
		this.termCredito = termCredito;
		this.situacion = situacion;
		this.fuente = fuente;
		this.fuente1 = fuente1;
		this.plazo = plazo;
		this.anos = anos;
	}

	public String getLoNo() {
		return loNo;
	}

	public void setLoNo(String loNo) {
		this.loNo = loNo;
	}

	public Integer getTraNo() {
		return traNo;
	}

	public void setTraNo(Integer traNo) {
		this.traNo = traNo;
	}

	public String getMoneda() {
		return moneda;
	}

	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	public Date getFechaDeFirma() {
		return fechaDeFirma;
	}

	public void setFechaDeFirma(Date fechaDeFirma) {
		this.fechaDeFirma = fechaDeFirma;
	}

	public String getDuracion() {
		return duracion;
	}

	public void setDuracion(String duracion) {
		this.duracion = duracion;
	}

	public String getProyecto() {
		return proyecto;
	}

	public void setProyecto(String proyecto) {
		this.proyecto = proyecto;
	}

	public String getLey() {
		return ley;
	}

	public void setLey(String ley) {
		this.ley = ley;
	}

	public String getMonedaOrigen() {
		return monedaOrigen;
	}

	public void setMonedaOrigen(String monedaOrigen) {
		this.monedaOrigen = monedaOrigen;
	}

	public BigDecimal getMonto() {
		return monto;
	}

	public void setMonto(BigDecimal monto) {
		this.monto = monto;
	}

	public String getRefAcreedor() {
		return refAcreedor;
	}

	public void setRefAcreedor(String refAcreedor) {
		this.refAcreedor = refAcreedor;
	}

	public String getFinex() {
		return finex;
	}

	public void setFinex(String finex) {
		this.finex = finex;
	}

	public String getTipoAcreedor() {
		return tipoAcreedor;
	}

	public void setTipoAcreedor(String tipoAcreedor) {
		this.tipoAcreedor = tipoAcreedor;
	}

	public String getPais() {
		return pais;
	}

	public void setPais(String pais) {
		this.pais = pais;
	}

	public String getAcreedor() {
		return acreedor;
	}

	public void setAcreedor(String acreedor) {
		this.acreedor = acreedor;
	}

	public String getTipoInstAcre() {
		return tipoInstAcre;
	}

	public void setTipoInstAcre(String tipoInstAcre) {
		this.tipoInstAcre = tipoInstAcre;
	}

	public String getGrupoAcreedor() {
		return grupoAcreedor;
	}

	public void setGrupoAcreedor(String grupoAcreedor) {
		this.grupoAcreedor = grupoAcreedor;
	}

	public String getAcreedorPais() {
		return acreedorPais;
	}

	public void setAcreedorPais(String acreedorPais) {
		this.acreedorPais = acreedorPais;
	}

	public String getSectorEconomico() {
		return sectorEconomico;
	}

	public void setSectorEconomico(String sectorEconomico) {
		this.sectorEconomico = sectorEconomico;
	}

	public String getUbicacion() {
		return ubicacion;
	}

	public void setUbicacion(String ubicacion) {
		this.ubicacion = ubicacion;
	}

	public String getTipoInst() {
		return tipoInst;
	}

	public void setTipoInst(String tipoInst) {
		this.tipoInst = tipoInst;
	}

	public String getSiglaProv() {
		return siglaProv;
	}

	public void setSiglaProv(String siglaProv) {
		this.siglaProv = siglaProv;
	}

	public String getProveedor() {
		return proveedor;
	}

	public void setProveedor(String proveedor) {
		this.proveedor = proveedor;
	}

	public String getEjecutor() {
		return ejecutor;
	}

	public void setEjecutor(String ejecutor) {
		this.ejecutor = ejecutor;
	}

	public String getTipoDeudor() {
		return tipoDeudor;
	}

	public void setTipoDeudor(String tipoDeudor) {
		this.tipoDeudor = tipoDeudor;
	}

	public String getGrupoProv() {
		return grupoProv;
	}

	public void setGrupoProv(String grupoProv) {
		this.grupoProv = grupoProv;
	}

	public String getCategoriaInteres() {
		return categoriaInteres;
	}

	public void setCategoriaInteres(String categoriaInteres) {
		this.categoriaInteres = categoriaInteres;
	}

	public String getInteres() {
		return interes;
	}

	public void setInteres(String interes) {
		this.interes = interes;
	}

	public BigDecimal getTasa() {
		return tasa;
	}

	public void setTasa(BigDecimal tasa) {
		this.tasa = tasa;
	}

	public String getTermCredito() {
		return termCredito;
	}

	public void setTermCredito(String termCredito) {
		this.termCredito = termCredito;
	}

	public String getSituacion() {
		return situacion;
	}

	public void setSituacion(String situacion) {
		this.situacion = situacion;
	}

	public String getFuente() {
		return fuente;
	}

	public void setFuente(String fuente) {
		this.fuente = fuente;
	}

	public String getFuente1() {
		return fuente1;
	}

	public void setFuente1(String fuente1) {
		this.fuente1 = fuente1;
	}

	public String getPlazo() {
		return plazo;
	}

	public void setPlazo(String plazo) {
		this.plazo = plazo;
	}

	public Integer getAnios() {
		return anos;
	}

	public void setAnios(Integer anios) {
		this.anos = anios;
	}

	@Override
	public String toString() {
		return "VcDatosAdic [loNo=" + loNo + ", traNo=" + traNo + ", moneda=" + moneda + ", fechaDeFirma=" + fechaDeFirma + ", duracion=" + duracion
				+ ", proyecto=" + proyecto + ", ley=" + ley + ", monedaOrigen=" + monedaOrigen + ", monto=" + monto + ", refAcreedor=" + refAcreedor
				+ ", finex=" + finex + ", tipoAcreedor=" + tipoAcreedor + ", pais=" + pais + ", acreedor=" + acreedor + ", tipoInstAcre="
				+ tipoInstAcre + ", grupoAcreedor=" + grupoAcreedor + ", acreedorPais=" + acreedorPais + ", sectorEconomico=" + sectorEconomico
				+ ", ubicacion=" + ubicacion + ", tipoInst=" + tipoInst + ", siglaProv=" + siglaProv + ", proveedor=" + proveedor + ", ejecutor="
				+ ejecutor + ", tipoDeudor=" + tipoDeudor + ", grupoProv=" + grupoProv + ", categoriaInteres=" + categoriaInteres + ", interes="
				+ interes + ", tasa=" + tasa + ", termCredito=" + termCredito + ", situacion=" + situacion + ", fuente=" + fuente + ", fuente1="
				+ fuente1 + ", plazo=" + plazo + ", anos=" + anos + "]";
	}
}
