package gob.bcb.jee.siodex.QL;



import gob.bcb.jee.siodex.entities.SchDebtServPmts;
import org.apache.log4j.Logger;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

/**
 * Created by pali on 20/02/2017.
 */
@Stateless
@LocalBean
public class SchDebtServPmtsQLBean extends DaoGeneric<SchDebtServPmts> implements SchDebtServPmtsQLBeanLocal {

    static final Logger logger = Logger.getLogger(SchDebtServPmts.class);

    @PersistenceContext(unitName = "dms1")
    //@PersistenceContext(unitName = "siodex")
    EntityManager em;

    /**
     * Default constructor.
     */
    public SchDebtServPmtsQLBean() {
        // TODO Auto-generated constructor stub
        super(SchDebtServPmts.class);
    }


    public SchDebtServPmts getDso(Integer codigo) {

        SchDebtServPmts dso = null;

        StringBuilder query = new StringBuilder();

        query.append("select d from DebtServOpers d where d.dsoId = ?");

        Query consulta = em.createQuery(query.toString());
        consulta.setParameter(1, codigo);

        List lista = consulta.getResultList();
        if (lista.size() > 0) {
            return (SchDebtServPmts) lista.get(0);
        }

        return dso;

    }

    @Override
    public void setEntityManager(EntityManager entityManager) {
        // TODO Auto-generated method stub

    }

    @Override
    public EntityManager getEntityManager() {
        // TODO Auto-generated method stub
        return em;
    }

}
