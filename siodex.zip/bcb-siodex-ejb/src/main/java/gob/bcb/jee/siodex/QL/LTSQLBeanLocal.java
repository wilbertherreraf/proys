package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.LoanTrancheSummary;

import java.util.List;

import javax.ejb.Local;

@Local
public interface LTSQLBeanLocal {

	/**
	 * 
	 * @return
	 */
	public LoanTrancheSummary listaLoanTrancheSummary(String loanId, int trancheNo);	
	public List <LoanTrancheSummary> listaLoanTrancheSummary0(String loanId, int trancheNo);
	
}
