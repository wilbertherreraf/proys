/**
 * AlmacenException.java
 *
 * Creado el 28 de mayo de 2003, 03:17 PM
 */
package gob.bcb.jee.siodex.exception;
/**
 * Clase de captura de excepcion personalizada
 * @author Alfredo Lupe
 */

public class VerificaException extends java.lang.Exception {

    /**
     * Crear una nueva instancia de <code>AlmacenException</code> sin detalles.
     */
    public VerificaException() {
    }


    /**
     * Construir una instancia de <code>AlmacenException</code> incluyendo detalles.
     * @param msg detalles del mensaje.
     */
    public VerificaException(String msg) {
        super(msg);
    }
}
