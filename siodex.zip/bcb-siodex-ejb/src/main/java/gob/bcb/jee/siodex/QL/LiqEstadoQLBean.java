package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.LiquidacionEstado;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

@Stateless
@LocalBean
public class LiqEstadoQLBean extends DaoGeneric<LiquidacionEstado> implements LiqEstadoQLBeanLocal {

	static final Logger logger = Logger.getLogger(LiqEstadoQLBean.class);

	@PersistenceContext(unitName = "siodex")
	EntityManager em;

	/**
	 * Default constructor.
	 */
	public LiqEstadoQLBean() {
		// TODO Auto-generated constructor stub
		super(LiquidacionEstado.class);
	}

	/**
	 * Método que permite obtener el registro de un estado de una liquidación.
	 */
	public LiquidacionEstado getLiqEstado(String codigo, String estado) {

		LiquidacionEstado liqEstado = null;

		StringBuilder query = new StringBuilder();

		query.append("select l from LiquidacionEstado l where l.liquidacionEstadoPK.liqCodigo = ? and l.liquidacionEstadoPK.cveEstado = ?");

		Query consulta = em.createQuery(query.toString());
		consulta.setParameter(1, codigo);
		consulta.setParameter(2, estado);

		List lista = consulta.getResultList();
		if (lista.size() > 0) {
			return (LiquidacionEstado) lista.get(0);
		}

		return liqEstado;

	}

	public LiquidacionEstado liqObservado(String liqCodigo, String cveEstado) {
		LiquidacionEstado liqEstado = null;

		StringBuilder query = new StringBuilder();
		// select *
		// from liquidacion_estado le
		// where le.liq_codigo = '003408'
		// and le.cve_estado = 'B'
		// and fecha_hora = (select max(b.fecha_hora)
		// from liquidacion_estado b
		// where b.liq_codigo = le.liq_codigo
		// and b.observacion is not null
		// and trim(b.observacion) != '')
		query.append("select l from LiquidacionEstado l ");
		query.append("where l.liquidacionEstadoPK.liqCodigo = :liqCodigo ");
		query.append("and l.liquidacionEstadoPK.cveEstado = :cveEstado ");
		query.append("and l.fechaHora = (select max(b.fechaHora) from LiquidacionEstado b where b.liquidacionEstadoPK.liqCodigo = l.liquidacionEstadoPK.liqCodigo and b.observacion is not null and trim(b.observacion) != '') ");

		//logger.info("Query liq estado : [" +liqCodigo+"," + cveEstado+ "]" + query.toString());
		Query consulta = em.createQuery(query.toString());
		consulta.setParameter("liqCodigo", liqCodigo);
		consulta.setParameter("cveEstado", cveEstado);

		List lista = consulta.getResultList();
		if (lista.size() > 0) {
			return (LiquidacionEstado) lista.get(0);
		}

		return liqEstado;

	}

	@Override
	public void setEntityManager(EntityManager entityManager) {
		// TODO Auto-generated method stub

	}

	@Override
	public EntityManager getEntityManager() {
		// TODO Auto-generated method stub
		return em;
	}

}
