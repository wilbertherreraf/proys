package gob.bcb.jee.siodex.entities;

/**
 *
 * @author CUriona
 */

@SuppressWarnings("serial")
public class Cuenta implements java.io.Serializable {
    private String cveTitular;	
    private String ctaCodigo;
    private String ctaFactura;
    private String ctaNumero;
    private String ctaNombre;
    private String ctaNit;
    private String bcoCodigo;
    private String bcoNombre;
    private String ctaAfectable;
    private String codPart;
    private String cveTipoCta;    
    private String codMovimiento;
    private String codMoneda;
    private String topCodigo; 
    private String topCodigoDescrip;    
    private String proCodigo; 
    private String proNombre; 
    private String cveTipoLiq; 
    private String cveTipoLiqInstan; 
    private String esqCodigo; 
    private String codlip; 
    private String pinPrestamo; 
    private Integer pinTramo;
    private String ptmCodigo;
    private Integer traCodigo;
    private String genMenswift;    
    private String ctaDireccion; 
    private String ctaPlaza;
    private String ctaSwift;
    private String bcoBic;    
    public Cuenta() {
    }

	public String getCtaCodigo() {
		return ctaCodigo;
	}

	public void setCtaCodigo(String ctaCodigo) {
		this.ctaCodigo = ctaCodigo;
	}

	public String getCtaFactura() {
		return ctaFactura;
	}

	public void setCtaFactura(String ctaFactura) {
		this.ctaFactura = ctaFactura;
	}

	public String getCtaNumero() {
		return ctaNumero;
	}

	public void setCtaNumero(String ctaNumero) {
		this.ctaNumero = ctaNumero;
	}

	public String getCtaNombre() {
		return ctaNombre;
	}

	public void setCtaNombre(String ctaNombre) {
		this.ctaNombre = ctaNombre;
	}

	public String getCtaNit() {
		return ctaNit;
	}

	public void setCtaNit(String ctaNit) {
		this.ctaNit = ctaNit;
	}

	public String getBcoCodigo() {
		return bcoCodigo;
	}

	public void setBcoCodigo(String bcoCodigo) {
		this.bcoCodigo = bcoCodigo;
	}

	public String getBcoNombre() {
		return bcoNombre;
	}

	public void setBcoNombre(String bcoNombre) {
		this.bcoNombre = bcoNombre;
	}

	public String getCtaAfectable() {
		return ctaAfectable;
	}

	public void setCtaAfectable(String ctaAfectable) {
		this.ctaAfectable = ctaAfectable;
	}

	public String getCodPart() {
		return codPart;
	}

	public void setCodPart(String codPart) {
		this.codPart = codPart;
	}

	public String getCveTitular() {
		return cveTitular;
	}

	public void setCveTitular(String cveTitular) {
		this.cveTitular = cveTitular;
	}

	public String getCodMovimiento() {
		return codMovimiento;
	}

	public void setCodMovimiento(String codMovimiento) {
		this.codMovimiento = codMovimiento;
	}

	public String getCodMoneda() {
		return codMoneda;
	}

	public void setCodMoneda(String codMoneda) {
		this.codMoneda = codMoneda;
	}

	public String getCveTipoCta() {
		return cveTipoCta;
	}

	public void setCveTipoCta(String cveTipoCta) {
		this.cveTipoCta = cveTipoCta;
	}

	public String getTopCodigo() {
		return topCodigo;
	}

	public void setTopCodigo(String topCodigo) {
		this.topCodigo = topCodigo;
	}

	public String getProCodigo() {
		return proCodigo;
	}

	public void setProCodigo(String proCodigo) {
		this.proCodigo = proCodigo;
	}

	public String getProNombre() {
		return proNombre;
	}

	public void setProNombre(String proNombre) {
		this.proNombre = proNombre;
	}

	public String getCveTipoLiq() {
		return cveTipoLiq;
	}

	public void setCveTipoLiq(String cveTipoLiq) {
		this.cveTipoLiq = cveTipoLiq;
	}

	public String getCveTipoLiqInstan() {
		return cveTipoLiqInstan;
	}

	public void setCveTipoLiqInstan(String cveTipoLiqInstan) {
		this.cveTipoLiqInstan = cveTipoLiqInstan;
	}

	public String getEsqCodigo() {
		return esqCodigo;
	}

	public void setEsqCodigo(String esqCodigo) {
		this.esqCodigo = esqCodigo;
	}

	public String getCodlip() {
		return codlip;
	}

	public void setCodlip(String codlip) {
		this.codlip = codlip;
	}

	public String getPinPrestamo() {
		return pinPrestamo;
	}

	public void setPinPrestamo(String pinPrestamo) {
		this.pinPrestamo = pinPrestamo;
	}

	public Integer getPinTramo() {
		return pinTramo;
	}

	public void setPinTramo(Integer pinTramo) {
		this.pinTramo = pinTramo;
	}

	public String getPtmCodigo() {
		return ptmCodigo;
	}

	public void setPtmCodigo(String ptmCodigo) {
		this.ptmCodigo = ptmCodigo;
	}

	public Integer getTraCodigo() {
		return traCodigo;
	}

	public void setTraCodigo(Integer traCodigo) {
		this.traCodigo = traCodigo;
	}

	public String getTopCodigoDescrip() {
		return topCodigoDescrip;
	}

	public void setTopCodigoDescrip(String topCodigoDescrip) {
		this.topCodigoDescrip = topCodigoDescrip;
	}

	public String getGenMenswift() {
		return genMenswift;
	}

	public void setGenMenswift(String genMenswift) {
		this.genMenswift = genMenswift;
	}

	public String getCtaDireccion() {
		return ctaDireccion;
	}

	public void setCtaDireccion(String ctaDireccion) {
		this.ctaDireccion = ctaDireccion;
	}

	public String getCtaPlaza() {
		return ctaPlaza;
	}

	public void setCtaPlaza(String ctaPlaza) {
		this.ctaPlaza = ctaPlaza;
	}

	public String getCtaSwift() {
		return ctaSwift;
	}

	public void setCtaSwift(String ctaSwift) {
		this.ctaSwift = ctaSwift;
	}

	@Override
	public String toString() {
		return "Cuenta [cveTitular=" + cveTitular + ", ctaCodigo=" + ctaCodigo + ", ctaFactura=" + ctaFactura + ", ctaNumero=" + ctaNumero
				+ ", ctaNombre=" + ctaNombre + ", ctaNit=" + ctaNit + ", bcoCodigo=" + bcoCodigo + ", bcoNombre=" + bcoNombre + ", ctaAfectable="
				+ ctaAfectable + ", codPart=" + codPart + ", cveTipoCta=" + cveTipoCta + ", codMovimiento=" + codMovimiento + ", codMoneda="
				+ codMoneda + ", topCodigo=" + topCodigo + ", topCodigoDescrip=" + topCodigoDescrip + ", proCodigo=" + proCodigo + ", proNombre="
				+ proNombre + ", cveTipoLiq=" + cveTipoLiq + ", cveTipoLiqInstan=" + cveTipoLiqInstan + ", esqCodigo=" + esqCodigo + ", codlip="
				+ codlip + ", pinPrestamo=" + pinPrestamo + ", pinTramo=" + pinTramo + ", ptmCodigo=" + ptmCodigo + ", traCodigo=" + traCodigo
				+ ", genMenswift=" + genMenswift + ", ctaDireccion=" + ctaDireccion + ", ctaPlaza=" + ctaPlaza + ", ctaSwift=" + ctaSwift + "]";
	}

	public String getBcoBic() {
		return bcoBic;
	}

	public void setBcoBic(String bcoBic) {
		this.bcoBic = bcoBic;
	}


}
