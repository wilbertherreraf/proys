package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.ClaveValor;
import gob.bcb.jee.siodex.entities.Comprobante;
import gob.bcb.jee.siodex.entities.LogAuditoria;
import gob.bcb.jee.siodex.entities.SolDato;
import gob.bcb.jee.siodex.entities.SolDatoPK;
import gob.bcb.jee.siodex.entities.Solicitud;
import gob.bcb.jee.siodex.exception.DataException;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

@Stateless
@LocalBean
public class SolDatoQLBean extends DaoGeneric<SolDato> implements SolDatoQLBeanLocal {

	static final Logger logger = Logger.getLogger(SolDatoQLBean.class);

	@PersistenceContext(unitName = "siodex")
	EntityManager em;

	@Inject
	private LogAuditoriaQLBeanLocal logAuditoriaQLBeanLocal;
	@Inject
	private ConsultasSdxQLBeanLocal consultasSdxQLBeanLocal;

	/**
	 * Default constructor.
	 */
	public SolDatoQLBean() {
		// TODO Auto-generated constructor stub
		super(SolDato.class);
	}

	public List<SolDato> getDatos(Integer codigo) {

		List<SolDato> lista = new ArrayList<SolDato>();

		StringBuilder query = new StringBuilder();

		query.append("select s from SolDato s where s.solDatoPK.solCodigo = ? order by s.orden ");

		Query consulta = em.createQuery(query.toString());
		consulta.setParameter(1, codigo);

		lista = consulta.getResultList();

		return lista;

	}

	public void eliminarDatosSolicitud(Integer codigo) throws DataException {
		logger.info("Eliminando datos solicitud " + codigo);
		List<SolDato> lista = getDatos(codigo);
		while (lista.size() > 0) {
			SolDato solDato = lista.get(0);
			remove(solDato);
			lista = getDatos(codigo);
		}

		lista = getDatos(codigo);

		if (lista.size() > 0) {
			throw new DataException("Datos de Solicitud " + codigo + " no se eliminaron correctamente");
		}
	}

	public SolDato getSolDato(Integer codigo, String codDato) {

		SolDato solDato = null;

		StringBuilder query = new StringBuilder();

		query.append("select s from SolDato s where s.solDatoPK.solCodigo = ? and s.solDatoPK.codDato = ?");

		Query consulta = em.createQuery(query.toString());
		consulta.setParameter(1, codigo);
		consulta.setParameter(2, codDato);

		List lista = consulta.getResultList();
		if (lista.size() > 0) {
			return (SolDato) lista.get(0);
		}

		return solDato;

	}

	/**
	 * actualiza un registro
	 * 
	 * @param codigo
	 * @param codDato
	 * @return
	 */
	public SolDato actualiza(Integer codSol, String codDato, BigDecimal monto, LogAuditoria logAudit) throws DataException {
		SolDato solDato = getSolDato(codSol, codDato);

		if (solDato != null) {
			LogAuditoria logAuditoria = logAuditoriaQLBeanLocal.crearLog(logAudit.getCodUsuario(), logAudit.getCodUsuario(), logAudit.getEstacion(),
					String.valueOf(codSol));

			solDato.setDatoNumero(monto);
			solDato.setLogAuditoriaId(logAuditoria.getLogAuditoriaId());
			edit(solDato);
		} else {
			LogAuditoria logAuditoria = logAuditoriaQLBeanLocal.crearLog(logAudit.getCodUsuario(), logAudit.getCodUsuario(), logAudit.getEstacion(),
					String.valueOf(codSol));
			solDato = new SolDato(new SolDatoPK(codSol, codDato), logAuditoria.getLogAuditoriaId(), monto, null);
			create(solDato);
		}
		logger.info("Dato solicitud actualizado " + solDato.toString());
		return solDato;
	}

	public SolDato actualizaCuentaMov(Solicitud soli, SolDato solDato) {
		String codDato = solDato.getSolDatoPK().getCodDato();

		String cuenta = "";
		String cveCuenta = "";
		if (solDato.getDatoNumero() != null && !StringUtils.isBlank(solDato.getCveDh())) {
			if (codDato.equals("TOTTRANS")) {

				codDato = codigoDatoForCodLip(soli.getCodLip(), "");
				if (soli.getCodLip().equals("I12") || soli.getCodLip().equals("I13")) {
					codDato = "TOTALDESTBDP";
				} else if (soli.getCodPart().equals("950")) {
					codDato = "TOTALENCAJEBDP";
				}
				cveCuenta = "cve_cuentasd";

			} else if (codDato.equals("TOTFNDR")) {

				codDato = codigoDatoForCodLip(soli.getCodLip(), "");
				cveCuenta = "cve_cuentasd";
				
			} else if (codDato.equals("MONTODIFCUTBS")) {

				codDato = "MONTOMDRICUTBS";
				cveCuenta = "cve_cuentas";
				
			} else if (codDato.equals("MONTODIFCUTUSD")) {

				codDato = "MONTOMDRICUTUSD";
				cveCuenta = "cve_cuentas";
				
			} else if (codDato.equals("MONTOTOTCOMISIONES")) {

				codDato = codigoDatoForCodLip(soli.getCodLip(), "COMIS");
				if (soli.getCodPart().equals("950")) {
					codDato = "TOTALCENCAJEBDP";
				}
				cveCuenta = "cve_cuentasc";
			} else if (codDato.equals("MONTOTOTUSDCOMISIONES")) {

				codDato = codigoDatoForCodLip(soli.getCodLip(), "COMIS");
				if (soli.getCodPart().equals("950")) {
					codDato = "TOTALCENCAJEBDP";
				}
				cveCuenta = "cve_cuentasc";
			} else {
				cveCuenta = "cve_cuentas";
			}

			ClaveValor claveValor = consultasSdxQLBeanLocal.clavesValorByCVVNombre(cveCuenta, codDato);
			if (claveValor != null) {
				cuenta = claveValor.getId().getCvvCodigo();
			}

			solDato.setCuentaMov(cuenta);

		}

		return solDato;
	}

	/**
	 * actualiza datos basicos del detalle de una solicitud procesada,
	 * generalmente para operaciones fecha valor
	 * 
	 * @param codSol
	 * @param logAudit
	 * @throws DataException
	 */
	public void actualizaDatosSolicitud(Integer codSol, LogAuditoria logAudit) throws DataException {

	}

	@Override
	public void setEntityManager(EntityManager entityManager) {
		// TODO Auto-generated method stub

	}

	@Override
	public EntityManager getEntityManager() {
		// TODO Auto-generated method stub
		return em;
	}

	public String codigoDatoForCodLip(String codLip, String tipoDeuCom) {
		String codDato = null;
		if (codLip.equals("I01") || codLip.equals("I06")) {
			codDato = "TOTALFISCAL";
			if (tipoDeuCom.equals("COMIS")) {
				codDato = "TOTALCFISCAL";
			}
		} else if (codLip.equals("I02") || codLip.equals("I07")) {
			codDato = "TOTALENCAJE";
			if (tipoDeuCom.equals("COMIS")) {
				codDato = "TOTALCENCAJE";
			}
		} else if (codLip.equals("I03") || codLip.equals("I08")) {
			codDato = "TOTALCUT";
			if (tipoDeuCom.equals("COMIS")) {
				codDato = "TOTALCCUTB";
			}
		} else if (codLip.equals("I04") || codLip.equals("I09")) {
			codDato = "TOTALCUTB";
			if (tipoDeuCom.equals("COMIS")) {
				codDato = "TOTALCCUTB";
			}
		} else if (codLip.equals("I05") || codLip.equals("I10")) {
			codDato = "TOTALTRANS";
			if (tipoDeuCom.equals("COMIS")) {
				codDato = "TOTALCCUTB";

			}
		} else if (codLip.equals("I12") || codLip.equals("I13")) {
			codDato = "TOTALDESTBDP";
			if (tipoDeuCom.equals("COMIS")) {
				codDato = "TOTALCBDP";

			}
		} else if (codLip.equals("I14") || codLip.equals("I15")) {
			codDato = "TOTALBDP";
			if (tipoDeuCom.equals("COMIS")) {
				codDato = "TOTALCBDP";

			}
		}

		return codDato;
	}

}
