package gob.bcb.jee.siodex.QL;

import java.util.List;

import gob.bcb.jee.siodex.entities.LogAuditoria;

import javax.ejb.Local;

@Local
public interface LogAuditoriaQLBeanLocal {

	/**
	 * 
	 * @return
	 */
	void edit(LogAuditoria log);
	void create(LogAuditoria log);
	public List<LogAuditoria> listaLog();
	public LogAuditoria getLog(Integer codigo);
	public Integer getCodigo();
	LogAuditoria maxLogAuditoria();
	LogAuditoria crearLog(String codUsuario, String codParticipante, String estacion, String codTransaccion);
	
}
