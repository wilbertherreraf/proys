package gob.bcb.jee.siodex.xml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "respuesta")
public class RespuestaVencCab {
	protected String id;
	protected String fecha;
	protected String totalReg;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getFecha() {
		return fecha;
	}
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}
	public String getTotalReg() {
		return totalReg;
	}
	public void setTotalReg(String totalReg) {
		this.totalReg = totalReg;
	}
}
