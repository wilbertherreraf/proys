package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.Liquidacion;
import gob.bcb.jee.siodex.entities.LogAuditoria;
import gob.bcb.jee.siodex.exception.DataException;

import java.util.Date;
import java.util.List;

import javax.ejb.Local;

@Local
public interface LiquidacionQLBeanLocal extends DAO<Liquidacion> {

	/**
	 * 
	 * @return
	 */
	
	public List<Liquidacion> listaLiquidacion(String estado);
	public Liquidacion getLiquidacion(String codigo);
	public Liquidacion cambioEstado(Liquidacion liquidacion, String observacion, String nuevoEstado) throws DataException;
	public Integer maxLote() ;
	public void actualizaLiquidacion(Liquidacion liquidacion)throws DataException;
	Liquidacion cambioEstado(Liquidacion liquidacion, String observacion, String nuevoEstado, LogAuditoria logAuditoria) throws DataException;
	List<Liquidacion> liquidacionesByEstadoNotif(String estado, String estadoNotif, Date fechaVenc, Date fechaHasta);
}
