package gob.bcb.jee.siodex.WS;

import gob.bcb.jee.siodex.exception.XMLException;
import gob.bcb.jee.siodex.util.XMLTools;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.security.InvalidParameterException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 * Clase utilitaria para el manejo de documentos xml.
 * 
 * @author scriales
 * 
 */
public class XmlUtil {
	public static Document getDomFromString(String xmlSource) throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setIgnoringElementContentWhitespace(true);
		factory.setNamespaceAware(true);
		DocumentBuilder builder = factory.newDocumentBuilder();
		return builder.parse(new InputSource(new StringReader(xmlSource)));
	}

	public static String getStringFromDom(Document doc) throws TransformerException {
		if (null == doc) {
			throw new InvalidParameterException("Objeto Document proporcionado es null.");
		}

		DOMSource domSource = new DOMSource(doc);
		StringWriter writer = new StringWriter();
		StreamResult result = new StreamResult(writer);
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = tf.newTransformer();
		transformer.setOutputProperty(OutputKeys.ENCODING, "ISO-8859-1");
		transformer.transform(domSource, result);
		return writer.toString();
	}

	public static Document stringXMLToDocument(String mensajeXML) throws XMLException {
		return XMLTools.stringXMLToDocument(mensajeXML);
	}

}