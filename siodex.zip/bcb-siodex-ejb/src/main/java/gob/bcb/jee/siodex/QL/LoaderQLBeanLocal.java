package gob.bcb.jee.siodex.QL;


import gob.bcb.jee.siodex.entities.Loader;
import gob.bcb.jee.siodex.exception.DataException;

import javax.ejb.Local;

@Local
public interface LoaderQLBeanLocal {

	/**
	 * 
	 * @return
	 */
	void edit(Loader solicitud);
	void create(Loader solicitud);
	//public List<Loader> listaLoader();
	//public Loader getLoader(Integer codigo);
	public Integer getCodigo() throws DataException;
	Integer maxNroSwift();
	
}
