/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author CUriona
 */
@Embeddable
public class DatosAdicionalesPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 15)
    @Column(name = "LO_NO")
    private String loNo;
    @Basic(optional = false)
    @NotNull
    @Column(name = "TRA_NO")
    private int traNo;

    public DatosAdicionalesPK() {
    }

    public DatosAdicionalesPK(String loNo, int traNo) {
        this.loNo = loNo;
        this.traNo = traNo;
    }

    public String getLoNo() {
        return loNo;
    }

    public void setLoNo(String loNo) {
    	this.loNo = loNo;
    }

    public int getTraNo() {
        return traNo;
    }

    public void setTraNo(int traNo) {
        this.traNo = traNo;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (loNo != null ? loNo.hashCode() : 0);
        hash += (int) traNo;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof DatosAdicionalesPK)) {
            return false;
        }
        DatosAdicionalesPK other = (DatosAdicionalesPK) object;
        if ((this.loNo == null && other.loNo != null) || (this.loNo != null && !this.loNo.equals(other.loNo))) {
            return false;
        }
        if (this.traNo != other.traNo) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gob.bcb.siodex.entities.DatosAdicionalesPK[ loNo=" + loNo + ", traNo=" + traNo + " ]";
    }
    
}
