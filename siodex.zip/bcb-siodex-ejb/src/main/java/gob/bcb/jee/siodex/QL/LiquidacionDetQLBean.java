package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.Liquidacion;
import gob.bcb.jee.siodex.entities.LiquidacionDet;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJBException;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

@Stateless
@LocalBean
public class LiquidacionDetQLBean extends DaoGeneric<LiquidacionDet> implements LiquidacionDetQLBeanLocal {

	static final Logger logger = Logger.getLogger(LiquidacionDetQLBean.class);

	@PersistenceContext(unitName = "siodex")
	EntityManager em;

	/**
	 * Default constructor.
	 */

	public LiquidacionDetQLBean() {
		// TODO Auto-generated constructor stub
		super(LiquidacionDet.class);	
		}

	
	@SuppressWarnings("unchecked")
	public List<LiquidacionDet> listaLiquidacion(String codigo) {

		List<LiquidacionDet> lista = new ArrayList<LiquidacionDet>();

		StringBuilder query = new StringBuilder();

		query.append("select l from LiquidacionDet l where l.liquidacionDetPK.liqCodigo = ?");

		Query consulta = em.createQuery(query.toString());
		consulta.setParameter(1, codigo);

		lista = consulta.getResultList();

		return lista;

	}

	@SuppressWarnings("rawtypes")
	public LiquidacionDet getLiquidacion(String codigo, String det) {

		LiquidacionDet liq = null;

		StringBuilder query = new StringBuilder();

		query.append("select l from LiquidacionDet l where l.liquidacionDetPK.liqCodigo = ? and l.liquidacionDetPK.liqDetalle = ?");

		Query consulta = em.createQuery(query.toString());
		consulta.setParameter(1, codigo);
		consulta.setParameter(2, det);

		List lista = consulta.getResultList();
		if (lista.size() > 0) {
			return (LiquidacionDet) lista.get(0);
		}

		return liq;

	}
	
	public LiquidacionDet getLiquidacionInstancia(String codigo, String prestamo, int tramo) {

		LiquidacionDet liq = null;

		StringBuilder query = new StringBuilder();

		query.append("select l from LiquidacionDet l where l.liquidacionDetPK.liqCodigo = ? and l.pinPrestamo = ? and l.pinTramo = ? ");

		Query consulta = em.createQuery(query.toString());
		consulta.setParameter(1, codigo);
		consulta.setParameter(2, prestamo);
		consulta.setParameter(3, tramo);

		liq = (LiquidacionDet) consulta.getSingleResult();

		return liq;

	}
	
	/**
	 * Actualiza principalmente el tipo de cambio, el cual es tcMO / TCCompra
	 */
	public LiquidacionDet actualizar(LiquidacionDet liquidacionDet) {
		LiquidacionDet liquidacionDetOld = getLiquidacion(liquidacionDet.getLiquidacionDetPK().getLiqCodigo(), liquidacionDet.getLiquidacionDetPK().getLiqDetalle());
		liquidacionDetOld.setTipoCambio(liquidacionDet.getTipoCambio());
		liquidacionDetOld.setTipoCambiomo(liquidacionDet.getTipoCambiomo());
		
		edit(liquidacionDetOld);
		return liquidacionDetOld;
	}
	
	@Override
	public void setEntityManager(EntityManager entityManager) {
		// TODO Auto-generated method stub
	}

	@Override
	public EntityManager getEntityManager() {
		// TODO Auto-generated method stub
		return em;
	}

}
