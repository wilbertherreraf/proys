package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.LoanTrancheSummary;
import gob.bcb.jee.siodex.exception.DataException;
import gob.bcb.jee.siodex.pojos.VcDatosAdic;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

@Stateless
@LocalBean
public class DAQLBean implements DAQLBeanLocal {

	static final Logger logger = Logger.getLogger(DAQLBean.class);

	@PersistenceContext(unitName = "dms1")
	EntityManager em;

	@Inject
	private LTSQLBeanLocal ltsQLBeanLocal;

	/**
	 * Default constructor.
	 */
	public DAQLBean() {
		// TODO Auto-generated constructor stub
	}


	@Override
	public Object[] nativo(String query) {

		Object[] datosA = null;

		logger.info("[DMS1]query a ejecutar: " + query);
		try{
			datosA = (Object[]) em.createNativeQuery(query).getSingleResult();
		} catch (NoResultException e) {
			logger.warn("Query sin resultados:: " + query);
		}

		//datosA = (Object[]) em.createNativeQuery(query).getResultList();

		return datosA;

	}

	/**
	 * Método que genera consulta.
	 * @query Consulta enviada.
	 */
	public Object obtieneValorConsulta(String query) {

		//	Instancia objeto.
		Object datosA = null;

		// Escribe en el log del sistema.
		logger.info("[DMS1]query a ejecutar: " + query);
		try{
			// Obtiene consulta enviada.
			datosA =  em.createNativeQuery(query).getSingleResult();
		} catch (NoResultException e) {
			// Escribe en el log del sistema.
			logger.warn("Query sin resultados:: " + query);
		}
		// Retorna resultado
		return datosA;
	}

	public Integer nativoSimple(String query) {

		Integer dato = 0;
		BigDecimal datoB = BigDecimal.valueOf(0);

		logger.info("query a ejecutar: " + query);
		datoB = (BigDecimal) em.createNativeQuery(query).getSingleResult();
		dato = datoB.intValue();

		return dato;

	}
	public Map<String, Object> comisionEInteres(String prestamo, int tramo, String fecha, String tipo) {
		List<LoanTrancheSummary> loanTrancheSummaryList = new ArrayList<LoanTrancheSummary>();
		logger.info("XXX: [DMS1] prestamosByEntidad");

		StringBuilder jsql = new StringBuilder();
		jsql.append(" SELECT ");
		jsql.append(" scp_id, amt_unpaid ");
		jsql.append(" FROM dmfas.sch_com_pmts ");
		jsql.append(" WHERE lo_no = '" + prestamo + "'");
		jsql.append(" and d_sch = to_date('" + fecha + "', 'yyyy-mm-dd')");
		jsql.append(" and cd_trns_typ = '" + tipo + "'");

		Query query = em.createNativeQuery(jsql.toString());
		List phones = query.getResultList();
		Iterator it = phones.iterator();

		try {

			while (it.hasNext()) {
				Object[] result = (Object[]) it.next();
				String codPrestamo = (String) result[0];
				BigDecimal codTramo = (BigDecimal) result[1];
				Integer trancheNo = Integer.valueOf(codTramo.toPlainString());
				String loanId = String.valueOf(codPrestamo);
				LoanTrancheSummary loanTrancheSummary = ltsQLBeanLocal.listaLoanTrancheSummary(loanId, trancheNo);
				loanTrancheSummaryList.add(loanTrancheSummary);
			}
		} catch (Exception e) {
			logger.error("XXX: error " + e.getMessage(), e);
		}

		return null;
	}

	public List<LoanTrancheSummary> prestamosByEntidad(String codEntidad) {
		List<LoanTrancheSummary> loanTrancheSummaryList = new ArrayList<LoanTrancheSummary>();
		logger.info("XXX: [DMS1] prestamosByEntidad");

		StringBuilder jsql = new StringBuilder();
		jsql.append("");
		jsql.append(" SELECT lo_no, tra_no,proveedor");
		jsql.append(" FROM reportes.vc_datos_adic ");
		jsql.append(" WHERE sigla_prov = '" + codEntidad + "'");

		Query query = em.createNativeQuery(jsql.toString());
		List phones = query.getResultList();
		Iterator it = phones.iterator();

		try {

			while (it.hasNext()) {
				Object[] result = (Object[]) it.next();
				String codPrestamo = (String) result[0];
				BigDecimal codTramo = (BigDecimal) result[1];
				Integer trancheNo = Integer.valueOf(codTramo.toPlainString());
				String loanId = String.valueOf(codPrestamo);
				LoanTrancheSummary loanTrancheSummary = ltsQLBeanLocal.listaLoanTrancheSummary(loanId, trancheNo);
				loanTrancheSummaryList.add(loanTrancheSummary);
			}
		} catch (Exception e) {
			logger.error("XXX: error " + e.getMessage(), e);
		}

		return loanTrancheSummaryList;
	}
	public List<VcDatosAdic> obtenerResumenDatGrales(String prestamo, Integer tramo) throws DataException {

		List<VcDatosAdic> vcDatosAdicLista = new ArrayList<VcDatosAdic>();
		try {
			StringBuilder jSql = new StringBuilder();
			jSql.append("");
			// jSql.append(" SELECT v ");
			jSql.append("Select LO_NO,TRA_NO,MONEDA,FECHA_DE_FIRMA,DURACION,							");
			jSql.append("PROYECTO,LEY,MONEDA_ORIGEN,MONTO,REF_ACREEDOR,FINEX,                   ");
			jSql.append("TIPO_ACREEDOR,PAIS,ACREEDOR,TIPO_INST_ACRE,GRUPO_ACREEDOR,             ");
			jSql.append("ACREEDOR_PAIS,SECTOR_ECONOMICO,UBICACION,TIPO_INST,                    ");
			jSql.append("SIGLA_PROV,PROVEEDOR,EJECUTOR,TIPO_DEUDOR,GRUPO_PROV,CATEGORIA_INTERES,");
			jSql.append("INTERES,TASA,TERM_CREDITO,SITUACION,FUENTE,FUENTE1,PLAZO               ");
			jSql.append(" FROM reportes.vc_datos_adic v ");

			if (!StringUtils.isBlank(prestamo)){
				jSql.append(" WHERE lo_no = '" + prestamo + "'");
				jSql.append(" and tra_no = " + tramo);
			}
			//logger.info("Query dat adic : " + jSql.toString());
			Query query = em.createNativeQuery(jSql.toString());
			List lista = query.getResultList();
			Iterator it = lista.iterator();

			while (it.hasNext()) {
				Object[] result = (Object[]) it.next();

				String loNo = (String) result[0];
				BigDecimal traNo1 = (BigDecimal) result[1];

				Integer traNo = Integer.valueOf(traNo1.toPlainString());
				String moneda = (String) result[2];
				Date fechaDeFirma = (Date) result[3];
				String duracion = (String) result[4];
				String proyecto = (String) result[5];
				String ley = (String) result[6];
				String monedaOrigen = (String) result[7];
				BigDecimal monto = (BigDecimal) result[8];
				String refAcreedor = (String) result[9];
				String finex = (String) result[10];
				String tipoAcreedor = (String) result[11];
				String pais = (String) result[12];
				String acreedor = (String) result[13];
				String tipoInstAcre = (String) result[14];
				String grupoAcreedor = (String) result[15];
				String acreedorPais = (String) result[16];
				String sectorEconomico = (String) result[17];
				String ubicacion = (String) result[18];
				String tipoInst = (String) result[19];
				String siglaProv = (String) result[20];
				String proveedor = (String) result[21];
				String ejecutor = (String) result[22];
				String tipoDeudor = (String) result[23];
				String grupoProv = (String) result[24];
				String categoriaInteres = (String) result[25];
				String interes = (String) result[26];
				BigDecimal tasa = (BigDecimal) result[27];
				String termCredito = (String) result[28];
				String situacion = (String) result[29];
				String fuente = (String) result[30];
				String fuente1 = (String) result[31];
				String plazo = (String) result[32];

				VcDatosAdic vcDatosAdic = new VcDatosAdic(loNo, traNo, moneda, fechaDeFirma, duracion, proyecto, ley, monedaOrigen, monto, refAcreedor, finex, tipoAcreedor, pais, acreedor, tipoInstAcre, grupoAcreedor, acreedorPais, sectorEconomico, ubicacion, tipoInst, siglaProv, proveedor, ejecutor, tipoDeudor, grupoProv, categoriaInteres, interes, tasa, termCredito, situacion, fuente, fuente1, plazo, null);
				vcDatosAdicLista.add(vcDatosAdic);
			}
		} catch (Exception e) {
			logger.error("Error en recuperar datos DMS1: " + e.getMessage());
			throw new DataException("Error al recuperar datos venc " + e.getMessage());
		}
		return vcDatosAdicLista;

	}

	public static void main(String[] args) {
		BigDecimal codTramo = BigDecimal.valueOf(10);
		Integer trancheNo = Integer.valueOf(codTramo.toPlainString());
		System.out.println("=========wwwwwwww " + trancheNo);
	}
}
