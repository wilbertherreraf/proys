package gob.bcb.jee.siodex.entities;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by pali on 15/02/2017.
 */
@Entity
@Table(name = "SCH_DEBT_SERV_PMTS")
@XmlRootElement
public class SchDebtServPmts implements Serializable {

    // Propiedad  tiempo de ejecución para la serialización.
    private static final long serialVersionUID = 1L;

    @Id
    @NotNull
    @Column(name = "sdsp_id", updatable = false)
    private Integer sdspId;

    @Size(min = 1, max = 15)
    @Column(name = "lo_no", nullable = false, length = 15)
    private String loNo;

    @Column(name = "tra_no", nullable = false)
    private int traNo;

    @Column(name = "cg_trns_typ", nullable = false)
    private int cgTrnsTyp;

    @Column(name = "cd_trns_typ", nullable = false, length = 10)
    private String cdTrnsTyp;

    @Column(name = "d_sch")
    @Temporal(TemporalType.DATE)
    private Date dSch;

    @Column(name = "sdsp_idp", nullable = false)
    private int sdspIdp;

    @Column(name = "amt", precision = 21, scale = 3)
    private BigDecimal amt;

    @Column(name = "tdsp_id", nullable = false)
    private int tdspId;

    @Column(name = "cg_sch_pmt_stat", nullable = false)
    private int cgSchPmtStat;

    @Column(name = "cd_sch_pmt_stat", nullable = false, length = 10)
    private String cdSchPmtStat;

    @Column(name = "amt_unpaid", precision = 21, scale = 3)
    private BigDecimal amtUnpaid;

    public void setSdspId(Integer sdspId) {
        this.sdspId = sdspId;
    }

    public void setLoNo(String loNo) {
        this.loNo = loNo;
    }

    public void setTraNo(int traNo) {
        this.traNo = traNo;
    }

    public void setCgTrnsTyp(int cgTrnsTyp) {
        this.cgTrnsTyp = cgTrnsTyp;
    }

    public void setCdTrnsTyp(String cdTrnsTyp) {
        this.cdTrnsTyp = cdTrnsTyp;
    }

    public void setdSch(Date dSch) {
        this.dSch = dSch;
    }

    public void setSdspIdp(int sdspIdp) {
        this.sdspIdp = sdspIdp;
    }

    public void setAmt(BigDecimal amt) {
        this.amt = amt;
    }

    public void setTdspId(int tdspId) {
        this.tdspId = tdspId;
    }

    public void setCgSchPmtStat(int cgSchPmtStat) {
        this.cgSchPmtStat = cgSchPmtStat;
    }

    public void setCdSchPmtStat(String cdSchPmtStat) {
        this.cdSchPmtStat = cdSchPmtStat;
    }

    public void setAmtUnpaid(BigDecimal amtUnpaid) {
        this.amtUnpaid = amtUnpaid;
    }

    public void setAmtOrderedUnpaid(BigDecimal amtOrderedUnpaid) {
        this.amtOrderedUnpaid = amtOrderedUnpaid;
    }

    public void setdPmtSch(Date dPmtSch) {
        this.dPmtSch = dPmtSch;
    }

    @Column(name = "amt_ordered_unpaid", precision = 21, scale = 3)
    private BigDecimal amtOrderedUnpaid;

    public Date getdPmtSch() {
        return dPmtSch;
    }

    public Integer getSdspId() {
        return sdspId;
    }

    public String getLoNo() {
        return loNo;
    }

    public int getTraNo() {
        return traNo;
    }

    public int getCgTrnsTyp() {
        return cgTrnsTyp;
    }

    public String getCdTrnsTyp() {
        return cdTrnsTyp;
    }

    public Date getdSch() {
        return dSch;
    }

    public int getSdspIdp() {
        return sdspIdp;
    }

    public BigDecimal getAmt() {
        return amt;
    }

    public int getTdspId() {
        return tdspId;
    }

    public int getCgSchPmtStat() {
        return cgSchPmtStat;
    }

    public String getCdSchPmtStat() {
        return cdSchPmtStat;
    }

    public BigDecimal getAmtUnpaid() {
        return amtUnpaid;
    }

    public BigDecimal getAmtOrderedUnpaid() {
        return amtOrderedUnpaid;
    }

    @Column(name = "d_pmt_sch")
    @Temporal(TemporalType.DATE)
    private Date dPmtSch;

    public SchDebtServPmts() {
        super();
    }

    @Override
    public String toString() {
        return "SchDebtServPmts{" +
                "sdspId=" + sdspId +
                ", loNo=" + loNo +
                ", traNo='" + traNo + '\'' +
                ", cgTrnsTyp='" + cgTrnsTyp + '\'' +
                ", cdTrnsTyp='" + cdTrnsTyp + '\'' +
                ", dSch='" + dSch + '\'' +
                ", sdspIdp='" + sdspIdp + '\'' +
                ", amt='" + amt + '\'' +
                ", tdspId='" + tdspId + '\'' +
                ", cgSchPmtStat='" + cgSchPmtStat + '\'' +
                ", cdSchPmtStat='" + cdSchPmtStat + '\'' +
                ", amtUnpaid='" + amtUnpaid + '\'' +
                ", amtOrderedUnpaid='" + amtOrderedUnpaid + '\'' +
                ", dPmtSch='" + dPmtSch + '\'' +
                '}';
    }
}
