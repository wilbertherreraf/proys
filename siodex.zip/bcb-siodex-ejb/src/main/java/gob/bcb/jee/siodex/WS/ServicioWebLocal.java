package gob.bcb.jee.siodex.WS;

/**
 * Interface que define los métodos de negocio para el procesamiento de
 * operaciones del TGN en el SIODEX; estos métodos son utilizados en un 
 * contexto de servicio web.
 * 
 * @author curiona
 * 
 */
public interface ServicioWebLocal
{
	public String consultaVencimientos(String mensaje) throws Exception;
	
	public String consultaVencimientosCorregidos(String mensaje) throws Exception;
	
	public String consultaPagos(String cod) throws Exception;
	
	public String alertaVencimientosObservados(Integer id, Integer fecha) throws Exception;
	
	public String alertaPagosAutorizados(Integer id, Integer fecha) throws Exception;
	
	public String recepcionObservados(String mensaje) throws Exception;
	
	public String recepcionAutorizados(String mensaje) throws Exception;	
}
