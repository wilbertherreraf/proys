/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author CUriona
 */
@Embeddable
public class SolDatoPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "sol_codigo", nullable = false)
    private Integer solCodigo;
    @Basic(optional = false)
    @NotNull
    @Column(name = "cod_dato", nullable = false)
    private String codDato;
        
    public SolDatoPK() {
    }

    public SolDatoPK(Integer solCodigo, String codDato) {
        this.solCodigo = solCodigo;
        this.codDato = codDato;
    }

    public Integer getSolCodigo() {
        return solCodigo;
    }

    public void setSolCodigo(Integer solCodigo) {
        this.solCodigo = solCodigo;
    }

    public String getCodDato() {
        return codDato;
    }

    public void setCodDato(String codDato) {
        this.codDato = codDato;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (solCodigo != null ? solCodigo.hashCode() : 0);
        hash += (codDato != null ? codDato.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SolDatoPK)) {
            return false;
        }
        SolDatoPK other = (SolDatoPK) object;
        if ((this.solCodigo == null && other.solCodigo != null) || (this.solCodigo != null && !this.solCodigo.equals(other.solCodigo))) {
            return false;
        }
        if ((this.codDato == null && other.codDato != null) || (this.codDato != null && !this.codDato.equals(other.codDato))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gob.bcb.siodex.entities.SoldatoPK[ solCodigo=" + solCodigo + ", codDato=" + codDato + " ]";
    }
    
}