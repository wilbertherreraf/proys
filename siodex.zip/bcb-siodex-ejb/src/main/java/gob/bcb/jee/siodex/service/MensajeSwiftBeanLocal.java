package gob.bcb.jee.siodex.service;

import java.util.List;

import gob.bcb.jee.siodex.entities.Datos;
import gob.bcb.jee.siodex.entities.Mensaje;
import gob.bcb.jee.siodex.entities.MensajeDatos;
import gob.bcb.jee.siodex.entities.Vencimiento;
import gob.bcb.jee.siodex.exception.DataException;

import javax.ejb.Local;

@Local
public interface MensajeSwiftBeanLocal {

	/**
	 * 
	 * @param men
	 * @return
	 */
	public String crearSwiftTexto(String codigo);
	List<MensajeDatos> crearSwift(Vencimiento vencimiento, Mensaje men, String ref, Integer nro, String ptm, Integer tramo, boolean conDocMov) throws DataException;
	List<MensajeDatos> crearSwift(Vencimiento vencimiento, Mensaje men, String ref, Integer nro, String ptm, Integer tramo, String codMov) throws DataException;
	List<Datos> getPretamoEsquema(String ptm, Integer tramo) throws DataException;
	String crearSwiftTexto(List<MensajeDatos> mensajeDatoslist);
	void actualizaCampo(Mensaje men, String campo, String ref, String ptm, Integer tramo) throws DataException;
	
}
