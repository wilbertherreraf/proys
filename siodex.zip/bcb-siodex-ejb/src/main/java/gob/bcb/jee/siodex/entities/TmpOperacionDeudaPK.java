/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;

/**
 *
 * @author CUriona
 */
@Embeddable
public class TmpOperacionDeudaPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 12)
    @Column(name = "deu_codigo", nullable = false, length = 12)
    private String deuCodigo;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 6)
    @Column(name = "ope_codigo", nullable = false, length = 6)
    private String opeCodigo;

    public TmpOperacionDeudaPK() {
    }

    public TmpOperacionDeudaPK(String deuCodigo, String opeCodigo) {
        this.deuCodigo = deuCodigo;
        this.opeCodigo = opeCodigo;
    }

    public String getDeuCodigo() {
        return deuCodigo;
    }

    public void setDeuCodigo(String deuCodigo) {
        this.deuCodigo = deuCodigo;
    }

    public String getOpeCodigo() {
        return opeCodigo;
    }

    public void setOpeCodigo(String opeCodigo) {
        this.opeCodigo = opeCodigo;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (deuCodigo != null ? deuCodigo.hashCode() : 0);
        hash += (opeCodigo != null ? opeCodigo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TmpOperacionDeudaPK)) {
            return false;
        }
        TmpOperacionDeudaPK other = (TmpOperacionDeudaPK) object;
        if ((this.deuCodigo == null && other.deuCodigo != null) || (this.deuCodigo != null && !this.deuCodigo.equals(other.deuCodigo))) {
            return false;
        }
        if ((this.opeCodigo == null && other.opeCodigo != null) || (this.opeCodigo != null && !this.opeCodigo.equals(other.opeCodigo))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gob.bcb.siodex.entities.TmpOperacionDeudaPK[ deuCodigo=" + deuCodigo + ", opeCodigo=" + opeCodigo + " ]";
    }
    
}