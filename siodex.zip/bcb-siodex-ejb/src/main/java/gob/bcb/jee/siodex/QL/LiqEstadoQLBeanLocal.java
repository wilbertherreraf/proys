package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.LiquidacionEstado;

import javax.ejb.Local;

@Local
public interface LiqEstadoQLBeanLocal {

	/**
	 * 
	 * @return
	 */
	void edit(LiquidacionEstado liqEstado);
	void create(LiquidacionEstado liqEstado);
	void remove(LiquidacionEstado liqEstado);
	public LiquidacionEstado getLiqEstado(String codigo, String estado);
	public LiquidacionEstado liqObservado(String liqCodigo, String cveEstado) ;	
}
