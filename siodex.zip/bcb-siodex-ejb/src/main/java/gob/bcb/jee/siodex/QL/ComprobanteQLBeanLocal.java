package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.Comprobante;
import gob.bcb.jee.siodex.exception.DataException;

import java.util.List;

import javax.ejb.Local;

@Local
public interface ComprobanteQLBeanLocal {

	/**
	 * 
	 * @return
	 * @throws DataException 
	 */
	public List<Comprobante> listaComprobante(Integer codigo) throws DataException;
	
	public void ajustarComprobante(Integer codigo) throws DataException;

	List<Comprobante> listaComprobanteAdic(Integer codigo) throws DataException;
	
}
