
package gob.bcb.jee.siodex.clientsigmaws.consultas;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the gob.bcb.jee.siodex.clientsigmaws.consultas package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _RecepcionConfirmacion_QNAME = new QName("http://mefp.gob.bo/itg", "RecepcionConfirmacion");
    private final static QName _RecepcionVencimientos_QNAME = new QName("http://mefp.gob.bo/itg", "RecepcionVencimientos");
    private final static QName _RecepcionVencimientosResponse_QNAME = new QName("http://mefp.gob.bo/itg", "RecepcionVencimientosResponse");
    private final static QName _RecepcionConfirmacionResponse_QNAME = new QName("http://mefp.gob.bo/itg", "RecepcionConfirmacionResponse");
    private final static QName _RecepcionCorreccionesResponse_QNAME = new QName("http://mefp.gob.bo/itg", "RecepcionCorreccionesResponse");
    private final static QName _RecepcionCorrecciones_QNAME = new QName("http://mefp.gob.bo/itg", "RecepcionCorrecciones");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: gob.bcb.jee.siodex.clientsigmaws.consultas
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link RecepcionCorrecciones }
     * 
     */
    public RecepcionCorrecciones createRecepcionCorrecciones() {
        return new RecepcionCorrecciones();
    }

    /**
     * Create an instance of {@link RecepcionVencimientos }
     * 
     */
    public RecepcionVencimientos createRecepcionVencimientos() {
        return new RecepcionVencimientos();
    }

    /**
     * Create an instance of {@link RecepcionVencimientosResponse }
     * 
     */
    public RecepcionVencimientosResponse createRecepcionVencimientosResponse() {
        return new RecepcionVencimientosResponse();
    }

    /**
     * Create an instance of {@link RecepcionConfirmacion }
     * 
     */
    public RecepcionConfirmacion createRecepcionConfirmacion() {
        return new RecepcionConfirmacion();
    }

    /**
     * Create an instance of {@link RecepcionCorreccionesResponse }
     * 
     */
    public RecepcionCorreccionesResponse createRecepcionCorreccionesResponse() {
        return new RecepcionCorreccionesResponse();
    }

    /**
     * Create an instance of {@link RecepcionConfirmacionResponse }
     * 
     */
    public RecepcionConfirmacionResponse createRecepcionConfirmacionResponse() {
        return new RecepcionConfirmacionResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RecepcionConfirmacion }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://mefp.gob.bo/itg", name = "RecepcionConfirmacion")
    public JAXBElement<RecepcionConfirmacion> createRecepcionConfirmacion(RecepcionConfirmacion value) {
        return new JAXBElement<RecepcionConfirmacion>(_RecepcionConfirmacion_QNAME, RecepcionConfirmacion.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RecepcionVencimientos }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://mefp.gob.bo/itg", name = "RecepcionVencimientos")
    public JAXBElement<RecepcionVencimientos> createRecepcionVencimientos(RecepcionVencimientos value) {
        return new JAXBElement<RecepcionVencimientos>(_RecepcionVencimientos_QNAME, RecepcionVencimientos.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RecepcionVencimientosResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://mefp.gob.bo/itg", name = "RecepcionVencimientosResponse")
    public JAXBElement<RecepcionVencimientosResponse> createRecepcionVencimientosResponse(RecepcionVencimientosResponse value) {
        return new JAXBElement<RecepcionVencimientosResponse>(_RecepcionVencimientosResponse_QNAME, RecepcionVencimientosResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RecepcionConfirmacionResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://mefp.gob.bo/itg", name = "RecepcionConfirmacionResponse")
    public JAXBElement<RecepcionConfirmacionResponse> createRecepcionConfirmacionResponse(RecepcionConfirmacionResponse value) {
        return new JAXBElement<RecepcionConfirmacionResponse>(_RecepcionConfirmacionResponse_QNAME, RecepcionConfirmacionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RecepcionCorreccionesResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://mefp.gob.bo/itg", name = "RecepcionCorreccionesResponse")
    public JAXBElement<RecepcionCorreccionesResponse> createRecepcionCorreccionesResponse(RecepcionCorreccionesResponse value) {
        return new JAXBElement<RecepcionCorreccionesResponse>(_RecepcionCorreccionesResponse_QNAME, RecepcionCorreccionesResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RecepcionCorrecciones }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://mefp.gob.bo/itg", name = "RecepcionCorrecciones")
    public JAXBElement<RecepcionCorrecciones> createRecepcionCorrecciones(RecepcionCorrecciones value) {
        return new JAXBElement<RecepcionCorrecciones>(_RecepcionCorrecciones_QNAME, RecepcionCorrecciones.class, null, value);
    }

}
