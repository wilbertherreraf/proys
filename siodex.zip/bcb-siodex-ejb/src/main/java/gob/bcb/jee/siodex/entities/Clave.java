package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the clave database table.
 * 
 */
@Entity
@Table(name="clave")
public class Clave implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="cve_codigo")
	private String cveCodigo;

	@Column(name="cve_nombre")
	private String cveNombre;

	private String estacion;

	@Column(name="fecha_hora")
	private Timestamp fechaHora;

	@Column(name="usr_codigo")
	private String usrCodigo;

    public Clave() {
    }

	public String getCveCodigo() {
		return this.cveCodigo;
	}

	public void setCveCodigo(String cveCodigo) {
		this.cveCodigo = cveCodigo;
	}

	public String getCveNombre() {
		return this.cveNombre;
	}

	public void setCveNombre(String cveNombre) {
		this.cveNombre = cveNombre;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Timestamp getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Timestamp fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getUsrCodigo() {
		return this.usrCodigo;
	}

	public void setUsrCodigo(String usrCodigo) {
		this.usrCodigo = usrCodigo;
	}

}