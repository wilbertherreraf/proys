package gob.bcb.jee.siodex.QL;

import java.util.List;

import gob.bcb.jee.siodex.entities.Cuenta;
import gob.bcb.jee.siodex.entities.CuentaAcreedor;
import gob.bcb.jee.siodex.exception.DataException;

import javax.ejb.Local;

@Local
public interface CuentaQLBeanLocal {

	/**
	 * 
	 * @return
	 */
	
	List<Cuenta> cuentasPrestamo(String ptmCodigo, Integer traCodigo, String titular) throws DataException;

	CuentaAcreedor getCuentaAcreedor(String acr_codigo, String mon_swift) throws DataException;

	List<Cuenta> getCuentas(String ptmCodigo, Integer traCodigo, String titular, String codCuenta) throws DataException;

	Cuenta getCuenta(String ptmCodigo, Integer traCodigo, String titular, String codCuenta) throws DataException;

	Cuenta getCuenta(String codCuenta) throws DataException;

}
