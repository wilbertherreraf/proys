package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.LiquidacionReng;
import gob.bcb.jee.siodex.entities.Renglon;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJBException;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;


@Stateless
@LocalBean
public class LiquidacionRengQLBean implements LiquidacionRengQLBeanLocal {

	static final Logger logger = Logger.getLogger(LiquidacionRengQLBean.class);
	
	@PersistenceContext(unitName = "siodex")
	EntityManager em;
	
	/**
	 * Default constructor.
	 */
	public LiquidacionRengQLBean() {

	}
	
	@SuppressWarnings("unchecked")
	public List<Renglon> listaLiquidacionReng(String codigo, String det, String tipo) {

		String conc = "";
		String concepto = "";
		List<LiquidacionReng> lista = new ArrayList<LiquidacionReng>();
		List<Renglon> listaR = new ArrayList<Renglon>();

		try {

			StringBuilder query = new StringBuilder();
			
			query.append("select l from LiquidacionReng l where l.liquidacionRengPK.liqCodigo = ? ");
			query.append("and l.liquidacionRengPK.liqDetalle = ? and l.tipoLiq = ? order by l.fechaVenc");
			
			Query consulta = em.createQuery(query.toString());
			
			consulta.setParameter(1, codigo);
			consulta.setParameter(2, det);
			consulta.setParameter(3, tipo);
			
			lista = consulta.getResultList();
			
			for (LiquidacionReng reng : lista) {
				
				conc = reng.getCveConcepto();
				if (conc.equals("S1") || conc.equals("SI")) {
					concepto = "SALDO ADEUDADO INICIAL";
				}
				else {
					if (conc.equals("S2") || conc.equals("SF")) {
						concepto = "SALDO ADEUDADO FINAL";
					}
					else {
						if (conc.equals("SS")) {
							concepto = "SALDO ADEUDADO";
						}
						else {
							if (conc.equals("P")) {
								concepto = "PAGO";
							}
							else {
								if (conc.equals("D")) {
									concepto = "DESEMBOLSO";
								}
							}
						}
					}
				}
				
				Renglon rr = new Renglon (reng.getLiquidacionRengPK().getLiqCodigo(), reng.getLiquidacionRengPK().getLiqDetalle(), 
						reng.getLiquidacionRengPK().getLiqRenglon(), concepto, reng.getFechaValor(), reng.getMontoMo(),
						reng.getTasa(), reng.getDias(), reng.getCalculoMo(), reng.getTipoLiq(), reng.getFechaVenc(), reng.getAnio(), 
						reng.getImprimir());
				
				listaR.add(rr);
			
			}
			
		} catch (EJBException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return listaR;

	}
	
	@SuppressWarnings("unchecked")
	public List<Renglon> listaLiquidacionReng1(String codigo, String det, String tipo) {

		String conc = "";
		String concepto = "";
		List<LiquidacionReng> lista = new ArrayList<LiquidacionReng>();
		List<Renglon> listaR = new ArrayList<Renglon>();

		try {

			StringBuilder query = new StringBuilder();
			
			query.append("select l from LiquidacionReng l where l.liquidacionRengPK.liqCodigo = ? ");
			query.append("and l.liquidacionRengPK.liqDetalle = ? and l.tipoLiq = ? order by l.fechaVenc");
			
			Query consulta = em.createQuery(query.toString());
			
			consulta.setParameter(1, codigo);
			consulta.setParameter(2, det);
			consulta.setParameter(3, tipo);
			
			lista = consulta.getResultList();
			
			for (LiquidacionReng reng : lista) {
				
				conc = reng.getCveConcepto();
				if (conc.equals("S1") || conc.equals("SI")) {
					concepto = "SALDO POR DESEMBOLSAR INICIAL";
				}
				else {
					if (conc.equals("S2") || conc.equals("SF")) {
						concepto = "SALDO POR DESEMBOLSAR FINAL";
					}
					else {
						if (conc.equals("SS")) {
							concepto = "SALDO POR DESEMBOLSAR";
						}
						else {
							if (conc.equals("P")) {
								concepto = "PAGO";
							}
							else {
								if (conc.equals("D")) {
									concepto = "DESEMBOLSO";
								}
							}
						}
					}
				}
				
				Renglon rr = new Renglon (reng.getLiquidacionRengPK().getLiqCodigo(), reng.getLiquidacionRengPK().getLiqDetalle(), 
						reng.getLiquidacionRengPK().getLiqRenglon(), concepto, reng.getFechaValor(), reng.getMontoMo(),
						reng.getTasa(), reng.getDias(), reng.getCalculoMo(), reng.getTipoLiq(), reng.getFechaVenc(), reng.getAnio(), 
						reng.getImprimir());
				
				listaR.add(rr);
			
			}
			
		} catch (EJBException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return listaR;

	}
	
}
