/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Blob;
import java.util.Date;
import java.util.List;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 * 
 * @author CUriona
 */
@Entity
@Table(name = "solicitud")
@XmlRootElement
@NamedQueries({ @NamedQuery(name = "Solicitud.findAll", query = "SELECT s FROM Solicitud s"),
		@NamedQuery(name = "Solicitud.findBySolCodigo", query = "SELECT s FROM Solicitud s WHERE s.solCodigo = :solCodigo"),
		@NamedQuery(name = "Solicitud.findByCodLip", query = "SELECT s FROM Solicitud s WHERE s.codLip = :codLip"),
		@NamedQuery(name = "Solicitud.findByCodPart", query = "SELECT s FROM Solicitud s WHERE s.codPart = :codPart"),
		@NamedQuery(name = "Solicitud.findByGlosa", query = "SELECT s FROM Solicitud s WHERE s.glosa = :glosa"),
		@NamedQuery(name = "Solicitud.findByFecha", query = "SELECT s FROM Solicitud s WHERE s.fecha = :fecha") })
public class Solicitud implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@Basic(optional = false)
	@NotNull
	@Column(name = "sol_codigo", nullable = false)
	private Integer solCodigo;
	@Basic(optional = false)
	@NotNull
	@Column(name = "log_auditoria_id", nullable = false)
	private Integer logAuditoriaId;
	@NotNull
	@Column(name = "cod_lip", nullable = false)
	private String codLip;
	@NotNull
	@Column(name = "cod_part", nullable = false)
	private String codPart;
	@Column(name = "glosa")
	private String glosa;
	@Column(name = "fecha")
	@Temporal(TemporalType.DATE)
	private Date fecha;
	@NotNull
	@Column(name = "liq_codigo", nullable = false)
	private String liqCodigo;
	@NotNull
	@Column(name = "cve_estado", nullable = false)
	private String cveEstado;
	@NotNull
	@Column(name = "moneda", nullable = false)
	private String moneda;
	@Column(name = "cod_part_des")
	private String codPartDes;
	@Column(name = "moneda_des")
	private String monedaDes;
	// @OneToMany(cascade = CascadeType.ALL, mappedBy = "solicitud")
	// private List<SolDato> solDatoList;

//	@Column(name = "capital_usd")
//	private BigDecimal capitalUsd;
//	@Column(name = "interes_usd")
//	private BigDecimal interesUsd;
//	@Column(name = "comision_usd")
//	private BigDecimal comisionUsd;
//	@Temporal(TemporalType.DATE)
//	@Column(name = "fecha_tc")
//	private Date fechaTc;
	
	@Column(name = "comprob_id")
	private Integer comprobId;
	
	@Column(name = "usr_codigo")
	private String usrCodigo;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "fecha_hora")
	private Date fechaHora;
	@Column(name = "estacion")
	private String estacion;

	public Solicitud() {
	}

	public Solicitud(Integer solCodigo) {
		this.solCodigo = solCodigo;
	}

	public Solicitud(Integer solCodigo, Integer logAuditoriaId, String codLip, String codPart, String glosa, Date fecha, String liqCodigo,
			String cveEstado, String moneda, String codPartDes, String monedaDes) {
		super();
		this.solCodigo = solCodigo;
		this.logAuditoriaId = logAuditoriaId;
		this.codLip = codLip;
		this.codPart = codPart;
		this.glosa = glosa;
		this.fecha = fecha;
		this.liqCodigo = liqCodigo;
		this.cveEstado = cveEstado;
		this.moneda = moneda;
		this.codPartDes = codPartDes;
		this.monedaDes = monedaDes;
	}

	public Integer getSolCodigo() {
		return solCodigo;
	}

	public void setSolCodigo(Integer solCodigo) {
		this.solCodigo = solCodigo;
	}

	public String getCodLip() {
		return codLip;
	}

	public void setCodLip(String codLip) {
		this.codLip = codLip;
	}

	public String getCodPart() {
		return codPart;
	}

	public void setCodPart(String codPart) {
		this.codPart = codPart;
	}

	public String getGlosa() {
		return glosa;
	}

	public void setGlosa(String glosa) {
		this.glosa = glosa;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public String getLiqCodigo() {
		return liqCodigo;
	}

	public void setLiqCodigo(String liqCodigo) {
		this.liqCodigo = liqCodigo;
	}

	public String getCveEstado() {
		return cveEstado;
	}

	public void setCveEstado(String cveEstado) {
		this.cveEstado = cveEstado;
	}

	public String getMoneda() {
		return moneda;
	}

	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	public String getCodPartDes() {
		return codPartDes;
	}

	public void setCodPartDes(String codPartDes) {
		this.codPartDes = codPartDes;
	}

	public String getMonedaDes() {
		return monedaDes;
	}

	public void setMonedaDes(String monedaDes) {
		this.monedaDes = monedaDes;
	}

	public Integer getLogAuditoriaId() {
		return logAuditoriaId;
	}

	public void setLogAuditoriaId(Integer logAuditoriaId) {
		this.logAuditoriaId = logAuditoriaId;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getUsrCodigo() {
		return usrCodigo;
	}

	public void setUsrCodigo(String usrCodigo) {
		this.usrCodigo = usrCodigo;
	}

	public Date getFechaHora() {
		return fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getEstacion() {
		return estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Integer getComprobId() {
		return comprobId;
	}

	public void setComprobId(Integer comprobId) {
		this.comprobId = comprobId;
	}

	@Override
	public String toString() {
		return "Solicitud [solCodigo=" + solCodigo + ", logAuditoriaId=" + logAuditoriaId + ", codLip=" + codLip + ", codPart=" + codPart
				+ ", glosa=" + glosa + ", fecha=" + fecha + ", liqCodigo=" + liqCodigo + ", cveEstado=" + cveEstado + ", moneda=" + moneda
				+ ", codPartDes=" + codPartDes + ", monedaDes=" + monedaDes + ", comprobId=" + comprobId + ", usrCodigo=" + usrCodigo
				+ ", fechaHora=" + fechaHora + ", estacion=" + estacion + "]";
	}
}
