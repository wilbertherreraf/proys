/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author CUriona
 */
@Entity
@Table(name = "LOAN_TRANCHE_SUMMARY")
@NamedQueries({
    @NamedQuery(name = "LoanTrancheSummary.findAll", query = "SELECT l FROM LoanTrancheSummary l"),
    @NamedQuery(name = "LoanTrancheSummary.findByLoanId", query = "SELECT l FROM LoanTrancheSummary l WHERE l.loanTrancheSummaryPK.loanId = :loanId"),
    @NamedQuery(name = "LoanTrancheSummary.findByTrancheNo", query = "SELECT l FROM LoanTrancheSummary l WHERE l.loanTrancheSummaryPK.trancheNo = :trancheNo")})
public class LoanTrancheSummary implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected LoanTrancheSummaryPK loanTrancheSummaryPK;
    @Size(max = 30)
    @Column(name = "NAME")
    private String name;
    @Size(max = 20)
    @Column(name = "CREDITOR_REF")
    private String creditorRef;
    @Size(max = 60)
    @Column(name = "CREDITOR_NAME")
    private String creditorName;

    public LoanTrancheSummary() {
    }

    public LoanTrancheSummary(LoanTrancheSummaryPK loanTrancheSummaryPK) {
        this.loanTrancheSummaryPK = loanTrancheSummaryPK;
    }

    public LoanTrancheSummary(LoanTrancheSummaryPK loanTrancheSummaryPK, String name, String creditorRef, String creditorName) {
        this.loanTrancheSummaryPK = loanTrancheSummaryPK;
        this.name = name;
        this.creditorRef = creditorRef;
        this.creditorName = creditorName;
    }

    public LoanTrancheSummary(String loanId, short trancheNo) {
        this.loanTrancheSummaryPK = new LoanTrancheSummaryPK(loanId, trancheNo);
    }

    public LoanTrancheSummaryPK getLoanTrancheSummaryPK() {
        return loanTrancheSummaryPK;
    }

    public void setLoanTrancheSummaryPK(LoanTrancheSummaryPK loanTrancheSummaryPK) {
        this.loanTrancheSummaryPK = loanTrancheSummaryPK;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCreditorRef() {
        return creditorRef;
    }

    public void setCreditorRef(String creditorRef) {
        this.creditorRef = creditorRef;
    }

    public String getCreditorName() {
        return creditorName;
    }

    public void setCreditorName(String creditorName) {
        this.creditorName = creditorName;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (loanTrancheSummaryPK != null ? loanTrancheSummaryPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof LoanTrancheSummary)) {
            return false;
        }
        LoanTrancheSummary other = (LoanTrancheSummary) object;
        if ((this.loanTrancheSummaryPK == null && other.loanTrancheSummaryPK != null) || (this.loanTrancheSummaryPK != null && !this.loanTrancheSummaryPK.equals(other.loanTrancheSummaryPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "gob.bcb.siodex.entities.LoanTrancheSummary[ loanTrancheSummaryPK=" + loanTrancheSummaryPK + " ]";
    }
    
}
