package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.exception.DataException;
import org.apache.log4j.Logger;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Created by eborda on 16/02/2017.
 */
@Stateless
@LocalBean
public class BancoQLBean implements BancoQLBeanLocal {

    static final Logger logger = Logger.getLogger(BancoQLBean.class);

    @PersistenceContext(unitName = "siodex")
    EntityManager em;


    /**
     * Default constructor.
     */
    public BancoQLBean() {
        // TODO Auto-generated constructor stub
    }


    @Override
    public Object[] nativo(String query) {
        Object[] datos = null;

        try {
            logger.info("Consulta nativa en Siodex: " + query);
            datos = (Object[]) em.createNativeQuery(query).getSingleResult();
        } catch (Exception e) {
            logger.error("error al ejecutar consulta nativa: " + e.getMessage(), e);
        }

        return datos;
    }

    @Override
    public Object[] getBanco(String bcoCodigo) throws DataException {
        String query = "SELECT bco_nombre, bco_bic,bco_plaza FROM banco " + "WHERE bco_codigo = '" + bcoCodigo + "' ";

        Object[] datos = nativo(query);

        if (datos == null) {
            logger.error("Banco inexistente en Siodex para :" + bcoCodigo);
            throw new DataException("Banco inexistente en Siodex para :" + bcoCodigo);
        }

        return datos;
    }
}
