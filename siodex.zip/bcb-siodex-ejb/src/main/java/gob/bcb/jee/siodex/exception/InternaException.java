/**
 * InternaException.java
 *
 * Creado el 28 de mayo de 2003, 08:48 AM
 */

package gob.bcb.jee.siodex.exception;


/**
 * Crea una nueva instancia de <code>InternaException</code> sin mensaje.
 */
public class InternaException extends java.lang.Exception {

    /**
     * Crea una nueva instancia de <code>InternaException</code> sin mensaje.
     */
    public InternaException() {
    }


    /**
     * Construye una instancia de <code>InternaException</code> incluyendo el mensaje.
     * @param msg detalle del mensaje.
     */
    public InternaException(String msg) {
        super(msg);
    }
}
