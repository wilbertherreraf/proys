package gob.bcb.jee.siodex.service;

import gob.bcb.contabilidad.pojo.RastroContablePojo;
import gob.bcb.contabilidad.service.OperacionesContabilidadSrvBeanRemote;
import gob.bcb.contabilidad.util.ContabilidadException;
import gob.bcb.jee.siodex.util.Util;
import gob.bcb.jee.siodex.util.UtilsDate;

import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import org.apache.log4j.Logger;

/**
 * Clase que contiene los metodos para crear los campos de un mensaje swift.
 * 
 * @author C. Cecilia Uriona
 * 
 */
@Stateless
public class ConsultaBean implements ConsultaBeanLocal {

	static final Logger logger = Logger.getLogger(ConsultaBean.class);

	@Inject
	private Util util;

	/**
	 * Metodo que devuelve la lista de rstrso contables
	 * 
	 * @param pFecha
	 * @param pCveEstadoComprob
	 * @return
	 * @throws Exception 
	 */
	public List<RastroContablePojo> obtenerRastroContable(Date fecha) throws Exception {

		List<RastroContablePojo> lista = null;

		try {
			logger.info("Consultando lista de rastros para " + fecha);
			// obteniendo objeto del servicio
			OperacionesContabilidadSrvBeanRemote operacionesContabilidadSrvBeanRemote = util.consumirEJB(OperacionesContabilidadSrvBeanRemote.class);

			lista = operacionesContabilidadSrvBeanRemote.obtenerRastroContable(fecha, "SIODEX");
			
			logger.info("Lista recuperada " + lista.size());
			return lista;			
			
		} catch (ContabilidadException e) {
			logger.error("Error Motor Contable: se produjo ContabilidadException al obtenerRastroContable " + e.getMessage(), e);
			throw new Exception("Error Motor Contable: se produjo ContabilidadException al obtenerRastroContable " + e.getMessage());			
		} catch (Exception e) {
			logger.error("Error Motor Contable: se produjo Exception al obtenerRastroContable " + e.getMessage(), e);
			throw new Exception("Error Motor Contable: se produjo Exception al obtenerRastroContable " + e.getMessage());
		} catch (Throwable e) {
			logger.error("Error Motor Contable: se produjo Throwable al obtenerRastroContable " + e.getMessage(), e);
			throw new Exception("Error Motor Contable: se produjo Throwable al obtenerRastroContable " + e.getMessage());
		}
		

	}

	public RastroContablePojo obtenerRastroContable(Date fecha, Integer comprobID) throws Exception {
		logger.info("Consulta de registro " + UtilsDate.stringFromDate(fecha, "dd/MM/yyyy") + " comprobID: " + comprobID);
		
		RastroContablePojo rastroContable = null;
		
		if (comprobID == null){
			return rastroContable;
		}
			
		List<RastroContablePojo> listaRastro = obtenerRastroContable(fecha);
		if (listaRastro != null){
			for (RastroContablePojo rastroContablePojo : listaRastro) {
				if (rastroContablePojo.getNroOperacion() != null &&  rastroContablePojo.getComprobId() != null && rastroContablePojo.getComprobId().equals(comprobID)) {
					rastroContable = rastroContablePojo;
					logger.info("RastroContable existente!!! " + fecha + " nroOperacion: " + rastroContable.getNroOperacion() + " getComprobId(): " + rastroContable.getComprobId());				
					break;
				}
			}
			
		}
		
		if (rastroContable != null && rastroContable.getComprobId().compareTo(comprobID) == 0) {
			return rastroContable;			
		}
		return null;
	}
	public RastroContablePojo obtenerRastroContableByNroOperacion(Date fecha, Integer nroOperacion) throws Exception {
		logger.info("Consulta de registro " + UtilsDate.stringFromDate(fecha, "dd/MM/yyyy") + " nroOperacion: " + nroOperacion);
		
		RastroContablePojo rastroContable = null;
		List<RastroContablePojo> listaRastro = obtenerRastroContable(fecha);
		if (listaRastro != null){
			for (RastroContablePojo rastroContablePojo : listaRastro) {
				if (rastroContablePojo.getNroOperacion() != null &&  rastroContablePojo.getComprobId() != null && rastroContablePojo.getNroOperacion().equals(nroOperacion)) {
					rastroContable = rastroContablePojo;
					logger.info("RastroContable existente!!! " + fecha + " nroOperacion: " + nroOperacion + " getComprobId(): " + rastroContable.getComprobId());				
					break;
				}
			}
			
		}
		return rastroContable;
		
	}
	public static void main(String[] args) {
		Integer a = 1;
		Integer b = 1;
		Integer c = new Integer(1);
		
		System.out.println(c == b);
		System.out.println(c == 1);		
		System.out.println(b == 1);		
		System.out.println(c.equals(Integer.valueOf(1)));
		System.out.println(b.compareTo(Integer.valueOf(1)));
	}
}
