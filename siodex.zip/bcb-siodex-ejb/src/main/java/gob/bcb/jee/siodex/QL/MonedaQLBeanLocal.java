package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.Moneda;
import gob.bcb.jee.siodex.exception.DataException;

import javax.ejb.Local;

@Local
public interface MonedaQLBeanLocal {

	Moneda getMonedaCoin(String monSigade) throws DataException;

	Moneda getMoneda(String monSigade) throws DataException;

}
