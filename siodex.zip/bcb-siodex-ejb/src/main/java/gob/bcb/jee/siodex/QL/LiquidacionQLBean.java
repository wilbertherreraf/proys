package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.Liquidacion;
import gob.bcb.jee.siodex.entities.LiquidacionEstado;
import gob.bcb.jee.siodex.entities.LiquidacionEstadoPK;
import gob.bcb.jee.siodex.entities.LogAuditoria;
import gob.bcb.jee.siodex.exception.DataException;
import gob.bcb.jee.siodex.util.UtilsDate;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TemporalType;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

@Stateless
@LocalBean
// @TransactionManagement(TransactionManagementType.CONTAINER)
public class LiquidacionQLBean extends DaoGeneric<Liquidacion> implements LiquidacionQLBeanLocal {

	static final Logger logger = Logger.getLogger(LiquidacionQLBean.class);

	// @Inject
	@PersistenceContext(unitName = "siodex")
	EntityManager em;

	@Inject
	private LiqEstadoQLBeanLocal liqEstadoQLBeanLocal;

	@Inject
	private LogAuditoriaQLBeanLocal logQLBeanLocal;

	/**
	 * Default constructor.
	 */
	public LiquidacionQLBean() {
		// TODO Auto-generated constructor stub
		super(Liquidacion.class);
	}

	@SuppressWarnings("unchecked")
	public List<Liquidacion> listaLiquidacion(String estado) {
		logger.info("obteniendo listaLiquidacion : " + estado);
		List<Liquidacion> lista = liquidacionesByEstadoNotif(estado, null, null, null);
		return lista;

	}

	public List<Liquidacion> liquidacionesByEstadoNotif(String estado, String estadoNotif, Date fechaVenc, Date fechaVencHasta) {
		if (!StringUtils.isBlank(estado) && estado.trim().length() == 1) {
			// para consultas que vienen con un solo caracter
			estado = "'" + estado + "'";
		}

		if (!StringUtils.isBlank(estadoNotif) && estadoNotif.trim().length() == 1) {
			// para consultas que vienen con un solo caracter
			estadoNotif = "'" + estadoNotif + "'";
		}

		List<Liquidacion> lista = new ArrayList<Liquidacion>();
		StringBuilder query = new StringBuilder();

		query.append("select l from Liquidacion l where l.cveEstado != 'Z' ");

		if (!StringUtils.isBlank(estado)) {
			query.append("and l.cveEstado in (" + estado + ") ");
		}

		if (fechaVenc != null) {
			query.append("and l.fechaVenc >= :fechaVenc ");
		}

		if (fechaVencHasta != null) {
			query.append("and l.fechaVenc <= :fechaVencHasta ");
		}

		if (!StringUtils.isBlank(estadoNotif)) {
			query.append("and l.cveEstnotif in (" + estadoNotif + ") ");
		}
		query.append("order by l.fechaVenc ");

		logger.info("Consultado liquidaciones[" + estado + "," + estadoNotif + "," + (fechaVenc != null ? UtilsDate.stringFromDate(fechaVenc, "dd/MM/yyyy"):"" )+ " ]: " + "["
				+ (fechaVencHasta != null ? UtilsDate.stringFromDate(fechaVencHasta, "dd/MM/yyyy") : "") + " ] " + query.toString());

		Query consulta = em.createQuery(query.toString());

		if (fechaVenc != null) {
			consulta.setParameter("fechaVenc", fechaVenc, TemporalType.DATE);
		}

		if (fechaVencHasta != null) {
			consulta.setParameter("fechaVencHasta", fechaVencHasta, TemporalType.DATE);
		}

		lista = consulta.getResultList();

		return lista;
	}

	public Liquidacion getLiquidacion(String codigo) {
		Liquidacion liq = null;
		StringBuilder query = new StringBuilder();

		query.append("select l from Liquidacion l where l.liqCodigo = ?");

		Query consulta = em.createQuery(query.toString());
		consulta.setParameter(1, codigo);

		List lista = consulta.getResultList();
		if (lista.size() > 0) {
			return (Liquidacion) lista.get(0);
		}

		return liq;

	}

	public Liquidacion cambioEstado(Liquidacion liquidacion, String observacion, String nuevoEstado) throws DataException {
		LogAuditoria logAuditoria = logQLBeanLocal.crearLog(liquidacion.getUsrCodigo(), "", liquidacion.getEstacion(), liquidacion.getLiqCodigo());
		Liquidacion liquidacionOld = cambioEstado(liquidacion, observacion, nuevoEstado, logAuditoria);
		return liquidacionOld;
	}

	// @TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public Liquidacion cambioEstado(Liquidacion liquidacion, String observacion, String nuevoEstado, LogAuditoria logAuditoria) throws DataException {
		logger.info("Ingresando a Cambio de estado " + liquidacion.getLiqCodigo() + " nuevo: " + nuevoEstado);

		liquidacion.setFechaHora(new Date());
		liquidacion.setEstacion(logAuditoria.getEstacion());
		liquidacion.setUsrCodigo(logAuditoria.getCodUsuario());

		if (!StringUtils.isBlank(nuevoEstado)) {
			// solo se actualiza el estado si tiene valor
			liquidacion.setCveEstado(nuevoEstado);

			edit(liquidacion);

			LiquidacionEstado liqEstado = liqEstadoQLBeanLocal.getLiqEstado(liquidacion.getLiqCodigo(), nuevoEstado);

			if (liqEstado == null) {
				logger.info("liqEstado nuevo " + liquidacion.getLiqCodigo());
				liqEstado = new LiquidacionEstado(new LiquidacionEstadoPK(liquidacion.getLiqCodigo(), nuevoEstado), logAuditoria.getLogAuditoriaId(),
						liquidacion.getUsrCodigo(), new Date());

				if (!StringUtils.isBlank(observacion))
					liqEstado.setObservacion(observacion);
				liqEstadoQLBeanLocal.create(liqEstado);
			} else {
				logger.info("liqEstado existente " + liquidacion.getLiqCodigo());
				liqEstado.setFechaHora(new Date());
				liqEstado.setLogAuditoriaId(logAuditoria.getLogAuditoriaId());
				liqEstado.setUsuario(liquidacion.getUsrCodigo());
				liqEstado.setObservacion(null);

				if (!StringUtils.isBlank(observacion))
					liqEstado.setObservacion(observacion);

				liqEstadoQLBeanLocal.edit(liqEstado);
			}

			logger.info("Estado cambiado codLiq: " + liquidacion.getLiqCodigo() + " nuevo: " + nuevoEstado);
		} else {
			edit(liquidacion);
		}

		Liquidacion liquidacionOld = getLiquidacion(liquidacion.getLiqCodigo());

		logger.info("Liquidacion actualizada: " + liquidacion.toString());

		return liquidacionOld;
	}

	public Integer maxLote() {

		StringBuilder jsql = new StringBuilder();
		jsql.append("select max(l.lote) from Liquidacion l");

		Query query = em.createQuery(jsql.toString());

		List result = query.getResultList();
		if (result.size() > 0) {
			Integer maximo = (Integer) result.get(0);
			return (maximo == null ? Integer.valueOf(0) : maximo);
		}

		return Integer.valueOf(0);
	}
	//L.O.C. 10/03/2017 Req. Ajuste de saldos
	public void actualizaLiquidacion(Liquidacion liquidacion) throws DataException {
		edit(liquidacion);
	}

	@Override
	public void setEntityManager(EntityManager entityManager) {
		// TODO Auto-generated method stub

	}

	@Override
	public EntityManager getEntityManager() {
		// TODO Auto-generated method stub
		return em;
	}

}
