package gob.bcb.jee.siodex.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import gob.bcb.jee.siodex.entities.Mensaje;
import gob.bcb.jee.siodex.entities.Vencimiento;
import gob.bcb.jee.siodex.exception.DataException;

import javax.ejb.Local;

@Local
public interface OperacionBeanLocal {

	List<Mensaje> registrarMensajeSwift(Vencimiento vencimiento, Date fechaValor, boolean actualizaLiq, String tipoCreacion, boolean cuentasOpInternas) throws DataException;

	void generarOperacionEnMotor(Vencimiento vencimiento, Date fechaValor) throws DataException;

	void crearSolicitud(Vencimiento vencimiento, String varAuxiliar) throws DataException;
}
