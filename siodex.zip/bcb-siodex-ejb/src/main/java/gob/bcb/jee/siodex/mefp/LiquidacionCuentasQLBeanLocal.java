package gob.bcb.jee.siodex.mefp;

import gob.bcb.jee.siodex.QL.DAO;

import java.util.List;

import javax.ejb.Local;

@Local
public interface LiquidacionCuentasQLBeanLocal extends DAO<LiquidacionCuentas> {

	public List<LiquidacionCuentas> getCuentas(String codigo);
	public LiquidacionCuentas getCuenta(String codigo, String tipo);
	LiquidacionCuentas actualizar(LiquidacionCuentas liquidacionCuentas);
	
}
