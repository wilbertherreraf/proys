package gob.bcb.jee.siodex.WS;

import java.util.HashMap;
import java.util.Map;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.inject.Inject;
import javax.jws.WebMethod;
import javax.jws.WebService;

import org.apache.log4j.Logger;

/**
 * Implementación de operaciones del TGN en el SIODEX en el contexto de servicio
 * web.
 * 
 * @author curiona
 * 
 */
@Stateless
@WebService
@TransactionManagement(TransactionManagementType.CONTAINER)
public class ServicioWebBean implements ServicioWebLocal {
	static final Logger logger = Logger.getLogger(ServicioWebBean.class);

	@Inject
	private ServicioUtil servicio;

	/**
	 * consulta de vencimientos si el parametro es CERO se genera un nuevo lote de consulta, si es mayor se verifica que exista o no el lote generado 
	 */
	@Override
	@WebMethod
	public String consultaVencimientos(String mensaje) throws Exception {
		Map<String, Object> parametros = new HashMap<String, Object>();

		if (mensaje.equals("9999")){
			parametros.put("tipooperacion", "ENVIARVENCIMIENTOS");			
			Map<String, Object> mapResult = servicio.procesarMensaje(parametros);
			String respuesta = (String) mapResult.get("respuesta");
			return respuesta;			
		}
		throw new Exception("metodo no implementado");
	}

	@Override
	@WebMethod
	public String alertaVencimientosObservados(Integer idLoteTGN, Integer fecha) throws Exception {
		logger.info("XXX:$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
		logger.info("Ingresando a la alerta de vencimientos observados: " + idLoteTGN + " fecha: " + fecha);

		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("tipooperacion", "ALERTVENCOBSERVADOS");
		parametros.put("idLoteTGN", idLoteTGN);
		parametros.put("fecha", fecha);
		
		Map<String, Object> mapResult = servicio.procesarMensaje(parametros);	
		String respuesta = (String) mapResult.get("respuesta");

		return respuesta;
	}

	@Override
	@WebMethod
	public String consultaVencimientosCorregidos(String mensaje) throws Exception {
		logger.info("Ingresando a la consulta de vencimientos corregidos...");

		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("tipooperacion", "CONSULTAVENCCORREGIDOS");
		parametros.put("mensaje", mensaje);
		
		Map<String, Object> mapResult = servicio.procesarMensaje(parametros);
		String respuesta = (String) mapResult.get("respuesta");
		return respuesta;
	}

	@Override
	@WebMethod
	public String alertaPagosAutorizados(Integer idLoteTGN, Integer fecha) throws Exception {
		// Obtener el mensaje de respuesta a enviar
		logger.info("Ingresando a la alerta de vencimientos autorizados: " + idLoteTGN + " fecha: " + fecha);
		String respuesta = "";
			Map<String, Object> parametros = new HashMap<String, Object>();
			parametros.put("tipooperacion", "ENVIARVENCAUTORIZADOS");
			parametros.put("codigoLiq", String.format("%06d", idLoteTGN));
			
			Map<String, Object> mapResult = servicio.procesarMensaje(parametros);
			respuesta = (String) mapResult.get("respuesta");

		return respuesta;		
	}

	@Override
	@WebMethod
	public String consultaPagos(String cod) throws Exception {
		logger.info("Ingresando a la consulta de pagos efectuados con código: " + cod);
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("tipooperacion", "CONSULTAPAGOSEFECT");
		parametros.put("codigo", cod);
		
		Map<String, Object> mapResult = servicio.procesarMensaje(parametros);
		String respuesta = (String) mapResult.get("respuesta");
		return respuesta;

	}

	@Override
	@WebMethod	
	public String recepcionObservados(String mensaje) throws Exception {
		logger.info("Ingresando a pagos observados: ");
		
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("tipooperacion", "PROCESARVENCOBSERVADOS");
		parametros.put("mensaje", mensaje);
		
		Map<String, Object> mapResult = servicio.procesarMensaje(parametros);
		String respuesta = (String) mapResult.get("respuesta");
		return respuesta;
	}

	/**
	 * Procesa los registros autorizados enviados por el TGN
	 */
	@Override
	@WebMethod	
	public String recepcionAutorizados(String mensaje) throws Exception {
		logger.info("Ingresando a pagos efectuados");
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("tipooperacion", "PROCESARVENCAUTORIZADOS");
		parametros.put("mensaje", mensaje);
		
		Map<String, Object> mapResult = servicio.procesarMensaje(parametros);
		String respuesta = (String) mapResult.get("respuesta");
		return respuesta;
	}
}
