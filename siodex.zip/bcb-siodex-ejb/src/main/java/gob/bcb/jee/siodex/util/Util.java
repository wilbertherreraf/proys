package gob.bcb.jee.siodex.util;

import gob.bcb.ejb.seguridad.services.utils.EJBRemotoSeguridad;
import gob.bcb.contabilidad.util.EJBRemotoContabilidad;

import java.io.Serializable;

import javax.inject.Singleton;

/**
 * Clase que permite la conexion hacia un EJB Remoto
 * 
 * @author CUriona
 * 
 */
@Singleton
public class Util implements Serializable {

	private static final long serialVersionUID = 1L;
	
	EJBRemotoSeguridad ejbRemotoSeguridad;
	EJBRemotoContabilidad ejbRemotoContabilidad;

	public Util() {
	}
	
	/**
	 * Método que permite obtener una instancia de una EJB Remoto.
	 * 
	 * @param ejbRemoto
	 *            . Class de la Interfaz EJB Remota.
	 * @return Ejb. Instancia del implementada del <code>ejbRemoto</code>
	 */
	public <Ejb> Ejb consumirEJB(Class<Ejb> ejbRemoto) throws Exception {
		
		if(ejbRemotoContabilidad == null){
			ejbRemotoContabilidad = new EJBRemotoContabilidad();
		}
		
		Ejb ejb = ejbRemotoContabilidad.consumirEJB(ejbRemoto);
		
		if(ejb == null){
			throw new Exception("Error de comunicación con el módulo de contabilidad.");
		}
		
		return ejb;
	}

	/**
	 * Método que permite obtener una instancia de una EJB Remoto del servicio de seguridad.
	 * 
	 * @param ejbRemoto
	 *            . Class de la Interfaz EJB Remota.
	 * @return Ejb. Instancia del implementada del <code>ejbRemoto</code>
	 */
	public <Ejb> Ejb consumirEJBSeguridad(Class<Ejb> ejbRemoto) throws Exception {
					
			if(ejbRemotoSeguridad == null){
				ejbRemotoSeguridad = new EJBRemotoSeguridad();
			}
			
			Ejb ejb = ejbRemotoSeguridad.consumirEJB(ejbRemoto);
			
			if(ejb == null){
				throw new Exception("Error de comunicación con el moódulo de seguridad.");
			}
			
			return ejb;
			
	}
	
}
