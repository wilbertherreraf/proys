/*
 /*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.jee.siodex.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author CUriona
 */
@Embeddable
public class PrestamoInstanciaPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "ptm_codigo")
    private String ptmCodigo;
    @Basic(optional = false)
    @NotNull
    @Column(name = "cve_tipo_liq")
    private String cveTipoLiq;
    @Basic(optional = false)
    @NotNull
    @Column(name = "tra_codigo")
    private int traCodigo;

    public PrestamoInstanciaPK() {
    }

    public PrestamoInstanciaPK(String ptmCodigo, String cveTipoLiq, int traCodigo) {
        this.ptmCodigo = ptmCodigo;
        this.cveTipoLiq = cveTipoLiq;
        this.traCodigo = traCodigo;
    }

    public String getPtmCodigo() {
		return ptmCodigo;
	}

	public void setPtmCodigo(String ptmCodigo) {
		this.ptmCodigo = ptmCodigo;
	}

	public String getCveTipoLiq() {
		return cveTipoLiq;
	}

	public void setCveTipoLiq(String cveTipoLiq) {
		this.cveTipoLiq = cveTipoLiq;
	}

    public int getTraCodigo() {
		return traCodigo;
	}

	public void setTraCodigo(int traCodigo) {
		this.traCodigo = traCodigo;
	}

	@Override
    public String toString() {
        return "gob.bcb.siodex.entities.PrestamoInstanciaPK[ ptmCodigo=" + ptmCodigo + ", cveTipoLiq=" + cveTipoLiq + ", traCodigo=" + traCodigo + " ]";
    }

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((cveTipoLiq == null) ? 0 : cveTipoLiq.hashCode());
		result = prime * result + ((ptmCodigo == null) ? 0 : ptmCodigo.hashCode());
		result = prime * result + traCodigo;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PrestamoInstanciaPK other = (PrestamoInstanciaPK) obj;
		if (cveTipoLiq == null) {
			if (other.cveTipoLiq != null)
				return false;
		} else if (!cveTipoLiq.equals(other.cveTipoLiq))
			return false;
		if (ptmCodigo == null) {
			if (other.ptmCodigo != null)
				return false;
		} else if (!ptmCodigo.equals(other.ptmCodigo))
			return false;
		if (traCodigo != other.traCodigo)
			return false;
		return true;
	}
    
}
