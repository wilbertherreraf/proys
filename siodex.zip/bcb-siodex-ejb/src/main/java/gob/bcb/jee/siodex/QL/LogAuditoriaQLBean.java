package gob.bcb.jee.siodex.QL;

import gob.bcb.jee.siodex.entities.LogAuditoria;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.EJBException;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

@Stateless
@LocalBean
public class LogAuditoriaQLBean extends DaoGeneric<LogAuditoria> implements LogAuditoriaQLBeanLocal {

	static final Logger logger = Logger.getLogger(LogAuditoriaQLBean.class);

	@PersistenceContext(unitName = "siodex")
	EntityManager em;

	/**
	 * Default constructor.
	 */
	public LogAuditoriaQLBean() {
		// TODO Auto-generated constructor stub
		super(LogAuditoria.class);
	}

	public List<LogAuditoria> listaLog() {

		List<LogAuditoria> lista = new ArrayList<LogAuditoria>();

		StringBuilder query = new StringBuilder();
		query.append("select l from LogAuditoria l");
		Query consulta = em.createQuery(query.toString());
		lista = consulta.getResultList();

		return lista;

	}

	public LogAuditoria crearLog(String codUsuario, String codParticipante, String estacion, String codTransaccion) {

		LogAuditoria maxLog = maxLogAuditoria();

		LogAuditoria logAuditoria = new LogAuditoria();
		
		logAuditoria.setLogAuditoriaId(maxLog.getLogAuditoriaId() + 1);
		logAuditoria.setCodUsuario(codUsuario);
		logAuditoria.setEstacion(estacion);
		logAuditoria.setCodTransaccion(codTransaccion);
		logAuditoria.setFechaHora(new Date());
		
		logger.info("Log a crear: " + logAuditoria.toString());
		
		create(logAuditoria);
		
		return logAuditoria; 
	}
	
	public LogAuditoria getLog(Integer codigo) {

		LogAuditoria log = null;

		StringBuilder query = new StringBuilder();

		query.append("select l from LogAuditoria l where l.logAuditoriaId = ?");

		Query consulta = em.createQuery(query.toString());
		consulta.setParameter(1, codigo);

		List lista = consulta.getResultList();
		if (lista.size() > 0) {
			return (LogAuditoria) lista.get(0);
		}

		return log;

	}

	public LogAuditoria maxLogAuditoria() {
		LogAuditoria logAuditoria = null;
		StringBuilder query = new StringBuilder();

		query.append("select l1 from LogAuditoria l1 where l1.logAuditoriaId = (select max(l.logAuditoriaId) from LogAuditoria l)");

		Query consulta = em.createQuery(query.toString());
		List lista = consulta.getResultList();
		if (lista.size() > 0) {
			logAuditoria = (LogAuditoria) lista.get(0);
		} else {
			logger.error("Error en consulta maximo log auditoria");
			throw new RuntimeException("Error en consulta maximo log auditoria");
		}
		
		return logAuditoria;
	}

	public Integer getCodigo() {
		LogAuditoria logAuditoria = maxLogAuditoria();
		Integer codigo = logAuditoria.getLogAuditoriaId();
		logger.info("log: " + codigo);
		return codigo;
	}

	@Override
	public void setEntityManager(EntityManager entityManager) {
		// TODO Auto-generated method stub

	}

	@Override
	public EntityManager getEntityManager() {
		// TODO Auto-generated method stub
		return em;
	}

}
