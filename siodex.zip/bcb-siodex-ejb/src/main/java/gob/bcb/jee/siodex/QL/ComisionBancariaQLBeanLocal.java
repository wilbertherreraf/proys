package gob.bcb.jee.siodex.QL;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import gob.bcb.jee.siodex.entities.ComisionBancaria;
import gob.bcb.jee.siodex.entities.Liquidacion;
import gob.bcb.jee.siodex.entities.LogAuditoria;
import gob.bcb.jee.siodex.entities.Vencimiento;
import gob.bcb.jee.siodex.exception.DataException;

import javax.ejb.Local;

@Local
public interface ComisionBancariaQLBeanLocal {

	/**
	 * 
	 * @return
	 */

	void edit(ComisionBancaria comi);
	void create(ComisionBancaria comi);
	public List<ComisionBancaria> getComisiones(String codigo);
	public ComisionBancaria getComisionByCodTipo(String codigo, String tipoComision) ;

	ComisionBancaria crearOactualizar(ComisionBancaria comisionBancaria);
	ComisionBancaria crearOactualizar(String codLiq, String tipoComi, BigDecimal monto, LogAuditoria log);
	Map<String, BigDecimal> getComisiones(Liquidacion liquidacion);	
}
