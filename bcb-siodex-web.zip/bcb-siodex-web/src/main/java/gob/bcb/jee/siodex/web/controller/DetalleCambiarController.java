package gob.bcb.jee.siodex.web.controller;

import gob.bcb.jee.siodex.QL.LiquidacionDetQLBeanLocal;
import gob.bcb.jee.siodex.QL.LiquidacionQLBeanLocal;
import gob.bcb.jee.siodex.controller.BaseBean;
import gob.bcb.jee.siodex.entities.Liquidacion;
import gob.bcb.jee.siodex.entities.LiquidacionDet;
import gob.bcb.jee.siodex.entities.Solicitud;

import java.io.IOException;
import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

// The @Model stereotype is a convenience mechanism to make this a request-scoped bean that has an
// EL name
// Read more about the @Model stereotype in this FAQ:
// http://sfwk.org/Documentation/WhatIsThePurposeOfTheModelAnnotation
//@Model
@ManagedBean(name = "detalleCambiarController")
@ViewScoped
public class DetalleCambiarController extends BaseBean {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	static final Logger logger = Logger.getLogger(DetalleCambiarController.class);

	@Inject
	private LiquidacionDetQLBeanLocal liquidacionDetQLBeanLocal;
	@Inject
	private LiquidacionQLBeanLocal liquidacionQLBeanLocal;
	private String codigo;
	private String codDetalle;	
	private LiquidacionDet liquidacionDet;
	private String tituloError;
	private String mensajeError;
	private boolean mostrarError = false;

	private Solicitud solicitud = null;

	private String contextPath;

	@PostConstruct
	public void inicio() {

		// obteniendo el path de la aplicacion
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		contextPath = request.getContextPath();
		
		recuperarParametros();
		
		codigo = (String) ((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).getAttribute("codigo");
		codDetalle = (String) ((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).getAttribute("coddetalle");		

		liquidacionDet = liquidacionDetQLBeanLocal.getLiquidacion(codigo, codDetalle);
		
		logger.info("Objeto instanciado: " + codigo);
	}

	public String botonRetornar() throws IOException {
		((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("codigo", codigo);
		FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/detalleven_edit.jsf");

		return "";
	}

	public String botonGuardar() {
		logger.info("autorizando...");

		try {
			Liquidacion liquidacion = liquidacionQLBeanLocal.getLiquidacion(codigo);
			
			if (!liquidacion.getCveEstado().equals("Z") && !liquidacion.getCveEstado().equals("C")){
				liquidacionDetQLBeanLocal.edit(liquidacionDet);
				
				liquidacionDet = liquidacionDetQLBeanLocal.getLiquidacion(codigo, codDetalle);
				
				mostrarError = true;
				tituloError = "MENSAJE";
				mensajeError = "La operacion se realizo satisfactoriamente.";
			} else {
				mostrarError = true;
				tituloError = "MENSAJE";
				mensajeError = "La liquidacion se encuentra con estado incorrecto no puede modificar.";
			}
			return null;
			// solicitud.setCveEstado("Z");
		} catch (Exception e) {
			logger.error("Error guardar " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage("errorcito",
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Ocurrió un error: " + e.getMessage(), null));
		}

		return "";
	}

	public Solicitud getSolicitud() {
		return solicitud;
	}

	public void setSolicitud(Solicitud solicitud) {
		this.solicitud = solicitud;
	}

	public String getTituloError() {
		return tituloError;
	}

	public void setTituloError(String tituloError) {
		this.tituloError = tituloError;
	}

	public String getMensajeError() {
		return mensajeError;
	}

	public void setMensajeError(String mensajeError) {
		this.mensajeError = mensajeError;
	}

	public boolean isMostrarError() {
		return mostrarError;
	}

	public void setMostrarError(boolean mostrarError) {
		this.mostrarError = mostrarError;
	}

	public LiquidacionDet getLiquidacionDet() {
		return liquidacionDet;
	}

	public void setLiquidacionDet(LiquidacionDet liquidacionDet) {
		this.liquidacionDet = liquidacionDet;
	}

}
