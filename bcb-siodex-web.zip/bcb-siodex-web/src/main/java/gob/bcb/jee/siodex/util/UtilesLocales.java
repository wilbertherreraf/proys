package gob.bcb.jee.siodex.util;

import java.util.Enumeration;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.http.HttpSession;

/**
 * 
 * Clase que permite manejar los utiles de la aplicaciones locales
 * 
 * @author eibanez
 * 
 */
public class UtilesLocales {

	/**
	 * 
	 * Metodo que permite limpiar los bena del tipo session
	 * 
	 * @param session
	 */
	public static void limpiarCache(HttpSession session) {

		session.removeAttribute("vencimientosController");
				

	}
	
	/**
	 * Metodo que verifica la fortaleza de una contraseña
	 * 
	 * @param password
	 * @return
	 */
	private static boolean verficaFortaleza(String password) {
		boolean resultado = false;
		if (password.length() >= 8) {
			Pattern pattern = Pattern.compile(".*[A-Z]+.*");
			Matcher matcher = pattern.matcher(password);
			if (matcher.find()) {
				pattern = Pattern.compile(".*[0-9]+.*");
				matcher = pattern.matcher(password);
				if (matcher.find()) {
					pattern = Pattern.compile(".*[a-z]+.*");
					matcher = pattern.matcher(password);
					if (matcher.find()) {
						resultado = true;
					}
				}
			}
		}
		return resultado;
	}

}
