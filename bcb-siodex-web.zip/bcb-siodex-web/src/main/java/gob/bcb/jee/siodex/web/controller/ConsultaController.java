package gob.bcb.jee.siodex.web.controller;

import gob.bcb.contabilidad.pojo.RastroContablePojo;
import gob.bcb.jee.siodex.controller.BaseBean;
import gob.bcb.jee.siodex.mail.controller.Email;
import gob.bcb.jee.siodex.service.ComprobanteBeanLocal;
import gob.bcb.jee.siodex.service.ConsultaBeanLocal;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

//import dk.itst.oiosaml.sp.UserAssertion;
//import dk.itst.oiosaml.sp.service.util.Constants;

// The @Model stereotype is a convenience mechanism to make this a request-scoped bean that has an
// EL name
// Read more about the @Model stereotype in this FAQ:
// http://sfwk.org/Documentation/WhatIsThePurposeOfTheModelAnnotation
//@Model
@ManagedBean(name = "consultaController")
@ViewScoped
public class ConsultaController extends BaseBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	static final Logger logger = Logger.getLogger(ConsultaController.class);

	@Inject
	private ConsultaBeanLocal consultaBean;

	@Inject
	private ComprobanteBeanLocal comprobante;

	private List<RastroContablePojo> lista = null;

	private RastroContablePojo rast;

	private String tituloError;
	private String mensajeError;
	private boolean mostrarError = false;

	@PostConstruct
	public void inicio() {
		try {
			rast = new RastroContablePojo();

			Date fecha = new Date();
			lista = consultaBean.obtenerRastroContable(fecha);

			System.out.println("Valor: " + (lista == null ? "NULL" : lista.size()));
			logger.info("Lista recuperada: " + (lista == null ? "NULL" : lista.size()));
		} catch (Exception e) {
			// sessionContext.setRollbackOnly();
			mostrarError = true;
			tituloError = "ERROR";
			mensajeError = "La operación generó ERROR: " + e.getMessage();
			logger.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "La operacion produjo un error: " + e.getMessage(), null));

		}
	}

	public String contabilizar() {
		try {
			System.out.println("Contabilizando rastro contable...");
			logger.info("Contabilizando rastro contable...");
			Map<String, Object> mapaResult = new HashMap<String, Object>();

			System.out.println("Detalle1: " + rast);
			System.out.println("Detalle2: " + rast.getNroOperacion());
			logger.info("Rastro número: " + rast.getNroOperacion());

			HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
			String ip = getVisitBean().getUsuario().getUsrIpasignado();
			String usuario = request.getUserPrincipal().getName();

			mapaResult = comprobante.contabilizarUno(rast, usuario, ip);
			Integer continuar = (Integer) mapaResult.get("continuar");
			String descError = (String) mapaResult.get("descMensaje");

			logger.info("Devuelve contabilización...");
			logger.info("continuar: " + continuar);
			logger.info("mensaje: " + descError);

			if (continuar == 1) {
				mostrarError = true;
				tituloError = "MENSAJE";
				mensajeError = "El rastro contable se contabilizó exitosamente.";
			} else {
				mostrarError = true;
				tituloError = "ERROR";
				mensajeError = "Se produjo un error al contabilizar el rastro contable. " + descError;
			}

			return "";
		} catch (Exception e) {
			// sessionContext.setRollbackOnly();
			mostrarError = true;
			tituloError = "ERROR";
			mensajeError = "La operación generó ERROR: " + e.getMessage();
			logger.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "La operacion produjo un error: " + e.getMessage(), null));
			return null;
		}
	}

	public List<RastroContablePojo> getLista() {
		return lista;
	}

	public String botonRetornar() {

		System.out.println("Retornando...");

		return "";
	}

	public RastroContablePojo getRast() {
		return rast;
	}

	public void setRast(RastroContablePojo rast) {
		this.rast = rast;
	}

	public String getTituloError() {
		return tituloError;
	}

	public void setTituloError(String tituloError) {
		this.tituloError = tituloError;
	}

	public String getMensajeError() {
		return mensajeError;
	}

	public void setMensajeError(String mensajeError) {
		this.mensajeError = mensajeError;
	}

	public boolean isMostrarError() {
		return mostrarError;
	}

	public void setMostrarError(boolean mostrarError) {
		this.mostrarError = mostrarError;
	}

}
