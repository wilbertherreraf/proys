package gob.bcb.jee.siodex.web.controller;

import gob.bcb.jee.siodex.QL.MensajeDatosQLBeanLocal;
import gob.bcb.jee.siodex.QL.MensajeQLBeanLocal;
import gob.bcb.jee.siodex.entities.Mensaje;
import gob.bcb.jee.siodex.entities.MensajeDatos;
import gob.bcb.jee.siodex.entities.Datos;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

// The @Model stereotype is a convenience mechanism to make this a request-scoped bean that has an
// EL name
// Read more about the @Model stereotype in this FAQ:
// http://sfwk.org/Documentation/WhatIsThePurposeOfTheModelAnnotation
//@Model
@ManagedBean(name = "detalleMenModifController")
@ViewScoped
public class DetalleMenModifController implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	static final Logger logger = Logger.getLogger(DetalleMenModifController.class);

	@Inject
	private MensajeQLBeanLocal mensajeQLBeanLocal;

	@Inject
	private MensajeDatosQLBeanLocal mensajeDatosQLBeanLocal;

	private String codigo = "";

	private String tituloError;
	private String mensajeError;
	private boolean mostrarError = false;

	private MensajeDatos dato = null;
	private List<Datos> listaCampos = new ArrayList<Datos>();

	public List<Datos> getListaCampos() {
		return listaCampos;
	}

	private String contextPath;

	@PostConstruct
	public void inicio() {

		// obteniendo el path de la aplicacion
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		contextPath = request.getContextPath();

		codigo = (String) ((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).getAttribute("codigo");

		System.out.println("Objeto instanciado: " + codigo);
		logger.info("Objeto instanciado: " + codigo);

		if (mensajeDatosQLBeanLocal != null) {

			listaCampos = mensajeDatosQLBeanLocal.getDatosVer(codigo);

		}

	}

	public String botonCancelar() throws IOException {

		HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);

		session.removeAttribute("mensajesModificarController");

		FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/mensajesModificar.jsf");

		return "";
	}

	public String botonGuardar() {

		System.out.println("Guardando datos mensaje...");
		logger.info("Guardando datos mensaje...");

		try {

			if (mensajeDatosQLBeanLocal != null) {

				for (Datos dd : listaCampos) {
					if (dd.getCamCodigo().equals(":32A") || dd.getCamCodigo().equals(":72")) {
						dato = mensajeDatosQLBeanLocal.getDato(codigo, dd.getCamCodigo());
						dato.setMdtValor(dd.getMdtValor());
						mensajeDatosQLBeanLocal.edit(dato);
					}
				}

				if (mensajeQLBeanLocal != null) {
					Mensaje mensaje = mensajeQLBeanLocal.getMensaje(codigo);
					mensaje.setCveEstadoS("E");
					mensajeQLBeanLocal.edit(mensaje);

					mostrarError = true;
					tituloError = "MENSAJE";
					mensajeError = "Los datos del mensaje se guardaron exitosamente";
				}
			}
		} catch (Exception e) {
			mostrarError = true;
			tituloError = "MENSAJE";
			mensajeError = "Se produjo un error al guardar los datos del mensaje";
			logger.info("error al guardar los datos del mensaje:" + e.getMessage());
			e.printStackTrace();
		}

		return "";
	}

	public String botonRetornar() throws IOException {

		HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);

		session.removeAttribute("mensajesModificarController");

		FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/mensajesModificar.jsf");

		return "";
	}

	public String getTituloError() {
		return tituloError;
	}

	public void setTituloError(String tituloError) {
		this.tituloError = tituloError;
	}

	public String getMensajeError() {
		return mensajeError;
	}

	public void setMensajeError(String mensajeError) {
		this.mensajeError = mensajeError;
	}

	public boolean isMostrarError() {
		return mostrarError;
	}

	public void setMostrarError(boolean mostrarError) {
		this.mostrarError = mostrarError;
	}

	public MensajeDatos getDato() {
		return dato;
	}

	public void setDato(MensajeDatos dato) {
		this.dato = dato;
	}

}
