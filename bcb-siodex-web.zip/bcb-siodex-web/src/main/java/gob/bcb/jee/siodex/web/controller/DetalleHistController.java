package gob.bcb.jee.siodex.web.controller;

import gob.bcb.jee.siodex.QL.CoinQLBeanLocal;
import gob.bcb.jee.siodex.QL.ConsultasSdxQLBeanLocal;
import gob.bcb.jee.siodex.QL.CuentaQLBeanLocal;
import gob.bcb.jee.siodex.QL.VencimientoQLBeanLocal;
import gob.bcb.jee.siodex.entities.Cuenta;
import gob.bcb.jee.siodex.entities.Vencimiento;
import gob.bcb.jee.siodex.exception.DataException;

import java.io.IOException;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

// The @Model stereotype is a convenience mechanism to make this a request-scoped bean that has an
// EL name
// Read more about the @Model stereotype in this FAQ:
// http://sfwk.org/Documentation/WhatIsThePurposeOfTheModelAnnotation
@ManagedBean(name = "detalleHistController")
@ViewScoped
public class DetalleHistController implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	static final Logger logger = Logger.getLogger(DetalleHistController.class);

	@Inject
	private VencimientoQLBeanLocal vencimientoQLBeanLocal;

	@Inject
	private CuentaQLBeanLocal cuentaQLBeanLocal;
	@Inject
	private ConsultasSdxQLBeanLocal consultasSdxQLBeanLocal;
	@Inject
	private CoinQLBeanLocal coinQLBeanLocal;
	private String ptm = "";
	private int tramo = 0;
	private String codigo = "";
	private String titulo = "";
	private String total = "";
	private BigDecimal equivalente = BigDecimal.valueOf(0.00);
	private BigDecimal tcV = BigDecimal.valueOf(6.96);
	private BigDecimal tc = BigDecimal.valueOf(6.86);
	private BigDecimal comi = BigDecimal.valueOf(0.07);
	private BigDecimal comiPago = BigDecimal.valueOf(0.00);
	private BigDecimal swift = BigDecimal.valueOf(200.00);
	private BigDecimal utiles = BigDecimal.valueOf(40.00);
	private BigDecimal comiTotal = BigDecimal.valueOf(0.00);
	private BigDecimal pagoTotal = BigDecimal.valueOf(0.00);

	private String tituloError;
	private String mensajeError;
	private boolean mostrarError = false;

	private List<SelectItem> cuentasS = new ArrayList<SelectItem>();
	private Cuenta cuentaS = null;
	private String ctaS = "";

	private List<SelectItem> cuentasC = new ArrayList<SelectItem>();
	private Cuenta cuentaC = null;
	private String ctaC = "";

	private Vencimiento vencimiento = null;

	private String urlReporte;
	private String contextPath;

	@PostConstruct
	public void inicio() {
		try {
			// obteniendo el path de la aplicacion
			HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
			contextPath = request.getContextPath();

			ptm = (String) ((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).getAttribute("ptm");
			tramo = (Integer) ((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).getAttribute("tramo");
			codigo = (String) ((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).getAttribute("codigo");

			logger.info("Objeto instanciado: " + ptm + ", " + tramo);

			String comistr = consultasSdxQLBeanLocal.getParametro("@pdex");
			comi = new BigDecimal(comistr.replace(",", "."));

			String swiftistr = consultasSdxQLBeanLocal.getParametro("@gcom");
			swift = new BigDecimal(swiftistr.replace(",", "."));

			String utilesstr = consultasSdxQLBeanLocal.getParametro("@util");
			utiles = new BigDecimal(utilesstr.replace(",", "."));

			vencimiento = vencimientoQLBeanLocal.getVencimiento(ptm, tramo, codigo);

			tcV = coinQLBeanLocal.getTC(vencimiento.getFechaTc(), "35");
			tc = coinQLBeanLocal.getTC(vencimiento.getFechaTc(), "34");

			titulo = vencimiento.getAcreedor() + " - " + vencimiento.getRefAcre() + " - " + vencimiento.getPrestamo();
			equivalente = vencimiento.getTotalUsd().multiply(tcV).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
			comiPago = vencimiento.getTotalUsd().multiply(comi).divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP).multiply(tc)
					.divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
			comiTotal = comiPago.add(swift).add(utiles);
			pagoTotal = equivalente.add(comiTotal);
			total = "Total débito efectuado el " + DateFormat.getDateInstance().format(vencimiento.getFechaVenc()) + " en Bolivianos ";

			//cuentaS = cuentaQLBeanLocal.getCuenta(ptm, tramo, "DEUD");
			cuentasS.add(new SelectItem(cuentaS.getCtaCodigo(), cuentaS.getCtaNumero()));
			ctaS = cuentaS.getCtaCodigo();
		} catch (DataException e) {
			logger.error("Error al obtener lista vencimientos " + e.getMessage());
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Ocurrió un error: " + e.getMessage(), null));
		}
	}

	public String botonCancelar() throws IOException {

		HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);

		session.removeAttribute("vencimientosPController");

		FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/vencimientosP.jsf");

		return "";
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getTotal() {
		return total;
	}

	public void setTotal(String total) {
		this.total = total;
	}

	public String getPtm() {
		return ptm;
	}

	public void setPtm(String ptm) {
		this.ptm = ptm;
	}

	public int getTramo() {
		return tramo;
	}

	public void setTramo(int tramo) {
		this.tramo = tramo;
	}

	public BigDecimal getEquivalente() {
		return equivalente;
	}

	public void setEquivalente(BigDecimal equivalente) {
		this.equivalente = equivalente;
	}

	public BigDecimal getTcV() {
		return tcV;
	}

	public void setTcV(BigDecimal tcV) {
		this.tcV = tcV;
	}

	public BigDecimal getComiPago() {
		return comiPago;
	}

	public void setComiPago(BigDecimal comiPago) {
		this.comiPago = comiPago;
	}

	public BigDecimal getSwift() {
		return swift;
	}

	public void setSwift(BigDecimal swift) {
		this.swift = swift;
	}

	public BigDecimal getUtiles() {
		return utiles;
	}

	public void setUtiles(BigDecimal utiles) {
		this.utiles = utiles;
	}

	public BigDecimal getComiTotal() {
		return comiTotal;
	}

	public void setComiTotal(BigDecimal comiTotal) {
		this.comiTotal = comiTotal;
	}

	public BigDecimal getPagoTotal() {
		return pagoTotal;
	}

	public void setPagoTotal(BigDecimal pagoTotal) {
		this.pagoTotal = pagoTotal;
	}

	public String getTituloError() {
		return tituloError;
	}

	public void setTituloError(String tituloError) {
		this.tituloError = tituloError;
	}

	public String getMensajeError() {
		return mensajeError;
	}

	public void setMensajeError(String mensajeError) {
		this.mensajeError = mensajeError;
	}

	public boolean isMostrarError() {
		return mostrarError;
	}

	public void setMostrarError(boolean mostrarError) {
		this.mostrarError = mostrarError;
	}

	public Cuenta getCuentaS() {
		return cuentaS;
	}

	public void setCuentaS(Cuenta cuentaS) {
		this.cuentaS = cuentaS;
	}

	public List<SelectItem> getCuentasS() {
		return cuentasS;
	}

	public void setCuentasS(List<SelectItem> cuentasS) {
		this.cuentasS = cuentasS;
	}

	public List<SelectItem> getCuentasC() {
		return cuentasC;
	}

	public void setCuentasC(List<SelectItem> cuentasC) {
		this.cuentasC = cuentasC;
	}

	public Cuenta getCuentaC() {
		return cuentaC;
	}

	public void setCuentaC(Cuenta cuentaC) {
		this.cuentaC = cuentaC;
	}

	public String getCtaS() {
		return ctaS;
	}

	public void setCtaS(String ctaS) {
		this.ctaS = ctaS;
	}

	public String getCtaC() {
		return ctaC;
	}

	public void setCtaC(String ctaC) {
		this.ctaC = ctaC;
	}

	public Vencimiento getVencimiento() {
		return vencimiento;
	}

	public void setVencimiento(Vencimiento vencimiento) {
		this.vencimiento = vencimiento;
	}

	private static String getRaiz() {
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		String url = request.getRequestURL().toString();
		System.out.println(url);
		String direccionRaiz = null;
		if (url.indexOf("/pages") > 0)
			direccionRaiz = url.substring(0, url.indexOf("/pages")) + "/";
		else
			direccionRaiz = url;
		return direccionRaiz;
	}

	public String getUrlReporte() {
		String prestamo = "PAGO PRESTAMO " + titulo + " - VENCIMIENTO " + DateFormat.getDateInstance().format(vencimiento.getFechaVenc());
		urlReporte = getRaiz() + "reporte?cod=" + codigo + "&tipo=CON&tc=" + tc + "&tcV=" + tcV + "&prestamo=" + prestamo;
		System.out.println("1:" + urlReporte);
		return urlReporte;
	}

	public void setUrlReporte(String urlReporte) {
		this.urlReporte = urlReporte;
	}

}
