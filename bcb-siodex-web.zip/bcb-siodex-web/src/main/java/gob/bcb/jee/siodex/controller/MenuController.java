package gob.bcb.jee.siodex.controller;

import gob.bcb.ejb.seguridad.services.UsuarioPlazaQLBeanRemote;
import gob.bcb.ejb.seguridad.services.pojo.DatosSeguridad;
import gob.bcb.ejb.seguridad.services.pojo.Usuario;
import gob.bcb.jee.siodex.pojos.Participante;
import gob.bcb.jee.siodex.util.Util;
import gob.bcb.jee.siodex.util.UtilesLocales;

import java.io.IOException;
import java.util.Date;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

//import dk.itst.oiosaml.sp.UserAssertion;
//import dk.itst.oiosaml.sp.service.util.Constants;

@ManagedBean(name = "menuController")
@SessionScoped
public class MenuController extends BaseBean {

	static final Logger log = Logger.getLogger(MenuController.class);

	private String usuario = "";
	private String pagina = "";
	private String nombre = "";
	private String codEnt = "";
	private String entidad = "";
	private Date fecha;
	private String contextPath;

	@Inject
	private Util util;

	@PostConstruct
	public void inicio() {
		log.info("===>>>oo00OCreando Menu ControllerO00oo<<<===");
		Usuario genUsuario = new Usuario();

		Participante participante = new Participante();

		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		String ip = this.getClientIpAddr(request);
		
		// obteniendo el path de la aplicacion
		contextPath = request.getContextPath();

		log.info("Path: " + contextPath);

		this.usuario = request.getUserPrincipal().getName();

		log.info("util: " + util);

		UsuarioPlazaQLBeanRemote usuarioPlazaQLBeanRemote;

		try {
			usuarioPlazaQLBeanRemote = util.consumirEJBSeguridad(UsuarioPlazaQLBeanRemote.class);
			DatosSeguridad datosSeguridad = usuarioPlazaQLBeanRemote.buscarUsuarioAgenciaPlaza(usuario);

			// /////////////////////////////////
			// whf ojooo borrar eliminar por desa
//			 DatosSeguridad datosSeguridad = new DatosSeguridad();
//			 datosSeguridad.setCodPersona("900");
//			 datosSeguridad.setCodUsuario(usuario);
//			 datosSeguridad.setEmail("wherrera@bcb.gob.bo");
//			 datosSeguridad.setNombreCompletoUsuario("wil herrera");
//			 datosSeguridad.setNombreCompletoPersona("BACO CNETARA");
			// /////////////////////////////////
		
			log.info("datosSeguridad: " + datosSeguridad.toString());

			this.nombre = datosSeguridad.getNombreCompletoUsuario();
			this.codEnt = datosSeguridad.getCodPersona();

			if (this.codEnt != null && !this.codEnt.equals("900")) {
				this.entidad = datosSeguridad.getNombreCompletoPersona();
			} else {
				this.entidad = "";
			}
			genUsuario.setUsrLogin(usuario);
			genUsuario.setUsrEmail(datosSeguridad.getEmail());
			// genUsuario.setUsrCoduser(datosSeguridad.getCodUsuario());
			genUsuario.setUsrCodemp(datosSeguridad.getCodUsuario());
			genUsuario.setUsrNombres(datosSeguridad.getNombreCompletoUsuario());
			genUsuario.setUsrIpasignado(ip);
			// genUsuario.setUsrApellidos(datosSeguridad.get);
			participante.setCodPte(codEnt);
			participante.setNombrePte(entidad);

			getVisitBean().setUsuario(genUsuario);
			getVisitBean().setParticipante(participante);
		} catch (Exception e) {
			log.error("Error al iniciar init " + e.getMessage(), e);
		}

		log.info("Usuario autenticado: " + nombre + ", entidad: " + codEnt + " usuario:" + usuario);

		this.fecha = new Date();

		this.pagina = "/pages/principal.xhtml";
		log.info("Estoy en el constructor...: " + pagina);

	}

	/**
	 * 
	 * Metodo que maneja los eventos del menu
	 * 
	 * @param event
	 * @throws IOException
	 */
	public void eventoMenu(ActionEvent event) throws IOException {
		HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);

		log.info("Sesion creada evento: " + session);
		getVisitBean().setSelectedLiquidacion(null);
		getVisitBean().removeParametro("SIODEX_PARAM");
		getVisitBean().removeParametro("SIODEX_PARM_VERIFICAR");
		// limpiando el cache de la session
		UtilesLocales.limpiarCache(session);
		Map<String, String> map = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();

		// obteniendo la pagina de la session
		this.pagina = (String) map.get("pagina");
		String SIODEX_PARAM = (String) map.get("SIODEX_PARAM");
		log.info("XXX: SIODEX_PARAM: " + SIODEX_PARAM);
		getVisitBean().setParametro("SIODEX_PARAM", SIODEX_PARAM);
		pagina = contextPath + pagina;
		log.info("Pagina: " + pagina);

		((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("SIODEX_PARAM", SIODEX_PARAM);
		FacesContext.getCurrentInstance().getExternalContext().redirect(pagina);

		log.info("Estoy en el evento para cargar la pagina: " + pagina);

	}

	public String getPagina() {
		return pagina;
	}

	public void setPagina(String pagina) {
		this.pagina = pagina;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getEntidad() {
		return entidad;
	}

	public void setEntidad(String entidad) {
		this.entidad = entidad;
	}

	public String getCodEnt() {
		return codEnt;
	}

	public void setCodEnt(String codEnt) {
		this.codEnt = codEnt;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	private String getClientIpAddr(HttpServletRequest request) {

		String ip = request.getHeader("X-Forwarded-For");

		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("Proxy-Client-IP");
		}

		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}

		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_CLIENT_IP");
		}

		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_X_FORWARDED_FOR");
		}

		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}

		return ip;
	}

}
