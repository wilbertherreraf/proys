package gob.bcb.jee.siodex.web.controller;

import gob.bcb.jee.siodex.QL.SolicitudQLBeanLocal;
import gob.bcb.jee.siodex.entities.Solicitud;
import gob.bcb.jee.siodex.service.ComprobanteBeanLocal;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

// The @Model stereotype is a convenience mechanism to make this a request-scoped bean that has an
// EL name
// Read more about the @Model stereotype in this FAQ:
// http://sfwk.org/Documentation/WhatIsThePurposeOfTheModelAnnotation
//@Model
@ManagedBean(name = "operacionesCambiarController")
@ViewScoped
public class OperacionesCambiarController implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	static final Logger logger = Logger.getLogger(OperacionesController.class);

	@Inject
	private SolicitudQLBeanLocal solicitudQLBeanLocal;

	private List<Solicitud> listaSol = new ArrayList<Solicitud>();

	private String contextPath;

	private Solicitud sol;

	public List<Solicitud> getListaSol() {
		return listaSol;
	}

	@PostConstruct
	public void inicio() {

		// obteniendo el path de la aplicacion
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		contextPath = request.getContextPath();

		sol = new Solicitud();

		listaSol = solicitudQLBeanLocal.listaSolicitudPendiente();

		logger.info("lista: " + (listaSol == null ? "NULL" : listaSol.size()));
	}

	public String botonDetalle() throws IOException {
		logger.info("detalle: " + sol.getLiqCodigo());

		Integer codSol = sol.getSolCodigo();
		Date fecha = sol.getFecha();

		// cargando prestamo
		((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("codSol", codSol);

		((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("fecha", fecha);

		HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);

		session.removeAttribute("detalleCambiarController");

		FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/detalleCambiar.jsf");

		return "/pages/detalleCambiar";
	}

	public Solicitud getSol() {
		return sol;
	}

	public void setSol(Solicitud sol) {
		this.sol = sol;
	}

}
