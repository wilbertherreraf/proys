package gob.bcb.jee.siodex.web.controller;

import gob.bcb.jee.siodex.QL.VencimientoQLBeanLocal;
import gob.bcb.jee.siodex.controller.BaseBean;
import gob.bcb.jee.siodex.entities.Vencimiento;
import gob.bcb.jee.siodex.exception.DataException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

// The @Model stereotype is a convenience mechanism to make this a request-scoped bean that has an
// EL name
// Read more about the @Model stereotype in this FAQ:
// http://sfwk.org/Documentation/WhatIsThePurposeOfTheModelAnnotation
//@Model
@ManagedBean(name = "vencimientosNController")
@ViewScoped
public class VencimientosNController extends BaseBean {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	static final Logger logger = Logger.getLogger(VencimientosNController.class);

	@Inject
	private VencimientoQLBeanLocal vencimientoQLBeanLocal;

	private String nombre = "";

	private Vencimiento liq;
	private String contextPath;

	private List<Vencimiento> listaVen = new ArrayList<Vencimiento>();

	public List<Vencimiento> getListaVen() {
		return listaVen;
	}

	@PostConstruct
	public void inicio() {
		try {
			// obteniendo el path de la aplicacion
			HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
			contextPath = request.getContextPath();

			String codEnt = getVisitBean().getParticipante().getCodPte();
			logger.info("codEnt: " + codEnt);

			liq = new Vencimiento();

			listaVen = vencimientoQLBeanLocal.listaVencimiento("P", codEnt);
			logger.info("lista: " + (listaVen == null ? "NULL" : listaVen.size()));
		} catch (DataException e) {
			logger.error("Error al obtener lista vencimientos " + e.getMessage());
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Ocurrió un error: " + e.getMessage(), null));
		}
	}

	public String botonDetalle() throws IOException {
		logger.info("detalle: " + liq.getPtmCodigo());

		String ptm = liq.getPtmCodigo();
		int tramo = liq.getTraCodigo();
		String codigo = liq.getLiqCodigo();

		// cargando prestamo
		((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("ptm", ptm);
		((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("tramo", tramo);
		((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("codigo", codigo);

		HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);
		session.removeAttribute("detalleVenNotaController");
		FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/pages/detalleVenNota.jsf");

		return "/pages/detalleVenNota";
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Vencimiento getLiq() {
		return liq;
	}

	public void setLiq(Vencimiento liq) {
		this.liq = liq;
	}

}
