package gob.bcb.jee.siodex.controller;
import gob.bcb.ejb.seguridad.services.pojo.Usuario;

import gob.bcb.jee.siodex.entities.Liquidacion;
import gob.bcb.jee.siodex.pojos.Participante;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import javax.enterprise.context.SessionScoped;
import javax.faces.bean.ManagedBean;

import org.apache.log4j.Logger;

@ManagedBean
@SessionScoped
public class VisitBean implements Serializable {
	static final Logger log = Logger.getLogger(VisitBean.class);	
	private Liquidacion selectedLiquidacion;
	private Map<String, Object> parametro;
	private Usuario usuario; 
	private Participante participante;
	
	public VisitBean() {
		log.info("Creando Visit .....");
		participante = new Participante();
		usuario = new Usuario();
		parametro = new HashMap<String, Object>();		
	}

	public void setParametro(String key, Object valor) {
		if (this.parametro == null) {
			parametro = new HashMap<String, Object>();
		}
		if (valor == null) {
			if (parametro.containsKey(key))
				parametro.remove(key);
		} else {
			if (key != null) {
				parametro.put(key, valor);
			}
		}
	}

	public Object getParametro(String key) {
		return parametro.get(key);
	}

	public void removeParametro(String key) {
		try {
			parametro.remove(key);
		} catch (Exception e) {
		}
	}

	public void limpiarParametros() {
		parametro.clear();
	}

	public void setParametro(Map<String, Object> parametro) {
		this.parametro = parametro;
	}

	public Map<String, Object> getParametro() {
		return parametro;
	}

	public Participante getParticipante() {
		return participante;
	}

	public void setParticipante(Participante participante) {
		this.participante = participante;
	}

	public Liquidacion getSelectedLiquidacion() {
		return selectedLiquidacion;
	}

	public void setSelectedLiquidacion(Liquidacion selectedLiquidacion) {
		this.selectedLiquidacion = selectedLiquidacion;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

}
