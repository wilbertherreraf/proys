package gob.bcb.jee.siodex.controller;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean(name = "titleController")
@SessionScoped
public class TitleController implements Serializable {

	private static final long serialVersionUID = 1L;

	public TitleController() {

	}

	@PostConstruct
	public void inicio() {

	}

}
