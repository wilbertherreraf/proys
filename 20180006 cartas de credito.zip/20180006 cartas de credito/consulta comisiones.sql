select ccd_codcartacr, ccd_nroccreddet, ccd_tipoemision,
oc.cla_comision,
cto.descrip,oco_monto total, 
monto_mo comision, oco_montoimpt iva,
esq.cod_cargo 
from car_cartascrdet, soc_opecomi oc, soc_esquemas esq, soc_comitipoope cto
where ccd_soccodigo = oc.ope_codigo
and oc.det_codigo = 0
and ccd_esqcodigo = esq.esq_codigo
and cto.cod_cargo = esq.cod_cargo
and cto.cla_comisionopecomi = oc.cla_comision
and ccd_codcartacr = '000072' ;

select oc.cla_comision,
(case
    when (oc.cla_comision = 'MONTOCOMEMISCARTCREDSLD') then
        'MONTO SALDO'
    when (oc.cla_comision = 'MONTOCOMEMISCARTCREDMT') then
        'MONTO TRANSFERENCIA'
end) sobre_monto_desc,
factura rango_fechas,oco_montoimpt nrodias,monto_mo sobre_monto,
oc.cod_moneda, 
(select m.mon_sigla from gen_moneda m where m.cod_moneda = oc.cod_moneda) cod_moneda_sigla,
oco_monto comision_bs
from car_cartascrdet, soc_opecomi oc, soc_esquemas esq
where ccd_soccodigo = oc.ope_codigo
and oc.det_codigo = 0
and ccd_esqcodigo = esq.esq_codigo
and ccd_codcartacr = '000072'
and ccd_nroccreddet = 5
and oc.cla_comision in ('MONTOCOMEMISCARTCREDMT','MONTOCOMEMISCARTCREDSLD');

select ccd_codcartacr, ccd_nroccreddet, ccd_tipoemision,oc.cla_comision,ccd_soccodigo,
cto.descrip,oco_monto total, 
(select ocmt.monto_mo 
    from soc_opecomi ocmt 
    where ocmt.ope_codigo = ccd_soccodigo 
    and ocmt.cla_comision = 'MONTOCOMEMISCARTCREDMT' 
    and ocmt.det_codigo = 0) sobre_monto,
(select ocmt.oco_monto
    from soc_opecomi ocmt 
    where ocmt.ope_codigo = ccd_soccodigo 
    and ocmt.cla_comision = 'MONTOCOMEMISCARTCREDMT' 
    and ocmt.det_codigo = 0) comision_bs,
monto_mo comision, oco_montoimpt iva,
esq.cod_cargo 
from car_cartascrdet, soc_opecomi oc, soc_esquemas esq, soc_comitipoope cto
where ccd_soccodigo = oc.ope_codigo
and oc.det_codigo = 0
and ccd_esqcodigo = esq.esq_codigo
and cto.cod_cargo = esq.cod_cargo
and cto.cla_comisionopecomi = oc.cla_comision
and ccd_codcartacr = '000072' ;
--and oc.cla_comision in ('MONTOCOMEMISCARTCREDMT','MONTOCOMEMISCARTCREDSLD');



select cla_comision,ope_codigo,det_codigo,
oco_monto,monto_mo,
oc.cod_moneda,
(select m.mon_sigla from gen_moneda m where m.cod_moneda = oc.cod_moneda) opecomimoneda_sigla,
oco_montoimpt,nro_cuenta,cve_tipocomis,
tipo_cambio,cla_estadovar,
nit,factura
from soc_opecomi oc
--where oc.ope_codigo = '006518'
where oc.cla_comision in ('MONTOCOMEMISCARTCREDMT','MONTOCOMEMISCARTCREDSLD');


select car_cartascrdet.*
from car_cartascr, car_cartascrdet
where ccr_codcartacr = ccd_codcartacr
and ccd_estregistro = 'V'
and ccr_codcartacr = '000067'
and ccd_tipoemision in ('E','I','D')
--and ccd_tipoemision in ('P')
order by ccd_nroccreddet;
