create   index idx_swfmen02 on swf_mensaje (
        men_Codoperacion         ASC,
men_Detcodigo asc
);
-- grant contbcb
grant select on "d_conta".afectable_concilia to "w_siocw" as "d_conta";

-- siocweb
alter table d_siocw.soc_claves modify (cla_codigo varchar(30) not null);
alter table d_siocw.soc_valorescla modify (cla_codigo VARCHAR(30) NOT NULL);

alter table d_siocw.soc_solicitudctas modify (tipo_cuenta varchar(30) not null);
alter table d_siocw.soc_comitipoope modify (cla_comision varchar(30) not null);
alter table d_siocw.soc_comitipoope add (cla_cuenta varchar(30));
alter table d_siocw.soc_comitipoope add (sct_tipocuenta varchar(15));
alter table d_siocw.soc_comitipoope add (cla_comisvarfact varchar(30));
alter table d_siocw.soc_comitipoope add (cla_comisionopecomi varchar(30) before descrip);
-- cla_formapago: U=uno por comprob; D:se calc tambien por detalle
alter table d_siocw.soc_comitipoope add (cla_formapago varchar(10) default "U");
alter table d_siocw.soc_comitipoope add (com_auditusr VARCHAR(30));
alter table d_siocw.soc_comitipoope add (com_auditfho DATETIME YEAR TO SECOND);
alter table d_siocw.soc_comitipoope add (com_auditwst VARCHAR(30));

update d_siocw.soc_comitipoope
set cla_cuenta = 'CTA_UTILESESC',
cla_comisionopecomi = 'MONTOGASTOADM',
sct_tipocuenta = 'COMGADM',
cla_comisvarfact = 'ADM',
cod_moneda = 69,
descrip = 'UTILES DE ESCRITORIO'
where cla_comision = 'UTIL';

update d_siocw.soc_comitipoope
set cla_cuenta = 'CTA_GASTOSCOM',
cla_comisionopecomi = 'MONTOGASTOCOM',
sct_tipocuenta = 'COMGADM',
cla_comisvarfact = 'ADM',
cod_moneda = 69,
descrip = 'COSTO DE MENSAJERIA SWIFT',
cla_formapago = 'D'
where cla_comision = 'SWFT';

update d_siocw.soc_comitipoope
set cla_cuenta = 'CTA_COMTRANDEXT',
cla_comisionopecomi = 'MONTOCOMTRANSEXT',
sct_tipocuenta = 'COMCTRA',
cla_comisvarfact = 'CTRA',
cod_moneda = 69,
descrip = 'COMISION POR TRANSFERENCIA DEL EXTERIOR'
where cla_comision = 'CDEX';

update d_siocw.soc_comitipoope
set cla_cuenta = 'CTA_COMTRANEXT',
cla_comisionopecomi = 'MONTOCOMTRANSEXT',
sct_tipocuenta = 'COMCTRA',
cla_comisvarfact = 'CTRA',
cod_moneda = 69,
descrip = 'COMISION POR TRANSF. AL EXTERIOR SIST FINANCIERO',
cla_formapago = 'D'
where cla_comision = 'CTRF';

update d_siocw.soc_comitipoope
set cla_cuenta = 'CTA_COMTRANEXT',
cla_comisionopecomi = 'MONTOCOMTRANSEXT',
sct_tipocuenta = 'COMCTRA',
cla_comisvarfact = 'CTRA',
cod_moneda = 69,
descrip = 'COMISION POR TRANSF. AL EXTERIOR SECTOR PUBLICO',
cla_formapago = 'D'
where cla_comision = 'CTRA';

-- datos de la CP para cartas
insert into d_siocw.soc_valorescla (cla_codigo, val_codigo, val_nombre, cla_vigente, usr_codigo, fecha_hora, estacion) values ('cla_rengcp', null, '70003-3', 1, 'adm', current, 'adm');

--claves
insert into d_siocw.soc_claves (cla_codigo,cla_nombre,usr_codigo,fecha_hora,estacion) values ('ccr_estadoccred', 'ESTADO CARTA CREDITO','ADM',current,'ADM');
insert into d_siocw.soc_valorescla (cla_codigo, val_codigo, val_nombre,cla_vigente,usr_codigo,fecha_hora,estacion) values ('ccr_estadoccred', 'R', 'REGISTRADO',1,'ADM',current,'ADM');
insert into d_siocw.soc_valorescla (cla_codigo, val_codigo, val_nombre,cla_vigente,usr_codigo,fecha_hora,estacion) values ('ccr_estadoccred', 'V', 'VIGENTE',1,'ADM',current,'ADM');
insert into d_siocw.soc_valorescla (cla_codigo, val_codigo, val_nombre,cla_vigente,usr_codigo,fecha_hora,estacion) values ('ccr_estadoccred', 'L', 'LIQUIDADO',1,'ADM',current,'ADM');
insert into d_siocw.soc_valorescla (cla_codigo, val_codigo, val_nombre,cla_vigente,usr_codigo,fecha_hora,estacion) values ('ccr_estadoccred', 'A', 'ANULADO',1,'ADM',current,'ADM');

insert into d_siocw.soc_claves (cla_codigo,cla_nombre,usr_codigo,fecha_hora,estacion) values ('ccd_estmovccred', 'ESTADO OPERACION CARTA CREDITO','ADM',current,'ADM');
insert into d_siocw.soc_valorescla (cla_codigo, val_codigo, val_nombre,cla_vigente,usr_codigo,fecha_hora,estacion) values ('ccd_estmovccred', 'P', 'PENDIENTE',1,'ADM',current,'ADM');
insert into d_siocw.soc_valorescla (cla_codigo, val_codigo, val_nombre,cla_vigente,usr_codigo,fecha_hora,estacion) values ('ccd_estmovccred', '1', 'PRE AUTORIZADO',1,'ADM',current,'ADM');
insert into d_siocw.soc_valorescla (cla_codigo, val_codigo, val_nombre,cla_vigente,usr_codigo,fecha_hora,estacion) values ('ccd_estmovccred', 'A', 'AUTORIZADO',1,'ADM',current,'ADM');

insert into d_siocw.soc_claves (cla_codigo,cla_nombre,usr_codigo,fecha_hora,estacion) values ('cve_tipomovcarta', 'TIPO DE OPERACION CARTA DE CREDITO','ADM',current,'ADM');
insert into d_siocw.soc_valorescla (cla_codigo, val_codigo, val_nombre,cla_vigente,usr_codigo,fecha_hora,estacion) values ('cve_tipomovcarta', 'A', 'REGISTRO DE AFECTACION',1,'ADM',current,'ADM');
insert into d_siocw.soc_valorescla (cla_codigo, val_codigo, val_nombre,cla_vigente,usr_codigo,fecha_hora,estacion) values ('cve_tipomovcarta', 'E', 'REGISTRO DE ENMIENDA',1,'ADM',current,'ADM');
insert into d_siocw.soc_valorescla (cla_codigo, val_codigo, val_nombre,cla_vigente,usr_codigo,fecha_hora,estacion) values ('cve_tipomovcarta', 'P', 'REGISTRO DE PAGO',1,'ADM',current,'ADM');

insert into d_siocw.soc_claves (cla_codigo,cla_nombre,usr_codigo,fecha_hora,estacion) values ('cve_tipoemiscarta', 'TIPO DE AFECTATACION','ADM',current,'ADM');
insert into d_siocw.soc_valorescla (cla_codigo, val_codigo, val_nombre,cla_vigente,usr_codigo,fecha_hora,estacion) values ('cve_tipoemiscarta', 'E', 'EMISION',1,'ADM',current,'ADM');
insert into d_siocw.soc_valorescla (cla_codigo, val_codigo, val_nombre,cla_vigente,usr_codigo,fecha_hora,estacion) values ('cve_tipoemiscarta', 'I', 'INCREMENTO',1,'ADM',current,'ADM');
insert into d_siocw.soc_valorescla (cla_codigo, val_codigo, val_nombre,cla_vigente,usr_codigo,fecha_hora,estacion) values ('cve_tipoemiscarta', 'D', 'DECREMENTO',1,'ADM',current,'ADM');
insert into d_siocw.soc_valorescla (cla_codigo, val_codigo, val_nombre,cla_vigente,usr_codigo,fecha_hora,estacion) values ('cve_tipoemiscarta', 'R', 'ENMIENDA REDUCCION',1,'ADM',current,'ADM');
insert into d_siocw.soc_valorescla (cla_codigo, val_codigo, val_nombre,cla_vigente,usr_codigo,fecha_hora,estacion) values ('cve_tipoemiscarta', 'A', 'ENMIENDA AMPLIACION',1,'ADM',current,'ADM');
insert into d_siocw.soc_valorescla (cla_codigo, val_codigo, val_nombre,cla_vigente,usr_codigo,fecha_hora,estacion) values ('cve_tipoemiscarta', 'P', 'PAGO',1,'ADM',current,'ADM');
insert into d_siocw.soc_valorescla (cla_codigo, val_codigo, val_nombre,cla_vigente,usr_codigo,fecha_hora,estacion) values ('cve_tipoemiscarta', 'M', 'MODIFICACION DATOS',1,'ADM',current,'ADM');

-- comisiones para emision apertura de Cartas 
-- CECC comision por emision de carta de credito
insert into d_siocw.soc_comitipoope (cod_cargo, cla_comision, cla_comisionopecomi, descrip, cod_moneda, valor, cla_tipocargo, cla_operacion, cla_cuenta, sct_tipocuenta, cla_comisvarfact, cla_formapago) values (5, 'MONTOCOMEMISCARTCREDMO', 'MONTOCOMEMISCARTCRED', 'COMISION POR EMISION CARTAS DE CREDITO', 69, 0.15, 'D', 'TECC', 'CTA_COMEMISCARTCRED', 'COMGADM', 'ADM', 'U');
insert into d_siocw.soc_comitipoope (cod_cargo, cla_comision, cla_comisionopecomi, descrip, cod_moneda, valor, cla_tipocargo, cla_operacion, cla_cuenta, sct_tipocuenta, cla_comisvarfact, cla_formapago) values (5, 'SWFT', 'MONTOGASTOCOM', 'COSTO DE MENSAJERIA SWIFT', 69, 220.00, 'F', 'TECC', 'CTA_GASTOSCOM', 'COMGADM', 'ADM', 'D');
insert into d_siocw.soc_comitipoope (cod_cargo, cla_comision, cla_comisionopecomi, descrip, cod_moneda, valor, cla_tipocargo, cla_operacion, cla_cuenta, sct_tipocuenta, cla_comisvarfact, cla_formapago) values (5, 'UTIL', 'MONTOGASTOADM', 'UTILES DE ESCRITORIO', 69, 50.00, 'F', 'TECC', 'CTA_UTILESESC', 'COMGADM', 'ADM', 'U');

-- comisiones por enmienda de Cartas 
-- CECC comision por emision de carta de credito
insert into d_siocw.soc_comitipoope (cod_cargo, cla_comision, cla_comisionopecomi, descrip, cod_moneda, valor, cla_tipocargo, cla_operacion, cla_cuenta, sct_tipocuenta, cla_comisvarfact, cla_formapago) values (6, 'MONTOCOMEMISCARTCREDMO', 'MONTOCOMEMISCARTCRED', 'COMISION POR EMISION CARTAS DE CREDITO', 69, 0.15, 'D', 'TECC', 'CTA_COMEMISCARTCRED', 'COMGADM', 'ADM', 'U');
insert into d_siocw.soc_comitipoope (cod_cargo, cla_comision, cla_comisionopecomi, descrip, cod_moneda, valor, cla_tipocargo, cla_operacion, cla_cuenta, sct_tipocuenta, cla_comisvarfact, cla_formapago) values (6, 'MONTOCOMENMIENDAMO', 'MONTOCOMENMIENDA', 'COMISION POR ENMIENDA', 69, 220.00, 'F', 'ENMC', 'CTA_COMEMISCARTCRED', 'COMGADM', 'ADM', 'U');
insert into d_siocw.soc_comitipoope (cod_cargo, cla_comision, cla_comisionopecomi, descrip, cod_moneda, valor, cla_tipocargo, cla_operacion, cla_cuenta, sct_tipocuenta, cla_comisvarfact, cla_formapago) values (6, 'SWFT', 'MONTOGASTOCOM', 'COSTO DE MENSAJERIA SWIFT', 69, 220.00, 'F', 'ENMC', 'CTA_GASTOSCOM', 'COMGADM', 'ADM', 'D');
insert into d_siocw.soc_comitipoope (cod_cargo, cla_comision, cla_comisionopecomi, descrip, cod_moneda, valor, cla_tipocargo, cla_operacion, cla_cuenta, sct_tipocuenta, cla_comisvarfact, cla_formapago) values (6, 'UTIL', 'MONTOGASTOADM', 'UTILES DE ESCRITORIO', 69, 50.00, 'F', 'ENMC', 'CTA_UTILESESC', 'COMGADM', 'ADM', 'U');

-- comisiones por pago
insert into d_siocw.soc_comitipoope (cod_cargo, cla_comision, cla_comisionopecomi, descrip, cod_moneda, valor, cla_tipocargo, cla_operacion, cla_cuenta, sct_tipocuenta, cla_comisvarfact, cla_formapago) values (7, 'MONTOCOMTRANSEXTMO', 'MONTOCOMTRANSEXT', 'COMISION POR TRANSF. AL EXT. SECTOR PUB.(CARTAS CREDITO)', 69, 0.10, 'P', 'TE', 'CTA_COMTRANEXT', 'COMCTRA', 'CTRA', 'D');
insert into d_siocw.soc_comitipoope (cod_cargo, cla_comision, cla_comisionopecomi, descrip, cod_moneda, valor, cla_tipocargo, cla_operacion, cla_cuenta, sct_tipocuenta, cla_comisvarfact, cla_formapago) values (7, 'SWFT', 'MONTOGASTOCOM', 'COSTO DE MENSAJERIA SWIFT', 69, 220.00, 'F', 'TE', 'CTA_GASTOSCOM', 'COMGADM', 'ADM', 'D');
insert into d_siocw.soc_comitipoope (cod_cargo, cla_comision, cla_comisionopecomi, descrip, cod_moneda, valor, cla_tipocargo, cla_operacion, cla_cuenta, sct_tipocuenta, cla_comisvarfact, cla_formapago) values (7, 'UTIL', 'MONTOGASTOADM', 'UTILES DE ESCRITORIO', 69, 50.00, 'F', 'TE', 'CTA_UTILESESC', 'COMGADM', 'ADM', 'U');

-- comisiones por enmienda decremento
insert into d_siocw.soc_comitipoope (cod_cargo, cla_comision, cla_comisionopecomi, descrip, cod_moneda, valor, cla_tipocargo, cla_operacion, cla_cuenta, sct_tipocuenta, cla_comisvarfact, cla_formapago) values (8, 'MONTOCOMENMIENDAMO', 'MONTOCOMENMIENDA', 'COMISION POR ENMIENDA', 69, 220.00, 'F', 'ENMC', 'CTA_COMEMISCARTCRED', 'COMGADM', 'ADM', 'U');
insert into d_siocw.soc_comitipoope (cod_cargo, cla_comision, cla_comisionopecomi, descrip, cod_moneda, valor, cla_tipocargo, cla_operacion, cla_cuenta, sct_tipocuenta, cla_comisvarfact, cla_formapago) values (8, 'SWFT', 'MONTOGASTOCOM', 'COSTO DE MENSAJERIA SWIFT', 69, 220.00, 'F', 'ENMC', 'CTA_GASTOSCOM', 'COMGADM', 'ADM', 'D');
insert into d_siocw.soc_comitipoope (cod_cargo, cla_comision, cla_comisionopecomi, descrip, cod_moneda, valor, cla_tipocargo, cla_operacion, cla_cuenta, sct_tipocuenta, cla_comisvarfact, cla_formapago) values (8, 'UTIL', 'MONTOGASTOADM', 'UTILES DE ESCRITORIO', 69, 50.00, 'F', 'ENMC', 'CTA_UTILESESC', 'COMGADM', 'ADM', 'U');


insert into d_siocw.soc_valorescla (cla_codigo, val_codigo, val_nombre, cla_vigente, usr_codigo, fecha_hora, estacion) values ('cve_conceptofac', 'CTA_COMEMISCARTCRED', 'COMISION EMISION', 1, 'ADM', current, 'ADM');

-- cuentas para cartas de credito
insert into d_siocw.soc_cuentassol (cta_codigo, cta_movimiento, moneda, cta_nommovimiento, cta_afectable, cla_cuenta, partida, cve_imptsigma, cve_imptppto, cve_imptiva, cla_vigente, usr_codigo, fecha_hora, estacion, gen_itf) values (157, '7329', 34, 'GARANTIAS POR ACREDITIVOS - EMPRESAS PUBLICAS', '013308', 'CTA_GARANT_ACREDIT', null, 'N', 'N', 'N', 1, '1653', current, '172.29.18.21', 0);
insert into d_siocw.soc_cuentassol (cta_codigo, cta_movimiento, moneda, cta_nommovimiento, cta_afectable, cla_cuenta, partida, cve_imptsigma, cve_imptppto, cve_imptiva, cla_vigente, usr_codigo, fecha_hora, estacion, gen_itf) values (158, '7329', 53, 'GARANTIAS POR ACREDITIVOS - EMPRESAS PUBLICAS - EUR', '013309', 'CTA_GARANT_ACREDIT', null, 'N', 'N', 'N', 1, '1653', current, '172.29.18.21', 0);
-- cta comisiones emision
insert into d_siocw.soc_cuentassol (cta_codigo, cta_movimiento, moneda, cta_nommovimiento, cta_afectable, cla_cuenta, partida, cve_imptsigma, cve_imptppto, cve_imptiva, cla_vigente, usr_codigo, fecha_hora, estacion, gen_itf) values (159, '1554', 69, 'COMISIONES POR EMISION DE CARTAS DE CREDITO', '001752', 'CTA_COMEMISCARTCRED', null, 'N', 'S', 'C', 1, '1653', current, 'dba', 0);

-- esquemas de emision de carta de credito

insert into d_siocw.soc_esquemas (esq_codigo, cod_tipooper, cod_tipoperacion, cve_tiposolic, cod_moneda, cla_operacion, cla_subtipo, esq_descrip, cla_vigente, glosa_comp, provisiona, tipo_retencion, tipo_transfer, genera, cod_esqref, cod_cargo, cve_subtipooper, usr_codigo, fecha_hora, estacion) values (110, 'VE', 'V10', null, '', 'VDD', 'CCRED', 'VENTA DE DIVISAS EMISION DE CARTAS DE CREDITO', '1', 'VENTA DE DIVISAS A SOLICITUD DE @CCSOLICITANTE POR EMISION CARTA DE CREDITO @CCCORRELATIVO @CCNRODIASMT SEGUN SOLICITUD @NROMEFP REF: @GLOSASOL', '', 'S', 'P', 'WSP', 301, 5, 'CC', 'adm', TO_DATE('2014-06-23 17:57:49', '%Y-%m-%d %H:%M:%S'), 'adm');

insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (110, 100, null, 'MOVPROVISION', 'D', 'TOTALPROV', '', 'PROVISION DE FONDOS EMISION @CCCORRELATIVO @CCBENEF @CTALIB-MOVPROVISION', null, 0, '5110', 'TIPOSIGMA=PVD&DOCSIGMA=@DOCSIGMA');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (110, 200, null, 'CTA_GARANT_ACREDIT', 'H', 'TOTTRANSMT', '', '@NROCONCILIA @CCCORRELATIVO @CCBENEF', null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (110, 300, null, 'CTA_DIFCAMBVDD', 'H', 'MONTODIFCAMBVENDIV', null, null, null, 0, null, null);
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (110, 400, null, 'DIFCAMB', 'D', 'DIFERTC', '', '@CTALIB-DIFCAMB POR DIFERENCIAL CAMBIARIO', null, 0, '', 'TIPOSIGMA=DVD&TIPOSIGMAH=PVD&DOCSIGMA=@DOCSIGMA');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (110, 500, null, 'COMGADM', 'D', 'TOTCOMISION', '', '@CTALIB-COMGADM REF: COMISIONES EMISION @CCCORRELATIVO', null, 0, '', 'TIPOSIGMA=CVD&DOCSIGMA=@DOCSIGMA');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (110, 600, null, 'CTA_COMEMISCARTCRED', 'H', 'MONTOCOMEMISCARTCRED', null, 'COMISION POR EMISION', null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (110, 700, null, 'CTA_GASTOSCOM', 'H', 'MONTOGASTOCOM', null, null, null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (110, 800, null, 'CTA_UTILESESC', 'H', 'MONTOGASTOADM', null, null, null, 0, null, 'VFACMO=COMUTIL&VFACIVA=MONTOGASTOADMIVA&VFACT=ADM');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (110, 900, null, 'CTA_DEBFISCAL', 'H', 'MONTOCOMIVA', null, null, null, 0, null, null);


insert into d_siocw.soc_esquemas (esq_codigo, cod_tipooper, cod_tipoperacion, cve_tiposolic, cod_moneda, cla_operacion, cla_subtipo, esq_descrip, cla_vigente, glosa_comp, provisiona, tipo_retencion, tipo_transfer, genera, cod_esqref, cod_cargo, cve_subtipooper, usr_codigo, fecha_hora, estacion) values (5110, 'RET', 'RETEMISCC', null, null, 'RET', '', 'RETIRO POR VENTA DE DIVISAS EMISION DE CARTAS DE CREDITO', '1', 'VENTA DE DIVISAS A SOLICITUD DE @CCSOLICITANTE POR EMISION CARTA DE CREDITO @CCCORRELATIVO @CCNRODIASMT SEGUN SOLICITUD @NROMEFP REF: @GLOSASOL', '', 'S', 'C', '', null, null, 'TRA', 'ADM', current, 'ADMBDD');

insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5110, 100, null, 'MOVPROVISION', 'D', 'TOTALPROV', '', 'PROVISION DE FONDOS EMISION @CCCORRELATIVO @CCBENEF @CTALIB-MOVPROVISION', null, 0, '', 'TIPOSIGMA=PVD&DOCSIGMA=@DOCSIGMA');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5110, 200, null, 'CTA_GARANT_ACREDIT', 'H', 'TOTTRANSMT', '', '@NROCONCILIA @CCCORRELATIVO @CCBENEF', null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5110, 300, null, 'CTA_DIFCAMBVDD', 'H', 'MONTODIFCAMBVENDIV', null, null, null, 0, null, null);
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5110, 400, null, 'DIFCAMB', 'D', 'DIFERTC', '', '@CTALIB-DIFCAMB POR DIFERENCIAL CAMBIARIO', null, 0, '', 'TIPOSIGMA=DVD&TIPOSIGMAH=PVD&DOCSIGMA=@DOCSIGMA');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5110, 500, null, 'COMGADM', 'D', 'TOTCOMISION', '', '@CTALIB-COMGADM REF: COMISIONES EMISION @CCCORRELATIVO', null, 0, '', 'TIPOSIGMA=CVD&DOCSIGMA=@DOCSIGMA');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5110, 600, null, 'CTA_COMEMISCARTCRED', 'H', 'MONTOCOMEMISCARTCRED', null, 'COMISION POR EMISION', null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5110, 700, null, 'CTA_GASTOSCOM', 'H', 'MONTOGASTOCOM', null, null, null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5110, 800, null, 'CTA_UTILESESC', 'H', 'MONTOGASTOADM', null, null, null, 0, null, 'VFACMO=COMUTIL&VFACIVA=MONTOGASTOADMIVA&VFACT=ADM');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5110, 900, null, 'CTA_DEBFISCAL', 'H', 'MONTOCOMIVA', null, null, null, 0, null, null);


-- esquema de pago operacion
insert into d_siocw.soc_esquemas (esq_codigo, cod_tipooper, cod_tipoperacion, cve_tiposolic, cod_moneda, cla_operacion, cla_subtipo, esq_descrip, cla_vigente, glosa_comp, provisiona, tipo_retencion, tipo_transfer, genera, cod_esqref, cod_cargo, cve_subtipooper, usr_codigo, fecha_hora, estacion) values (281, 'CC', 'CCPGOP', '000', '999', 'RESP POR CANCEL', '', 'RESPUESTA AL BANQUERO POR CANCELACION', '1', 'RESPUESTA AL BANQUERO POR CANCELACION DE CARTA DE CREDITO @CCCORRELATIVO @CCSOLICITANTE @CCBENEF SEGUN @CCEMISNROMEFP DE FECHA @CCEMISFECHASOL SEGUN: @CCCCDGLOSA', null, 'S', 'S', 'SSP', null, 7, 'TE', 'adm', CURRENT, 'adm');

insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (281, 100, null, 'CTA_GARANT_ACREDIT', 'D', 'TOTALPROV', null, '@NROCONCILIA', null, 0, '5281', null);
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (281, 200, null, 'BENEFMT', 'H', 'MONTOD', null, '@CCCUENTABEN', null, 1, null, null);
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (281, 400, null, 'DIFCAMB', 'D', 'DIFERTC', '', '@CTALIB-DIFCAMB POR DIFERENCIAL CAMBIARIO', null, 0, '', '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (281, 500, null, 'COMGADM', 'D', 'TOTCOMISION', '', '@CTALIB-COMGADM', null, 0, '5282', 'TIPOSIGMA=CVD&DOCSIGMA=@DOCSIGMA');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (281, 600, null, 'CTA_COMTRANEXT', 'H', 'MONTOCOMTRANSEXT', '', '@CTALIB-COMGADM', null, 0, '', '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (281, 700, null, 'CTA_GASTOSCOM', 'H', 'MONTOGASTOCOM', null, null, null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (281, 800, null, 'CTA_UTILESESC', 'H', 'MONTOGASTOADM', null, null, null, 0, null, 'TIPOSIGMA=CVD&DOCSIGMA=@DOCSIGMA');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (281, 900, null, 'CTA_DEBFISCAL', 'H', 'MONTOCOMIVA', null, null, null, 0, null, null);

--esq pago transferencia
insert into d_siocw.soc_esquemas (esq_codigo, cod_tipooper, cod_tipoperacion, cve_tiposolic, cod_moneda, cla_operacion, cla_subtipo, esq_descrip, cla_vigente, glosa_comp, provisiona, tipo_retencion, tipo_transfer, genera, cod_esqref, cod_cargo, cve_subtipooper, usr_codigo, fecha_hora, estacion) values (5281, 'CC', 'CCPGOPTRA', '000', '999', 'PAGO CC TRANSF', '', 'RESPUESTA AL BANQUERO POR CANCELACION TRANSFERENCIA', '1', 'RESPUESTA AL BANQUERO POR CANCELACION DE CARTA DE CREDITO @CCCORRELATIVO @CCSOLICITANTE @CCBENEF SEGUN @CCEMISNROMEFP DE FECHA @CCEMISFECHASOL SEGUN: @CCCCDGLOSA', null, 'S', 'S', 'SSP', null, 7, 'TE', 'adm', CURRENT, 'adm');

insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5281, 100, null, 'CTA_GARANT_ACREDIT', 'D', 'TOTALPROV', null, '@NROCONCILIA', null, 0, '', null);
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5281, 200, null, 'BENEFMT', 'H', 'MONTOD', null, '@CCCUENTABEN', null, 1, null, null);
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5281, 300, null, 'DIFCAMB', 'D', 'DIFERTC', '', '@CTALIB-DIFCAMB POR DIFERENCIAL CAMBIARIO', null, 0, '', '');

--esq pago transferencia COBRO COMIS
insert into d_siocw.soc_esquemas (esq_codigo, cod_tipooper, cod_tipoperacion, cve_tiposolic, cod_moneda, cla_operacion, cla_subtipo, esq_descrip, cla_vigente, glosa_comp, provisiona, tipo_retencion, tipo_transfer, genera, cod_esqref, cod_cargo, cve_subtipooper, usr_codigo, fecha_hora, estacion) values (5282, 'CC', 'CCPGTRACOM', '000', '999', 'COB. TR AL EXT CC', '', 'COBRO DE COMISIONES POR TRANSFERENCIA DE FONDOS AL EXTERIOR', '1', 'REGISTRO COBRO COMISION TRANSFERENCIA AL EXTERIOR POR @CCMONTOTRANS SEGUN @CCCCDGLOSA EN COMPLEMENTO A CBTE: @CCNROCBTETRX', null, 'S', 'S', 'SSP', null, 7, 'TE', '1576', CURRENT, 'adm');

insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5282, 500, null, 'COMGADM', 'D', 'TOTCOMISION', '', '@CTALIB-COMGADM', null, 0, '', 'TIPOSIGMA=CVD&DOCSIGMA=@DOCSIGMA');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5282, 600, null, 'CTA_COMTRANEXT', 'H', 'MONTOCOMTRANSEXT', '', '@CTALIB-COMGADM', null, 0, '', '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5282, 700, null, 'CTA_GASTOSCOM', 'H', 'MONTOGASTOCOM', null, null, null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5282, 800, null, 'CTA_UTILESESC', 'H', 'MONTOGASTOADM', null, null, null, 0, null, 'TIPOSIGMA=CVD&DOCSIGMA=@DOCSIGMA');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5282, 900, null, 'CTA_DEBFISCAL', 'H', 'MONTOCOMIVA', null, null, null, 0, null, null);


-- swift transferencia de pago
--E: benef en el ext; F: ent financiera
--alter table d_siocw.swf_mttransfer (mtt_tipobenef varchar(20));
-- 
--alter table d_siocw.swf_mttransfer (mtt_tiporeceiver varchar(20));
--alter table d_siocw.swf_mttransfer (mtt_tipoenvio varchar(20));

insert into d_siocw.swf_mttransfer (mtt_codttransfer, mtt_descrip, mtt_codmt) values ('202E', '[202E]Ent Depositaria con BIC/Ent Benef con BIC', '202');

insert into d_siocw.swf_mttransferdet (dtt_codttransfer, dtt_codcampo, dtt_bloque, dtt_tipocampo, dtt_valcampo) values ('202E', '108', 3, 'K', 'AUT');
insert into d_siocw.swf_mttransferdet (dtt_codttransfer, dtt_codcampo, dtt_bloque, dtt_tipocampo, dtt_valcampo) values ('202E', '20', 4, 'C', null);
insert into d_siocw.swf_mttransferdet (dtt_codttransfer, dtt_codcampo, dtt_bloque, dtt_tipocampo, dtt_valcampo) values ('202E', '21', 4, 'K', 'NONREF');
insert into d_siocw.swf_mttransferdet (dtt_codttransfer, dtt_codcampo, dtt_bloque, dtt_tipocampo, dtt_valcampo) values ('202E', '32A', 4, 'C', null);
insert into d_siocw.swf_mttransferdet (dtt_codttransfer, dtt_codcampo, dtt_bloque, dtt_tipocampo, dtt_valcampo) values ('202E', '53B', 4, 'C', null);
insert into d_siocw.swf_mttransferdet (dtt_codttransfer, dtt_codcampo, dtt_bloque, dtt_tipocampo, dtt_valcampo) values ('202E', '57A', 4, 'C', null);
insert into d_siocw.swf_mttransferdet (dtt_codttransfer, dtt_codcampo, dtt_bloque, dtt_tipocampo, dtt_valcampo) values ('202E', '58A', 4, 'C', null);
insert into d_siocw.swf_mttransferdet (dtt_codttransfer, dtt_codcampo, dtt_bloque, dtt_tipocampo, dtt_valcampo) values ('202E', '72', 4, 'C', null);
insert into d_siocw.swf_mttransferdet (dtt_codttransfer, dtt_codcampo, dtt_bloque, dtt_tipocampo, dtt_valcampo) values ('202E', 'IDAPP', 1, 'K', 'F');
insert into d_siocw.swf_mttransferdet (dtt_codttransfer, dtt_codcampo, dtt_bloque, dtt_tipocampo, dtt_valcampo) values ('202E', 'SERVID', 1, 'K', '01');
insert into d_siocw.swf_mttransferdet (dtt_codttransfer, dtt_codcampo, dtt_bloque, dtt_tipocampo, dtt_valcampo) values ('202E', 'LTID', 1, 'K', 'A');
insert into d_siocw.swf_mttransferdet (dtt_codttransfer, dtt_codcampo, dtt_bloque, dtt_tipocampo, dtt_valcampo) values ('202E', 'SESSNUM', 1, 'K', '1000');
insert into d_siocw.swf_mttransferdet (dtt_codttransfer, dtt_codcampo, dtt_bloque, dtt_tipocampo, dtt_valcampo) values ('202E', 'SEQNUM', 1, 'K', '100001');
insert into d_siocw.swf_mttransferdet (dtt_codttransfer, dtt_codcampo, dtt_bloque, dtt_tipocampo, dtt_valcampo) values ('202E', 'PRIOR', 2, 'K', 'N');

-- enmienda de modificacion de fechas

insert into d_siocw.soc_esquemas (esq_codigo, cod_tipooper, cod_tipoperacion, cve_tiposolic, cod_moneda, cla_operacion, cla_subtipo, esq_descrip, cla_vigente, glosa_comp, provisiona, tipo_retencion, tipo_transfer, genera, cod_esqref, cod_cargo, cve_subtipooper, usr_codigo, fecha_hora, estacion) values (283, 'CCEN', 'CCENCOBCOMENM', '000', '999', 'COB. COMIS. CC', '', 'COBRO DE COMISIONES POR ENMIENDA', '1', 'COBRO DE COMISION POR ENMIENDA DE @CCSOLICITANTE POR CARTA DE CREDITO @CCCORRELATIVO POR @CCCCDGLOSA', null, 'S', 'S', 'SSP', null, 6, 'CC', '1576', CURRENT, 'adm');

insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (283, 100, null, 'COMGADM', 'D', 'TOTCOMISION', '', '@CTALIB-COMGADM', null, 0, '5283', 'TIPOSIGMA=CVD&DOCSIGMA=@DOCSIGMA');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (283, 200, null, 'CTA_COMEMISCARTCRED', 'H', 'MONTOCOMEMISCARTCRED', null, 'COMISION POR EMISION', null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (283, 300, null, 'CTA_COMEMISCARTCRED', 'H', 'MONTOCOMENMIENDA', null, 'COMISION POR ENMIENDA', null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (283, 500, null, 'CTA_GASTOSCOM', 'H', 'MONTOGASTOCOM', null, null, null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (283, 600, null, 'CTA_UTILESESC', 'H', 'MONTOGASTOADM', null, null, null, 0, null, 'VFACMO=COMUTIL&VFACIVA=MONTOGASTOADMIVA&VFACT=ADM');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (283, 700, null, 'CTA_DEBFISCAL', 'H', 'MONTOCOMIVA', null, null, null, 0, null, null);

insert into d_siocw.soc_esquemas (esq_codigo, cod_tipooper, cod_tipoperacion, cve_tiposolic, cod_moneda, cla_operacion, cla_subtipo, esq_descrip, cla_vigente, glosa_comp, provisiona, tipo_retencion, tipo_transfer, genera, cod_esqref, cod_cargo, cve_subtipooper, usr_codigo, fecha_hora, estacion) values (5283, 'CCEN', 'CCENCOBCOMENM', '000', '999', 'COB. COMIS. CC', '', 'COBRO DE COMISIONES POR ENMIENDA', '1', 'COBRO DE COMISION POR ENMIENDA DE @CCSOLICITANTE POR CARTA DE CREDITO @CCCORRELATIVO POR @CCCCDGLOSA', null, 'S', 'S', 'SSP', null, 6, 'CC', '1576', CURRENT, 'adm');

insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5283, 100, null, 'COMGADM', 'D', 'TOTCOMISION', '', '@CTALIB-COMGADM', null, 0, '', 'TIPOSIGMA=CVD&DOCSIGMA=@DOCSIGMA');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5283, 200, null, 'CTA_COMEMISCARTCRED', 'H', 'MONTOCOMEMISCARTCRED', null, 'COMISION POR EMISION', null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5283, 300, null, 'CTA_COMEMISCARTCRED', 'H', 'MONTOCOMENMIENDA', null, 'COMISION POR ENMIENDA', null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5283, 500, null, 'CTA_GASTOSCOM', 'H', 'MONTOGASTOCOM', null, null, null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5283, 600, null, 'CTA_UTILESESC', 'H', 'MONTOGASTOADM', null, null, null, 0, null, 'VFACMO=COMUTIL&VFACIVA=MONTOGASTOADMIVA&VFACT=ADM');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5283, 700, null, 'CTA_DEBFISCAL', 'H', 'MONTOCOMIVA', null, null, null, 0, null, null);

-- enmienda por modificacion a monto

insert into d_siocw.soc_esquemas (esq_codigo, cod_tipooper, cod_tipoperacion, cve_tiposolic, cod_moneda, cla_operacion, cla_subtipo, esq_descrip, cla_vigente, glosa_comp, provisiona, tipo_retencion, tipo_transfer, genera, cod_esqref, cod_cargo, cve_subtipooper, usr_codigo, fecha_hora, estacion) values (285, 'VE', 'CCENF', null, '', 'VDD', 'CCRED', 'VENTA DE DIVISAS EMISION DE CARTAS DE CREDITO', '1', 'ENMIENDA DE @CCSOLICITANTE POR CARTA DE CREDITO @CCCORRELATIVO POR @CCMONTOTRANS REF: @CCCCDGLOSA', '', 'S', 'P', 'WSP', null, 6, 'CC', 'adm', CURRENT, 'adm');

insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (285, 100, null, 'MOVPROVISION', 'D', 'TOTALPROV', '', '@CTALIB-MOVPROVISION', null, 0, '5285', 'TIPOSIGMA=PVD&DOCSIGMA=@DOCSIGMA');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (285, 200, null, 'CTA_GARANT_ACREDIT', 'H', 'TOTTRANSMT', '', '@NROCONCILIA @CCCORRELATIVO @CCBENEF', null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (285, 300, null, 'CTA_DIFCAMBVDD', 'H', 'MONTODIFCAMBVENDIV', null, null, null, 0, null, null);
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (285, 400, null, 'DIFCAMB', 'D', 'DIFERTC', '', '@CTALIB-DIFCAMB POR DIFERENCIAL CAMBIARIO', null, 0, '', 'TIPOSIGMA=DVD&TIPOSIGMAH=PVD&DOCSIGMA=@DOCSIGMA');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (285, 500, null, 'COMGADM', 'D', 'TOTCOMISION', '', '@CTALIB-COMGADM', null, 0, '5288', 'TIPOSIGMA=CVD&DOCSIGMA=@DOCSIGMA');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (285, 600, null, 'CTA_COMEMISCARTCRED', 'H', 'MONTOCOMEMISCARTCRED', null, 'COMISION POR EMISION', null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (285, 700, null, 'CTA_COMEMISCARTCRED', 'H', 'MONTOCOMENMIENDA', null, 'COMISION POR ENMIENDA', null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (285, 800, null, 'CTA_GASTOSCOM', 'H', 'MONTOGASTOCOM', null, null, null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (285, 900, null, 'CTA_UTILESESC', 'H', 'MONTOGASTOADM', null, null, null, 0, null, 'VFACMO=COMUTIL&VFACIVA=MONTOGASTOADMIVA&VFACT=ADM');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (285, 1000, null, 'CTA_DEBFISCAL', 'H', 'MONTOCOMIVA', null, null, null, 0, null, null);

insert into d_siocw.soc_esquemas (esq_codigo, cod_tipooper, cod_tipoperacion, cve_tiposolic, cod_moneda, cla_operacion, cla_subtipo, esq_descrip, cla_vigente, glosa_comp, provisiona, tipo_retencion, tipo_transfer, genera, cod_esqref, cod_cargo, cve_subtipooper, usr_codigo, fecha_hora, estacion) values (5285, 'VE', 'CCENF', null, '', 'VDD', 'CCRED', 'VENTA DE DIVISAS POR ENMIENDA A EMISION DE CARTAS DE CREDITO', '1', 'ENMIENDA DE @CCSOLICITANTE POR CARTA DE CREDITO @CCCORRELATIVO POR @CCMONTOTRANS REF: @CCCCDGLOSA', '', 'S', 'P', 'WSP', null, 6, 'CC', 'adm', CURRENT, 'adm');

insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5285, 100, null, 'MOVPROVISION', 'D', 'TOTALPROV', '', '@CTALIB-MOVPROVISION', null, 0, '5285', 'TIPOSIGMA=PVD&DOCSIGMA=@DOCSIGMA');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5285, 200, null, 'CTA_GARANT_ACREDIT', 'H', 'TOTTRANSMT', '', '@NROCONCILIA @CCCORRELATIVO @CCBENEF', null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5285, 300, null, 'CTA_DIFCAMBVDD', 'H', 'MONTODIFCAMBVENDIV', null, null, null, 0, null, null);
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5285, 400, null, 'DIFCAMB', 'D', 'DIFERTC', '', '@CTALIB-DIFCAMB POR DIFERENCIAL CAMBIARIO', null, 0, '', 'TIPOSIGMA=DVD&TIPOSIGMAH=PVD&DOCSIGMA=@DOCSIGMA');

insert into d_siocw.soc_esquemas (esq_codigo, cod_tipooper, cod_tipoperacion, cve_tiposolic, cod_moneda, cla_operacion, cla_subtipo, esq_descrip, cla_vigente, glosa_comp, provisiona, tipo_retencion, tipo_transfer, genera, cod_esqref, cod_cargo, cve_subtipooper, usr_codigo, fecha_hora, estacion) values (5288, 'VE', 'CCENF', null, '', 'VDD', 'CCRED', 'COBRO DE COMISIONES POR ENMIENDA A INCREMENTO', '1', 'COBRO DE COMISIONES POR ENMIENDA DE @CCSOLICITANTE POR CARTA DE CREDITO @CCCORRELATIVO POR @CCMONTOTRANS REF: @CCCCDGLOSA', '', 'S', 'P', 'WSP', null, 6, 'CC', 'adm', CURRENT, 'adm');

insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5288, 500, null, 'COMGADM', 'D', 'TOTCOMISION', '', '@CTALIB-COMGADM', null, 0, '', 'TIPOSIGMA=CVD&DOCSIGMA=@DOCSIGMA');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5288, 600, null, 'CTA_COMEMISCARTCRED', 'H', 'MONTOCOMEMISCARTCRED', null, 'COMISION POR EMISION', null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5288, 700, null, 'CTA_COMEMISCARTCRED', 'H', 'MONTOCOMENMIENDA', null, 'COMISION POR ENMIENDA', null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5288, 800, null, 'CTA_GASTOSCOM', 'H', 'MONTOGASTOCOM', null, null, null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5288, 900, null, 'CTA_UTILESESC', 'H', 'MONTOGASTOADM', null, null, null, 0, null, 'VFACMO=COMUTIL&VFACIVA=MONTOGASTOADMIVA&VFACT=ADM');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5288, 1000, null, 'CTA_DEBFISCAL', 'H', 'MONTOCOMIVA', null, null, null, 0, null, null);


-- enmienda por modificacion a monto decremento

insert into d_siocw.soc_esquemas (esq_codigo, cod_tipooper, cod_tipoperacion, cve_tiposolic, cod_moneda, cla_operacion, cla_subtipo, esq_descrip, cla_vigente, glosa_comp, provisiona, tipo_retencion, tipo_transfer, genera, cod_esqref, cod_cargo, cve_subtipooper, usr_codigo, fecha_hora, estacion) values (286, 'CC', 'CCENF', null, '', 'CC', 'CCRED', 'ENMIENDA POR DECREMENTO EN MONTO', '1', 'ENMIENDA DECREMENTO DE @CCSOLICITANTE POR CARTA DE CREDITO @CCCORRELATIVO POR @CCMONTOTRANS REF: @CCCCDGLOSA', '', 'S', 'P', 'WSP', null, 8, 'CC', 'adm', CURRENT, 'adm');

insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (286, 100, null, 'CTA_GARANT_ACREDIT', 'D', 'TOTALPROV', '', '@NROCONCILIA', null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (286, 200, null, 'MOVPROVISION', 'H', 'TOTTRANSMT', '', '@CTALIB-MOVPROVISION', null, 0, '5286', 'TIPOSIGMA=PVD&DOCSIGMA=@DOCSIGMA');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (286, 300, null, 'DIFCAMB', 'D', 'DIFERTC', '', '@CTALIB-DIFCAMB POR DIFERENCIAL CAMBIARIO', null, 0, '', 'TIPOSIGMA=DVD&TIPOSIGMAH=PVD&DOCSIGMA=@DOCSIGMA');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (286, 500, null, 'COMGADM', 'D', 'TOTCOMISION', '', '@CTALIB-COMGADM', null, 0, '', 'TIPOSIGMA=CVD&DOCSIGMA=@DOCSIGMA');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (286, 700, null, 'CTA_COMEMISCARTCRED', 'H', 'MONTOCOMENMIENDA', null, 'COMISION POR ENMIENDA', null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (286, 800, null, 'CTA_GASTOSCOM', 'H', 'MONTOGASTOCOM', null, null, null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (286, 900, null, 'CTA_UTILESESC', 'H', 'MONTOGASTOADM', null, null, null, 0, null, 'VFACMO=COMUTIL&VFACIVA=MONTOGASTOADMIVA&VFACT=ADM');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (286, 1000, null, 'CTA_DEBFISCAL', 'H', 'MONTOCOMIVA', null, null, null, 0, null, null);

insert into d_siocw.soc_esquemas (esq_codigo, cod_tipooper, cod_tipoperacion, cve_tiposolic, cod_moneda, cla_operacion, cla_subtipo, esq_descrip, cla_vigente, glosa_comp, provisiona, tipo_retencion, tipo_transfer, genera, cod_esqref, cod_cargo, cve_subtipooper, usr_codigo, fecha_hora, estacion) values (5286, 'CC', 'CCENF', null, '', 'CC', 'CCRED', 'ENMIENDA POR DECREMENTO EN MONTO', '1', 'ENMIENDA DECREMENTO DE @CCSOLICITANTE POR CARTA DE CREDITO @CCCORRELATIVO POR @CCMONTOTRANS REF: @CCCCDGLOSA', '', 'S', 'P', 'WSP', null, 8, 'CC', 'adm', CURRENT, 'adm');

insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5286, 100, null, 'CTA_GARANT_ACREDIT', 'D', 'TOTALPROV', '', '@NROCONCILIA', null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5286, 200, null, 'MOVPROVISION', 'H', 'TOTTRANSMT', '', '@CTALIB-MOVPROVISION', null, 0, '5286', 'TIPOSIGMA=PVD&DOCSIGMA=@DOCSIGMA');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5286, 300, null, 'DIFCAMB', 'D', 'DIFERTC', '', '@CTALIB-DIFCAMB POR DIFERENCIAL CAMBIARIO', null, 0, '', 'TIPOSIGMA=DVD&TIPOSIGMAH=PVD&DOCSIGMA=@DOCSIGMA');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5286, 500, null, 'COMGADM', 'D', 'TOTCOMISION', '', '@CTALIB-COMGADM', null, 0, '', 'TIPOSIGMA=CVD&DOCSIGMA=@DOCSIGMA');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5286, 700, null, 'CTA_COMEMISCARTCRED', 'H', 'MONTOCOMENMIENDA', null, 'COMISION POR ENMIENDA', null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5286, 800, null, 'CTA_GASTOSCOM', 'H', 'MONTOGASTOCOM', null, null, null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5286, 900, null, 'CTA_UTILESESC', 'H', 'MONTOGASTOADM', null, null, null, 0, null, 'VFACMO=COMUTIL&VFACIVA=MONTOGASTOADMIVA&VFACT=ADM');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5286, 1000, null, 'CTA_DEBFISCAL', 'H', 'MONTOCOMIVA', null, null, null, 0, null, null);


-- enmienda por modificacion a FECHA disminuci�n de fecha

insert into d_siocw.soc_esquemas (esq_codigo, cod_tipooper, cod_tipoperacion, cve_tiposolic, cod_moneda, cla_operacion, cla_subtipo, esq_descrip, cla_vigente, glosa_comp, provisiona, tipo_retencion, tipo_transfer, genera, cod_esqref, cod_cargo, cve_subtipooper, usr_codigo, fecha_hora, estacion) values (287, 'CC', 'CCENF', null, '', 'CC', 'CCRED', 'ENMIENDA EN FECHA DISMINUCION', '1', 'COBRO DE COMISIONES POR ENMIENDA DE MODIFICACION DE @CCSOLICITANTE POR CARTA DE CREDITO @CCCORRELATIVO REF: @CCCCDGLOSA', '', 'S', 'P', 'WSP', null, 8, 'CC', 'adm', CURRENT, 'adm');

insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (287, 500, null, 'COMGADM', 'D', 'TOTCOMISION', '', '@CTALIB-COMGADM', null, 0, '5287', 'TIPOSIGMA=CVD&DOCSIGMA=@DOCSIGMA');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (287, 700, null, 'CTA_COMEMISCARTCRED', 'H', 'MONTOCOMENMIENDA', null, 'COMISION POR ENMIENDA', null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (287, 800, null, 'CTA_GASTOSCOM', 'H', 'MONTOGASTOCOM', null, null, null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (287, 900, null, 'CTA_UTILESESC', 'H', 'MONTOGASTOADM', null, null, null, 0, null, 'VFACMO=COMUTIL&VFACIVA=MONTOGASTOADMIVA&VFACT=ADM');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (287, 1000, null, 'CTA_DEBFISCAL', 'H', 'MONTOCOMIVA', null, null, null, 0, null, null);

insert into d_siocw.soc_esquemas (esq_codigo, cod_tipooper, cod_tipoperacion, cve_tiposolic, cod_moneda, cla_operacion, cla_subtipo, esq_descrip, cla_vigente, glosa_comp, provisiona, tipo_retencion, tipo_transfer, genera, cod_esqref, cod_cargo, cve_subtipooper, usr_codigo, fecha_hora, estacion) values (5287, 'CC', 'CCENF', null, '', 'CC', 'CCRED', 'ENMIENDA EN FECHA DISMINUCION', '1', 'COBRO DE COMISIONES POR ENMIENDA DE MODIFICACION DE @CCSOLICITANTE POR CARTA DE CREDITO @CCCORRELATIVO REF: @CCCCDGLOSA', '', 'S', 'P', 'WSP', null, 8, 'CC', 'adm', CURRENT, 'adm');

insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5287, 500, null, 'COMGADM', 'D', 'TOTCOMISION', '', '@CTALIB-COMGADM', null, 0, null, 'TIPOSIGMA=CVD&DOCSIGMA=@DOCSIGMA');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5287, 700, null, 'CTA_COMEMISCARTCRED', 'H', 'MONTOCOMENMIENDA', null, 'COMISION POR ENMIENDA', null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5287, 800, null, 'CTA_GASTOSCOM', 'H', 'MONTOGASTOCOM', null, null, null, 0, null, '');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5287, 900, null, 'CTA_UTILESESC', 'H', 'MONTOGASTOADM', null, null, null, 0, null, 'VFACMO=COMUTIL&VFACIVA=MONTOGASTOADMIVA&VFACT=ADM');
insert into d_siocw.soc_rengesq (esq_codigo, det_codigo, esq_descrip, cla_cuenta, esq_dh, esq_definicion, tipo_cuenta, cla_glosa_r, cod_moneda, repetible, cta_destorig, nom_datoadic) values (5287, 1000, null, 'CTA_DEBFISCAL', 'H', 'MONTOCOMIVA', null, null, null, 0, null, null);
