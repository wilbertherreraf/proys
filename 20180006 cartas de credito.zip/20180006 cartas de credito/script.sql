
drop table "d_siocw".car_cartascr;
    
create table "d_siocw".car_cartascr (
    ccr_codcartacr VARCHAR(13) NOT NULL,
    ccr_tipoimpexp varchar(1),
    ccr_anio integer,
    ccr_nrocorr integer,
    ccr_correlativo varchar(15),
    ccr_soccodigo VARCHAR(13),
    ccr_solcodigo varchar(15),
    ccr_bencodigo varchar(6),
    ccr_bcocodigo varchar(6),
    ccr_fechaemis date,
    ccr_fechavtoval date,
    ccr_fechavtopag date,
    ccr_nrodias integer,
    ccr_estadoccred varchar(1),
    ccr_codpais varchar(5),
    ccr_monto DECIMAL(16,2) DEFAULT 0.00,
    ccr_codmoneda integer,
    ccr_codmontrans integer,
    ccr_saldo DECIMAL(16,2) DEFAULT 0.00,
    ccr_nomproducto varchar(215),
    ccr_nomimportador varchar(215),
    ccr_nomexportador varchar(215),
    ccr_auditusr VARCHAR(30),
    ccr_auditfho DATETIME YEAR TO SECOND,
    ccr_auditwst VARCHAR(30),
    PRIMARY KEY (ccr_codcartacr) CONSTRAINT pk_cartacred
  ); 

drop TABLE car_cartascrdet;
CREATE TABLE car_cartascrdet (
    ccd_codcartacr VARCHAR(13) NOT NULL,
    ccd_nroccreddet INTEGER NOT NULL,
    ccd_tipomov varCHAR(1),
    ccd_tipoemision varCHAR(1),
    ccd_soccodigo VARCHAR(13),
    ccd_detcodigo INTEGER ,
    ccd_codbcoreceptor varCHAR(6),
    ccd_codbcornocta varCHAR(35),
    ccd_estmovccred varCHAR(1),
    ccd_fechacont DATE,
    ccd_fechareg DATE,
    ccd_fechacargo DATE,
    ccd_monto DECIMAL(16,2) DEFAULT 0.00,
    ccd_codmonmonto INTEGER,
    ccd_montotrans DECIMAL(16,2) DEFAULT 0.00,
    ccd_codmontrans INTEGER,
    ccd_glosa VARCHAR(245),
    ccd_nrodias integer,
    ccd_nit varCHAR(15),
    ccd_rengconcilia varCHAR(30),
    ccd_esqcodigo integer,
    ccd_estregistro varCHAR(1),
    ccd_auditusr VARCHAR(30),
    ccd_auditfho DATETIME YEAR TO SECOND,
    ccd_auditwst VARCHAR(30),
        PRIMARY KEY (ccd_codcartacr, ccd_nroccreddet) CONSTRAINT pk_cartcreddet
    );

create   index idx_soccoddet on car_cartascrdet (
        ccd_soccodigo ASC,
        ccd_detcodigo ASC
);

create   index idx_ccdestmov on car_cartascrdet (
        ccd_estmovccred ASC
);

create   index idx_ccdtipoemis on car_cartascrdet (
        ccd_tipoemision ASC
);
