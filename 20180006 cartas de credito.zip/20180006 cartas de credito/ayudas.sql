select *
from contbcb@wildb:afectable_partida p
where nro_afectable = cta_afectable
--and nro_afectable in ('007795','001712','001708','001761','001752','001564','012729','012675','012674')
and p.cve_vigente = 'V';
012729
012675
012674
select *
from contbcb@wildb:afectable_sigma 
where nro_afectable = cta_afectable
--nro_afectable in ('011164','005465','006804','007256')
and cve_vigente = 'V';

select m.nro_mayor || '' nro_mayor, m.cod_mayor
from contbcb@wildb:cuenta_movimiento c, contbcb@wildb:cuenta_mayor m 
where substr(c.cod_tipo_cuenta, 1, 4) = m.cod_mayor 
and m.nro_centro = 1 
and c.cod_movimiento = '7329'
and c.cve_estado_cuenta = 'V'
and c.cve_estado_cuenta = 'V';


select *
from contbcb@wildb:cuenta_afectable ca
where ca.cod_movimiento = '7329'
and ca.cod_moneda = '34'
and ca.cve_estado_cuenta = 'V'

select co.nro_afectable,
(select ca.cod_moneda
from contbcb@wildb:cuenta_afectable ca
where ca.nro_afectable = co.nro_afectable)
from contbcb@wildb:afectable_concilia  co
where co.nro_afectable = '013308'
and co.cve_estado_cuenta = 'V' 	;



select *
from soc_valorescla
where cla_codigo in ('cla_rengcp');

select s.cta_movimiento,s.moneda, s.cta_nommovimiento,s.cta_afectable,
(select count(*)
from contbcb@wildb:afectable_partida p
where nro_afectable = s.cta_afectable
and p.cve_vigente = 'V') afec_partida,
(select count(*)
from contbcb@wildb:afectable_sigma 
where nro_afectable = s.cta_afectable
--nro_afectable in ('011164','005465','006804','007256')
and cve_vigente = 'V') afec_sigma,
(select count(*)
from contbcb@wildb:afectable_concilia 
where nro_afectable = s.cta_afectable
and cve_estado_cuenta = 'V' 	) afec_concilia,
(select c.cod_persona from contbcb@wildb:cuenta_movimiento c where c.cod_movimiento = s.cta_movimiento)
from soc_cuentassol s