select ccr_codcartacr, 
ccr_tipoimpexp, ccr_anio,ccr_nrocorr,ccr_correlativo,ccr_soccodigo,
ccr_solcodigo, 
(select ss.sol_persona from soc_solicitante ss where ss.sol_codigo = ccr_solcodigo) nom_solicitante,
ccr_bencodigo,
(select ben_nombre from soc_benefs b where b.ben_codigo = ccr_bencodigo) beneficiario,
ccr_bcocodigo,ccr_fechaemis,ccr_fechavtoval,ccr_fechavtopag,
ccr_nrodias,
ccr_estadoccred,
(select vc.val_nombre from soc_valorescla vc where vc.cla_codigo = 'ccr_estadoccred' and vc.val_codigo = ccr_estadoccred) ccr_estadoccreddesc,
ccr_codpais,ccr_monto,
ccr_codmoneda,
ccr_codmontrans,
(select m.mon_sigla from gen_moneda m where m.cod_moneda = ccr_codmontrans) monedatrans_sigla,
ccr_saldo,ccr_nomproducto,ccr_nomimportador,ccr_nomexportador,
ccd_glosa,
ccd_rengconcilia,
cod_solicitudorig
from car_cartascr, car_cartascrdet, soc_solicitudes s
where ccr_codcartacr = ccd_codcartacr
and ccd_soccodigo = s.soc_codigo
and ccd_tipoemision = 'E'
and ccd_estregistro = 'V'
and ccr_codcartacr = '000057'