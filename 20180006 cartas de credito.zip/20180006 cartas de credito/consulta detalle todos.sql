select ccd_codcartacr, ccd_nroccreddet,ccd_tipomov,
ccd_tipoemision,
(select vc.val_nombre from soc_valorescla vc where vc.cla_codigo = 'cve_tipoemiscarta' and vc.val_codigo = ccd_tipoemision) ccd_tipoemisiondesc,
ccd_soccodigo,ccd_detcodigo,ccd_codbcoreceptor,
ccd_estmovccred,
(select vc.val_nombre from soc_valorescla vc where vc.cla_codigo = 'ccd_estmovccred' and vc.val_codigo = ccd_estmovccred) ccd_estmovccreddesc,
ccd_fechacont,ccd_fechareg,ccd_fechacargo,
ccd_monto,
(case
    when (ccd_tipoemision in ('E','I','D')) then
        ccd_monto
    else
        0
end) ccd_monto_oper,
ccd_codmonmonto,
(select m.mon_sigla from gen_moneda m where m.cod_moneda = ccd_codmonmonto) ccd_codmonmonto_sigla,
ccd_montotrans,
(case
    when (ccd_tipoemision in ('E','I','D')) then
        ccd_montotrans
    else
        0
end) monto_oper,
ccd_codmontrans,
(select m.mon_sigla from gen_moneda m where m.cod_moneda = ccd_codmontrans) ccd_codmontrans_sigla,
ccd_glosa,ccd_nrodias,ccd_nit,ccd_rengconcilia,
ccd_esqcodigo,
ccd_estregistro,
oc.cla_comision occla_comision,
(case
    when (oc.cla_comision = 'MONTODIFCAMBVENDIV') then
        'VENTA DE DIVISAS'
    else
        (select cto1.descrip from soc_comitipoope cto1 where cto1.cod_cargo = esq.cod_cargo and cto1.cla_comisionopecomi = oc.cla_comision)
end) descrip, 
oco_monto comis_total, 
monto_mo comision_bcb, oco_montoimpt comision_iva,
oc.nro_cuenta
from car_cartascr, car_cartascrdet, soc_esquemas esq, soc_opecomi oc
where ccr_codcartacr = ccd_codcartacr
and ccd_soccodigo = oc.ope_codigo
and oc.det_codigo = 0
and ccd_esqcodigo = esq.esq_codigo
and (exists (select * 
from soc_comitipoope cto
where cto.cod_cargo = esq.cod_cargo
and cto.cla_comisionopecomi = oc.cla_comision ) 
or oc.cla_comision = 'MONTODIFCAMBVENDIV')
and ccd_estregistro = 'V'
and ccr_codcartacr = '000067'
and ccd_tipoemision in ('E','I','D','M','R','A')
order by ccd_nroccreddet;


select ccd_codcartacr, ccd_nroccreddet,ccd_tipomov,
ccd_tipoemision,
(select vc.val_nombre from soc_valorescla vc where vc.cla_codigo = 'cve_tipoemiscarta' and vc.val_codigo = ccd_tipoemision) ccd_tipoemisiondesc,
ccd_soccodigo,ccd_detcodigo,
ccd_codbcoreceptor,
(select b.bco_nombre || ', ' || p.pla_nombre from soc_bancos b, soc_plazas p where p.bco_codigo = b.bco_codigo and b.bco_codigo = ccd_codbcoreceptor) ccd_codbcoreceptordesc,
ccd_estmovccred,
(select vc.val_nombre from soc_valorescla vc where vc.cla_codigo = 'ccd_estmovccred' and vc.val_codigo = ccd_estmovccred) ccd_estmovccreddesc,
ccd_fechacont,ccd_fechareg,ccd_fechacargo,
ccd_monto,
ccd_codmonmonto,
(select m.mon_sigla from gen_moneda m where m.cod_moneda = ccd_codmonmonto) ccd_codmonmonto_sigla,
ccd_montotrans,
(case
    when (ccd_tipoemision in ('E','I','D')) then
        ccd_montotrans
    else
        0
end) monto_oper,
ccd_codmontrans,
(select m.mon_sigla from gen_moneda m where m.cod_moneda = ccd_codmontrans) ccd_codmontrans_sigla,
ccd_glosa,ccd_nrodias,ccd_nit,ccd_rengconcilia,
ccd_esqcodigo,
ccd_estregistro,
(select sd.det_info from soc_detallessol sd where sd.soc_codigo = ccd_soccodigo and sd.det_codigo = ccd_detcodigo) det_info,
oc.cla_comision occla_comision,
cto.descrip, oco_monto comis_total, 
monto_mo comision_bcb, oco_montoimpt comision_iva
from car_cartascr, car_cartascrdet, soc_opecomi oc, soc_esquemas esq, soc_comitipoope cto
where ccr_codcartacr = ccd_codcartacr
and ccd_soccodigo = oc.ope_codigo
and oc.det_codigo = 0
and ccd_esqcodigo = esq.esq_codigo
and cto.cod_cargo = esq.cod_cargo
and cto.cla_comisionopecomi = oc.cla_comision
and ccd_estregistro = 'V'
and ccr_codcartacr = '000072'
and ccd_tipoemision = 'P'
order by ccd_nroccreddet