ALTER TABLE d_aladi.h_params DROP CONSTRAINT pk_h_params;
ALTER TABLE d_aladi.h_categoria DROP CONSTRAINT pk_h_categoria;

alter table d_aladi.swf_mensaje add (men_nrolavado integer before men_auditusr);
insert into d_aladi.params (nomparam, descparam, valparam, cod_usuario, fecha_hora, estacion) 
values ('verifica-lavado', 'VARIABLE QUE DETERMINA SI SE VERIFICA CON SIST. LAVADO(S:SI, N:NO)', 'N', 'ADM', current, 'ADMIN');
insert into d_aladi.params (nomparam, descparam, valparam, cod_usuario, fecha_hora, estacion) 
values ('url-lavado', 'URL DEL SISTEMA DE LAVADO', 'http://swfapp.bcb.com:8881/lavado/', 'ADM', current, 'ADMIN');

insert into d_aladi.params (nomparam, descparam, valparam, cod_usuario, fecha_hora, estacion) 
values ('url-otp', 'URL DEL SISTEMA DE VERIFICACION DE CODIGOS OTP', 'https://dsci.bcb.gob.bo/multiotp/otp_http_auth.php', 'ADM', current, 'ADMIN');	
insert into d_aladi.params (nomparam, descparam, valparam, cod_usuario, fecha_hora, estacion) 
values ('verifica-otp', 'DETERMINA SI SE VERIFICA EL CODIGO OTP', 'S', 'ADM', current, 'ADMIN');	