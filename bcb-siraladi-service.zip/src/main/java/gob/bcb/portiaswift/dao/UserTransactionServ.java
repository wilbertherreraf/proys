package gob.bcb.portiaswift.dao;

import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

public interface UserTransactionServ extends UserTransaction{
	public boolean isActive() throws SystemException;
}
