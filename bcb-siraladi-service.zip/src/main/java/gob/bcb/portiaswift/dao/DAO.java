/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.portiaswift.dao;

import java.util.List;
import javax.persistence.EntityManager;
/**
 * Interfaz generica que se utiliza para abstrar el comportamient general de un DAO.
 * Esta clase abstra la funcionalidad de persistir, inactivar, remover, mezclar, actualizar,
 * buscar por primary key, y obtener los registros cuyo cve_estado sea 'A'
 * @author wherrera
 */
/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 * @param <K>
 * @param <E>
 */
public interface DAO<K, E> {
	void setEntityManager(EntityManager em);
	Class<E> getEntityBeanType();
    /**
     * Metodo que inserta un registro en base de datos.
     * @param entity Entidad asociada que sera ingresada a la Base de Datos
     */
    //void insertar(E entity, EntityManager em);
    void persist(E entity); 
    /**
     * Metodo que coloca el cve_estado en 'S' de un registro en base de datos
     * @param entity Entidad asociada que sera suspendida (inactivada) en la Base de Datos
     */
    void inactivar(E entity);

    /**
     * Metodo que elimina un registro en base de datos
     * @param entity Entidad asociada que sera eliminada de la Base de Datos
     */
    //void remover(E entity, EntityManager em);
    void makeTransient(E entity);
    void flush();
    public void clear();    
    /**
     * Metodo que actualiza un registro en base de datos
     * @param entity Entidad asociada que sera actualizada a la Base de Datos
     */
    //void actualizar(E entity, EntityManager em);
    E makePersistent(E entity);
    /**
     * Metodo que refresca el cache de una entidad
     * @param entity Entidad asociada que sera refrescada a la Base de Datos
     */
    void refresh(E entity);

    /**
     * Método que devuelve una entidad a partir de su llave primaria.
     * @param id Llave primaria para buscar la entidad
     * @return Entidad encontrada o en su defecto null
     */
    //E buscarPorPK(K id, EntityManager em);
    E findById(K id, boolean lock);
    List<E> findAll();
    List<E> findByExample(E exampleInstance, String... excludeProperty);
	void setAuditWstUsr(String estacionAudit, String usuarioDBAudit); 
  
}
