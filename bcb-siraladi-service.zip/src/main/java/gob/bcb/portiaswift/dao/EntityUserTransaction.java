package gob.bcb.portiaswift.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.Status;
import javax.transaction.SystemException;

import static javax.transaction.Status.STATUS_ACTIVE;

public class EntityUserTransaction implements UserTransactionServ {
	@PersistenceContext(unitName = "portia_pu")
	private EntityManager entityManager;
	public EntityUserTransaction() {
		
	}
	public EntityUserTransaction(EntityManager em) {
		this.entityManager = em;
	}

	
	public void begin() throws NotSupportedException {
		if (getStatus() != Status.STATUS_NO_TRANSACTION){
			throw new NotSupportedException("Existe una transaccion activa, no se puede iniciar una nueva");
		}
		try{
			getEntityManager().getTransaction().begin();
		}catch (Exception e) {
			throw new NotSupportedException("Error al iniciar transacci�n " + e.getMessage());
		}
	}

	
	public void commit() throws RollbackException {
		try {
			if (getStatus() == Status.STATUS_NO_TRANSACTION){
				// no existe ninguna transaccion activa
				return;				
			}
			getEntityManager().getTransaction().commit();
		} catch (javax.persistence.RollbackException e) {
			throw new RollbackException("Error al actualizar en la base de datos " + e.getMessage());
		}
	}

	
	public void rollback() throws SystemException {
		try {
			if (getStatus() != Status.STATUS_NO_TRANSACTION){			
				getEntityManager().getTransaction().rollback();
			}
		} catch (PersistenceException e) {
			throw new SystemException("Error al realizar rollback " + e.getMessage());
		}
	}

	
	public void setRollbackOnly() {
		getEntityManager().getTransaction().setRollbackOnly();
	}

	
	public int getStatus() {
		if (getEntityManager().getTransaction().isActive()) {
			return Status.STATUS_ACTIVE;
		} else {
			return Status.STATUS_NO_TRANSACTION;
		}
	}

	
	public void setTransactionTimeout(int timeout) {
		throw new UnsupportedOperationException();
	}

	
	public boolean isActive() throws SystemException {
		return getStatus() == STATUS_ACTIVE;
	}

	/**
	 * @return the entityManager
	 */
	public EntityManager getEntityManager() {
		return entityManager;
	}
}
