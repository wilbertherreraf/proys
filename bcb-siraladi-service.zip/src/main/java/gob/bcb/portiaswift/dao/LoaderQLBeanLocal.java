package gob.bcb.portiaswift.dao;

import gob.bcb.portiaswift.entities.Loader;



public interface LoaderQLBeanLocal extends DAO<Integer, Loader>{
	Integer getCodigo();
	Integer maxNroSwift();
	Loader nuevoCodSwift(String idSistema, String auditWst, String auditUsr);
	Loader maxLoader();
	Loader findByCodigo(Integer idLoader);
	Loader saveorupdate(Loader loader);
	Loader generarNroSwift(Loader loader);
	
}
