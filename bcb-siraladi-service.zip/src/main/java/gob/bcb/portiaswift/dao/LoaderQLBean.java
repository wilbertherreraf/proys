package gob.bcb.portiaswift.dao;

import gob.bcb.portiaswift.entities.Loader;

import java.util.Date;
import java.util.List;


import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("loaderQLBeanLocal")
//@Transactional("transactionManagerJPA-portia")
@Transactional
public class LoaderQLBean extends GenericDAO<Integer, Loader> implements LoaderQLBeanLocal {
	static final Logger logger = Logger.getLogger(LoaderQLBean.class);
//
//	@PersistenceContext(unitName = "portia_pu")
//	EntityManager entityManager;

	/**
	 * Default constructor.
	 */
	public Integer getCodigo() {
		Loader loader = maxLoader();
		if (loader == null){
			logger.error("No se pudo recuperar nro swift");
			return 1;
			//throw new RuntimeException("No se pudo recuperar nro swift");
		}
 
		Integer codigo = loader.getIdLoader() + 1;
		logger.info("IdLoader : " + codigo);		
		return codigo;

	}
	public Loader maxLoader() {

		StringBuilder query = new StringBuilder();
		
	    query = query.append(" select re ");
	    query = query.append(" from Loader re ");
	    query = query.append(" where re.idLoader = (select max(r1.idLoader) from Loader r1) ");

		Query consulta = getEntityManager().createQuery(query.toString());
		List lista =  consulta.getResultList();
		if (lista.size() > 0){
			return (Loader) lista.get(0); 
		}

		return null;		
	}
	
	public Loader findByCodigo(Integer idLoader) {

		StringBuilder query = new StringBuilder();
		
	    query = query.append(" select re ");
	    query = query.append(" from Loader re ");
	    query = query.append(" where re.idLoader = :idLoader ");

		Query consulta = getEntityManager().createQuery(query.toString());
		
		consulta.setParameter("idLoader", idLoader);
		
		List lista =  consulta.getResultList();
		if (lista.size() > 0){
			return (Loader) lista.get(0); 
		}

		return null;		
	}	
	//@Transactional(propagation = Propagation.REQUIRES_NEW)
	//@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public Loader nuevoCodSwift(String idSistema, String auditWst, String auditUsr) {
		Integer codSwift = maxNroSwift();
		Integer idLoader = getCodigo();

		logger.info("numero SWIFT obtenito: " + codSwift + " idLoader " + idLoader);

		//Loader loader = new Loader(idLoader, 0, 0, codSwift, '1', idSistema, auditWst, new Date(), auditUsr);
		Loader loader = new Loader();		
		loader.setIdLoader(idLoader);
		loader.setIdBase(0);
		loader.setIdPortia(0);
		loader.setNumeroSwift(codSwift);
		loader.setEstado('0');
		loader.setDescrip(idSistema);
		loader.setEstacion(auditWst);
		loader.setFechaHora(new Date());
		loader.setUsuario(auditUsr);		
		//getEntityManager().persist(loader);
		persist(loader);
		
		Loader loaderNew = findByCodigo(idLoader);
		logger.info("registro Swift en PORTIA a crear: " + loaderNew.toString());
		return loader;		
	}
	public Loader generarNroSwift(Loader loader) {
		Integer codSwift = maxNroSwift();
		Integer idLoader = getCodigo();

		logger.info("numero SWIFT obtenito: " + codSwift + " idLoader " + idLoader);

		loader.setIdLoader(idLoader);
		loader.setIdBase(0);
		loader.setIdPortia(0);
		loader.setNumeroSwift(codSwift);
		loader.setEstado('0');
		loader.setFechaHora(new Date());
		persist(loader);
		
		Loader loaderNew = findByCodigo(idLoader);
		logger.info("registro Swift en PORTIA a crear: " + loaderNew.toString());
		return loader;		
	}	
	public Loader saveorupdate(Loader loader) {
		logger.info("saveorupdate PORTIA a mod: " + loader.toString());
		Loader  loaderOld = findByCodigo(loader.getIdLoader());
		if (loaderOld == null){
			throw new RuntimeException("Swift: No puede insertar nuevo registro");
		} else {
			loaderOld.setEstado(loader.getEstado());
			loaderOld.setIdBase(loader.getIdBase());
			loaderOld.setIdPortia(loader.getIdPortia());
			loaderOld.setDescrip("loader.getDescrip()");
			logger.info("XXX:111111111111111111111111111111111111111111111111111111111111111111");
			//entityManager.getTransaction().begin();
			loader = makePersistent(loaderOld);
			logger.info("XXX:2222222222222222222222222222222222222222222 " + loader.getDescrip());
			Loader loaderN = findByCodigo(loader.getIdLoader());
			logger.info("XXX:2222222222222222222222222222222222222222222 " + loaderN.getDescrip());
			loaderOld.setDescrip("loader222");
			//Loader loaderN2 = entityManager.merge(loaderN);
			//logger.info("XXX:22222 " + loaderN.getDescrip() + " ::: " + loaderN2.getDescrip());			
		}
		return loader; 
	}
	public Integer maxNroSwift() {

			StringBuilder jsql = new StringBuilder();
			jsql.append("select max(l.numeroSwift) from Loader l");

			Query query = getEntityManager().createQuery(jsql.toString());

			List result = query.getResultList();
			if (result.size() > 0) {
				Integer maximo = (Integer) result.get(0);
				return (maximo == null ? Integer.valueOf(1) : ++maximo);
			}

			return Integer.valueOf(0);
	}	
}
