package gob.bcb.portiaswift.entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;

/**
 *
 * @author CUriona
 */
@Entity
@Table(name = "loader")
public class Loader implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Column(name = "id_loader")
    private Integer idLoader;
    @Column(name = "id_base")
    private int idBase;
    @Column(name = "id_portia")
    private Integer idPortia;
    @Column(name = "numero_swift")
    private Integer numeroSwift;
    @Column(name = "estado")
    private char estado;
    @Column(name = "descrip")
    private String descrip;
    @Column(name = "estacion")
    private String estacion;
    @Column(name = "fecha_hora")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaHora;
    @Column(name = "usuario")
    
    private String usuario;

    
    public Loader() {
    }

//    public Loader(Integer idLoader) {
//        this.idLoader = idLoader;
//    }
//    
//	public Loader(Integer idLoader, int idBase, Integer idPortia,
//			Integer numeroSwift, char estado, String descrip, String estacion,
//			Date fechaHora, String usuario) {
//		//super();
//		this.idLoader = idLoader;
//		this.idBase = idBase;
//		this.idPortia = idPortia;
//		this.numeroSwift = numeroSwift;
//		this.estado = estado;
//		this.descrip = descrip;
//		this.estacion = estacion;
//		this.fechaHora = fechaHora;
//		this.usuario = usuario;
//	}

	public Integer getIdLoader() {
		return idLoader;
	}

	public void setIdLoader(Integer idLoader) {
		this.idLoader = idLoader;
	}

	public int getIdBase() {
		return idBase;
	}

	public void setIdBase(int idBase) {
		this.idBase = idBase;
	}

	public Integer getIdPortia() {
		return idPortia;
	}

	public void setIdPortia(Integer idPortia) {
		this.idPortia = idPortia;
	}

	public Integer getNumeroSwift() {
		return numeroSwift;
	}

	public void setNumeroSwift(Integer numeroSwift) {
		this.numeroSwift = numeroSwift;
	}

	public char getEstado() {
		return estado;
	}

	public void setEstado(char estado) {
		this.estado = estado;
	}

	public String getDescrip() {
		return descrip;
	}

	public void setDescrip(String descrip) {
		this.descrip = descrip;
	}

	public String getEstacion() {
		return estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
	public String toString() {
		return "Loader [idLoader=" + idLoader + ", idBase=" + idBase + ", idPortia=" + idPortia + ", numeroSwift=" + numeroSwift + ", estado="
				+ estado + ", descrip=" + descrip + ", estacion=" + estacion + ", fechaHora=" + fechaHora + ", usuario=" + usuario + "]";
	}

    
}
