package gob.bcb.portiaswift.service;

import gob.bcb.portiaswift.dao.LoaderQLBeanLocal;

public interface ServiceSwiftDao {

	LoaderQLBeanLocal getLoaderQLBeanLocal();

}
