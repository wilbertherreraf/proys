package gob.bcb.portiaswift.service;


import gob.bcb.portiaswift.dao.LoaderQLBean;
import gob.bcb.portiaswift.dao.LoaderQLBeanLocal;

import javax.persistence.EntityManager;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
/**
 * Clase que implementa servicios para operaciones de portia swift
 * @author wherrera
 *
 */
@Service("serviceSwiftDao")
@Transactional(propagation = Propagation.REQUIRED)
public class ServiceSwiftDaoImpl implements ServiceSwiftDao{
	private static Logger log = Logger.getLogger(ServiceSwiftDaoImpl.class);
	
	@Autowired
	private LoaderQLBeanLocal loaderQLBeanLocal;
	
	public ServiceSwiftDaoImpl() {
		log.info("ServiceSwiftDaoImpl DAO creado ...");
	}
	public ServiceSwiftDaoImpl(EntityManager entityManager) {
		//super(entityManager);
		loaderQLBeanLocal = new LoaderQLBean();
		loaderQLBeanLocal.setEntityManager(entityManager);
	}
	public LoaderQLBeanLocal getLoaderQLBeanLocal() {
		return loaderQLBeanLocal;
	}

	public void setLoaderQLBeanLocal(LoaderQLBeanLocal loaderQLBeanLocal) {
		this.loaderQLBeanLocal = loaderQLBeanLocal;
	}
}
