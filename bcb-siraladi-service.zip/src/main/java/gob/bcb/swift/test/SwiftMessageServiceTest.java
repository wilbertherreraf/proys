package gob.bcb.swift.test;

import gob.bcb.bpm.siraladi.dao.HorarioBean;
import gob.bcb.bpm.siraladi.dao.RegAnticipadoBean;
import gob.bcb.bpm.siraladi.dao.RegAnticipadoLocal;
import gob.bcb.bpm.siraladi.dao.SwfMensajeBean;
import gob.bcb.bpm.siraladi.dao.SwfMensajeLocal;
import gob.bcb.bpm.siraladi.jpa.Horario;
import gob.bcb.bpm.siraladi.jpa.RegAnticipado;
import gob.bcb.bpm.siraladi.jpa.SwfMensaje;
import gob.bcb.bpm.siraladi.logic.RegAnticipadoServiceBean;
import gob.bcb.bpm.siraladi.service.DispatcherSirAladi;
import gob.bcb.bpm.siraladi.utils.UtilsPersist;
import gob.bcb.portiaswift.service.ServiceSwiftDaoImpl;
import gob.bcb.service.siraladi.ServerListener;
import gob.bcb.swift.service.SwiftMessageService;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

public class SwiftMessageServiceTest {
	private static final Logger log = Logger.getLogger(SwiftMessageServiceTest.class);
	private EntityManager entityManager;
	private EntityManager entityManagerPortia;
	public void initConectionDB() {
		if (entityManager == null) {

			ServerListener serverListener = new ServerListener();
			serverListener.init();

			entityManager = ServerListener.getEntityMgrFactory().createEntityManager();
			DispatcherSirAladi dispatcherSirAladi = new DispatcherSirAladi(entityManager);
			
			EntityManagerFactory entityManagerFactory = UtilsPersist.createEntityManagerFactory2("e:/opt/aplicaciones/configuraciones/web/siraladi/configdb.xml", "portia", "portia_pu");
			entityManagerPortia = entityManagerFactory.createEntityManager();
		}
	}

	public void pru() {
		HorarioBean horarioBean = new HorarioBean();
		horarioBean.setEntityManager(entityManager);
		List<Horario> horario = horarioBean.findAll();
		for (Horario horario2 : horario) {
			System.out.println(horario2.getId().getCodHorario());
		}

	}

	public void generarSwift() {
		RegAnticipadoLocal regAnticipadoLocal = new RegAnticipadoBean();
		regAnticipadoLocal.setEntityManager(entityManager);
		RegAnticipado regAnticipado = regAnticipadoLocal.findById(47100, false); // 46281, 46867 int 46798 
		log.info("XXX:===========================");
		log.info("XXX:regAnticipado " + regAnticipado.getCodigoReembolso());
		RegAnticipadoServiceBean regAnticipadoServiceBean = new RegAnticipadoServiceBean(entityManager);
		try {
			regAnticipadoServiceBean.begin();
			regAnticipadoServiceBean.crearSwiftDeRegAnticipado(regAnticipado);
			regAnticipadoServiceBean.commit();
		} catch (NotSupportedException e) {
			log.error(e.getMessage(), e);
		} catch (RollbackException e) {
			log.error(e.getMessage(), e);
		}

		System.out.println(regAnticipado.getNroReembLiteral(false));

	}

	public void autorizarSwift() {
		RegAnticipadoServiceBean regAnticipadoServiceBean = new RegAnticipadoServiceBean(entityManager);
		try {
			regAnticipadoServiceBean.begin();

			SwfMensajeLocal swfMensajeLocal = new SwfMensajeBean();
			swfMensajeLocal.setEntityManager(entityManager);
			SwfMensaje swfMensaje = swfMensajeLocal.findByCodigo(16);
			String pathSwift = "e:/opt/aplicaciones/configuraciones/web/siraladi/swift";
			swfMensajeLocal.autorizarSwift(swfMensaje, pathSwift);
			regAnticipadoServiceBean.commit();
		} catch (NotSupportedException e) {
			log.error(e.getMessage(), e);
		} catch (RollbackException e) {
			log.error(e.getMessage(), e);
		}
	}
	public void recuperarSwiftPlano() {
		RegAnticipadoServiceBean regAnticipadoServiceBean = new RegAnticipadoServiceBean(entityManager);
		ServiceSwiftDaoImpl serviceSwiftDaoImpl = new ServiceSwiftDaoImpl(entityManagerPortia);
		try {
			//serviceSwiftDaoImpl.begin();
			regAnticipadoServiceBean.begin();

			SwfMensajeLocal swfMensajeLocal = new SwfMensajeBean();
			swfMensajeLocal.setEntityManager(entityManager);
			SwfMensaje swfMensaje = swfMensajeLocal.findByCodigo(17);
			
			//SwiftDatos swiftDatos = swfMensajeLocal.swiftDatosFromSwfMensaje(swfMensaje);
			
			SwiftMessageService swiftMessageService = new SwiftMessageService(entityManager);
			//swiftMessageService.setLoaderQLBeanLocal(serviceSwiftDaoImpl.getLoaderQLBeanLocal());
			//swiftMessageService.setSwiftDatos(swiftDatos);
			swiftMessageService.actualizarCorrelativo(swfMensaje);
			
			regAnticipadoServiceBean.commit();
			//serviceSwiftDaoImpl.commit();
		} catch (NotSupportedException e) {
			log.error(e.getMessage(), e);
		} catch (RollbackException e) {
			log.error(e.getMessage(), e);
		}
	}
	public static void main(String[] args) {
		SwiftMessageServiceTest swiftMessageServiceTest = new SwiftMessageServiceTest();
		swiftMessageServiceTest.initConectionDB();

		swiftMessageServiceTest.generarSwift();
//		swiftMessageServiceTest.autorizarSwift();
		//swiftMessageServiceTest.recuperarSwiftPlano();
		System.out.println("FIIIIIIIIIIIIIIIIIIIIIIN");
		String str = "asdf asdf   ";
		System.out.println("'" + StringUtils.trim(str) + "'");
		str = "  asdf asdf   ";
		System.out.println("'" + StringUtils.trim(str) + "'");		
		str = null;
		System.out.println("'" + StringUtils.trim(str) + "'");
		str = StringUtils.trim(str);
		System.out.println(str == null);
	}
}
