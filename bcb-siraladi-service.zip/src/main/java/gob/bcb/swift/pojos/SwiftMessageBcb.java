package gob.bcb.swift.pojos;

import gob.bcb.core.utils.UtilsDate;
import gob.bcb.swift.commons.MensSwiftUtiles;

import java.io.IOException;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Currency;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.prowidesoftware.swift.io.parser.SwiftParser;
import com.prowidesoftware.swift.model.BIC;
import com.prowidesoftware.swift.model.MtSwiftMessage;
import com.prowidesoftware.swift.model.SwiftBlock1;
import com.prowidesoftware.swift.model.SwiftBlock2;
import com.prowidesoftware.swift.model.SwiftBlock2Input;
import com.prowidesoftware.swift.model.SwiftBlock3;
import com.prowidesoftware.swift.model.SwiftBlock4;
import com.prowidesoftware.swift.model.SwiftBlock5;
import com.prowidesoftware.swift.model.SwiftMessage;
import com.prowidesoftware.swift.model.Tag;
import com.prowidesoftware.swift.model.field.Field;
import com.prowidesoftware.swift.model.field.Field20;
import com.prowidesoftware.swift.model.field.Field21;
import com.prowidesoftware.swift.model.field.Field32A;
import com.prowidesoftware.swift.model.field.Field52A;
import com.prowidesoftware.swift.model.field.Field52D;
import com.prowidesoftware.swift.model.field.Field53A;
import com.prowidesoftware.swift.model.field.Field53B;
import com.prowidesoftware.swift.model.field.Field53D;
import com.prowidesoftware.swift.model.field.Field54A;
import com.prowidesoftware.swift.model.field.Field54B;
import com.prowidesoftware.swift.model.field.Field54D;
import com.prowidesoftware.swift.model.field.Field56A;
import com.prowidesoftware.swift.model.field.Field56D;
import com.prowidesoftware.swift.model.field.Field57A;
import com.prowidesoftware.swift.model.field.Field57B;
import com.prowidesoftware.swift.model.field.Field57D;
import com.prowidesoftware.swift.model.field.Field58A;
import com.prowidesoftware.swift.model.field.Field58D;
import com.prowidesoftware.swift.model.field.Field72;
import com.prowidesoftware.swift.model.field.SwiftParseUtils;

public class SwiftMessageBcb implements Serializable {
	private static final Logger log = Logger.getLogger(SwiftMessageBcb.class);
	private MtSwiftMessage mtSwiftMessage;
	/**
	 * Block 1
	 */
	private SwiftBlock1 block1;

	/**
	 * Block 2
	 */
	private SwiftBlock2 block2;
	private SwiftBlock2Input swiftBlock2Input;
	/**
	 * Block 3
	 */
	private SwiftBlock3 block3;

	/**
	 * Block 4
	 */
	private SwiftBlock4 block4;

	/**
	 * Block 5
	 */
	private SwiftBlock5 block5;

	public SwiftMessageBcb() {
		inicializar();
	}

	public void inicializar() {
		// crea los bloques estaticos 1, 2, 3
		block1 = new SwiftBlock1();
		block2 = new SwiftBlock2Input();
		swiftBlock2Input = new SwiftBlock2Input();
		block3 = new SwiftBlock3();
		block4 = new SwiftBlock4();
		block5 = new SwiftBlock5();

		if (mtSwiftMessage == null) {
			mtSwiftMessage = new MtSwiftMessage();
		}
		if (mtSwiftMessage.getModelMessage() == null) {
			SwiftMessage swiftMessage = new SwiftMessage();
			mtSwiftMessage.setModelMessage(swiftMessage);
		}
		mtSwiftMessage.getModelMessage().setBlock1(block1);
		mtSwiftMessage.getModelMessage().setBlock2(swiftBlock2Input);
		mtSwiftMessage.getModelMessage().setBlock3(block3);
		mtSwiftMessage.getModelMessage().setBlock4(block4);
		//mtSwiftMessage.getModelMessage().setBlock5(block5);
	}

	public void createBlock1(String applicationId, String serviceId, String logicalTerminal, String sessionNumber, String sequenceNumber) {
		// block1 = new SwiftBlock1(applicationId, serviceId, logicalTerminal,
		// sessionNumber, sequenceNumber);
		block1.setApplicationId(applicationId);
		block1.setServiceId(serviceId);
		block1.setLogicalTerminal(logicalTerminal);
		block1.setSessionNumber(sessionNumber);
		block1.setSequenceNumber(sequenceNumber);
	}

	public void createBlock2(String messageType, String bicReceiver, String messagePriority, String deliveryMonitoring, String obsolescencePeriod) {
		// swiftBlock2Input = new SwiftBlock2Input(messageType, receiverAddress,
		// messagePriority, deliveryMonitoring, obsolescencePeriod);
		swiftBlock2Input.setMessageType(messageType);
		BIC bicswf = new BIC(bicReceiver);

		swiftBlock2Input.setReceiver(bicswf);
		swiftBlock2Input.setMessagePriority(messagePriority);
//		swiftBlock2Input.setDeliveryMonitoring(deliveryMonitoring);
//		swiftBlock2Input.setObsolescencePeriod(obsolescencePeriod);
	}

	public void createBlock3(String tagname, String value) {
		Tag tag = new Tag(tagname, value);

		if (block3 == null) {
			List<Tag> tagsBlock3 = new ArrayList<Tag>();
			block3 = new SwiftBlock3();
			block3.setTags(tagsBlock3);
		}
		int v = block3.removeAll(tagname);

		log.info("removido tag block 3 " + tagname + " value " + v);
		block3.getTags().add(tag);

	}

	public Field getField(String fieldName) {
		Field field = block4.getFieldByName(fieldName);
		return field;
	}

	public Field modifyFieldComponent(String fieldName, Integer numberComponent, String value) {

		Field field = getField(fieldName);

		if (field == null) {
			Tag tag = new Tag(fieldName, value);
			field = tag.getField();

			List<String> components = new ArrayList<String>(numberComponent);
			field.setComponents(components);
		}
		field.setComponent(numberComponent, value);

		int v = block4.removeAll(fieldName);
		log.info("removido fieldName " + fieldName + " value " + v);

		block4.add(field);

		return getField(fieldName);
	}

	public Field addField(Field field, boolean replace) {
		if (replace) {
			Field fld = getField(field.getName());
			int count = block4.countByName(field.getName());
			int index = block4.indexOfFirst(field.getName());
			
			if (count == 1 && index > -1) {
				log.info("reemplazando index " + field.getName() + " index " + index + " " + fld.getValue());
				block4.getTags().set(index, field.asTag());
				
				log.info("reemplazando index " + field.getName() + " index " + index + " " + field.getValue());				
			} else {
				int c = block4.countAll();
				int v = block4.removeAll(field.getName());
				int c1 = block4.countAll();
				log.info("removido field " + field.getName() + " ant " + c + " count: " + v + " c1 " + c1);
				
				block4.add(field);				
			}

		}else {
			block4.add(field);
		}

		Field f = getField(field.getName());
		return f;
	}

	public Field addField(Field field) {
		return addField(field, true);
	}

	public MtSwiftMessage getMtSwiftMessage() {
		return mtSwiftMessage;
	}

	public String FIN() {
		mtSwiftMessage.updateFromModel();
		return mtSwiftMessage.getMessage();
	}

	public Field setField20(Integer nroCorr, Date fechaValor, String userIniciales) {
		userIniciales = StringUtils.trim(userIniciales);
		
		Field20 f = new Field20();

		String corr = String.format("%04d", (nroCorr == null ? 0 : nroCorr));
		String fecStr = UtilsDate.stringFromDate(fechaValor, "ddMMyy");

		String valor = corr + "/" + fecStr + "/" + userIniciales;

		f.setReference(valor);

		return f; //return addField(f);
	}

	public Field setField21(String valor) {
		valor = StringUtils.trim(valor);
		
		Field21 f = new Field21();
		f.setReference(valor);
		return f; //return addField(f);
	}

	public Field setField32A(Date fecha, String codMoneda, BigDecimal monto) {
		Field32A f = new Field32A();

		Calendar c = GregorianCalendar.getInstance();
		c.setTime(fecha);
		Currency currency = Currency.getInstance(codMoneda);

		f.setDate(c);
		f.setCurrency(currency);
		f.setAmount(monto);

		return f; //return addField(f);
	}

	public Field setField52A(String ctaNro, String bic) {
		ctaNro = StringUtils.trim(ctaNro);
		bic = StringUtils.trim(bic);
		
		Field52A f = new Field52A();
		f.setAccount(ctaNro);
		BIC bicswf = new BIC(bic);
		f.setBIC(bicswf);
		return f; //return addField(f);
	}

	public Field setField52D(String valor) {
		valor = StringUtils.trim(valor);
		
		Field52D f = new Field52D();
		return f; //return addField(f);
	}

	public Field setField53A(String ctaNro, String bic) {
		ctaNro = StringUtils.trim(ctaNro);
		bic = StringUtils.trim(bic);
		
		Field53A f = new Field53A();
		f.setAccount(ctaNro);
		BIC bicswf = new BIC(bic);
		f.setBIC(bicswf);
		
		return f; //return addField(f);
	}

	public Field setField53B(String ctaNro, String location) {
		ctaNro = StringUtils.trim(ctaNro);
		location = StringUtils.trim(location);
		
		Field53B f = new Field53B();
		f.setAccount(ctaNro);
		f.setLocation(location);

		SwiftParseUtils.setComponentsFromTokens(f, 3, 3, 34, location);
		return f; //return addField(f);
	}

	public Field setField53D(String valor) {
		valor = StringUtils.trim(valor);
		
		Field53D f = new Field53D();
		return f; //return addField(f);
	}

	public Field setField54A(String ctaNro, String bic) {
		ctaNro = StringUtils.trim(ctaNro);
		bic = StringUtils.trim(bic);
		
		Field54A f = new Field54A();
		f.setAccount(ctaNro);
		BIC bicswf = new BIC(bic);
		f.setBIC(bicswf);
		return f; //return addField(f);
	}

	public Field setField54B(String ctaNro, String location) {
		ctaNro = StringUtils.trim(ctaNro);
		location = StringUtils.trim(location);
		
		Field54B f = new Field54B();
		f.setAccount(ctaNro);
		f.setLocation(location);
		SwiftParseUtils.setComponentsFromTokens(f, 3, 3, 34, location);		
		return f; //return addField(f);
	}

	public Field setField54D(String valor) {
		valor = StringUtils.trim(valor);
		
		Field54D f = new Field54D();
		return f; //return addField(f);
	}

	public Field setField56A(String ctaNro, String bic) {
		ctaNro = StringUtils.trim(ctaNro);
		bic = StringUtils.trim(bic);
		
		Field56A f = new Field56A();
		f.setAccount(ctaNro);
		BIC bicswf = new BIC(bic);
		f.setBIC(bicswf);
		return f; //return addField(f);
	}

	public Field setField56D(String valor) {
		Field56D f = new Field56D();
		return f; //return addField(f);
	}

	public Field setField57A(String ctaNro, String bic) {
		ctaNro = StringUtils.trim(ctaNro);
		bic = StringUtils.trim(bic);
		
		Field57A f = new Field57A();
		f.setAccount(ctaNro);
		BIC bicswf = new BIC(bic);
		f.setBIC(bicswf);
		return f; //return addField(f);
	}

	public Field setField57B(String ctaNro, String location) {
		ctaNro = StringUtils.trim(ctaNro);
		location = StringUtils.trim(location);
		
		Field57B f = new Field57B();
		f.setAccount(ctaNro);
		f.setLocation(location);
		SwiftParseUtils.setComponentsFromTokens(f, 3, 3, 34, location);
		return f; //return addField(f);
	}

	public Field setField57D(String ctaNro, String location) {
		ctaNro = StringUtils.trim(ctaNro);
		location = StringUtils.trim(location);
		
		Field57D f = new Field57D();
		f.setAccount(ctaNro);
		f.setNameAndAddressLine1(location);
		return f; //return addField(f);
	}

	public Field setField58A(String ctaNro, String bic) {
		ctaNro = StringUtils.trim(ctaNro);
		bic = StringUtils.trim(bic);
		
		Field58A f = new Field58A();
		f.setAccount(ctaNro);
		BIC bicswf = new BIC(bic);
		f.setBIC(bicswf);
		return f; //return addField(f);
	}

	public Field setField58D(String ctaNro, String location) {
		ctaNro = StringUtils.trim(ctaNro).toUpperCase();
		location = StringUtils.trim(location).toUpperCase();

		if (ctaNro.startsWith("FW")) {
			ctaNro = "/".concat(ctaNro);
		}
		
		Field58D f = new Field58D();
		f.setAccount(ctaNro);
		List<String> lines = MensSwiftUtiles.splitInLines(location, 3, "", "", 1);
		SwiftParseUtils.setComponentsFromLines(f, 3, f.componentsPattern().length(), 0, lines);
		return f; // return addField(f);
	}
	public Field setField58D(String ctaNro, String name, String location) {
		ctaNro = StringUtils.trim(ctaNro);
		name = StringUtils.trim(name);
		location = StringUtils.trim(location);
		
		Field58D f = new Field58D();
		f.setAccount(ctaNro);
		String nameandlocation = name + " " + location;
		f.setNameAndAddressLine1(nameandlocation);
		return f; //return addField(f);
	}
	public Field setField72(String valor) {
		valor = StringUtils.trim(valor);
		Field72 f = new Field72();
		SwiftParseUtils.setComponentsFromTokens(f, 1, 35, 34, valor);
		return f; //return addField(f);
	}
	public void fromString(String swiftPlano) throws IOException{
		log.info("fromString " + swiftPlano);
		SwiftParser swiftParser = new SwiftParser(swiftPlano);
		SwiftMessage swiftMessage = swiftParser.message();
		
		mtSwiftMessage = new MtSwiftMessage(swiftMessage);
		mtSwiftMessage.setModelMessage(swiftMessage);
		mtSwiftMessage.updateFromModel();

		//log.info("FIIN " + mtSwiftMessage.getMessage());
		
		block1 = swiftMessage.getBlock1();
		block2 = swiftMessage.getBlock2();
		swiftBlock2Input = (SwiftBlock2Input) block2;
		block3 = swiftMessage.getBlock3();
		block4 = swiftMessage.getBlock4();
	}
	public void verificarPlano(String swiftPlano) {
		if (StringUtils.isBlank(swiftPlano) ) {
			throw new RuntimeException("Error al verificar mensaje parametro swiftPlano nulo");
		}
		
		try {
			log.info("Verificando::\n" + swiftPlano);
			fromString(swiftPlano);
			
			SwiftMessage swiftMessage = mtSwiftMessage.getModelMessage();
			if (swiftMessage.getBlockCount() <=3 ){
				throw new RuntimeException("numero de bloques invalido: " + swiftMessage.getBlockCount());
			}
			
			if (swiftMessage.getType() == null ){
				throw new RuntimeException("tipo de mensaje nulo");
			}
			
			if (swiftMessage.getSender() == null ){
				throw new RuntimeException("campo sender nulo");
			}
			
			if (swiftMessage.getReceiver() == null ){
				throw new RuntimeException("campo receiver nulo");
			}			
			
			if (block4 == null || block4.isEmpty() || block4.getTags().size() <= 1) {
				throw new RuntimeException("bloque 4 con campos insuficientes" );
			}

			
		} catch (Exception e) {
			log.error("Error al verificar mensaje plano:" + e.getMessage(), e);
			throw new RuntimeException("Error al verificar swift " + e.getMessage() , e);
		}
	}
	public SwiftBlock1 getBlock1() {
		return block1;
	}

	public void setBlock1(SwiftBlock1 block1) {
		this.block1 = block1;
	}

	public SwiftBlock2 getBlock2() {
		return block2;
	}

	public void setBlock2(SwiftBlock2 block2) {
		this.block2 = block2;
	}

	public SwiftBlock3 getBlock3() {
		return block3;
	}

	public void setBlock3(SwiftBlock3 block3) {
		this.block3 = block3;
	}

	public SwiftBlock4 getBlock4() {
		return block4;
	}

	public void setBlock4(SwiftBlock4 block4) {
		this.block4 = block4;
	}

	public SwiftBlock5 getBlock5() {
		return block5;
	}

	public void setBlock5(SwiftBlock5 block5) {
		this.block5 = block5;
	}

	public SwiftBlock2Input getSwiftBlock2Input() {
		return swiftBlock2Input;
	}

	public void setSwiftBlock2Input(SwiftBlock2Input swiftBlock2Input) {
		this.swiftBlock2Input = swiftBlock2Input;
	}
	public static void main(String[] args) {
		String cta = "/FW400047144";
		String valor = "RETRIBU,CION AL TITULAR REPóSICION DE, LA ENERGIA PAGADA Y NO, RETIRADA PERIODO ,SEPTIEMBRE 14 A ABRIL 2015.";
		valor = "/ACC/FFC:983622168 BG \"cUBAA,BOLIVIA\r\nARMAS/C\rORPORAT\rIONÁÉÍÆÓÚÑáéíóúñÁ123áAcXYZ�holamundocruel niño m'\'a(aÁÑ(ÀÇ Ã±";
		valor = "MINISTERIO DE RELACIONES EXTERIORES PLAZA MURILLO C. JUNIN ESQ. INGAVI LA PAZ - BOLIVIA MEXICO, MX MEXICO, MXBOLIVIA MEXICO, MX MEXICO, MXBOLIVIA MEXICO, MX MEXICO, MX";
		valor = "/BNF/FFC TO CORTE INTERAMERICANA//DE DERECHOS HUMANOS//ACCOUNT OEA: 5042//01120751 BOLIVIA MEXICO, MX MEXICO, MXBOLIVIA MEXICO, MX MEXICO, MXBOLIVIA MEXICO, MX MEXICO, MX";
		String location = "211 EAST 43RD STREET SUITE 1004 NY10017 NEW YORK - EE.UU.";
		SwiftMessageBcb swiftMessageBcb = new SwiftMessageBcb();
		// System.out.println("==> " + valor);
		Field field = (Field58D) swiftMessageBcb.setField58D(cta, valor);
		System.out.println(field.getValue());
		// SwiftParseUtils.setComponentsFromTokens(f, 1, 35, 34, valor);
		// System.out.println(f.getValue() + " " + f.getName());
		// System.out.println(f.getLabel(f.F_70, "103", null, Locale.ENGLISH));
		// System.out.println(f.getLabel(f.F_70, "103", null, new
		// Locale("es")));
		// System.out.println(StringEscapeUtils.unescapeHtml(f.getLabel(f.F_70,
		// "103", null, new Locale("es_ES"))));

	}

}
