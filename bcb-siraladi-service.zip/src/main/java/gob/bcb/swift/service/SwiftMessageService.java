package gob.bcb.swift.service;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.prowidesoftware.swift.model.LogicalTerminalAddress;
import com.prowidesoftware.swift.model.SwiftBlock4;
import com.prowidesoftware.swift.model.Tag;
import com.prowidesoftware.swift.model.field.Field;

import gob.bcb.bpm.siraladi.dao.InstitucionBean;
import gob.bcb.bpm.siraladi.dao.InstitucionLocal;
import gob.bcb.bpm.siraladi.dao.ParamsBean;
import gob.bcb.bpm.siraladi.dao.ParamsLocal;
import gob.bcb.bpm.siraladi.dao.SwfDetmensajeBean;
import gob.bcb.bpm.siraladi.dao.SwfDetmensajeLocal;
import gob.bcb.bpm.siraladi.dao.SwfMensajeBean;
import gob.bcb.bpm.siraladi.dao.SwfMensajeLocal;
import gob.bcb.bpm.siraladi.dao.SwfMttransferBean;
import gob.bcb.bpm.siraladi.dao.SwfMttransferLocal;
import gob.bcb.bpm.siraladi.dao.SwfMttransferdetBean;
import gob.bcb.bpm.siraladi.dao.SwfMttransferdetLocal;
import gob.bcb.bpm.siraladi.dao.SwfPersonactaBean;
import gob.bcb.bpm.siraladi.dao.SwfPersonactaLocal;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Param;
import gob.bcb.bpm.siraladi.jpa.SwfDetmensaje;
import gob.bcb.bpm.siraladi.jpa.SwfMensaje;
import gob.bcb.bpm.siraladi.jpa.SwfMttransfer;
import gob.bcb.bpm.siraladi.jpa.SwfMttransferdet;
import gob.bcb.bpm.siraladi.jpa.SwfPersonacta;
import gob.bcb.bpm.siraladi.service.ClienteLvdSir;
import gob.bcb.bpm.siraladi.utils.Constants;
import gob.bcb.lavado.client.HandlerGeneratorLauCli;
import gob.bcb.lavado.client.pojos.SearchResponse;
import gob.bcb.portiaswift.entities.Loader;
import gob.bcb.portiaswift.service.ServiceSwiftDao;
import gob.bcb.portiaswift.service.ServiceSwiftDaoImpl;
import gob.bcb.swift.exception.SwiftAdminException;
import gob.bcb.swift.pojos.SwiftDatos;
import gob.bcb.swift.pojos.SwiftMessageBcb;

//
// @Repository("swiftMessageServiceLocal")
@Service("swiftMessageServiceLocal")
@Transactional
public class SwiftMessageService implements SwiftMessageServiceLocal {
	private static final Logger log = Logger.getLogger(SwiftMessageService.class);
	public static final String CODCAMPO_IDAPP = "IDAPP";
	public static final String CODCAMPO_SERVID = "SERVID";
	public static final String CODCAMPO_LTERMINAL = "LTID";
	public static final String CODCAMPO_SESSNUM = "SESSNUM";
	public static final String CODCAMPO_SEQNUM = "SEQNUM";
	public static final String CODCAMPO_PRIORITY = "PRIOR";
	public static final String CODCAMPO_RECEIVER = "RECEIVER";

	// private SwiftMessageBcb swiftMessageBcb;
	@Autowired
	private ParamsLocal paramsLocal;
	@Autowired
	private InstitucionLocal institucionLocal;
	@Autowired
	private SwfMttransferdetLocal swfMttransferdetLocal;
	@Autowired
	private SwfMensajeLocal swfMensajeLocal;
	@Autowired
	private SwfMttransferLocal swfMttransferLocal;
	@Autowired
	private SwfPersonactaLocal swfPersonactaLocal;
	@Autowired
	private SwfDetmensajeLocal swfDetmensajeLocal;
	@Autowired
	private ServiceSwiftDao serviceSwiftDao;
	private EntityManager entityManager;

	public SwiftMessageService() {
		log.info("Creado SwiftMessageService...");
		
		log.info("Inicializando cliente LAU");
		try {
			HandlerGeneratorLauCli.initCurrentInstance("/opt/aplicaciones/configuraciones/web/siraladi", Constants.NOMBRE_APP);
		} catch (Exception e) {
			log.error("Error al inicializar cliente LAU " + e.getMessage(), e);
			throw new RuntimeException("Error al inicializar cliente LAU " + e.getMessage(), e);
		}
	
		
	}

	public SwiftMessageService(EntityManager entityManager) {
		paramsLocal = new ParamsBean();
		institucionLocal = new InstitucionBean();
		swfMttransferdetLocal = new SwfMttransferdetBean();
		swfMttransferLocal = new SwfMttransferBean();
		swfPersonactaLocal = new SwfPersonactaBean();
		swfMensajeLocal = new SwfMensajeBean();
		swfDetmensajeLocal = new SwfDetmensajeBean();
		//serviceSwiftDao = new ServiceSwiftDaoImpl(entityManager);
		
		paramsLocal.setEntityManager(entityManager);
		institucionLocal.setEntityManager(entityManager);
		swfMttransferdetLocal.setEntityManager(entityManager);
		swfMttransferLocal.setEntityManager(entityManager);
		swfPersonactaLocal.setEntityManager(entityManager);
		swfMensajeLocal.setEntityManager(entityManager);
		swfDetmensajeLocal.setEntityManager(entityManager);

		this.entityManager = entityManager;
		log.info("Creado SwiftMessageService(entityManager)...");
	}

	public SwfMensaje generarMensaje(SwiftDatos swiftDatos) {
		log.info("En generarMensaje swiftDatos inicio de generar Swift " + swiftDatos.getSwfMensaje().getMenCodmt() + " "
				+ swiftDatos.getSwfMensaje().getMenCodoperacion() + " " + swiftDatos.getSwfMensaje().getMenCodusrswf());

		SwiftMessageBcb swiftMessageBcb = new SwiftMessageBcb();
		populateSwfMensaje(swiftDatos);

		llenarBlock12(swiftMessageBcb, swiftDatos.getSwfMensaje().getMenCodmt(), swiftDatos.getSwfMensaje().getMenBic());
		llenarBlock3(swiftMessageBcb, swiftDatos.getSwfMensaje().getMenCodmt());

		obtenerCamposBlk4(swiftDatos, swiftMessageBcb);

		log.info("SMIFT::\n" + swiftMessageBcb.FIN());

		SwfMensaje swfMensaje = guardarSwiftObject(swiftDatos, swiftMessageBcb);
		return swfMensaje;

	}

	public void obtenerCamposBlk4(SwiftDatos swiftDatos, SwiftMessageBcb swiftMessageBcb) {
		log.info("En obtenerCamposBlk4 " + swiftDatos.getSwfMensaje().getMenCodmt());
		List<SwfMttransferdet> SwfMttransferdetLista = swfMttransferdetLocal.findByCodTTransfer(swiftDatos.getSwfMensaje().getMenCodmt(), 4);

		for (SwfMttransferdet swfMttransferdet : SwfMttransferdetLista) {
			Field field = obtenerValor(swiftDatos, swiftDatos.getSwfMensaje(), swiftMessageBcb, swfMttransferdet);
			swiftMessageBcb.addField(field);
		}
	}

	public void populateSwfMensaje(SwiftDatos swiftDatos) {
		log.info("En populateSwfMensaje " + (swiftDatos.getSwfMensaje() == null) + " " + (swiftDatos.getBeneficiario() == null));
		swiftDatos.getSwfMensaje().setMenCodmt(swiftDatos.getBeneficiario().getPecCodttransfer());

		Institucion institucionSender = institucionLocal.findByCodInst(swiftDatos.getSender().getId().getPecCodinst());
		swiftDatos.getSwfMensaje().setMenBic(institucionSender.getBic());

		SwfPersonacta swfPersonactaIntermediary = null;
		if (swiftDatos.getBeneficiario() != null) {
			// se determina si es o no cn intermediario
			if (swiftDatos.getBeneficiario().getPecTipoctainst().equals("I")) {
				// cta con intermediario
				// con el codigo del bco del beneficario, codigo del el bco
				// intermdiario y la cuenta del bco del beneficario en el bco
				// intermediaro se busca la cta del del co intermediario ojo
				// esta parte es de estructura arbol
				swfPersonactaIntermediary = swfPersonactaLocal.findByCodigo(swiftDatos.getBeneficiario().getId().getPecCodinst(),
						swiftDatos.getBeneficiario().getPecCodinstinter(), swiftDatos.getBeneficiario().getPecNroctainter());
			}
		}
		swiftDatos.setIntermediario(swfPersonactaIntermediary);
	}

	/**
	 * recupera valor del campo propio del bloque 4
	 * 
	 * @param swfMttransferdet
	 * @return
	 */
	public Field obtenerValor(SwiftDatos swiftDatos, SwfMensaje swfMensaje, SwiftMessageBcb swiftMessageBcb, SwfMttransferdet swfMttransferdet) {

		if (swiftMessageBcb == null) {
			swiftMessageBcb = new SwiftMessageBcb();
		}

		String campo = swfMttransferdet.getId().getDttCodcampo();
		String valorKtte = "";
		if (!StringUtils.isBlank(swfMttransferdet.getDttTipocampo())) {
			if (swfMttransferdet.getDttTipocampo().equals("K")) {
				// campo constante
				if (!StringUtils.isBlank(swfMttransferdet.getDttValcampo())) {
					valorKtte = swfMttransferdet.getDttTipocampo();
				}
			}
		}

		log.info("Obtener Valor " + swfMttransferdet.getId().getDttCodttransfer() + " campo:" + campo + " Bloque:" + swfMttransferdet.getId().getDttBloque());
		Field field = null;

		if (campo.equals("20")) {
			// ref transaccion
			field = swiftMessageBcb.setField20(swfMensaje.getMenNrocorr(), new Date(), swfMensaje.getMenCodusrswf());
		} else if (campo.equals("21")) {
			// referencia original
			field = swiftMessageBcb.setField21(swfMttransferdet.getDttValcampo());
		} else if (campo.equals("32A")) {
			// FECHA MONEDA IMPORTE
			field = swiftMessageBcb.setField32A(swfMensaje.getMenFecvalor(), swfMensaje.getMenCodmonswift(), swfMensaje.getMenMonto());
		} else if (campo.equals("52A")) {
		} else if (campo.equals("52D")) {
			// field = swiftMessageBcb.setField20(swfMensaje.getMenNrocorr(),
			// swfMensaje.getMenFecvalor(), swfMensaje.getMenCodusrswf());
		} else if (campo.equals("53A")) {
			// field = swiftMessageBcb.setField20(swfMensaje.getMenNrocorr(),
			// swfMensaje.getMenFecvalor(), swfMensaje.getMenCodusrswf());
		} else if (campo.equals("53B")) {
			// CORRESPONSAL DEL REMITENTE LUGAR
			// CTA BCB EN EL ESTANDAR
			// NOMBRE CTA
			field = swiftMessageBcb.setField53B(swiftDatos.getSender().getId().getPecNrocta(), swiftDatos.getSender().getPecDescripcta());
		} else if (campo.equals("53D")) {
			// field = swiftMessageBcb.setField20(swfMensaje.getMenNrocorr(),
			// swfMensaje.getMenFecvalor(), swfMensaje.getMenCodusrswf());
		} else if (campo.equals("54B")) {
			// field = swiftMessageBcb.setField20(swfMensaje.getMenNrocorr(),
			// swfMensaje.getMenFecvalor(), swfMensaje.getMenCodusrswf());
		} else if (campo.equals("54D")) {
			// field = swiftMessageBcb.setField20(swfMensaje.getMenNrocorr(),
			// swfMensaje.getMenFecvalor(), swfMensaje.getMenCodusrswf());
		} else if (campo.equals("56A")) {
			// BIC INTERMEDIARIO
			// NOMBRE BCO INTERMEDIARO
			// intemediario
			// 56A
			if (swiftDatos.getIntermediario() == null || swiftDatos.getIntermediario() == null || swiftDatos.getIntermediario().getId() == null
					|| swiftDatos.getIntermediario().getId().getPecCodinst() == null) {
				throw new SwiftAdminException("Mensaje con intermediario, error de parametrización revise las ctas de la institucion");
			}
			Institucion institucion = institucionLocal.findByCodInst(swiftDatos.getIntermediario().getId().getPecCodinst());
			if (institucion == null) {
				throw new SwiftAdminException("Mensaje con intermediario, institucion inexistente " + swiftDatos.getIntermediario().getId().getPecCodinst());
			}
			field = swiftMessageBcb.setField56A(null, institucion.getBic());

		} else if (campo.equals("56D")) {
			// field = swiftMessageBcb.setField20(swfMensaje.getMenNrocorr(),
			// swfMensaje.getMenFecvalor(), swfMensaje.getMenCodusrswf());
		} else if (campo.equals("57A")) {
			// ENT. DEPOSITARIA DE LA CTA - FI BIC
			Institucion institucion = institucionLocal.findByCodInst(swiftDatos.getBeneficiario().getId().getPecCodinst());
			field = swiftMessageBcb.setField57A(null, institucion.getBic());
		} else if (campo.equals("57B")) {
			// field = swiftMessageBcb.setField20(swfMensaje.getMenNrocorr(),
			// swfMensaje.getMenFecvalor(), swfMensaje.getMenCodusrswf());
		} else if (campo.equals("57D")) {
			// ENTIDAD DEPOSITARIA DE CTA NOMBRE DIRECCION
			// cuenta del bco beneficiario en el bco intermediaro

			field = swiftMessageBcb.setField57D(swiftDatos.getIntermediario().getId().getPecNrocta(), swiftDatos.getIntermediario().getPecDescripcta());
		} else if (campo.equals("58A")) {
			// field = swiftMessageBcb.setField20(swfMensaje.getMenNrocorr(),
			// swfMensaje.getMenFecvalor(), swfMensaje.getMenCodusrswf());
		} else if (campo.equals("58D")) {
			// ENT BENEFICIARIA NOMBRE DIRECCION

			field = swiftMessageBcb.setField58D(swiftDatos.getBeneficiario().getId().getPecNrocta(), swiftDatos.getBeneficiario().getPecDescripcta());
			// Institucion institucion =
			// institucionLocal.findByCodInst(swiftDatos.getBeneficiario().getId().getPecCodpersona());
			// field =
			// swiftMessageBcb.setField58D(swiftDatos.getBeneficiario().getId().getPecNrocta(),
			// institucion.getNomInst(), institucion.getNomPlaza());
		} else if (campo.equals("72")) {
			field = swiftMessageBcb.setField72(swfMttransferdet.getDttValcampo());
		} else if (campo.equals("KTTE")) {
			field = swiftMessageBcb.setField72(swfMttransferdet.getDttValcampo());
		} else {
			throw new SwiftAdminException("Campo " + campo + " Cod MT " + swfMttransferdet.getId().getDttCodttransfer() + " no definido avise a sistemas ");
		}

		if (field == null) {
			throw new SwiftAdminException(
					"Campo " + campo + " Cod MT " + swfMttransferdet.getId().getDttCodttransfer() + " sin definicion de valor, avise a sistemas");
		}

		log.info("Valor obtenido: " + swfMttransferdet.getId().getDttCodttransfer() + ":" + campo + ":" + swfMttransferdet.getId().getDttBloque() + " => "
				+ field.getValue());
		return field;
	}

	private void llenarBlock12(SwiftMessageBcb swiftMessageBcb, String mttCodttransfer, String bicReceiver) {
		log.info("Inicio llenar Block12 " + mttCodttransfer + " bicReceiver : " + bicReceiver);
		SwfMttransfer swfMttransfer = swfMttransferLocal.findByCodigo(mttCodttransfer);

		String mt = swfMttransfer.getMttCodmt();

		SwfMttransferdet swfMttransferdet = swfMttransferdetLocal.findByCodigo(mttCodttransfer, CODCAMPO_IDAPP, 1);
		log.info("XXX: swfMttransferdet " + swfMttransferdet.getDttValcampo());
		String applicationId = swfMttransferdet.getDttValcampo().trim();

		swfMttransferdet = swfMttransferdetLocal.findByCodigo(mttCodttransfer, CODCAMPO_SERVID, 1);
		String serviceId = swfMttransferdet.getDttValcampo().trim();

		Param param = paramsLocal.findByCodigo("BCB");

		String logicalTerminal = getLogicalTerminal(param.getValparam().trim(), mttCodttransfer);

		swfMttransferdet = swfMttransferdetLocal.findByCodigo(mttCodttransfer, CODCAMPO_SESSNUM, 1);
		String sessionNumber = swfMttransferdet.getDttValcampo().trim();

		swfMttransferdet = swfMttransferdetLocal.findByCodigo(mttCodttransfer, CODCAMPO_SEQNUM, 1);
		String sequenceNumber = swfMttransferdet.getDttValcampo().trim();

		// swiftMessageBcb.createBlock1("F", "01", "BCEBBOLPAXXX", "1000",
		// "100001");

		log.info("Preparando mensaje mt " + applicationId + "-" + serviceId + "-" + logicalTerminal + "-" + sessionNumber + "-" + sequenceNumber);
		swiftMessageBcb.createBlock1(applicationId, serviceId, logicalTerminal, sessionNumber, sequenceNumber);

		swfMttransferdet = swfMttransferdetLocal.findByCodigo(mttCodttransfer, CODCAMPO_PRIORITY, 2);
		String messagePriority = swfMttransferdet.getDttValcampo().trim();

		String deliveryMonitoring = null;
		String obsolescencePeriod = null;

		swiftMessageBcb.createBlock2(mt, bicReceiver, messagePriority, deliveryMonitoring, obsolescencePeriod);
	}

	private void llenarBlock3(SwiftMessageBcb swiftMessageBcb, String mt) {
		log.info("Inicio llenar Block3 " + mt);
		List<SwfMttransferdet> SwfMttransferdetLista = swfMttransferdetLocal.findByCodTTransfer(mt, 3);
		for (SwfMttransferdet swfMttransferdet : SwfMttransferdetLista) {
			swiftMessageBcb.createBlock3(swfMttransferdet.getId().getDttCodcampo(), swfMttransferdet.getDttValcampo());
		}
	}

	private String getLogicalTerminal(String codInst, String dttCodttransfer) {
		log.info("Obteniendo LogicalTerminal " + codInst + " dttCodttransfer: " + dttCodttransfer);
		Institucion institucion = institucionLocal.findByCodInst(codInst);

		SwfMttransferdet swfMttransferdet = swfMttransferdetLocal.findByCodigo(dttCodttransfer, CODCAMPO_LTERMINAL, 1);

		LogicalTerminalAddress logicalTerminalAddress = new LogicalTerminalAddress(institucion.getBic().trim());
		logicalTerminalAddress.setLTIdentifier(swfMttransferdet.getDttValcampo().trim().charAt(0));

		return logicalTerminalAddress.getSenderLogicalTerminalAddress();
	}

	private SwfMensaje guardarSwiftObject(SwiftDatos swiftDatos, SwiftMessageBcb swiftMessageBcbIn) {
		log.info("Guardando mensaje y detalles swift:: " + swiftDatos.getSwfMensaje().getMenCodoperacion() + " " + swiftDatos.getSwfMensaje().getMenCodmen());
		try {

			String menPlano = swiftMessageBcbIn.FIN();
			log.info("Guardando swift:: menPlano:: " + menPlano);

			swiftDatos.getSwfMensaje().setMenPlano(menPlano);

			SwfMensaje swfMensajeNew = swfMensajeLocal.saveorupdate(swiftDatos.getSwfMensaje());

			List<SwfDetmensaje> swfDetmensajeLista = new ArrayList<SwfDetmensaje>();

			// se elimina todos los detalles
			swfDetmensajeLocal.actualizarDetalles(swfMensajeNew, swfDetmensajeLista);

			final SwiftBlock4 b4 = swiftMessageBcbIn.getBlock4();

			if (b4 != null && !b4.isEmpty()) {
				for (Tag t : b4.getTags()) {
					// barremos todos los campos del BLOCK4
					final Field field = t.getField();

					SwfDetmensaje swfDetmensaje = swfDetmensajeLocal.actualizarCampo(swfMensajeNew.getMenCodmen(), field.getName(), 4, field.getValue(),
							swfMensajeNew.getMenAuditusr(), swfMensajeNew.getMenAuditwst());

					swfDetmensajeLista.add(swfDetmensaje);
				}
			}

			swfMensajeNew = swfMensajeLocal.findByCodigo(swfMensajeNew.getMenCodmen());
			swiftDatos.setSwfMensaje(swfMensajeNew);

			log.info("SWIFT Salvado hecho ... " + swfMensajeNew.getMenCodmen() + " " + swfMensajeNew.getMenCodoperacion());
			return swfMensajeNew;
		} catch (Exception e) {
			log.error("Error al actualizar swift " + e.getMessage(), e);
			throw new SwiftAdminException("Error al actualizar swift " + e.getMessage());
		}
	}

	private SwfMensaje actualizarCampo(SwiftDatos swiftDatos, String codCampo, Integer demBloque, String valorCampo, ClienteLvdSir clienteLvdSir) {
		// el objeto es mantener el principio que el mensaje debe ser
		// actualizado a partir de las fuentes
		log.info("actualizarCampo:: " + swiftDatos.getSwfMensaje().getMenCodmen() + " codCampo: " + codCampo + " demBloque:" + demBloque);
		SwiftMessageBcb swiftMessageBcb = new SwiftMessageBcb();

		try {
			swiftMessageBcb.fromString(swiftDatos.getSwfMensaje().getMenPlano());
			log.info("SMIFT::\n" + swiftMessageBcb.FIN());

			SwfMttransferdet swfMttransferdet = swfMttransferdetLocal.findByCodigo(swiftDatos.getSwfMensaje().getMenCodmt(), codCampo, demBloque);

			Field field = obtenerValor(swiftDatos, swiftDatos.getSwfMensaje(), swiftMessageBcb, swfMttransferdet);

			swiftMessageBcb.addField(field);

			String menPlano = swiftMessageBcb.FIN();
			log.info("Guardando swift:: menPlano:: " + menPlano);

			swiftDatos.getSwfMensaje().setMenPlano(menPlano);

			SwfMensaje swfMensajeNew = swfMensajeLocal.saveorupdate(swiftDatos.getSwfMensaje());

			SwfDetmensaje swfDetmensaje = swfDetmensajeLocal.actualizarCampo(swiftDatos.getSwfMensaje().getMenCodmen(), codCampo, demBloque, field.getValue(),
					swfMensajeNew.getMenAuditusr(), swfMensajeNew.getMenAuditwst());

			if (clienteLvdSir.getClienteLvd() != null) {
				// se realiza el scaneo
				clienteLvdSir.scanMensaje(swfMensajeNew);
			}

			swiftDatos.setSwfMensaje(swfMensajeNew);

			log.info("Detalle mensaje acutliazado ::" + swfDetmensaje.toString());

			return swfMensajeNew;

		} catch (Exception e) {
			log.error("Error al actualizar campo swift " + e.getMessage(), e);
			throw new SwiftAdminException("Error al actualizar swift " + e.getMessage(), e);
		}
	}

	private SwfMensaje generarCorrelativoSwiftPortia(SwiftDatos swiftDatos, ClienteLvdSir clienteLvdSir) {
		log.info(
				"Inicio actualizar nro swift " + swiftDatos.getSwfMensaje().getMenCodmen() + " " + swiftDatos.getAuditusr() + " " + swiftDatos.getAuditwst());

		SwfMensaje swfMensaje = swfMensajeLocal.findByCodigo(swiftDatos.getSwfMensaje().getMenCodmen());

		if (swfMensaje == null) {
			log.error("Error al actualizar nro swift mensaje " + swiftDatos.getSwfMensaje().getMenCodmen() + " inexistente");
			throw new SwiftAdminException("Error al actualizar nro swift mensaje " + swiftDatos.getSwfMensaje().getMenCodmen() + " inexistente");
		}

		if (StringUtils.isBlank(swfMensaje.getMenCveestswift()) || !swfMensaje.getMenCveestswift().trim().equals(Constants.PAR_ESTSWIFT_PEND)) {
			log.error("Error al actualizar nro swift mensaje " + swfMensaje.getMenCodmen() + " con estado " + swfMensaje.getMenCveestswift() + " invalido");
			throw new SwiftAdminException(
					"Error al actualizar nro swift mensaje " + swfMensaje.getMenCodmen() + " con estado " + swfMensaje.getMenCveestswift() + " invalido");
		}

		if (swfMensaje.getMenNrocorr() != null && swfMensaje.getMenNrocorr().compareTo(0) > 0) {
			throw new SwiftAdminException(
					"Error al actualizar nro swift mensaje " + swfMensaje.getMenCodmen() + " con nro swift asignado " + swfMensaje.getMenNrocorr());
		}

		if (StringUtils.isBlank(swfMensaje.getMenCodusrswf())) {
			log.error("Error al actualizar nro swift mensaje " + swfMensaje.getMenCodmen() + " sin codigo de usuario");
			throw new SwiftAdminException("Error al actualizar nro swift mensaje " + swfMensaje.getMenCodmen() + " sin codigo de usuario");
		}

		if (clienteLvdSir.getClienteLvd() == null) {
			// POOOOOOORTIA
			log.info("Inicio portia solicitud de nuevo nro swift");
			Loader loader = serviceSwiftDao.getLoaderQLBeanLocal().nuevoCodSwift(Constants.NOMBRE_APP, swiftDatos.getAuditwst(), swiftDatos.getAuditusr());

			log.info("Nro swift Portia asignado " + loader.getNumeroSwift() + " id " + loader.getIdLoader() + " a mensaje==> " + swfMensaje.getMenCodmen());

			swfMensaje.setMenNrocorr(loader.getNumeroSwift());
			loader = serviceSwiftDao.getLoaderQLBeanLocal().findByCodigo(loader.getIdLoader());

			log.info("loader.getIdLoader() " + loader.getIdLoader() + " " + swfMensaje.getMenNrocorr());

			if (loader == null || loader.getNumeroSwift().compareTo(swfMensaje.getMenNrocorr()) != 0) {
				throw new SwiftAdminException(
						"Error al actualizar nro swift mensaje " + swfMensaje.getMenCodmen() + " nro asignado no coincide " + swfMensaje.getMenNrocorr());
			}
		} else {
			SearchResponse searchResponse = clienteLvdSir.solicitarCorrelativo(swfMensaje.getMenCodoperacion(), swfMensaje.getMenAuditusr());
			swfMensaje.setMenNrocorr(searchResponse.getNrocorr());
			swfMensaje.setMenNrolavado(Integer.valueOf(searchResponse.getCodoperacion()));
		}

		SwfMensaje swfMensajeNew = swfMensajeLocal.saveorupdate(swfMensaje);
		swiftDatos.setSwfMensaje(swfMensajeNew);

		log.info("Fin generara correltativo a mensaje==> " + swfMensajeNew.getMenCodmen());
		return swfMensajeNew;
	}

	public SwfMensaje actualizarCorrelativo(SwfMensaje swfMensajePar) {
		log.info("Inicio actualizar correlativo portia " + swfMensajePar.getMenCodmen());

		SwiftDatos swiftDatos = swfMensajeLocal.swiftDatosFromSwfMensaje(swfMensajePar);

		swiftDatos.getSwfMensaje().setMenAuditusr(swfMensajePar.getMenAuditusr());
		swiftDatos.getSwfMensaje().setMenAuditwst(swfMensajePar.getMenAuditwst());

		swiftDatos.setAuditusr(swfMensajePar.getMenAuditusr());
		swiftDatos.setAuditwst(swfMensajePar.getMenAuditwst());

		Param param = paramsLocal.findByCodigo(Constants.LAVADO_VERIFICA_LAVADO);
		log.info("==>>>>>param.getValparam() " + param.getValparam());
		
		ClienteLvdSir clienteLvdSir = new ClienteLvdSir(entityManager);
		clienteLvdSir.initClienteLvd(paramsLocal);
		clienteLvdSir.getSessionLavado(swfMensajePar.getMenAuditusr());

		log.info("Estacion " + swfMensajePar.getMenAuditwst() + " " + swfMensajePar.getMenAuditusr());
		generarCorrelativoSwiftPortia(swiftDatos, clienteLvdSir);

		SwfMensaje swfMensaje = actualizarCampo(swiftDatos, "20", 4, null, clienteLvdSir);
		clienteLvdSir.cerrarSession(swfMensajePar.getMenAuditusr());

		log.info("FIN UPD correlativo portia " + swfMensajePar.getMenCodmen());
		return swfMensaje;
	}

	public SwfMensaje actualizarMensaje(SwfMensaje swfMensajePar) {
		log.info("Inicio actualizar correlativo portia " + swfMensajePar.getMenCodmen());

		SwiftDatos swiftDatos = swfMensajeLocal.swiftDatosFromSwfMensaje(swfMensajePar);

		swiftDatos.getSwfMensaje().setMenAuditusr(swfMensajePar.getMenAuditusr());
		swiftDatos.getSwfMensaje().setMenAuditwst(swfMensajePar.getMenAuditwst());

		swiftDatos.setAuditusr(swfMensajePar.getMenAuditusr());
		swiftDatos.setAuditwst(swfMensajePar.getMenAuditwst());

		swiftDatos.getSwfMensaje().setMenFecvalor(swfMensajePar.getMenFecvalor());

		Param param = paramsLocal.findByCodigo(Constants.LAVADO_VERIFICA_LAVADO);
		log.info("==>>>>>AAAAAAA param.getValparam() " + param.getValparam());
		
		ClienteLvdSir clienteLvdSir = new ClienteLvdSir(entityManager);
		clienteLvdSir.initClienteLvd(paramsLocal);
		clienteLvdSir.getSessionLavado(swfMensajePar.getMenAuditusr());

		SwfMensaje swfMensaje = actualizarCampo(swiftDatos, "32A", 4, null, clienteLvdSir);
		clienteLvdSir.cerrarSession(swfMensajePar.getMenAuditusr());

		log.info("FIN UPD correlativo portia " + swfMensajePar.getMenCodmen());
		return swfMensaje;
	}

	public SwfMensaje autorizarMensaje(SwfMensaje swfMensajePar) {
		log.info("Inicio AUTORIZAR MENSAJE: " + swfMensajePar.getMenCodmen());

		Param param = paramsLocal.findByCodigo(Constants.PARAM_PATHSWIFT);

		String pathSwift = param.getValparam();

		File d0 = new File(pathSwift);

		if (!d0.exists() || !d0.isDirectory()) {
			throw new SwiftAdminException("Error al autorizar directorio swift " + pathSwift + " inexistente, avise a sistemas");
		}

		SwfMensaje swfMensaje = swfMensajeLocal.autorizarSwift(swfMensajePar, pathSwift);

		return swfMensaje;
	}

	public void setServicePortiaDao(ServiceSwiftDao serviceSwiftDao) {
		this.serviceSwiftDao = serviceSwiftDao;
	}

}
