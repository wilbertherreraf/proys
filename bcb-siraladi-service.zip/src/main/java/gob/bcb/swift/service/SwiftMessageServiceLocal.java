package gob.bcb.swift.service;

import gob.bcb.bpm.siraladi.jpa.SwfMensaje;
import gob.bcb.swift.pojos.SwiftDatos;

public interface SwiftMessageServiceLocal {

	SwfMensaje actualizarCorrelativo(SwfMensaje swfMensajePar);

	SwfMensaje autorizarMensaje(SwfMensaje swfMensajePar);

	SwfMensaje actualizarMensaje(SwfMensaje swfMensajePar);

}
