package gob.bcb.swift.service;

import gob.bcb.core.utils.UtilsDate;
import gob.bcb.swift.pojos.Block4;
import gob.bcb.swift.pojos.HeaderMsg;
import gob.bcb.swift.pojos.SwiftDatos;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.prowidesoftware.swift.io.parser.SwiftParser;
import com.prowidesoftware.swift.model.MtSwiftMessage;
import com.prowidesoftware.swift.model.SwiftBlock1;
import com.prowidesoftware.swift.model.SwiftBlock2;
import com.prowidesoftware.swift.model.SwiftBlock2Input;
import com.prowidesoftware.swift.model.SwiftBlock2Output;
import com.prowidesoftware.swift.model.SwiftBlock4;
import com.prowidesoftware.swift.model.SwiftBlock5;
import com.prowidesoftware.swift.model.SwiftMessage;
import com.prowidesoftware.swift.model.Tag;
import com.prowidesoftware.swift.model.field.Field;
import com.prowidesoftware.swift.model.field.Field20;

public abstract class ReporteSwiftAbstract extends ArchivoSinpleServiceImpl {

	private static final Logger log = Logger.getLogger(ReporteSwiftAbstract.class);

	private ArchivoSinpleServiceImpl archivoTemplateReport = new ArchivoSinpleServiceImpl();
	private HeaderMsg headerMsg;
	private List<Block4> block4Lista;

	public void populateFieldsReport(String swiftPlano, SwiftDatos mensajesDatos) throws IOException {

		log.info("En populateFieldsReport: \n" + swiftPlano);

		SwiftParser swiftParser = new SwiftParser(swiftPlano);
		SwiftMessage swiftMessage = swiftParser.message();

		MtSwiftMessage mtSwiftMessage = new MtSwiftMessage(swiftMessage);
		// log.info("Sender " + swiftMessage.getSender() + " - " +
		// mtSwiftMessage.getSender());

		SwiftBlock1 block1 = swiftMessage.getBlock1();
		// log.info("XXX: block1: " + block1.toJson());

		SwiftBlock2 block2 = swiftMessage.getBlock2();
		// log.info("XXX: block2: " + block2.toJson());
		// SwiftBlock2Output swiftBlock2Output0 = (SwiftBlock2Output) block2;
		SwiftBlock2Input swiftBlock2Input = (SwiftBlock2Input) block2;
		// log.info("XXX: BlockValue " + swiftBlock2Input.getBlockValue());
		// log.info(swiftBlock2Input.toJson());

		final SwiftBlock4 b4 = swiftMessage.getBlock4();

		block4Lista = new ArrayList<Block4>();
		headerMsg = new HeaderMsg();
		headerMsg.setMencodmen(String.valueOf(mensajesDatos.getSwfMensaje().getMenCodmen()));

		headerMsg.setNrocorr("");
		if (mensajesDatos.getSwfMensaje().getMenNrocorr() != null)
			headerMsg.setNrocorr(String.valueOf(mensajesDatos.getSwfMensaje().getMenNrocorr()));

		headerMsg.setOperator((mensajesDatos.getSwfMensaje().getMenCodusrswf() == null ? "" : mensajesDatos.getSwfMensaje().getMenCodusrswf()));

		headerMsg.setCodusuario((mensajesDatos.getAuditusr() == null ? "" : mensajesDatos.getAuditusr()) + " "
				+ (mensajesDatos.getAuditwst() == null ? "" : mensajesDatos.getAuditwst()));

		headerMsg.setPriority(block2.getMessagePriority());

		headerMsg.setNroreference("I");// (swiftBlock2Output.getReceiverOutputTime());

		Field20 field20 = new Field20();
		field20 = (Field20) b4.getFieldByName("20");

		headerMsg.setReference("");
		if (field20 != null)
			headerMsg.setReference((mensajesDatos.getSwfMensaje().getMenFecauto() != null ? UtilsDate.stringFromDate(mensajesDatos.getSwfMensaje()
					.getMenFecauto(), "hhmm yyMMdd") : "")
					+ " " + field20.getValue());

		// headerMsg.setInreference(UtilsDate.stringFromDate(mensajesDatos.getSwfMensaje().getMenFecreg(),
		// "hhmm") + " " + mtSwiftMessage.getMir());
		headerMsg.setMur(mtSwiftMessage.getMur());

		headerMsg.setMt(swiftMessage.getType());
		headerMsg.setMtdescrip(mensajesDatos.getSwfMttransfer().getMttDescrip());
		headerMsg.setSender(block1.getLogicalTerminal());

		String senderdescrip = mensajesDatos.getSwfBicsSender().getBicDescrip().trim() + "\n"
				+ mensajesDatos.getSwfBicsSender().getBicCiudad().trim() + ", " + mensajesDatos.getSwfBicsSender().getBicPais().trim();
		headerMsg.setSenderdescrip(senderdescrip);

		headerMsg.setReceiver(mtSwiftMessage.getReceiver());
		headerMsg.setReceiverdescrip(mensajesDatos.getSwfBicsReceiver().getBicDescrip().trim() + "\n"
				+ mensajesDatos.getSwfBicsReceiver().getBicCiudad().trim());

		SwiftBlock5 block5 = swiftMessage.getBlock5();

		if (block5 == null) {
			block5 = new SwiftBlock5();
			headerMsg.setFooter(UtilsDate.stringFromDate(mensajesDatos.getSwfMensaje().getMenAuditfho(), "dd/MM/yyyy hh:mm:ss"));
		} else {
			headerMsg.setFooter(block5.toJson());
		}

		headerMsg.setFechora(UtilsDate.stringFromDate(new Date(), "dd/MM/yyyy hh:mm:ss"));

		if (b4 != null && !b4.isEmpty()) {
			for (Tag t : b4.getTags()) {
				final Field field = t.getField();

				String labelLan = Field.getLabel(field.getName(), null, null, new Locale("en_EN"));
				log.info("XXX labelLanlabelLan " + labelLan);
				log.info(field.getLabel() + " => " + field.getName() + " : " + field.getValue());
				

				Block4 block = new Block4();

				block.setName(field.getName());
				String label = StringEscapeUtils.unescapeHtml(field.getLabel(new Locale("en_EN")));
				block.setReference(label);

				String valorf = "";
				String valorfcomponents = "";
				String valorCampo = field.getValue();

				if (valorCampo != null) {
					String[] valorCampoArra = valorCampo.split("\r\n");
					// longitud hasta el primer salto
					int tama = valorCampoArra[0].length();
					String[] valorCampoArra2 = valorCampoArra[0].split("//");
					tama = valorCampoArra2[0].length();
					for (String linea : valorCampoArra) {
						valorf = valorf + "  ::  " + linea;
					}

					final List<String> components = field.getComponents();
					int tamacompo = 0;
					for (int i = 0; i < components.size(); i++) {
						final String component = components.get(i);

						if (!StringUtils.isBlank(component)) {
							tamacompo = tamacompo + component.length();
							if (tamacompo <= tama) {
								valorfcomponents = valorfcomponents + component + " \t ";
							} else {
								valorfcomponents = valorfcomponents + "\r\n" + component;
							}
						}
					}
				}
				block.setValue(valorfcomponents);

				block4Lista.add(block);
			}
		}
	}

	public void populateFieldsReportIn(String swiftPlano, SwiftDatos mensajesDatos) throws IOException {

		log.info(swiftPlano);

		SwiftParser swiftParser = new SwiftParser(swiftPlano);
		SwiftMessage swiftMessage = swiftParser.message();

		MtSwiftMessage mtSwiftMessage = new MtSwiftMessage(swiftMessage);

		log.info("Sender " + swiftMessage.getSender() + " - " + mtSwiftMessage.getSender());

		SwiftBlock1 block1 = swiftMessage.getBlock1();
		// log.info(block1.toJson());

		SwiftBlock2 block2 = swiftMessage.getBlock2();

		SwiftBlock2Output swiftBlock2Output = (SwiftBlock2Output) block2;
		// SwiftBlock2Input swiftBlock2Input = (SwiftBlock2Input) block2;
		// log.info(block2.toJson());

		block4Lista = new ArrayList<Block4>();
		headerMsg = new HeaderMsg();
		headerMsg.setMencodmen(String.valueOf(mensajesDatos.getSwfMensaje().getMenCodmen()));
		headerMsg.setNrocorr("");
		if (mensajesDatos.getSwfMensaje().getMenNrocorr() != null)
			headerMsg.setNrocorr(String.valueOf(mensajesDatos.getSwfMensaje().getMenNrocorr()));

		headerMsg.setCodusuario("");
		if (!StringUtils.isBlank(mensajesDatos.getAuditusr()))
			headerMsg.setCodusuario(mensajesDatos.getAuditusr());

		headerMsg.setPriority(block2.getMessagePriority());

		headerMsg.setNroreference(swiftBlock2Output.getReceiverOutputTime());
		headerMsg.setReference(block1.getApplicationId() + " " + block1.getBlockValue());
		headerMsg.setReference(swiftBlock2Output.getReceiverOutputDate() + block1.getLogicalTerminal() + block1.getSessionNumber()
				+ block1.getSequenceNumber());

		headerMsg.setNroinreference(swiftBlock2Output.getSenderInputTime());
		headerMsg.setInreference(mtSwiftMessage.getMir());
		headerMsg.setInreference(swiftBlock2Output.getMIR());

		headerMsg.setMt(swiftMessage.getType());
		headerMsg.setMtdescrip(mensajesDatos.getSwfMttransfer().getMttDescrip());
		headerMsg.setSender(mensajesDatos.getSwfMensaje().getMenBic());

		String senderdescrip = mensajesDatos.getSwfBicsSender().getBicDescrip() + "\n" + mensajesDatos.getSwfBicsSender().getBicDirecc1() + ", "
				+ mensajesDatos.getSwfBicsSender().getBicCiudad() + ", " + mensajesDatos.getSwfBicsSender().getBicPais();
		headerMsg.setSenderdescrip(senderdescrip);
		headerMsg.setReceiver(mtSwiftMessage.getReceiver());
		headerMsg.setReceiverdescrip(mensajesDatos.getSwfBicsReceiver().getBicDescrip() + "\n" + mensajesDatos.getSwfBicsReceiver().getBicPais());

		SwiftBlock5 block5 = swiftMessage.getBlock5();

		headerMsg.setFooter(block5.toJson());
		headerMsg.setFechora(UtilsDate.stringFromDate(new Date(), "dd/MM/yyyy hh:mm:ss"));

		headerMsg.setMur(mtSwiftMessage.getMur());

		final SwiftBlock4 b4 = swiftMessage.getBlock4();
		if (b4 != null && !b4.isEmpty()) {
			for (Tag t : b4.getTags()) {
				final Field field = t.getField();

				log.info(field.getLabel() + " => " + field.getName() + " : " + field.getValue());

				Block4 block = new Block4();

				block.setName(field.getName());
				String label = StringEscapeUtils.unescapeHtml(field.getLabel(new Locale("es_ES")));
				block.setReference(label);

				String valorf = "";
				String valorfcomponents = "";
				String valorCampo = field.getValue();

				if (valorCampo != null) {
					String[] valorCampoArra = valorCampo.split("\r\n");
					// longitud hasta el primer salto
					int tama = valorCampoArra[0].length();
					String[] valorCampoArra2 = valorCampoArra[0].split("//");
					tama = valorCampoArra2[0].length();
					for (String linea : valorCampoArra) {
						valorf = valorf + "  ::  " + linea;
					}

					final List<String> components = field.getComponents();
					int tamacompo = 0;
					for (int i = 0; i < components.size(); i++) {
						final String component = components.get(i);

						if (!StringUtils.isBlank(component)) {
							tamacompo = tamacompo + component.length();
							if (tamacompo <= tama) {
								valorfcomponents = valorfcomponents + component + " \t ";
							} else {
								valorfcomponents = valorfcomponents + "\r\n" + component;
							}
						}
					}
				}
				block.setValue(valorfcomponents);

				block4Lista.add(block);
			}
		}
	}

	public ArchivoSinpleServiceImpl getArchivoTemplateReport() {
		return archivoTemplateReport;
	}

	public void setArchivoTemplateReport(ArchivoSinpleServiceImpl archivoTemplateReport) {
		this.archivoTemplateReport = archivoTemplateReport;
	}

	public void initArchivoTemplate(InputStream in, String nameReport) {
		archivoTemplateReport = new ArchivoSinpleServiceImpl();
		archivoTemplateReport.fileUpload(in, nameReport);
		archivoTemplateReport.getArchivoSinple().setDirectory("");
	}

	public HeaderMsg getHeaderMsg() {
		return headerMsg;
	}

	public void setHeaderMsg(HeaderMsg headerMsg) {
		this.headerMsg = headerMsg;
	}

	public List<Block4> getBlock4Lista() {
		return block4Lista;
	}

	public void setBlock4Lista(List<Block4> block4Lista) {
		this.block4Lista = block4Lista;
	}

}
