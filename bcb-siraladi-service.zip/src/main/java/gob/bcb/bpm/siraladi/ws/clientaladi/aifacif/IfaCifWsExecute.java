
package gob.bcb.bpm.siraladi.ws.clientaladi.aifacif;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Login" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Contrasena" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Convenio" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Estado" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Ranifadesde" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Ranifahasta" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Fecini" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="Fecfin" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="Fecmodini" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="Fecmodfin" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "login",
    "contrasena",
    "convenio",
    "estado",
    "ranifadesde",
    "ranifahasta",
    "fecini",
    "fecfin",
    "fecmodini",
    "fecmodfin"
})
@XmlRootElement(name = "ifa_cif_ws.Execute")
public class IfaCifWsExecute {

    @XmlElement(name = "Login", required = true)
    protected String login;
    @XmlElement(name = "Contrasena", required = true)
    protected String contrasena;
    @XmlElement(name = "Convenio", required = true)
    protected String convenio;
    @XmlElement(name = "Estado", required = true)
    protected String estado;
    @XmlElement(name = "Ranifadesde")
    protected String ranifadesde;
    @XmlElement(name = "Ranifahasta")
    protected String ranifahasta;
    @XmlElement(name = "Fecini")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar fecini;
    @XmlElement(name = "Fecfin")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar fecfin;
    @XmlElement(name = "Fecmodini")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar fecmodini;
    @XmlElement(name = "Fecmodfin")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar fecmodfin;

    /**
     * Gets the value of the login property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLogin() {
        return login;
    }

    /**
     * Sets the value of the login property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLogin(String value) {
        this.login = value;
    }

    /**
     * Gets the value of the contrasena property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContrasena() {
        return contrasena;
    }

    /**
     * Sets the value of the contrasena property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContrasena(String value) {
        this.contrasena = value;
    }

    /**
     * Gets the value of the convenio property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConvenio() {
        return convenio;
    }

    /**
     * Sets the value of the convenio property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConvenio(String value) {
        this.convenio = value;
    }

    /**
     * Gets the value of the estado property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEstado() {
        return estado;
    }

    /**
     * Sets the value of the estado property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEstado(String value) {
        this.estado = value;
    }

    /**
     * Gets the value of the ranifadesde property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRanifadesde() {
        return ranifadesde;
    }

    /**
     * Sets the value of the ranifadesde property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRanifadesde(String value) {
        this.ranifadesde = value;
    }

    /**
     * Gets the value of the ranifahasta property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRanifahasta() {
        return ranifahasta;
    }

    /**
     * Sets the value of the ranifahasta property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRanifahasta(String value) {
        this.ranifahasta = value;
    }

    /**
     * Gets the value of the fecini property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getFecini() {
        return fecini;
    }

    /**
     * Sets the value of the fecini property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFecini(XMLGregorianCalendar value) {
        this.fecini = value;
    }

    /**
     * Gets the value of the fecfin property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getFecfin() {
        return fecfin;
    }

    /**
     * Sets the value of the fecfin property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFecfin(XMLGregorianCalendar value) {
        this.fecfin = value;
    }

    /**
     * Gets the value of the fecmodini property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getFecmodini() {
        return fecmodini;
    }

    /**
     * Sets the value of the fecmodini property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFecmodini(XMLGregorianCalendar value) {
        this.fecmodini = value;
    }

    /**
     * Gets the value of the fecmodfin property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getFecmodfin() {
        return fecmodfin;
    }

    /**
     * Sets the value of the fecmodfin property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFecmodfin(XMLGregorianCalendar value) {
        this.fecmodfin = value;
    }

}
