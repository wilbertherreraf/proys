package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The primary key class for the categoria database table.
 * 
 */

@Embeddable
public class CategoriaPK implements Serializable {

	@Column(name="cod_persona")
	private String codPersona;

	@Temporal(TemporalType.DATE)
	@Column(name="fecha_vig")
	private Date fechaVig;
	
	@Column(name="cod_calif")
	private String codCalif;

    public CategoriaPK() {
    }
	public String getCodPersona() {
		return this.codPersona;
	}
	public Date getFechaVig() {
		return fechaVig;
	}
	public void setFechaVig(Date fechaVig) {
		this.fechaVig = fechaVig;
	}
	public void setCodPersona(String codPersona) {
		this.codPersona = codPersona;
	}
	public String getCodCalif() {
		return this.codCalif;
	}
	public void setCodCalif(String codCalif) {
		this.codCalif = codCalif;
	}

	
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof CategoriaPK)) {
			return false;
		}
		CategoriaPK castOther = (CategoriaPK)other;
		return 
			this.codPersona.equals(castOther.codPersona)
			&& this.codCalif.equals(castOther.codCalif)
			&& this.fechaVig.equals(castOther.fechaVig);

    }
    
	
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.codPersona.hashCode();
		hash = hash * prime + this.codCalif.hashCode();
		hash = hash * prime + this.fechaVig.hashCode();
		
		return hash;
    }
}
