package gob.bcb.bpm.siraladi.utils;

/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public interface StatusCode {
	public static final String OPERACION_RECEIVED = "Received";	
	public static final String OPERACION_SUCCESS = "A00000";
	public static final String OPERACION_ERROR = "Error";
	public static final String ALADI_EXCEPTION = "ERROR_DE_VALIDACION";
	public static final String OPERACION_SENDED = "Sended";
	public static final String UNKNOWN_EXCEPTION = "UnknownException";	
	public static final String RUNTIME_EXCEPTION = "RuntimeException";	
	public static final String DATABASE_EXCEPTION = "DataBaseException";
	public static final String SECURITY_EXCEPTION = "SecurityException";	
	public static final String UNSUPPORTED_OPERATION_EXCEPTION = "UnsupportedOperationException";	
}
