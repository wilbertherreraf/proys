package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.exceptions.AladiException;
import gob.bcb.bpm.siraladi.jpa.Horario;
import gob.bcb.bpm.siraladi.jpa.Param;

import java.util.List;


import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("paramsLocal")
@Transactional
public class ParamsBean extends GenericDAO<String, Param> implements ParamsLocal {
	public Param findByCodigo(String nomparam) {
		String jpql = "SELECT t FROM Param t ";
		jpql = jpql.concat("WHERE t.nomparam = :nomparam ");

		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("nomparam", nomparam);

		List lista = query.getResultList();
		if (lista.size() > 0) {
			return (Param) lista.get(0);
		}
		throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Parametro " +nomparam + " no fue parametrizado en tabla Params" });
	}
	
	public Param saveorupdate(Param params ) {
		Param horarioOld = findByCodigo(params.getNomparam());
	
		if (horarioOld == null){
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Registro inexistente" });
		} else {
			makePersistent(params);
		}
		horarioOld = findByCodigo(params.getNomparam());
		log.info("Actualizando Param " + horarioOld.toString());		
		return horarioOld; 
	}	
}
