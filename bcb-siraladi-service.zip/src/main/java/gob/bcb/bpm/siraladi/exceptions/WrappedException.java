package gob.bcb.bpm.siraladi.exceptions;

/**
 * Wraps an exception, which a program cannot be expected to handle (e.g. certain flavors of
 * SQLException, Error, RuntimeException, ...). This exception type is
 * used as a "catch all" mechanism, when there is no need to specify the exact failure any
 * further. The WrappedException is a RuntimeException and can be thrown freely.
 */
/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public class WrappedException extends UnrecoverableException {

	public static final String VERSION = "$Id: WrappedException.java 1 2011-07-30 13:37:36Z wherrera $";
	private static final long serialVersionUID = -4215933609877540662L;

	/**
	 * @see UnrecoverableException#UnrecoverableException(ErrorCodes.ErrorCode, Layer, String)
	 */
	public WrappedException(Layer layer, Throwable cause) {
        super(ErrorCodes.WRAPPED_EXCEPTION, layer, "Wrapped" , cause);
    }
}
