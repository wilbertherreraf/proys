package gob.bcb.bpm.siraladi.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


import gob.bcb.bpm.siraladi.jpa.PlanPago;
import gob.bcb.bpm.siraladi.jpa.PlanPagoPK;


public interface PlanPagoLocal extends DAO<PlanPagoPK, PlanPago> {
	List<PlanPago> findPlanPagos(Integer nroMov, String cveEstadoPlan, Date fechaVal);
	PlanPago findPlanPagoByReembolso(Integer nroMov, Date fechaVal, BigDecimal monto, String capitalOInteres);
	/**
	 * Retorna el ultimo numero registrado para una apertura
	 * @param nroMov numero de apertura
	 * @param em 
	 * @return un Integer, si no encuentra es nulo
	 */
	Integer getMaxPPagos(Integer nroMov);

	/**
	 * Retorna la suma del monto total del plan de pagos entre registros cobrados y no cobrados
	 * @param nroMov nro de movimeitno de instrumento
	 * @param cveEstadoPlan estato del plan si es nulo se excluye del filtro
	 * @param fechaVal fecha hasta la cual sumar si es nulo se excluye del filtro
	 * @return suma del capital y el interes del plan de pagos 
	 */
	BigDecimal getSumaPlanPagos(Integer nroMov, String cveEstadoPlan, Date fechaVal);
}
