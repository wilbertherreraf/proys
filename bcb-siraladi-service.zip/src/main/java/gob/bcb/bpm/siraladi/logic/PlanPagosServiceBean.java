package gob.bcb.bpm.siraladi.logic;

import java.math.BigDecimal;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import javax.annotation.Resource;


import javax.persistence.EntityManager;
import javax.transaction.UserTransaction;
import gob.bcb.bpm.siraladi.dao.AperturaBean;
import gob.bcb.bpm.siraladi.dao.AperturaLocal;
import gob.bcb.bpm.siraladi.dao.EntityUserTransaction;
import gob.bcb.bpm.siraladi.dao.PlanPagoBean;
import gob.bcb.bpm.siraladi.dao.PlanPagoLocal;
import gob.bcb.bpm.siraladi.dao.RegistroBean;
import gob.bcb.bpm.siraladi.dao.RegistroLocal;
import gob.bcb.bpm.siraladi.exceptions.AladiException;
import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Instrumento;
import gob.bcb.bpm.siraladi.jpa.Movimiento;
import gob.bcb.bpm.siraladi.jpa.PlanPago;
import gob.bcb.bpm.siraladi.jpa.PlanPagoPK;
import gob.bcb.bpm.siraladi.jpa.Registro;
import gob.bcb.bpm.siraladi.service.ConfigurationServ;
import gob.bcb.bpm.siraladi.utils.Constants;
import gob.bcb.bpm.siraladi.utils.UtilsDate;
import gob.bcb.bpm.siraladi.ws.clientaladi.ClientAladiWSHandler;
import gob.bcb.bpm.siraladi.ws.clientaladi.RespWSAladi;

/**
 * @author wilherrera Wilbert Herrera Flores Banco Central de Bolivia Departamento de Desarrollo
 */

public class PlanPagosServiceBean extends EntityUserTransaction implements PlanPagosServiceLocal {
	private static Logger log = Logger.getLogger(PlanPagosServiceBean.class);
	
	private PlanPagoLocal planPagoLocal;
	private Map<String, Object> warnnings = new HashMap<String, Object>();

	public PlanPagosServiceBean(EntityManager entityManager) {
		super(entityManager);
		planPagoLocal = new PlanPagoBean();
		planPagoLocal.setEntityManager(entityManager);
	}

	
	public PlanPago crearReg(PlanPago planPago, Apertura apertura) {
		planPago.setCveEstadoPlan("P");

		isValidData(planPago, apertura);

		List<PlanPago> planPagoList = planPagoLocal.findPlanPagos(apertura.getNroMov(), null, planPago.getFechaVal());
		for (PlanPago planPago2 : planPagoList) {
			if (planPago.getFechaNeg().equals(planPago2.getFechaNeg()) && planPago.getMonto().compareTo(planPago2.getMonto()) == 0) {
				throw new AladiException("PLAN_PAGOS_EXISTENTE", new Object[] { apertura.getNroReembLiteral(),
						UtilsDate.stringFromDate(planPago.getFechaVal(), Constants.FORMAT_DATE_DB) });
			}
		}

		log.debug("creando plan de pagos para nro mov " + apertura.getNroMov() + " fecha " + planPago.getFechaVal());

		MovimientoServiceLocal movimientoService = new MovimientoServiceBean(getEntityManager());
		Movimiento movimiento = movimientoService.actualizarNroReembolso(apertura.getNroMov());
		PlanPagoPK planPagoPK = new PlanPagoPK();

		Integer nroPlan = planPagoLocal.getMaxPPagos(apertura.getNroMov());
		if (nroPlan == null) {
			nroPlan = Integer.valueOf(0);
		}
		nroPlan++;
		planPagoPK.setNroMov(apertura.getNroMov());
		planPagoPK.setNroPlan(nroPlan);
		planPago.setNroSecReemb(movimiento.getNroSecReemb());
		planPago.setId(planPagoPK);

		planPago = planPagoLocal.makePersistent(planPago);

		return planPago;
	}

	
	public List<PlanPago> crearReg(List<PlanPago> planPagoListIn, Apertura apertura) {
		if (apertura == null) {
			throw new AladiException("OBJETO_NULO", new Object[] { "Objeto 'apertura' nulo" });
		}

		List<PlanPago> planPagoList = new ArrayList<PlanPago>();
		for (PlanPago planPago : planPagoListIn) {
			planPagoList.add(crearReg(planPago, apertura));
		}
		return planPagoList;
	}

	public PlanPago modificar_plan(PlanPago planPago, Apertura apertura) {
		if (planPago.getId() == null) {
			throw new AladiException("OBJETO_NULO", new Object[] { "Objeto ID plan pagos nulo" });
		}
		PlanPago planPagoOld = planPagoLocal.findById(planPago.getId(), false);
		if (planPagoOld == null) {
			throw new AladiException("PLAN_PAGOS_NO_ENCONTRADO", new Object[] { apertura.getNroReembLiteral(), planPago.getFechaVal(), planPago.getMonto() });
		}
		if (planPagoOld.getCveEstadoPlan().equals("S")) {
			throw new AladiException("PLAN_PAGOS_NO_ENCONTRADO", new Object[] { apertura.getNroReembLiteral(), planPago.getFechaVal(), planPago.getMonto() });
		}

		planPagoOld.setCapital(planPago.getCapital());
		planPagoOld.setInteres(planPago.getInteres());
		planPagoOld.setFechaNeg(planPago.getFechaNeg());
		planPagoOld.setFechaVal(planPago.getFechaVal());
		planPagoOld.setCveEstadoPlan(planPago.getCveEstadoPlan());
		isValidData(planPagoOld, apertura);

		planPagoOld = planPagoLocal.makePersistent(planPagoOld);
		planPagoLocal.flush();
		return planPagoOld;
	}

	
	public PlanPago modificar(PlanPago planPago, Apertura apertura) {
		String cveEstadoPlan = planPago.getCveEstadoPlan();

		if (planPago.getCveEstadoPlan() == null) {
			throw new AladiException("OBJETO_NULO", new Object[] { "Valor de estado plan nulo" });
		}

		if (cveEstadoPlan.equals("E")) {
			// registro marcado con el monto de la emision
			List<PlanPago> planPagoList = planPagoLocal.findPlanPagos(apertura.getNroMov(), cveEstadoPlan, null);
			if (planPagoList.size() == 0) {
				planPago = crearReg(planPago, apertura);
			} else if (planPagoList.size() > 1) {
				throw new AladiException("PPAGOS_ESTADO_EMISION_MULTIPLE", new Object[] { apertura.getNroReembLiteral() });
			} else {
				// PlanPago planPagoOld = planPagoLocal.findById(planPagoList.get(0).getId(), false);
				PlanPago planPagoOld = modificar_plan(planPagoList.get(0), apertura);
				return planPagoOld;
			}
		} else if (cveEstadoPlan.equals("P")) {
			if (planPago.getId() == null) {
				throw new AladiException("OBJETO_NULO", new Object[] { "Objeto ID plan pagos nulo" });
			}
			if (planPago.getId().getNroPlan() == null || planPago.getId().getNroPlan().equals(0)) {
				// si esta en P y nro plan es cero o nulo se crea un nuevo
				// registro
				planPago = crearReg(planPago, apertura);
				planPagoLocal.flush();
				registroWSPorExport(planPago, apertura, "N");
				planPago.setCveEstadoPlan("N");
				planPago = planPagoLocal.makePersistent(planPago);
				return planPago;
			} else {
				// si envia con estado P este se modifica y se negocia excepto
				// si esta suspendido
				PlanPago planPagoOld = modificar_plan(planPago, apertura);

				if (planPagoOld.getFechoraRegaladi() == null) {
					// no existe registro de que fueron registrados en aladi
					// informamos a convenio aladi si es exportaci n
					registroWSPorExport(planPagoOld, apertura, "N");
				} else {
					registroWSPorExport(planPagoOld, apertura, "X");
				}

				planPagoOld.setCveEstadoPlan("N");
				planPagoOld = planPagoLocal.makePersistent(planPagoOld);
				return planPagoOld;
			}

		} else if (cveEstadoPlan.equals("N")) {
			// modificacion de una negociacion hecha
			PlanPago planPagoOld = modificar_plan(planPago, apertura);

			if (planPagoOld.getFechoraRegaladi() == null) {
				// por si las moscas si no se inform  anteriormente
				// informamos a convenio aladi
				registroWSPorExport(planPagoOld, apertura, "N");
			} else {
				// informamos a convenio aladi
				registroWSPorExport(planPagoOld, apertura, "X");
			}
			planPagoOld = planPagoLocal.makePersistent(planPagoOld);
			planPagoLocal.flush();
			return planPagoOld;
		} else if (cveEstadoPlan.equals("S")) {
			// eliminar o suspender un plan de pago
			if (planPago.getId() == null) {
				throw new AladiException("OBJETO_NULO", new Object[] { "Objeto ID plan pagos nulo" });
			}

			PlanPago planPagoOld = planPagoLocal.findById(planPago.getId(), false);
			if (planPagoOld == null) {
				throw new AladiException("PLAN_PAGOS_NO_ENCONTRADO",
						new Object[] { apertura.getNroReembLiteral(), planPago.getFechaVal(), planPago.getMonto() });
			}
			if (planPagoOld.getCveEstadoPlan().equals("S")) {
				throw new AladiException("PLAN_PAGOS_NO_ENCONTRADO",
						new Object[] { apertura.getNroReembLiteral(), planPago.getFechaVal(), planPago.getMonto() });
			}
			planPagoOld.setCveEstadoPlan(cveEstadoPlan);
			if (planPagoOld.getFechoraRegaladi() == null) {
				// no fue informado al peru, se elimina fisicamente
				planPagoLocal.makeTransient(planPagoOld);
				planPagoLocal.flush();
			} else {
				// no se elimina negociaciones fisicamente
				planPagoOld = planPagoLocal.makePersistent(planPagoOld);
				planPagoLocal.flush();
				registroWSPorExport(planPagoOld, apertura, "X");
				planPagoOld = planPagoLocal.makePersistent(planPagoOld);
				planPagoLocal.flush();
			}
			return planPagoOld;
		} else if (cveEstadoPlan.equals("C")) {
			// si se cancela
			if (planPago.getId() == null) {
				throw new AladiException("OBJETO_NULO", new Object[] { "Objeto ID plan pagos nulo" });
			}

			PlanPago planPagoOld = planPagoLocal.findById(planPago.getId(), false);
			if (planPagoOld == null) {
				throw new AladiException("PLAN_PAGOS_NO_ENCONTRADO",
						new Object[] { apertura.getNroReembLiteral(), planPago.getFechaVal(), planPago.getMonto() });
			}

			if (planPagoOld.getCveEstadoPlan().equals("S")) {
				throw new AladiException("PLAN_PAGOS_NO_ENCONTRADO",
						new Object[] { apertura.getNroReembLiteral(), planPago.getFechaVal(), planPago.getMonto() });
			}
			planPagoOld.setCveEstadoPlan(cveEstadoPlan);
			planPagoOld = planPagoLocal.makePersistent(planPagoOld);
			planPagoLocal.flush();
			return planPagoOld;
		}

		return planPago;
	}

	
	public void eliminar(Apertura apertura) {
		List<PlanPago> planPagosList = planPagoLocal.findPlanPagos(apertura.getNroMov(), null, null);
		// se elimina todo el plan de pagos existente
		for (PlanPago pPago : planPagosList) {
			if (pPago.getFechoraRegaladi() != null) {
				throw new AladiException("REEMBOLSO_INEXISTENTE", new Object[] { apertura.getNroReembLiteral(), pPago.getFechaVal(), pPago.getMonto() });
			}
			planPagoLocal.makeTransient(pPago);
		}
		planPagoLocal.flush();
	}

	
	public boolean isValidData(PlanPago planPago, Apertura apertura) {
		boolean result = false;

		if (!apertura.getCveEstadoApe().equalsIgnoreCase("V")) {
			throw new AladiException("INVALIDO_PARA_MODIFICACION", new Object[] { apertura.getNroReembLiteral(), apertura.getCveEstadoApe() });
		}

		if (!apertura.getCveEstadoApe().equals("V")) {
			throw new AladiException("REEMBOLSO_INEXISTENTE", new Object[] { apertura.getNroReembLiteral() });
		}

		if (planPago.getFechaVal() == null) {
			throw new AladiException("OBJETO_NULO", new Object[] { "Fecha Pago con valor nulo" });
		}

		if (planPago.getFechaNeg() == null) {
			throw new AladiException("OBJETO_NULO", new Object[] { "Fecha negociaci n con valor nulo" });
		}

		if (planPago.getCveEstadoPlan() == null) {
			throw new AladiException("OBJETO_NULO", new Object[] { "Valor de estado plan nulo" });
		}

		if (planPago.getCapital().compareTo(BigDecimal.ZERO) == 0 && planPago.getInteres().compareTo(BigDecimal.ZERO) != 0) {
			// si se registra interes este esta casado con el capital
			throw new AladiException("MONTOS_PLAN_PAGOS_INVALIDOS", new Object[] { UtilsDate.stringFromDate(planPago.getFechaVal(), Constants.FORMAT_DATE_DB) });
		}
		if ((!planPago.getCveEstadoPlan().equalsIgnoreCase("C") && !planPago.getCveEstadoPlan().equalsIgnoreCase("P"))
				&& !planPago.getCveEstadoPlan().equalsIgnoreCase("E") && !planPago.getCveEstadoPlan().equalsIgnoreCase("N")
				&& !planPago.getCveEstadoPlan().equalsIgnoreCase("S")) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Valor de estado " + planPago.getCveEstadoPlan() + " invalido " });
		}

		if (planPago.getCapital().compareTo(BigDecimal.ZERO) == 0 && planPago.getInteres().compareTo(BigDecimal.ZERO) == 0) {
			throw new AladiException("MONTOS_PLAN_PAGOS_INVALIDOS", new Object[] { UtilsDate.stringFromDate(planPago.getFechaVal(), Constants.FORMAT_DATE_DB) });
		}

		Date fechaVal = planPago.getFechaVal();

		if (!apertura.getCveTipoApe().trim().equals("I")) {
			// solo se valida para exportaciones
			if (fechaVal.before(apertura.getFechaEmis()) || fechaVal.after(apertura.getFechaVtoPag())) {
				throw new AladiException("FECHAPPAGOS_FUERA_DE_RANGO", new Object[] {
						UtilsDate.stringFromDate(planPago.getFechaVal(), Constants.FORMAT_DATE_DB),
						UtilsDate.stringFromDate(apertura.getFechaEmis(), Constants.FORMAT_DATE_DB),
						UtilsDate.stringFromDate(apertura.getFechaVtoPag(), Constants.FORMAT_DATE_DB) });
			}

			if (planPago.getFechaNeg().before(apertura.getFechaEmis()) || planPago.getFechaNeg().after(apertura.getFechaVtoPag())) {
				throw new AladiException("FECHAPPAGOS_FUERA_DE_RANGO", new Object[] {
						UtilsDate.stringFromDate(planPago.getFechaNeg(), Constants.FORMAT_DATE_DB),
						UtilsDate.stringFromDate(apertura.getFechaEmis(), Constants.FORMAT_DATE_DB),
						UtilsDate.stringFromDate(apertura.getFechaVtoPag(), Constants.FORMAT_DATE_DB) });
			}
		}
		result = true;
		return result;
	}

	/**
	 * @return the planPagoLocal
	 */
	
	public PlanPagoLocal getPlanPagoLocal() {
		return planPagoLocal;
	}

	
	public PlanPago crearPrimerPlan(Apertura apertura, Registro registro) {
		// Plan de Pago
		PlanPagoPK pk = new PlanPagoPK();
		pk.setNroPlan(1);
		pk.setNroMov(apertura.getNroMov());

		PlanPago primerPlanPago = new PlanPago();
		primerPlanPago.setId(pk);
		primerPlanPago.setInteres(BigDecimal.ZERO);
		primerPlanPago.setCapital(registro.getDebeMo());
		primerPlanPago.setMonto(registro.getDebeMo());
		primerPlanPago.setFechaNeg(apertura.getFechaEmis());
		primerPlanPago.setFechaVal(apertura.getFechaVtoPag());
		primerPlanPago.setNroSecReemb(Integer.valueOf(0));
		primerPlanPago.setCveEstadoPlan("P");
		primerPlanPago = planPagoLocal.makePersistent(primerPlanPago);
		planPagoLocal.flush();

		return primerPlanPago;
	}

	
	public Map<String, Object> getWarnnings() {
		return warnnings;
	}

	
	public void registroWSPorExport(PlanPago planPago, Apertura apertura, String tipoOperacionAladi) {
		// registro de negociaciones o a WS aladi
		RegistroLocal registroLocal = new RegistroBean();
		registroLocal.setEntityManager(getEntityManager());

		List<Registro> registroList = registroLocal.getRegistroByTipoEmis(apertura.getNroMov(), "E");
		if (registroList.size() == 0) {
			throw new AladiException("NO_EXISTE_EMIS", new Object[] { apertura.getNroReembLiteral() });
		}
		Registro registro = registroList.get(0);

		if (apertura.getCveTipoApe().trim().equals("I")) {
			String obs = null;
			BigDecimal monto = BigDecimal.ZERO;
			Date fecEmisONego = planPago.getFechaNeg();
			Date fecVencOPago = planPago.getFechaVal();
			if (planPago.getCapital().compareTo(BigDecimal.ZERO) > 0) {
				monto = planPago.getCapital();
			} else if (planPago.getInteres().compareTo(BigDecimal.ZERO) > 0) {
				monto = planPago.getInteres();
			}

			if ((planPago.getCveEstadoPlan().equals("P") || planPago.getCveEstadoPlan().equals("N")) && tipoOperacionAladi.equals("N")) {

			} else if ((planPago.getCveEstadoPlan().equals("P") || planPago.getCveEstadoPlan().equals("N")) && tipoOperacionAladi.equals("X")) {
				obs = "N";
			} else if ((planPago.getCveEstadoPlan().equals("S")) && tipoOperacionAladi.equals("X")) {
				obs = "N";
				monto = null;
				fecEmisONego = null;
				fecVencOPago = null;
			}

			String instr = registro.getInstrumento().getCodInstrumento().trim();
			if (planPago.getInteres().compareTo(BigDecimal.ZERO) > 0) {
				instr += "I";
				Instrumento instrumento = getEntityManager().find(Instrumento.class, instr);
				if (instrumento == null) {
					throw new AladiException("INSTRUMENTO_NO_ENCONTRADO", new Object[] { instr });
				}
			}
			RespWSAladi respWSAladi = ClientAladiWSHandler.execWSSicomrima(apertura, apertura.getPais().getCodPais(), instr, tipoOperacionAladi, registro
					.getInstitucion().getCodInst(), fecEmisONego, fecVencOPago, monto, obs, planPago.getNroSecReemb());
			// se registra en plan la hora aladi
			planPago.setFechoraRegaladi(respWSAladi.getFechaHoraReg());
		} else if (apertura.getCveTipoApe().equalsIgnoreCase("E")) {
			String obs = null;

			Date fecEmisONego = planPago.getFechaNeg();
			Date fecVencOPago = planPago.getFechaVal();
			BigDecimal capital = planPago.getCapital();
			BigDecimal interes = planPago.getInteres();

			// registro de emisiones por exportacion, modificaciones de emision
			// o anulacion
			if ((planPago.getCveEstadoPlan().equals("P") || planPago.getCveEstadoPlan().equals("N")) && tipoOperacionAladi.equals("N")) {

			} else if ((planPago.getCveEstadoPlan().equals("P") || planPago.getCveEstadoPlan().equals("N")) && tipoOperacionAladi.equals("X")) {
				obs = "N";
			} else if ((planPago.getCveEstadoPlan().equals("S")) && tipoOperacionAladi.equals("X")) {
				obs = "N";
				capital = null;
				interes = null;
				fecEmisONego = null;
				fecVencOPago = null;
			}

			Institucion institucion = getEntityManager().find(Institucion.class, apertura.getInstitucion().getCodInst());

			String instr = registro.getInstrumento().getCodInstrumento().trim();
			String instrInteres = instr.concat("I");

			// VErificamos que el instrumeto exista
			Instrumento instrumento = getEntityManager().find(Instrumento.class, instrInteres);
			if (instrumento == null) {
				throw new AladiException("INSTRUMENTO_NO_ENCONTRADO", new Object[] { instrInteres });
			}
			log.info("Enviando datos para capital " + apertura.getNroReembLiteral() + " plan nro " + planPago.getId().getNroPlan());

			RespWSAladi respWSAladi = ClientAladiWSHandler.execWSSicofrdcma(apertura, institucion.getPais().getCodPais(), instr, tipoOperacionAladi, registro
					.getInstitucion().getCodInst(), fecEmisONego, fecVencOPago, capital, obs, planPago.getNroSecReemb());

			planPago.setFechoraRegaladi(respWSAladi.getFechaHoraReg());

			// se envia otra negociaci n si el interes es mayor a cero
			if (planPago.getInteres().compareTo(BigDecimal.ZERO) != 0) {
				// si el interes es mayor a cero
				try {
					log.info("Enviando datos para interes " + apertura.getNroReembLiteral() + " plan nro " + planPago.getId().getNroPlan());
					respWSAladi = ClientAladiWSHandler.execWSSicofrdcma(apertura, institucion.getPais().getCodPais(), instrInteres, tipoOperacionAladi,
							registro.getInstitucion().getCodInst(), fecEmisONego, fecVencOPago, interes, obs, planPago.getNroSecReemb());
				} catch (AladiException e) {
					warnnings.put("AVISO_INTERES_NO_REGISTRADO", AladiException.getDescription("AVISO_INTERES_NO_REGISTRADO", new Object[] { e.getMessage() }));

				}
			}

			// se registra en plan la hora aladi
			planPago.setFechoraRegaladi(respWSAladi.getFechaHoraReg());
		}
	}
}
