package gob.bcb.bpm.siraladi.logic;

import java.math.BigDecimal;

import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import javax.persistence.EntityManager;
import gob.bcb.bpm.siraladi.dao.EntityUserTransaction;
import gob.bcb.bpm.siraladi.dao.EstadoMovBean;
import gob.bcb.bpm.siraladi.dao.EstadoMovLocal;
import gob.bcb.bpm.siraladi.dao.PagoBean;
import gob.bcb.bpm.siraladi.dao.PagoLocal;
import gob.bcb.bpm.siraladi.dao.PerTipoCuentaBean;
import gob.bcb.bpm.siraladi.dao.PerTipoCuentaLocal;
import gob.bcb.bpm.siraladi.dao.PersonaInstBean;
import gob.bcb.bpm.siraladi.dao.PersonaInstLocal;
import gob.bcb.bpm.siraladi.dao.RegistroBean;
import gob.bcb.bpm.siraladi.dao.RegistroLocal;
import gob.bcb.bpm.siraladi.dao.qnative.QCoinCommos;
import gob.bcb.bpm.siraladi.exceptions.AladiException;
import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.EstadoMov;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Instrumento;
import gob.bcb.bpm.siraladi.jpa.Movimiento;
import gob.bcb.bpm.siraladi.jpa.PerTipoCuenta;
import gob.bcb.bpm.siraladi.jpa.PersonaInst;
import gob.bcb.bpm.siraladi.jpa.Registro;
import gob.bcb.bpm.siraladi.msgmail.MsgLogic;
import gob.bcb.bpm.siraladi.utils.UtilsDate;
import gob.bcb.bpm.siraladi.utils.Constants;
import gob.bcb.bpm.siraladi.ws.clientaladi.ClientAladiWSHandler;
import gob.bcb.bpm.siraladi.ws.clientaladi.RespWSAladi;

/**
 * @author wilherrera Wilbert Herrera Flores Banco Central de Bolivia
 *         Departamento de Desarrollo
 */

public class RegistroServiceBean extends EntityUserTransaction implements RegistroServiceLocal {
	private static Logger log = Logger.getLogger(RegistroServiceBean.class);
	private RegistroLocal registroLocal;

	private Map<String, Object> warnnings = new HashMap<String, Object>();

	public RegistroServiceBean(EntityManager em) {
		super(em);
		registroLocal = new RegistroBean();
		registroLocal.setEntityManager(em);
	}

	
	public Registro crearReg(Registro registro, Apertura apertura) {
		if (registro == null) {
			throw new AladiException("OBJETO_NULO", new Object[] { "registro" });
		}

		List<Registro> registroList = registroLocal.getByNroMovApeCveEstadoReg(apertura.getNroMov(), "P");
		for (Registro registro2 : registroList) {
			if (registro.getNroMov() != null && registro2.getNroMov().compareTo(registro.getNroMov()) != 0)
				throw new AladiException("ENMIENDAS_PENDIENTES", new Object[] { apertura.getNroReembLiteral() });

			if (registro.getNroMov() == null) {
				throw new AladiException("ENMIENDAS_PENDIENTES", new Object[] { apertura.getNroReembLiteral() });
			}
		}

		AperturaServiceLocal aperturaService = new AperturaServiceBean(getEntityManager());
		// si es emision no se recupera nit, si no de persona coin
		String nit = aperturaService.obtenerNIT(apertura, registro.getNit(), registro.getInstitucion().getCodInst(),
				(registro.getCveTipoEmis().trim()));
		registro.setNit(nit);

		registro.setCveEstadoReg("P");
		if (!isValidData(registro, apertura)) {
			throw new AladiException("El registro tiene errores de validacion");
		}
		// agregar nro sec reemb
		MovimientoServiceLocal movimientoService = new MovimientoServiceBean(getEntityManager());
		Movimiento movimiento = movimientoService.crearMovimiento("R", apertura.getCodMoneda(), new Date(), apertura.getNroMov());
		Integer nroMov = movimiento.getNroMov();

		if (nroMov == null || nroMov <= 0) {
			throw new AladiException("ERROR_GENERANDO_NRO_MOV", new Object[] { apertura.getNroReembLiteral() });
		}
		// el nrosecreemb siempre es cero
		// si tiene el instrumento emision el reemb es cero
		// si no tiene emsion solo tiene una negociacion reemb es cero
		log.info("registro monto ====== " + registro.getDebeMo() + " :: " + registro.getHaberMo());
		registro.setNroSecReemb(Integer.valueOf(0));
		registro.setNroMov(nroMov);
		registro.setNroMovApe(apertura.getNroMov());
		registro = registroLocal.makePersistent(registro);
		// validar datos contables
		registroLocal.flush();
		OpersContaServiceLocal opersContaService = new OpersContaServiceBean();
		opersContaService.setEntityManager(getEntityManager());
		// opersContaService.contabilizaRegistro(registro, 0);
		String codCalif = aperturaService.validarCalifRiesgo(apertura, new Date());

		apertura.setCodCalif(codCalif);
		apertura = aperturaService.getAperturaLocal().makePersistent(apertura);
		aperturaService.getAperturaLocal().flush();
		return registro;
	}

	
	public boolean isValidData(Registro registro, Apertura apertura) {

		if (!apertura.getCveEstadoApe().trim().equals("V")) {
			throw new AladiException("INVALIDO_PARA_MODIFICACION", new Object[] { apertura.getNroReembLiteral(), apertura.getCveEstadoApe() });
		}

		if (registro.getCveTipoEmis() == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Tipo operacion nulo" });
		}

		if (!registro.getCveTipoEmis().equals("E") && !registro.getCveTipoEmis().equals("I") && !registro.getCveTipoEmis().equals("D")) {
			throw new AladiException("TIPO_OPERACION_INCORRECTO", new Object[] { registro.getCveTipoEmis(), apertura.getNroReembLiteral() });
		}
		Integer nroMovApe = apertura.getNroMov();

		// whf validar valores de campos pertenecientes a claves

		if (registro.getInstitucion() == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Valor de Institucion nulo" });
		}

		if (registro.getInstrumento() == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Valor de Instrumento nulo" });
		}

		if (registro.getFechaTrans() == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Fecha transaccion invalida" });
		}

		if (registro.getDebeMo() == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Monto del DEBE invalido o NULO" });
		}

		if (registro.getHaberMo() == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Monto del HABER invalido o NULO" });
		}

		// control de la existencia de una emision en el conjunto de registros
		List<Registro> registroList = registroLocal.getByNroMovApeCveEstadoReg(apertura.getNroMov(), null);
		if (registroList.size() == 0) {
			if (!registro.getCveTipoEmis().trim().equals("E")) {
				throw new AladiException("OPERACION_NO_ES_EMISION", new Object[] { apertura.getNroReembLiteral() });
			}
		} else {
			registroList = registroLocal.getRegistroByTipoEmis(apertura.getNroMov(), "E");
			if (registroList.size() == 0) {
				throw new AladiException("NO_EXISTE_EMIS", new Object[] { apertura.getNroReembLiteral() });
			}

			if (registroList.size() > 1) {
				throw new AladiException("NRO_EMIS_MAYOR_1", new Object[] { apertura.getNroReembLiteral() });
			}

			if (!registroList.get(0).getInstrumento().getCodInstrumento().trim()
					.equalsIgnoreCase(registro.getInstrumento().getCodInstrumento().trim())) {
				// 2011-08 el instrumento no cambia ya que es parte del cod
				// reembolso y es el mismo
				// de la emision se emite un warnning
				warnnings.put(
						"AVISO_DIFERENCIA_INSTRUMENTOS",
						AladiException.getDescription("AVISO_DIFERENCIA_INSTRUMENTOS", new Object[] { apertura.getNroReembLiteral(),
								registroList.get(0).getInstrumento().getCodInstrumento(), registro.getInstrumento().getCodInstrumento() }));
			}
		}

		BigDecimal montoRegistro = null;

		if (registro.getNroMov() != null && registro.getNroMov() > 0) {
			montoRegistro = registroLocal.getMontoSinNroMov(nroMovApe, registro.getNroMov());
		} else {
			montoRegistro = registroLocal.getSaldoRegistro(nroMovApe);
			montoRegistro = (montoRegistro == null ? BigDecimal.ZERO : montoRegistro);
		}
		PagoLocal pagoLocal = new PagoBean();
		pagoLocal.setEntityManager(getEntityManager());

		BigDecimal montoPago = pagoLocal.getMontoPago(nroMovApe);

		BigDecimal sumReg = BigDecimal.ZERO;
		sumReg = montoRegistro.add(registro.getDebeMo().subtract(registro.getHaberMo()));
		sumReg = sumReg.setScale(2, BigDecimal.ROUND_HALF_UP);
		if (sumReg.compareTo(BigDecimal.ZERO) < 0) {
			throw new AladiException("SUMA_EMISIONES_NEGATIVO", new Object[] { sumReg.toPlainString(), apertura.getNroReembLiteral() });
		}
		montoPago = montoPago.setScale(2, BigDecimal.ROUND_HALF_UP);
		if (montoPago.compareTo(sumReg) > 0) {
			throw new AladiException("EMISIONES_MENOR_A_DEBREEM", new Object[] { sumReg.toPlainString(), montoPago.toPlainString() });
		}
		/*
		 * if (registro.getFechaTrans().before(apertura.getFechaEmis()) ||
		 * registro.getFechaTrans().after(apertura.getFechaVtoPag())) { throw
		 * new AladiException("FECHA_FUERA_DE_RANGO", new Object[] {
		 * UtilsDate.stringFromDate(apertura.getFechaEmis(),
		 * Constants.FORMAT_DATE_DB),
		 * UtilsDate.stringFromDate(apertura.getFechaVtoPag(),
		 * Constants.FORMAT_DATE_DB) }); }
		 */
		PerTipoCuentaLocal perTipoCuentaLocal = new PerTipoCuentaBean();
		perTipoCuentaLocal.setEntityManager(getEntityManager());
		PerTipoCuenta perTipoCuenta = null;
		if (apertura.getCveTipoApe().equals("I")) {
			perTipoCuenta = perTipoCuentaLocal.getPerTipoCuenta(apertura.getCveTipoApe(), apertura.getInstitucion().getCodInst(), apertura
					.getIdentificador().getCodId(), apertura.getCodMoneda());
			if (perTipoCuenta == null) {
				throw new AladiException("CTA_NO_DEFINIDA_PARA_INSTIT", new Object[] { apertura.getInstitucion().getCodInst(),
						apertura.getIdentificador().getCodId(), apertura.getCodMoneda() });
			}
		} else if (apertura.getCveTipoApe().equals("E")) {
			perTipoCuenta = perTipoCuentaLocal.getPerTipoCuenta(apertura.getCveTipoApe(), registro.getInstitucion().getCodInst(), apertura
					.getIdentificador().getCodId(), apertura.getCodMoneda());
			if (perTipoCuenta == null) {
				// no se valida por las instituciones publicas
//				throw new AladiException("CTA_NO_DEFINIDA_PARA_INSTIT", new Object[] { registro.getInstitucion().getCodInst(),
//						apertura.getIdentificador().getCodId(), apertura.getCodMoneda() });
			}
		}

		return true;
	}

	
	public Registro modificar(Registro registro, Apertura apertura, String tipoOperacionAladi) {
		if (registro == null) {
			throw new AladiException("OBJETO_NULO", new Object[] { "registro" });
		}

		if (registro.getCveEstadoReg() == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Valor 'Estado' del registro con valor nulo" });
		}

		String cveEstadoReg = registro.getCveEstadoReg().trim();

		if (registro.getNroMov() == null || registro.getNroMov() <= 0) {
			throw new AladiException("CODIGO_NRO_MOV_NULO", new Object[] { "registro" });
		}

		log.info("iniciando modificacion registro " + registro.getNroMov());

		Registro registroOld = registroLocal.getByNroMov(registro.getNroMov());
		if (registroOld == null) {
			throw new AladiException("REGISTRO_INEXISTENTE", new Object[] { registro.getNroMov() });
		}

		List<Registro> registroList = registroLocal.getByNroMovApeCveEstadoReg(apertura.getNroMov(), "P");
		for (Registro registro2 : registroList) {
			// verificamos que no exista otros registros pendientes
			if (registro2.getNroMov().compareTo(registro.getNroMov()) != 0)
				throw new AladiException("ENMIENDAS_PENDIENTES", new Object[] { apertura.getNroReembLiteral() });
		}

		if (registroOld.getCveEstadoReg().trim().equals("C") || registroOld.getCveEstadoReg().trim().equals("R")) {
			throw new AladiException("REGNEG_NO_VALIDO_PARA_MODIF", new Object[] { registroOld.getNroMov().toString(), registroOld.getCveEstadoReg(),
					apertura.getNroReembLiteral() });
		}

		if (registroOld.getCveEstadoReg().trim().equals("P") && cveEstadoReg.equals("P")) {
			registroOld.setDebeMo(registro.getDebeMo());
			registroOld.setHaberMo(registro.getHaberMo());
			registroOld.setRegObs(registro.getRegObs());
			registroOld.setInstitucion(registro.getInstitucion());
			registroOld.setInstrumento(registro.getInstrumento());
			AperturaServiceLocal aperturaService = new AperturaServiceBean(getEntityManager());
			String nit = aperturaService.obtenerNIT(apertura, registro.getNit(), registroOld.getInstitucion().getCodInst(),
					(registroOld.getCveTipoEmis().trim()));
			registroOld.setNit(nit);
		}

		registroOld.setFechaTrans(new Date());
		isValidData(registroOld, apertura);
		OpersContaServiceLocal opersContaService = new OpersContaServiceBean();
		opersContaService.setEntityManager(getEntityManager());

		if ((registroOld.getCveEstadoReg().trim().equals("P") && cveEstadoReg.equals("C"))
				|| (registroOld.getCveEstadoReg().trim().equals("1") && cveEstadoReg.equals("C"))) {
			
			if (registroOld.getCveTipoEmis().trim().equals("E") && tipoOperacionAladi.equals("X")){
				throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Intenta AUTORIZAR UNA EMISION con la opci�n de AUTORIZAR ENMIENDA" });			
			}

			// si se pasa a un estado de contabilizacion
			// //////////////////////INICIO
			// CONTABILIZACION//////////////////////////////
			registroOld.setCveEstadoReg(cveEstadoReg);
			registroOld = registroLocal.makePersistent(registroOld);
			registroLocal.flush();
			registroWSPorImporExport(registroOld, apertura, tipoOperacionAladi);
			// actualizamos cambios realizados en envio de datos
			registroLocal.flush();

			Object[] parameters = new Object[] { "Reembolso: "
					+ apertura.getNroReembLiteral()
					+ "\nMonto: "
					+ registroOld.getDebeMo().add(registroOld.getHaberMo())
					+ (warnnings.size() > 0 ? "\n\nOBSERVACIONES ADICIONALES: "
							+ warnnings.values().toString() : "") };

			MsgLogic.envioMail(getEntityManager(), "REGISOPERACION", (apertura.getCveTipoApe().trim().equals("I") ? apertura.getInstitucion()
					.getCodInst() : registroOld.getInstitucion().getCodInst()), (tipoOperacionAladi.equals("E") ? "Emisi�n" : "Enmienda")
					+ " autorizada", false, parameters);
			return registroOld;
		} else {
			// validar datos contables
			registroOld.setCveEstadoReg(cveEstadoReg);
			registroOld = registroLocal.makePersistent(registroOld);
			registroLocal.flush();
		}

		return registroOld;
	}

	
	public void eliminar(Registro registro, Apertura apertura) {
		Movimiento movimiento = null;

		if (registro == null) {
			throw new AladiException("OBJETO_NULO", new Object[] { "registro" });
		}

		if (registro.getNroMov() == null || registro.getNroMov() <= 0) {
			throw new AladiException("CODIGO_NRO_MOV_NULO", new Object[] { "registro" });
		}

		Registro registroOld = registroLocal.getByNroMov(registro.getNroMov());

		if (registroOld == null) {
			throw new AladiException("REGISTRO_INEXISTENTE", new Object[] { registro.getNroMov() });
		}

		if (registroOld.getCveEstadoReg().equals("C")) {
			throw new AladiException("REGISTRO_INVALIDO_BAJA", new Object[] { registro.getNroMov() });
		}

		if (!registroOld.getNroMovApe().equals(apertura.getNroMov())) {
			throw new AladiException("REGISTRO_INEXISTENTE", new Object[] { registro.getNroMov() });
		}

		MovimientoServiceLocal movimientoService = new MovimientoServiceBean(getEntityManager());
		movimiento = movimientoService.getMovimientoLocal().getByNroMov(registro.getNroMov());

		if (movimiento.getFechoraRegaladi() != null) {
			throw new AladiException("REGISTRO_INVALIDO_BAJA", new Object[] { registro.getNroMov() });
		}
		EstadoMovLocal estadoMovLocal = new EstadoMovBean();
		estadoMovLocal.setEntityManager(getEntityManager());
		List<EstadoMov> estadoMovList = estadoMovLocal.getByNroMovEstado(registro.getNroMov(), null);

		if (estadoMovList.size() > 0) {
			throw new AladiException("REGISTRO_INVALIDO_BAJA", new Object[] { registro.getNroMov() });
		}
		// solo se elimina fisicamente si no se ha informado a aladi,
		// se aclara que en registro se registra la emision y sus modificaciones
		registroLocal.makeTransient(registroOld);
		movimientoService.getMovimientoLocal().makeTransient(movimiento);
	}

	
	public void registroWSPorImporExport(Registro registro, Apertura apertura, String tipoOperacionAladi) {
		String obs = null;
		MovimientoServiceLocal movimientoService = new MovimientoServiceBean(getEntityManager());
		Integer nroSecReemb = registro.getNroSecReemb();
		Date fecEmisONego = apertura.getFechaEmis();
		Date fecVencOPago = apertura.getFechaVtoPag();
		BigDecimal monto = registroLocal.getSaldoRegistro(apertura.getNroMov());
		if (registro.getCveEstadoReg().equalsIgnoreCase("C") && apertura.getCveTipoApe().trim().equals("I")) {
			// registro de emisiones por importacion
			// registro de emisiones por exportacion, modificaciones de emision
			// o anulacion

			if ((registro.getCveTipoEmis().equals("E") || registro.getCveTipoEmis().equals("I") || registro.getCveTipoEmis().equals("D"))
					&& tipoOperacionAladi.equals("E")) {
				if (!registro.getInstrumento().getCodInstrumento().trim().equals("CC")
						&& !registro.getInstrumento().getCodInstrumento().trim().equals("CD")
						&& !registro.getInstrumento().getCodInstrumento().trim().equals("OD")) {
					tipoOperacionAladi = "N";
				}
				nroSecReemb = 0;
			} else if ((registro.getCveTipoEmis().equals("E") || registro.getCveTipoEmis().equals("I") || registro.getCveTipoEmis().equals("D"))
					&& tipoOperacionAladi.equals("X")) {
				// se setea a 0 porque se debe modificar o anular la emision
				// y las emisiones o negociaciones que entran en este codio
				// siempres son con
				// nro sec rermbolso = 0
				nroSecReemb = 0;
				if (apertura.getCveEstadoApe().trim().equals("A")) {
					monto = null;
					fecEmisONego = null;
					fecVencOPago = null;
				}
				if (!registro.getInstrumento().getCodInstrumento().trim().equals("CC")
						&& !registro.getInstrumento().getCodInstrumento().trim().equals("CD")
						&& !registro.getInstrumento().getCodInstrumento().trim().equals("OD")) {
					log.info("Instrumento " + registro.getInstrumento().getCodInstrumento() + " no permite modificacion para "
							+ apertura.getNroReembLiteral());
					obs = "N";
				} else
					obs = "E";
			}
			RespWSAladi respWSAladi = ClientAladiWSHandler.execWSSicomrima(apertura, apertura.getPais().getCodPais(), registro.getInstrumento()
					.getCodInstrumento(), tipoOperacionAladi, registro.getInstitucion().getCodInst(), fecEmisONego, fecVencOPago, monto, obs,
					nroSecReemb);

			movimientoService.actualizarRegAladi(registro.getNroMov(), tipoOperacionAladi + ":Sicom:rima", respWSAladi.getFechaHoraReg());
			if (!tipoOperacionAladi.equals("X"))
				// marcamos solo en la emision del instrumento
				movimientoService.actualizarRegAladi(apertura.getNroMov(), tipoOperacionAladi + ":Sicom:rima", respWSAladi.getFechaHoraReg());
		} else if (registro.getCveEstadoReg().trim().equals("C") && apertura.getCveTipoApe().trim().equals("E")) {
			// registro de emisiones por exportacion, modificaciones de emision
			// o anulacion
			if ((registro.getCveTipoEmis().equals("E") || registro.getCveTipoEmis().equals("I") || registro.getCveTipoEmis().equals("D"))
					&& tipoOperacionAladi.equals("E")) {
				if (!registro.getInstrumento().getCodInstrumento().trim().equals("CC")
						&& !registro.getInstrumento().getCodInstrumento().trim().equals("CD")
						&& !registro.getInstrumento().getCodInstrumento().trim().equals("OD")) {
					tipoOperacionAladi = "N";
				}
				nroSecReemb = 0;
			} else if ((registro.getCveTipoEmis().equals("E") || registro.getCveTipoEmis().equals("I") || registro.getCveTipoEmis().equals("D"))
					&& tipoOperacionAladi.equals("X")) {
				// se setea a 0 porque se debe modificar o anular la emision y
				// las emisiones o negociaciones que entran en este codio
				// siempres son con
				// nro sec rermbolso = 0
				nroSecReemb = 0;
				if (apertura.getCveEstadoApe().trim().equals("A")) {
					monto = null;
					fecEmisONego = null;
					fecVencOPago = null;
				}

				// solo instrumentos CC CD y Od permiten Emisiones otros viajan
				// como negociacion
				if (!registro.getInstrumento().getCodInstrumento().trim().equals("CC")
						&& !registro.getInstrumento().getCodInstrumento().trim().equals("CD")
						&& !registro.getInstrumento().getCodInstrumento().trim().equals("OD")) {
					// instrumentos diferentes no emiten, pero los registros de
					// dichos instrumentos registrados en registro van como
					// negociacion
					obs = "N";
				} else
					obs = "E";
			}

			Institucion institucion = getEntityManager().find(Institucion.class, apertura.getInstitucion().getCodInst());
			RespWSAladi respWSAladi = ClientAladiWSHandler.execWSSicofrdcma(apertura, institucion.getPais().getCodPais(), registro.getInstrumento()
					.getCodInstrumento(), tipoOperacionAladi, registro.getInstitucion().getCodInst(), fecEmisONego, fecVencOPago, monto, obs,
					nroSecReemb);

			movimientoService.actualizarRegAladi(registro.getNroMov(), tipoOperacionAladi + ":Sicof:rdcma", respWSAladi.getFechaHoraReg());
			if (!tipoOperacionAladi.equals("X"))
				// marcamos solo en la emision del instrumento
				movimientoService.actualizarRegAladi(apertura.getNroMov(), tipoOperacionAladi + ":Sicof:rdcma", respWSAladi.getFechaHoraReg());
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gob.bcb.bpm.siraladi.logic.RegistroServiceLocal#registroDeAnulacion(gob
	 * .bcb.bpm.siraladi.jpa.Apertura)
	 */
	
	public Registro registroDeAnulacion(Apertura apertura) {
		Registro registro = null;

		OpersContaServiceLocal opersContaService = new OpersContaServiceBean();
		opersContaService.setEntityManager(getEntityManager());

		AperturaServiceLocal aperturaService = new AperturaServiceBean(getEntityManager());
		BigDecimal saldo = aperturaService.getAperturaLocal().getSaldo(apertura.getNroMov());
		if ((saldo != null) && (saldo.compareTo(BigDecimal.ZERO) > 0)) {
			List<Registro> registroList = registroLocal.getRegistroByTipoEmis(apertura.getNroMov(), "E");

			if (registroList.size() == 0) {
				throw new AladiException("INVALIDO_PARA_ANULACION", new Object[] { apertura.getNroReembLiteral(),
						"instrumento sin registro de emisi�n" });
			}

			if (!registroList.get(0).getCveEstadoReg().trim().equals("C")) {
				throw new AladiException("INVALIDO_PARA_ANULACION", new Object[] { apertura.getNroReembLiteral(),
						"el estado de la emisi�n debe ser autorizado" });
			}

			Calendar calendar = Calendar.getInstance();
			calendar.setTime(new Date());
			registro = new Registro();
			registro.setInstrumento(new Instrumento());
			registro.setInstitucion(new Institucion());
			registro.setFechaTrans(calendar.getTime());

			registro.setNroMovApe(apertura.getNroMov());
			registro.getInstrumento().setCodInstrumento(registroList.get(0).getInstrumento().getCodInstrumento());
			registro.setCveTipoEmis("D");
			registro.getInstitucion().setCodInst(registroList.get(0).getInstitucion().getCodInst());
			registro.setDebeMo(BigDecimal.ZERO);
			registro.setHaberMo(saldo);

			try {
				registro.setNit(registroList.get(0).getNit());
			} catch (Exception e) {
			}

			String nit = aperturaService.obtenerNIT(apertura, registro.getNit(), registro.getInstitucion().getCodInst(),
					(registro.getCveTipoEmis().trim()));
			registro.setNit(nit);
			registro.setCveEstadoReg("P");
			MovimientoServiceLocal movimientoService = new MovimientoServiceBean(getEntityManager());

			Movimiento movimiento = movimientoService.crearMovimiento("R", apertura.getCodMoneda(), new Date(), apertura.getNroMov());
			Integer nroMov = movimiento.getNroMov();
			if (nroMov == null || nroMov <= 0) {
				throw new AladiException("ERROR_GENERANDO_NRO_MOV", new Object[] { apertura.getNroReembLiteral() });
			}
			// el secreemb es cero ya que se anula la emision si permite el
			// instrumento de lo contrario igualmente
			registro.setNroSecReemb(Integer.valueOf(0));
			registro.setNroMov(nroMov);
			registro = registroLocal.makePersistent(registro);

			registroLocal.flush();
			registro.setCveEstadoReg("C");
			registro = registroLocal.makePersistent(registro);
			registroLocal.flush();

			// si se pasa a un estado de contabilizacion
			if (!opersContaService.getDiaHabil(registro.getFechaTrans())) {
				throw new AladiException("FECHA_NO_HABILITADA", new Object[] { UtilsDate.stringFromDate(registro.getFechaTrans(),
						Constants.FORMAT_DATE_DB) });
			}

			// //////////////////////INICIO
			// CONTABILIZACION//////////////////////////////
			registroLocal.flush();
			// opersContaService.contabilizaRegistro(registro, 1);
			// ////////////////////////////////////////////////////
		} else {
			// throw new AladiException("SALDO_NO_VALIDO_PARA_ANULACION", new
			// Object[] { saldo.toPlainString(), apertura.getNroReembLiteral()
			// });
			List<Registro> registroList = registroLocal.getRegistroByTipoEmis(apertura.getNroMov(), "E");
			if (registroList.size() == 0) {
				throw new AladiException("REEMBOLSO_SIN_REG_EMISION", new Object[] { apertura.getNroReembLiteral() });
			}

			if (!registroList.get(0).getCveEstadoReg().trim().equals("C")) {
				throw new AladiException("INVALIDO_PARA_ANULACION", new Object[] { apertura.getNroReembLiteral(),
						"el estado de la emisi�n debe ser autorizado" });
			}

			if ((saldo == null) || (saldo.compareTo(BigDecimal.ZERO) == 0)) {
				throw new AladiException("INVALIDO_PARA_ANULACION", new Object[] { apertura.getNroReembLiteral(),
						"saldo del instrumento CERO revise los datos" });
			}
			registro = registroList.get(0);
		}
		return registro;
	}

	
	public RegistroLocal getRegistroLocal() {
		return registroLocal;
	}

	
	public Map<String, Object> getWarnnings() {
		return warnnings;
	}

	public static void main(String[] args) {
		Map<String, Object> m = new HashMap<String, Object>();
		Map<String, Object> m1 = new HashMap<String, Object>();
		Map<String, Object> m2 = new HashMap<String, Object>();
		m.put("a", "asdf");
		m.put("b", 1);
		m1.putAll(m);
		System.out.println(m1.values().toString());
		System.out.println(m2.size() > 0 ? m2.values().toString() : "");

	}
}
