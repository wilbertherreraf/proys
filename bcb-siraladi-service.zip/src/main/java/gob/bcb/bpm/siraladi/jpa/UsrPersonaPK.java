package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * The primary key class for the usr_persona database table.
 * 
 */

@Embeddable
public class UsrPersonaPK implements Serializable {
	//default serial version id, required for serializable classes.

	//@GeneratedValue
	private static final long serialVersionUID = 1L;
	//@Id
	@Column(name="cod_usuario", unique=true, nullable=false)
	private String codUsuario;

	@Column(name="cod_persona", unique=true, nullable=false)
	private String codPersona;

    public UsrPersonaPK() {
    }
	public String getCodUsuario() {
		return this.codUsuario;
	}
	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}
	public String getCodPersona() {
		return this.codPersona;
	}
	public void setCodPersona(String codPersona) {
		this.codPersona = codPersona;
	}

	
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof UsrPersonaPK)) {
			return false;
		}
		UsrPersonaPK castOther = (UsrPersonaPK)other;
		return 
			this.codUsuario.equals(castOther.codUsuario)
			&& this.codPersona.equals(castOther.codPersona);

    }
    
	
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.codUsuario.hashCode();
		hash = hash * prime + this.codPersona.hashCode();
		
		return hash;
    }
}
