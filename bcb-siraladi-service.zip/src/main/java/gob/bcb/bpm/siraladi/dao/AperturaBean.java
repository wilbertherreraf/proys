package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.exceptions.AladiException;
import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.Persona;
import gob.bcb.bpm.siraladi.jpa.PersonaInst;
import gob.bcb.bpm.siraladi.jpa.Registro;
import gob.bcb.bpm.siraladi.service.session.UserSessionHolder;
import gob.bcb.bpm.siraladi.utils.Constants;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author wilherrera
 * 
 */
@Repository("aperturaLocal")
@Transactional
public class AperturaBean extends GenericDAO<Integer, Apertura> implements AperturaLocal {

	public List<Apertura> getAperturas() {
		Query query = getEntityManager().createNamedQuery("Apertura.findAll");
		return query.getResultList();
	}

	public Apertura findByCodReembolso(String codInst, String codId, String anio, String secuencia, Integer dav) {
		return findByCodReembolso(codInst, codId, anio, secuencia, dav, true);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.bpm.siraladi.dao.AperturaLocal#findByCodReembolso(java.lang.String , java.lang.String, java.lang.String,
	 * java.lang.String, int, boolean)
	 */
	private final static String FIND_BY_COD_REEMBOLSO = "SELECT a FROM Apertura a where a.institucion.codInst = :codInst " +
			"AND a.identificador.codId = :codId " + "AND a.anio = :anio "
	+ "AND a.secuencia = :secuencia ";
	
	public Apertura findByCodReembolso(String codInst, String codId, String anio, String secuencia, Integer dav, boolean control) {
		Apertura apertura = null;
		Query query = getEntityManager().createQuery(FIND_BY_COD_REEMBOLSO);
		query.setParameter("codInst", codInst.trim());
		query.setParameter("codId", codId.trim());
		query.setParameter("anio", anio.trim());
		query.setParameter("secuencia", secuencia.trim());

		List result = query.getResultList();
		if (result.size() > 0)
			apertura = (Apertura) result.get(0);

		if (control) {
			controlUsuarioOperacion(apertura);
		}
		return apertura;

	}

	
	public void controlUsuarioOperacion(Apertura apertura) {
		if ((apertura != null) && !UserSessionHolder.get("codIFARequest").toString().trim().equals("900")) {
			if (UserSessionHolder.get("personaRevisada") == null) {
				// si el usuario lokeado es externo
				// se verifica que la oepracion sea de la institucion
				PersonaInstLocal personaInstLocal = new PersonaInstBean();
				personaInstLocal.setEntityManager(getEntityManager());
				UserSessionHolder.set("personaRevisada", UserSessionHolder.get("codIFARequest"));

				if (apertura.getCveTipoApe().equals("I")) {
					PersonaInst personaInst = personaInstLocal.findByCodInst(apertura.getInstitucion().getCodInst());
					if (personaInst != null) {
						UserSessionHolder.set("personaRevisada", personaInst.getId().getCodPersona());
					}
				} else {
					RegistroBean registroBean = new RegistroBean();
					registroBean.setEntityManager(getEntityManager());
					List<Registro> registroList = registroBean.getRegistroByTipoEmis(apertura.getNroMov(), "E");
					if (registroList.size() > 0) {
						Registro registro = registroList.get(0);
						PersonaInst personaInst = personaInstLocal.findByCodInst(registro.getInstitucion().getCodInst());
						if (personaInst != null) {
							UserSessionHolder.set("personaRevisada", personaInst.getId().getCodPersona());
						}
					}
				}
			}

			// controlar que la institucion de la operacion sea una institucion
			// a la cual pertenece el usuario lokeado

			if (!((String) UserSessionHolder.get("personaRevisada")).trim().equals(((String) UserSessionHolder.get("codIFARequest")).trim())) {
				throw new AladiException("OPERACION_NO_CORRESPONDE_A_USUARIO", new Object[] { apertura.getNroReembLiteral(),
						UserSessionHolder.get("personaRevisada"), UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID),
						UserSessionHolder.get("codIFARequest") });
			}
		}
	}

	
	public BigDecimal getSaldo(Integer nroMov) {
		RegistroLocal registroLocal = new RegistroBean();
		registroLocal.setEntityManager(getEntityManager());

		BigDecimal saldo = new BigDecimal(0);
		BigDecimal saldoR = registroLocal.getSaldoRegistro(nroMov);

		PagoLocal pagoLocal = new PagoBean();
		pagoLocal.setEntityManager(getEntityManager());

		BigDecimal saldoP = pagoLocal.getSaldoPago(nroMov);
		// se suma ya que la diferencia entre p.debeMo - p.haberMo de pago es
		// negativo
		saldo = saldoR.add(saldoP);
		return saldo;
	}

	
	public Apertura findByNroMovCveEstado(Integer nroMov, String cveEstadoApe) {
		Apertura apertura = null;
		String jpql = "SELECT a FROM Apertura a " + "where a.nroMov = :nroMov ";

		if (cveEstadoApe != null) {
			jpql += "and a.cveEstadoApe = :cveEstadoApe ";
		}
		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("nroMov", nroMov);

		if (cveEstadoApe != null) {
			query.setParameter("cveEstadoApe", cveEstadoApe);
		}

		List result = query.getResultList();
		if (result.size() > 0)
			apertura = (Apertura) result.get(0);

		return apertura;

	}

	public String selectAperturas(String tipoApertura, String estadoApertura, String codPersona, String tipoReg, String estadoRegistro,
			String codConvenio) {
		StringBuffer query = new StringBuffer("SELECT a FROM Apertura a ");
		codPersona = codPersona.trim();
		boolean insWhere = true;
		if (tipoApertura != null && !tipoApertura.trim().isEmpty()) {
			insWhere = false;
			query.append("WHERE a.cveTipoApe = '").append(tipoApertura).append("' ");

			if (estadoApertura != null && !estadoApertura.trim().isEmpty())
				query.append("AND a.cveEstadoApe in ('").append(estadoApertura).append("') ");

			if (tipoApertura.equals("I")) {
				if (!codPersona.equals(Constants.CODIGO_PERSONA_BCB)) {
					query.append("AND exists (select 1 from PersonaInst pi WHERE pi.id.codInst = a.institucion.codInst ");
					query.append("AND pi.id.codPersona = '").append(codPersona).append("') "); // select
																								// 1
				}
				if (codConvenio != null && !codConvenio.trim().isEmpty()) {
					// selecciona el pais convenio
					query.append("AND a.pais.codPais = '").append(codConvenio).append("' ");
				}
			} else if (tipoApertura.equals("E")) {
				if (!codPersona.equals(Constants.CODIGO_PERSONA_BCB)) {
					query.append("AND exists (select 1 from PersonaInst pi, Registro r ");
					query.append("WHERE pi.id.codInst = r.institucion.codInst ");
					query.append("AND r.nroMovApe = a.nroMov AND r.cveTipoEmis = 'E' ");
					query.append("AND pi.id.codPersona = '").append(codPersona).append("') "); // select
																								// 1
				}
				if (codConvenio != null && !codConvenio.trim().isEmpty()) {
					// selecciona el pais convenio
					query.append("AND exists (select 1 from Institucion i "); // select1
																				// pais
					query.append("where i.codInst = a.institucion.codInst ");
					query.append("and i.pais.codPais = '").append(codConvenio).append("') ");
				}
			}
		} else {
			if (estadoApertura != null && !estadoApertura.trim().isEmpty()) {
				query.append("WHERE a.cveEstadoApe in ('").append(estadoApertura).append("') ");
				insWhere = false;
			}
			if (!codPersona.equals(Constants.CODIGO_PERSONA_BCB)) {
				if (insWhere)
					query.append("WHERE ");
				else
					query.append("AND ");

				query.append("(" + // init
						"(a.cveTipoApe = 'I' AND exists (select 1 from PersonaInst pi WHERE pi.id.codInst = a.institucion.codInst ");
				query.append("AND pi.id.codPersona = '").append(codPersona).append("')) "); // select
																							// 1
				query.append("OR ");
				query.append("(a.cveTipoApe = 'E' AND exists (select 1 from PersonaInst pi, Registro r ");
				query.append("WHERE pi.id.codInst = r.institucion.codInst ");
				query.append("AND r.nroMovApe = a.nroMov AND r.cveTipoEmis = 'E' ");
				query.append("AND pi.id.codPersona = '").append(codPersona).append("')) "); // select
																							// 1
				query.append(") "); // fin init
				insWhere = false;
			}
			if (codConvenio != null && !codConvenio.trim().isEmpty()) {
				if (insWhere)
					query.append("WHERE ");
				else
					query.append("AND ");
				// selecciona el pais convenio
				query.append("("); // init
				query.append("(a.cveTipoApe = 'E' AND exists (select 1 from Institucion i "); // select1
																								// pais
				query.append("where i.codInst = a.institucion.codInst ");
				query.append("and i.pais.codPais = '").append(codConvenio).append("')) "); // finselect1pais
				query.append("OR ");
				query.append("(a.cveTipoApe = 'I' AND a.pais.codPais = '").append(codConvenio).append("')");
				query.append(") "); // fin init
				insWhere = false;
			}
		}
		if (tipoReg != null && estadoRegistro != null && !estadoRegistro.trim().isEmpty()) {
			if (insWhere)
				query.append("WHERE ");
			else
				query.append("AND ");

			insWhere = false;

			if (tipoReg.equals("R")) {
				// si es tabla registro, aperturas que tengan un registro en
				// estado = estadoRegistro
				query.append("exists (select 1 from Registro r1 ");
				query.append("WHERE r1.nroMovApe = a.nroMov ");
				query.append("AND r1.cveEstadoReg = '").append(estadoRegistro).append("') "); // select
																								// 1
			} else if (tipoReg.equals("P")) {
				query.append("exists (select 1 from Pago p1 ");
				query.append("WHERE p1.nroMovApe = a.nroMov ");
				query.append("AND p1.cveEstadoPago = '").append(estadoRegistro).append("') "); // select
																								// 1
			} else if (tipoReg.equals("PP")) {
				// si es tabla plan de pagos aperturas que tengan un registro en
				// estado = estadoRegistro
				query.append("exists (select 1 from Pago p1 ");
				query.append("WHERE p1.nroMovApe = a.nroMov ");
				query.append("AND p1.cveEstadoPago = '").append(estadoRegistro).append("') "); // select
																								// 1
			}
		}
		return query.toString();
	}
	
}
