package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the calif_riesgo database table.
 * 
 */
@Entity
@Table(name="calif_riesgo")
public class CalifRiesgo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="cod_calif", unique=true, nullable=false)
	private String codCalif;

	@Column(name="cod_usuario")
	private String codUsuario;

	@Column(name="estacion")
	private String estacion;

	@Column(name="fecha_hora")
	private Date fechaHora;

	private short plazo;
    public CalifRiesgo() {
    }

	public String getCodCalif() {
		return this.codCalif;
	}

	public void setCodCalif(String codCalif) {
		this.codCalif = codCalif;
	}

	public String getCodUsuario() {
		return this.codUsuario;
	}

	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public short getPlazo() {
		return this.plazo;
	}

	public void setPlazo(short plazo) {
		this.plazo = plazo;
	}
	
}
