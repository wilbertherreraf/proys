package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;

public interface DomainObject extends Serializable {

}
