package gob.bcb.bpm.siraladi.service;

/*import gob.bcb.core.seguridad.AuthorizationService;

 import gob.bcb.core.seguridad.PopulateContextUtil;
 import gob.bcb.core.seguridad.RequestContextLocalAdm;
 import gob.bcb.core.seguridad.ServiceAuthorizingInterceptor;*/

import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.exception.GenericJDBCException;

import gob.bcb.bpm.siraladi.dao.EntityUserTransaction;
import gob.bcb.bpm.siraladi.dao.HorarioBean;
import gob.bcb.bpm.siraladi.dao.qnative.DBSourceHandlerFactory;
import gob.bcb.bpm.siraladi.exceptions.AladiException;
import gob.bcb.bpm.siraladi.exceptions.BusinessException;
import gob.bcb.bpm.siraladi.exceptions.DataBaseException;
import gob.bcb.bpm.siraladi.exceptions.SystemInternalException;
import gob.bcb.bpm.siraladi.jpa.Param;
import gob.bcb.bpm.siraladi.service.session.UserSessionHolder;
import gob.bcb.bpm.siraladi.utils.Constants;
import gob.bcb.bpm.siraladi.utils.StatusCode;
import gob.bcb.bpm.siraladi.utils.Utils;
import gob.bcb.bpm.siraladi.utils.UtilsDate;
import gob.bcb.core.jms.BcbRequest;

/**
 * @author wilherrera Wilbert Herrera Flores Banco Central de Bolivia
 *         Departamento de Desarrollo
 */
public class DispatcherSirAladi {
	private static Logger log = Logger.getLogger(DispatcherSirAladi.class);
	private Map<String, ServiceAladiHandler> handlers = new HashMap<String, ServiceAladiHandler>();
	@PersistenceContext(unitName = "ALADI_PU")
	private EntityManager entityManager;
	private EntityUserTransaction userTransaction;

	// private AuthorizationService authorizationService;

	public DispatcherSirAladi(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public void init() {
		if (!entityManager.isOpen()) {
			log.error("No se pudo abrir el contexto de base de datos para servicio "
					+ ConfigurationServ.getServiceName());
			throw new RuntimeException("No se pudo abrir el contexto de base de datos para servicio "
					+ ConfigurationServ.getServiceName());
		}
		userTransaction = new EntityUserTransaction(entityManager);
		ConfigurationServ configuration = new ConfigurationServ();
		handlers.putAll(Utils.getHandlers(configuration, entityManager));
	}

	public void doService(BcbRequest bcbRequest, ResponseContext responseContext) {
		String statusCode = StatusCode.OPERACION_RECEIVED;
		String consent = null;
		init();

		if (bcbRequest == null) {
			responseContext.updateReponse("OBJETO_NULO",
					AladiException.getDescription("OBJETO_NULO", new Object[] { "bcbRequest" }));
			return;
		}
		UserSessionHolder.set(null, null);
		log.info("::Mensaje recibido::" + UtilsDate.stringFromDate(new Date(), Constants.FORMAT_DATE_TIME)
				+ " IP Origen: " + bcbRequest.getIpOrigen());

		String codOperacion = bcbRequest.getIdTipoOperacion().trim();

		log.info("Inicio proceso operacion con Tipo Operacion en mensaje: " + codOperacion);

		ClassHandlerTOper classHandlerTOper = ConfigurationServ.findHandlerByCodTipoOper(codOperacion);
		if (classHandlerTOper == null) {
			responseContext.updateReponse("TIPO_DE_OPERACION_NO_IMPLEMENTADA",
					AladiException.getDescription("TIPO_DE_OPERACION_NO_IMPLEMENTADA", new Object[] { codOperacion }));
			return;
		}

		try {

			// ///////////////////////////////////
			// Seteo de valores de sesion de usuario
			Param param = getEntityManager().find(Param.class, "correoremitente");
			UserSessionHolder.set("correoremitente", param.getValparam());
			UserSessionHolder.set(Constants.AUDIT_USER_ESTACION, bcbRequest.getMsgbcb().getMsgcabecera().getIdemisor());
			UserSessionHolder.set(Constants.AUDIT_COD_TIPO_OPERACION, codOperacion);
			UserSessionHolder.set(Constants.AUDIT_HORA_RECEPCION,
					(Date) responseContext.getBcbResponse().getReceivedDate());

			String[] idUsuarioArr = StringUtils.trimToEmpty(bcbRequest.getMsgbcb().getMsgcabecera().getIdusuario())
					.split("\\|");

			String idUsuario = StringUtils.trimToEmpty(idUsuarioArr[0]);
			String usrCodemp = idUsuario;
			String usrCodpte = null;

			if (idUsuarioArr.length > 1) {
				// tiene info de codemp y participante
				usrCodemp = StringUtils.trimToEmpty(idUsuarioArr[1]);
				if (idUsuarioArr.length > 2) {
					usrCodpte = StringUtils.trimToEmpty(idUsuarioArr[2]);
				}
			}

			if (idUsuario == null || idUsuario.isEmpty()) {
				throw new AladiException("USUARIO_INEXISTENTE", new Object[] { idUsuario });
			}

			if (usrCodpte == null) {
				throw new AladiException("ERROR_DE_VALIDACION",
						new Object[] { "Usuario debe tener asignado un codigo de participante " + idUsuario });
			}

			UserSessionHolder.set(Constants.AUDIT_USER_SESSION_ID, idUsuario);
			UserSessionHolder.set(Constants.AUDIT_USER_DATABASE_ID, usrCodemp);
			UserSessionHolder.set("codIFARequest", usrCodpte);

			if (!usrCodpte.equals(Constants.CODIGO_PERSONA_BCB)) {
				usrCodpte = "EF" + usrCodpte.trim();
				UserSessionHolder.set(Constants.AUDIT_USER_DATABASE_ID, usrCodpte);
			}

			log.info("Usuario externo logueado " + idUsuario + " codempleado: " + usrCodemp + " usuario participante: "
					+ usrCodpte);
			// ///////////////////////////////////
			// verificacion del horario
			HorarioBean horarioBean = new HorarioBean();
			horarioBean.setEntityManager(entityManager);

			if (!horarioBean.operacionEstaEnHorario(codOperacion, "N",
					responseContext.getBcbResponse().getReceivedDate())) {
				// la operacion no se encuentra fuera de plazo para horario
				// normal N

				throw new AladiException("OPERACION_FUERA_DE_HORARIO",
						new Object[] { (String) UserSessionHolder.get(Constants.AUDIT_COD_TIPO_OPERACION),
								UtilsDate.stringFromDate((Date) UserSessionHolder.get(Constants.AUDIT_HORA_RECEPCION),
										Constants.FORMAT_DATE_TIME) });

			}

			// Handler administrador de la operacion
			ServiceAladiHandler handler = handlers.get(classHandlerTOper.getCodClassHandler());

			if (handler == null) {
				throw new SystemInternalException("CLASE_NO_IMPLEMENTADA",
						new Object[] { classHandlerTOper.getCodClassHandler() });
			}
			// #######################EXECUTE SERVICE
			// BUSSINESS##############################
			RequestContext context = new RequestContext(bcbRequest, responseContext, entityManager);
			context.populateRequestParameters();
			handler.handlerProcesarMsg(context);
			// #####################################################
			consent = responseContext.getBcbResponse().getMsgBcbresp().getMsgsistemaresp().getDescripcion();
			statusCode = responseContext.getBcbResponse().getMsgBcbresp().getMsgsistemaresp().getCodestadoresp();
		} catch (AladiException e) {
			log.error(e.getCode() + ": " + e.getMessage(), e);
			consent = e.getMessage();
			statusCode = e.getCode();
		} catch (BusinessException e) {
			log.error(e.getCode() + ": " + e.getMessage(), e);
			consent = e.getMessage();
			statusCode = e.getCode();
		} catch (GenericJDBCException e) {
			log.error(e.getMessage(), e);
			StringBuilder sb = new StringBuilder();
			int count = 0;
			for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
				if (cause instanceof SQLException) {
					count++;
					sb.append(cause.getMessage());
					sb.append(" , ");
				}
			}
			consent = (count > 0 ? sb.toString().replace(", null ,", "") : e.getMessage().replace(", null ,", ""));
			statusCode = StatusCode.DATABASE_EXCEPTION;
		} catch (DataBaseException e) {
			log.error(e.getCode() + ": " + e.getMessage(), e);
			consent = e.getMessage();
			statusCode = e.getCode();
		} catch (SQLException e) {
			log.error(e.getMessage(), e);
			consent = e.getMessage();
			statusCode = StatusCode.DATABASE_EXCEPTION;
		} catch (SystemException e) {
			log.error(e.getMessage(), e);
			consent = e.getMessage();
			statusCode = StatusCode.RUNTIME_EXCEPTION;
		} catch (SystemInternalException e) {
			log.error(e.getCode() + ": " + e.getMessage(), e);
			consent = e.getMessage();
			statusCode = e.getCode();
		} catch (NotSupportedException e) {
			log.error(e.getMessage(), e);
			consent = e.getMessage();
			statusCode = StatusCode.DATABASE_EXCEPTION;
		} catch (RollbackException e) {
			rollbackEntityManager();
			log.error(e.getMessage(), e);
			consent = e.getMessage();
			statusCode = StatusCode.DATABASE_EXCEPTION;
		} catch (HeuristicMixedException e) {
			log.error(e.getMessage(), e);
			consent = e.getMessage();
			statusCode = StatusCode.DATABASE_EXCEPTION;
		} catch (HeuristicRollbackException e) {
			log.error(e.getMessage(), e);
			consent = e.getMessage();
			statusCode = StatusCode.DATABASE_EXCEPTION;
		} catch (PersistenceException e) {
			log.error("Persistencia: " + e.getMessage(), e);
			StringBuilder sb = new StringBuilder();
			int count = 0;
			for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
				if (cause instanceof SQLException) {
					count++;
					sb.append(cause.getMessage());
					sb.append(" , ");
				}
			}
			consent = (count > 0 ? sb.toString().replace(", null ,", "") : e.getMessage().replace(", null ,", ""));
			statusCode = StatusCode.DATABASE_EXCEPTION;
		} catch (RuntimeException e) {
			log.error(e.getMessage(), e);
			consent = e.getMessage();
			statusCode = StatusCode.RUNTIME_EXCEPTION;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			consent = "Error desconocido: " + e.getMessage();
			statusCode = StatusCode.UNKNOWN_EXCEPTION;
		} finally {
			UserSessionHolder.set(null, null);
			// se verifica que no haya una transaccion anterior local
			rollbackEntityManager();
			log.info("Tarea u operacion concluida con mensaje:" + statusCode + " : " + StatusCode.OPERACION_SUCCESS);
			if (!statusCode.equalsIgnoreCase(StatusCode.OPERACION_SUCCESS)) {
				// hubo un error y se actualiza la respuesta
				responseContext.updateReponse(statusCode, consent);
			}
			closeEntityManager();
		}
		log.info("::Mensaje procesado::" + UtilsDate.stringFromDate(new Date(), Constants.FORMAT_DATE_TIME)
				+ " IP Origen: " + bcbRequest.getIpOrigen());
	}

	/**
	 * Inserta handler de manera manual al arreglo del mismo
	 * 
	 * @param handler
	 * @param dispatchPath
	 */
	public void setHandler(ServiceAladiHandler handler, String dispatchPath) {
		handlers.put(dispatchPath, handler);
	}

	public void rollbackEntityManager() {
		// whf viabilidad de setRollbackOnly
		try {
			if (entityManager == null) {
				return;
			}
			if (!entityManager.isOpen()) {
				return;
			}
			if (entityManager.getTransaction() != null && entityManager.getTransaction().isActive()) {
				entityManager.getTransaction().rollback();
				log.info("Realizado rollback a transaccion activa, verifique mensajes anteriores para la operacion ");
			}
		} catch (Exception e) {
			log.info("Excepci�n al Rolbacking entityManager en caso de necesidad " + e.getMessage());
			// log.error("==>DESCRIPCION EXCEPCION: ", e);
		}
	}

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void closeEntityManager() {
		rollbackEntityManager();
		try {
			log.info("Cerrando.... entityManager");
			if (entityManager == null) {
				return;
			}

			if (entityManager.isOpen()) {
				entityManager.close();
			}
		} catch (Exception e) {
			log.info("==>EXCEPCION CERRANDO ENTITYMANAGER: ", e);
		}
	}

	public void close() {
		closeEntityManager();
		try {
			log.info("Cerrando.... DBSourceHandlerFactory");
			DBSourceHandlerFactory.Factory.close();
		} catch (Exception e) {
			log.info("==>EXCEPCION CERRANDO CONEXIONES NATIVAS: ", e);
		}
	}

	public Map<String, ServiceAladiHandler> getHandlers() {
		return handlers;
	}
}
