package gob.bcb.bpm.siraladi.exceptions;

/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public class InvalidCertificateException extends RuntimeException {

	public InvalidCertificateException(String reason) {
		super(reason);
	}

	public InvalidCertificateException(String message, Exception e) {
		super(message, e);
	}
}
