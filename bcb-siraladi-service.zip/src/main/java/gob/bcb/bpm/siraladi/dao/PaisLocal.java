package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.Pago;
import gob.bcb.bpm.siraladi.jpa.Pais;

import java.math.BigDecimal;
import java.util.Date;

public interface PaisLocal extends DAO<String, Pais> {
	BigDecimal montoPagosPendientes(String codPais, Date fechaVal);

	BigDecimal montoCobrosPendientes(String codPais, Date fechaVal);
}
