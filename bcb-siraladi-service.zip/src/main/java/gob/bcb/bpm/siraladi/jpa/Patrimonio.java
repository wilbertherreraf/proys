package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import javax.persistence.OneToMany;


/**
 * The persistent class for the patrimonio database table.
 * 
 */
@Entity
@Table(name="patrimonio")
public class Patrimonio implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="nro_orden", unique=true, nullable=false)
	private Integer nroOrden;

	@Column(name="cod_usuario")
	private String codUsuario;

	@Column(name="concepto")
	private String concepto;

	@Column(name="estacion")
	private String estacion;

	@Column(name="factor_bs", precision=10, scale=7)
	private BigDecimal factorBs;

    @Temporal( TemporalType.DATE)
	@Column(name="fecha_actual")
	private Date fechaActual;

    @Temporal( TemporalType.DATE)
	@Column(name="fecha_anterior")
	private Date fechaAnterior;

	@Column(name="fecha_hora")
    @Temporal( TemporalType.TIMESTAMP)	
	private Date fechaHora;

	@Column(precision=5, scale=2)
	private BigDecimal nivel;

    public Patrimonio() {
    }

	public Integer getNroOrden() {
		return this.nroOrden;
	}

	public void setNroOrden(Integer nroOrden) {
		this.nroOrden = nroOrden;
	}

	public String getCodUsuario() {
		return this.codUsuario;
	}

	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}

	public String getConcepto() {
		return this.concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public BigDecimal getFactorBs() {
		return this.factorBs;
	}

	public void setFactorBs(BigDecimal factorBs) {
		this.factorBs = factorBs;
	}

	public Date getFechaActual() {
		return this.fechaActual;
	}

	public void setFechaActual(Date fechaActual) {
		this.fechaActual = fechaActual;
	}

	public Date getFechaAnterior() {
		return this.fechaAnterior;
	}

	public void setFechaAnterior(Date fechaAnterior) {
		this.fechaAnterior = fechaAnterior;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public BigDecimal getNivel() {
		return this.nivel;
	}

	public void setNivel(BigDecimal nivel) {
		this.nivel = nivel;
	}

}
