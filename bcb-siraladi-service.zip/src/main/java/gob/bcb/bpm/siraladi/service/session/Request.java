package gob.bcb.bpm.siraladi.service.session;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;

public class Request implements Serializable {
	private final String codOperacion;
	private final Date fecha;
	private final String msgOriginal;
	private final String method;
	private final Map<String, String[]> parameters;
	
	public Request(String codOperacion, Date fecha, String msgOriginal, String method, Map<String, String[]> parameters) {
		this.codOperacion = codOperacion;
		this.fecha = fecha;
		this.msgOriginal = msgOriginal;		
		this.method = method;
		this.parameters = parameters;		
	}
	
	public static Request fromMsgOrig(String req) {
		return new Request("",null,"","",null);
	}
	
	public String getCodOperacion() {
		return codOperacion;
	}

	public String getMsgOriginal() {
		return msgOriginal;
	}
	
	public String getMethod() {
		return method;
	}
	
	public Map<String, String[]> getParameters() {
		return parameters;
	}

	public Date getFecha() {
		return fecha;
	}

 	
}
