package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.PlanPago;
import gob.bcb.bpm.siraladi.jpa.PlanPagoPK;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


import javax.persistence.Query;
import javax.persistence.TemporalType;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("planPagoLocal")
@Transactional
public class PlanPagoBean extends GenericDAO<PlanPagoPK, PlanPago> implements PlanPagoLocal {
	/**
	 * Retorna el plan de pagos de un instrumento
	 * 
	 * @param nroMov
	 * @param cveEstadoPlan
	 *            'S' o 'P', si es nulo se retorna todos
	 * @param fechaVal
	 * @return retorna la lista del plan de pagos ordenados por fecha
	 */
	
	public List<PlanPago> findPlanPagos(Integer nroMov, String cveEstadoPlan, Date fechaVal) {
		String jpql = "SELECT p FROM PlanPago p " + " WHERE p.id.nroMov = :nroMov and p.cveEstadoPlan <> 'S' ";
		if (fechaVal != null) {
			jpql += "and p.fechaVal = :fechaVal ";
		}
		if (cveEstadoPlan != null) {
			jpql += "and p.cveEstadoPlan = :cveEstadoPlan ";
		}
		jpql += "order by p.fechaVal, p.id.nroPlan asc ";

		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("nroMov", nroMov);
		if (fechaVal != null) {
			query.setParameter("fechaVal", fechaVal, TemporalType.DATE);
		}
		if (cveEstadoPlan != null) {
			query.setParameter("cveEstadoPlan", cveEstadoPlan);
		}
		return query.getResultList();
	}
	public PlanPago findPlanPagoByReembolso(Integer nroMov, Date fechaVal, BigDecimal monto, String capitalOInteres) {
		PlanPago planPago = null;
		String jpql = "SELECT p FROM PlanPago p " + " WHERE p.id.nroMov = :nroMov and p.cveEstadoPlan = 'N' " + "and p.fechoraRegaladi is not null ";
		jpql += "and p.fechaVal = :fechaVal ";
		if (capitalOInteres.equals("K")) {
			jpql += "and p.capital = :monto ";
		}
		if (capitalOInteres.equals("I")) {
			jpql += "and p.interes = :monto ";
		}

		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("nroMov", nroMov);
		query.setParameter("fechaVal", fechaVal, TemporalType.DATE);
		
		if (capitalOInteres.equals("K")) {
			query.setParameter("monto", monto);
		}
		if (capitalOInteres.equals("I")) {
			query.setParameter("monto", monto);
		}
		List result = query.getResultList();
		if (result.size() > 0)
			planPago = (PlanPago) result.get(0);
		return planPago;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.bpm.siraladi.dao.PlanPagoLocal#getSumaPlanPagos(java.lang.Integer, java.lang.String, java.util.Date)
	 */
	
	public BigDecimal getSumaPlanPagos(Integer nroMov, String cveEstadoPlan, Date fechaVal) {
		String jpql = "SELECT sum(nvl(p.interes, 0) + nvl(p.capital, 0)) FROM PlanPago p " + " WHERE p.id.nroMov = :nroMov and p.cveEstadoPlan != 'S' ";

		if (cveEstadoPlan != null) {
			jpql += "and p.cveEstadoPlan = :cveEstadoPlan ";
		}

		if (fechaVal != null) {
			jpql += "and p.fechaVal <= :fechaVal ";
		}
		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("nroMov", nroMov);

		if (cveEstadoPlan != null) {
			query.setParameter("cveEstadoPlan", cveEstadoPlan);
		}

		if (fechaVal != null) {
			query.setParameter("fechaVal", fechaVal, TemporalType.DATE);
		}
		List result = query.getResultList();
		if (result.size() > 0) {
			Double valor = (Double) result.get(0);
			return (BigDecimal.valueOf((valor == null ? Double.valueOf(0) : valor)));
		}

		return BigDecimal.ZERO;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.bpm.siraladi.dao.PlanPagoLocal#getMaxPPagos(int, javax.persistence.EntityManager)
	 */
	
	public Integer getMaxPPagos(Integer nroMov) {
		String jpql = "SELECT max(p.id.nroPlan) FROM PlanPago p " + " WHERE p.id.nroMov = :nroMov ";
		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("nroMov", nroMov);

		List result = query.getResultList();
		if (result.size() > 0)
			return (Integer) result.get(0);

		return Integer.valueOf(0);
	}

	
	public PlanPago makePersistent(PlanPago planPago) {
		planPago = super.makePersistent(planPago);

		planPago.setMonto(planPago.getCapital().add(planPago.getInteres()));

		return getEntityManager().merge(planPago);
	}
}
