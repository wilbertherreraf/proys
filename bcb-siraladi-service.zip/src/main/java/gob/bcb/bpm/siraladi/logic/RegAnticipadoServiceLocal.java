package gob.bcb.bpm.siraladi.logic;

import java.util.List;
import java.util.Map;

import gob.bcb.bpm.siraladi.dao.RegAnticipadoLocal;
import gob.bcb.bpm.siraladi.dao.UserTransactionServ;
import gob.bcb.bpm.siraladi.jpa.RegAnticipado;
import gob.bcb.bpm.siraladi.jpa.SwfMensaje;

/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public interface RegAnticipadoServiceLocal extends UserTransactionServ{
	RegAnticipado crearReg(RegAnticipado regAnticipado);
	RegAnticipado modificar(RegAnticipado regAnticipado);
	boolean isValidData(RegAnticipado regAnticipado);
	RegAnticipadoLocal getRegAnticipadoLocal();
	Map<String, Object> getWarnnings();
	List<RegAnticipado> crearReg(List<RegAnticipado> regAnticipadoListIn);
	List<RegAnticipado> modificar(List<RegAnticipado> regAnticipadoListIn);
	void eliminar(RegAnticipado regAnticipado);
	RegAnticipado crearPAnticipadoSwift(RegAnticipado regAnticipado);
	SwfMensaje crearSwiftDeRegAnticipado(RegAnticipado regAnticipado);
	RegAnticipado modificarPAnticipadoSwift(RegAnticipado regAnticipado);	
}