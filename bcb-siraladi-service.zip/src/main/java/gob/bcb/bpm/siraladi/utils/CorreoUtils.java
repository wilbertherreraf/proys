/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.bpm.siraladi.utils;

import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;
import org.apache.log4j.Logger;

public class CorreoUtils {
	private static Logger log = Logger.getLogger(CorreoUtils.class);
    private Properties props;
    private String smtpHost = "10.2.11.27";
    private int smtpPort = 25;

    public CorreoUtils() {
    }

    public CorreoUtils(String smtpHost, int smtpPort) {
        this.smtpHost = smtpHost;
        this.smtpPort = smtpPort;
    }

    public void enviaAlServidorSMTP(String from, String to,
            String subject, String content) {
        try {
            initProperties();
            Session session = Session.getInstance(props);

            // Construct the message
            Message msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress(from));
            msg.setRecipient(Message.RecipientType.TO, new InternetAddress(to));
            msg.setSubject(subject);
            msg.setText(content);

            // Send the message
            Transport.send(msg);
            log.info("Correo enviado " + to);
        } catch (AddressException add) {
            log.error("Error de Direccion IP: " + add.toString());
        } catch (MessagingException mes) {
            log.error("Error de Mensaje: " + mes.toString());
        } catch (NullPointerException e) {
            log.error("Error de Mensaje: valor nulo " + e.getMessage(), e);            
        } catch (Exception e) {
            log.error("Error de Mensaje: " + e.getMessage());            
        }
    }

    private void initProperties() {
        // Create a mail session
        props = new Properties();
        //log.info(" props: " + props.getProperty("mail.smtp.host"));
        props.put("mail.smtp.host", smtpHost);
        props.put("mail.smtp.port", "" + smtpPort);
        //log.info(" props: " + props.getProperty("mail.smtp.host"));
    }

    /**
     * @return the smtpHost
     */
    public String getSmtpHost() {
        return smtpHost;
    }

    /**
     * @param smtpHost the smtpHost to set
     */
    public void setSmtpHost(String smtpHost) {
        this.smtpHost = smtpHost;
    }

    /**
     * @return the smtpPort
     */
    public int getSmtpPort() {
        return smtpPort;
    }

    /**
     * @param smtpPort the smtpPort to set
     */
    public void setSmtpPort(int smtpPort) {
        this.smtpPort = smtpPort;
    }
}
