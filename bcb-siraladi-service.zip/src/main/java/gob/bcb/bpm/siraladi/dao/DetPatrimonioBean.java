package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.DetPatrimonio;
import gob.bcb.bpm.siraladi.jpa.DetPatrimonioPK;
import gob.bcb.bpm.siraladi.jpa.Patrimonio;
import gob.bcb.bpm.siraladi.logic.ConsultasBD;

import java.math.BigDecimal;
import java.util.Date;



import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("detPatrimonioLocal")
@Transactional
public class DetPatrimonioBean extends GenericDAO<DetPatrimonioPK, DetPatrimonio> implements DetPatrimonioLocal {

	
	public DetPatrimonio actualizarSaldoIFA(String codPersona) {
		
		DetPatrimonio detPatrimonio = null;
		if (codPersona != null) {

			ConsultasBD consultasBD = new ConsultasBD(getEntityManager());
			BigDecimal saldoIFA = consultasBD.getSaldoCont(codPersona, new Date(), "I");

			if (saldoIFA != null) {
				PatrimonioLocal patrimonioLocal = new PatrimonioBean();
				patrimonioLocal.setEntityManager(getEntityManager());
				Patrimonio patrimonio = patrimonioLocal.getMaxPatrimonio();

				if (patrimonio != null) {
					DetPatrimonioPK detPatrimonioPK = new DetPatrimonioPK();
					detPatrimonioPK.setCodPersona(codPersona);
					detPatrimonioPK.setNroOrden(patrimonio.getNroOrden());
					detPatrimonio = findById(detPatrimonioPK, false);
					detPatrimonio.setSaldoDeudor(saldoIFA);
					log.info("saldoIFA = " + saldoIFA.toPlainString());
					detPatrimonio = makePersistent(detPatrimonio);
					// 553404.77
				}
			}
		}
		return detPatrimonio;
	}
}
