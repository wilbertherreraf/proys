package gob.bcb.bpm.siraladi.logic;

import gob.bcb.bpm.siraladi.dao.MovimientoLocal;
import gob.bcb.bpm.siraladi.dao.UserTransactionServ;
import gob.bcb.bpm.siraladi.jpa.Movimiento;

import java.util.Date;
import java.util.Map;

/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public interface MovimientoServiceLocal  extends UserTransactionServ{
	Movimiento crearMovimiento(String cveTipoMov, String codMoneda, Date fechaMov, Integer nroMovApe);

	Map<String, Object> getWarnnings();

	MovimientoLocal getMovimientoLocal();

	Movimiento actualizarRegAladi(Integer nroMov, String tipoOperAladi, Date horaRegaladi);

	Movimiento actualizarNroReembolso(Integer nroMov);

}