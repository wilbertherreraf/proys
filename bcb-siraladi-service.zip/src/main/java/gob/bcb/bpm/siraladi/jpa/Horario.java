package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;

import java.util.Date;
import java.math.BigDecimal;


/**
 * The persistent class for the horario database table.
 * 
 */
@Entity
@Table(name="horario")
public class Horario implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private HorarioPK id;

	@Column(name="descrip")
	private String descrip;
	
	@Column(name="cod_usuario")
	private String codUsuario;

	@Column(name="cve_estado_hor")
	private String cveEstadoHor;

	private String estacion;

	@Temporal(TemporalType.TIMESTAMP)	
	@Column(name="fecha_hora")
	private Date fechaHora;

	@Temporal(TemporalType.TIME)
	@Column(name="hora_fin")
	private Date horaFin;

	@Temporal(TemporalType.TIME)	
	@Column(name="hora_ini")
	private Date horaIni;

	@Column(name="monto_tarifa")
	private BigDecimal montoTarifa;

    public Horario() {
    }

	public HorarioPK getId() {
		return this.id;
	}

	public void setId(HorarioPK id) {
		this.id = id;
	}
	
	public String getCodUsuario() {
		return this.codUsuario;
	}

	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}

	public String getCveEstadoHor() {
		return this.cveEstadoHor;
	}

	public void setCveEstadoHor(String cveEstadoHor) {
		this.cveEstadoHor = cveEstadoHor;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public Date getHoraFin() {
		return this.horaFin;
	}

	public void setHoraFin(Date horaFin) {
		this.horaFin = horaFin;
	}

	public Date getHoraIni() {
		return this.horaIni;
	}

	public void setHoraIni(Date horaIni) {
		this.horaIni = horaIni;
	}

	public BigDecimal getMontoTarifa() {
		return this.montoTarifa;
	}

	public void setMontoTarifa(BigDecimal montoTarifa) {
		this.montoTarifa = montoTarifa;
	}

	public String getDescrip() {
		return descrip;
	}

	public void setDescrip(String descrip) {
		this.descrip = descrip;
	}

}