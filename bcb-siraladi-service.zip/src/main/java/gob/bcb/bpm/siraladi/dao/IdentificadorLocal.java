package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.Identificador;

public interface IdentificadorLocal extends DAO<String, Identificador> {

}
