package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.Pais;

import java.math.BigDecimal;
import java.util.Date;


import javax.persistence.Query;
import javax.persistence.TemporalType;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("paisLocal")
@Transactional
public class PaisBean extends GenericDAO<String, Pais> implements PaisLocal {
	private final static String MONTO_PAGOS_PENDIENTES = "select sum(nvl(d.capital,0) + nvl(d.interes,0)) "
			+ "from Persona a, PersonaInst b, Apertura c, PlanPago d " + "where a.codPersona = b.id.codPersona " + "and b.id.codInst = c.institucion.codInst "
			+ "and c.nroMov = d.id.nroMov " + "and c.cveEstadoApe = 'V' " + "and d.cveEstadoPlan not in ('C','S') " + "and d.fechaVal <= :fechaVal  "
			+ "and c.cveTipoApe = 'I' " + "and c.pais.codPais = :codPais";

	
	public BigDecimal montoPagosPendientes(String codPais, Date fechaVal) {
		Query query = getEntityManager().createQuery(MONTO_PAGOS_PENDIENTES);
		query.setParameter("fechaVal", fechaVal, TemporalType.DATE);
		query.setParameter("codPais", codPais);

		if (query.getSingleResult() == null) {
			return BigDecimal.ZERO;
		}
		double saldo = (Double) query.getSingleResult();
		return (BigDecimal) BigDecimal.valueOf(saldo);
	}

	private final static String MONTO_COBROS_PENDIENTES = "select sum(nvl(d.capital,0) + nvl(d.interes,0)) " + "from Apertura c, PlanPago d, Institucion e "
			+ "where c.nroMov = d.id.nroMov " + "and c.institucion.codInst = e.codInst " + "and d.cveEstadoPlan not in ('C','S') "
			+ "and  d.cveEstadoPlan = 'P' " + "and e.pais.codPais = :codPais " + "and d.fechaVal <= :fechaVal " + "and c.cveTipoApe = 'E'";

	
	public BigDecimal montoCobrosPendientes(String codPais, Date fechaVal) {
		Query query = getEntityManager().createQuery(MONTO_COBROS_PENDIENTES);
		query.setParameter("fechaVal", fechaVal, TemporalType.DATE);
		query.setParameter("codPais", codPais);

		if (query.getSingleResult() == null) {
			return BigDecimal.ZERO;
		}
		double saldo = (Double) query.getSingleResult();
		return (BigDecimal) BigDecimal.valueOf(saldo);
	}

	private final static String PAGOS_EFECTUADOS_PENDIENTES = "select sum(nvl(r.debeMo,0) - nvl(r.haberMo,0)) from RegAnticipado r, Institucion i "
			+ "where i.codInst = r.codInstRecep and r.fechaCargo <= :fechaCargo and (r.cveEstadoAnt = 'C') and r.nroReembolso is null and r.nroDebito  is null "
			+ "and r.cveTipoApe = 'I' and i.pais.codPais = :codPais ";

	public BigDecimal montoPagosFecha(String codPais, Date fechaCargo) {
		Query query = getEntityManager().createQuery(PAGOS_EFECTUADOS_PENDIENTES);
		query.setParameter("fechaCargo", fechaCargo, TemporalType.DATE);
		query.setParameter("codPais", codPais);

		if (query.getSingleResult() == null) {
			return BigDecimal.ZERO;
		}
		double saldo = (Double) query.getSingleResult();
		return (BigDecimal) BigDecimal.valueOf(saldo);
	}

	private final static String MONTO_COBROS_FECHA = "select sum(nvl(d.capital,0) + nvl(d.interes,0)) "
			+ "from Persona a, PersonaInst b, Apertura c, PlanPago d " + "where a.codPersona = b.id.codPersona " + "and b.id.codInst = c.institucion.codInst "
			+ "and c.nroMov = d.id.nroMov " + "and c.cveEstadoApe = 'V' " + "and d.cveEstadoPlan = 'P' " + "and d.fechaVal <= :fechaVal  "
			+ "and c.cveTipoApe = 'I' " + "and c.pais.codPais = :codPais";

	public BigDecimal montoCobrosFecha(String codPais, Date fechaVal) {
		Query query = getEntityManager().createQuery(MONTO_COBROS_FECHA);
		query.setParameter("fechaVal", fechaVal, TemporalType.DATE);
		query.setParameter("codPais", codPais);

		if (query.getSingleResult() == null) {
			return BigDecimal.ZERO;
		}
		double saldo = (Double) query.getSingleResult();
		return (BigDecimal) BigDecimal.valueOf(saldo);
	}
}
