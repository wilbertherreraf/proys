package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * The persistent class for the moneda database table.
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@Entity
@Table(name = "moneda")
@XmlRootElement(name = "moneda")
public class Moneda implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "cod_moneda", unique = true, nullable = false, length = 3)
	private String codMoneda;

	@Column(name = "nom_moneda", length = 30)
	private String nomMoneda;

	public Moneda() {
	}

	public String getCodMoneda() {
		return this.codMoneda;
	}

	public void setCodMoneda(String codMoneda) {
		this.codMoneda = codMoneda;
	}

	public String getNomMoneda() {
		return this.nomMoneda;
	}

	public void setNomMoneda(String nomMoneda) {
		this.nomMoneda = nomMoneda;
	}
}
