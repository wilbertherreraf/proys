package gob.bcb.bpm.siraladi.service;

import java.io.StringReader;

import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.stream.FactoryConfigurationError;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import org.apache.log4j.Logger;
import gob.bcb.bpm.siraladi.exceptions.SystemInternalException;
import gob.bcb.bpm.siraladi.jpa.TPagoImp;
import gob.bcb.bpm.siraladi.pojo.OperacionAladi;
import gob.bcb.bpm.siraladi.utils.StatusCode;
import gob.bcb.core.jms.BcbRequest;
import gob.bcb.core.jms.BcbResponse;
import gob.bcb.core.jms.DescripcionParametro;
import gob.bcb.siraladi.xml.Contenidotype;
import gob.bcb.siraladi.xml.Contenidotype.Valorcompuesto;
import gob.bcb.siraladi.xml.model.Apertura;
import gob.bcb.siraladi.xml.model.Institucion;
import gob.bcb.siraladi.xml.model.Listainstitucion;
import gob.bcb.siraladi.xml.model.Listapagos;
import gob.bcb.siraladi.xml.model.Listaplanpagos;
import gob.bcb.siraladi.xml.model.Listareganticipado;
import gob.bcb.siraladi.xml.model.Listaregistros;
import gob.bcb.siraladi.xml.model.Listasaldoconvenio;
import gob.bcb.siraladi.xml.model.Listatpagoimport;
import gob.bcb.siraladi.xml.model.Pago;
import gob.bcb.siraladi.xml.model.Planpago;
import gob.bcb.siraladi.xml.model.Reganticipado;
import gob.bcb.siraladi.xml.model.Registro;
import gob.bcb.siraladi.xml.model.Saldoconvenio;
import gob.bcb.siraladi.xml.model.Tpagoimport;
import gob.bcb.siraladi.xml.operaciones.Aladireqresptipo01Type;
import gob.bcb.siraladi.xml.operaciones.Aladiresponsetipo01Type;
import gob.bcb.siraladi.xml.operaciones.ObjectFactory;

/**
 * @author wilherrera Wilbert Herrera Flores Banco Central de Bolivia
 *         Departamento de Desarrollo
 */
public class ResponseContext {
	private static Logger log = Logger.getLogger(ResponseContext.class);

	// private String codRespuesta;
	// private String codTipoOperacion;
	private String statusCode = StatusCode.OPERACION_RECEIVED;
	private OperacionAladi operacionAladi = new OperacionAladi();
	private boolean initialized = false;
	private BcbResponse bcbResponse;
	private Map<String, DescripcionParametro> descripcionParametroList = new HashMap<String, DescripcionParametro>();
	private final BcbRequest bcbRequest;

	// private StatusResponse statusResponse;

	public ResponseContext(BcbRequest bcbRequest) {
		this.bcbRequest = bcbRequest;
		init();
	}

	public final void init() {
		if (!isInitialized()) {
			if (bcbRequest == null) {
				log.error("Mensaje recibido nulo o no fue inicializado BCBRequest");
				throw new SystemInternalException("REQUEST_NULO");
			}

			if (getCodTipoOperacion() == null || getCodTipoOperacion().isEmpty()) {
				throw new SystemInternalException("TIPO_OPERACION_NO_INICIALIZADO");
			}

			try {
				bcbResponse = BcbResponse.Factory.createFromBcbRequest(bcbRequest, statusCode,
						"Estado inicial del mensaje recepcionado en el servidor. Si recibe este mensaje favor comunicar al administrador");

			} catch (Exception e) {
				throw new SystemInternalException("ERROR_CREANDO_OBJETO_RESPONSE", new Object[] { e.getMessage() });
			}
			initialized = true;
		}
	}

	/**
	 * A�ade en un mapa de objetos el objeto para ser devuelto en la respuesta,
	 * si el objeto a devolver en la respuesta es diferente a al objeto
	 * contenido en el parametro objeto se debe realizar la conversion
	 * respectiva
	 * 
	 * @param codTipoOperacion
	 * @param paramName
	 * @param tipoParam
	 * @param objeto
	 */
	public void addDescripcionParametro(String codTipoOperacion, String paramName, String tipoParam, Object objeto) {
		// para este segmento de codigo revisar las regeneraciones de
		// archivos JAXB
		try {
			if (objeto instanceof gob.bcb.bpm.siraladi.jpa.Apertura) {
				gob.bcb.bpm.siraladi.jpa.Apertura aperturaJPA = (gob.bcb.bpm.siraladi.jpa.Apertura) objeto;

				Apertura apertura = aperturaJPA.getObjectJAXB();
				DescripcionParametro descripParam = new DescripcionParametro(paramName, Apertura.class.getName(), apertura, codTipoOperacion);
				descripcionParametroList.put(paramName, descripParam);
			} else if (objeto instanceof gob.bcb.bpm.siraladi.jpa.Registro) {
				gob.bcb.bpm.siraladi.jpa.Registro registroJPA = (gob.bcb.bpm.siraladi.jpa.Registro) objeto;

				Registro registro = registroJPA.getObjectJAXB();
				DescripcionParametro descripParam = new DescripcionParametro(paramName, Registro.class.getName(), registro, codTipoOperacion);
				descripcionParametroList.put(paramName, descripParam);
			} else if (objeto instanceof gob.bcb.bpm.siraladi.jpa.RegAnticipado) {
				gob.bcb.bpm.siraladi.jpa.RegAnticipado registroJPA = (gob.bcb.bpm.siraladi.jpa.RegAnticipado) objeto;

				Reganticipado registro = registroJPA.getObjectJAXB();
				DescripcionParametro descripParam = new DescripcionParametro(paramName, Reganticipado.class.getName(), registro, codTipoOperacion);
				descripcionParametroList.put(paramName, descripParam);
			} else if (objeto instanceof gob.bcb.bpm.siraladi.jpa.Pago) {
				gob.bcb.bpm.siraladi.jpa.Pago pagoJPA = (gob.bcb.bpm.siraladi.jpa.Pago) objeto;

				Pago pago = pagoJPA.getObjectJAXB();
				DescripcionParametro descripParam = new DescripcionParametro(paramName, Pago.class.getName(), pago, codTipoOperacion);
				descripcionParametroList.put(paramName, descripParam);
			} else if (objeto instanceof gob.bcb.bpm.siraladi.jpa.PlanPago) {
				gob.bcb.bpm.siraladi.jpa.PlanPago planPagoJPA = (gob.bcb.bpm.siraladi.jpa.PlanPago) objeto;

				Planpago planPago = planPagoJPA.getObjectJAXB();
				DescripcionParametro descripParam = new DescripcionParametro(paramName, Planpago.class.getName(), planPago, codTipoOperacion);
				descripcionParametroList.put(paramName, descripParam);
			} else if (paramName.equalsIgnoreCase("listaregistros")) {
				List<gob.bcb.bpm.siraladi.jpa.Registro> listaregistrosJPA = (List<gob.bcb.bpm.siraladi.jpa.Registro>) objeto;
				Listaregistros listaObjJAXB = new Listaregistros();
				for (gob.bcb.bpm.siraladi.jpa.Registro registroJPA : listaregistrosJPA) {
					Registro registro = registroJPA.getObjectJAXB();
					listaObjJAXB.getRegistro().add(registro);
				}

				DescripcionParametro descripParam = new DescripcionParametro(paramName, Listaregistros.class.getName(), listaObjJAXB,
						codTipoOperacion);
				descripcionParametroList.put(paramName, descripParam);
			} else if (paramName.equalsIgnoreCase("listapagos")) {
				List<gob.bcb.bpm.siraladi.jpa.Pago> listapagosJPA = (List<gob.bcb.bpm.siraladi.jpa.Pago>) objeto;
				Listapagos listapagos = new Listapagos();
				for (gob.bcb.bpm.siraladi.jpa.Pago pagoJPA : listapagosJPA) {
					Pago pago = pagoJPA.getObjectJAXB();
					listapagos.getPago().add(pago);
				}

				DescripcionParametro descripParam = new DescripcionParametro(paramName, Listapagos.class.getName(), listapagos, codTipoOperacion);
				descripcionParametroList.put(paramName, descripParam);
			} else if (paramName.equalsIgnoreCase("listaplanpagos")) {
				List<gob.bcb.bpm.siraladi.jpa.PlanPago> listaregistrosJPA = (List<gob.bcb.bpm.siraladi.jpa.PlanPago>) objeto;
				Listaplanpagos listaObjJAXB = new Listaplanpagos();
				for (gob.bcb.bpm.siraladi.jpa.PlanPago registroJPA : listaregistrosJPA) {
					Planpago registro = registroJPA.getObjectJAXB();
					listaObjJAXB.getPlanpago().add(registro);
				}
				DescripcionParametro descripParam = new DescripcionParametro(paramName, Listaplanpagos.class.getName(), listaObjJAXB,
						codTipoOperacion);
				descripcionParametroList.put(paramName, descripParam);
			} else if (paramName.equalsIgnoreCase("listatpagoimport")) {
				List<gob.bcb.bpm.siraladi.jpa.TPagoImp> listaregistrosJPA = (List<gob.bcb.bpm.siraladi.jpa.TPagoImp>) objeto;
				Listatpagoimport listaObjJAXB = new Listatpagoimport();
				for (gob.bcb.bpm.siraladi.jpa.TPagoImp registroJPA : listaregistrosJPA) {
					Tpagoimport registro = registroJPA.getObjectJAXB();
					listaObjJAXB.getTpagoimport().add(registro);
				}
				DescripcionParametro descripParam = new DescripcionParametro(paramName, Listatpagoimport.class.getName(), listaObjJAXB,
						codTipoOperacion);
				descripcionParametroList.put(paramName, descripParam);
			} else if (paramName.equalsIgnoreCase("listasaldoconvenio")) {
				List<gob.bcb.bpm.siraladi.pojo.SaldoConvenio> listaregistrosJPA = (List<gob.bcb.bpm.siraladi.pojo.SaldoConvenio>) objeto;
				Listasaldoconvenio listaObjJAXB = new Listasaldoconvenio();
				for (gob.bcb.bpm.siraladi.pojo.SaldoConvenio registroJPA : listaregistrosJPA) {
					Saldoconvenio registro = registroJPA.getObjectJAXB();
					listaObjJAXB.getSaldoconvenio().add(registro);
				}
				DescripcionParametro descripParam = new DescripcionParametro(paramName, Listasaldoconvenio.class.getName(), listaObjJAXB,
						codTipoOperacion);
				descripcionParametroList.put(paramName, descripParam);
			} else if (paramName.equalsIgnoreCase("listainstitucion")) {
				List<gob.bcb.bpm.siraladi.jpa.Institucion> listaregistrosJPA = (List<gob.bcb.bpm.siraladi.jpa.Institucion>) objeto;
				Listainstitucion listaObjJAXB = new Listainstitucion();
				for (gob.bcb.bpm.siraladi.jpa.Institucion registroJPA : listaregistrosJPA) {
					Institucion registro = registroJPA.getObjectJAXB();
					listaObjJAXB.getInstitucion().add(registro);
				}
				DescripcionParametro descripParam = new DescripcionParametro(paramName, Listainstitucion.class.getName(), listaObjJAXB,
						codTipoOperacion);
				descripcionParametroList.put(paramName, descripParam);
			} else if (paramName.equalsIgnoreCase("listareganticipado")) {
				List<gob.bcb.bpm.siraladi.jpa.RegAnticipado> listaregistrosJPA = (List<gob.bcb.bpm.siraladi.jpa.RegAnticipado>) objeto;
				Listareganticipado listaObjJAXB = new Listareganticipado();
				for (gob.bcb.bpm.siraladi.jpa.RegAnticipado registroJPA : listaregistrosJPA) {
					Reganticipado registro = registroJPA.getObjectJAXB();
					listaObjJAXB.getReganticipado().add(registro);
				}
				DescripcionParametro descripParam = new DescripcionParametro(paramName, Listareganticipado.class.getName(), listaObjJAXB,
						codTipoOperacion);
				descripcionParametroList.put(paramName, descripParam);
			} else if (paramName.equalsIgnoreCase("listapagosimportwsxxx")) {
				JAXBContext context = JAXBContext.newInstance(TPagoImp.class);
				Marshaller marshaller = context.createMarshaller();
				List<TPagoImp> tPagoImpList = (List<TPagoImp>) objeto;
				StringBuilder listaObjetos = new StringBuilder();
				Contenidotype contenido = new Contenidotype();
				List<String> objetosList = new ArrayList<String>();
				for (TPagoImp tPagoImp : tPagoImpList) {
					try {
						Writer buffer = new StringWriter();
						// whf setear si la impresion es pretty o no
						// isPrettyPrint() ? Boolean.TRUE : Boolean.FALSE
						marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.FALSE);
						marshaller.setProperty(Marshaller.JAXB_ENCODING, "ISO-8859-1");
						marshaller.marshal(tPagoImp, buffer);
						listaObjetos.append(buffer.toString());
						contenido.getValor().add("<![CDATA[" + buffer.toString() + "]]>");
						objetosList.add("<![CDATA[" + buffer.toString() + "]]>");
					} catch (JAXBException e) {
						throw new Exception(e);
					} catch (FactoryConfigurationError e) {
						throw new Exception(e);
					}
				}
				DescripcionParametro descripParam = new DescripcionParametro(paramName, TPagoImp.class.getName(), objetosList, codTipoOperacion);
				descripcionParametroList.put(paramName, descripParam);
			} else {
				// en veremos
				// cuando no es un tipo definido convertirlo cdata e insertarlo
				// en valor contenido
				// con XMLStreamWriter writer =
				// XMLOutputFactory.newInstance().createXMLStreamWriter(buffer);

				String valorXML = "";
				try {
					JAXBContext context = JAXBContext.newInstance(objeto.getClass());
					Marshaller marshaller = context.createMarshaller();
					Writer buffer = new StringWriter();
					XMLStreamWriter writer = XMLOutputFactory.newInstance().createXMLStreamWriter(buffer);
					// get an Apache XMLSerializer configured to generate CDATA
					// XMLSerializer serializer = getXMLSerializer();

					// whf setear si la impresion es pretty o no isPrettyPrint()
					// ? Boolean.TRUE : Boolean.FALSE
					marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
					// marshaller.marshal(objeto,
					// serializer.asContentHandler());

					valorXML = "<![CDATA[" + buffer.toString() + "]]>";
					valorXML = buffer.toString();

				} catch (JAXBException e) {
					throw new Exception(e);
				} catch (XMLStreamException e) {
					throw new Exception(e);
				} catch (FactoryConfigurationError e) {
					throw new Exception(e);
				}

				DescripcionParametro descripParam = new DescripcionParametro(paramName, objeto.getClass().getName(), valorXML, codTipoOperacion);
				descripcionParametroList.put(paramName, descripParam);
			}
		} catch (Exception e) {
			throw new SystemInternalException("ERROR_EN_PARAMETROS_RESPUESTA", new Object[] { codTipoOperacion, paramName,
					objeto.getClass().getName(), e.getMessage() });
		}
	}

	/**
	 * Arma los parametros de respuesta que se debe retornar en el objeto
	 * msgsistemaresp.contenido seg�n el requerimiento de la operacion, para
	 * ello se discrimina por tipo de operacion valor contenido en
	 * descripcionParValor.getFormato
	 * 
	 * @param statusCode
	 * @param consent
	 */
	public void updateReponse(String statusCode, String consent) {
		init();
		log.debug("Actualizando response con statusCode: " + statusCode + " y descripci�n: " + consent);
		if (statusCode != null && !StatusCode.OPERACION_SUCCESS.equalsIgnoreCase(statusCode)) {
			if (consent == null) {
				consent = "Estado de la respuesta es " + statusCode + " pero sin descripcion del mismo. Comunique a sistemas";
			}
			// eliminar el resto de las descripciones de parametros
			descripcionParametroList.clear();
		}

		Aladiresponsetipo01Type aladiresponsetipo01Type = new Aladiresponsetipo01Type();
		Aladireqresptipo01Type aladireqresptipo01Type = new Aladireqresptipo01Type();
		JAXBElement<? extends Contenidotype> contenido = null;
		String tipoResponse = null;

		try {
			for (Iterator<?> i = descripcionParametroList.keySet().iterator(); i.hasNext();) {
				String key = (String) i.next();
				if (descripcionParametroList.get(key) != null) {
					Apertura apertura = null;
					Pago pago = null;
					Registro registro = null;
					Reganticipado regAnticipado = null;
					Planpago planPago = null;
					Listaregistros listaregistros = null;
					Listapagos listapagos = null;
					Listaplanpagos listaplanpagos = null;
					Listatpagoimport listatpagoimport = null;
					Listasaldoconvenio listasaldoconvenio = null;
					Listainstitucion listainstitucion = null;
					Listareganticipado listareganticipado = null;
					List<String> objetosList = null;
					String valorXML = null;

					DescripcionParametro descripcionParValor = descripcionParametroList.get(key);
					// segun el tipo de operacion se arma los beans que se debe
					// retornar en la respuesta
					if (descripcionParValor.getValue() instanceof Apertura) {
						apertura = (Apertura) descripcionParValor.getValue();
					} else if (descripcionParValor.getValue() instanceof Registro) {
						registro = (Registro) descripcionParValor.getValue();
					} else if (descripcionParValor.getValue() instanceof Pago) {
						pago = (Pago) descripcionParValor.getValue();
					} else if (descripcionParValor.getValue() instanceof Planpago) {
						planPago = (Planpago) descripcionParValor.getValue();
					} else if (descripcionParValor.getValue() instanceof Reganticipado) {
						regAnticipado = (Reganticipado) descripcionParValor.getValue();
					} else if (descripcionParValor.getValue() instanceof Listaregistros) {
						listaregistros = (Listaregistros) descripcionParValor.getValue();
					} else if (descripcionParValor.getValue() instanceof Listapagos) {
						listapagos = (Listapagos) descripcionParValor.getValue();
					} else if (descripcionParValor.getValue() instanceof Listaplanpagos) {
						listaplanpagos = (Listaplanpagos) descripcionParValor.getValue();
					} else if (descripcionParValor.getValue() instanceof Listatpagoimport) {
						listatpagoimport = (Listatpagoimport) descripcionParValor.getValue();
					} else if (descripcionParValor.getValue() instanceof Listasaldoconvenio) {
						listasaldoconvenio = (Listasaldoconvenio) descripcionParValor.getValue();
					} else if (descripcionParValor.getValue() instanceof Listainstitucion) {
						listainstitucion = (Listainstitucion) descripcionParValor.getValue();
					} else if (descripcionParValor.getValue() instanceof Listareganticipado) {
						listareganticipado = (Listareganticipado) descripcionParValor.getValue();
					} else if (descripcionParValor.getValue() instanceof List<?>) {
						objetosList = (List<String>) descripcionParValor.getValue();
					} else {
						// valorXML = (String) descripcionParValor.getValue();
					}

					// -----------------------------------------------------------------//
					if (apertura != null) {
						aladiresponsetipo01Type.setApertura(apertura);
						tipoResponse = aladiresponsetipo01Type.getClass().getName();
					} else if (registro != null) {
						aladiresponsetipo01Type.setRegistro(registro);
						tipoResponse = aladiresponsetipo01Type.getClass().getName();
					} else if (pago != null) {
						aladiresponsetipo01Type.setPago(pago);
						tipoResponse = aladiresponsetipo01Type.getClass().getName();
					} else if (planPago != null) {
						aladiresponsetipo01Type.setPlanpago(planPago);
						tipoResponse = aladiresponsetipo01Type.getClass().getName();
					} else if (listaregistros != null) {
						aladiresponsetipo01Type.setListaregistros(listaregistros);
						tipoResponse = aladiresponsetipo01Type.getClass().getName();
					} else if (listapagos != null) {
						aladiresponsetipo01Type.setListapagos(listapagos);
						tipoResponse = aladiresponsetipo01Type.getClass().getName();
					} else if (listaplanpagos != null) {
						aladiresponsetipo01Type.setListaplanpagos(listaplanpagos);
						tipoResponse = aladiresponsetipo01Type.getClass().getName();
						// -----------------------------------------------------------------//
					} else if (listatpagoimport != null) {
						aladireqresptipo01Type.setListatpagoimport(listatpagoimport);
						tipoResponse = aladireqresptipo01Type.getClass().getName();
					} else if (regAnticipado != null) {
						aladireqresptipo01Type.setReganticipado(regAnticipado);
						tipoResponse = aladireqresptipo01Type.getClass().getName();
					} else if (listasaldoconvenio != null) {
						aladireqresptipo01Type.setListasaldoconvenio(listasaldoconvenio);
						tipoResponse = aladireqresptipo01Type.getClass().getName();
					} else if (listainstitucion != null) {
						aladireqresptipo01Type.setListainstitucion(listainstitucion);
						tipoResponse = aladireqresptipo01Type.getClass().getName();
					} else if (listareganticipado != null) {
						aladireqresptipo01Type.setListareganticipado(listareganticipado);
						tipoResponse = aladireqresptipo01Type.getClass().getName();
						// -----------------------------------------------------------------//
					} else if (objetosList != null) {
						// al0103Type.getValor().addAll(objetosList);
						Valorcompuesto contenidotypeValorcompuesto = new Valorcompuesto();
						contenidotypeValorcompuesto.setTipovalor(descripcionParValor.getTipo());
						contenidotypeValorcompuesto.getValorreglon().addAll(objetosList);
						aladiresponsetipo01Type.getValorcompuesto().add(contenidotypeValorcompuesto);
						// whf analizar respuestas tipo xml incrustado
						// tipoResponse =
						// aladiresponsetipo01Type.getClass().getName();
					}
					/*
					 * else if (valorXML != null) {
					 * aladiresponsetipo01Type.getValor().add(valorXML);
					 * tipoResponse =
					 * aladireqresptipo01Type.getClass().getName(); }
					 */
				}
			}
		} catch (Exception e) {
			throw new SystemInternalException("ERROR_ACTUALIZANDO_PARAMS_RESPUESTA", new Object[] { e.getMessage() });

		}

		if (descripcionParametroList.size() > 0) {
			if (tipoResponse == null) {
				throw new SystemInternalException("ERROR_AL_GENERAR_RESPUESTA", new Object[] { descripcionParametroList.keySet().toString() });
			}
			ObjectFactory of = new ObjectFactory();
			if (tipoResponse.equals(aladiresponsetipo01Type.getClass().getName()))
				contenido = of.createAladiresponsetipo01(aladiresponsetipo01Type);
			else if (tipoResponse.equals(aladireqresptipo01Type.getClass().getName())) {
				contenido = of.createAladireqresptipo01(aladireqresptipo01Type);
			}
		}

		try {
			bcbResponse.updateMsgsistemaresp(statusCode, consent, contenido);
		} catch (Exception e) {
			throw new SystemInternalException("ERROR_AL_ACTUALIZAR_RESPUESTA", new Object[] { descripcionParametroList.keySet().toString() });
		}
	}

	public String objectBcbRequestToXML() {
		init();
		Map<String, DescripcionParametro> respuestas = new LinkedHashMap<String, DescripcionParametro>();
		int contador = 1;

		for (Iterator<?> answer = descripcionParametroList.keySet().iterator(); answer.hasNext();) {
			String key = (String) answer.next();
			if (descripcionParametroList.get(key) != null) {
				respuestas.put(String.valueOf(contador++), descripcionParametroList.get(key));
			}
		}

		String xml = null;
		try {
			// xml =
			// bcbResponse.stringFromObjectJAXB(bcbResponse.getMsgBcbresp());
			xml = bcbResponse.toString(bcbResponse.getMsgBcbresp());
		} catch (JAXBException e) {
			throw new SystemInternalException("ERROR_XML", new Object[] { e.getMessage() });
		} catch (ParserConfigurationException e) {
			throw new SystemInternalException("ERROR_XML", new Object[] { e.getMessage() });
		}
		return xml;

	}

	public void addTaskDescripAdicional(Map<String, Object> taskAdic) {
		if (taskAdic.size() == 0) {
			return;
		}

		init();
		List<String> msgsAdic = new ArrayList<String>();
		for (Iterator<?> i = taskAdic.keySet().iterator(); i.hasNext();) {
			String key = (String) i.next();
			msgsAdic.add((String) taskAdic.get(key));
		}
		bcbResponse.getMsgBcbresp().getMsgsistemaresp().setMsgsadicionales(msgsAdic.toString());
	}

	public static BcbResponse errorRequest(String statusCode, String consent) {
		log.error("!!!ERROR NO CONTROLADO: Generacion de mensaje de error " + statusCode + " - " + consent);

		// whf eliminar las contantes aladi
		BcbResponse respuesta = BcbResponse.Factory.createDefaultResponse("BCB", ConfigurationServ.getServiceName(), "no definido", "1", statusCode,
				consent, "No definido");

		return respuesta;
	}

	/**
	 * @param codTipoOperacion
	 *            the codTipoOperacion to set
	 */
	public void setCodTipoOperacion(String codTipoOperacion) {
		this.operacionAladi.setCodTipoOperacion(codTipoOperacion);
	}

	/**
	 * @return the codTipoOperacion
	 */
	public String getCodTipoOperacion() {
		if (operacionAladi.getCodTipoOperacion() == null) {
			operacionAladi.setCodTipoOperacion(bcbRequest.getIdTipoOperacion());
		}
		return operacionAladi.getCodTipoOperacion();
	}

	public void setOperacionAladi(OperacionAladi operacionAladi) {
		this.operacionAladi = operacionAladi;
	}

	public OperacionAladi getOperacionAladi() {
		return operacionAladi;
	}

	/**
	 * @return the initialized
	 */
	public boolean isInitialized() {
		return initialized;
	}

	/**
	 * @return the bcbResponse
	 */
	public BcbResponse getBcbResponse() {
		return bcbResponse;
	}

	public static void main(String[] args) {
		TPagoImp tPagoImp = new TPagoImp();

		try {
			JAXBContext context = JAXBContext.newInstance(TPagoImp.class);
			Marshaller marshaller = context.createMarshaller();
			Writer buffer = new StringWriter();
			XMLStreamWriter writer = XMLOutputFactory.newInstance().createXMLStreamWriter(buffer);
			// whf setear si la impresion es pretty o no isPrettyPrint() ?
			// Boolean.TRUE : Boolean.FALSE
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			marshaller.setProperty(Marshaller.JAXB_ENCODING, "ISO-8859-1");
			marshaller.marshal(tPagoImp, buffer);

			String xml = buffer.toString();
			System.out.println(xml);

			Unmarshaller u = context.createUnmarshaller();
			TPagoImp tPagoImp2 = (TPagoImp) u.unmarshal(new StringReader(xml));
			System.out.println(tPagoImp2.getNroReg());

		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (XMLStreamException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FactoryConfigurationError e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
