package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

/**
 * The persistent class for the usr_persona database table.
 * 
 */
@Entity
@Table(name = "usr_persona")
public class UsrPersona implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@EmbeddedId
	private UsrPersonaPK id;

	@Column(name = "cod_usuario_ha")
	private String codUsuarioHa;

	@Column(name = "cve_tipo_mod")
	private String cveTipoMod;

	@Column(name = "cve_vigente")
	private String cveVigente;

	private String estacion;

	@Column(name = "fecha_hora")
	private Date fechaHora;

	public UsrPersona() {
	}

	public UsrPersonaPK getId() {
		return this.id;
	}

	public void setId(UsrPersonaPK id) {
		this.id = id;
	}

	public String getCodUsuarioHa() {
		return this.codUsuarioHa;
	}

	public void setCodUsuarioHa(String codUsuarioHa) {
		this.codUsuarioHa = codUsuarioHa;
	}

	public String getCveTipoMod() {
		return this.cveTipoMod;
	}

	public void setCveTipoMod(String cveTipoMod) {
		this.cveTipoMod = cveTipoMod;
	}

	public String getCveVigente() {
		return this.cveVigente;
	}

	public void setCveVigente(String cveVigente) {
		this.cveVigente = cveVigente;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

}
