package gob.bcb.bpm.siraladi.logic;

import java.util.List;

import gob.bcb.bpm.siraladi.dao.UserTransactionServ;
import gob.bcb.bpm.siraladi.jpa.Institucion;

/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public interface InstitucionServiceLocal extends UserTransactionServ{

	List<Institucion> crearReg(List<Institucion> institucionListIn);

	/**
	 * Suspende las instituciones para asegurar las vigentes, proceso que se ejecuta antes de llamar a WS convenio Aladi
	 */
	void suspenderInstituciones();

}
