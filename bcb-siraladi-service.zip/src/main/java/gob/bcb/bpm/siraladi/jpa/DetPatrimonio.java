package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.math.BigDecimal;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the det_patrimonio database table.
 * 
 */
@Entity
@Table(name="det_patrimonio")
public class DetPatrimonio implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@EmbeddedId
	private DetPatrimonioPK id;

	@Column(name="cod_usuario")
	private String codUsuario;

	@Column(name="estacion")
	private String estacion;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="fecha_hora")
	private Date fechaHora;

	@Column(name="limite_max", precision=16, scale=2)
	private BigDecimal limiteMax;

	@Column(name="pat_actual", precision=16, scale=2)
	private BigDecimal patActual;

	@Column(name="pat_bs", precision=16, scale=2)
	private BigDecimal patBs;

	@Column(name="saldo_deudor", precision=16, scale=2)
	private BigDecimal saldoDeudor;

    public DetPatrimonio() {
    }

	public DetPatrimonioPK getId() {
		return this.id;
	}

	public void setId(DetPatrimonioPK id) {
		this.id = id;
	}
	
	public String getCodUsuario() {
		return this.codUsuario;
	}

	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public BigDecimal getLimiteMax() {
		return this.limiteMax;
	}

	public void setLimiteMax(BigDecimal limiteMax) {
		this.limiteMax = limiteMax;
	}

	public BigDecimal getPatActual() {
		return this.patActual;
	}

	public void setPatActual(BigDecimal patActual) {
		this.patActual = patActual;
	}

	public BigDecimal getPatBs() {
		return this.patBs;
	}

	public void setPatBs(BigDecimal patBs) {
		this.patBs = patBs;
	}

	public BigDecimal getSaldoDeudor() {
		return this.saldoDeudor;
	}

	public void setSaldoDeudor(BigDecimal saldoDeudor) {
		this.saldoDeudor = saldoDeudor;
	}
}
