package gob.bcb.bpm.siraladi.dao;

import java.util.List;



import gob.bcb.bpm.siraladi.jpa.SwfDetmensaje;
import gob.bcb.bpm.siraladi.jpa.SwfDetmensajePK;
import gob.bcb.bpm.siraladi.jpa.SwfMensaje;


public interface SwfDetmensajeLocal extends DAO<SwfDetmensajePK, SwfDetmensaje>{

	SwfDetmensaje findByCodigo(Integer demCodmen, Integer demNrocorr);

	List<SwfDetmensaje> findByCodMen(Integer demCodmen);

	SwfDetmensaje nuevoDetmensaje(SwfDetmensaje swfDetmensaje);

	SwfDetmensaje updateDetmensaje(SwfDetmensaje swfDetmensaje);

	List<SwfDetmensaje> actualizarDetalles(SwfMensaje swfMensaje, List<SwfDetmensaje> swfDetmensajeList);

	SwfDetmensaje saveorupdate(SwfMensaje swfMensaje, SwfDetmensaje swfDetmensaje);

	SwfDetmensaje findByCampo(Integer demCodmen, String demCodcampo, Integer demBloque);

	SwfDetmensaje actualizarCampo(Integer demCodmen, String demCodcampo, Integer demBloque, String demValor, String auditUsr, String auditWst);

}
