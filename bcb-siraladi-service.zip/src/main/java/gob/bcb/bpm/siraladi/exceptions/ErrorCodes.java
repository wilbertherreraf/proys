package gob.bcb.bpm.siraladi.exceptions;

/**
 * @author wherrera
 */
public class ErrorCodes {

	public static final String VERSION = "$Id: ErrorCodes.java 1 2011-07-30 12:11:31Z jre $";
    public static final ErrorCode RUNTIME_EXCEPTION = new ErrorCode("RUNTIME_EXCEPTION");
    public static final ErrorCode REMOTE_EXCEPTION = new ErrorCode("REMOTE_EXCEPTION");
    public static final ErrorCode WRAPPED_EXCEPTION = new ErrorCode("WRAPPED_EXCEPTION");
    public static final ErrorCode SERIALIZED_EXCEPTION = new ErrorCode("SERIALIZED_EXCEPTION");
    public static final ErrorCode OBJECT_NOT_FOUND = new ErrorCode("OBJECT_NOT_FOUND");
    public static final ErrorCode STARTUP_EXCEPTION = new ErrorCode("STARTUP_EXCEPTION");

    public static class ErrorCode {
        private String value;

        /**
         * Create a new <code>ErrorCode</code>
         * @param value The value of the error
         */
        public ErrorCode(String value) {
            this.value = value;
        }

        /**
         * @return The value of the error code
         */
        public String getValue() {
            return value;
        }
    }

}
