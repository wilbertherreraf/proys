
package gob.bcb.bpm.siraladi.ws.clientaladi.asicapcsbn;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for sdtSICAPCSBN.sdtSICAPCSBNItem complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="sdtSICAPCSBN.sdtSICAPCSBNItem">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="CodigoRpta" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="FechaAl" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="Convenio" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="NumeralA" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="SaldoA" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="NumeralB" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="SaldoB" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "sdtSICAPCSBN.sdtSICAPCSBNItem", propOrder = {

})
public class SdtSICAPCSBNSdtSICAPCSBNItem {

    @XmlElement(name = "CodigoRpta", required = true)
    protected String codigoRpta;
    @XmlElement(name = "FechaAl", required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar fechaAl;
    @XmlElement(name = "Convenio", required = true)
    protected String convenio;
    @XmlElement(name = "NumeralA")
    protected double numeralA;
    @XmlElement(name = "SaldoA")
    protected double saldoA;
    @XmlElement(name = "NumeralB")
    protected double numeralB;
    @XmlElement(name = "SaldoB")
    protected double saldoB;

    /**
     * Gets the value of the codigoRpta property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigoRpta() {
        return codigoRpta;
    }

    /**
     * Sets the value of the codigoRpta property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigoRpta(String value) {
        this.codigoRpta = value;
    }

    /**
     * Gets the value of the fechaAl property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getFechaAl() {
        return fechaAl;
    }

    /**
     * Sets the value of the fechaAl property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFechaAl(XMLGregorianCalendar value) {
        this.fechaAl = value;
    }

    /**
     * Gets the value of the convenio property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConvenio() {
        return convenio;
    }

    /**
     * Sets the value of the convenio property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConvenio(String value) {
        this.convenio = value;
    }

    /**
     * Gets the value of the numeralA property.
     * 
     */
    public double getNumeralA() {
        return numeralA;
    }

    /**
     * Sets the value of the numeralA property.
     * 
     */
    public void setNumeralA(double value) {
        this.numeralA = value;
    }

    /**
     * Gets the value of the saldoA property.
     * 
     */
    public double getSaldoA() {
        return saldoA;
    }

    /**
     * Sets the value of the saldoA property.
     * 
     */
    public void setSaldoA(double value) {
        this.saldoA = value;
    }

    /**
     * Gets the value of the numeralB property.
     * 
     */
    public double getNumeralB() {
        return numeralB;
    }

    /**
     * Sets the value of the numeralB property.
     * 
     */
    public void setNumeralB(double value) {
        this.numeralB = value;
    }

    /**
     * Gets the value of the saldoB property.
     * 
     */
    public double getSaldoB() {
        return saldoB;
    }

    /**
     * Sets the value of the saldoB property.
     * 
     */
    public void setSaldoB(double value) {
        this.saldoB = value;
    }

}
