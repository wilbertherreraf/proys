package gob.bcb.bpm.siraladi.service;

import java.util.List;
import java.util.Map;


import javax.persistence.EntityManager;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;

import org.apache.log4j.Logger;

import gob.bcb.bpm.siraladi.dao.DetPatrimonioBean;
import gob.bcb.bpm.siraladi.dao.EntityUserTransaction;
import gob.bcb.bpm.siraladi.dao.MovCoinBean;
import gob.bcb.bpm.siraladi.dao.MovCoinLocal;
import gob.bcb.bpm.siraladi.exceptions.AladiException;
import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.MovCoin;
import gob.bcb.bpm.siraladi.jpa.Registro;
import gob.bcb.bpm.siraladi.logic.AperturaServiceBean;
import gob.bcb.bpm.siraladi.logic.AperturaServiceLocal;
import gob.bcb.bpm.siraladi.logic.RegistroServiceBean;
import gob.bcb.bpm.siraladi.logic.RegistroServiceLocal;
import gob.bcb.bpm.siraladi.service.session.UserSessionHolder;
import gob.bcb.bpm.siraladi.utils.Constants;
import gob.bcb.bpm.siraladi.utils.StatusCode;

/**
 * @author wilherrera Wilbert Herrera Flores Banco Central de Bolivia
 *         Departamento de Desarrollo
 */
public class RegistroServiceHandler implements ServiceAladiHandler {
	private static Logger log = Logger.getLogger(RegistroServiceHandler.class);

	RegistroServiceLocal registroService;
	AperturaServiceLocal aperturaService;
	EntityManager entityManager;

	public RegistroServiceHandler(EntityManager entityManager) {
		log.debug("Creando RegistroServiceHandler ");
		aperturaService = new AperturaServiceBean(entityManager);
		registroService = new RegistroServiceBean(entityManager);
		this.entityManager = entityManager;

	}

	
	public void handlerProcesarMsg(RequestContext requestContext) throws AladiException, SecurityException, IllegalStateException, RollbackException,
			HeuristicMixedException, HeuristicRollbackException, SystemException, NotSupportedException {
		String statusCode = StatusCode.OPERACION_RECEIVED;
		String consent = null;

		Map<String, Object> parametros = requestContext.getBcbRequest().getRequestElements();

		String codTipoOperacion = requestContext.getResponseContext().getOperacionAladi().getCodTipoOperacion();

		ResponseContext response = requestContext.getResponseContext();

		log.info("inicio tipo de operacion " + codTipoOperacion);

		if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0201)) {
			// crear nuevo transaccion registro
			Apertura apertura = (Apertura) parametros.get("apertura");
			Registro registro = (Registro) parametros.get("registro");

			registroService.begin();

			Apertura aperturaOld = aperturaService.getAperturaLocal().findByCodReembolso(apertura.getInstitucion().getCodInst(),
					apertura.getIdentificador().getCodId(), apertura.getAnio(), apertura.getSecuencia(), apertura.getDav());

			if (aperturaOld == null) {
				throw new AladiException("REEMBOLSO_INEXISTENTE", new Object[] { apertura.getNroReembLiteral() });
			}

			registro = registroService.crearReg(registro, aperturaOld);
			response.addDescripcionParametro(codTipoOperacion, "registro", "Custom", registro);
			response.addDescripcionParametro(codTipoOperacion, "apertura", "Custom", aperturaOld);

			response.addTaskDescripAdicional(registroService.getWarnnings());
			registroService.commit();

			log.info("Transaccion Registro nroMov " + registro.getNroMov() + " creada satisfactoriamente");
			statusCode = StatusCode.OPERACION_SUCCESS;
			consent = "Operacion efectuada existosamente Registro nroMov : " + registro.getNroMov();

		} else if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0202)) {
			// modificacion
			Apertura apertura = (Apertura) parametros.get("apertura");
			Registro registro = (Registro) parametros.get("registro");

			registroService.begin();

			Apertura aperturaOld = aperturaService.getAperturaLocal().findByCodReembolso(apertura.getInstitucion().getCodInst(),
					apertura.getIdentificador().getCodId(), apertura.getAnio(), apertura.getSecuencia(), apertura.getDav());

			if (aperturaOld == null) {
				throw new AladiException("REEMBOLSO_INEXISTENTE", new Object[] { apertura.getNroReembLiteral() });
			}
			
			registro = registroService.modificar(registro, aperturaOld, "X");

			// registro a los WS en la central peru Peru, se marca como modificacion
			//registroService.registroWSPorImporExport(registro, aperturaOld, "X");
			registroService.getRegistroLocal().flush();
			response.addTaskDescripAdicional(registroService.getWarnnings());
			registroService.commit();
			statusCode = StatusCode.OPERACION_SUCCESS;
			consent = "Operacion efectuada existosamente Registro nroMov : " + registro.getNroMov();
			
			response.addDescripcionParametro(codTipoOperacion, "apertura", "Custom", apertura);			
			response.addDescripcionParametro(codTipoOperacion, "registro", "Custom", registro);
			
			try {
				// segmento que actualiza el saldo de la institucion pero que no
				// debería afectar al resultado de la transaccion
				registroService.begin();
				DetPatrimonioBean detPatrimonioBean = new DetPatrimonioBean();
				detPatrimonioBean.setEntityManager(entityManager);

				detPatrimonioBean.actualizarSaldoIFA((String) UserSessionHolder.get("personaRevisada"));
				registroService.commit();
			} catch (Exception e) {
				log.error("Error al actualizar saldo deudor" + e.getMessage(), e);
			}

		} else if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0203)) {
			// consulta de registros por apertura
			Apertura apertura = (Apertura) parametros.get("apertura");

			Apertura aperturaOut = aperturaService.getAperturaLocal().findByCodReembolso(apertura.getInstitucion().getCodInst(),
					apertura.getIdentificador().getCodId(), apertura.getAnio(), apertura.getSecuencia(), apertura.getDav());
			response.addDescripcionParametro(codTipoOperacion, "apertura", "Custom", aperturaOut);

			if (aperturaOut == null) {
				throw new AladiException("REEMBOLSO_INEXISTENTE", new Object[] { apertura.getNroReembLiteral() });
			}

			List<Registro> registroList = registroService.getRegistroLocal().getByNroMovApeCveEstadoReg(aperturaOut.getNroMov(), null);
			response.addDescripcionParametro(codTipoOperacion, "listaregistros", "Custom", registroList);

			statusCode = StatusCode.OPERACION_SUCCESS;
			consent = "Operacion efectuada existosamente nroMov : " + aperturaOut.getNroMov();

		} else if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0204)) {
			// operaion destinada al cliente WS, sistema externo que llama al
			// servicio bcb cliente WS
			//hasta fecha 3/2012 no se usa
			Apertura apertura = (Apertura) parametros.get("apertura");
			Registro registro = (Registro) parametros.get("registro");
			registroService.begin();
			
			Apertura aperturaOld = aperturaService.getAperturaLocal().findByCodReembolso(apertura.getInstitucion().getCodInst(),
					apertura.getIdentificador().getCodId(), apertura.getAnio(), apertura.getSecuencia(), apertura.getDav());

			if (aperturaOld == null) {
				throw new AladiException("REEMBOLSO_INEXISTENTE", new Object[] { apertura.getNroReembLiteral() });
			}

			Registro registroNew = registroService.crearReg(registro, aperturaOld);
			// seteo para contabilizacion directa
			registro.setCveEstadoReg("C");
			registroNew = registroService.modificar(registro, apertura, "X");

			// registro a los WS en la central peru Peru
			//registroService.registroWSPorImporExport(registroNew, aperturaOld, "X");

			response.addTaskDescripAdicional(registroService.getWarnnings());

			registroService.commit();
			statusCode = StatusCode.OPERACION_SUCCESS;
			consent = "Operacion efectuada existosamente Registro nroMov : " + registroNew.getNroMov();
		} else if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0205)) {
			//eliminar registro
			Apertura apertura = (Apertura) parametros.get("apertura");
			Registro registro = (Registro) parametros.get("registro");

			registroService.begin();

			Apertura aperturaOld = aperturaService.getAperturaLocal().findByCodReembolso(apertura.getInstitucion().getCodInst(),
					apertura.getIdentificador().getCodId(), apertura.getAnio(), apertura.getSecuencia(), apertura.getDav());

			if (aperturaOld == null) {
				throw new AladiException("REEMBOLSO_INEXISTENTE", new Object[] { apertura.getNroReembLiteral() });
			}
			registroService.eliminar(registro, aperturaOld);
			registroService.commit();

			statusCode = StatusCode.OPERACION_SUCCESS;
			consent = "Operacion eliminada existosamente Registro nroMov : " + registro.getNroMov();
		} else {
			throw new AladiException("TIPO_DE_OPERACION_NO_IMPLEMENTADA", new Object[] { requestContext.getResponseContext().getOperacionAladi()
					.getCodTipoOperacion() });
		}
		response.updateReponse(statusCode, consent);
		log.info("Operacion realizada exitosamente operacion " + codTipoOperacion);
	}
}
