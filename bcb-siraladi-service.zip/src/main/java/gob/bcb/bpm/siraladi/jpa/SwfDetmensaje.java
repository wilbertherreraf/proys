package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;


/**
 * The persistent class for the swf_detmensaje database table.
 * 
 */
@Entity
@Table(name="swf_detmensaje")
public class SwfDetmensaje implements Serializable{
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SwfDetmensajePK id;

	@Column(name="dem_codcampo")
	private String demCodcampo;

	@Column(name="dem_bloque")
	private Integer demBloque;
	
	@Column(name="dem_valor")
	private String demValor;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "dem_auditfho")
	private Date demAuditfho;

	@Column(name = "dem_auditusr")
	private String demAuditusr;

	@Column(name = "dem_auditwst")
	private String demAuditwst;

	public SwfDetmensaje() {
	}

	public SwfDetmensajePK getId() {
		return this.id;
	}

	public void setId(SwfDetmensajePK id) {
		this.id = id;
	}

	public String getDemValor() {
		return this.demValor;
	}

	public void setDemValor(String demValor) {
		this.demValor = demValor;
	}

	public String getDemCodcampo() {
		return demCodcampo;
	}

	public void setDemCodcampo(String demCodcampo) {
		this.demCodcampo = demCodcampo;
	}

	public Integer getDemBloque() {
		return demBloque;
	}

	public void setDemBloque(Integer demBloque) {
		this.demBloque = demBloque;
	}

	public Date getDemAuditfho() {
		return demAuditfho;
	}

	public void setDemAuditfho(Date demAuditfho) {
		this.demAuditfho = demAuditfho;
	}

	public String getDemAuditusr() {
		return demAuditusr;
	}

	public void setDemAuditusr(String demAuditusr) {
		this.demAuditusr = demAuditusr;
	}

	public String getDemAuditwst() {
		return demAuditwst;
	}

	public void setDemAuditwst(String demAuditwst) {
		this.demAuditwst = demAuditwst;
	}

}