package gob.bcb.bpm.siraladi.jpa;

import gob.bcb.bpm.siraladi.utils.UtilsDate;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.Date;

/**
 * The persistent class for the reg_anticipado database table.
 * 
 */
@Entity
@Table(name = "reg_anticipado")
public class RegAnticipado implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "nro_mov", unique = true, nullable = false)
	private Integer nroMov;

	@Column(length = 4)
	private String anio;

	@Column(name = "cod_id", nullable = false)
	private String codId;

	@Column(name = "cod_inst", nullable = false)
	private String codInst;

	@Column(name = "cod_inst_recep")
	private String codInstRecep;

	@Column(name = "cod_instrumento")
	private String codInstrumento;

	@Column(name = "cod_moneda")
	private String codMoneda;

	@Column(name = "cod_usuario")
	private String codUsuario;

	@Column(name = "cve_estado_ant", length = 1)
	private String cveEstadoAnt;

	@Column(name = "cve_tipo_ape", length = 1)
	private String cveTipoApe;

	@Column(nullable = false)
	private Integer dav;

	@Column(name = "debe_mo", precision = 15, scale = 2)
	private BigDecimal debeMo;

	@Column(length = 30)
	private String estacion;

	@Temporal(TemporalType.DATE)
	@Column(name = "fecha_cargo")
	private Date fechaCargo;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "fecha_hora")
	private Date fechaHora;

	@Temporal(TemporalType.DATE)
	@Column(name = "fecha_val")
	private Date fechaVal;

	@Column(name = "haber_mo", precision = 15, scale = 2)
	private BigDecimal haberMo;

	@Column(name = "nro_debito")
	private Integer nroDebito;

	@Column(name = "nro_reembolso")
	private String nroReembolso;

	private Integer nror;

	@Column(nullable = false, length = 6)
	private String secuencia;

	public RegAnticipado() {
	}

	public RegAnticipado(Integer nroMov, String anio, String codId, String codInst, String codInstRecep, String codInstrumento, String codMoneda,
			String codUsuario, String cveEstadoAnt, String cveTipoApe, Integer dav, BigDecimal debeMo, String estacion, Date fechaCargo,
			Timestamp fechaHora, Date fechaVal, BigDecimal haberMo, Integer nroDebito, Integer nror, String secuencia) {
		this.nroMov = nroMov;
		this.anio = anio;
		this.codId = codId;
		this.codInst = codInst;
		this.codInstRecep = codInstRecep;
		this.codInstrumento = codInstrumento;
		this.codMoneda = codMoneda;
		this.codUsuario = codUsuario;
		this.cveEstadoAnt = cveEstadoAnt;
		this.cveTipoApe = cveTipoApe;
		this.dav = dav;
		this.debeMo = debeMo;
		this.estacion = estacion;
		this.fechaCargo = fechaCargo;
		this.fechaHora = fechaHora;
		this.fechaVal = fechaVal;
		this.haberMo = haberMo;
		this.nroDebito = nroDebito;
		this.secuencia = secuencia;
	}

	public RegAnticipado(gob.bcb.siraladi.xml.model.Reganticipado reganticipado) {
		this.nroMov = reganticipado.getNroMov();
		this.anio = reganticipado.getAnio();
		this.codId = reganticipado.getCodId();
		this.codInst = reganticipado.getCodInst();
		this.codInstRecep = reganticipado.getCodInstRecep();
		this.codInstrumento = reganticipado.getCodInstrumento();
		this.codMoneda = reganticipado.getCodMoneda();
		this.cveEstadoAnt = reganticipado.getCveEstadoAnt();
		this.cveTipoApe = reganticipado.getCveTipoApe();
		this.dav = reganticipado.getDav();
		this.debeMo = reganticipado.getDebeMo();
		try {
			this.fechaCargo = reganticipado.getFechaCargo().toGregorianCalendar().getTime();
		} catch (Exception e) {
		}
		try {
			this.fechaVal = reganticipado.getFechaVal().toGregorianCalendar().getTime();
		} catch (Exception e) {
		}
		this.haberMo = reganticipado.getHaberMo();
		this.nroDebito = reganticipado.getNroDebito();
		this.secuencia = reganticipado.getSecuencia();
	}

	public gob.bcb.siraladi.xml.model.Reganticipado getObjectJAXB() {
		gob.bcb.siraladi.xml.model.Reganticipado reganticipado = new gob.bcb.siraladi.xml.model.Reganticipado();
		reganticipado.setNroMov(nroMov);
		reganticipado.setAnio(anio);
		reganticipado.setCodId(codId);
		reganticipado.setCodInst(codInst);
		reganticipado.setCodInstRecep(codInstRecep);
		reganticipado.setCodInstrumento(codInstrumento);
		reganticipado.setCodMoneda(codMoneda);
		reganticipado.setCveEstadoAnt(cveEstadoAnt);
		reganticipado.setCveTipoApe(cveTipoApe);
		reganticipado.setDav(dav);
		reganticipado.setDebeMo(debeMo);
		try {
			reganticipado.setFechaCargo(UtilsDate.StrToXMLGregoCal(UtilsDate.stringFromDate(fechaCargo, "yyyy-MM-dd"), "-"));
		} catch (Exception e) {
		}
		try {
			reganticipado.setFechaVal(UtilsDate.StrToXMLGregoCal(UtilsDate.stringFromDate(fechaVal, "yyyy-MM-dd"), "-"));
		} catch (Exception e) {
		}
		reganticipado.setHaberMo(haberMo);
		reganticipado.setNroDebito(nroDebito);
		reganticipado.setSecuencia(secuencia);
		return reganticipado;
	}

	public Integer getNroMov() {
		return this.nroMov;
	}

	public void setNroMov(Integer nroMov) {
		this.nroMov = nroMov;
	}

	public String getAnio() {
		return this.anio;
	}

	public void setAnio(String anio) {
		this.anio = anio;
	}

	public String getCodId() {
		return this.codId;
	}

	public void setCodId(String codId) {
		this.codId = codId;
	}

	public String getCodInst() {
		return this.codInst;
	}

	public void setCodInst(String codInst) {
		this.codInst = codInst;
	}

	public String getCodInstRecep() {
		return this.codInstRecep;
	}

	public void setCodInstRecep(String codInstRecep) {
		this.codInstRecep = codInstRecep;
	}

	public String getCodInstrumento() {
		return this.codInstrumento;
	}

	public void setCodInstrumento(String codInstrumento) {
		this.codInstrumento = codInstrumento;
	}

	public String getCodMoneda() {
		return this.codMoneda;
	}

	public void setCodMoneda(String codMoneda) {
		this.codMoneda = codMoneda;
	}

	public String getCodUsuario() {
		return this.codUsuario;
	}

	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}

	public String getCveEstadoAnt() {
		return this.cveEstadoAnt;
	}

	public void setCveEstadoAnt(String cveEstadoAnt) {
		this.cveEstadoAnt = cveEstadoAnt;
	}

	public String getCveTipoApe() {
		return this.cveTipoApe;
	}

	public void setCveTipoApe(String cveTipoApe) {
		this.cveTipoApe = cveTipoApe;
	}

	public Integer getDav() {
		return this.dav;
	}

	public void setDav(Integer dav) {
		this.dav = dav;
	}

	public BigDecimal getDebeMo() {
		return this.debeMo;
	}

	public void setDebeMo(BigDecimal debeMo) {
		this.debeMo = debeMo;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaCargo() {
		return this.fechaCargo;
	}

	public void setFechaCargo(Date fechaCargo) {
		this.fechaCargo = fechaCargo;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public Date getFechaVal() {
		return this.fechaVal;
	}

	public void setFechaVal(Date fechaVal) {
		this.fechaVal = fechaVal;
	}

	public BigDecimal getHaberMo() {
		return this.haberMo;
	}

	public void setHaberMo(BigDecimal haberMo) {
		this.haberMo = haberMo;
	}

	public Integer getNroDebito() {
		return this.nroDebito;
	}

	public void setNroDebito(Integer nroDebito) {
		this.nroDebito = nroDebito;
	}

	public Integer getNror() {
		return this.nror;
	}

	public void setNror(Integer nror) {
		this.nror = nror;
	}

	public String getSecuencia() {
		return this.secuencia;
	}

	public void setSecuencia(String secuencia) {
		this.secuencia = secuencia;
	}

	public String getNroReembLiteral(boolean formatoLineal) {
		if (formatoLineal)
			return getNroReembLiteral(new boolean[] { formatoLineal });
		return getNroReembLiteral();
	}

	public String getNroReembLiteral(boolean... params) {
		String separador = "";
		if (params.length == 0) {
			separador = "-";
		}
		String nroReembolso = String.format("%04d", (codInst != null ? Integer.valueOf(codInst.trim()) : 0)).concat(separador);
		nroReembolso = nroReembolso.concat(String.format("%01d", (codId != null ? Integer.valueOf(codId.trim()) : 0))).concat(separador);
		nroReembolso = nroReembolso.concat(String.format("%04d", (anio != null ? Integer.valueOf(anio.trim()) : 0))).concat(separador);
		nroReembolso = nroReembolso.concat(String.format("%06d", (secuencia != null ? Integer.valueOf(secuencia.trim()) : 0))).concat(separador);
		nroReembolso = nroReembolso.concat(String.format("%01d", (dav != null ? dav : 0)));
		return nroReembolso;
	}

	public String getCodigoReembolso() {
		String codReembolso = null;
		try {
			codReembolso = getNroReembLiteral(true);
		} catch (Exception e) {
			;
		}
		return codReembolso;
	}
	public String getCodigoReembolsoLit() {
		String codReembolso = null;
		try {
			codReembolso = getNroReembLiteral();
		} catch (Exception e) {
			;
		}
		return codReembolso;
	}
	public void setNroReembolso(String nroReembolso) {
		this.nroReembolso = nroReembolso;
	}

	public String getNroReembolso() {
		return nroReembolso;
	}

}