package gob.bcb.bpm.siraladi.jpa;

import gob.bcb.bpm.siraladi.utils.UtilsDate;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.persistence.Column;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the plan_pago database table.
 * 
 */
@Entity
@Table(name = "plan_pago")
public class PlanPago implements Serializable, Comparable<PlanPago> {

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private PlanPagoPK id;

	@Column(precision = 15, scale = 2)
	private BigDecimal capital = BigDecimal.ZERO;

	@Temporal(TemporalType.DATE)
	@Column(name = "fecha_neg")
	private Date fechaNeg;

	@Temporal(TemporalType.DATE)
	@Column(name = "fecha_val")
	private Date fechaVal;

	@Column(precision = 15, scale = 2)
	private BigDecimal interes = BigDecimal.ZERO;

	@Column(precision = 15, scale = 2)
	private BigDecimal monto = BigDecimal.ZERO;

	@Column(name = "cve_estado_plan")
	private String cveEstadoPlan;

	@Temporal(TemporalType.DATE)
	@Column(name = "fechora_regaladi")
	private Date fechoraRegaladi;

	@Column(name = "nro_mov_k")
	private Integer nroMovK;

	@Column(name = "nro_mov_i")
	private Integer nroMovI;

	@Column(name = "nro_sec_reemb")
	private Integer nroSecReemb;
	
	@Column(name = "cod_usuario")
	private String codUsuario;

	@Column(name = "estacion")
	private String estacion;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "fecha_hora")
	private Date fechaHora;
	
	public PlanPago() {
	}

	public PlanPago(gob.bcb.siraladi.xml.model.Planpago planpago) {
		PlanPagoPK id = new PlanPagoPK();
		id.setNroMov((planpago.getNromov() == null ? 0 : planpago.getNromov()));
		id.setNroPlan((planpago.getNroplan() == null ? 0 : planpago.getNroplan()));
		this.id = id;
		this.capital = (planpago.getCapital() == null ? BigDecimal.ZERO : planpago.getCapital());
		this.interes = (planpago.getInteres() == null ? BigDecimal.ZERO : planpago.getInteres());
		this.cveEstadoPlan = planpago.getEstadoplan();
		try {
			this.fechaVal = planpago.getFechaval().toGregorianCalendar().getTime();
		} catch (Exception e) {
		}
		try {
			this.fechaNeg = planpago.getFechaneg().toGregorianCalendar().getTime();
		} catch (Exception e) {
		}

		this.monto = this.capital.add(this.interes);
	}

	public gob.bcb.siraladi.xml.model.Planpago getObjectJAXB() {
		gob.bcb.siraladi.xml.model.Planpago planpago = new gob.bcb.siraladi.xml.model.Planpago();
		planpago.setNromov(id.getNroMov());
		planpago.setNroplan(id.getNroPlan());
		try {
			planpago.setFechaval(UtilsDate.StrToXMLGregoCal(UtilsDate.stringFromDate(fechaVal, "yyyy-MM-dd"), "-"));
		} catch (Exception e) {
		}
		try {
			planpago.setFechaneg(UtilsDate.StrToXMLGregoCal(UtilsDate.stringFromDate(fechaNeg, "yyyy-MM-dd"), "-"));
		} catch (Exception e) {
		}
		planpago.setCapital(capital);
		planpago.setInteres(interes);
		planpago.setEstadoplan(cveEstadoPlan);
		return planpago;
	}

	public PlanPagoPK getId() {
		return this.id;
	}

	public void setId(PlanPagoPK id) {
		this.id = id;
	}

	public BigDecimal getCapital() {
		return (this.capital == null ? BigDecimal.ZERO : this.capital);
	}

	public void setCapital(BigDecimal capital) {
		this.capital = capital;
	}

	public void setFechaNeg(Date fechaNeg) {
		this.fechaNeg = fechaNeg;
	}

	public Date getFechaNeg() {
		return fechaNeg;
	}

	public Date getFechaVal() {
		return this.fechaVal;
	}

	public void setFechaVal(Date fechaVal) {
		this.fechaVal = fechaVal;
	}

	public BigDecimal getInteres() {
		return (this.interes == null ? BigDecimal.ZERO : this.interes);
	}

	public void setInteres(BigDecimal interes) {
		this.interes = interes;
	}

	public BigDecimal getMonto() {
		this.monto = getCapital().add(getInteres());
		return this.monto;
	}

	public void setMonto(BigDecimal monto) {
		this.monto = monto;
	}

	public void setCveEstadoPlan(String cveEstadoPlan) {
		this.cveEstadoPlan = cveEstadoPlan;
	}

	public String getCveEstadoPlan() {
		return cveEstadoPlan;
	}

	public void setFechoraRegaladi(Date fechoraRegaladi) {
		this.fechoraRegaladi = fechoraRegaladi;
	}

	public Date getFechoraRegaladi() {
		return fechoraRegaladi;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	
	public int compareTo(PlanPago o) {
		int comp = 0;
		if (this.fechaVal.before(o.getFechaVal()))
			comp = -1;
		else if (this.fechaVal.after(o.getFechaVal()))
			comp = 1;
		return comp;
	}

	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}

	public String getCodUsuario() {
		return codUsuario;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public String getEstacion() {
		return estacion;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public Date getFechaHora() {
		return fechaHora;
	}

	public void setNroMovK(Integer nroMovK) {
		this.nroMovK = nroMovK;
	}

	public Integer getNroMovK() {
		return nroMovK;
	}

	public void setNroMovI(Integer nroMovI) {
		this.nroMovI = nroMovI;
	}

	public Integer getNroMovI() {
		return nroMovI;
	}

	public void setNroSecReemb(Integer nroSecReemb) {
		this.nroSecReemb = nroSecReemb;
	}

	public Integer getNroSecReemb() {
		return nroSecReemb;
	}

}
