package gob.bcb.bpm.siraladi.jpa;

import gob.bcb.bpm.siraladi.utils.UtilsDate;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.ManyToOne;

/**
 * The persistent class for the pago database table.
 * 
 */
@Entity
@Table(name = "pago")
public class Pago implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "nro_mov", unique = true, nullable = false)
	private Integer nroMov;

	@Column(name = "cod_usuario", length = 5)
	private String codUsuario;

	@Column(name = "cve_estado_pago", length = 1)
	private String cveEstadoPago;

	@Column(name = "debe_mo", precision = 15, scale = 2)
	private BigDecimal debeMo;

	@Column(name = "estacion")
	private String estacion;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "fecha_cargo")
	private Date fechaCargo;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "fecha_hora")
	private Date fechaHora;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "fecha_reg")
	private Date fechaReg;

	@Column(name = "haber_mo", precision = 15, scale = 2)
	private BigDecimal haberMo;

	@Column(name = "nro_debito")
	private Integer nroDebito;

	@Column(name = "nit")
	private String nit;

	@Column(name = "nro_extorno")
	private String nroExtorno;

	@Column(name = "glosa")
	private String glosa;
	
	@Column(name = "nro_mov_ape", nullable = false)
	private Integer nroMovApe;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "horaingdebito")
	private Date horaingdebito;

	@Column(name = "nro_sec_reemb")
	private Integer nroSecReemb;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "cod_inst_recep")
	private Institucion institucion;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "cod_instrumento")
	private Instrumento instrumento;

	public Pago() {
	}

	public Pago(gob.bcb.siraladi.xml.model.Pago pago) {
		this.nroMov= pago.getNromov();
		this.cveEstadoPago = pago.getEstadotrans();
		this.debeMo = pago.getDebe();
		this.haberMo = pago.getHaber();
		this.nit = pago.getNit();
		try {
			this.fechaCargo = pago.getFechatrans().toGregorianCalendar().getTime();
		} catch (Exception e) {
		}
		try {
			this.fechaReg = pago.getFechatrans().toGregorianCalendar().getTime();
		} catch (Exception e) {
		}

		this.institucion = new Institucion();
		this.institucion.setCodInst(pago.getCodinstrecep());
		this.instrumento = new Instrumento();
		this.instrumento.setCodInstrumento(pago.getCodinstrumento());
		this.glosa = pago.getGlosa();
	}
	public gob.bcb.siraladi.xml.model.Pago getObjectJAXB(){
		gob.bcb.siraladi.xml.model.Pago pago = new gob.bcb.siraladi.xml.model.Pago();
		pago.setNromov(nroMov);
		pago.setCodinstrumento(instrumento.getCodInstrumento());
		pago.setCodinstrecep(institucion.getCodInst());
		pago.setDebe(debeMo);
		pago.setHaber(haberMo);
		pago.setEstadotrans(cveEstadoPago);
		try {
			if (fechaReg != null)
				pago.setFechatrans(UtilsDate.StrToXMLGregoCal(UtilsDate.stringFromDate(fechaReg, "yyyy-MM-dd"), "-"));
		} catch (Exception e) {
		}
		pago.setGlosa(glosa);
		pago.setNit(nit);		
		return pago;
	}
	public Integer getNroMov() {
		return this.nroMov;
	}

	public void setNroMov(Integer nroMov) {
		this.nroMov = nroMov;
	}

	public String getCodUsuario() {
		return this.codUsuario;
	}

	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}

	public String getCveEstadoPago() {
		return this.cveEstadoPago;
	}

	public void setCveEstadoPago(String cveEstadoPago) {
		this.cveEstadoPago = cveEstadoPago;
	}

	public BigDecimal getDebeMo() {
		return this.debeMo;
	}

	public void setDebeMo(BigDecimal debeMo) {
		this.debeMo = debeMo;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaCargo() {
		return this.fechaCargo;
	}

	public void setFechaCargo(Date fechaCargo) {
		this.fechaCargo = fechaCargo;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public Date getFechaReg() {
		return this.fechaReg;
	}

	public void setFechaReg(Date fechaReg) {
		this.fechaReg = fechaReg;
	}

	public BigDecimal getHaberMo() {
		return this.haberMo;
	}

	public void setHaberMo(BigDecimal haberMo) {
		this.haberMo = haberMo;
	}

	public Integer getNroDebito() {
		return this.nroDebito;
	}

	public void setNroDebito(Integer nroDebito) {
		this.nroDebito = nroDebito;
	}

	public void setNit(String nit) {
		this.nit = nit;
	}

	public String getNit() {
		return nit;
	}

	public String getNroExtorno() {
		return this.nroExtorno;
	}

	public void setNroExtorno(String nroExtorno) {
		this.nroExtorno = nroExtorno;
	}

	public Integer getNroMovApe() {
		return this.nroMovApe;
	}

	public void setNroMovApe(Integer nroMovApe) {
		this.nroMovApe = nroMovApe;
	}

	public Institucion getInstitucion() {
		return this.institucion;
	}

	public void setInstitucion(Institucion institucion) {
		this.institucion = institucion;
	}

	public Instrumento getInstrumento() {
		return this.instrumento;
	}

	public void setInstrumento(Instrumento instrumento) {
		this.instrumento = instrumento;
	}

	public void setHoraingdebito(Date horaingdebito) {
		this.horaingdebito = horaingdebito;
	}

	public Date getHoraingdebito() {
		return horaingdebito;
	}

	public void setNroSecReemb(Integer nroSecReemb) {
		this.nroSecReemb = nroSecReemb;
	}

	public Integer getNroSecReemb() {
		return nroSecReemb;
	}	
	public void setGlosa(String glosa) {
		this.glosa = glosa;
	}

	public String getGlosa() {
		return glosa;
	}

	@Override
	public String toString() {
		return "Pago [nroMov=" + nroMov + ", codUsuario=" + codUsuario + ", cveEstadoPago=" + cveEstadoPago
				+ ", debeMo=" + debeMo + ", estacion=" + estacion + ", fechaCargo=" + fechaCargo + ", fechaHora="
				+ fechaHora + ", fechaReg=" + fechaReg + ", haberMo=" + haberMo + ", nroDebito=" + nroDebito + ", nit="
				+ nit + ", nroExtorno=" + nroExtorno + ", glosa=" + glosa + ", nroMovApe=" + nroMovApe
				+ ", horaingdebito=" + horaingdebito + ", nroSecReemb=" + nroSecReemb + ", institucion=" + institucion
				+ ", instrumento=" + instrumento + "]";
	}


}
