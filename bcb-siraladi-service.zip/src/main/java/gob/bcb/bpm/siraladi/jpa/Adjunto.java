/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-web-sirAladi
 * gob.bcb.bpm.siraladi.jpa.Adjunto
 * 23/11/2011 - 10:35:30
 * Creado por wherrera
 */
package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author wherrera 
 */

@Entity
@Table(name="adjunto")

public class Adjunto implements Serializable
{
	
	@Id
	@Column(name= "nro_mov", unique=true, nullable=false)
	private Integer nroMov;
	
	@Column(name = "cve_tipo_mov")
	private String cveTipoMov;
	
	@Column(name = "ruta_archivo")
	private String rutaArchivo;
	
	@Column(name = "cve_tipo_mime")
	private String cveTipoMime;

	public Integer getNroMov()
	{
		return nroMov;
	}

	public void setNroMov(Integer nroMov)
	{
		this.nroMov = nroMov;
	}

	public String getCveTipoMov()
	{
		return cveTipoMov;
	}

	public void setCveTipoMov(String cveTipoMov)
	{
		this.cveTipoMov = cveTipoMov;
	}

	public String getRutaArchivo()
	{
		return rutaArchivo;
	}

	public void setRutaArchivo(String rutaArchivo)
	{
		this.rutaArchivo = rutaArchivo;
	}

	public String getCveTipoMime()
	{
		return cveTipoMime;
	}

	public void setCveTipoMime(String cveTipoMime)
	{
		this.cveTipoMime = cveTipoMime;
	}
	public String getNombreArchivo() {
		int pos = rutaArchivo.lastIndexOf("\\");
		if (pos == -1)
			pos = rutaArchivo.lastIndexOf("/");
		return rutaArchivo.substring(1 + pos).replace(' ', '_');
	}

}
