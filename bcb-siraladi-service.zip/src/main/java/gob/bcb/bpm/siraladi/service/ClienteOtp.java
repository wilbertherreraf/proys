package gob.bcb.bpm.siraladi.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import gob.bcb.bpm.siraladi.pojo.OTPResponse;

public class ClienteOtp {
	private final Logger log = LoggerFactory.getLogger(ClienteOtp.class);	
	private final String urlBase;
	private final RestTemplate template;
	protected static ObjectMapper mapper;
	
	public final static String URL_PARAMS = "?user={user}&otp={otp}";
	public final static String OTP_CODE_SUCCESS = "0";	

	public ClienteOtp(String urlBase) {
		this.urlBase = urlBase;
		template = new RestTemplate();
		
		if (mapper == null){
			mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			log.info("Jackson mapper inicializado.....");
		}
	}

	public String verificarCodigo(String user, String otp) throws Exception {
		// http://otp.bcb.gob.bo/multiotp/otp_http_auth.php?user=XXXXX&otp=XXXXXXX
		Map<String, String> params = new HashMap<String, String>();
		params.put("user", user);
		params.put("otp", otp);
		// String url =
		// "http://otp.bcb.gob.bo/multiotp/otp_http_auth.php?user={user}&otp={otp}";
		String url = urlBase + URL_PARAMS;// "https://dsci.bcb.gob.bo/multiotp/otp_http_auth.php?user={user}&otp={otp}";
		try {
			log.info("user: {}, otp: {}",user, otp);			
			String searchResponses = template.getForEntity(url, String.class, params).getBody();
			log.info("Respuesta Serv. OTP: {}", searchResponses);
			OTPResponse searchResponse = deserialize(searchResponses);
			if (searchResponses == null) {
				throw new Exception("No hubo respuesta del servicio de Verificación de Código [" + urlBase + "] comunique al administrador.");
			}

			String code = searchResponse.getEstado();
			String codeDescrip = searchResponse.getMensaje();
			log.debug(code + " :: " + codeDescrip);			
			if (!code.equals(OTP_CODE_SUCCESS)){
				throw new Exception("[" + code + "] " + codeDescrip);
			}
			return code + ": " + codeDescrip;
		} catch (Exception e) {
			log.error("Error al verificar OPT: " + e.getMessage(), e);
			throw new Exception(e.getMessage(), e);
		}
	}

	public static OTPResponse deserialize(String object) {
		try {
			return mapper.readValue(object, OTPResponse.class);
		} catch (IOException e) {
			throw new IllegalArgumentException("Unserializable " + object.getClass().getName() + " -> " + object.toString());
		}
	}
	
	public static void main(String[] args) {
		//OTPResponse searchResponse = deserialize(searchResponses);		
	}
}
