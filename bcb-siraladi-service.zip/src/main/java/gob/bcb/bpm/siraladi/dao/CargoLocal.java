package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.Cargo;
import gob.bcb.bpm.siraladi.jpa.PersonaInst;

import java.util.List;

public interface CargoLocal extends DAO<Integer, Cargo>{

	public abstract Cargo findByCodCargo(Integer codCargo);

	public abstract List<Cargo> findByCodPersona(String codPersona);

	public abstract Cargo saveorupdate(Cargo params);

}