package gob.bcb.bpm.siraladi.utils;

import java.util.logging.Logger;

import org.apache.commons.lang.StringUtils;

/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public class NumeroDAV {
	private static Logger log = Logger.getLogger(NumeroDAV.class.getName());
	final static String CEROS = "000000";

	public static Integer generaDAV(String cod_inst, String cod_id, String anio, String secuencia) {
		if (StringUtils.isBlank(cod_inst)){
			throw new RuntimeException("Error al generar DAV cod_inst nulo");
		}
		if (StringUtils.isBlank(cod_id)){
			throw new RuntimeException("Error al generar DAV cod_id nulo");
		}
		if (StringUtils.isBlank(anio)){
			throw new RuntimeException("Error al generar DAV anio nulo");
		}
		if (StringUtils.isBlank(secuencia)){
			throw new RuntimeException("Error al generar DAV secuencia nulo");
		}
		
		String cadSec = String.format("%06d", Integer.valueOf(secuencia.trim()));
		//String cadAnio = String.format("%04d", Integer.valueOf(anio.trim()));
		//String cadSec = CEROS.concat(secuencia).trim();
		//cadSec = cadSec.substring(cadSec.length() - 6);		
		return generaDAV(cod_inst.trim() + cod_id.trim() + anio.trim() + cadSec);
	}

	public static Integer generaDAV(String cadReembolso) {

		int digito1;
		int digito2 = 0;
		int digito3;
		int suma = 0;
		String cad99 = null;
		String cadVerificador = "121212121212";

		if (cadReembolso.length() == 12) { // codigo antiguo
			cadVerificador = "121212121212";
		} else { // Codigo nuevo
			cadVerificador = "121212121212121";
		}
		for (int i = 0; i < cadReembolso.length(); i++) {
			int c = Integer.valueOf(cadReembolso.substring(i, i+1)) ;
			digito3 = c * Integer.valueOf(cadVerificador.substring(i, i+1));
			if (digito3 > 9) {
				cad99 = String.valueOf(digito3);
				suma = suma + Integer.valueOf(cad99.substring(0, 1)) + Integer.valueOf(cad99.substring(1));
			} else {
				suma = suma + digito3;
			}
		}
		cad99 = String.valueOf(suma);

		if (Integer.valueOf(cad99.substring(1)) == 0) {
			digito2 = 0;
		} else {
			digito1 = (Integer.valueOf(cad99.substring(0, 1)) + 1) * 10;
			digito2 = digito1 - suma;
		}

		cad99 = String.valueOf(digito2);

		// CONTROL PARA UN CASO QUE NUNCA SE DIO
		if (cad99.length() > 1) {
			digito2 = Integer.valueOf(cad99.substring(1, 2));
		}		
		return digito2;
	}

	public static boolean verificaDAV(String cod_inst, String cod_id, String anio, String secuencia, Integer dav_camisa) {
		int dav_sis;
		
		dav_sis = generaDAV(cod_inst, cod_id, anio, secuencia);
		if (dav_sis != dav_camisa) {
			log.info("DAV invalido " + dav_camisa + "  para " + cod_inst.trim() + cod_id.trim() + anio.trim() + secuencia.trim());
		}
		return (dav_sis == dav_camisa);
	}
	
}
