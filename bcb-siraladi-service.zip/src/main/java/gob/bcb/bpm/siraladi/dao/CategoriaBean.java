package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.exceptions.AladiException;
import gob.bcb.bpm.siraladi.jpa.Categoria;
import gob.bcb.bpm.siraladi.jpa.CategoriaPK;
import gob.bcb.bpm.siraladi.jpa.Persona;
import gob.bcb.core.utils.UtilsDate;

import java.util.Date;
import java.util.List;


import javax.persistence.Query;
import javax.persistence.TemporalType;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("categoriaLocal")
@Transactional
public class CategoriaBean extends GenericDAO<CategoriaPK, Categoria> implements CategoriaLocal {
	private static Logger log = Logger.getLogger(CategoriaBean.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gob.bcb.bpm.siraladi.dao.CategoriaLocal#getCalifVig(java.lang.String,
	 * java.util.Date, javax.persistence.EntityManager)
	 */
	
	public Categoria getCalifVig(String codInst, Date fechaVig) {
		log.debug("Categoria getCalifVig " + codInst + " fecha " + fechaVig);

		if (fechaVig == null) {
			log.debug("Error al obtener calificacion fecha NULO");
			return null;
		}

		String jpql = "SELECT p FROM Categoria p, PersonaInst i " + "where p.id.codPersona = i.id.codPersona "
				+ "and i.id.codInst = :codInst and p.cveVigente = 'V' "
				+ "and p.id.fechaVig = (select max(c.id.fechaVig) from Categoria c where c.id.codPersona = p.id.codPersona "
				+ "and c.cveVigente = 'V' and c.id.fechaVig <= :fechaVig) order by p.fechaHora desc ";
		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("codInst", codInst);
		// query.setParameter("codPersona2", codPersona);
		query.setParameter("fechaVig", fechaVig, TemporalType.DATE);
		List<Categoria> categoriaList = query.getResultList();
		if (categoriaList.size() > 1) {
			return categoriaList.get(0);
		} else {
			if (categoriaList.size() == 0) {
				log.debug("Calificacion no encontrada para inst " + codInst + " a fecha " + fechaVig);
				return null;
			} else {
				return categoriaList.get(0);
			}
		}
	}

	public Categoria getCalifVigByPersona(String codPersona, Date fechaVig) {
		log.info("$$$$$$$$ Categoria getCalifVig " + codPersona + " fecha " + fechaVig);

		if (fechaVig == null) {
			log.debug("Error al obtener calificacion fecha NULO");
			return null;
		}

		String jpql = "SELECT p FROM Categoria p, Persona i ";
		jpql = jpql.concat("where p.id.codPersona = i.codPersona ");
		jpql = jpql.concat("and i.codPersona = :codInst ");
		jpql = jpql.concat("and p.cveVigente = 'V' ");		
		jpql = jpql.concat("and p.id.fechaVig = (select max(c.id.fechaVig) from Categoria c where c.id.codPersona = p.id.codPersona ");
		jpql = jpql.concat("and c.cveVigente = 'V' and c.id.fechaVig <= :fechaVig) order by p.fechaHora desc ");

		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("codInst", codPersona);
		// query.setParameter("codPersona2", codPersona);
		query.setParameter("fechaVig", fechaVig, TemporalType.DATE);
		List<Categoria> categoriaList = query.getResultList();
		if (categoriaList.size() > 1) {
			return categoriaList.get(0);
		} else {
			if (categoriaList.size() == 0) {
				log.debug("Calificacion no encontrada para inst " + codPersona + " a fecha " + fechaVig + " " + jpql);
				return null;
			} else {
				return categoriaList.get(0);
			}
		}
	}

	public Categoria findByCodigo(String codPersona, Date fechaVig, String codCalif) {
		String jpql = "SELECT t FROM Categoria t ";
		jpql = jpql.concat("WHERE t.id.codPersona = :codPersona ");
		jpql = jpql.concat("and date(t.id.fechaVig) = :fechaVig ");
		jpql = jpql.concat("and t.id.codCalif = :codCalif ");

		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("codPersona", codPersona);
		query.setParameter("fechaVig", fechaVig, TemporalType.DATE);
		query.setParameter("codCalif", codCalif);

		List lista = query.getResultList();
		if (lista.size() > 0) {
			return (Categoria) lista.get(0);
		}
		log.info("XXX: " + codPersona + " " + UtilsDate.stringFromDate(fechaVig,"dd/MM/yyyy") + " " + jpql);
		return null;
	}

	public List<Categoria> categoriasByCodPersona(String codPersona) {
		String jpql = "SELECT t FROM Categoria t ";
		jpql = jpql.concat("WHERE t.id.codPersona = :codPersona ");

		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("codPersona", codPersona);

		List lista = query.getResultList();
		return lista;
	}
	
	public Categoria saveorupdate(Categoria params) {
		log.info("Actualizando categoria " + params.getId().getCodPersona() + " fecha vig: "+ params.getId().getFechaVig() + " calif: "+ params.getId().getCodCalif());
		List<Categoria> categoriaLista = categoriasByCodPersona(params.getId().getCodPersona());
		for (Categoria categoria : categoriaLista) {
			categoria.setCveVigente("S");
			categoria.setFechaHora(new Date());
			getEntityManager().merge(categoria);
		}
		
		Categoria categoriaOld = findByCodigo(params.getId().getCodPersona(), params.getId().getFechaVig(), params.getId().getCodCalif());

		if (categoriaOld == null) {
			params.setCveVigente("V");
			params.setFechaHora(new Date());
			makePersistent(params);
		} else {
			categoriaOld.setCveVigente("V");
			categoriaOld.setFechaHora(new Date());			
			categoriaOld.setEstacion(params.getEstacion());
			categoriaOld.setCodUsuario(params.getCodUsuario());
			
			makePersistent(categoriaOld);
		}

		categoriaOld = findByCodigo(params.getId().getCodPersona(), params.getId().getFechaVig(), params.getId().getCodCalif());
		log.info("Actualizando Categoria " + categoriaOld.toString());
		return categoriaOld;
	}

}
