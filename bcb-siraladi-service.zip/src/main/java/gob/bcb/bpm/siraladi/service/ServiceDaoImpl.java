package gob.bcb.bpm.siraladi.service;

import gob.bcb.bpm.siraladi.dao.AperturaLocal;
import gob.bcb.bpm.siraladi.dao.CalifRiesgoLocal;
import gob.bcb.bpm.siraladi.dao.CargoLocal;
import gob.bcb.bpm.siraladi.dao.CategoriaLocal;
import gob.bcb.bpm.siraladi.dao.ClasifProductosLocal;
import gob.bcb.bpm.siraladi.dao.ClavesLocal;
import gob.bcb.bpm.siraladi.dao.DetPatrimonioLocal;
import gob.bcb.bpm.siraladi.dao.EstadoMovLocal;
import gob.bcb.bpm.siraladi.dao.HorarioLocal;
import gob.bcb.bpm.siraladi.dao.IdentificadorLocal;
import gob.bcb.bpm.siraladi.dao.InstitucionLocal;
import gob.bcb.bpm.siraladi.dao.InstrumentoLocal;
import gob.bcb.bpm.siraladi.dao.MonedaLocal;
import gob.bcb.bpm.siraladi.dao.MovCoinLocal;
import gob.bcb.bpm.siraladi.dao.MovimientoLocal;
import gob.bcb.bpm.siraladi.dao.PagoLocal;
import gob.bcb.bpm.siraladi.dao.PaisLocal;
import gob.bcb.bpm.siraladi.dao.ParamsLocal;
import gob.bcb.bpm.siraladi.dao.PatrimonioLocal;
import gob.bcb.bpm.siraladi.dao.PerTipoCuentaLocal;
import gob.bcb.bpm.siraladi.dao.PersonaInstLocal;
import gob.bcb.bpm.siraladi.dao.PersonaLocal;
import gob.bcb.bpm.siraladi.dao.PlanPagoLocal;
import gob.bcb.bpm.siraladi.dao.RegAnticipadoLocal;
import gob.bcb.bpm.siraladi.dao.RegistroLocal;
import gob.bcb.bpm.siraladi.dao.SwfDetmensajeLocal;
import gob.bcb.bpm.siraladi.dao.SwfMensajeLocal;
import gob.bcb.bpm.siraladi.dao.SwfMttransferLocal;
import gob.bcb.bpm.siraladi.dao.SwfMttransferdetLocal;
import gob.bcb.bpm.siraladi.dao.SwfPersonactaLocal;
import gob.bcb.bpm.siraladi.dao.TPagoImpLocal;
import gob.bcb.bpm.siraladi.dao.UsuarioLocal;
import gob.bcb.bpm.siraladi.logic.RegAnticipadoServiceLocal;
import gob.bcb.bpm.siraladi.pojo.UsuarioSirAladi;
import gob.bcb.bpm.siraladi.service.session.UserSessionHolder;
import gob.bcb.bpm.siraladi.utils.Constants;
import gob.bcb.swift.service.SwiftMessageServiceLocal;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

//@Component("serviceDao")
@Service("serviceDao")
@Transactional(propagation = Propagation.REQUIRED)
public class ServiceDaoImpl implements ServiceDao {
	private static Logger log = Logger.getLogger(ServiceDaoImpl.class);

	private UsuarioSirAladi usuarioAudit;
	@Autowired
	private AperturaLocal aperturaLocal;
	@Autowired
	private CalifRiesgoLocal califRiesgoLocal;
	@Autowired
	private CargoLocal cargoLocal;	
	@Autowired
	private CategoriaLocal categoriaLocal;
	@Autowired
	private ClavesLocal clavesLocal;	
	@Autowired
	private DetPatrimonioLocal detPatrimonioLocal;
	@Autowired
	private EstadoMovLocal estadoMovLocal;
	@Autowired
	private HorarioLocal horarioLocal;
	@Autowired
	private IdentificadorLocal identificadorLocal;
	@Autowired
	private InstitucionLocal institucionLocal;
	@Autowired
	private InstrumentoLocal instrumentoLocal;
	@Autowired
	private MonedaLocal monedaLocal;
	@Autowired
	private MovCoinLocal movCoinLocal;
	@Autowired
	private MovimientoLocal movimientoLocal;
	@Autowired
	private PagoLocal pagoLocal;
	@Autowired
	private PaisLocal paisLocal;
	@Autowired
	private ParamsLocal paramsLocal;
	@Autowired
	private PatrimonioLocal patrimonioLocal;
	@Autowired
	private PersonaInstLocal personaInstLocal;
	@Autowired
	private PersonaLocal personaLocal;
	@Autowired
	private PerTipoCuentaLocal perTipoCuentaLocal;
	@Autowired
	private PlanPagoLocal planPagoLocal;
	@Autowired
	private RegAnticipadoLocal regAnticipadoLocal;
	@Autowired
	private RegistroLocal registroLocal;
	@Autowired
	private SwfDetmensajeLocal swfDetmensajeLocal;
	@Autowired
	private SwfMensajeLocal swfMensajeLocal;
	@Autowired
	private SwfMttransferdetLocal swfMttransferdetLocal;
	@Autowired
	private SwfMttransferLocal swfMttransferLocal;
	@Autowired
	private SwfPersonactaLocal swfPersonactaLocal;
	@Autowired
	private TPagoImpLocal tPagoImpLocal;
	@Autowired
	private UsuarioLocal usuarioLocal;
	@Autowired
	private ClasifProductosLocal clasifProductosLocal;	
	
	@Autowired
	private RegAnticipadoServiceLocal regAnticipadoServiceLocal;
	
	@Autowired
	private SwiftMessageServiceLocal swiftMessageServiceLocal;	
	public ServiceDaoImpl() {
		log.info("ServiceDaoImpl DAO creado ...");
	}

	public RegAnticipadoLocal getRegAnticipadoLocal() {
		return regAnticipadoLocal;
	}

	public UsuarioSirAladi getUsuarioAudit() {
		return usuarioAudit;
	}

	public void setUsuarioAudit(UsuarioSirAladi usuarioAudit) {
		UserSessionHolder.set(Constants.AUDIT_USER_DATABASE_ID, usuarioAudit.getLogin());
		UserSessionHolder.set(Constants.AUDIT_USER_ESTACION, usuarioAudit.getPersona().getEstacion());
		UserSessionHolder.set(Constants.AUDIT_USER_SESSION_ID, usuarioAudit.getLogin() + "_" + usuarioAudit.getPersona().getCorreos());
		this.usuarioAudit = usuarioAudit;
	}

	public InstitucionLocal getInstitucionLocal() {
		return institucionLocal;
	}

	public SwfMttransferLocal getSwfMttransferLocal() {
		return swfMttransferLocal;
	}

	public void setRegAnticipadoLocal(RegAnticipadoLocal regAnticipadoLocal) {
		this.regAnticipadoLocal = regAnticipadoLocal;
	}

	public AperturaLocal getAperturaLocal() {
		return aperturaLocal;
	}

	public void setAperturaLocal(AperturaLocal aperturaLocal) {
		this.aperturaLocal = aperturaLocal;
	}

	public CalifRiesgoLocal getCalifRiesgoLocal() {
		return califRiesgoLocal;
	}

	public void setCalifRiesgoLocal(CalifRiesgoLocal califRiesgoLocal) {
		this.califRiesgoLocal = califRiesgoLocal;
	}

	public CategoriaLocal getCategoriaLocal() {
		return categoriaLocal;
	}

	public void setCategoriaLocal(CategoriaLocal categoriaLocal) {
		this.categoriaLocal = categoriaLocal;
	}

	public DetPatrimonioLocal getDetPatrimonioLocal() {
		return detPatrimonioLocal;
	}

	public void setDetPatrimonioLocal(DetPatrimonioLocal detPatrimonioLocal) {
		this.detPatrimonioLocal = detPatrimonioLocal;
	}

//	public DiaEspecialLocal getDiaEspecialLocal() {
//		return diaEspecialLocal;
//	}
//
//	public void setDiaEspecialLocal(DiaEspecialLocal diaEspecialLocal) {
//		this.diaEspecialLocal = diaEspecialLocal;
//	}

	public EstadoMovLocal getEstadoMovLocal() {
		return estadoMovLocal;
	}

	public void setEstadoMovLocal(EstadoMovLocal estadoMovLocal) {
		this.estadoMovLocal = estadoMovLocal;
	}

	public HorarioLocal getHorarioLocal() {
		return horarioLocal;
	}

	public void setHorarioLocal(HorarioLocal horarioLocal) {
		this.horarioLocal = horarioLocal;
	}

	public IdentificadorLocal getIdentificadorLocal() {
		return identificadorLocal;
	}

	public void setIdentificadorLocal(IdentificadorLocal identificadorLocal) {
		this.identificadorLocal = identificadorLocal;
	}

	public InstrumentoLocal getInstrumentoLocal() {
		return instrumentoLocal;
	}

	public void setInstrumentoLocal(InstrumentoLocal instrumentoLocal) {
		this.instrumentoLocal = instrumentoLocal;
	}

	public MonedaLocal getMonedaLocal() {
		return monedaLocal;
	}

	public void setMonedaLocal(MonedaLocal monedaLocal) {
		this.monedaLocal = monedaLocal;
	}

	public MovCoinLocal getMovCoinLocal() {
		return movCoinLocal;
	}

	public void setMovCoinLocal(MovCoinLocal movCoinLocal) {
		this.movCoinLocal = movCoinLocal;
	}

	public MovimientoLocal getMovimientoLocal() {
		return movimientoLocal;
	}

	public void setMovimientoLocal(MovimientoLocal movimientoLocal) {
		this.movimientoLocal = movimientoLocal;
	}

	public PagoLocal getPagoLocal() {
		return pagoLocal;
	}

	public void setPagoLocal(PagoLocal pagoLocal) {
		this.pagoLocal = pagoLocal;
	}

	public PaisLocal getPaisLocal() {
		return paisLocal;
	}

	public void setPaisLocal(PaisLocal paisLocal) {
		this.paisLocal = paisLocal;
	}

	public ParamsLocal getParamsLocal() {
		return paramsLocal;
	}

	public void setParamsLocal(ParamsLocal paramsLocal) {
		this.paramsLocal = paramsLocal;
	}

	public PatrimonioLocal getPatrimonioLocal() {
		return patrimonioLocal;
	}

	public void setPatrimonioLocal(PatrimonioLocal patrimonioLocal) {
		this.patrimonioLocal = patrimonioLocal;
	}

	public PersonaInstLocal getPersonaInstLocal() {
		return personaInstLocal;
	}

	public void setPersonaInstLocal(PersonaInstLocal personaInstLocal) {
		this.personaInstLocal = personaInstLocal;
	}

	public PersonaLocal getPersonaLocal() {
		return personaLocal;
	}

	public void setPersonaLocal(PersonaLocal personaLocal) {
		this.personaLocal = personaLocal;
	}

	public PerTipoCuentaLocal getPerTipoCuentaLocal() {
		return perTipoCuentaLocal;
	}

	public void setPerTipoCuentaLocal(PerTipoCuentaLocal perTipoCuentaLocal) {
		this.perTipoCuentaLocal = perTipoCuentaLocal;
	}

	public PlanPagoLocal getPlanPagoLocal() {
		return planPagoLocal;
	}

	public void setPlanPagoLocal(PlanPagoLocal planPagoLocal) {
		this.planPagoLocal = planPagoLocal;
	}

	public RegistroLocal getRegistroLocal() {
		return registroLocal;
	}

	public void setRegistroLocal(RegistroLocal registroLocal) {
		this.registroLocal = registroLocal;
	}

	public SwfDetmensajeLocal getSwfDetmensajeLocal() {
		return swfDetmensajeLocal;
	}

	public void setSwfDetmensajeLocal(SwfDetmensajeLocal swfDetmensajeLocal) {
		this.swfDetmensajeLocal = swfDetmensajeLocal;
	}

	public SwfMensajeLocal getSwfMensajeLocal() {
		return swfMensajeLocal;
	}

	public void setSwfMensajeLocal(SwfMensajeLocal swfMensajeLocal) {
		this.swfMensajeLocal = swfMensajeLocal;
	}

	public SwfMttransferdetLocal getSwfMttransferdetLocal() {
		return swfMttransferdetLocal;
	}

	public void setSwfMttransferdetLocal(SwfMttransferdetLocal swfMttransferdetLocal) {
		this.swfMttransferdetLocal = swfMttransferdetLocal;
	}

	public SwfPersonactaLocal getSwfPersonactaLocal() {
		return swfPersonactaLocal;
	}

	public void setSwfPersonactaLocal(SwfPersonactaLocal swfPersonactaLocal) {
		this.swfPersonactaLocal = swfPersonactaLocal;
	}

	public TPagoImpLocal getTPagoImpLocal() {
		return tPagoImpLocal;
	}

	public void settPagoImpLocal(TPagoImpLocal tPagoImpLocal) {
		this.tPagoImpLocal = tPagoImpLocal;
	}

	public void setInstitucionLocal(InstitucionLocal institucionLocal) {
		this.institucionLocal = institucionLocal;
	}

	public void setSwfMttransferLocal(SwfMttransferLocal swfMttransferLocal) {
		this.swfMttransferLocal = swfMttransferLocal;
	}

	public ClavesLocal getClavesLocal() {
		return clavesLocal;
	}

	public void setClavesLocal(ClavesLocal clavesLocal) {
		this.clavesLocal = clavesLocal;
	}

	public RegAnticipadoServiceLocal getRegAnticipadoServiceLocal() {
		return regAnticipadoServiceLocal;
	}

	public void setRegAnticipadoServiceLocal(RegAnticipadoServiceLocal regAnticipadoServiceLocal) {
		this.regAnticipadoServiceLocal = regAnticipadoServiceLocal;
	}

	public SwiftMessageServiceLocal getSwiftMessageServiceLocal() {
		return swiftMessageServiceLocal;
	}

	public void setSwiftMessageServiceLocal(SwiftMessageServiceLocal swiftMessageServiceLocal) {
		this.swiftMessageServiceLocal = swiftMessageServiceLocal;
	}

	public UsuarioLocal getUsuarioLocal() {
		return usuarioLocal;
	}

	public void setUsuarioLocal(UsuarioLocal usuarioLocal) {
		this.usuarioLocal = usuarioLocal;
	}

	public CargoLocal getCargoLocal() {
		return cargoLocal;
	}

	public void setCargoLocal(CargoLocal cargoLocal) {
		this.cargoLocal = cargoLocal;
	}

	public ClasifProductosLocal getClasifProductosLocal() {
		return clasifProductosLocal;
	}

}
