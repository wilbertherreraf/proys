package gob.bcb.bpm.siraladi.service;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLDecoder;
import java.net.URLEncoder;

import javax.persistence.EntityManager;

import org.apache.commons.lang.StringUtils;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.apache.log4j.Logger;

import gob.bcb.bpm.siraladi.dao.ParamsBean;
import gob.bcb.bpm.siraladi.dao.ParamsLocal;
import gob.bcb.bpm.siraladi.jpa.Param;
import gob.bcb.bpm.siraladi.jpa.SwfMensaje;
import gob.bcb.bpm.siraladi.utils.Constants;
import gob.bcb.core.utils.ArchivoUtil;
import gob.bcb.core.utils.UtilsFile;
import gob.bcb.lavado.client.ClienteLvd;
import gob.bcb.lavado.client.pojos.SearchResponse;
import gob.bcb.swift.exception.SwiftAdminException;

public class ClienteLvdSir {
	private static Logger log = Logger.getLogger(ClienteLvdSir.class);
	private final EntityManager entityManager;
	private ClienteLvd clienteLvd;
	private String idsession = null;
	
	public ClienteLvdSir(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public ClienteLvd initClienteLvd(ParamsLocal paramsLocal) {
		log.info("Creando objeto ClienteLvd");
		
		String verificaEnLavado = "N";
		try {
			Param param = paramsLocal.findByCodigo(Constants.LAVADO_VERIFICA_LAVADO);
			verificaEnLavado = param.getValparam();
			if (StringUtils.isBlank(verificaEnLavado)) {
				verificaEnLavado = "N";
			}
			verificaEnLavado = verificaEnLavado.trim();

		} catch (NullPointerException e) {
			log.warn("No existe el parametro ", e);
		} catch (Exception e) {
			log.warn("Error en recuperar valor en parametros " + e.getMessage(), e);
		}

		log.info("Se valida con LAVADO " + verificaEnLavado + " ? " + (verificaEnLavado.equals(Constants.PAR_LAVADO_VERIFICA)));
		if (verificaEnLavado != null && verificaEnLavado.equals(Constants.PAR_LAVADO_VERIFICA)) {
			Param param = paramsLocal.findByCodigo(Constants.LAVADO_RESOURCE);
			if (StringUtils.isBlank(param.getValparam())) {
				throw new SwiftAdminException("Lavado: parametro " + Constants.LAVADO_RESOURCE + " invalido, revise soc_parametros");
			}

			try{
				clienteLvd = new ClienteLvd(param.getValparam().trim(), ConfigurationServ.getConfigurationHome(), Constants.NOMBRE_APP);
			}catch(NullPointerException e){			
				throw new SwiftAdminException(e);
			}catch(Exception e){
				throw new SwiftAdminException(e);				
			}
			
		}
		return clienteLvd;
	}

	public String getSessionLavado(String codUsuario) {

		if (clienteLvd != null) {
			try {
				SearchResponse searchResponse = clienteLvd.getIniSessionLavado(Constants.NOMBRE_APP, codUsuario);
				idsession = searchResponse.getCodoperacion();
				if (StringUtils.isBlank(searchResponse.getCodoperacion()) || !searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO)) {
					throw new SwiftAdminException("Error al obtener sesion LAVADO: " + searchResponse.getCodResp() + " " + searchResponse.getDescripResp());
				}
				return idsession;
			} catch (Exception e) {
				throw new SwiftAdminException(e.getMessage(), e);
			}
		}
		return idsession;
	}

	public SearchResponse solicitarCorrelativo(String codoperacion, String coduser) {
		SearchResponse searchResponse = null;
		try {
			searchResponse = clienteLvd.solicitarCorrelativo(Constants.NOMBRE_APP, codoperacion, coduser, idsession);
			if (!searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO) || Integer.valueOf(searchResponse.getCodoperacion()).compareTo(0) <= 0) {
				throw new SwiftAdminException("Error al obtener correlativo LAVADO: " + searchResponse.getCodResp() + " " + searchResponse.getDescripResp());
			}

			log.info("Nro swift LAVADO asignado " + searchResponse.getCodoperacion() + " Nrocorr==> " + searchResponse.getNrocorr());
			return searchResponse;
		} catch (Exception e) {
			throw new SwiftAdminException(e.getMessage(), e);
		}

	}

	public void scanMensaje(SwfMensaje swfMensaje) {
		String codigoOperacion = swfMensaje.getMenCodoperacion();
		scanMensaje(codigoOperacion, swfMensaje.getMenAuditusr(), swfMensaje.getMenNrolavado(), swfMensaje.getMenNrocorr(), swfMensaje.getMenPlano());
	}

	public void scanMensaje(String codigoOperacion, String codusuario, Integer nroLavado, Integer nroCorrelativo, String menPlano) {
		if (clienteLvd == null)
			return;
		try {
			log.info("ntrewsssssssssssssssssssssssssssssssssssssssss");
			log.info(menPlano);			
			String menPlano00 = clienteLvd.convertToUtf8(menPlano, "ISO-8859-1");
			log.info("xxxxxxxxxxxxxxxxxxx");			
			log.info(menPlano00);
			menPlano00 = URLEncoder.encode(menPlano00, "UTF-8");
			log.info("yyyyyyyyyyyyyyyyyyyyyyyyyyyyyy");			
			log.info(menPlano00);
			SearchResponse searchResponse = clienteLvd.scanSwiftRegistro(Constants.NOMBRE_APP, codusuario, nroLavado, nroCorrelativo, codigoOperacion, idsession, menPlano);

			if (searchResponse.getCountRegs().compareTo(0) > 0 || !searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO)) {
				throw new SwiftAdminException("Error Scaneo LAVADO: " + searchResponse.getCodResp() + " " + searchResponse.getDescripResp());
			}
		} catch (Exception e) {
			throw new SwiftAdminException(e.getMessage(), e);
		}
	}

	public void preautorizarSwift(SwfMensaje swfMensaje) {
		String codigoOperacion = swfMensaje.getMenCodoperacion();
		preautorizarSwift(codigoOperacion, swfMensaje.getMenAuditusr(), swfMensaje.getMenNrolavado(), swfMensaje.getMenNrocorr(), swfMensaje.getMenPlano());
	}

	public void preautorizarSwift(String codigoOperacion, String codusuario, Integer nroLavado, Integer nroCorrelativo, String menPlano) {
		if (clienteLvd == null)
			return;		
		try {
			SearchResponse searchResponse = clienteLvd.preautorizarSwift(Constants.NOMBRE_APP, codusuario, nroLavado, nroCorrelativo, codigoOperacion, idsession, menPlano);

			if (searchResponse.getCountRegs().compareTo(0) > 0 || !searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO)) {
				throw new SwiftAdminException("Error en APROBAR: " + searchResponse.getCodResp() + " " + searchResponse.getDescripResp());
			}
		} catch (Exception e) {
			throw new SwiftAdminException(e.getMessage(), e);
		}
	}

	public void cerrarSession(String coduser) {
		if (clienteLvd == null)
			return;
		try {
			SearchResponse searchResponse = clienteLvd.postSessionLavado(Constants.NOMBRE_APP, coduser, idsession);
			if (!searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO)) {
				throw new SwiftAdminException("Error Post Scaneo LAVADO: " + searchResponse.getCodResp() + " " + searchResponse.getDescripResp());
			}
		} catch (Exception e) {
			throw new SwiftAdminException(e.getMessage(), e);
		}
	}

	public String getIdsession() {
		return idsession;
	}

	public ClienteLvd getClienteLvd() {
		return clienteLvd;
	}
	
	public static String decodeFromUri(String strToDecode){
		boolean isEncoded = true;
		try {
			new URI(strToDecode);
		} catch (URISyntaxException e) {
			isEncoded = false;
		}

		if (isEncoded) {
			try {
				strToDecode = URLDecoder.decode(strToDecode, "UTF-8");
			} catch (UnsupportedEncodingException e) {
				throw new SwiftAdminException("Error en URLDecoder.decode " + e.getMessage(), e);
			}
		}
		return strToDecode;
	}

}
