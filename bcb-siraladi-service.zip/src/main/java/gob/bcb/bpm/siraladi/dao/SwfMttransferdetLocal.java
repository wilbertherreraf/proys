package gob.bcb.bpm.siraladi.dao;

import java.util.List;

import gob.bcb.bpm.siraladi.jpa.SwfMttransferdet;
import gob.bcb.bpm.siraladi.jpa.SwfMttransferdetPK;




public interface SwfMttransferdetLocal extends DAO<SwfMttransferdetPK, SwfMttransferdet>{

	List<SwfMttransferdet> findByCodTTransfer(String dttCodttransfer, Integer dttBloque);

	SwfMttransferdet findByCodigo(String dttCodttransfer, String dttCodcampo, Integer dttBloque);

}
