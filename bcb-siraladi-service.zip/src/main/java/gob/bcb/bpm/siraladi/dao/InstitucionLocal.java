package gob.bcb.bpm.siraladi.dao;

import java.util.List;

import gob.bcb.bpm.siraladi.jpa.Institucion;

//
public interface InstitucionLocal extends DAO<String, Institucion>{
	public Institucion findByPaisCodInst(String codPais, String codInst);

	/**
	 * Retorna la lista de instituciones por estado y pais
	 * @param cveEstado obligatorio, estado de la institucion 0(vigente) 1(suspendido) f(fusionado)
	 * @param codPais codigo de pais de convenio
	 * @return  lista de instituciones
	 */
	List<Institucion> findByCveEstado(String cveEstado, String codPais);

	Institucion findByCodInst(String codInst);

	List<Institucion> findInstituciones(Institucion institucion);

	Institucion guardarInstitucion(Institucion institucion);

	Institucion findByBIC(String bic, String bicBranch);
}
