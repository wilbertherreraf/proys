package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.Patrimonio;

public interface PatrimonioLocal extends DAO<Integer, Patrimonio>{

	Patrimonio getMaxPatrimonio();

}
