package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.DiaEspecial;
import gob.bcb.bpm.siraladi.jpa.DiaEspecialPK;

public class DiaEspecialBean extends GenericDAO<DiaEspecialPK, DiaEspecial> implements DiaEspecialLocal {

}
