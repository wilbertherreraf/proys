package gob.bcb.bpm.siraladi.service;

import java.util.Date;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;

import org.apache.log4j.Logger;

import gob.bcb.bpm.siraladi.dao.DetPatrimonioBean;
import gob.bcb.bpm.siraladi.dao.MovCoinBean;
import gob.bcb.bpm.siraladi.dao.MovCoinLocal;
import gob.bcb.bpm.siraladi.exceptions.AladiException;
import gob.bcb.bpm.siraladi.exceptions.BusinessException;
import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.MovCoin;
import gob.bcb.bpm.siraladi.jpa.Pago;
import gob.bcb.bpm.siraladi.jpa.Param;
import gob.bcb.bpm.siraladi.jpa.TPagoImp;
import gob.bcb.bpm.siraladi.logic.AperturaServiceBean;
import gob.bcb.bpm.siraladi.logic.AperturaServiceLocal;
import gob.bcb.bpm.siraladi.logic.PagoServiceBean;
import gob.bcb.bpm.siraladi.logic.PagoServiceLocal;
import gob.bcb.bpm.siraladi.service.session.UserSessionHolder;
import gob.bcb.bpm.siraladi.utils.Constants;
import gob.bcb.bpm.siraladi.utils.StatusCode;
import gob.bcb.bpm.siraladi.utils.UtilsDate;
import gob.bcb.bpm.siraladi.ws.clientaladi.ClientAladiWSHandler;

/**
 * @author wilherrera Wilbert Herrera Flores Banco Central de Bolivia
 *         Departamento de Desarrollo
 */
public class PagoServiceHandler implements ServiceAladiHandler {
	private static Logger log = Logger.getLogger(PagoServiceHandler.class);
	
	private PagoServiceLocal pagoService;
	private AperturaServiceLocal aperturaService;
	private EntityManager entityManager;

	public PagoServiceHandler(EntityManager entityManager) {
		log.debug("Creando PagoServiceHandler ");
		this.entityManager = entityManager;
		aperturaService = new AperturaServiceBean(entityManager);
		pagoService = new PagoServiceBean(entityManager);
	}

	
	public void handlerProcesarMsg(RequestContext requestContext) throws AladiException, NotSupportedException, SystemException, SecurityException,
			IllegalStateException, RollbackException, HeuristicMixedException, HeuristicRollbackException {
		String statusCode = StatusCode.OPERACION_RECEIVED;
		String consent = null;

		Map<String, Object> parametros = requestContext.getBcbRequest().getRequestElements();

		String codTipoOperacion = requestContext.getResponseContext().getCodTipoOperacion();

		ResponseContext response = requestContext.getResponseContext();

		if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0301)) {
			// crear nuevo transaccion pago
			Apertura apertura = (Apertura) parametros.get("apertura");
			Pago pago = (Pago) parametros.get("pago");
			pagoService.begin();

			Apertura aperturaOld = aperturaService.getAperturaLocal().findByCodReembolso(apertura.getInstitucion().getCodInst(),
					apertura.getIdentificador().getCodId(), apertura.getAnio(), apertura.getSecuencia(), apertura.getDav());

			if (aperturaOld == null) {
				throw new AladiException("REEMBOLSO_INEXISTENTE", new Object[] { apertura.getNroReembLiteral() });
			}

			pago = pagoService.crearReg(pago, aperturaOld);
			response.addDescripcionParametro(codTipoOperacion, "pago", "Custom", pago);
			response.addDescripcionParametro(codTipoOperacion, "apertura", "Custom", aperturaOld);
			pagoService.commit();

			log.info("Pago-Reembolso nroMov " + pago.getNroMov() + " creada satisfactoriamente");
			statusCode = StatusCode.OPERACION_SUCCESS;
			consent = "Pago-reembolso creado exist�samente con nroMov : " + pago.getNroMov();

		} else if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0302)) {
			Apertura apertura = (Apertura) parametros.get("apertura");
			Pago pago = (Pago) parametros.get("pago");

			pagoService.begin();

			Apertura aperturaOld = aperturaService.getAperturaLocal().findByCodReembolso(apertura.getInstitucion().getCodInst(),
					apertura.getIdentificador().getCodId(), apertura.getAnio(), apertura.getSecuencia(), apertura.getDav());

			if (aperturaOld == null) {
				throw new AladiException("REEMBOLSO_INEXISTENTE", new Object[] { apertura.getNroReembLiteral() });
			}

			pago = pagoService.modificar(pago, aperturaOld);

			aperturaService.getAperturaLocal().flush();

			aperturaOld = aperturaService.getAperturaLocal().findByCodReembolso(apertura.getInstitucion().getCodInst(),
					apertura.getIdentificador().getCodId(), apertura.getAnio(), apertura.getSecuencia(), apertura.getDav());

			pagoService.commit();

			statusCode = StatusCode.OPERACION_SUCCESS;
			consent = "Operacion efectuada exist�samente Pago nroMov : " + pago.getNroMov();

			response.addDescripcionParametro(codTipoOperacion, "apertura", "Custom", aperturaOld);
			response.addDescripcionParametro(codTipoOperacion, "pago", "Custom", pago);

			try {
				// segmento que actualiza el saldo de la institucion pero que no
				// deber�a afectar al resultado de la transaccion
				pagoService.begin();
				DetPatrimonioBean detPatrimonioBean = new DetPatrimonioBean();
				detPatrimonioBean.setEntityManager(entityManager);

				detPatrimonioBean.actualizarSaldoIFA((String) UserSessionHolder.get("personaRevisada"));
				pagoService.commit();
			} catch (Exception e) {
				log.error("Error al actualizar saldo deudor" + e.getMessage(), e);
			}
		} else if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0303)) {
			// consulta de pagos por apertura
			Apertura apertura = (Apertura) parametros.get("apertura");

			Apertura aperturaOut = aperturaService.getAperturaLocal().findByCodReembolso(apertura.getInstitucion().getCodInst(),
					apertura.getIdentificador().getCodId(), apertura.getAnio(), apertura.getSecuencia(), apertura.getDav());

			if (aperturaOut == null) {
				throw new AladiException("REEMBOLSO_INEXISTENTE", new Object[] { apertura.getNroReembLiteral() });
			}

			List<Pago> pagoList = pagoService.getPagoLocal().getByNroMovApeCveEstadoPago(aperturaOut.getNroMov(), null, true);
			response.addDescripcionParametro(codTipoOperacion, "listapagos", "Custom", pagoList);

			statusCode = StatusCode.OPERACION_SUCCESS;
			consent = "Operacion efectuada exist�samente nroMov : " + aperturaOut.getNroMov();

		} else if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0304)) {
			// operacion para clientes WS
			throw new AladiException("TIPO_DE_OPERACION_NO_IMPLEMENTADA", new Object[] { requestContext.getResponseContext().getOperacionAladi()
					.getCodTipoOperacion() });			
//			Apertura apertura = (Apertura) parametros.get("apertura");
//			Pago pago = (Pago) parametros.get("pago");
//
//			pagoService.begin();
//
//			Apertura aperturaOld = aperturaService.getAperturaLocal().findByCodReembolso(apertura.getInstitucion().getCodInst(),
//					apertura.getIdentificador().getCodId(), apertura.getAnio(), apertura.getSecuencia(), apertura.getDav());
//
//			if (aperturaOld == null) {
//				throw new AladiException("REEMBOLSO_INEXISTENTE", new Object[] { apertura.getNroReembLiteral() });
//			}
//			Pago pagoNew = pagoService.crearReg(pago, aperturaOld);
//
//			pago.setCveEstadoPago("C");
//			pagoNew = pagoService.modificar(pago, aperturaOld);
//			// whf ojoooo si se ha extornado se debe corregir el registro en
//			// plan de pagos y aque actualmente aparece como cancelado y no se
//			// puede modificar
//			pagoService.registroWSPorExport(pagoNew, aperturaOld);
//
//			pagoService.commit();
//
//			statusCode = StatusCode.OPERACION_SUCCESS;
//			consent = "Operacion efectuada exist�samente Pago nroMov : " + pagoNew.getNroMov();

		} else if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0305)) {
			// consulta a ws por pagos por importacion
			Date fechaDesde = (Date) parametros.get("fechaDesde");
			Date fechaHasta = (Date) parametros.get("fechaHasta");

			List<TPagoImp> tPagoImpList = ClientAladiWSHandler.execWSSicapCcb(fechaDesde, fechaHasta);
			response.addDescripcionParametro(codTipoOperacion, "listatpagoimport", "Custom", tPagoImpList);

			statusCode = StatusCode.OPERACION_SUCCESS;
			consent = "Operacion efectuada exist�samente";

		} else if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0306)) {
			// Operacion de almacenado en BDD individual de registros sobre
			// operaciones consultadas anteriormente a WS Aladi

			// TPagoImp tPagoImp = (TPagoImp) parametros.get("tpagoimport");
			//
			// pagoService.begin();
			// Pago pago = pagoService.registrarPagoImport(tPagoImp, false);
			//
			// pagoService.commit();
			//
			// statusCode = StatusCode.OPERACION_SUCCESS;
			// consent = "Operacion efectuada exist�samente";
			throw new AladiException("TIPO_DE_OPERACION_NO_IMPLEMENTADA", new Object[] { requestContext.getResponseContext().getOperacionAladi()
					.getCodTipoOperacion() });

		} else if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0307)) {
			// registro de debitos por importacion que fueron consultados a WS
			// convenio Aladi

			// List<TPagoImp> tPagoImpList = (List<TPagoImp>)
			// parametros.get("listatpagoimport");
			// List<Pago> pagoList =
			// pagoService.registrarPagoImport(tPagoImpList, false);
			//
			// response.addDescripcionParametro(codTipoOperacion, "listapagos",
			// "Custom", pagoList);
			//
			// statusCode = StatusCode.OPERACION_SUCCESS;
			// consent = "Operacion efectuada exist�samente";

			throw new AladiException("TIPO_DE_OPERACION_NO_IMPLEMENTADA", new Object[] { requestContext.getResponseContext().getOperacionAladi()
					.getCodTipoOperacion() });
		} else if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0308)) {
			// consulta a ws por pagos por importacion proceso automatico
			// solo de la fecha
			Date fechaDesde = new Date();// (Date) parametros.get("fechaDesde");
			Date fechaHasta = new Date();// (Date) parametros.get("fechaHasta");

			Param param = entityManager.find(Param.class, "diasconsulta");

			if (param.getValparam() != null) {
				String diasConsulta = param.getValparam().trim();
				Integer dias = 0;
				try {
					dias = Integer.valueOf(diasConsulta);
				} catch (Exception e) {
					dias = 0;
				}
				dias = dias * (-1);
				Calendar des = GregorianCalendar.getInstance();
				des.add(Calendar.DAY_OF_MONTH, dias);
				fechaDesde = des.getTime();
			}
			log.info("consultado a WS de " + UtilsDate.stringFromDate(fechaDesde, "ddMMyyyy") + " a "
					+ UtilsDate.stringFromDate(fechaHasta, "ddMMyyyy"));
			List<TPagoImp> tPagoImpList = ClientAladiWSHandler.execWSSicapCcb(fechaDesde, fechaHasta);

			pagoService.registrarPagoImport(tPagoImpList, true);

			statusCode = StatusCode.OPERACION_SUCCESS;
			consent = "Operacion efectuada existosamente";
			log.info("Consulta efectuada existosamente para " + UtilsDate.stringFromDate(fechaDesde, Constants.FORMAT_DATE_DB) + " a "
					+ UtilsDate.stringFromDate(fechaHasta, Constants.FORMAT_DATE_DB));
		} else if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0309)) {
			Apertura apertura = (Apertura) parametros.get("apertura");
			Pago pago = (Pago) parametros.get("pago");
			Apertura aperturaOut = aperturaService.getAperturaLocal().findByCodReembolso(apertura.getInstitucion().getCodInst(),
					apertura.getIdentificador().getCodId(), apertura.getAnio(), apertura.getSecuencia(), apertura.getDav());

			if (aperturaOut == null) {
				throw new AladiException("REEMBOLSO_INEXISTENTE", new Object[] { apertura.getNroReembLiteral() });
			}

			pagoService.begin();
			pagoService.eliminar(pago, aperturaOut);
			pagoService.commit();
			statusCode = StatusCode.OPERACION_SUCCESS;
			consent = "Operacion eliminada exist�samente";
		} else if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0310)) {
			// eliminacion de operacion no efectuada
			TPagoImp tPagoImp = (TPagoImp) parametros.get("tpagoimport");

			pagoService.begin();
			pagoService.eliminarPagoImport(tPagoImp);

			pagoService.commit();

			statusCode = StatusCode.OPERACION_SUCCESS;
			consent = "Operacion eliminada exist�samente";
		} else {
			throw new AladiException("TIPO_DE_OPERACION_NO_IMPLEMENTADA", new Object[] { requestContext.getResponseContext().getOperacionAladi()
					.getCodTipoOperacion() });
		}
		response.updateReponse(statusCode, consent);
		log.info("Operacion realizada exitosamente operacion " + codTipoOperacion);
	}

	public static void main(String[] args) {
		Calendar des = GregorianCalendar.getInstance();
		des.set(Calendar.DAY_OF_MONTH, 1);
		des.set(Calendar.MONTH, 1);
		des.set(Calendar.YEAR, 2012);
		System.out.println(des.getTime());
		des.add(Calendar.DAY_OF_MONTH, 0);
		System.out.println(des.getTime());

	}
}
