package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.Clave;
import gob.bcb.bpm.siraladi.jpa.Claves;
import gob.bcb.bpm.siraladi.jpa.ClavesPK;

import java.util.List;


import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("clavesLocal")
@Transactional
public class ClavesBean extends GenericDAO<ClavesPK, Claves> implements ClavesLocal {
	private static Logger log = Logger.getLogger(ClavesBean.class);

	public Claves getValoresByCod(String nomdato, String valdato) {
		StringBuffer query = new StringBuffer();

		query = query.append("SELECT h ");
		query = query.append("FROM Claves h ");
		query = query.append("where h.id.nomdato = :nomdato ");
		query = query.append("and h.id.valdato = :valdato ");
		query = query.append("order by h.id.valdato ");

		Query consulta = getEntityManager().createQuery(query.toString());

		consulta.setParameter("nomdato", nomdato);
		consulta.setParameter("valdato", valdato);
		List lista = consulta.getResultList();
		if (lista.size() > 0) {
			return (Claves) lista.get(0);
		}
		return null;
	}

	public List<Claves> getValoresByClave(String nomdato) {
		StringBuffer query = new StringBuffer();

		query = query.append("SELECT h ");
		query = query.append("FROM Claves h ");
		query = query.append("where h.id.nomdato = :nomdato ");
		query = query.append("order by h.id.valdato ");

		Query consulta = getEntityManager().createQuery(query.toString());

		consulta.setParameter("nomdato", nomdato);

		return consulta.getResultList();
	}

	public List<Clave> claves() {
		StringBuffer query = new StringBuffer();

		query = query.append("SELECT h ");
		query = query.append("FROM Clave h ");
		query = query.append("order by h.nomdato ");

		Query consulta = getEntityManager().createQuery(query.toString());

		return consulta.getResultList();
	}
	
	public Clave claveByCodigo(String nomdato) {
		StringBuffer query = new StringBuffer();

		query = query.append("SELECT h ");
		query = query.append("FROM Clave h ");
		query = query.append("where h.nomdato = :nomdato");

		Query consulta = getEntityManager().createQuery(query.toString());
		consulta.setParameter("nomdato", nomdato);
		
		List lista = consulta.getResultList();
		if (lista.size() > 0) {
			return (Clave) lista.get(0);
		}
		return null;
	}	
}
