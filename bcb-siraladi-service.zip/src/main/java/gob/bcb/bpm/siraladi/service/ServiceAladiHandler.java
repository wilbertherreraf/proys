package gob.bcb.bpm.siraladi.service;

import java.sql.SQLException;

import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;

import gob.bcb.bpm.siraladi.exceptions.AladiException;

/**
 * @author wilherrera Wilbert Herrera Flores Banco Central de Bolivia
 *         Departamento de Desarrollo
 */
public interface ServiceAladiHandler {
	public void handlerProcesarMsg(RequestContext requestContext) throws AladiException, SQLException, RuntimeException, SystemException,
			NotSupportedException, RollbackException, HeuristicMixedException, HeuristicRollbackException;
}
