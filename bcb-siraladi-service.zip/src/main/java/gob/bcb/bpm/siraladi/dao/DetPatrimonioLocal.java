package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.DetPatrimonio;
import gob.bcb.bpm.siraladi.jpa.DetPatrimonioPK;

public interface DetPatrimonioLocal extends DAO<DetPatrimonioPK, DetPatrimonio>{

	DetPatrimonio actualizarSaldoIFA(String codPersona);

}
