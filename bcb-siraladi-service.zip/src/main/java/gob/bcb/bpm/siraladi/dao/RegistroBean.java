package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.Registro;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


import javax.persistence.Query;
import javax.persistence.TemporalType;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("registroLocal")
@Transactional
public class RegistroBean extends GenericDAO<Integer, Registro> implements RegistroLocal {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gob.bcb.bpm.siraladi.dao.RegistroLocal#getSumDebHabRegistro(java.lang
	 * .Integer, javax.persistence.EntityManager)
	 */
	
	public BigDecimal getSaldoRegistro(Integer nroMovApe) {
		String jpql = "SELECT sum(nvl(p.debeMo, 0) - nvl(p.haberMo, 0)) FROM Registro p " + " WHERE p.nroMovApe = :nroMovApe "
				+ "and p.cveEstadoReg = 'C'";
		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("nroMovApe", nroMovApe);

		List result = query.getResultList();
		if (result.size() > 0){
			Double valor = (Double) result.get(0);
			return (BigDecimal.valueOf((valor == null? Double.valueOf(0):valor)) ) ;			
		}

		return BigDecimal.ZERO;

	}
	
	
	public Registro getByNroMov(Integer nroMov) {
		String jpql = "SELECT p FROM Registro p " + " WHERE p.nroMov = :nroMov";
		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("nroMov", nroMov);

		List result = query.getResultList();
		if (result.size() > 0){
			return (Registro) result.get(0);
		}

		return null;
	}
	
	/* (non-Javadoc)
	 * @see gob.bcb.bpm.siraladi.dao.RegistroLocal#getByNroMovApeCveEstadoReg(java.lang.Integer, java.lang.String)
	 */
	
	public List<Registro> getByNroMovApeCveEstadoReg(Integer nroMovApe, String cveEstadoReg) {
		String jpql = "SELECT p FROM Registro p " + " WHERE p.nroMovApe = :nroMovApe ";
		if (cveEstadoReg != null)
			jpql += "and p.cveEstadoReg = :cveEstadoReg ";
		
		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("nroMovApe", nroMovApe);
		
		if (cveEstadoReg != null)		
			query.setParameter("cveEstadoReg", cveEstadoReg);

		return query.getResultList();
	}

	
	public BigDecimal getMontoSinNroMov(Integer nroMovApe, Integer nroMov) {
		String jpql = "SELECT sum(nvl(p.debeMo, 0) - nvl(p.haberMo, 0)) FROM Registro p " + " WHERE p.nroMovApe = :nroMovApe " + "and p.cveEstadoReg = 'C' "
				+ "and p.nroMov <> :nroMov";
		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("nroMovApe", nroMovApe);
		query.setParameter("nroMov", nroMov);
		
		List result = query.getResultList();
		if (result.size() > 0){
			Double valor = (Double) result.get(0);
			return (BigDecimal.valueOf((valor == null? Double.valueOf(0):valor)) ) ;			
		}

		return BigDecimal.ZERO;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gob.bcb.bpm.siraladi.dao.RegistroLocal#getSaldoCont(java.lang.String,
	 * java.util.Date, java.lang.String)
	 */
	
	public BigDecimal getSaldoCont(String codPersona, Date fechaTrans, String cveTipoApe) {
		if (!cveTipoApe.equals("I") && !cveTipoApe.equals("E")) {
			return new BigDecimal(0);
		}

		String jpql = "SELECT sum(nvl(p.debeMo, 0) - nvl(p.haberMo, 0)) FROM Apertura a, Registro p, PersonaInst c " + " WHERE a.nroMov = p.nroMovApe " + "and "
				+ (cveTipoApe.equals("I") ? "a.institucion.codInst" : "p.institucion.codInst") + " = c.id.codInst "
				+ "and a.cveTipoApe = :cveTipoApe and c.id.codPersona = :codPersona " + "and p.cveEstadoReg = 'C' and p.fechaTrans <= :fechaTrans";
		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("cveTipoApe", cveTipoApe);
		query.setParameter("codPersona", codPersona);
		query.setParameter("fechaTrans", fechaTrans, TemporalType.DATE);

		List result = query.getResultList();
		if (result.size() > 0){
			Double valor = (Double) result.get(0);
			return (BigDecimal.valueOf((valor == null? Double.valueOf(0):valor)) ) ;			
		}

		return BigDecimal.ZERO;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gob.bcb.bpm.siraladi.dao.RegistroLocal#getRegistroByTipoEmis(java.lang
	 * .Integer, java.lang.String, javax.persistence.EntityManager)
	 */
	
	public List<Registro> getRegistroByTipoEmis(Integer nroMov, String cveTipoEmis) {
		String jpql = "SELECT p FROM Registro p WHERE p.nroMovApe = :nroMovApe and p.cveTipoEmis = :cveTipoEmis ";
		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("nroMovApe", nroMov);
		query.setParameter("cveTipoEmis", cveTipoEmis);
		return query.getResultList();
	}
}
