package gob.bcb.bpm.siraladi.common;

import gob.bcb.bpm.siraladi.dao.qnative.QCoinCommos;
import gob.bcb.bpm.siraladi.exceptions.AladiException;
import java.util.Calendar;
import java.util.Date;

/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public class ConsComunesNegocio {

	/**
	 * Calcula o cuenta los d�as habiles antes(- negativo) o despues (+ positivo) de una fecha  
	 * @param fecha fecha a partir de la cual se calcula 
	 * @param diasAntes dias habiles que se debe contar si es negativo es dias antes, positivo dias despues
	 * @return
	 */
	public static Date fecHabilAntesDespuesDe(Date fecha, int diasAntes) {
		if (diasAntes == 0) {
			return fecha;
		}

		if (diasAntes > 365) {
			throw new AladiException("El numero de dias para calcular fecha habil antes de " + diasAntes
					+ " dias es mayor al permitido 365.");
		}

		//QCoinCommos qCoinCommos = new QCoinCommos("aladi");
		QCoinCommos qCoinCommos = new QCoinCommos("coin");

		int diasAbs = (diasAntes < 0 ? -diasAntes : diasAntes);
		int signo = (diasAntes < 0 ? -1 : 1);

		int contDias = 1;
		int cont = 1;

		Calendar fecEval = null;
		fecEval = Calendar.getInstance();
		fecEval.setTime(fecha);

		while (cont <= diasAbs && contDias <= 365) {
			fecEval.setTime(fecha);
			fecEval.add(Calendar.DAY_OF_YEAR, signo * contDias);

			if (qCoinCommos.isHabil(fecEval.getTime())) {
				cont++;
			} 
			contDias++;
		}

		if ((cont > diasAntes) && (fecEval.getTime().before(fecha) || fecEval.getTime().after(fecha))) {
			return fecEval.getTime();
		} else {
			return null;
		}
	}
}
