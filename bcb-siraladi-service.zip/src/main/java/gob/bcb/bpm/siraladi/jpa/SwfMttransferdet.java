package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="swf_mttransferdet")
public class SwfMttransferdet implements Serializable{
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SwfMttransferdetPK id;

	@Column(name="dtt_valcampo")
	private String dttValcampo;

	@Column(name="dtt_tipocampo")
	private String dttTipocampo;
	
	public SwfMttransferdet(){
		
	}
	
	public SwfMttransferdetPK getId() {
		return id;
	}

	public void setId(SwfMttransferdetPK id) {
		this.id = id;
	}

	public String getDttValcampo() {
		return dttValcampo;
	}

	public void setDttValcampo(String dttValcampo) {
		this.dttValcampo = dttValcampo;
	}

	public String getDttTipocampo() {
		return dttTipocampo;
	}

	public void setDttTipocampo(String dttTipocampo) {
		this.dttTipocampo = dttTipocampo;
	}


}
