package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;


/**
 * The persistent class for the persona database table.
 * 
 */
@Entity
@Table(name="persona")
public class Persona implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="cod_persona")
	private String codPersona;

	@Column(name="cod_usuario")
	private String codUsuario;

	@Column(name="cta_encaje")
	private String ctaEncaje;

	@Column(name="cta_mov_a")
	private String ctaMovA;

	@Column(name="cta_mov_b")
	private String ctaMovB;

	@Column(name="cve_tipo_persona")
	private String cveTipoPersona;

	@Column(name="cve_vigente")
	private String cveVigente;

	@Column(name="correos")
	private String correos;
	
	@Column(name="estacion")
	private String estacion;

	@Column(name="fecha_hora")
	private Date fechaHora;

	@Column(name="nom_persona", nullable=false)
	private String nomPersona;

    @ManyToMany
	@JoinTable(
		name="persona_inst"
		, joinColumns={
			@JoinColumn(name="cod_persona")
			}
		, inverseJoinColumns={
			@JoinColumn(name="cod_inst", nullable=false)
			}
		)
	private List<Institucion> institucions;

    public Persona() {
    }

	public String getCodPersona() {
		return this.codPersona;
	}

	public void setCodPersona(String codPersona) {
		this.codPersona = codPersona;
	}

	public String getCodUsuario() {
		return this.codUsuario;
	}

	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}

	public String getCtaEncaje() {
		return this.ctaEncaje;
	}

	public void setCtaEncaje(String ctaEncaje) {
		this.ctaEncaje = ctaEncaje;
	}

	public String getCtaMovA() {
		return this.ctaMovA;
	}

	public void setCtaMovA(String ctaMovA) {
		this.ctaMovA = ctaMovA;
	}

	public String getCtaMovB() {
		return this.ctaMovB;
	}

	public void setCtaMovB(String ctaMovB) {
		this.ctaMovB = ctaMovB;
	}

	public String getCveTipoPersona() {
		return this.cveTipoPersona;
	}

	public void setCveTipoPersona(String cveTipoPersona) {
		this.cveTipoPersona = cveTipoPersona;
	}

	public String getCveVigente() {
		return this.cveVigente;
	}

	public void setCveVigente(String cveVigente) {
		this.cveVigente = cveVigente;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getNomPersona() {
		return this.nomPersona;
	}

	public void setNomPersona(String nomPersona) {
		this.nomPersona = nomPersona;
	}

	public List<Institucion> getInstitucions() {
		return this.institucions;
	}

	public void setInstitucions(List<Institucion> institucions) {
		this.institucions = institucions;
	}

	public void setCorreos(String correos) {
		this.correos = correos;
	}

	public String getCorreos() {
		return correos;
	}
}