package gob.bcb.bpm.siraladi.logic;

import gob.bcb.bpm.siraladi.dao.EntityUserTransaction;
import gob.bcb.bpm.siraladi.dao.InstitucionBean;
import gob.bcb.bpm.siraladi.dao.InstitucionLocal;
import gob.bcb.bpm.siraladi.dao.RegAnticipadoBean;
import gob.bcb.bpm.siraladi.dao.RegAnticipadoLocal;
import gob.bcb.bpm.siraladi.dao.SwfMensajeBean;
import gob.bcb.bpm.siraladi.dao.SwfMensajeLocal;
import gob.bcb.bpm.siraladi.dao.SwfPersonactaBean;
import gob.bcb.bpm.siraladi.dao.SwfPersonactaLocal;
import gob.bcb.bpm.siraladi.dao.UsuarioBean;
import gob.bcb.bpm.siraladi.dao.UsuarioLocal;
import gob.bcb.bpm.siraladi.exceptions.AladiException;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Pais;
import gob.bcb.bpm.siraladi.jpa.RegAnticipado;
import gob.bcb.bpm.siraladi.jpa.SwfMensaje;
import gob.bcb.bpm.siraladi.jpa.SwfPersonacta;
import gob.bcb.bpm.siraladi.jpa.Usuario;
import gob.bcb.bpm.siraladi.utils.Constants;
import gob.bcb.bpm.siraladi.utils.NumeroDAV;
import gob.bcb.swift.pojos.SwiftDatos;
import gob.bcb.swift.service.SwiftMessageService;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import javax.persistence.EntityManager;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

//escuchando train
/**
 * @author wilherrera Wilbert Herrera Flores Banco Central de Bolivia
 *         Departamento de Desarrollo
 */
//
@Service("regAnticipadoServiceLocal")
@Repository
@Transactional
public class RegAnticipadoServiceBean extends EntityUserTransaction implements RegAnticipadoServiceLocal {
	private static Logger log = Logger.getLogger(RegAnticipadoServiceBean.class);
	public static final String CODIGO_MONEDA_DOLARES = "34";
	public static final String CODIGO_MONEDA_DOLARES_SWF = "USD";
	public static final String EST_MEN_SWFT = "P";
	@Autowired
	private RegAnticipadoLocal regAnticipadoLocal;

	private Map<String, Object> warnnings = new HashMap<String, Object>();

	public RegAnticipadoServiceBean() {

	}

	public RegAnticipadoServiceBean(EntityManager entityManager) {
		super(entityManager);
		regAnticipadoLocal = new RegAnticipadoBean();
		regAnticipadoLocal.setEntityManager(entityManager);
	}

	
	public List<RegAnticipado> crearReg(List<RegAnticipado> regAnticipadoListIn) {
		List<RegAnticipado> regAnticipadoList = new ArrayList<RegAnticipado>();
		for (RegAnticipado regAnticipado : regAnticipadoListIn) {
			regAnticipadoList.add(crearReg(regAnticipado));
		}
		return regAnticipadoList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.bpm.siraladi.logic.RegAnticipadoServiceLocal#init()
	 */

	
	public RegAnticipado crearReg(RegAnticipado regAnticipado) {
		String codReembolso = regAnticipado.getNroReembLiteral();
		log.info("Ingresando a crearAnticipado para " + codReembolso + ":::: " + (regAnticipadoLocal == null) + " ge " + (getEntityManager() == null));
		regAnticipado = regAnticipadoLocal.guardar(regAnticipado);
		regAnticipadoLocal.flush();
		return regAnticipado;
	}

	
	public List<RegAnticipado> modificar(List<RegAnticipado> regAnticipadoListIn) {

		List<RegAnticipado> regAnticipadoList = new ArrayList<RegAnticipado>();
		for (RegAnticipado regAnticipado : regAnticipadoListIn) {
			RegAnticipado regAnt = crearReg(regAnticipado);
			if (regAnt != null) {
				regAnticipadoList.add(regAnt);
			}
		}
		return regAnticipadoList;
	}

	
	public RegAnticipado modificar(RegAnticipado regAnticipado) {

		if (regAnticipado == null) {
			throw new AladiException("OBJETO_NULO", new Object[] { "regAnticipado" });
		}

		log.info("ingresando a modificar RegAnticipado " + regAnticipado.getNroMov());

		if (regAnticipado.getCveEstadoAnt() == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Valor estado pago anticipado nulo" });
		}
		String cveEstadoAnt = regAnticipado.getCveEstadoAnt().trim();

		if (regAnticipado.getNroMov() == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Valor codigo nro mov nulo" });
		}

		RegAnticipado regAnticipadoOld = regAnticipadoLocal.findById(regAnticipado.getNroMov(), false);

		if (regAnticipadoOld == null) {
			throw new AladiException("PAGO_ANT_NO_ENCONTRADO", new Object[] { regAnticipado.getNroMov() });
		}

		if (regAnticipadoOld.getCveEstadoAnt().trim().equals("L") || regAnticipadoOld.getCveEstadoAnt().trim().equals("R")) {
			throw new AladiException("PAGO_ANT_INVALIDO_PARA_MODIF", new Object[] { regAnticipado.getNroMov() });
		}

		log.info("Modificando Reg anticiapdo de estado actual " + regAnticipadoOld.getCveEstadoAnt() + " A: " + cveEstadoAnt);

		if (regAnticipadoOld.getCveEstadoAnt().trim().equals("P") && cveEstadoAnt.equals("P")) {
			regAnticipadoOld.setAnio(regAnticipado.getAnio());
			regAnticipadoOld.setCodInst(regAnticipado.getCodInst());
			regAnticipadoOld.setCodId(regAnticipado.getCodId());
			regAnticipadoOld.setSecuencia(regAnticipado.getSecuencia());
			regAnticipadoOld.setCodInstRecep(regAnticipado.getCodInstRecep());
			regAnticipadoOld.setCodInstrumento(regAnticipado.getCodInstrumento());
			regAnticipadoOld.setDebeMo(regAnticipado.getDebeMo());
			regAnticipadoOld.setHaberMo(regAnticipado.getHaberMo());
			regAnticipadoOld.setCodUsuario(regAnticipado.getCodUsuario());			
			regAnticipadoOld.setEstacion(regAnticipado.getEstacion());			
			try {
				regAnticipadoOld.setFechaVal(regAnticipado.getFechaVal());
			} catch (Exception e) {
			}
			regAnticipadoOld.setDav(NumeroDAV.generaDAV(regAnticipadoOld.getCodInst(), regAnticipadoOld.getCodId(), regAnticipadoOld.getAnio(),
					regAnticipadoOld.getSecuencia()));
		} else if (regAnticipadoOld.getCveEstadoAnt().trim().equals("P") && cveEstadoAnt.equals("1")) {
			regAnticipadoOld.setFechaVal(new Date());
		} else if ((regAnticipadoOld.getCveEstadoAnt().trim().equals("P") && cveEstadoAnt.equals("C"))
				|| (regAnticipadoOld.getCveEstadoAnt().trim().equals("P") && cveEstadoAnt.equals("L"))
				|| (regAnticipadoOld.getCveEstadoAnt().trim().equals("1") && cveEstadoAnt.equals("C"))) {

		} else if ((regAnticipadoOld.getCveEstadoAnt().trim().equals("C") && cveEstadoAnt.equals("L"))) {
			log.info("Paso de Contabilizado => Liquidado " + regAnticipado.getNroMov());
			if (regAnticipadoOld.getCveTipoApe().equals("I")) {
				try {
					regAnticipadoOld.setFechaVal(regAnticipado.getFechaVal());
				} catch (Exception e) {
				}
				regAnticipadoOld.setSecuencia(regAnticipado.getSecuencia());
				regAnticipadoOld.setDav(NumeroDAV.generaDAV(regAnticipadoOld.getCodInst(), regAnticipadoOld.getCodId(), regAnticipadoOld.getAnio(),
						regAnticipadoOld.getSecuencia()));
			} else if (regAnticipadoOld.getCveTipoApe().equals("E")) {
				regAnticipadoOld.setCveEstadoAnt(cveEstadoAnt);
				regAnticipadoOld = regAnticipadoLocal.makePersistent(regAnticipadoOld);
				regAnticipadoLocal.flush();
				return regAnticipadoOld;
			}
		}

		regAnticipadoLocal.isValidData(regAnticipadoOld);

		if ((regAnticipadoOld.getCveEstadoAnt().trim().equals("P") && cveEstadoAnt.equals("C"))
				|| (regAnticipadoOld.getCveEstadoAnt().trim().equals("P") && cveEstadoAnt.equals("L"))
				|| (regAnticipadoOld.getCveEstadoAnt().trim().equals("1") && cveEstadoAnt.equals("C"))) {

			// si el estado cambia
			// insertar en estado_mov
			// si se pasa a un estado de contabilizacion
			if (regAnticipadoOld.getCveTipoApe().equals("E")) {
				// en export contabilizado es igual a liquidado
				cveEstadoAnt = "L";
			}
			regAnticipadoOld.setCveEstadoAnt(cveEstadoAnt);
			regAnticipadoOld.setFechaCargo(new Date());
			regAnticipadoOld = regAnticipadoLocal.makePersistent(regAnticipadoOld);
			regAnticipadoLocal.flush();
			// ////////////////////////////////////////////////////
		} else {
			regAnticipadoOld.setCveEstadoAnt(cveEstadoAnt);
			regAnticipadoOld = regAnticipadoLocal.makePersistent(regAnticipadoOld);
			regAnticipadoLocal.flush();
		}
		return regAnticipadoOld;
	}

	
	public void eliminar(RegAnticipado regAnticipado) {
		if (regAnticipado == null) {
			throw new AladiException("ERROR_DE_VALIDACION",
					new Object[] { "Datos de Reg. Anticipado no pueden recuperarse, revise el mensaje enviado" });
		}

		if (regAnticipado.getNroMov() == null) {
			throw new AladiException("OBJETO_NULO", new Object[] { "nroMov" });
		}

		RegAnticipado regAnticipadoOld = regAnticipadoLocal.findById(regAnticipado.getNroMov(), false);

		if (regAnticipadoOld == null) {
			throw new AladiException("PAGO_ANT_NO_ENCONTRADO", new Object[] { regAnticipado.getNroMov() });
		}

		if (!regAnticipadoOld.getCveEstadoAnt().trim().equals("P") && !regAnticipadoOld.getCveEstadoAnt().trim().equals("1")) {
			throw new AladiException("PAGO_ANT_INVALIDO_PARA_MODIF", new Object[] { regAnticipado.getNroMov() });
		}

		if (regAnticipadoOld.getCveTipoApe().trim().equals("I")) {
			log.warn("Operacioon de tipo "  + regAnticipadoOld.getCveTipoApe() + " no corresponde generar swift");
			if (regAnticipadoOld.getCodInstrumento().trim().equals("LEX")) {
				log.warn("Operacioon con instrumento "  + regAnticipadoOld.getCodInstrumento() + " corresponde rechazar swift");
				SwfMensajeLocal swfMensajeLocal = new SwfMensajeBean();
				swfMensajeLocal.setEntityManager(getEntityManager());
				
				swfMensajeLocal.rechazarSwift(String.valueOf(regAnticipadoOld.getNroMov()), regAnticipado.getCodUsuario(), regAnticipado.getEstacion());
			}
		}
		
		regAnticipadoLocal.makeTransient(regAnticipadoOld);
		regAnticipadoLocal.flush();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gob.bcb.bpm.siraladi.logic.RegAnticipadoServiceLocal#isValidData(gob.
	 * bcb.bpm.siraladi.jpa .RegAnticipado)
	 */
	
	public boolean isValidData(RegAnticipado regAnticipado) {

		if (regAnticipado.getCodInstrumento() == null || regAnticipado.getCodInstrumento().trim().isEmpty()) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "El valor de codigo Instrumento involido." });
		}

		if (regAnticipado.getCodInst().equals(regAnticipado.getCodInstRecep())) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "El Banco emisor y el banco Receptor son idonticos. Revise los datos." });
		}

		if (regAnticipado.getDebeMo() == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Monto del Debe invalido." });
		}
		if (regAnticipado.getHaberMo() == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Monto del Haber invalido." });
		}
		if (!NumeroDAV.verificaDAV(regAnticipado.getCodInst(), regAnticipado.getCodId(), regAnticipado.getAnio(), regAnticipado.getSecuencia(),
				regAnticipado.getDav())) {
			throw new AladiException(
					"El nomero autoverificador (DAV) : '"
							+ regAnticipado.getDav()
							+ "', difiere con el nomero elaborado por el sistema: '"
							+ NumeroDAV.generaDAV(regAnticipado.getCodInst(), regAnticipado.getCodId(), regAnticipado.getAnio(),
									regAnticipado.getSecuencia()) + "'.Verifique el codigo.");
		}

		if ((regAnticipado.getDebeMo().compareTo(BigDecimal.valueOf(0)) == 0) && (regAnticipado.getHaberMo().compareTo(BigDecimal.valueOf(0)) == 0)) {
			throw new AladiException("ERROR_DE_VALIDACION",
					new Object[] { "Los montos del DEBE y el HABER son iguales a CERO. Corrija los datos para continuar" });
		}

		InstitucionLocal institucionLocal = new InstitucionBean();
		institucionLocal.setEntityManager(getEntityManager());

		if (regAnticipado.getCveTipoApe().equals("I")) {
			Institucion institucion = institucionLocal.findById(regAnticipado.getCodInstRecep(), false);

			if (institucion == null) {
				throw new AladiException("INSTITUCION_NO_ENCONTRADA", new Object[] { regAnticipado.getCodInstRecep() });
			}

			Pais pais = getEntityManager().find(Pais.class, institucion.getPais().getCodPais());

			if (pais == null) {
				throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Pais convenio inexistente " + institucion.getPais().getCodPais() });
			}

			if (regAnticipado.getCodInstrumento().equals("ALE")) {
				if (regAnticipado.getHaberMo().compareTo(BigDecimal.valueOf(0)) == 0) {
					throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "ALE: Importe de Haber con valor nulo o cero" });
				}
			} else {
				if (regAnticipado.getDebeMo() == null || regAnticipado.getDebeMo().compareTo(BigDecimal.valueOf(0)) == 0) {
					throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Importe de DEBE con valor nulo o cero" });
				}
			}
		} else if (regAnticipado.getCveTipoApe().equals("E")) {
			Institucion institucion = institucionLocal.findById(regAnticipado.getCodInst(), false);

			if (institucion == null) {
				throw new AladiException("INSTITUCION_NO_ENCONTRADA", new Object[] { regAnticipado.getCodInst() });
			}

			if (regAnticipado.getCodInstrumento().equals("ALE")) {
				if (regAnticipado.getDebeMo().compareTo(BigDecimal.valueOf(0)) == 0) {
					throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "ALE: Importe de DEBE con valor nulo o cero" });
				}
			} else {
				if (regAnticipado.getHaberMo() == null || regAnticipado.getHaberMo().compareTo(BigDecimal.valueOf(0)) == 0) {
					throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Importe de HABER con valor nulo o cero" });
				}
			}
		} else {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Tipo de operacion invalido debe ser I(Importacion) o E(Exportacion)" });
		}

		return true;
	}

	public RegAnticipado crearPAnticipadoSwift(RegAnticipado regAnticipado) {
		log.info("Inicio crearPAnticipadoSwift ");
		
		RegAnticipado regAnticipadoNew = crearReg(regAnticipado);
		
		crearSwiftDeRegAnticipado(regAnticipadoNew);
		
		log.info("Fin crearPAnticipadoSwift " + regAnticipado.getNroMov());
		return regAnticipadoNew;
	}

	public RegAnticipado modificarPAnticipadoSwift(RegAnticipado regAnticipado) {
		log.info("Inicio modificarPAnticipadoSwift	 " + regAnticipado.getNroMov());

		RegAnticipado regAnticipadoNew = modificar(regAnticipado);

		crearSwiftDeRegAnticipado(regAnticipadoNew);
		log.info("Fin crearPAnticipadoSwift " + regAnticipado.getNroMov());

		return regAnticipadoNew;
	}

	public SwfMensaje crearSwiftDeRegAnticipado(RegAnticipado regAnticipado) {

		RegAnticipado regAnticipadoOld = regAnticipadoLocal.findByNroMov(regAnticipado.getNroMov());
		if (regAnticipadoOld == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Operacion (" + regAnticipado.getNroMov() + ") inexistente" });
		}
		if (!regAnticipadoOld.getCveTipoApe().trim().equals("I")) {
			log.warn("Operacioon de tipo "  + regAnticipadoOld.getCveTipoApe() + " no corresponde generar swift");
			return null;
//			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Tipo de operacion (" + regAnticipadoOld.getCveTipoApe()
//					+ ") invalido debe ser I(Importacion)" });
		}
		if (!regAnticipadoOld.getCodInstrumento().trim().equals("LEX")) {
			log.warn("Operacioon con instrumento "  + regAnticipadoOld.getCodInstrumento() + " no corresponde generar swift");
			return null;			
//			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Operacion (" + regAnticipadoOld.getNroMov() + ") con instrumento ["
//					+ regAnticipadoOld.getCodInstrumento() + "] no valido" });
		}
		if (!regAnticipadoOld.getCveEstadoAnt().trim().equals("P")) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Operacion (" + regAnticipadoOld.getNroMov() + ") con estado ["
					+ regAnticipadoOld.getCveEstadoAnt() + "] no puede continuar" });
		}
		// registra el mensaje swift con los datos de la operacion
		log.info("generando info de mensaje swift " + regAnticipadoOld.toString() + " " + regAnticipadoOld.getCodInstRecep());

		SwiftDatos swiftDatos = new SwiftDatos();
		
		swiftDatos.setAuditusr(regAnticipadoOld.getCodUsuario());
		swiftDatos.setAuditwst(regAnticipadoOld.getEstacion());
		
		SwfMensajeLocal swfMensajeLocal = new SwfMensajeBean();
		swfMensajeLocal.setEntityManager(getEntityManager());

		SwfMensaje swfMensaje = swfMensajeLocal.findByCodoperacion(String.valueOf(regAnticipadoOld.getNroMov()), Constants.PAR_ESTSWIFT_AUTO);
		
		if (swfMensaje != null) {
			log.error("Operacion (" + regAnticipadoOld.getNroMov() + ") con Mensaje swift autorizado " + regAnticipadoOld.getNroMov());
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Operacion (" + regAnticipadoOld.getNroMov()
					+ ") con Mensaje swift autorizado " + swfMensaje.getMenCodmen() });
		}

		swfMensaje = swfMensajeLocal.findByCodoperacion(String.valueOf(regAnticipadoOld.getNroMov()), null);
		
		if (swfMensaje == null) {
			swfMensaje = new SwfMensaje();
			swfMensaje.setMenCodoperacion(String.valueOf(regAnticipadoOld.getNroMov()));			
		}
		
		SwiftMessageService swiftMessageService = new SwiftMessageService(getEntityManager());

		InstitucionLocal institucionLocal = new InstitucionBean();
		institucionLocal.setEntityManager(getEntityManager());

		UsuarioLocal usuarioLocal = new UsuarioBean();
		usuarioLocal.setEntityManager(getEntityManager());
		
		SwfPersonactaLocal swfPersonactaLocal = new SwfPersonactaBean();
		swfPersonactaLocal.setEntityManager(getEntityManager());

		Institucion institucionSender = institucionLocal.findByCodInst(regAnticipadoOld.getCodInst());
		SwfPersonacta swfPersonactaSender = swfPersonactaLocal.findByCodigo(institucionSender.getCodInst(), institucionSender.getCtaCodinst(),
				institucionSender.getCtaNumero());

		if (swfPersonactaSender == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Swift: Error de parametrización institucion "
					+ institucionSender.getCodInst() + " sin ctas parametrizadas" });
		}
		swiftDatos.newSwfBicsSender(institucionSender.getBic(), "", institucionSender.getNomInst(), null, institucionSender.getNomPlaza(),
				institucionSender.getPais().getNomPais());
		swiftDatos.setSender(swfPersonactaSender);

		Institucion institucionReceiver = institucionLocal.findByCodInst(institucionSender.getCtaCodinst());
		if (institucionReceiver == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Swift: Error de parametrización institucion "
					+ institucionSender.getCodInst() + " sin banco destino" });
		}

		swiftDatos.newSwfBicsReceiver(institucionReceiver.getBic(), "", institucionReceiver.getNomInst(), null, institucionReceiver.getNomPlaza(),
				institucionReceiver.getPais().getNomPais());

		Institucion institucionBenef = institucionLocal.findByCodInst(regAnticipadoOld.getCodInstRecep());
		SwfPersonacta swfPersonactaBenef = swfPersonactaLocal.findByCodigo(institucionBenef.getCodInst(), institucionBenef.getCtaCodinst(),
				institucionBenef.getCtaNumero());

		if (swfPersonactaBenef == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Swift: Error de parametrización institucion benefiacia "
					+ institucionBenef.getCodInst() + " sin ctas parametrizadas" });
		}

		swiftDatos.setBeneficiario(swfPersonactaBenef);
		Calendar c = GregorianCalendar.getInstance();

		swfMensaje.setMenBicemisor(institucionSender.getBic());
		swfMensaje.setMenGestion(c.get(Calendar.YEAR));
		swfMensaje.setMenMonto(regAnticipadoOld.getDebeMo());
		swfMensaje.setMenCodmon(Integer.valueOf(regAnticipadoOld.getCodMoneda().trim()));
		swfMensaje.setMenCodmonswift(Constants.CODIGO_MONEDA_DOLARES_SWF);
		swfMensaje.setMenFecreg(new Date());
		swfMensaje.setMenFecvalor(regAnticipadoOld.getFechaCargo());
		swfMensaje.setMenCveestswift(Constants.PAR_ESTSWIFT_PEND);
		
		Usuario usuario = usuarioLocal.findByCodigo(regAnticipadoOld.getCodUsuario());
		if (usuario == null){
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Swift: Error de parametrización usuario "
					+ regAnticipadoOld.getCodUsuario() + " inexistente en tabla usuario" });			
		}
		
		if (StringUtils.isBlank(usuario.getUsrIniciales())){
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Swift: Error de parametrización usuario "
					+ regAnticipadoOld.getCodUsuario() + " con iniciales nulo" });			
		}
		
		swfMensaje.setMenCodusrswf(usuario.getUsrIniciales());
		swfMensaje.setMenAuditusr(regAnticipadoOld.getCodUsuario());
		swfMensaje.setMenAuditwst(regAnticipadoOld.getEstacion());

		swiftDatos.setSwfMensaje(swfMensaje);
		SwfMensaje swfMensajeNew = swiftMessageService.generarMensaje(swiftDatos);

		log.info("Swift creado " + swfMensajeNew.getMenCodmen());
		return swfMensaje;
	}

	
	public RegAnticipadoLocal getRegAnticipadoLocal() {
		return regAnticipadoLocal;
	}

	
	public Map<String, Object> getWarnnings() {
		return warnnings;
	}
}
