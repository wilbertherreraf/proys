package gob.bcb.bpm.siraladi.logic;

import java.util.List;
import java.util.Map;


import gob.bcb.bpm.siraladi.dao.AperturaLocal;
import gob.bcb.bpm.siraladi.dao.PlanPagoLocal;
import gob.bcb.bpm.siraladi.dao.UserTransactionServ;
import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.PlanPago;
import gob.bcb.bpm.siraladi.jpa.Registro;
/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */

public interface PlanPagosServiceLocal extends UserTransactionServ{
	PlanPago modificar(PlanPago planPago, Apertura apertura);	
	PlanPago crearReg(PlanPago planPago, Apertura apertura);	
	List<PlanPago> crearReg(List<PlanPago> planPagoListIn, Apertura apertura);
	PlanPagoLocal getPlanPagoLocal();
	boolean isValidData(PlanPago planPago, Apertura apertura);
	Map<String, Object> getWarnnings();
	PlanPago crearPrimerPlan(Apertura apertura, Registro registro);
	void eliminar(Apertura apertura);
	void registroWSPorExport(PlanPago planPago, Apertura apertura, String tipoOperacionAladi);	
}
