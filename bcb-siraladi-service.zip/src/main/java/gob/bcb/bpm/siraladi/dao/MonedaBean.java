package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.Moneda;



import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("monedaLocal")
@Transactional
public class MonedaBean extends GenericDAO<String, Moneda> implements MonedaLocal {

/*	
	public Moneda findMoneda(String codMoneda){
		return getEntityManager().find(Moneda.class, codMoneda);
	}*/

}
