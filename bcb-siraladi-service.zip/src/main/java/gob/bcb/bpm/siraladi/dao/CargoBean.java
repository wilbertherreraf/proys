package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.Cargo;

import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("cargoLocal")
@Transactional
public class CargoBean extends GenericDAO<Integer, Cargo> implements CargoLocal {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gob.bcb.bpm.siraladi.dao.CargoLocal#findByCodCargo(java.lang.Integer)
	 */
	
	public Cargo findByCodCargo(Integer codCargo) {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT a ");
		sb.append("FROM Cargo a ");
		sb.append("where a.codCargo = :codCargo ");
		Query query = getEntityManager().createQuery(sb.toString());
		query.setParameter("codCargo", codCargo);

		List result = query.getResultList();
		if (result.size() > 0)
			return (Cargo) result.get(0);

		return null;
	}

	public Cargo findByCodPersona(String codPersona, String cveTipoApe, String cveTipoCargo) {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT a ");
		sb.append("FROM Cargo a ");
		sb.append("where a.codPersona = :codPersona ");
		sb.append("and a.cveTipoApe = :cveTipoApe ");
		sb.append("and a.cveTipoCargo = :cveTipoCargo ");

		Query query = getEntityManager().createQuery(sb.toString());
		query.setParameter("codPersona", codPersona);
		query.setParameter("cveTipoApe", cveTipoApe);
		query.setParameter("cveTipoCargo", cveTipoCargo);

		List result = query.getResultList();
		if (result.size() > 0)
			return (Cargo) result.get(0);

		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gob.bcb.bpm.siraladi.dao.CargoLocal#findByCodPersona(java.lang.String)
	 */
	
	public List<Cargo> findByCodPersona(String codPersona) {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT a ");
		sb.append("FROM Cargo a ");
		sb.append("where a.codPersona = :codPersona ");
		Query query = getEntityManager().createQuery(sb.toString());
		query.setParameter("codPersona", codPersona.trim());

		List result = query.getResultList();
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gob.bcb.bpm.siraladi.dao.CargoLocal#saveorupdate(gob.bcb.bpm.siraladi
	 * .jpa.Cargo)
	 */
	
	public Cargo saveorupdate(Cargo params) {
		Cargo horarioOld = findByCodPersona(params.getCodPersona(), params.getCveTipoApe(), params.getCveTipoCargo());

		if (horarioOld == null) {
			Integer max = getMaxMovimiento().getCodCargo();
			max++;
			params.setCodCargo(max);
			makePersistent(params);
		} else {
			horarioOld.setCtaCoin(params.getCtaCoin());
			horarioOld.setCodMoneda(params.getCodMoneda());
			horarioOld.setValor(params.getValor());
			makePersistent(horarioOld);
		}

		horarioOld = findByCodPersona(params.getCodPersona(), params.getCveTipoApe(), params.getCveTipoCargo());
		log.info("Actualizando Cargo " + horarioOld.toString());
		return horarioOld;
	}

	public Cargo getMaxMovimiento() {
		Cargo movimiento = null;
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT p ");
		sb.append("FROM Cargo p ");
		sb.append("where p.codCargo = (select max(m.codCargo) from Cargo m) ");

		Query query = getEntityManager().createQuery(sb.toString());

		List result = query.getResultList();
		if (result.size() > 0)
			movimiento = (Cargo) result.get(0);

		return movimiento;
	}
}
