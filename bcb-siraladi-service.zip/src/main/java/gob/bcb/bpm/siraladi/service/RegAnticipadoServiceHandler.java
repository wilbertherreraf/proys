package gob.bcb.bpm.siraladi.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;

import org.apache.log4j.Logger;

import gob.bcb.bpm.siraladi.dao.SwfMensajeBean;
import gob.bcb.bpm.siraladi.dao.SwfMensajeLocal;
import gob.bcb.bpm.siraladi.exceptions.AladiException;
import gob.bcb.bpm.siraladi.jpa.RegAnticipado;
import gob.bcb.bpm.siraladi.jpa.SwfMensaje;
import gob.bcb.bpm.siraladi.logic.RegAnticipadoServiceBean;
import gob.bcb.bpm.siraladi.logic.RegAnticipadoServiceLocal;
import gob.bcb.bpm.siraladi.pojo.SaldoConvenio;
import gob.bcb.bpm.siraladi.utils.Constants;
import gob.bcb.bpm.siraladi.utils.StatusCode;
import gob.bcb.bpm.siraladi.ws.clientaladi.ClientAladiWSHandler;
import gob.bcb.swift.service.SwiftMessageService;

/**
 * @author wilherrera Wilbert Herrera Flores Banco Central de Bolivia
 *         Departamento de Desarrollo
 */
public class RegAnticipadoServiceHandler implements ServiceAladiHandler {
	private static Logger log = Logger.getLogger(RegAnticipadoServiceHandler.class);
	@PersistenceContext(unitName = "ALADI_PU")
	private EntityManager entityManager;
	private RegAnticipadoServiceLocal regAnticipadoService;

	public RegAnticipadoServiceHandler(EntityManager entityManager) {
		this.entityManager = entityManager;
		regAnticipadoService = new RegAnticipadoServiceBean(entityManager);
	}

	
	public void handlerProcesarMsg(RequestContext requestContext) throws AladiException, NotSupportedException, SystemException, SecurityException,
			IllegalStateException, RollbackException, HeuristicMixedException, HeuristicRollbackException {
		String statusCode = StatusCode.OPERACION_RECEIVED;
		String consent = null;

		Map<String, Object> parametros = requestContext.getBcbRequest().getRequestElements();

		String codTipoOperacion = requestContext.getResponseContext().getCodTipoOperacion();

		ResponseContext response = requestContext.getResponseContext();

		log.info("inicio tipo de operacion " + codTipoOperacion);

		if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0401)) {
			// crear nuevo transaccion
			List<RegAnticipado> regAnticipadoList = (List<RegAnticipado>) parametros.get("listareganticipado");
			if (regAnticipadoList == null || regAnticipadoList.size() == 0) {
				throw new AladiException("OBJETO_NULO", new Object[] { "listareganticipado" });
			}

			regAnticipadoService.begin();
			regAnticipadoList = regAnticipadoService.crearReg(regAnticipadoList);
			response.addDescripcionParametro(codTipoOperacion, "listareganticipado", "Custom", regAnticipadoList);

			regAnticipadoService.commit();

			log.info("Transaccion reg. Anticipado creada satisfactoriamente");
			statusCode = StatusCode.OPERACION_SUCCESS;
			consent = "Operacion efectuada existosamente";

		} else if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0402)) {
			// consulta de pendientes
			String cveEstadoAnt = (String) parametros.get("cveEstadoAnt");

			List<RegAnticipado> regAnticipadoList = regAnticipadoService.getRegAnticipadoLocal().getRegAnticipadoByEstado(cveEstadoAnt);
			response.addDescripcionParametro(codTipoOperacion, "reganticipado", "Custom", regAnticipadoList);

			statusCode = StatusCode.OPERACION_SUCCESS;
			consent = "Operacion efectuada existosamente.";
		} else if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0403)) {
			// consulta a ws por saldos bilaterales numerales y saldos de
			// emisiones y debitos
			Date fechaDesde = (Date) parametros.get("fechaDesde");
			Date fechaHasta = (Date) parametros.get("fechaHasta");
			Date fechaAl = (Date) parametros.get("fechaAl");

			if (fechaDesde == null || fechaHasta == null || fechaAl == null) {
				throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Parametros de consulta invalidos o nulos" });
			}

			if (fechaDesde.after(fechaHasta)) {
				throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Fecha desde debe ser anterior a fecha hasta" });
			}

			if (fechaHasta.after(fechaAl)) {
				throw new AladiException("ERROR_DE_VALIDACION",
						new Object[] { "Fecha Al(fecha de calculo para pendientes) debe ser posterior a fecha hasta" });
			}
			List<SaldoConvenio> saldoConvenioList = ClientAladiWSHandler.execWSasicapCsbn(fechaDesde, fechaHasta, fechaAl, entityManager);
			response.addDescripcionParametro(codTipoOperacion, "listasaldoconvenio", "Custom", saldoConvenioList);

			statusCode = StatusCode.OPERACION_SUCCESS;
			consent = "Consulta efectuada existosamente";
		} else if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0404)) {
			// modificacion 
			RegAnticipado regAnticipado = (RegAnticipado) parametros.get("reganticipado");
			regAnticipadoService.begin();

			regAnticipado = regAnticipadoService.modificar(regAnticipado);
			response.addDescripcionParametro(codTipoOperacion, "reganticipado", "Custom", regAnticipado);

			regAnticipadoService.commit();

			statusCode = StatusCode.OPERACION_SUCCESS;
			consent = "Operacion efectuada existosamente nro Mov: " + regAnticipado.getNroMov();
			
		} else if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0405)) {
			RegAnticipado regAnticipado = (RegAnticipado) parametros.get("reganticipado");
			regAnticipadoService.begin();
			regAnticipadoService.eliminar(regAnticipado);
			regAnticipadoService.commit();

			statusCode = StatusCode.OPERACION_SUCCESS;
			consent = "Operacion eliminada existosamente nro Mov: " + regAnticipado.getNroMov();
			
		} else if (codTipoOperacion.equalsIgnoreCase("SWF_PREAUTO")) {
			// modificacion
			SwfMensajeLocal swfMensajeLocal = new SwfMensajeBean();
			swfMensajeLocal.setEntityManager(entityManager);

			SwiftMessageService swiftMessageService = new SwiftMessageService(entityManager);
			
			RegAnticipado regAnticipado = (RegAnticipado) parametros.get("reganticipado");
			regAnticipadoService.begin();
			SwfMensaje swfMensaje = swfMensajeLocal.findByCodigo(regAnticipado.getNroMov());
			log.info("inicio pre autorizar MenCodmen() " + swfMensaje.getMenCodmen());
			
			swfMensaje.setMenAuditusr(regAnticipado.getCodUsuario());
			swfMensaje.setMenAuditwst(regAnticipado.getEstacion());
			
			swiftMessageService.actualizarCorrelativo(swfMensaje);

			response.addDescripcionParametro(codTipoOperacion, "reganticipado", "Custom", regAnticipado);

			regAnticipadoService.commit();

			statusCode = StatusCode.OPERACION_SUCCESS;
			consent = "Operacion efectuada existosamente nro Mov: " + regAnticipado.getNroMov();
			
		} else if (codTipoOperacion.equalsIgnoreCase("SWF_AUTO")) {
			// modificacion
			//directorios
			//reporte
			SwfMensajeLocal swfMensajeLocal = new SwfMensajeBean();
			swfMensajeLocal.setEntityManager(entityManager);

			SwiftMessageService swiftMessageService = new SwiftMessageService(entityManager);
			
			RegAnticipado regAnticipado = (RegAnticipado) parametros.get("reganticipado");
			regAnticipadoService.begin();
			SwfMensaje swfMensaje = swfMensajeLocal.findByCodigo(regAnticipado.getNroMov());
			
			log.info("inicio autorizar MenCodmen() " + swfMensaje.getMenCodmen());
			
			swfMensaje.setMenAuditusr(regAnticipado.getCodUsuario());
			swfMensaje.setMenAuditwst(regAnticipado.getEstacion());
			
			swiftMessageService.autorizarMensaje(swfMensaje);

			response.addDescripcionParametro(codTipoOperacion, "reganticipado", "Custom", regAnticipado);

			regAnticipadoService.commit();

			statusCode = StatusCode.OPERACION_SUCCESS;
			consent = "Operacion efectuada existosamente nro Mov: " + regAnticipado.getNroMov();			
		} else {
			throw new AladiException("TIPO_DE_OPERACION_NO_IMPLEMENTADA", new Object[] { requestContext.getResponseContext().getOperacionAladi()
					.getCodTipoOperacion() });
		}
		response.updateReponse(statusCode, consent);
		log.info("Operacion realizada exitosamente operacion " + codTipoOperacion);

	}

}
