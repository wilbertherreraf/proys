package gob.bcb.bpm.siraladi.utils;

import gob.bcb.bpm.siraladi.service.ConfigurationServ;
import gob.bcb.bpm.siraladi.service.ServiceAladiHandler;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
//import java.util.logging.Logger;
import org.apache.commons.configuration.XMLConfiguration;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;

import com.thoughtworks.xstream.XStream;

import java.io.BufferedReader;
import java.io.FileReader;
import java.lang.reflect.Constructor;

import javax.persistence.EntityManager;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public final class Utils {
	private static Logger log = Logger.getLogger(Utils.class.getName());

	/**
	 * Making nice XML for output in browser, i.e. converting &lt; to &amp;lt;, &gt; to &amp;gt;
	 * etc.
	 */
	public static String makeXML(String param) {
		String xml = param;
		if (xml != null && !"".equals(xml)) {
			xml = xml.replaceAll("><", ">\n<");
			xml = xml.replaceAll("<", "&lt;");
			xml = xml.replaceAll(">", "&gt;");
			xml = xml.replaceAll("\n", "<br />");
		}
		return xml;
	}

	/**
	 * @return A beautified xml string
	 */
	public static String beautifyAndHtmlXML(String xml, String split) {
		return makeXML(beautifyXML(xml, split));
	}

	/**
	 * @return A beautified xml string
	 */
	public static String beautifyXML(String xml, String split) {
		String s = "";
		if (split != null)
			s = ".:split:.";

		if (xml == null || "".equals(xml))
			return xml;

		StringBuffer result = new StringBuffer();

		String[] results = xml.split("<");
		for (int i = 1; i < results.length; i++) {
			results[i] = "<" + results[i].trim();
			if (results[i].endsWith("/>")) {
				result.append(results[i]).append(s);
			} else if (results[i].startsWith("</")) {
				result.append(results[i]).append(s);
			} else if (results[i].endsWith(">")) {
				result.append(results[i]).append(s);
			} else {
				result.append(results[i]);
			}
		}
		// result = result.trim();

		if (split == null)
			return result.toString().trim();

		StringBuilder newResult = new StringBuilder();
		String ident = "";
		results = result.toString().split(s);
		for (int i = 0; i < results.length; i++) {
			if (results[i].startsWith("</"))
				ident = ident.substring(split.length());

			newResult.append(ident).append(results[i]).append("\n");

			if (!results[i].startsWith("<!") && !results[i].startsWith("<?") && results[i].indexOf("</") == -1
					&& results[i].indexOf("/>") == -1)
				ident += split;
		}
		return newResult.toString();
	}

	/**
	 * Generate a valid xs:ID string.
	 */
	public static String generateUUID() {
		return "_" + UUID.randomUUID().toString();
	}

	public static String objectToXML(Object object) {
		String xml = null;
		XStream xstream = new XStream();
		String packageObject[] = object.getClass().getPackage().toString().split(" ");
		if (packageObject.length == 1) {
			xstream.aliasPackage("", packageObject[0].trim());
		} else if (packageObject.length > 1) {
			xstream.aliasPackage("", packageObject[1].trim());
		}
		xml = xstream.toXML(object);
		return xml;
	}

	public static Object newInstance(String name) {
		try {
			Class<?> c = Class.forName(name);
			return c.newInstance();
		} catch (Exception e) {
			throw new RuntimeException("No se puede crear instancia de " + name, e);
		}
	}

	public static Object newInstance(ConfigurationServ cfg, String property) {
		String name = (String) ConfigurationServ.getConfigProperty(property, "string");
		if (name == null) {
			throw new IllegalArgumentException("Propiedad " + property + " no tiene su clase a implementar");
		}
		if (log.isDebugEnabled())
			log.debug("Usando handler " + name + " para propiedad " + property);
		try {
			Class<?> c = Class.forName(name);
			return c.newInstance();
		} catch (Exception e) {
			throw new RuntimeException("No se puede crear instancia de " + name, e);
		}
	}

	public static Map<String, ServiceAladiHandler> getHandlers(ConfigurationServ config, EntityManager entityManager) {
		Map<String, ServiceAladiHandler> handlers = new HashMap<String, ServiceAladiHandler>();

		for (Iterator<?> i = ConfigurationServ.getKeys(); i.hasNext();) {
			String key = (String) i.next();
			// if (!key.startsWith("bcb.gob.siraladi.service.")) continue;
			String className = ConfigurationServ.getClassHandler(key).getClassHandler();
			log.info("Checking " + key + ", className " + className);

			try {
				Class<?> c = Class.forName(className);
				ServiceAladiHandler instance;
				try {
					Constructor<?> constructor = c.getConstructor(ConfigurationServ.class);
					instance = (ServiceAladiHandler) constructor.newInstance(config);
				} catch (NoSuchMethodException e) {
					try {
						Constructor<?> constructor = c.getConstructor(EntityManager.class);
						instance = (ServiceAladiHandler) constructor.newInstance(entityManager);
					} catch (NoSuchMethodException ex) {
						instance = (ServiceAladiHandler) c.newInstance();
					}
				}

				// handlers.put(key.substring(key.lastIndexOf('.') + 1), instance);
				handlers.put(key, instance);
			} catch (Exception e) {
				log.error("Unable to instantiate " + key + ": " + className, e);
				throw new RuntimeException(e);
			}
		}

		return handlers;
	}

	public static String readFileAsString(String filePath) throws java.io.IOException {
		String result = null;
		BufferedReader reader = null;
		try {
			StringBuffer fileData = new StringBuffer(1000);
			reader = new BufferedReader(new FileReader(filePath));
			char[] buf = new char[1024];
			int numRead = 0;
			while ((numRead = reader.read(buf)) != -1) {
				fileData.append(buf, 0, numRead);
			}
			reader.close();
			result = fileData.toString();
		} finally {
			try{
				reader.close();
			}catch (Exception e) {
				// no hacer nada
			}
		}
		return result;
	}
	
	/**
	 * Dado un objeto XMLConfiguration busca mediante una consulta xpath una valor en el mismo
	 * @param config Archivo XMLConfiguration contenedor de propiedades
	 * @param expXpath ruta de consulta escrita en formato xpath
	 * @param typeValRet tipo de dato del valor a retornar string, number, node o dom
	 * @return  los tipos de valores retornados pueden ser string, number, node o dom
	 */
	public static Object getValueFromXML(XMLConfiguration config, String expXpath, String typeValRet) {
		Object propResult = null;

		Document document = config.getDocument();
		try {
			XPathFactory xFactory = XPathFactory.newInstance();
			XPath xpath = xFactory.newXPath();
			XPathExpression exp = null;

			exp = xpath.compile(expXpath);

			if (typeValRet.equalsIgnoreCase("STRING")) {
				propResult = exp.evaluate(document, XPathConstants.STRING);
			} else if (typeValRet.equalsIgnoreCase("NUMBER")) {
				propResult = exp.evaluate(document, XPathConstants.NUMBER);
			} else if (typeValRet.equalsIgnoreCase("NODE")) {
				propResult = exp.evaluate(document, XPathConstants.NODE);
			} else if (typeValRet.equalsIgnoreCase("DOM")) {
				propResult = exp.evaluate(document);
			}

		} catch (XPathExpressionException e) {
			document = null;
			throw new RuntimeException(e);
		} catch (Exception e) {
			document = null;
			throw new RuntimeException(e);
		}
		document = null;
		return propResult;
	}
	
}
