package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the per_tipo_cuenta database table.
 * 
 */
@Embeddable
public class PerTipoCuentaPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="cod_persona")
	private String codPersona;

	@Column(name="cod_id")
	private String codId;

	@Column(name="cve_tipo_ape")
	private String cveTipoApe;

	@Column(name="cod_moneda")
	private String codMoneda;

    public PerTipoCuentaPK() {
    }
	public String getCodPersona() {
		return this.codPersona;
	}
	public void setCodPersona(String codPersona) {
		this.codPersona = codPersona;
	}
	public String getCodId() {
		return this.codId;
	}
	public void setCodId(String codId) {
		this.codId = codId;
	}
	public String getCveTipoApe() {
		return this.cveTipoApe;
	}
	public void setCveTipoApe(String cveTipoApe) {
		this.cveTipoApe = cveTipoApe;
	}
	public String getCodMoneda() {
		return this.codMoneda;
	}
	public void setCodMoneda(String codMoneda) {
		this.codMoneda = codMoneda;
	}

	
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof PerTipoCuentaPK)) {
			return false;
		}
		PerTipoCuentaPK castOther = (PerTipoCuentaPK)other;
		return 
			this.codPersona.equals(castOther.codPersona)
			&& this.codId.equals(castOther.codId)
			&& this.cveTipoApe.equals(castOther.cveTipoApe)
			&& this.codMoneda.equals(castOther.codMoneda);

    }
    
	
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.codPersona.hashCode();
		hash = hash * prime + this.codId.hashCode();
		hash = hash * prime + this.cveTipoApe.hashCode();
		hash = hash * prime + this.codMoneda.hashCode();
		
		return hash;
    }
}
