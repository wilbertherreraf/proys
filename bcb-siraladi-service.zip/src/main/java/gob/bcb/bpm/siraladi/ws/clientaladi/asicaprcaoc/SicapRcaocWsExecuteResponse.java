
package gob.bcb.bpm.siraladi.ws.clientaladi.asicaprcaoc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Sicap" type="{BCRP}sdtSICAPRCAOC"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "sicap"
})
@XmlRootElement(name = "sicap_rcaoc_ws.ExecuteResponse")
public class SicapRcaocWsExecuteResponse {

    @XmlElement(name = "Sicap", required = true)
    protected SdtSICAPRCAOC sicap;

    /**
     * Gets the value of the sicap property.
     * 
     * @return
     *     possible object is
     *     {@link SdtSICAPRCAOC }
     *     
     */
    public SdtSICAPRCAOC getSicap() {
        return sicap;
    }

    /**
     * Sets the value of the sicap property.
     * 
     * @param value
     *     allowed object is
     *     {@link SdtSICAPRCAOC }
     *     
     */
    public void setSicap(SdtSICAPRCAOC value) {
        this.sicap = value;
    }

}
