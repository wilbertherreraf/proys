package gob.bcb.bpm.siraladi.jpa;

import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Identificador;
import gob.bcb.bpm.siraladi.jpa.Pais;
import gob.bcb.bpm.siraladi.utils.UtilsDate;

import javax.persistence.*;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the apertura database table.
 * 
 */
/**
 * @author wilherrera
 * 
 */
@Entity
@Table(name = "apertura")
@NamedQueries({ @NamedQuery(name = "Apertura.findAll", query = "SELECT a FROM Apertura a order by a.fechaEmis") })
public class Apertura implements Serializable {

	// private static final long serialVersionUID = 1L; implements Serializable

	@Id
	@Column(name = "nro_mov", unique = true, nullable = false)
	private Integer nroMov;

	@Column(name = "anio")
	private String anio;

	@Column(name = "cod_calif")
	private String codCalif;

	@Column(name = "cod_moneda")
	private String codMoneda;

	@Column(name = "cod_usuario")
	private String codUsuario;

	@Column(name = "cve_estado_ape")
	private String cveEstadoApe;

	@Column(name = "cve_tipo_ape")
	private String cveTipoApe;

	@Column(name = "cve_tipo_calc")
	private String cveTipoCalc;

	@Column(name = "dav")
	private Integer dav;

	@Column(name = "estacion")
	private String estacion;

	@Temporal(TemporalType.DATE)
	@Column(name = "fecha_calc")
	private Date fechaCalc;

	@Temporal(TemporalType.DATE)
	@Column(name = "fecha_emis")
	private Date fechaEmis;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "fecha_hora")
	private Date fechaHora;

	@Temporal(TemporalType.DATE)
	@Column(name = "fecha_vto_pag")
	private Date fechaVtoPag;

	@Temporal(TemporalType.DATE)
	@Column(name = "fecha_vto_val")
	private Date fechaVtoVal;

	@Column(name = "nom_exportador")
	private String nomExportador;

	@Column(name = "nom_importador")
	private String nomImportador;

	@Column(name = "nom_producto")
	private String nomProducto;

	@Column(name = "nro_dias")
	private Integer nroDias;

	@Column(length = 6)
	private String secuencia;

	@Column(name = "cod_persona")
	private String codPersona;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "cod_id")
	private Identificador identificador;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "cod_inst")
	private Institucion institucion;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "cod_pais")
	private Pais pais;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "cod_clasifprod")
	private ClasifProductos clasifProductos;

	@ManyToOne(fetch = FetchType.EAGER )
	@JoinColumn(name = "cod_persona", nullable=true, insertable=false, updatable=false)
	private Persona persona;
	
	public Apertura() {
	}

	public Apertura(gob.bcb.siraladi.xml.model.Apertura apertura) {
		this.nroMov = apertura.getNromov();
		this.anio = apertura.getAnio();
		this.codMoneda = apertura.getCodmoneda();
		this.cveTipoApe = apertura.getTipoape();
		this.dav = apertura.getDav();
		this.nomExportador = apertura.getNomexportador();
		this.nomImportador = apertura.getNomimportador();
		this.nomProducto = apertura.getNomproducto();
		this.nroDias = apertura.getNrodias();
		this.secuencia = apertura.getSecuencia();
		this.identificador = new Identificador();
		this.identificador.setCodId(apertura.getCodid());
		this.institucion = new Institucion();
		this.institucion.setCodInst(apertura.getCodinst());
		this.pais = new Pais();
		this.pais.setCodPais(apertura.getCodpais());
		this.cveEstadoApe = apertura.getEstado();
		this.clasifProductos = new ClasifProductos();
		this.clasifProductos.setCodClasifprod(apertura.getClasifproducto());
		try {
			this.fechaEmis = apertura.getFechaemis().toGregorianCalendar().getTime();
		} catch (Exception e) {
		}
		//this.persona = new Persona();
		this.setCodPersona(apertura.getCodpersona());
		try {
			this.fechaEmis = apertura.getFechaemis().toGregorianCalendar().getTime();
		} catch (Exception e) {
		}		
		try {
			this.fechaVtoPag = apertura.getFechavto().toGregorianCalendar().getTime();
		} catch (Exception e) {
		}
		try {
			this.fechaVtoVal = apertura.getFechavto().toGregorianCalendar().getTime();
		} catch (Exception e) {
		}
	}

	public gob.bcb.siraladi.xml.model.Apertura getObjectJAXB() {
		gob.bcb.siraladi.xml.model.Apertura apertura = new gob.bcb.siraladi.xml.model.Apertura();
		apertura.setTipoape(cveTipoApe);
		apertura.setNromov(nroMov);
		if (this.institucion != null)
			apertura.setCodinst(this.institucion.getCodInst());
		if (this.identificador != null)
			apertura.setCodid(this.identificador.getCodId());
		apertura.setAnio(anio);
		apertura.setSecuencia(secuencia);
		apertura.setDav(dav);
		if (this.pais != null)
			apertura.setCodpais(this.pais.getCodPais());
		apertura.setCodmoneda(codMoneda);
		apertura.setFechaemis(UtilsDate.StrToXMLGregoCal(UtilsDate.stringFromDate(fechaEmis, "yyyy-MM-dd"), "-"));
		apertura.setFechavto(UtilsDate.StrToXMLGregoCal(UtilsDate.stringFromDate(fechaVtoPag, "yyyy-MM-dd"), "-"));
		apertura.setNrodias(nroDias);
		apertura.setNomproducto(nomProducto.toUpperCase());
		apertura.setNomimportador(nomImportador.toUpperCase());
		apertura.setNomexportador(nomExportador.toUpperCase());
		apertura.setEstado(cveEstadoApe);
		apertura.setCodpersona(codPersona);		
		if (this.clasifProductos != null)
			apertura.setClasifproducto(this.getClasifProductos().getCodClasifprod());
		if (this.persona != null)			
			apertura.setCodpersona(this.getCodPersona());		
		return apertura;
	}

	public Integer getNroMov() {
		return this.nroMov;
	}

	public void setNroMov(Integer nroMov) {
		this.nroMov = nroMov;
	}

	public String getAnio() {
		return this.anio;
	}

	public void setAnio(String anio) {
		this.anio = anio;
	}

	public String getCodCalif() {
		return this.codCalif;
	}

	public void setCodCalif(String codCalif) {
		this.codCalif = codCalif;
	}

	public String getCodMoneda() {
		return this.codMoneda;
	}

	public void setCodMoneda(String codMoneda) {
		this.codMoneda = codMoneda;
	}

	public String getCodUsuario() {
		return this.codUsuario;
	}

	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}

	public String getCveEstadoApe() {
		return this.cveEstadoApe;
	}

	public void setCveEstadoApe(String cveEstadoApe) {
		this.cveEstadoApe = cveEstadoApe;
	}

	public String getCveTipoApe() {
		return this.cveTipoApe;
	}

	public void setCveTipoApe(String cveTipoApe) {
		this.cveTipoApe = cveTipoApe;
	}

	public String getCveTipoCalc() {
		return this.cveTipoCalc;
	}

	public void setCveTipoCalc(String cveTipoCalc) {
		this.cveTipoCalc = cveTipoCalc;
	}

	public Integer getDav() {
		return this.dav;
	}

	public void setDav(Integer dav) {
		this.dav = dav;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaCalc() {
		return this.fechaCalc;
	}

	public void setFechaCalc(Date fechaCalc) {
		this.fechaCalc = fechaCalc;
	}

	public Date getFechaEmis() {
		return this.fechaEmis;
	}

	public void setFechaEmis(Date fechaEmis) {
		this.fechaEmis = fechaEmis;
	}

	public Date getFechaVtoPag() {
		return this.fechaVtoPag;
	}

	public void setFechaVtoPag(Date fechaVtoPag) {
		this.fechaVtoPag = fechaVtoPag;
	}

	public Date getFechaVtoVal() {
		return this.fechaVtoVal;
	}

	public void setFechaVtoVal(Date fechaVtoVal) {
		this.fechaVtoVal = fechaVtoVal;
	}

	public String getNomExportador() {
		return this.nomExportador;
	}

	public void setNomExportador(String nomExportador) {
		this.nomExportador = nomExportador;
	}

	public String getNomImportador() {
		return this.nomImportador;
	}

	public void setNomImportador(String nomImportador) {
		this.nomImportador = nomImportador;
	}

	public String getNomProducto() {
		return this.nomProducto;
	}

	public void setNomProducto(String nomProducto) {
		this.nomProducto = nomProducto;
	}

	public Integer getNroDias() {
		return this.nroDias;
	}

	public void setNroDias(Integer nroDias) {
		this.nroDias = nroDias;
	}

	public String getSecuencia() {
		return this.secuencia;
	}

	public void setSecuencia(String secuencia) {
		this.secuencia = secuencia;
	}

	public Identificador getIdentificador() {
		return this.identificador;
	}

	public void setIdentificador(Identificador identificador) {
		this.identificador = identificador;
	}

	public Institucion getInstitucion() {
		return this.institucion;
	}

	public void setInstitucion(Institucion institucion) {
		this.institucion = institucion;
	}

	public Pais getPais() {
		return this.pais;
	}

	public void setPais(Pais pais) {
		this.pais = pais;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public Date getFechaHora() {
		return fechaHora;
	}

	public void setNroReembLiteral(String nroReembLiteral) {

	}
	public String getNroReembLiteral() {
		String separador = "-";
		String nroReembolso = String.format("%04d", (institucion != null ? Integer.valueOf(institucion.getCodInst().trim()) : 0)).concat(separador);
		nroReembolso = nroReembolso.concat(String.format("%01d", (identificador != null ? Integer.valueOf(identificador.getCodId().trim()) : 0)))
				.concat(separador);
		nroReembolso = nroReembolso.concat(String.format("%04d", (anio != null ? Integer.valueOf(anio.trim()) : 0))).concat(separador);
		nroReembolso = nroReembolso.concat(String.format("%06d", (secuencia != null ? Integer.valueOf(secuencia.trim()) : 0))).concat(separador);
		nroReembolso = nroReembolso.concat(String.format("%01d", (dav != null ? dav : 0)));
		return nroReembolso;
	}

	public String getNroReembLiteral(boolean formatoLineal) {
		if (formatoLineal)
			return getNroReembLiteral(new boolean[] { formatoLineal });
		return getNroReembLiteral();
	}

	public String getNroReembLiteral(boolean... params) {
		String separador = "";
		if (params.length == 0) {
			separador = "-";
		}

		String nroReembolso = String.format("%04d", (institucion != null ? Integer.valueOf(institucion.getCodInst().trim()) : 0)).concat(separador);
		nroReembolso = nroReembolso.concat(String.format("%01d", (identificador != null ? Integer.valueOf(identificador.getCodId().trim()) : 0)))
				.concat(separador);
		nroReembolso = nroReembolso.concat(String.format("%04d", (anio != null ? Integer.valueOf(anio.trim()) : 0))).concat(separador);
		nroReembolso = nroReembolso.concat(String.format("%06d", (secuencia != null ? Integer.valueOf(secuencia.trim()) : 0))).concat(separador);
		nroReembolso = nroReembolso.concat(String.format("%01d", (dav != null ? dav : 0)));
		return nroReembolso;
	}

	public static void main(String[] args) {
		Apertura a = new Apertura();
		a.setAnio("2011");
		Identificador i = new Identificador();
		i.setCodId("1");
		a.setIdentificador(i);
		Institucion ins = new Institucion();
		ins.setCodInst("0698");
		a.setInstitucion(ins);
		a.setSecuencia("610");
		a.setDav(5);
	}

	public void setClasifProductos(ClasifProductos clasifProductos) {
		this.clasifProductos = clasifProductos;
	}

	public ClasifProductos getClasifProductos() {
		return clasifProductos;
	}

	public void setPersona(Persona persona) {
		this.persona = persona;
	}

	public Persona getPersona() {
		return persona;
	}

	public String getCodigoReembolso() {
		String codReembolso = null;
		try {
			codReembolso = getNroReembLiteral();
		} catch (Exception e) {
			;
		}
		return codReembolso;
	}

	public String getCodigoReembolsoCorrido() {
		String codReembolso = null;
		try {
			codReembolso = getNroReembLiteral().replace("-", "");
		} catch (Exception e) {
			;
		}
		return codReembolso;
	}

	public String getCodPersona() {
		return codPersona;
	}

	public void setCodPersona(String codPersona) {
		this.codPersona = codPersona;
	}

}
