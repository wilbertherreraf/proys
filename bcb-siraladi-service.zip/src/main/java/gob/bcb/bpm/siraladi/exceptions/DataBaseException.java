package gob.bcb.bpm.siraladi.exceptions;

import gob.bcb.bpm.siraladi.common.MsgManager;
import gob.bcb.bpm.siraladi.utils.StatusCode;

import java.util.ResourceBundle;

import javax.xml.namespace.QName;

import org.apache.log4j.Logger;

public class DataBaseException extends UncheckedException{
	private static final long serialVersionUID = 397003471340404801L;
	private String message;
	public static final ResourceBundle BUNDLE;
	static {
		ResourceBundle bundle = null;
		try {
			bundle = ResourceBundle.getBundle("errorsdatabase");
			BUNDLE = bundle;
		} catch (Exception e) {
			throw new RuntimeException("No se pudo cargar archivo de mensajes 'errorsdatabase'");
		}
	}
	/**
	 * Constructor
	 * 
	 * @param message
	 *            Mensaje de la excepcion
	 * @param ex
	 *            La excpecion como tal
	 */
	public DataBaseException(String msg, Throwable t) {
		this(msg, BUNDLE, t);
	}

	/**
	 * Constructor
	 * 
	 * @param message
	 *            Mensaje para crear la nueva excepcion
	 */

	public DataBaseException(String message) {
		//this(new MsgManager(message, BUNDLE));
		// whf ojooo eliminar cuando todas las excepciones esten codificadas
		// mensaje personalizado si el codigo no existe en la configuracion lo
		// setea a
		this(BUNDLE.containsKey(message) ? (new MsgManager(message, BUNDLE)) : (new MsgManager(StatusCode.DATABASE_EXCEPTION, BUNDLE,
				new Object[] { message })));
	}

	public DataBaseException(String message, Object... params) {
		this(new MsgManager(message, BUNDLE, params));
	}

	public DataBaseException(MsgManager message, Throwable throwable) {
		super(message, throwable);
		this.message = message.toString();
	}

	public DataBaseException(MsgManager message) {
		super(message);
		this.message = message.toString();
	}

	public DataBaseException(String message, Logger log) {
		this(new MsgManager(message, log));
	}

	public DataBaseException(String message, ResourceBundle b) {
		this(new MsgManager(message, b));
	}

	public DataBaseException(String message, Logger log, Throwable t) {
		this(new MsgManager(message, log), t);
	}

	public DataBaseException(String message, ResourceBundle b, Throwable t) {
		this(new MsgManager(message, b), t);
	}

	public DataBaseException(String message, Logger log, Throwable t, Object... params) {
		this(new MsgManager(message, log, params), t);
	}

	public DataBaseException(String message, ResourceBundle b, Throwable t, Object... params) {
		this(new MsgManager(message, b, params), t);
	}

	public DataBaseException(Throwable t) {
		super(t);
        if (super.getMessage() != null) {
            message = super.getMessage();
		} else {
			message = t == null ? null : t.getMessage();
		}
	}

	public DataBaseException(MsgManager message, Throwable throwable, QName fc) {
		super(message, throwable);
		this.message = message.toString();
	}

	public DataBaseException(MsgManager message, QName fc) {
		super(message);
		this.message = message.toString();
	}

	public DataBaseException(Throwable t, QName fc) {
		super(t);
		if (super.getMessage() != null) {
			message = super.getMessage();
		} else {
			message = t == null ? null : t.getMessage();
		}
	}

	public String getMsgManager() {
		return message;
	}

	public void setMsgManager(String message) {
		this.message = message;
	}

	public static String getDescription(String message, Object... params){
		return new MsgManager(message, BUNDLE, params).toString();
	}	
}
