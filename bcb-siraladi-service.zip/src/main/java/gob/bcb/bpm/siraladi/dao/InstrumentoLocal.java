package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.Instrumento;

public interface InstrumentoLocal extends DAO<String, Instrumento>{

}
