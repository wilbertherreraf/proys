
package gob.bcb.bpm.siraladi.ws.clientaladi.asicapccb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Sdtsicap" type="{BCRP}sdtSICAPCCB"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "sdtsicap"
})
@XmlRootElement(name = "sicap_ccb_ws.ExecuteResponse")
public class SicapCcbWsExecuteResponse {

    @XmlElement(name = "Sdtsicap", required = true)
    protected SdtSICAPCCB sdtsicap;

    /**
     * Gets the value of the sdtsicap property.
     * 
     * @return
     *     possible object is
     *     {@link SdtSICAPCCB }
     *     
     */
    public SdtSICAPCCB getSdtsicap() {
        return sdtsicap;
    }

    /**
     * Sets the value of the sdtsicap property.
     * 
     * @param value
     *     allowed object is
     *     {@link SdtSICAPCCB }
     *     
     */
    public void setSdtsicap(SdtSICAPCCB value) {
        this.sdtsicap = value;
    }

}
