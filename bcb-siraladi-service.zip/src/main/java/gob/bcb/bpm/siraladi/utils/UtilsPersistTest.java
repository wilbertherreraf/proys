package gob.bcb.bpm.siraladi.utils;

import javax.persistence.EntityManagerFactory;

public class UtilsPersistTest {
	public EntityManagerFactory getEntityManagerFactory(String path, String idDBSource, String persistenceUnit) {
		EntityManagerFactory factory = UtilsPersist.createEntityManagerFactory2(path, idDBSource, persistenceUnit);
		return factory;
	}
	public static void main(String[] args) {
		UtilsPersistTest utilsPersistTest = new UtilsPersistTest();
		utilsPersistTest.getEntityManagerFactory("E:\\opt\\aplicaciones\\configuraciones\\web\\siraladi\\configdb.xml", "aladi", "ALADI_PU");
		
	}
}
