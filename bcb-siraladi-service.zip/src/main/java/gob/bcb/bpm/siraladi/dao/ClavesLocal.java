package gob.bcb.bpm.siraladi.dao;

import java.util.List;

import gob.bcb.bpm.siraladi.jpa.Clave;
import gob.bcb.bpm.siraladi.jpa.Claves;
import gob.bcb.bpm.siraladi.jpa.ClavesPK;

public interface ClavesLocal extends DAO<ClavesPK, Claves>{

	Claves getValoresByCod(String nomdato, String valdato);

	List<Claves> getValoresByClave(String nomdato);

	List<Clave> claves();

	Clave claveByCodigo(String nomdato);

}
