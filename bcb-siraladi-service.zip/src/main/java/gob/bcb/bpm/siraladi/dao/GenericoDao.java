package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.DomainObject;

import java.util.List;


public interface GenericoDao<T extends DomainObject> {

    public T get(Long id);

    public List<T> getAll();

    public void save(T object);
    public T update(T object);    

    public void delete(T object);

//
//	GenUsuario getGenUsuario();
//
//	void setGenUsuario(GenUsuario genUsuario);
//
}
