package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the per_tipo_cuenta database table.
 * 
 */
@Entity
@Table(name="per_tipo_cuenta")
public class PerTipoCuenta implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private PerTipoCuentaPK id;

	@Column(name="cod_usuario")
	private String codUsuario;

	@Column(name="cta_encaje")
	private String ctaEncaje;

	@Column(name="cta_mov_ab")
	private String ctaMovAb;

	@Column(name="cve_vigente")
	private String cveVigente;

	@Column(name="estacion")
	private String estacion;

	@Column(name="fecha_hora")
	private Timestamp fechaHora;

	//bi-directional many-to-one association to Identificador
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="cod_id", nullable=false, insertable=false, updatable=false)
	private Identificador identificador;

	//bi-directional many-to-one association to Moneda
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="cod_moneda", nullable=false, insertable=false, updatable=false)
	private Moneda moneda;

	//bi-directional many-to-one association to Persona
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="cod_persona", nullable=false, insertable=false, updatable=false)
	private Persona persona;

    public PerTipoCuenta() {
    }

	public PerTipoCuentaPK getId() {
		return this.id;
	}

	public void setId(PerTipoCuentaPK id) {
		this.id = id;
	}
	
	public String getCodUsuario() {
		return this.codUsuario;
	}

	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}

	public String getCtaEncaje() {
		return this.ctaEncaje;
	}

	public void setCtaEncaje(String ctaEncaje) {
		this.ctaEncaje = ctaEncaje;
	}

	public String getCtaMovAb() {
		return this.ctaMovAb;
	}

	public void setCtaMovAb(String ctaMovAb) {
		this.ctaMovAb = ctaMovAb;
	}

	public String getCveVigente() {
		return this.cveVigente;
	}

	public void setCveVigente(String cveVigente) {
		this.cveVigente = cveVigente;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Timestamp getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Timestamp fechaHora) {
		this.fechaHora = fechaHora;
	}

	public Identificador getIdentificador() {
		return this.identificador;
	}

	public void setIdentificador(Identificador identificador) {
		this.identificador = identificador;
	}
	
	public Moneda getMoneda() {
		return this.moneda;
	}

	public void setMoneda(Moneda moneda) {
		this.moneda = moneda;
	}
	
	public Persona getPersona() {
		return this.persona;
	}

	public void setPersona(Persona persona) {
		this.persona = persona;
	}
	
}