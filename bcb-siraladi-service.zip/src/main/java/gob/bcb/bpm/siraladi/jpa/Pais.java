package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;

/**
 * The persistent class for the pais database table.
 * 
 */
@Entity
@Table(name = "pais")
public class Pais implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "cod_pais")
	private String codPais;

	@Column(name = "cod_usuario")
	private String codUsuario;

	@Column(name = "cta_mov_a")
	private String ctaMovA;

	@Column(name = "cta_mov_b")
	private String ctaMovB;

	@Column(name = "cve_est_convenio")
	private String cveEstConvenio;

	@Column(name = "estacion")
	private String estacion;

	@Column(name = "fecha_hora")
	private Date fechaHora;

	@Column(name = "nom_pais")
	private String nomPais;

	public Pais() {
	}

	public String getCodPais() {
		return this.codPais;
	}

	public void setCodPais(String codPais) {
		this.codPais = codPais;
	}

	public String getCodUsuario() {
		return this.codUsuario;
	}

	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}

	public String getCtaMovA() {
		return this.ctaMovA;
	}

	public void setCtaMovA(String ctaMovA) {
		this.ctaMovA = ctaMovA;
	}

	public String getCtaMovB() {
		return this.ctaMovB;
	}

	public void setCtaMovB(String ctaMovB) {
		this.ctaMovB = ctaMovB;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getNomPais() {
		return this.nomPais;
	}

	public void setNomPais(String nomPais) {
		this.nomPais = nomPais;
	}

	public void setCveEstConvenio(String cveEstConvenio) {
		this.cveEstConvenio = cveEstConvenio;
	}

	public String getCveEstConvenio() {
		return cveEstConvenio;
	}
}
