
package gob.bcb.bpm.siraladi.ws.clientaladi.asicapcpa;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for sdtSICAPCPA.sdtSICAPCPAItem complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="sdtSICAPCPA.sdtSICAPCPAItem">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="CodigoRpta" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Convenio" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Monto" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="Corresponsal" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="FechaValor" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="OrdendePago" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SaldoBilateralAl" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="FechaRegistro" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="HoraRegistro" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ConvenioRegistro" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "sdtSICAPCPA.sdtSICAPCPAItem", propOrder = {

})
public class SdtSICAPCPASdtSICAPCPAItem {

    @XmlElement(name = "CodigoRpta", required = true)
    protected String codigoRpta;
    @XmlElement(name = "Convenio", required = true)
    protected String convenio;
    @XmlElement(name = "Monto")
    protected double monto;
    @XmlElement(name = "Corresponsal", required = true)
    protected String corresponsal;
    @XmlElement(name = "FechaValor", required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar fechaValor;
    @XmlElement(name = "OrdendePago", required = true)
    protected String ordendePago;
    @XmlElement(name = "SaldoBilateralAl", required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar saldoBilateralAl;
    @XmlElement(name = "FechaRegistro", required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar fechaRegistro;
    @XmlElement(name = "HoraRegistro", required = true)
    protected String horaRegistro;
    @XmlElement(name = "ConvenioRegistro", required = true)
    protected String convenioRegistro;

    /**
     * Gets the value of the codigoRpta property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigoRpta() {
        return codigoRpta;
    }

    /**
     * Sets the value of the codigoRpta property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigoRpta(String value) {
        this.codigoRpta = value;
    }

    /**
     * Gets the value of the convenio property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConvenio() {
        return convenio;
    }

    /**
     * Sets the value of the convenio property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConvenio(String value) {
        this.convenio = value;
    }

    /**
     * Gets the value of the monto property.
     * 
     */
    public double getMonto() {
        return monto;
    }

    /**
     * Sets the value of the monto property.
     * 
     */
    public void setMonto(double value) {
        this.monto = value;
    }

    /**
     * Gets the value of the corresponsal property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCorresponsal() {
        return corresponsal;
    }

    /**
     * Sets the value of the corresponsal property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCorresponsal(String value) {
        this.corresponsal = value;
    }

    /**
     * Gets the value of the fechaValor property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getFechaValor() {
        return fechaValor;
    }

    /**
     * Sets the value of the fechaValor property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFechaValor(XMLGregorianCalendar value) {
        this.fechaValor = value;
    }

    /**
     * Gets the value of the ordendePago property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrdendePago() {
        return ordendePago;
    }

    /**
     * Sets the value of the ordendePago property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrdendePago(String value) {
        this.ordendePago = value;
    }

    /**
     * Gets the value of the saldoBilateralAl property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getSaldoBilateralAl() {
        return saldoBilateralAl;
    }

    /**
     * Sets the value of the saldoBilateralAl property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setSaldoBilateralAl(XMLGregorianCalendar value) {
        this.saldoBilateralAl = value;
    }

    /**
     * Gets the value of the fechaRegistro property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getFechaRegistro() {
        return fechaRegistro;
    }

    /**
     * Sets the value of the fechaRegistro property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFechaRegistro(XMLGregorianCalendar value) {
        this.fechaRegistro = value;
    }

    /**
     * Gets the value of the horaRegistro property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHoraRegistro() {
        return horaRegistro;
    }

    /**
     * Sets the value of the horaRegistro property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHoraRegistro(String value) {
        this.horaRegistro = value;
    }

    /**
     * Gets the value of the convenioRegistro property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConvenioRegistro() {
        return convenioRegistro;
    }

    /**
     * Sets the value of the convenioRegistro property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConvenioRegistro(String value) {
        this.convenioRegistro = value;
    }

}
