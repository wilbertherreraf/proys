/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-web-sirAladi
 * gob.bcb.bpm.siraladi.pojo.UsuarioSirAladi
 * 07/10/2011 - 11:12:14
 * Creado por wherrera
 */
package gob.bcb.bpm.siraladi.pojo;

import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Persona;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Bean que contiene datos del usuario.
 *
 *
 * @author wherrera
 *
 */
public class UsuarioSirAladi implements Serializable
{
	private String login;
	private String codEmp;	
	private Persona persona;
	Map<String, Institucion> mapInstituciones;
	private List<String> recursos;
	private List<String> roles;
	private Map<String, Boolean> recAutorizadosMapa = new HashMap<String, Boolean>();
	public UsuarioSirAladi(String login)
	{
		super();
		this.login = login;
	}
	public String getLogin()
	{
		return login;
	}
	public void setLogin(String login)
	{
		this.login = login;
	}
	public Persona getPersona()
	{
		return persona;
	}
	public void setPersona(Persona persona)
	{
		this.persona = persona;
		this.mapInstituciones = new HashMap<String, Institucion>();
		for (Institucion institucion : this.persona.getInstitucions())
			this.mapInstituciones.put(institucion.getCodInst(), institucion);
	}	
	public Map<String, Institucion> getMapInstituciones()
	{
		return mapInstituciones;
	}
	
	public String getCodigosIntituciones() {
		StringBuffer sb = new StringBuffer();
		for (Institucion institucion : this.persona.getInstitucions())
			sb.append(",'").append(institucion.getCodInst()).append("'");
		return (sb.length() > 0) ? sb.substring(1) : null;
	}
	public void setRecursos(List<String> recursos) {
		if (recAutorizadosMapa != null){
			recAutorizadosMapa.clear();
		} else {
			recAutorizadosMapa = new HashMap<String, Boolean>();
		}
		for (String recurso : recursos) {
			recAutorizadosMapa.put(recurso, true);
		}
		this.recursos = recursos;
	}
	public List<String> getRecursos() {
		return recursos;
	}
	public void setRoles(List<String> roles) {
		this.roles = roles;
	}
	public List<String> getRoles() {
		return roles;
	}
	public void setRecAutorizadosMapa(Map<String, Boolean> recAutorizadosMapa) {
		this.recAutorizadosMapa = recAutorizadosMapa;
	}
	public Map<String, Boolean> getRecAutorizadosMapa() {
		return recAutorizadosMapa;
	}
	public String getCodEmp() {
		return codEmp;
	}
	public void setCodEmp(String codEmp) {
		this.codEmp = codEmp;
	}

}
