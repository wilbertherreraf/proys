package gob.bcb.bpm.siraladi.dao.qnative;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;
import gob.bcb.bpm.siraladi.service.ConfigurationServ;
import gob.bcb.bpm.siraladi.utils.Constants;
import gob.bcb.bpm.siraladi.utils.Utils;

/**
 * Factory for creating new session handlers. Normally, only one instance of a factory is created
 * (using {@link Factory}), so implementations must be thread safe.
 */
/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public interface DBSourceHandlerFactory {

	/**
	 * Obtiene un nuevo DB Source handler .
	 */
	public DBSourceHandler getHandler();

	/**
	 * Close the factory. No calls to {@link #getHandler()} will be made after this call. Be aware
	 * that this method might be called several times, and should not fail if this happens.
	 */
	public void close();

	/**
	 * Configure the factory. This will be called before any calls are made to {@link #getHandler()}
	 * .
	 */
	public void configure(ConfigurationServ config);

	public void configure(ConfigurationServ config, String idDBSource);

	public static class Factory {
		private static final Logger log = Logger.getLogger(DBSourceHandlerFactory.class);

		private static Map<String, DBSourceHandlerFactory> instance = new HashMap<String, DBSourceHandlerFactory>();

		public static synchronized DBSourceHandlerFactory newInstance(ConfigurationServ configuration, String idDBSource) {
			if (instance.containsKey(idDBSource))
				return instance.get(idDBSource);

			if (configuration == null)
				return null;
			
			log.info("Creando nuevo handler factory: " + idDBSource);
			
			String name = (String) ConfigurationServ.getConfigProperty(
					Constants.PROP_DB_HANDLER_FACTORY.replaceFirst("ID-DATABASE", idDBSource), "string");

			log.info("Using session handler factory class: " + name);

			DBSourceHandlerFactory factory = (DBSourceHandlerFactory) Utils.newInstance(configuration,
					Constants.PROP_DB_HANDLER_FACTORY.replaceFirst("ID-DATABASE", idDBSource));
			factory.configure(configuration, idDBSource);
			instance.put(idDBSource, factory);
			log.info("Nueva conexión nativa creada id: " + idDBSource);
			return factory;
		}

		public static void close() {
			log.info("Cerrando instancias de conexiones nativas");
			if (instance == null) {
				return;
			}
			
			try {
				instance.clear();
				instance = null;
			} catch (Exception e) {
				log.error("Error al cerrar instancias de conexion nativas", e);
			}
			log.info("Instancias de conexiones nativas cerradas ... hecho");
		}
	}

}
