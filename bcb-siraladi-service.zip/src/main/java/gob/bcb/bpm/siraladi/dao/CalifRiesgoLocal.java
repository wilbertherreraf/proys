package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.CalifRiesgo;

public interface CalifRiesgoLocal  extends DAO<String, CalifRiesgo>{

	CalifRiesgo findByCodigo(String nomparam);

	CalifRiesgo saveorupdate(CalifRiesgo params);

}
