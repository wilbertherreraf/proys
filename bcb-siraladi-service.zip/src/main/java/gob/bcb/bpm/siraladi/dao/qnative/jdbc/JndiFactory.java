package gob.bcb.bpm.siraladi.dao.qnative.jdbc;

import javax.naming.InitialContext;

import javax.naming.NamingException;
import javax.sql.DataSource;

import gob.bcb.bpm.siraladi.dao.qnative.DBSourceHandler;
import gob.bcb.bpm.siraladi.dao.qnative.DBSourceHandlerFactory;
import gob.bcb.bpm.siraladi.service.ConfigurationServ;
import gob.bcb.bpm.siraladi.utils.Constants;

/**
 * Factory for creating {@link JdbcDBSourceHandler} objects.
 * 
 * This requires a JNDI resource to be configured, and the name must be present in the configuration 
 * under the property <strong>oiosaml-sp.sessionhandler.jndi</strong>.
 * 
 * @author recht
 *
 */
/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public class JndiFactory implements DBSourceHandlerFactory {

	private String name;

	
	public void close() {
		
	}

	
	public void configure(ConfigurationServ config, String idDBSource) {
		name = (String) ConfigurationServ.getConfigProperty(Constants.PROP_DB_JNDI.replaceFirst("ID-DATABASE", idDBSource), "string");
	}	
	
	public void configure(ConfigurationServ config) {
		name = (String) ConfigurationServ.getConfigProperty(Constants.PROP_DB_JNDI, "string");
	}

	
	public DBSourceHandler getHandler() {
		try {
			InitialContext ctx = new InitialContext();
			DataSource ds = (DataSource) ctx.lookup(name);
			
			return new JdbcDBSourceHandler(ds);
		} catch (NamingException e) {
			throw new RuntimeException(e);
		}
	}

}
