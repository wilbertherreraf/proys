package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.Identificador;



import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("identificadorLocal")
@Transactional
public class IdentificadorBean extends GenericDAO<String, Identificador> implements IdentificadorLocal {
}
