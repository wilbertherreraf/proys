package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * The primary key class for the det_patrimonio database table.
 * 
 */

@Embeddable
public class DetPatrimonioPK implements Serializable {
	//default serial version id, required for serializable classes.
	@Column(name="nro_orden", unique=true, nullable=false)
	private Integer nroOrden;

	@Column(name="cod_persona", unique=true, nullable=false)
	private String codPersona;

    public DetPatrimonioPK() {
    }
	public Integer getNroOrden() {
		return this.nroOrden;
	}
	public void setNroOrden(Integer nroOrden) {
		this.nroOrden = nroOrden;
	}
	public String getCodPersona() {
		return this.codPersona;
	}
	public void setCodPersona(String codPersona) {
		this.codPersona = codPersona;
	}

	
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof DetPatrimonioPK)) {
			return false;
		}
		DetPatrimonioPK castOther = (DetPatrimonioPK)other;
		return 
			(this.nroOrden == castOther.nroOrden)
			&& this.codPersona.equals(castOther.codPersona);

    }
    
	
	public int hashCode() {
		final Integer prime = 31;
		int hash = 17;
		hash = hash * prime + this.nroOrden;
		hash = hash * prime + this.codPersona.hashCode();
		
		return hash;
    }
}
