package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;
import javax.persistence.Id;

/**
 * The primary key class for the plan_pago database table.
 * 
 */
 
@Embeddable
public class PlanPagoPK implements Serializable {
	//default serial version id, required for serializable classes.
	@Column(name="nro_mov", unique=true, nullable=false)
	private Integer nroMov;

	@Column(name="nro_plan", unique=true, nullable=false)
	private Integer nroPlan;

    public PlanPagoPK() {
    }
	public Integer getNroMov() {
		return this.nroMov;
	}
	public void setNroMov(Integer nroMov) {
		this.nroMov = nroMov;
	}
	public Integer getNroPlan() {
		return this.nroPlan;
	}
	public void setNroPlan(Integer nroPlan) {
		this.nroPlan = nroPlan;
	}

	
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof PlanPagoPK)) {
			return false;
		}
		PlanPagoPK castOther = (PlanPagoPK)other;
		return 
			(this.nroMov == castOther.nroMov)
			&& (this.nroPlan == castOther.nroPlan);

    }
    
	
	public int hashCode() {
		final Integer prime = 31;
		int hash = 17;
		hash = hash * prime + this.nroMov;
		hash = hash * prime + (this.nroPlan);
		
		return hash;
    }
}
