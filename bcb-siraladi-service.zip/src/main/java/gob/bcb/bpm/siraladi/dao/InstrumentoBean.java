package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.Instrumento;



import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("instrumentoLocal")
@Transactional
public class InstrumentoBean extends GenericDAO <String, Instrumento> implements InstrumentoLocal {
	
}
