package gob.bcb.bpm.siraladi.ws.clientaladi;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import gob.bcb.bpm.siraladi.utils.Constants;
import gob.bcb.bpm.siraladi.utils.Utils;
import gob.bcb.bpm.siraladi.utils.UtilsDate;
import gob.bcb.bpm.siraladi.ws.clientaladi.asicomrima.SdtSICOMRIMA;

import com.thoughtworks.xstream.XStream;

public class RespWSAladi {
	private static Logger log = Logger.getLogger(RespWSAladi.class);
	private String code;
	private Map<String, String> codesDescrip = new HashMap<String, String>();
	private String descripResp;
	private String contentXML;
	private Date fechaHoraReg;
	private Map<String, Object> datosAdicionales = new HashMap<String, Object>();

	public void setCode(String code) {
		if (code != null) {
			code = code.trim();
			if (code.length() > 4) {
				int numcodes = code.length() / 4;
				for (int i = 1; i <= numcodes; i++) {
					codesDescrip.put(code.substring((i * 4) - 4, i * 4), MessagesRespAladi.getDescripResp(code.substring((i * 4) - 4, i * 4)));
				}
			} else {
				codesDescrip.put(code, MessagesRespAladi.getDescripResp(code));
			}
		}
	}

	public String getCode() {
		return codesDescrip.keySet().toString().substring(1, codesDescrip.keySet().toString().lastIndexOf("]"));
	}

	public void setDescripResp(String descripResp) {
		this.descripResp = descripResp;
	}

	public String getDescripResp() {
		return codesDescrip.values().toString().substring(1, codesDescrip.values().toString().lastIndexOf("]"));
	}

	public void setContentXML(String contentXML) {
		this.contentXML = contentXML;
	}

	public String getContentXML() {
		return contentXML;
	}

	public void setFechaHoraReg(Date fecha, String hora) {
		Calendar c = GregorianCalendar.getInstance();
		c.setTime(fecha);
		String[] h = null;
		if (hora != null) {
			h = hora.split(":");
			c.set(Calendar.HOUR, Integer.valueOf(h[0]));
			c.set(Calendar.MINUTE, Integer.valueOf(h[1]));
			c.set(Calendar.SECOND, Integer.valueOf(h[2]));

		}
		this.fechaHoraReg = c.getTime();
	}

	public Date getFechaHoraReg() {
		return fechaHoraReg;
	}

	public void setDatosAdicionales(Map<String, Object> datosAdicionales) {
		this.datosAdicionales = datosAdicionales;
	}

	public Map<String, Object> getDatosAdicionales() {
		return datosAdicionales;
	}

	public boolean isSuccessMsg() {
		for (Iterator<?> i = codesDescrip.keySet().iterator(); i.hasNext();) {
			String key = (String) i.next();
			if (!Constants.CODES_SUCCESS_ALADI.contains(key)) {
				return false;
			}
		}
		return true;
	}

	public static void main(String[] args) {
		RespWSAladi respWSAladi = new RespWSAladi();
		respWSAladi.setCode("asdf");
		String code = "10003026ertf";
		Map<String, String> codes = new HashMap<String, String>();
		int numcodes = code.length() / 4;

		for (int i = 1; i <= numcodes; i++) {
			codes.put(code.substring((i * 4) - 4, i * 4), MessagesRespAladi.getDescripResp(code.substring((i * 4) - 4, i * 4)));

		}
		System.out.println(respWSAladi.getCode() + " - " + respWSAladi.getDescripResp());
		System.out.println(respWSAladi.getDescripResp());
		System.out.println(respWSAladi.isSuccessMsg());
	}
}
