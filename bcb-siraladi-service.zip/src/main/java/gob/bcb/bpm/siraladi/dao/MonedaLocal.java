package gob.bcb.bpm.siraladi.dao;
import gob.bcb.bpm.siraladi.jpa.Moneda;



public interface MonedaLocal extends DAO<String, Moneda>{
}
