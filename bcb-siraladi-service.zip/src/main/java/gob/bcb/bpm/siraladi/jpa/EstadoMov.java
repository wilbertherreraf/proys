package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;
import javax.persistence.ManyToOne;


/**
 * The persistent class for the estado_mov database table.
 * 
 */
@Entity
@Table(name="estado_mov")
public class EstadoMov implements Serializable {
	@EmbeddedId
	private EstadoMovPK id;

	@Column(name="cod_usuario")
	private String codUsuario;

	@Column
	private String estacion;

    public EstadoMov() {
    }

	public EstadoMovPK getId() {
		return this.id;
	}

	public void setId(EstadoMovPK id) {
		this.id = id;
	}
	
	public String getCodUsuario() {
		return this.codUsuario;
	}

	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}
}
