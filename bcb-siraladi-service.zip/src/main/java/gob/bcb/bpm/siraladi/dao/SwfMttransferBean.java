package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.SwfMttransfer;
import gob.bcb.bpm.siraladi.jpa.SwfMttransferdet;
import gob.bcb.bpm.siraladi.jpa.SwfMttransferdetPK;

import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("swfMttransferLocal")
@Transactional
public class SwfMttransferBean extends GenericDAO<String, SwfMttransfer> implements SwfMttransferLocal {
	private static Logger log = Logger.getLogger(SwfMttransferBean.class);

	public SwfMttransfer findByCodigo(String mttCodttransfer) {
		
		String jpql = "SELECT t FROM SwfMttransfer t WHERE t.mttCodttransfer = :mttCodttransfer ";
		log.info("En findByCodigo " + mttCodttransfer + " " + jpql);
		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("mttCodttransfer", mttCodttransfer);
		List lista = query.getResultList();
		if (lista.size() > 0) {
			return (SwfMttransfer) lista.get(0);
		}
		return null;
	}
	public List<SwfMttransfer> getMTs() {
		
		String jpql = "SELECT t FROM SwfMttransfer t ";

		Query query = getEntityManager().createQuery(jpql);

		List lista = query.getResultList();
		return lista;
	}
}
