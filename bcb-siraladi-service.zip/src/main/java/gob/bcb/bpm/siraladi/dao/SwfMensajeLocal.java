package gob.bcb.bpm.siraladi.dao;

import java.util.List;

import gob.bcb.bpm.siraladi.jpa.SwfDetmensaje;
import gob.bcb.bpm.siraladi.jpa.SwfMensaje;
import gob.bcb.swift.pojos.SwiftDatos;




public interface SwfMensajeLocal extends DAO<Integer, SwfMensaje>{

	SwfMensaje findByCodigo(Integer menCodmen);

	List<SwfMensaje> findByEstMen(String menCveestswift);

	SwfMensaje saveorupdate(SwfMensaje swfMensaje);

	SwfMensaje actualizarSwift(SwfMensaje swfMensaje, List<SwfDetmensaje> swfDetmensajeList);

	SwfMensaje findByCodoperacion(String menCodoperacion, String menCveestswift);

	SwiftDatos swiftDatosFromSwfMensaje(SwfMensaje swfMensajePar);

	SwfMensaje autorizarSwift(SwfMensaje swfMensajePar, String pathSwift);

	void rechazarSwift(String menCodoperacion, String menAuditusr, String menAuditwst);

	void rechazarSwift(Integer menCodmen, String menAuditusr, String menAuditwst);

}
