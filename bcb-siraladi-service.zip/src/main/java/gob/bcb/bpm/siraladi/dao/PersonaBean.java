package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.Persona;

import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("personaLocal")
@Transactional
public class PersonaBean extends GenericDAO<String, Persona> implements PersonaLocal {
	/* (non-Javadoc)
	 * @see gob.bcb.bpm.siraladi.dao.PersonaLocal#findForUser(java.lang.String)
	 */
	public Persona findForUser(String login){
		Persona persona = null;
		String jpql = "SELECT p FROM UsrPersona u, Persona p WHERE u.id.codPersona = p.codPersona AND u.cveVigente = 'V' AND p.cveVigente = 'V' "
				+ " and u.id.codUsuario = :codUsuario ";
		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("codUsuario", login);

		List result = query.getResultList();
		if (result.size() > 0)
			persona = (Persona) result.get(0);

		return persona;		
	}
	
	public Persona findByCodigo(String nomparam) {
		String jpql = "SELECT t FROM Persona t ";
		jpql = jpql.concat("WHERE t.codPersona = :codPersona ");

		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("codPersona", nomparam);

		List lista = query.getResultList();
		if (lista.size() > 0) {
			return (Persona) lista.get(0);
		}
		return null;
	}
	
	public Persona saveorupdate(Persona params ) {
		Persona horarioOld = findByCodigo(params.getCodPersona());
	
		if (horarioOld == null){
			makePersistent(params);
		} else {
			horarioOld.setNomPersona(params.getNomPersona());
			horarioOld.setCtaMovA(params.getCtaMovA());
			horarioOld.setCtaMovB(params.getCtaMovB());
			horarioOld.setCtaEncaje(params.getCtaEncaje());
			horarioOld.setCveTipoPersona(params.getCveTipoPersona());
			horarioOld.setCveVigente(params.getCveVigente());
			horarioOld.setCorreos(params.getCorreos());
			horarioOld.setEstacion(params.getEstacion());
			horarioOld.setCodUsuario(params.getCodUsuario());
			horarioOld.setFechaHora(new Date());
			makePersistent(horarioOld);
		}
		horarioOld = findByCodigo(params.getCodPersona());
		log.info("Actualizando Persona " + horarioOld.toString());		
		return horarioOld; 
	}	
	
}
