package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the swf_detmensaje database table.
 * 
 */
@Embeddable
public class SwfDetmensajePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="dem_codmen")
	private Integer demCodmen;

	@Column(name="dem_nrocorr")
	private Integer demNrocorr;

	public SwfDetmensajePK() {
	}
	public Integer getDemCodmen() {
		return this.demCodmen;
	}
	public void setDemCodmen(Integer demCodmen) {
		this.demCodmen = demCodmen;
	}
	public Integer getDemNrocorr() {
		return demNrocorr;
	}
	public void setDemNrocorr(Integer demNrocorr) {
		this.demNrocorr = demNrocorr;
	}
	
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((demCodmen == null) ? 0 : demCodmen.hashCode());
		result = prime * result + ((demNrocorr == null) ? 0 : demNrocorr.hashCode());
		return result;
	}
	
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SwfDetmensajePK other = (SwfDetmensajePK) obj;
		if (demCodmen == null) {
			if (other.demCodmen != null)
				return false;
		} else if (!demCodmen.equals(other.demCodmen))
			return false;
		if (demNrocorr == null) {
			if (other.demNrocorr != null)
				return false;
		} else if (!demNrocorr.equals(other.demNrocorr))
			return false;
		return true;
	}


}
