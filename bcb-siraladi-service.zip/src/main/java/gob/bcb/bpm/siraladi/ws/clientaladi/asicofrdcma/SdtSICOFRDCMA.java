
package gob.bcb.bpm.siraladi.ws.clientaladi.asicofrdcma;

import gob.bcb.bpm.siraladi.ws.clientaladi.LocalDateAdapter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import javax.xml.datatype.XMLGregorianCalendar;

import org.joda.time.LocalDate;


/**
 * <p>Java class for sdtSICOFRDCMA complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="sdtSICOFRDCMA">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="CodigoRpta" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="FechaValor" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="Hora" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="FechaSICOM" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "sdtSICOFRDCMA", propOrder = {

})
public class SdtSICOFRDCMA {

    @XmlElement(name = "CodigoRpta", required = true)
    protected String codigoRpta;
    @XmlElement(name = "FechaValor", required = true)
    @XmlSchemaType(name = "date")
    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    //protected XMLGregorianCalendar fechaValor;
    protected LocalDate fechaValor;
    @XmlElement(name = "Hora", required = true)
    protected String hora;
    @XmlElement(name = "FechaSICOM", required = true)
    @XmlSchemaType(name = "date")
    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    //protected XMLGregorianCalendar fechaSICOM;
    protected LocalDate fechaSICOM;
    /**
     * Gets the value of the codigoRpta property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigoRpta() {
        return codigoRpta;
    }

    /**
     * Sets the value of the codigoRpta property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigoRpta(String value) {
        this.codigoRpta = value;
    }

    /**
     * Gets the value of the fechaValor property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public LocalDate getFechaValor() {
        return fechaValor;
    }

    /**
     * Sets the value of the fechaValor property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFechaValor(LocalDate value) {
        this.fechaValor = value;
    }

    /**
     * Gets the value of the hora property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHora() {
        return hora;
    }

    /**
     * Sets the value of the hora property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHora(String value) {
        this.hora = value;
    }

    /**
     * Gets the value of the fechaSICOM property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public LocalDate getFechaSICOM() {
        return fechaSICOM;
    }

    /**
     * Sets the value of the fechaSICOM property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFechaSICOM(LocalDate value) {
        this.fechaSICOM = value;
    }

}
