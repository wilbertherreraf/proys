package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.TPagoImp;

import java.math.BigDecimal;
import java.util.List;


import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("tPagoImpLocal")
@Transactional
public class TPagoImpBean extends GenericDAO<Integer, TPagoImp> implements
		TPagoImpLocal {

	public TPagoImp getMaxMovimiento() {
		TPagoImp tPagoImp = null;
		String jpql = "SELECT p FROM TPagoImp p where p.nroReg = "
				+ "(select max(m.nroReg) from TPagoImp m)";
		Query query = getEntityManager().createQuery(jpql);

		List result = query.getResultList();
		if (result.size() > 0)
			tPagoImp = (TPagoImp) result.get(0);

		return tPagoImp;
	}
	public TPagoImp findByNroReembolso(String codInst, String codId,
			String anio, String secuencia, Integer dav, Integer nroDebito,
			String codInstrumento, String corr) {

		TPagoImp tPagoImp = null;
		String jpql = "SELECT a ";
		jpql = jpql.concat("FROM TPagoImp a ");
		jpql = jpql.concat("where a.codInst = :codInst ");
		jpql = jpql.concat("AND a.codId = :codId ");
		jpql = jpql.concat("AND a.anio = :anio ");
		jpql = jpql.concat("AND a.secuencia = :secuencia ");
		jpql = jpql.concat("AND a.dav = :dav ");
		
		if (nroDebito != null){
			jpql = jpql.concat("and a.nroDebito = :nroDebito ");			
		}
		
		jpql = jpql.concat("and a.codInstrumento = :codInstrumento ");
		jpql = jpql.concat("and a.corr = :corr ");

		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("codInst", codInst.trim());
		query.setParameter("codId", codId.trim());
		query.setParameter("anio", anio.trim());
		query.setParameter("secuencia", secuencia.trim());
		query.setParameter("dav", dav);		
		
		if (nroDebito != null){
			query.setParameter("nroDebito", nroDebito);			
		}
		
		query.setParameter("codInstrumento", codInstrumento.trim());
		query.setParameter("corr", corr.trim());
		
		List result = query.getResultList();
		if (result.size() > 0)
			tPagoImp = (TPagoImp) result.get(0);

		return tPagoImp;
	}

	public TPagoImp findLEXofALE(String codInstrumento, String codInst, String codId,
			String anio, String secuencia, Integer dav, 
			String corr, BigDecimal montoMo) {

		TPagoImp tPagoImp = null;
		String jpql = "SELECT a ";
		jpql = jpql.concat("FROM TPagoImp a ");
		jpql = jpql.concat("where a.codInst = :codInst ");
		jpql = jpql.concat("AND a.codId = :codId ");
		jpql = jpql.concat("AND a.anio = :anio ");
		jpql = jpql.concat("AND a.secuencia = :secuencia ");
		jpql = jpql.concat("AND a.dav = :dav ");
		jpql = jpql.concat("and a.codInstrumento = :codInstrumento ");
		jpql = jpql.concat("and a.corr = :corr ");
		jpql = jpql.concat("and a.montoMo = :montoMo ");
		
		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("codInst", codInst.trim());
		query.setParameter("codId", codId.trim());
		query.setParameter("anio", anio.trim());
		query.setParameter("secuencia", secuencia.trim());
		query.setParameter("dav", dav);		
		query.setParameter("codInstrumento", codInstrumento.trim());
		query.setParameter("corr", corr.trim());
		query.setParameter("montoMo", montoMo.multiply(BigDecimal.valueOf(-1)));
		
		List result = query.getResultList();
		if (result.size() > 0)
			tPagoImp = (TPagoImp) result.get(0);

		return tPagoImp;
	}
	
	public TPagoImp findALEofLEX(String codInstrumento, BigDecimal montoMo, String obs) {

		TPagoImp tPagoImp = null;
		String jpql = "SELECT a ";
		jpql = jpql.concat("FROM TPagoImp a ");
		jpql = jpql.concat("where a.codInstrumento = :codInstrumento ");
		jpql = jpql.concat("and a.montoMo = :montoMo ");		
		jpql = jpql.concat("and a.obs = :obs ");

		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("codInstrumento", codInstrumento.trim());
		// para operaciones ALE el monto es el monto invertido
		query.setParameter("montoMo", montoMo.multiply(BigDecimal.valueOf(-1)));		
		query.setParameter("obs", obs.trim());
		
		List result = query.getResultList();
		if (result.size() > 0)
			tPagoImp = (TPagoImp) result.get(0);

		return tPagoImp;
	}
	
}
