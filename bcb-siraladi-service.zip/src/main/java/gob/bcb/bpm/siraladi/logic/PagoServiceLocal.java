package gob.bcb.bpm.siraladi.logic;

import java.util.List;
import java.util.Map;

import gob.bcb.bpm.siraladi.dao.PagoLocal;
import gob.bcb.bpm.siraladi.dao.UserTransactionServ;
import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.Pago;
import gob.bcb.bpm.siraladi.jpa.TPagoImp;

/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public interface PagoServiceLocal extends UserTransactionServ{

	Pago crearReg(Pago pago, Apertura apertura);
	boolean isValidData(Pago pago, Apertura apertura);
	Pago modificar(Pago pago, Apertura apertura) ;
	/**
	 * registro de debitos por importacion de datos consultados a WS convenio aladi, si ocurre un error al guardar
	 * en base de datos este se obvia ya que el proceso es realizado autom�ticamente
	 * @param tPagoImpList lista de debitos
	 * @return lista de pagos pendientes de autorizaci�n
	 */
	List<Pago> registrarPagoImport(List<TPagoImp> tPagoImpList, boolean isProcesoAutomatico);
	PagoLocal getPagoLocal();
	Map<String, Object> getWarnnings();
	void registroWSPorExport(Pago pago, Apertura apertura);
	void eliminar(Pago pago, Apertura apertura);
	void eliminarPagoImport(TPagoImp tPagoImp);		
	Pago registrarPagoImport(TPagoImp tPagoImp, boolean isProcesoAutomatico);
}