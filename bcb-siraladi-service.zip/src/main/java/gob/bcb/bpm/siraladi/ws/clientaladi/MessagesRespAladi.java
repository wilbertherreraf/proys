package gob.bcb.bpm.siraladi.ws.clientaladi;

import gob.bcb.bpm.siraladi.common.MsgManager;
import gob.bcb.bpm.siraladi.dao.qnative.DBSourceHandlerFactory;
import gob.bcb.bpm.siraladi.service.ConfigurationServ;
import gob.bcb.bpm.siraladi.utils.Constants;
import gob.bcb.bpm.siraladi.utils.UtilsProperties;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

/**
 * @author wherrera Clase singleton que administra los mensajes de error
 */
public class MessagesRespAladi {
	private static Logger log = Logger.getLogger(MessagesRespAladi.class);
	private Properties messagesAladi;
	private static Map<String, MessagesRespAladi> instance = new HashMap<String, MessagesRespAladi>();
	public static final ResourceBundle resourceBundle;

	static {
		ResourceBundle bundle = null;
		try {
			bundle = ResourceBundle.getBundle("messagesaladi");
			resourceBundle = bundle;
			log.setResourceBundle(resourceBundle);
		} catch (Exception e) {
			throw new RuntimeException("No se pudo cargar archivo de mensajes 'messagesaladi'");
		}
		log.info("Carga de recurso de mensajes Convenio Aladi ... hecho ");
	}

	public static MessagesRespAladi newInstanceOfMsg(String idProperties, String pathFilePropMsg) {
		if (instance.containsKey(idProperties))
			return instance.get(idProperties);

		Properties messagesAladi = UtilsProperties.loadFileMsgProperties(pathFilePropMsg);

		if (messagesAladi.isEmpty()) {
			throw new RuntimeException("Mensajes de respuesta para " + idProperties + " no fue inicializado correctamente, archivo "
					+ pathFilePropMsg + " sin contenido");
		}
		MessagesRespAladi messagesRespAladi = new MessagesRespAladi();
		messagesRespAladi.setMessagesAladi(messagesAladi);
		instance.put(idProperties, messagesRespAladi);
		log.info("Archivo de mensajes " + idProperties + " configurado con ruta " + pathFilePropMsg + " ... hecho");

		return messagesRespAladi;
	}

	public static MessagesRespAladi getInstance(String idProperties) {
		if (instance.size() == 0) {
			throw new RuntimeException("No se inicializ  correctamente la instancia del contenedor de mensajes " + MessagesRespAladi.class.getName());
		}
		if (!instance.containsKey(idProperties))
			throw new RuntimeException("No se existe el archivo de propiedades de mensaje con id " + idProperties);

		return instance.get(idProperties);

	}

	public static String getDescripResp(String idProperties, String code) {
		String descrip = "";

		if (code == null || code.trim().isEmpty()) {
			descrip = "CODIGO RESP NULO - DESCRIPCION CODIGO RESPUESTA NO DEFINIDA";
		} else {
			descrip = MessagesRespAladi
					.getInstance(idProperties)
					.getMessagesAladi()
					.getProperty(
							code,
							"Codigo " + code + " de respuesta aladi inexistente en archivo: "
									+ (String) ConfigurationServ.getConfigProperty(Constants.FILE_MESSAGES_RESP_ALADI, "string"));
		}

		return descrip;
	}

	public static String getDescripResp(String code) {
		return new MsgManager(code, resourceBundle).toString().trim();
		//return new MsgManager(code, log, new Object[] { code }).toString();

	}

	public void setMessagesAladi(Properties messagesAladi) {
		this.messagesAladi = messagesAladi;
	}

	private Properties getMessagesAladi() {
		return messagesAladi;
	}
/*
	public static void main(String[] args) {
		System.out.println("inicio");
		System.out.println(MessagesRespAladi.getDescripResp("1046"));
		System.out.println(MessagesRespAladi.getDescripResp("1048"));

	}*/
}
