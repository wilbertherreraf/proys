package gob.bcb.bpm.siraladi.logic;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

import gob.bcb.bpm.siraladi.dao.RegistroLocal;
import gob.bcb.bpm.siraladi.dao.UserTransactionServ;
import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.Registro;



/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */

public interface RegistroServiceLocal extends UserTransactionServ{
	Registro crearReg(Registro registro, Apertura apertura);
	Registro modificar(Registro registro, Apertura apertura, String tipoOperacionAladi) ;
	boolean isValidData(Registro registro, Apertura apertura);

	RegistroLocal getRegistroLocal();
	Map<String, Object> getWarnnings();
	void eliminar(Registro registro, Apertura apertura);
	void registroWSPorImporExport(Registro registro, Apertura apertura, String tipoOperacionAladi);
	/**
	 * Genera un registro de anulacion con datos del total del saldo del instrumento y se contabiliza
	 * @param apertura
	 * @return
	 */
	Registro registroDeAnulacion(Apertura apertura);
}
