package gob.bcb.bpm.siraladi.pojo;

import java.math.BigDecimal;

public class SaldoConvenio {

	private String codPais;
	private String nomPais;
	private BigDecimal debitoA;
	private BigDecimal montoCuentaA;
	private BigDecimal debitoB;
	private BigDecimal montoCuentaB;
	private BigDecimal saldoAladi;
	private BigDecimal saldoDiaCtaA;
	private BigDecimal saldoDiaCtaB;
	private BigDecimal pagosPendientes;
	private BigDecimal cobrosPendientes;
	private BigDecimal total;
	private boolean seleccionado;

	public SaldoConvenio() {
	}

	public SaldoConvenio(String codPais, String nomPais, BigDecimal debitoA, BigDecimal montoCuentaA, BigDecimal debitoB,
			BigDecimal montoCuentaB, BigDecimal saldoAladi, BigDecimal pagosPendientes, BigDecimal cobrosPendientes, BigDecimal total,
			boolean seleccionado) {
		this.codPais = codPais;
		this.nomPais = nomPais;
		this.debitoA = debitoA;
		this.montoCuentaA = montoCuentaA;
		this.debitoB = debitoB;
		this.montoCuentaB = montoCuentaB;
		this.saldoAladi = saldoAladi;
		this.pagosPendientes = pagosPendientes;
		this.cobrosPendientes = cobrosPendientes;
		this.total = total;
		this.seleccionado = seleccionado;
		
		this.saldoDiaCtaA = BigDecimal.ZERO;
		this.saldoDiaCtaB = BigDecimal.ZERO;		
	}
	public SaldoConvenio(gob.bcb.siraladi.xml.model.Saldoconvenio saldoconvenio) {
		this.codPais = saldoconvenio.getCodPais();
		this.nomPais = saldoconvenio.getNomPais();
		this.debitoA = saldoconvenio.getDebitoA();
		this.montoCuentaA = saldoconvenio.getMontoCuentaA();
		this.debitoB = saldoconvenio.getDebitoB();
		this.montoCuentaB = saldoconvenio.getMontoCuentaB();
		this.saldoDiaCtaA = saldoconvenio.getSaldoDiaCtaA();
		this.saldoDiaCtaB = saldoconvenio.getSaldoDiaCtaB();		
		this.saldoAladi = saldoconvenio.getSaldoAladi();
		this.pagosPendientes = saldoconvenio.getPagosPendientes();
		this.cobrosPendientes = saldoconvenio.getCobrosPendientes();
		
	}
	public gob.bcb.siraladi.xml.model.Saldoconvenio getObjectJAXB() {
		gob.bcb.siraladi.xml.model.Saldoconvenio saldoconvenio = new gob.bcb.siraladi.xml.model.Saldoconvenio();
		saldoconvenio.setCodPais(codPais);
		saldoconvenio.setNomPais(nomPais);
		saldoconvenio.setDebitoA(debitoA);
		saldoconvenio.setMontoCuentaA(montoCuentaA);
		saldoconvenio.setDebitoB(debitoB);
		saldoconvenio.setMontoCuentaB(montoCuentaB);
		saldoconvenio.setSaldoDiaCtaA(saldoDiaCtaA);
		saldoconvenio.setSaldoDiaCtaB(saldoDiaCtaB);		
		saldoconvenio.setSaldoAladi(saldoAladi);
		saldoconvenio.setPagosPendientes(pagosPendientes);
		saldoconvenio.setCobrosPendientes(cobrosPendientes);
		return saldoconvenio;
	}

	public String getCodPais() {
		return codPais;
	}

	public void setCodPais(String codPais) {
		this.codPais = codPais;
	}

	public String getNomPais() {
		return nomPais;
	}

	public void setNomPais(String nomPais) {
		this.nomPais = nomPais;
	}

	public BigDecimal getDebitoA() {
		return debitoA;
	}

	public void setDebitoA(BigDecimal debitoA) {
		this.debitoA = debitoA;
	}

	public BigDecimal getMontoCuentaA() {
		return montoCuentaA;
	}

	public void setMontoCuentaA(BigDecimal montoCuentaA) {
		this.montoCuentaA = montoCuentaA;
	}

	public BigDecimal getDebitoB() {
		return debitoB;
	}

	public void setDebitoB(BigDecimal debitoB) {
		this.debitoB = debitoB;
	}

	public BigDecimal getMontoCuentaB() {
		return montoCuentaB;
	}

	public void setMontoCuentaB(BigDecimal montoCuentaB) {
		this.montoCuentaB = montoCuentaB;
	}

	public BigDecimal getSaldoAladi() {
		return saldoAladi;
	}

	public void setSaldoAladi(BigDecimal saldoAladi) {
		this.saldoAladi = saldoAladi;
	}

	public BigDecimal getPagosPendientes() {
		return pagosPendientes;
	}

	public void setPagosPendientes(BigDecimal pagosPendientes) {
		this.pagosPendientes = pagosPendientes;
	}

	public BigDecimal getCobrosPendientes() {
		return cobrosPendientes;
	}

	public void setCobrosPendientes(BigDecimal cobrosPendientes) {
		this.cobrosPendientes = cobrosPendientes;
	}

	public BigDecimal getTotal() {
		return total;
	}

	public void setTotal(BigDecimal total) {
		this.total = total;
	}

	public boolean isSeleccionado() {
		return seleccionado;
	}

	public void setSeleccionado(boolean seleccionado) {
		this.seleccionado = seleccionado;
	}

	public void setSaldoDiaCtaA(BigDecimal saldoDiaCtaA) {
		this.saldoDiaCtaA = saldoDiaCtaA;
	}

	public BigDecimal getSaldoDiaCtaA() {
		return saldoDiaCtaA;
	}

	public void setSaldoDiaCtaB(BigDecimal saldoDiaCtaB) {
		this.saldoDiaCtaB = saldoDiaCtaB;
	}

	public BigDecimal getSaldoDiaCtaB() {
		return saldoDiaCtaB;
	}

}
