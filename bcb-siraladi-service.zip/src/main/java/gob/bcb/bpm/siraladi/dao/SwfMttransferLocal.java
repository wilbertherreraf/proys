package gob.bcb.bpm.siraladi.dao;

import java.util.List;

import gob.bcb.bpm.siraladi.jpa.SwfMttransfer;
import gob.bcb.bpm.siraladi.jpa.SwfMttransferdet;
import gob.bcb.bpm.siraladi.jpa.SwfMttransferdetPK;



//
//public interface SwfMttransferLocal extends DAO<String, SwfMttransfer>{
//public interface SwfMttransferLocal 	extends GenericoDao<SwfMttransfer> {
public interface SwfMttransferLocal extends DAO<String, SwfMttransfer>{
	SwfMttransfer findByCodigo(String mttCodttransfer);

	List<SwfMttransfer> getMTs();

}
