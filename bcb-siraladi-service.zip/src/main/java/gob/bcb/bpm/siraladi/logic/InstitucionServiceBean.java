package gob.bcb.bpm.siraladi.logic;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.transaction.SystemException;

import org.apache.log4j.Logger;

import gob.bcb.bpm.siraladi.dao.EntityUserTransaction;
import gob.bcb.bpm.siraladi.dao.InstitucionBean;
import gob.bcb.bpm.siraladi.dao.InstitucionLocal;
import gob.bcb.bpm.siraladi.exceptions.AladiException;
import gob.bcb.bpm.siraladi.jpa.Institucion;

/**
 * @author wilherrera Wilbert Herrera Flores Banco Central de Bolivia Departamento de Desarrollo
 */
public class InstitucionServiceBean extends EntityUserTransaction implements InstitucionServiceLocal {
	private static Logger log = Logger.getLogger(InstitucionServiceBean.class);
	private InstitucionLocal institucionLocal;

	public InstitucionServiceBean(EntityManager entityManager) {
		super(entityManager);
		institucionLocal = new InstitucionBean();
		institucionLocal.setEntityManager(entityManager);
	}

	
	public List<Institucion> crearReg(List<Institucion> institucionListIn) {
		List<Institucion> institucionList = new ArrayList<Institucion>();
		for (Institucion institucion : institucionListIn) {
			try {
				begin();
				Institucion institucionOld = institucionLocal.findById(institucion.getCodInst(), false);
				if (institucionOld != null) {
					if (institucionOld.getCveTipoInst() == null) {
						institucion.setCveTipoInst("N");
						institucionOld.setCveTipoInst("N");
					}

					if (!institucionOld.getCveTipoInst().trim().equals("S")) {
						institucion = institucionLocal.makePersistent(institucion);
						institucionList.add(institucion);
					}
				} else {
					institucion.setCveTipoInst("N");
					institucion = institucionLocal.makePersistent(institucion);
					institucionList.add(institucion);
				}
				institucionLocal.flush();
				commit();
				log.debug("salvando institucion " + institucion.getCodInst());
			} catch (Exception e) {
				log.error("Error al registrar " + institucion.getCodInst() + " en base de datos local información de instituciones: " + e.getMessage());
				try {
					rollback();
				} catch (SystemException e1) {
					log.info("Error al realizar rollback en base de datos : " + e1.getMessage());
				}
			}
		}

		return institucionList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.bpm.siraladi.logic.InstitucionServiceLocal#suspenderInstituciones()
	 */
	
	public void suspenderInstituciones() {
		try {

			List<Institucion> institucionList = institucionLocal.findByCveEstado("0", null);
			institucionList.addAll(institucionLocal.findByCveEstado("F", null));
			for (Institucion institucion : institucionList) {
				try {
					begin();
					if (!institucion.getCveTipoInst().equals("S")) {
						institucion.setCveEstado("1");
						institucion = institucionLocal.makePersistent(institucion);
						institucionLocal.flush();
					}
					commit();
				} catch (Exception e) {
					log.error("Errror al suspender intitucion " + institucion.getCodInst() + " ERROR: " + e.getMessage());
					rollback();
				}

			}
		} catch (Exception e) {
			throw new AladiException("ERROR_ACTUALIZAR_INSTITUCIONES", new Object[] { e.getMessage() });
		} finally {
			try {
				rollback();
			} catch (SystemException e) {
				log.error("Error en rollback " + e.getMessage(), e);
			}

		}

	}
}
