package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.Movimiento;



public interface MovimientoLocal extends DAO<Integer, Movimiento>{
	/**
	 * @return retorna el movimiento con el maximo nromov 
	 */
	Movimiento getMaxMovimiento();

	/**
	 * @param nroMov numero de movimiento a retornar
	 * @return movimiento registrado 
	 */
	Movimiento getByNroMov(Integer nroMov);
}
