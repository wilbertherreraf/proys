
package gob.bcb.bpm.siraladi.ws.clientaladi.asicaprcaoc;

import gob.bcb.bpm.siraladi.ws.clientaladi.LocalDateAdapter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import javax.xml.datatype.XMLGregorianCalendar;

import org.joda.time.LocalDate;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Login" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Contrasena" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Inspag" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Conv" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Nroreemb" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Inst" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Fchemi" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="Monto" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="Obs" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Nrosol" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "login",
    "contrasena",
    "inspag",
    "conv",
    "nroreemb",
    "inst",
    "fchemi",
    "monto",
    "obs",
    "nrosol"
})
@XmlRootElement(name = "sicap_rcaoc_ws.Execute")
public class SicapRcaocWsExecute {

    @XmlElement(name = "Login", required = true)
    protected String login;
    @XmlElement(name = "Contrasena", required = true)
    protected String contrasena;
    @XmlElement(name = "Inspag", required = true)
    protected String inspag;
    @XmlElement(name = "Conv", required = true)
    protected String conv;
    @XmlElement(name = "Nroreemb", required = true)
    protected String nroreemb;
    @XmlElement(name = "Inst", required = true)
    protected String inst;
    @XmlElement(name = "Fchemi")
    @XmlJavaTypeAdapter(LocalDateAdapter.class)    
    @XmlSchemaType(name = "date")
    protected LocalDate fchemi;
    //protected XMLGregorianCalendar fchemi;
    @XmlElement(name = "Monto")
    protected double monto;
    @XmlElement(name = "Obs")
    protected String obs;
    @XmlElement(name = "Nrosol")
    protected String nrosol;

    /**
     * Gets the value of the login property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLogin() {
        return login;
    }

    /**
     * Sets the value of the login property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLogin(String value) {
        this.login = value;
    }

    /**
     * Gets the value of the contrasena property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContrasena() {
        return contrasena;
    }

    /**
     * Sets the value of the contrasena property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContrasena(String value) {
        this.contrasena = value;
    }

    /**
     * Gets the value of the inspag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInspag() {
        return inspag;
    }

    /**
     * Sets the value of the inspag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInspag(String value) {
        this.inspag = value;
    }

    /**
     * Gets the value of the conv property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConv() {
        return conv;
    }

    /**
     * Sets the value of the conv property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConv(String value) {
        this.conv = value;
    }

    /**
     * Gets the value of the nroreemb property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNroreemb() {
        return nroreemb;
    }

    /**
     * Sets the value of the nroreemb property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNroreemb(String value) {
        this.nroreemb = value;
    }

    /**
     * Gets the value of the inst property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInst() {
        return inst;
    }

    /**
     * Sets the value of the inst property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInst(String value) {
        this.inst = value;
    }

    /**
     * Gets the value of the fchemi property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public LocalDate getFchemi() {
        return fchemi;
    }    
//    public XMLGregorianCalendar getFchemi() {
//        return fchemi;
//    }

    /**
     * Sets the value of the fchemi property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFchemi(LocalDate value) {
        this.fchemi = value;
    }    
//    public void setFchemi(XMLGregorianCalendar value) {
//        this.fchemi = value;
//    }

    /**
     * Gets the value of the monto property.
     * 
     */
    public double getMonto() {
        return monto;
    }

    /**
     * Sets the value of the monto property.
     * 
     */
    public void setMonto(double value) {
        this.monto = value;
    }

    /**
     * Gets the value of the obs property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getObs() {
        return obs;
    }

    /**
     * Sets the value of the obs property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setObs(String value) {
        this.obs = value;
    }

    /**
     * Gets the value of the nrosol property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNrosol() {
        return nrosol;
    }

    /**
     * Sets the value of the nrosol property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNrosol(String value) {
        this.nrosol = value;
    }

}
