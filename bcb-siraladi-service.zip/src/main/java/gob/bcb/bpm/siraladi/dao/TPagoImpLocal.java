package gob.bcb.bpm.siraladi.dao;



import gob.bcb.bpm.siraladi.jpa.TPagoImp;


public interface TPagoImpLocal  extends DAO<Integer, TPagoImp>{
	TPagoImp getMaxMovimiento();

}
