package gob.bcb.bpm.siraladi.dao;

import java.util.List;

import gob.bcb.bpm.siraladi.jpa.Usuario;

public interface UsuarioLocal extends DAO<String, Usuario>{

	Usuario findByCodigo(String codUsuario);

	List<Usuario> findByEstado(String cveVigente);

	Usuario saveorupdate(Usuario usuario);

}
