package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the persona_inst database table.
 * 
 */
@Entity
@Table(name="persona_inst")
public class PersonaInst implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private PersonaInstPK id;

	@ManyToOne
	@JoinColumn(name="cod_inst", insertable = false, updatable=false)
	private Institucion institucion;
	
    public PersonaInst() {
    }

	public PersonaInstPK getId() {
		return this.id;
	}

	public void setId(PersonaInstPK id) {
		this.id = id;
	}

	public Institucion getInstitucion() {
		return institucion;
	}

	public void setInstitucion(Institucion institucion) {
		this.institucion = institucion;
	}
	
}