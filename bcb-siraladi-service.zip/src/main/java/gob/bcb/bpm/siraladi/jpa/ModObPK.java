package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the mod_obs database table.
 * 
 */
//@Embeddable
public class ModObPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="nro_mov", unique=true, nullable=false)
	private int nroMov;

	@Column(name="nro_mod", unique=true, nullable=false)
	private short nroMod;

    public ModObPK() {
    }
	public int getNroMov() {
		return this.nroMov;
	}
	public void setNroMov(int nroMov) {
		this.nroMov = nroMov;
	}
	public short getNroMod() {
		return this.nroMod;
	}
	public void setNroMod(short nroMod) {
		this.nroMod = nroMod;
	}

	
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof ModObPK)) {
			return false;
		}
		ModObPK castOther = (ModObPK)other;
		return 
			(this.nroMov == castOther.nroMov)
			&& (this.nroMod == castOther.nroMod);

    }
    
	
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.nroMov;
		hash = hash * prime + (this.nroMod);
		
		return hash;
    }
}
