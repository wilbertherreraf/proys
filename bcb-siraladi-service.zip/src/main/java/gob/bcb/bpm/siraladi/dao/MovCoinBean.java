package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.MovCoin;
import gob.bcb.bpm.siraladi.jpa.MovCoinPK;

import java.util.List;


import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("movCoinLocal")
@Transactional
public class MovCoinBean extends GenericDAO<MovCoinPK, MovCoin> implements MovCoinLocal {
	/* (non-Javadoc)
	 * @see gob.bcb.bpm.siraladi.dao.MovCoinLocal#findByNroMov(int)
	 */
	
	public List<MovCoin> findByNroMov(Integer nroMov) {
		String jpql = "SELECT p FROM MovCoin p " + " WHERE p.id.nroMov = :nroMov ";
		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("nroMov", nroMov);
		return query.getResultList();
	}	
}
