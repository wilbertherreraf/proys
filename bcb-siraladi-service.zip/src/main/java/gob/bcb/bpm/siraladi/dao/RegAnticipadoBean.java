package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.exceptions.AladiException;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Movimiento;
import gob.bcb.bpm.siraladi.jpa.Pais;
import gob.bcb.bpm.siraladi.jpa.RegAnticipado;
import gob.bcb.bpm.siraladi.logic.MovimientoServiceBean;
import gob.bcb.bpm.siraladi.logic.MovimientoServiceLocal;
import gob.bcb.bpm.siraladi.utils.NumeroDAV;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


import javax.persistence.Query;
import javax.persistence.TemporalType;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("regAnticipadoLocal")
@Transactional
public class RegAnticipadoBean extends GenericDAO<Integer, RegAnticipado> implements RegAnticipadoLocal {

	// public RegAnticipadoBean() {
	// super();
	// log.info("creado dao " + this.getClass().getName());
	// }
	public RegAnticipado findByNroMov(Integer nroMov) {
		RegAnticipado regAnticipado = null;

		String jpql = "SELECT a FROM RegAnticipado a ";
		jpql = jpql.concat("where a.nroMov = :nroMov ");

		log.info("RegAnticipado findByNroMov " + nroMov + " " + jpql);

		Query query = entityManager.createQuery(jpql);

		query.setParameter("nroMov", nroMov);

		List result = query.getResultList();
		if (result.size() > 0)
			regAnticipado = (RegAnticipado) result.get(0);
		return regAnticipado;
	}

	public RegAnticipado findByCodReembolso(String codInst, String codId, String anio, String secuencia, Integer dav) {
		RegAnticipado regAnticipado = null;

		String jpql = "SELECT a FROM RegAnticipado a ";
		jpql = jpql.concat("where a.codInst = :codInst ");
		jpql = jpql.concat("AND a.codId = :codId ");
		jpql = jpql.concat("AND a.anio = :anio ");
		jpql = jpql.concat("AND a.secuencia = :secuencia ");
		log.info("findByCodReembolso ");
		log.info("findByCodReembolso " + jpql + " em " + (getEntityManager() == null));

		Query query = getEntityManager().createQuery(jpql);

		query.setParameter("codInst", codInst.trim());
		query.setParameter("codId", codId.trim());
		query.setParameter("anio", anio.trim());
		query.setParameter("secuencia", (secuencia == null ? "" : secuencia.trim()));

		List result = query.getResultList();
		if (result.size() > 0)
			regAnticipado = (RegAnticipado) result.get(0);

		return regAnticipado;
	}

	public RegAnticipado findByCodReembolsoAladi(String cveTipoApe, String nroReembolso, String cveEstadoAnt, Integer nroDebito, String codInstrumento) {
		RegAnticipado regAnticipado = null;
		String jpql = "SELECT a ";
		jpql = jpql.concat("FROM RegAnticipado a ");
		jpql = jpql.concat("where a.cveTipoApe = :cveTipoApe ");
		jpql = jpql.concat("and a.nroReembolso = :nroReembolso ");
		jpql = jpql.concat("and a.codInstrumento = :codInstrumento ");

		if (!StringUtils.isBlank(cveEstadoAnt)) {
			jpql += "and a.cveEstadoAnt = :cveEstadoAnt ";
		}
		if (nroDebito != null) {
			jpql += "and a.nroDebito = :nroDebito ";
		}
		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("cveTipoApe", cveTipoApe);
		query.setParameter("nroReembolso", nroReembolso);
		query.setParameter("codInstrumento", codInstrumento);

		if (!StringUtils.isBlank(cveEstadoAnt)) {
			query.setParameter("cveEstadoAnt", cveEstadoAnt);
		}
		if (nroDebito != null) {
			query.setParameter("nroDebito", nroDebito);
		}

		List result = query.getResultList();
		if (result.size() > 0)
			regAnticipado = (RegAnticipado) result.get(0);
		return regAnticipado;
	}

	
	public RegAnticipado getRegistroFicticio(String cveTipoApe, String codInstRecep, BigDecimal monto, Date fecha, String cveEstadoAnt,
			String codInstrumento, String tipoDH) {
		RegAnticipado regAnticipado = null;
		String jpql = "SELECT a ";
		jpql = jpql.concat("FROM RegAnticipado a ");
		jpql = jpql.concat("where a.cveTipoApe = :cveTipoApe ");
		jpql = jpql.concat("and a.codInstRecep = :codInstRecep ");
		jpql = jpql.concat("and a.fechaCargo = :fechaCargo ");
		jpql = jpql.concat("and a.cveEstadoAnt = :cveEstadoAnt ");
		jpql = jpql.concat("and a.codInstrumento = :codInstrumento ");

		if (tipoDH.equals("D")) {
			jpql += "and a.debeMo = :monto ";
		}
		if (tipoDH.equals("H")) {
			jpql += "and a.haberMo = :monto ";
		}

		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("cveTipoApe", cveTipoApe);
		query.setParameter("codInstRecep", codInstRecep);
		query.setParameter("monto", monto.abs());
		query.setParameter("fechaCargo", fecha, TemporalType.DATE);
		query.setParameter("cveEstadoAnt", cveEstadoAnt);
		query.setParameter("codInstrumento", codInstrumento);
		List result = query.getResultList();
		if (result.size() > 0)
			regAnticipado = (RegAnticipado) result.get(0);
		return regAnticipado;
	}

	public List<RegAnticipado> registrosAntBy(String cveTipoApe, String codInstRecep, Date fecha, String cveEstadoAnt, String codInstrumento) {

		String jpql = "SELECT a ";
		jpql = jpql.concat("FROM RegAnticipado a ");
		jpql = jpql.concat("where a.cveTipoApe = :cveTipoApe ");

		if (!StringUtils.isBlank(codInstRecep))
			jpql = jpql.concat("and a.codInstRecep = :codInstRecep ");

		if (fecha != null)
			jpql = jpql.concat("and a.fechaCargo = :fechaCargo ");

		if (!StringUtils.isBlank(cveEstadoAnt))
			jpql = jpql.concat("and a.cveEstadoAnt = :cveEstadoAnt ");

		if (!StringUtils.isBlank(codInstrumento))
			jpql = jpql.concat("and a.codInstrumento = :codInstrumento ");

		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("cveTipoApe", cveTipoApe);
		if (!StringUtils.isBlank(codInstRecep))
			query.setParameter("codInstRecep", codInstRecep);
		if (fecha != null)
			query.setParameter("fechaCargo", fecha, TemporalType.DATE);
		if (!StringUtils.isBlank(cveEstadoAnt))
			query.setParameter("cveEstadoAnt", cveEstadoAnt);
		if (!StringUtils.isBlank(codInstrumento))
			query.setParameter("codInstrumento", codInstrumento);

		List result = query.getResultList();

		return result;
	}

	
	public List<RegAnticipado> getRegAnticipadoByEstado(String cveEstadoAnt) {
		String jpql = "SELECT p FROM RegAnticipado p WHERE p.cveEstadoAnt = :cveEstadoAnt order by p.fechaVal asc";

		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("cveEstadoAnt", cveEstadoAnt);

		return query.getResultList();
	}

	public RegAnticipado guardar(RegAnticipado regAnticipado) {
		log.info("Inicio Salvando reganticipado ");

		MovimientoServiceLocal movimientoService = new MovimientoServiceBean(getEntityManager());
		Movimiento movimiento = movimientoService.crearMovimiento("T", regAnticipado.getCodMoneda(), new Date(), null);
		Integer nroMov = movimiento.getNroMov();

		if (nroMov == null || nroMov <= 0) {
			throw new AladiException("ERROR_GENERANDO_NRO_MOV", new Object[] { regAnticipado.getNroReembLiteral() });
		}

		if (StringUtils.isBlank(regAnticipado.getSecuencia())) {
			if (regAnticipado.getCveTipoApe().equals("I")) {
				if (regAnticipado.getCodInstrumento().equals("LEX")) {
					// la operacion es pago anticipado y genera swift para ello
					// se genera un secuencial temporal que sera el nro_mov
					regAnticipado.setSecuencia(StringUtils.leftPad(String.valueOf(nroMov), 6, '0'));
					regAnticipado.setDav(NumeroDAV.generaDAV(regAnticipado.getCodInst(), regAnticipado.getCodId(), regAnticipado.getAnio(),
							regAnticipado.getSecuencia()));
				}
			}
		}

		log.info("Salvando reganticipado " + regAnticipado.getCodigoReembolso());

		isValidData(regAnticipado);

		regAnticipado.setNroMov(nroMov);
		regAnticipado.setCveEstadoAnt("P");
		regAnticipado = makePersistent(regAnticipado);

		RegAnticipado regAnticipadoNew = findByNroMov(nroMov);
		log.info("Nuevo reganticipado " + regAnticipado.getNroMov() + " creado.");
		return regAnticipadoNew;
	}

	public boolean isValidData(RegAnticipado regAnticipado) {
		log.info("Validando RegAnticipado ");
		if (regAnticipado.getCodInstrumento() == null || regAnticipado.getCodInstrumento().trim().isEmpty()) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "El valor de codigo Instrumento inválido." });
		}

		if (regAnticipado.getCodInst().equals(regAnticipado.getCodInstRecep())) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "El Banco emisor y el banco Receptor son idénticos. Revise los datos." });
		}

		if (regAnticipado.getDebeMo() == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Monto del Debe invalido." });
		}
		if (regAnticipado.getHaberMo() == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Monto del Haber invalido." });
		}
		log.info("Validando RegAnticipado " + regAnticipado.toString());
		if (!NumeroDAV.verificaDAV(regAnticipado.getCodInst(), regAnticipado.getCodId(), regAnticipado.getAnio(), regAnticipado.getSecuencia(),
				regAnticipado.getDav())) {
			throw new AladiException(
					"El numero autoverificador (DAV) : '"
							+ regAnticipado.getDav()
							+ "', difiere con el numero elaborado por el sistema: '"
							+ NumeroDAV.generaDAV(regAnticipado.getCodInst(), regAnticipado.getCodId(), regAnticipado.getAnio(),
									regAnticipado.getSecuencia()) + "'.Verifique el codigo.");
		}

		if ((regAnticipado.getDebeMo().compareTo(BigDecimal.valueOf(0)) == 0) && (regAnticipado.getHaberMo().compareTo(BigDecimal.valueOf(0)) == 0)) {
			throw new AladiException("ERROR_DE_VALIDACION",
					new Object[] { "Los montos del DEBE y el HABER son iguales a CERO. Corrija los datos para continuar" });
		}

		InstitucionLocal institucionLocal = new InstitucionBean();
		institucionLocal.setEntityManager(getEntityManager());

		if (regAnticipado.getCveTipoApe().equals("I")) {
			Institucion institucion = institucionLocal.findById(regAnticipado.getCodInstRecep(), false);

			if (institucion == null) {
				throw new AladiException("INSTITUCION_NO_ENCONTRADA", new Object[] { regAnticipado.getCodInstRecep() });
			}

			Pais pais = getEntityManager().find(Pais.class, institucion.getPais().getCodPais());

			if (pais == null) {
				throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Pais convenio inexistente " + institucion.getPais().getCodPais() });
			}

			if (regAnticipado.getCodInstrumento().equals("ALE")) {
				if (regAnticipado.getHaberMo().compareTo(BigDecimal.valueOf(0)) == 0) {
					throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "ALE: Importe de Haber con valor nulo o cero" });
				}
			} else {
				if (regAnticipado.getDebeMo() == null || regAnticipado.getDebeMo().compareTo(BigDecimal.valueOf(0)) == 0) {
					throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Importe de DEBE con valor nulo o cero" });
				}
			}
		} else if (regAnticipado.getCveTipoApe().equals("E")) {
			Institucion institucion = institucionLocal.findById(regAnticipado.getCodInst(), false);

			if (institucion == null) {
				throw new AladiException("INSTITUCION_NO_ENCONTRADA", new Object[] { regAnticipado.getCodInst() });
			}

			if (regAnticipado.getCodInstrumento().equals("ALE")) {
				if (regAnticipado.getDebeMo().compareTo(BigDecimal.valueOf(0)) == 0) {
					throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "ALE: Importe de DEBE con valor nulo o cero" });
				}
			} else {
				if (regAnticipado.getHaberMo() == null || regAnticipado.getHaberMo().compareTo(BigDecimal.valueOf(0)) == 0) {
					throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Importe de HABER con valor nulo o cero" });
				}
			}
		} else {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Tipo de operacion invalido debe ser I(Importaci�n) o E(Exportaci�n)" });
		}

		return true;
	}

}
