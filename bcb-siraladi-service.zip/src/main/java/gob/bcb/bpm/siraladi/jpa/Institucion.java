package gob.bcb.bpm.siraladi.jpa;

import gob.bcb.bpm.siraladi.utils.UtilsDate;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;

import javax.persistence.ManyToOne;

/**
 * The persistent class for the institucion database table.
 * 
 */
@Entity
@Table(name = "institucion")
public class Institucion implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy=GenerationType.IDENTITY)	
	@Column(name = "cod_inst")
	private String codInst;

	@Column(name = "cod_usuario")
	private String codUsuario;

	@Column(name = "cve_estado")
	private String cveEstado;

	@Column(name = "cve_tipo_inst")
	private String cveTipoInst;

	@Column(name = "estacion")
	private String estacion;

	@Column(name = "titular")
	private String titular;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "fecha_ape")
	private Date fechaApe;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "fecha_hora")
	private Date fechaHora;

	@Column(name = "nom_inst")
	private String nomInst;

	@Column(name = "nom_plaza")
	private String nomPlaza;

	@Column(name = "bic")
	private String bic;
	
	@Column(name = "cta_numero")
	private String ctaNumero;
	
	@Column(name = "cta_codmon")
	private String ctaCodmon;
	
	@Column(name = "cta_nrodescrip")
	private String ctaNrodescrip;
	
	@Column(name = "cta_codinst")
	private String ctaCodinst;

	@Column(name = "cta_codttransfer")
	private String ctaCodttransfer;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "cod_pais")
	private Pais pais;

	public Institucion() {
	}

	public Institucion(String codInst, String codUsuario, String cveEstado, String cveTipoInst, String estacion, String titular, Date fechaApe,
			Date fechaHora, String nomInst, String nomPlaza, Pais pais) {
		this.codInst = codInst;
		this.codUsuario = codUsuario;
		this.cveEstado = cveEstado;
		this.cveTipoInst = cveTipoInst;
		this.estacion = estacion;
		this.titular = titular;
		this.fechaApe = fechaApe;
		this.fechaHora = fechaHora;
		this.nomInst = nomInst;
		this.nomPlaza = nomPlaza;
		this.pais = pais;
	}

	public Institucion(gob.bcb.siraladi.xml.model.Institucion institucion) {
		this.codInst = institucion.getCodInst();
		this.cveEstado = institucion.getCveEstado();
		this.cveTipoInst = institucion.getCveTipoInst();
		this.titular = institucion.getTitular();
		try {
			this.fechaApe = institucion.getFechaApe().toGregorianCalendar().getTime();
		} catch (Exception e) {
		}
		this.nomInst = institucion.getNomInst();
		this.nomPlaza = institucion.getNomPlaza();
		Pais pais = new Pais();
		pais.setCodPais(institucion.getCodPais());
		this.pais = pais;
	}

	public gob.bcb.siraladi.xml.model.Institucion getObjectJAXB() {
		gob.bcb.siraladi.xml.model.Institucion institucion = new gob.bcb.siraladi.xml.model.Institucion();
		institucion.setCodInst(codInst);
		institucion.setCveEstado(cveEstado);
		institucion.setCveTipoInst(cveTipoInst);
		institucion.setTitular(titular);
		try {
			institucion.setFechaApe(UtilsDate.StrToXMLGregoCal(UtilsDate.stringFromDate(fechaApe, "yyyy-MM-dd"), "-"));
		} catch (Exception e) {
		}
		institucion.setNomInst(nomInst);
		institucion.setNomPlaza(nomPlaza);
		institucion.setCodPais(pais.getCodPais());
		return institucion;
	}

	public String getCodInst() {
		return this.codInst;
	}

	public void setCodInst(String codInst) {
		this.codInst = codInst;
	}

	public String getCodUsuario() {
		return this.codUsuario;
	}

	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}

	public String getCveEstado() {
		return this.cveEstado;
	}

	public void setCveEstado(String cveEstado) {
		this.cveEstado = cveEstado;
	}

	public String getCveTipoInst() {
		return this.cveTipoInst;
	}

	public void setCveTipoInst(String cveTipoInst) {
		this.cveTipoInst = cveTipoInst;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaApe() {
		return this.fechaApe;
	}

	public void setFechaApe(Date fechaApe) {
		this.fechaApe = fechaApe;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getNomInst() {
		return this.nomInst;
	}

	public void setNomInst(String nomInst) {
		this.nomInst = nomInst;
	}

	public String getNomPlaza() {
		return this.nomPlaza;
	}

	public void setNomPlaza(String nomPlaza) {
		this.nomPlaza = nomPlaza;
	}

	/*
	 * public List<Apertura> getAperturas() { return this.aperturas; }
	 * 
	 * public void setAperturas(List<Apertura> aperturas) { this.aperturas =
	 * aperturas; }
	 */
	public Pais getPais() {
		return this.pais;
	}

	public void setPais(Pais pais) {
		this.pais = pais;
	}

	public void setTitular(String titular) {
		this.titular = titular;
	}

	public String getTitular() {
		return titular;
	}

	public String getBic() {
		return bic;
	}

	public void setBic(String bic) {
		this.bic = bic;
	}

	public String getCtaNumero() {
		return ctaNumero;
	}

	public void setCtaNumero(String ctaNumero) {
		this.ctaNumero = ctaNumero;
	}

	public String getCtaCodmon() {
		return ctaCodmon;
	}

	public void setCtaCodmon(String ctaCodmon) {
		this.ctaCodmon = ctaCodmon;
	}

	public String getCtaNrodescrip() {
		return ctaNrodescrip;
	}

	public void setCtaNrodescrip(String ctaNrodescrip) {
		this.ctaNrodescrip = ctaNrodescrip;
	}

	public String getCtaCodinst() {
		return ctaCodinst;
	}

	public void setCtaCodinst(String ctaCodinst) {
		this.ctaCodinst = ctaCodinst;
	}

	public String getCtaCodttransfer() {
		return ctaCodttransfer;
	}

	public void setCtaCodttransfer(String ctaCodttransfer) {
		this.ctaCodttransfer = ctaCodttransfer;
	}
}
