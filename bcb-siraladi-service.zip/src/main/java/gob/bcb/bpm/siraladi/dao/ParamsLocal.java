package gob.bcb.bpm.siraladi.dao;


import gob.bcb.bpm.siraladi.jpa.Param;


public interface ParamsLocal extends DAO<String, Param>{

	Param findByCodigo(String nomparam);

	Param saveorupdate(Param horario);

}
