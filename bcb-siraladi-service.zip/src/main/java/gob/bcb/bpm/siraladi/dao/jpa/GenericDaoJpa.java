package gob.bcb.bpm.siraladi.dao.jpa;

import gob.bcb.bpm.siraladi.dao.GenericoDao;
import gob.bcb.bpm.siraladi.jpa.DomainObject;

import java.lang.reflect.ParameterizedType;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;

//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
public class GenericDaoJpa<T extends DomainObject> implements GenericoDao<T> {
	private static final Logger log = Logger.getLogger(GenericDaoJpa.class);
	// private static final Logger log = LoggerFactory.getLogger(
	// GenericDaoJpa.class );
	private Class<T> type;
	@PersistenceContext(unitName = "ALADI_PU")
	protected EntityManager entityManager;

//	private GenUsuario genUsuario;
	private String fieldAuditAuditfho;
	private String fieldAuditAuditusr;
	private String fieldAuditAuditwst;

    protected GenericDaoJpa() {
    	log.info("AAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        this.type = (Class<T>) ((ParameterizedType) getClass()
                .getGenericSuperclass()).getActualTypeArguments()[0];
    }
//
//	public GenericDaoJpa(Class<T> type) {
//		super();
//		this.type = type;
//
////		List<String> fieldsAudit0 = AccessorsUtil.extractFieldsList(type);
////		for (String field : fieldsAudit0) {
////			if (field.contains("Auditfho")) {
////				fieldAuditAuditfho = field;
////				fieldAuditAuditfho = "set" + Character.toUpperCase(fieldAuditAuditfho.charAt(0)) + fieldAuditAuditfho.substring(1);
////			} else if (field.contains("Auditusr")) {
////				fieldAuditAuditusr = field;
////				fieldAuditAuditusr = "set" + Character.toUpperCase(fieldAuditAuditusr.charAt(0)) + fieldAuditAuditusr.substring(1);
////			} else if (field.contains("Auditwst")) {
////				fieldAuditAuditwst = field;
////				fieldAuditAuditwst = "set" + Character.toUpperCase(fieldAuditAuditwst.charAt(0)) + fieldAuditAuditwst.substring(1);
////			}
////		}
//
//		log.info("Creando DAO " + type.getName() + " " + fieldAuditAuditfho + " " + fieldAuditAuditusr + " " + fieldAuditAuditwst);
//	}

	// @PersistenceContext
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	// public EntityManager getEntityManager() {
	// return this.entityManager;
	// }
	public T get(Long id) {
		return (T) entityManager.find(type, id);
	}

	public List<T> getAll() {
		return entityManager.createQuery("select obj from " + type.getName() + " obj").getResultList();
	}

	public void save(T object) throws DataAccessException {
		audit(object);
		entityManager.persist(object);
		log.debug("::Nuevo registro " + object.getClass().getSimpleName() + "=>" + object.toString());
	}

	public T update(T object) throws DataAccessException {
		audit(object);
		log.debug("::Modificacion registro " + object.getClass().getSimpleName() + "=>" + object.toString());
		return (T) entityManager.merge(object);
	}

	public void delete(T object) throws DataAccessException {
//		log.warn("Eliminando " + object.toString() + " AuditAuditfho " + UtilsDate.stringFromDate(new Date(), "dd/MM/yyyy H:mm:ss")
//				+ (genUsuario != null ? " AuditAuditusr " + genUsuario.getUsrLogin() + " AuditAuditwst " + genUsuario.getUsrAuditwst() : ""));
		entityManager.remove(object);
	}

	private void audit(T object) {

//		try {
//			Method method = type.getMethod(fieldAuditAuditfho, Date.class);
//			method.invoke(object, new Date());
//		} catch (Exception ex) {
//			;
//		}
//		if (genUsuario != null) {
//			try {
//				Method method = type.getMethod(fieldAuditAuditusr, String.class);
//				method.invoke(object, genUsuario.getUsrLogin());
//			} catch (Exception ex) {
//				;
//			}
//			try {
//				Method method = type.getMethod(fieldAuditAuditwst, String.class);
//				method.invoke(object, genUsuario.getUsrAuditwst());
//			} catch (Exception ex) {
//				;
//			}
//		}
	}

//	public GenUsuario getGenUsuario() {
//		return genUsuario;
//	}
//
//	public void setGenUsuario(GenUsuario genUsuario) {
//		this.genUsuario = genUsuario;
//	}

}
