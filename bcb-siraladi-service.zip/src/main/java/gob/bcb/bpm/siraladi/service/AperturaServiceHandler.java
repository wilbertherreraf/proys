package gob.bcb.bpm.siraladi.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


import javax.persistence.EntityManager;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import org.apache.log4j.Logger;

import gob.bcb.bpm.siraladi.dao.DetPatrimonioBean;
import gob.bcb.bpm.siraladi.exceptions.AladiException;
import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.Pago;
import gob.bcb.bpm.siraladi.jpa.Registro;
import gob.bcb.bpm.siraladi.jpa.PlanPago;
import gob.bcb.bpm.siraladi.logic.AperturaServiceBean;
import gob.bcb.bpm.siraladi.logic.AperturaServiceLocal;
import gob.bcb.bpm.siraladi.logic.PagoServiceBean;
import gob.bcb.bpm.siraladi.logic.PagoServiceLocal;
import gob.bcb.bpm.siraladi.logic.PlanPagosServiceBean;
import gob.bcb.bpm.siraladi.logic.PlanPagosServiceLocal;
import gob.bcb.bpm.siraladi.logic.RegistroServiceBean;
import gob.bcb.bpm.siraladi.logic.RegistroServiceLocal;
import gob.bcb.bpm.siraladi.msgmail.MsgLogic;
import gob.bcb.bpm.siraladi.service.session.UserSessionHolder;
import gob.bcb.bpm.siraladi.utils.Constants;
import gob.bcb.bpm.siraladi.utils.StatusCode;

/**
 * @author wilherrera Wilbert Herrera Flores Banco Central de Bolivia
 *         Departamento de Desarrollo
 */
public class AperturaServiceHandler implements ServiceAladiHandler {
	private static final Logger log = Logger.getLogger(AperturaServiceHandler.class);

	private AperturaServiceLocal aperturaService;
	private PlanPagosServiceLocal planPagosService;

	private EntityManager entityManager;

	public AperturaServiceHandler(EntityManager entityManager) {
		this.entityManager = entityManager;
		aperturaService = new AperturaServiceBean(entityManager);
		planPagosService = new PlanPagosServiceBean(entityManager);
	}

	
	public void handlerProcesarMsg(RequestContext requestContext) throws AladiException, SQLException, SystemException, NotSupportedException,
			SecurityException, IllegalStateException, RollbackException, HeuristicMixedException, HeuristicRollbackException {
		PagoServiceLocal pagoService = new PagoServiceBean(entityManager);
		RegistroServiceLocal registroService = new RegistroServiceBean(entityManager);
		String statusCode = StatusCode.OPERACION_RECEIVED;
		String consent = null;

		Map<String, Object> parametros = requestContext.getBcbRequest().getRequestElements();

		String codTipoOperacion = requestContext.getResponseContext().getCodTipoOperacion();
		log.info("inicio proceso operacion handlerProcesarMsg " + codTipoOperacion);

		ResponseContext response = requestContext.getResponseContext();

		if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0101)) {
			// se verifica que la transaccion no sea proveniente de otro
			// tipo de operacion local
			aperturaService.begin();

			Apertura apertura = (Apertura) parametros.get("apertura");
			apertura = aperturaService.crearReg(apertura);
			response.addTaskDescripAdicional(aperturaService.getWarnnings());

			Registro registro = (Registro) parametros.get("registro");
			registro = registroService.crearReg(registro, apertura);

			List<PlanPago> planPagoList = new ArrayList<PlanPago>();
			planPagoList.add(planPagosService.crearPrimerPlan(apertura, registro));

			aperturaService.commit();

			response.addDescripcionParametro(codTipoOperacion, "apertura", "apertura", apertura);
			response.addDescripcionParametro(codTipoOperacion, "registro", "registro", registro);
			response.addDescripcionParametro(codTipoOperacion, "listaplanpagos", "Custom", planPagoList);
			
			log.info("Apertura creada " + apertura.getNroMov());
			statusCode = StatusCode.OPERACION_SUCCESS;
			consent = "Operacion efectuada existosamente nro Mov: " + apertura.getNroMov();

		} else if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0102)) {
			Apertura apertura = (Apertura) parametros.get("apertura");

			aperturaService.begin();

			Apertura aperturaNew = aperturaService.modificar(apertura);
			
			Registro registro = (Registro) parametros.get("registro");			
			if (registro != null){
				if (registro.getCveTipoEmis().equals("E")){
					registroService.getWarnnings().putAll(aperturaService.getWarnnings());
					Registro registroNew = registroService.modificar(registro, aperturaNew, "E");
					aperturaService.getAperturaLocal().flush();
					// registro a los WS en la central peru Peru
					//registroService.registroWSPorImporExport(registroNew, aperturaNew, "E");

					response.addDescripcionParametro(codTipoOperacion, "registro", "Custom", registroNew);
				}
			}
			aperturaService.commit();
			
			response.addDescripcionParametro(codTipoOperacion, "apertura", "Custom", aperturaNew);
			response.addTaskDescripAdicional(aperturaService.getWarnnings());

			statusCode = StatusCode.OPERACION_SUCCESS;
			consent = "Operacion efectuada existosamente nro Mov: " + aperturaNew.getNroMov();

			try {
				// segmento que actualiza el saldo de la institucion pero que no
				// deber a afectar al resultado de la transaccion
				aperturaService.begin();
				DetPatrimonioBean detPatrimonioBean = new DetPatrimonioBean();
				detPatrimonioBean.setEntityManager(entityManager);

				detPatrimonioBean.actualizarSaldoIFA((String) UserSessionHolder.get("personaRevisada"));
				aperturaService.commit();
			} catch (Exception e) {
				log.error("Error al actualizar saldo deudor" + e.getMessage(), e);
			}

		} else if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0103)) {
			// modificacion de apertura
			Apertura apertura = (Apertura) parametros.get("apertura");

			Apertura aperturaOut = null;
			if (apertura.getNroMov() == null || apertura.getNroMov() <= 0) {
				aperturaOut = aperturaService.getAperturaLocal().findByCodReembolso(apertura.getInstitucion().getCodInst(),
						apertura.getIdentificador().getCodId(), apertura.getAnio(), apertura.getSecuencia(), apertura.getDav());
			} else {
				aperturaOut = aperturaService.getAperturaLocal().findById(apertura.getNroMov(), false);
			}

			if (aperturaOut == null) {
				throw new AladiException("REEMBOLSO_INEXISTENTE", new Object[] { apertura.getNroReembLiteral() });
			}
			response.addDescripcionParametro(codTipoOperacion, "apertura", "Custom", aperturaOut);
			List<Registro> registroList = registroService.getRegistroLocal().getByNroMovApeCveEstadoReg(aperturaOut.getNroMov(), "C");
			response.addDescripcionParametro(codTipoOperacion, "listaregistros", "Custom", registroList);
			List<Pago> pagoList = pagoService.getPagoLocal().getByNroMovApeCveEstadoPago(aperturaOut.getNroMov(), null, true);
			response.addDescripcionParametro(codTipoOperacion, "listapagos", "Custom", pagoList);
			List<PlanPago> planPagoList = planPagosService.getPlanPagoLocal().findPlanPagos(aperturaOut.getNroMov(), null, null);
			response.addDescripcionParametro(codTipoOperacion, "listaplanpagos", "Custom", planPagoList);

			statusCode = StatusCode.OPERACION_SUCCESS;
			consent = "Operacion efectuada existosamente nro Mov: " + aperturaOut.getNroMov();

		} else if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0104)) {
			// es un mensaje proveniente de u na institucion autorizada
			// realizamos llamadas recursivas a las operaciones al0101 y
			// despues a la 0102 implicitamente

			Apertura apertura = (Apertura) parametros.get("apertura");
			Registro registro = (Registro) parametros.get("registro");

			aperturaService.begin();

			apertura = aperturaService.crearReg(apertura);

			log.info("Apertura creada " + apertura.getNroMov());

			Registro registroNew = registroService.crearReg(registro, apertura);

			List<PlanPago> planPagoList = new ArrayList<PlanPago>();
			planPagoList.add(planPagosService.crearPrimerPlan(apertura, registroNew));

			planPagoList = planPagosService.crearReg(planPagoList, apertura);

			// seteo para contabilizacion directa
			registro.setCveEstadoReg("C");
			// notita mental wil: cuando se realiza una consulta select
			// hiber hace un flush a la base
			registroNew = registroService.modificar(registro, apertura, "E");

			apertura = aperturaService.getAperturaLocal().findByCodReembolso(apertura.getInstitucion().getCodInst(),
					apertura.getIdentificador().getCodId(), apertura.getAnio(), apertura.getSecuencia(), apertura.getDav());

			// registro a los WS en la central peru Peru E de Emision
			//registroService.registroWSPorImporExport(registroNew, apertura, "E");

			response.addTaskDescripAdicional(aperturaService.getWarnnings());

			aperturaService.commit();

			log.info("Apertura creada " + apertura.getNroMov());
			statusCode = StatusCode.OPERACION_SUCCESS;
			consent = "Operacion efectuada existosamente nro Mov: " + apertura.getNroMov();

			try {
				// segmento que actualiza el saldo de la institucion pero que no
				// deber a afectar al resultado de la transaccion
				aperturaService.begin();
				DetPatrimonioBean detPatrimonioBean = new DetPatrimonioBean();
				detPatrimonioBean.setEntityManager(entityManager);

				detPatrimonioBean.actualizarSaldoIFA((String) UserSessionHolder.get("personaRevisada"));
				aperturaService.commit();
			} catch (Exception e) {
				log.error("Error al actualizar saldo deudor" + e.getMessage(), e);
			}

		} else if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0105)) {
			// eliminacion
			Apertura apertura = (Apertura) parametros.get("apertura");

			aperturaService.begin();
			Apertura aperturaOld = aperturaService.getAperturaLocal().findByCodReembolso(apertura.getInstitucion().getCodInst(),
					apertura.getIdentificador().getCodId(), apertura.getAnio(), apertura.getSecuencia(), apertura.getDav());

			if (aperturaOld == null) {
				throw new AladiException("REEMBOLSO_INEXISTENTE", new Object[] { apertura.getNroReembLiteral() });
			}

			List<Registro> registroList = registroService.getRegistroLocal().getByNroMovApeCveEstadoReg(aperturaOld.getNroMov(), null);
			for (Registro registro : registroList) {
				registroService.eliminar(registro, aperturaOld);
			}

			List<Pago> pagoList = pagoService.getPagoLocal().getByNroMovApeCveEstadoPago(aperturaOld.getNroMov(), null, false);
			for (Pago pago : pagoList) {
				pagoService.eliminar(pago, aperturaOld);
			}

			planPagosService.eliminar(aperturaOld);
			aperturaService.eliminar(aperturaOld);

			aperturaService.commit();

			log.info("Reembolso eliminado exit samente: " + apertura.getNroReembLiteral());
			statusCode = StatusCode.OPERACION_SUCCESS;
			consent = "Reembolso eliminado exit samente: " + apertura.getNroReembLiteral();
		} else if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0106)) {
			// anulacion de instrumento
			// la anulacion se realiza mediante la creaci n de un registro de
			// decremento pero que este es para fines contables en siraladi
			Apertura apertura = (Apertura) parametros.get("apertura");
			aperturaService.begin();
			Apertura aperturaOld = aperturaService.getAperturaLocal().findByCodReembolso(apertura.getInstitucion().getCodInst(),
					apertura.getIdentificador().getCodId(), apertura.getAnio(), apertura.getSecuencia(), apertura.getDav());

			if (aperturaOld == null) {
				throw new AladiException("REEMBOLSO_INEXISTENTE", new Object[] { apertura.getNroReembLiteral() });
			}
			Registro registroNew = registroService.registroDeAnulacion(aperturaOld);

			aperturaOld = aperturaService.anularInstrumento(aperturaOld);
			// registro a los WS en la central peru Peru E de Emision
			registroService.registroWSPorImporExport(registroNew, aperturaOld, "X");

			Object[] parameters = new Object[] { "Reembolso: "
					+ aperturaOld.getNroReembLiteral()
					+ "\nMonto: "
					+ registroNew.getDebeMo().add(registroNew.getHaberMo())};

			MsgLogic.envioMail(entityManager, "REGISOPERACION", (apertura.getCveTipoApe().trim().equals("I") ? aperturaOld.getInstitucion()
					.getCodInst() : registroNew.getInstitucion().getCodInst()), "Anulaci n instrumento autorizada", false, parameters);
			
			aperturaService.commit();

			log.info("Reembolso anulado exit samente: " + apertura.getNroReembLiteral());
			statusCode = StatusCode.OPERACION_SUCCESS;
			consent = "Reembolso anulado exit samente: " + apertura.getNroReembLiteral();
		} else if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0107)) {
			//modificacion solo de datos de apertura
			Apertura apertura = (Apertura) parametros.get("apertura");

			aperturaService.begin();

			Apertura aperturaNew = aperturaService.modificar(apertura);

			List<Registro> registroList = registroService.getRegistroLocal().getRegistroByTipoEmis(aperturaNew.getNroMov(), "E");
			if (registroList.size() == 0) {
				throw new AladiException("NO_EXISTE_EMIS", new Object[] { apertura.getNroReembLiteral() });
			}

			if (registroList.size() > 1) {
				throw new AladiException("NRO_EMIS_MAYOR_1", new Object[] { apertura.getNroReembLiteral() });
			}			
			// registro a los WS en la central peru Peru, se marca como modificacion
			registroService.registroWSPorImporExport(registroList.get(0), aperturaNew, "X");

			aperturaService.commit();
			
			response.addDescripcionParametro(codTipoOperacion, "apertura", "Custom", aperturaNew);
			response.addTaskDescripAdicional(aperturaService.getWarnnings());

			statusCode = StatusCode.OPERACION_SUCCESS;
			consent = "Operacion modificada existosamente nro Mov: " + aperturaNew.getNroMov();
		} else if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0108)) {
			//modificacion solo de datos de apertura sin envio de datos 
			Apertura apertura = (Apertura) parametros.get("apertura");

			aperturaService.begin();

			Apertura aperturaNew = aperturaService.modificaSinValidacion(apertura);

			List<Registro> registroList = registroService.getRegistroLocal().getRegistroByTipoEmis(aperturaNew.getNroMov(), "E");
			if (registroList.size() == 0) {
				throw new AladiException("NO_EXISTE_EMIS", new Object[] { apertura.getNroReembLiteral() });
			}

			if (registroList.size() > 1) {
				throw new AladiException("NRO_EMIS_MAYOR_1", new Object[] { apertura.getNroReembLiteral() });
			}			
			aperturaService.commit();
			
			response.addDescripcionParametro(codTipoOperacion, "apertura", "Custom", aperturaNew);
			response.addTaskDescripAdicional(aperturaService.getWarnnings());

			statusCode = StatusCode.OPERACION_SUCCESS;
			consent = "Operacion modificada existosamente nro Mov: " + aperturaNew.getNroMov();			
		} else {
			throw new AladiException("TIPO_DE_OPERACION_NO_IMPLEMENTADA", new Object[] { requestContext.getResponseContext().getOperacionAladi()
					.getCodTipoOperacion() });
		}
		response.updateReponse(statusCode, consent);
		log.info("Operacion realizada exitosamente operacion " + codTipoOperacion);
	}
}
