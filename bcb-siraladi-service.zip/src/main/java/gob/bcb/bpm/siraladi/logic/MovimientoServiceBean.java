package gob.bcb.bpm.siraladi.logic;

import gob.bcb.bpm.siraladi.dao.EntityUserTransaction;
import gob.bcb.bpm.siraladi.dao.MonedaBean;
import gob.bcb.bpm.siraladi.dao.MonedaLocal;
import gob.bcb.bpm.siraladi.dao.MovimientoBean;
import gob.bcb.bpm.siraladi.dao.MovimientoLocal;
import gob.bcb.bpm.siraladi.exceptions.AladiException;
import gob.bcb.bpm.siraladi.jpa.Moneda;
import gob.bcb.bpm.siraladi.jpa.Movimiento;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;



import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * @author wilherrera Wilbert Herrera Flores Banco Central de Bolivia
 *         Departamento de Desarrollo
 */

public class MovimientoServiceBean extends EntityUserTransaction implements MovimientoServiceLocal {
	private static Logger log = Logger.getLogger(MovimientoServiceBean.class);
	private MovimientoLocal movimientoLocal;

	private Map<String, Object> warnnings = new HashMap<String, Object>();

	public MovimientoServiceBean(EntityManager em) {
		super(em);
		movimientoLocal = new MovimientoBean();
		movimientoLocal.setEntityManager(em);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gob.bcb.bpm.siraladi.logic.MovimientoServiceLocal#crearMovimiento(java
	 * .lang.String, java.lang.String, java.util.Date)
	 */
	
	public Movimiento crearMovimiento(String cveTipoMov, String codMoneda, Date fechaMov, Integer nroMovApe) {
		log.info("crearMovimiento: inicio " + cveTipoMov + "; codMoneda: " + codMoneda + "; fechaMov: " + fechaMov);
		Movimiento movimientoMax = movimientoLocal.getMaxMovimiento();

		Integer nroMov = movimientoMax.getNroMov() + 1;

		Movimiento movimiento = new Movimiento();
		movimiento.setCveTipoMov(cveTipoMov);
		movimiento.setNroMov(nroMov);
		
		MonedaLocal monedaLocal = new MonedaBean();
		monedaLocal.setEntityManager(getEntityManager());		
		Moneda moneda = monedaLocal.findById(codMoneda, false);
		movimiento.setMoneda(moneda);
		movimiento.setFechaMov(fechaMov);
		
		movimiento.setNroSecReemb(0);
		if (cveTipoMov.equals("A")){
			movimiento.setNroSecReemb(0);			
		} else if (cveTipoMov.equals("R") || cveTipoMov.equals("P")){
			// se modifica el registro padre es decir la apertura a la que pertenece
			if (nroMovApe != null){
				Movimiento movimientoPadre = actualizarNroReembolso(nroMovApe);
				movimiento.setNroSecReemb(movimientoPadre.getNroSecReemb());
			}
		}

		movimiento = movimientoLocal.makePersistent(movimiento);
		movimientoLocal.flush();
		log.info("Nuevo nro operacion " + nroMov + " para " + cveTipoMov + "; codMoneda: " + codMoneda + "; fechaMov: " + fechaMov);		
		return movimiento;
	}
	
	public Movimiento actualizarRegAladi(Integer nroMov, String tipoOperAladi, Date horaRegaladi){
		Movimiento movimiento = movimientoLocal.getByNroMov(nroMov);
		if (movimiento == null){
			throw new AladiException("NRO_MOVIMIENTO_INEXISTENTE", new Object[] { nroMov });			
		}

		movimiento.setTipoOperAladi(tipoOperAladi);
		movimiento.setFechoraRegaladi(horaRegaladi);
		movimiento = movimientoLocal.makePersistent(movimiento);
		
		return movimiento;
	}

		
	public Movimiento actualizarNroReembolso(Integer nroMov){
		Movimiento movimiento = movimientoLocal.getByNroMov(nroMov);
		if (movimiento == null){
			throw new AladiException("NRO_MOVIMIENTO_INEXISTENTE", new Object[] { nroMov });			
		}

		Integer nroSecReemb = (movimiento.getNroSecReemb() == null ? 0 : movimiento.getNroSecReemb());
		movimiento.setNroSecReemb(nroSecReemb + 1);
		movimiento = movimientoLocal.makePersistent(movimiento);
		
		return movimiento;
	}

	
	
	public Map<String, Object> getWarnnings() {
		return warnnings;
	}

	
	public MovimientoLocal getMovimientoLocal() {
		return movimientoLocal;
	}
}
