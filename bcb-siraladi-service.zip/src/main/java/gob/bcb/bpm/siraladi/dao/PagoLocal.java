package gob.bcb.bpm.siraladi.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import gob.bcb.bpm.siraladi.jpa.Pago;




public interface PagoLocal extends DAO<Integer, Pago> {
	BigDecimal getMontoPago(Integer nroMovApe);

	/**
	 * Retorna los pagos por nro de mov de apertura
	 * @param nroMovApe
	 * @param cveEstadoPago estado del registro de pago si es nulo retorna todos los registros
	 * @param sinGastosYComisiones si es true agrega a la consulta codInstrumento  <> 'CG' sin gastos y comisiones 
	 * @return
	 */
	List<Pago> getByNroMovApeCveEstadoPago(Integer nroMovApe, String cveEstadoPago, boolean sinGastosYComisiones);
	
	BigDecimal getMontoSinNroMov(Integer nroMovApe, Integer nroMov);	
	/**
	 * Retorna la suma del debe - haber sin gastos y comision y el estado este contabilizado
	 * @param nroMov numero de apertura
	 * @param em
	 * @return saldo, si el nro de apertura no existe CERO
	 */
	BigDecimal getSaldoPago(Integer nroMovApe);
	/**
	 * Retorna el saldo contingente de pagos
	 * @param codPersona
	 * @param fechaCargo
	 * @param cveTipoApe
	 * @return
	 */
	BigDecimal getSaldoCont(String codPersona, Date fechaCargo, String cveTipoApe);

	Pago findByPagoImport(Integer nroMovApe, Integer nroDebito, String codInstrumento, BigDecimal monto, Integer nroSecReemb);
}
