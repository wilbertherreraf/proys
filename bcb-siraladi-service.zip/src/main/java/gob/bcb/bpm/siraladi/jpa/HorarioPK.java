package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the horario database table.
 * 
 */
@Embeddable
public class HorarioPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="cod_operacion")
	private String codOperacion;

	@Column(name="cod_horario")
	private String codHorario;

    public HorarioPK() {
    }
    
	public void setCodOperacion(String codOperacion) {
		this.codOperacion = codOperacion;
	}
	public String getCodOperacion() {
		return codOperacion;
	}
	
	public String getCodHorario() {
		return this.codHorario;
	}
	public void setCodHorario(String codHorario) {
		this.codHorario = codHorario;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof HorarioPK)) {
			return false;
		}
		HorarioPK castOther = (HorarioPK)other;
		return 
			this.codOperacion.equals(castOther.codOperacion)
			&& (this.codHorario == castOther.codHorario);

    }
    
	public int hashCode() {
		final Integer prime = 31;
		int hash = 17;
		hash = hash * prime + this.codOperacion.hashCode();
		hash = hash * prime + this.codHorario.hashCode();
		
		return hash;
    }

}