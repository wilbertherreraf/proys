
package gob.bcb.bpm.siraladi.ws.clientaladi.asicomrima;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Sicom" type="{BCRP}sdtSICOMRIMA"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "sicom"
})
@XmlRootElement(name = "sicom_rima_ws.ExecuteResponse")
public class SicomRimaWsExecuteResponse {

    @XmlElement(name = "Sicom", required = true)
    protected SdtSICOMRIMA sicom;

    /**
     * Gets the value of the sicom property.
     * 
     * @return
     *     possible object is
     *     {@link SdtSICOMRIMA }
     *     
     */
    public SdtSICOMRIMA getSicom() {
        return sicom;
    }

    /**
     * Sets the value of the sicom property.
     * 
     * @param value
     *     allowed object is
     *     {@link SdtSICOMRIMA }
     *     
     */
    public void setSicom(SdtSICOMRIMA value) {
        this.sicom = value;
    }

}
