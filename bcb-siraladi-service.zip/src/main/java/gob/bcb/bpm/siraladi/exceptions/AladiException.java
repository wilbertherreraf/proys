package gob.bcb.bpm.siraladi.exceptions;

import gob.bcb.bpm.siraladi.common.MsgManager;
import gob.bcb.bpm.siraladi.utils.StatusCode;

import java.util.ResourceBundle;
import org.apache.log4j.Logger;

import javax.xml.namespace.QName;

import org.w3c.dom.Element;

/**
 * @author wilherrera Wilbert Herrera Flores Banco Central de Bolivia
 *         Departamento de Desarrollo
 */
public class AladiException extends UncheckedException {
	private static final long serialVersionUID = 397003471340404805L;
	private String message;

	public static final ResourceBundle BUNDLE;
	static {
		ResourceBundle bundle = null;
		try {
			bundle = ResourceBundle.getBundle("messagessiraladi");
			BUNDLE = bundle;
		} catch (Exception e) {
			throw new RuntimeException("No se pudo cargar archivo de mensajes 'messagessiraladi'");
		}
	}

	/**
	 * Constructor
	 * 
	 * @param message
	 *            Mensaje de la excepcion
	 * @param ex
	 *            La excpecion como tal
	 */
	public AladiException(String msg, Throwable t) {
		this(msg, BUNDLE, t);
	}

	/**
	 * Constructor
	 * 
	 * @param message
	 *            Mensaje para crear la nueva excepcion
	 */

	public AladiException(String message) {
		// this(new MsgManager(message, BUNDLE));
		// whf ojooo eliminar cuando todas las excepciones esten codificadas
		// mensaje personalizado si el codigo no existe en la configuracion lo
		// setea a
		this(BUNDLE.containsKey(message) ? (new MsgManager(message, BUNDLE)) : (new MsgManager(StatusCode.ALADI_EXCEPTION, BUNDLE,
				new Object[] { message })));
	}

	public AladiException(String message, Object... params) {
		this(new MsgManager(message, BUNDLE, params));
	}

	public AladiException(MsgManager message, Throwable throwable) {
		super(message, throwable);
		this.message = message.toString();
		// code = FAULT_CODE_SERVER;
	}

	public AladiException(MsgManager message) {
		super(message);
		this.message = message.toString();
		// code = FAULT_CODE_SERVER;
	}

	public AladiException(String message, Logger log) {
		this(new MsgManager(message, log));
	}

	public AladiException(String message, ResourceBundle b) {
		this(new MsgManager(message, b));
	}

	public AladiException(String message, Logger log, Throwable t) {
		this(new MsgManager(message, log), t);
	}

	public AladiException(String message, ResourceBundle b, Throwable t) {
		this(new MsgManager(message, b), t);
	}

	public AladiException(String message, Logger log, Throwable t, Object... params) {
		this(new MsgManager(message, log, params), t);
	}

	public AladiException(String message, ResourceBundle b, Throwable t, Object... params) {
		this(new MsgManager(message, b, params), t);
	}

	public AladiException(Throwable t) {
		super(t);
        if (super.getMessage() != null) {
            message = super.getMessage();
		} else {
			message = t == null ? null : t.getMessage();
		}
		// code = FAULT_CODE_SERVER;
	}

	public AladiException(MsgManager message, Throwable throwable, QName fc) {
		super(message, throwable);
		this.message = message.toString();
		// code = fc;
	}

	public AladiException(MsgManager message, QName fc) {
		super(message);
		this.message = message.toString();
		// code = fc;
	}

	public AladiException(Throwable t, QName fc) {
		super(t);
		if (super.getMessage() != null) {
			message = super.getMessage();
		} else {
			message = t == null ? null : t.getMessage();
		}
		// code = fc;
	}

	public String getMsgManager() {
		return message;
	}

	public void setMsgManager(String message) {
		this.message = message;
	}

	/*
	 * public QName getFaultCode() { return code; }
	 */

	public AladiException setFaultCode(QName c) {
		// code = c;
		return this;
	}

	public static String getDescription(String message, Object... params){
		return new MsgManager(message, BUNDLE, params).toString();
	}
}
