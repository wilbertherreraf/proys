package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.PerTipoCuenta;
import gob.bcb.bpm.siraladi.jpa.PerTipoCuentaPK;

public interface PerTipoCuentaLocal extends DAO<PerTipoCuentaPK, PerTipoCuenta> {
	/**
	 * Retorna el objeto persona tipo cuenta, tabla de relacion entre cuentas y personas
	 * @param cveTipoApe tipo de apertura importacion o exportacion (I,E)
	 * @param codInst codigo de institucion si es importacion este debe ser el valor de codinst de la apertura, si es exportacion
	 * este debe ser el codInstRecep de registro
	 * @param codId codigo de identificador
	 * @param codMoneda codigo de moneda
	 * @return si el registro no encuentra retorna nulo
	 */
	public PerTipoCuenta getPerTipoCuenta(String cveTipoApe, String codInst, String codId, String codMoneda);
}
