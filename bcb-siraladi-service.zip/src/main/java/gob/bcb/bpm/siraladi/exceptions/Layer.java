package gob.bcb.bpm.siraladi.exceptions;

/**
 * Feasible layers to use when throwing unrecoverable exceptions
 * @author wherrera
 */
public class Layer {
    
	public static final String VERSION = "$Id: Layer.java 1 2011-07-30 13:37:36Z wherrera $";
    public static final Layer CLIENT = new Layer("CLIENT");
    public static final Layer BUSINESS = new Layer("BUSINESS");
    public static final Layer DATAACCESS = new Layer("RESOURCE");
    public static final Layer UNDEFINED = new Layer("UNDEFINED");
    public static final Layer FRAMEWORK = new Layer("FRAMEWORK");
    public static final Layer CLIENTWS = new Layer("CLIENTWS");    
    private String value;

    /**
     * Create a new layer
     * @param value The value of the layer
     */
    private Layer(String value) {
        this.value = value;
    }

    /**
     * 
     * @return The value of the layer
     */
    public String getValue() {
        return value;
    }

    /**
     * {@inheritDoc Object#toString()}
     */
    
	public String toString() {
        return value;
    }

    /**
	 * @see Object#equals(Object)
	 */
    public boolean equals(Layer layer) {
        return value.equals(layer.value);
    }

    /**
     * {@inheritDoc Object#hashCode()}
     */
    
	public int hashCode() {
        return getValue().hashCode();
    }

    /**
     * {@inheritDoc Object#equals(Object)}
     */
    
	public boolean equals(Object obj) {
        if(!(obj instanceof Layer)) {
            return false;
        } else {
            return ((getValue() != null) && (getValue().equals(((Layer)obj).getValue())));
        }
    }
}
