package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;
import javax.persistence.Id;
import javax.persistence.ManyToOne;


/**
 * The persistent class for the mov_coin database table.
 * 
 */
@Entity
@Table(name="mov_coin")
public class MovCoin implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@EmbeddedId
	private MovCoinPK id;

	@Column(name="cve_tipo_comprob")
	private String cveTipoComprob;

	@Column(name="nro_comprob")
	private String nroComprob;

	@Column(name="nro_comprob_rev")
	private String nroComprobRev;

	//bi-directional many-to-one association to Movimiento
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="nro_mov", nullable=false, insertable=false, updatable=false)
	private Movimiento movimiento;

    public MovCoin() {
    }

	public MovCoinPK getId() {
		return this.id;
	}

	public void setId(MovCoinPK id) {
		this.id = id;
	}
	
	public String getCveTipoComprob() {
		return this.cveTipoComprob;
	}

	public void setCveTipoComprob(String cveTipoComprob) {
		this.cveTipoComprob = cveTipoComprob;
	}

	public String getNroComprob() {
		return this.nroComprob;
	}

	public void setNroComprob(String nroComprob) {
		this.nroComprob = nroComprob;
	}

	public String getNroComprobRev() {
		return this.nroComprobRev;
	}

	public void setNroComprobRev(String nroComprobRev) {
		this.nroComprobRev = nroComprobRev;
	}

	public Movimiento getMovimiento() {
		return this.movimiento;
	}

	public void setMovimiento(Movimiento movimiento) {
		this.movimiento = movimiento;
	}
	
}
