package gob.bcb.bpm.siraladi.exceptions;

/**
 * Exception that is not expected to be recoverable.
 * @author wherrera
 */
public abstract class UnrecoverableException extends RuntimeException  {

	private static final long serialVersionUID = 8184459972073800325L;
	public static final String VERSION = "$Id: UnrecoverableException.java 1 2011-07-30 13:37:36Z wherrera $";
    private ErrorCodes.ErrorCode errorCode;
    private Layer layer;

    /**
     * Create an unrecoverable exception
     * @param errorCode The {@link ErrorCodes} to associate with the exception
     * @param layer The {@link Layer} to associate with the exception
     * @param internalMessage An additional message
     * @param cause The original exception
     */
    public UnrecoverableException(ErrorCodes.ErrorCode errorCode, Layer layer, String internalMessage, Throwable cause) {
        super(internalMessage, cause);
        this.errorCode = errorCode;
        this.layer = layer;
    }

    /**
     * @see #UnrecoverableException(ErrorCodes.ErrorCode, Layer, String, Throwable)
     */
    public UnrecoverableException(ErrorCodes.ErrorCode errorCode, Layer layer, String internalMessage) {
        this(errorCode, layer, internalMessage,  null);
    }

    /**
     * 
     * @return The {@link ErrorCodes.ErrorCode} associated with the exception
     */
    public ErrorCodes.ErrorCode getErrorCode() {
        return errorCode;
    }

    /**
     * 
     * @return The {@link Layer} associated with the exception
     */
    public Layer getLayer() {
        return layer;
    }
}
