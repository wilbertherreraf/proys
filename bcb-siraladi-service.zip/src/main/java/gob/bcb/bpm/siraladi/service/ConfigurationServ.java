package gob.bcb.bpm.siraladi.service;

import gob.bcb.bpm.siraladi.pojo.OperacionAladi;

import gob.bcb.bpm.siraladi.utils.Constants;
import gob.bcb.bpm.siraladi.ws.clientaladi.ClientAladiTLS;

import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;
import javax.net.ssl.X509TrustManager;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.XMLConfiguration;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;

/**
 * @author wilherrera Wilbert Herrera Flores Banco Central de Bolivia
 *         Departamento de Desarrollo
 */
public class ConfigurationServ {
	private static String serviceName;
	private static Logger log = Logger.getLogger(ConfigurationServ.class);
	private static String name = "bcb-service-siraladi.xml";
	private static String home;
	private static Map<String, ClassHandlerTOper> keysMap = new ConcurrentHashMap<String, ClassHandlerTOper>();
	private static Map<String, String> paramsSystem = new ConcurrentHashMap<String, String>();
	private static XMLConfiguration config;
	private static boolean configInitialized = false;

	public static ClassHandlerTOper getClassHandler(String property) {
		return keysMap.get(property);
	}

	public static Iterator<?> getKeys() {
		return keysMap.keySet().iterator();
	}

	/**
	 * Inicializa el mapa de la relacion de clase handler y tipos de operaciones
	 * que implementa en el servicio aladi
	 */
	private static void initValsClassHandler() {
		List<ClassHandlerTOper> classHandlerTOperList = new ArrayList<ClassHandlerTOper>();

		List<OperacionAladi> operacionAladiList = new ArrayList<OperacionAladi>();

		operacionAladiList.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0101, "Emision de instrumento"));
		operacionAladiList.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0102, "Modificacion-Autorizaci�n de un apaertura"));
		operacionAladiList.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0103, "Consulta de instrumento"));
		operacionAladiList.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0104, "Consulta de un apaertura"));
		operacionAladiList.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0105, "Eliminaci�n de instrumento pendiente"));
		operacionAladiList.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0106, "Anulaci�n de instrumento"));
		operacionAladiList.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0107, "modificacion de solo apertura"));
		operacionAladiList.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0108, "modificacion de solo apertura sin envio de datos"));
		classHandlerTOperList.add(new ClassHandlerTOper("Apertura", "gob.bcb.bpm.siraladi.service.AperturaServiceHandler", operacionAladiList));

		List<OperacionAladi> operacionAladiList2 = new ArrayList<OperacionAladi>();
		operacionAladiList2.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0201, "Creacion de un apaertura"));
		operacionAladiList2.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0202, "Modificacion de un apaertura"));
		operacionAladiList2.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0203, "Consulta de un apaertura"));
		operacionAladiList2.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0204, "Consulta de un apaertura"));
		operacionAladiList2.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0205, "Elimina de un apaertura"));
		classHandlerTOperList.add(new ClassHandlerTOper("Registro", "gob.bcb.bpm.siraladi.service.RegistroServiceHandler", operacionAladiList2));

		List<OperacionAladi> operacionAladiList3 = new ArrayList<OperacionAladi>();
		operacionAladiList3.clear();
		operacionAladiList3.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0301, "Creacion de un apaertura"));
		operacionAladiList3.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0302, "Modificacion de un apaertura"));
		operacionAladiList3.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0303, "Consulta de un apaertura"));
		operacionAladiList3.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0304, "Creacion de un apaertura"));
		operacionAladiList3.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0305, "Modificacion de un apaertura"));
		operacionAladiList3.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0306, "Consulta de un apaertura"));
		operacionAladiList3.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0307, "Consulta de un apaertura"));
		operacionAladiList3.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0308, "Consulta de un apaertura"));
		operacionAladiList3.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0309, "elimina un pago"));
		operacionAladiList3.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0310, "elimina un t_pago_imp"));
		classHandlerTOperList.add(new ClassHandlerTOper("Pago", "gob.bcb.bpm.siraladi.service.PagoServiceHandler", operacionAladiList3));

		List<OperacionAladi> operacionAladiList4 = new ArrayList<OperacionAladi>();
		operacionAladiList4.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0401, "Creacion de un apaertura"));
		operacionAladiList4.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0402, "Modificacion de un apaertura"));
		operacionAladiList4.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0403, "Consulta de saldos de convenio"));
		operacionAladiList4.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0404, "Consulta de saldos de convenio"));
		operacionAladiList4.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0405, "Eliminar anticipado"));
		operacionAladiList4.add(new OperacionAladi("SWF_PREAUTO", "Preautorizar swift"));		
		classHandlerTOperList.add(new ClassHandlerTOper("RegAnticipado", "gob.bcb.bpm.siraladi.service.RegAnticipadoServiceHandler",
				operacionAladiList4));

		List<OperacionAladi> operacionAladiList5 = new ArrayList<OperacionAladi>();
		operacionAladiList5.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0501, ""));
		operacionAladiList5.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0502, "Modificacion de un apaertura"));
		operacionAladiList5.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0503, "Consulta de un apaertura"));
		operacionAladiList5.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0504, "modificacion de plan de pagos"));
		operacionAladiList5.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0505, "Consulta de un apaertura"));
		classHandlerTOperList.add(new ClassHandlerTOper("PlanPagos", "gob.bcb.bpm.siraladi.service.PlanPagosServiceHandler", operacionAladiList5));

		List<OperacionAladi> operacionAladiList6 = new ArrayList<OperacionAladi>();
		operacionAladiList6.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0601, "Consultas de instituciones en ALADI"));
		operacionAladiList6.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0602, "Modificacion de un apaertura"));
		operacionAladiList6.add(new OperacionAladi(Constants.TIPO_OPERACION_AL0603, "Consulta de un apaertura"));
		classHandlerTOperList.add(new ClassHandlerTOper("Consultas", "gob.bcb.bpm.siraladi.service.ConsultasServiceHandler", operacionAladiList6));

		// llenamos el mapa de clases solo con las clases que implementan
		for (ClassHandlerTOper classHandlerTOper : classHandlerTOperList) {
			keysMap.put(classHandlerTOper.getCodClassHandler(), classHandlerTOper);
		}
		log.info("Objetos Handlers de clases sobre operaciones ... hecho");
	}

	public static void init(String home) {
		if (isConfigured()) {
			if (!configInitialized) {
				log.info("Inicializando objetos de configuraciï¿½n ConfigurationServ");
				initValsClassHandler();
				try {
					config = new XMLConfiguration(new File(ConfigurationServ.getConfigurationHome() + "/" + name));
				} catch (ConfigurationException e) {
					e.printStackTrace();
					throw new RuntimeException(e);
				}

				log.info("Seteo de propiedades de sistema para acceso a Web Services PERU");
				String trustStore = (String) ConfigurationServ.getConfigProperty(Constants.PROP_TRUSTSTORE_LOCATION, "string");

				if (trustStore == null) {
					throw new RuntimeException("Variable TRUSTSTORE_LOCATION nulo");
				}
				log.info("Archivo trustStore: " + trustStore);
				// Location of the Java keystore file containing an application
				// process's own certificate and private key.
				
				System.setProperty("javax.net.ssl.trustStore", trustStore);

				String trustStorePassword = (String) ConfigurationServ.getConfigProperty(Constants.PROP_TRUSTSTORE_PASSWORD, "string");
				if (trustStorePassword == null) {
					throw new RuntimeException("Variable TRUSTSTORE_PASSWORD nulo");
				}
				// javax.net.ssl.trustStorePassword - Password to unlock the
				// keystore file (store password) specified by
				// javax.net.ssl.trustStore.
				
				System.setProperty("javax.net.ssl.trustStorePassword", trustStorePassword);

				String keyStore = (String) ConfigurationServ.getConfigProperty(Constants.PROP_KEYSTORE_LOCATION, "string");
				if (keyStore == null) {
					throw new RuntimeException("Variable KEYSTORE_LOCATION nulo");
				}
				log.info("Archivo keyStore: " + keyStore);
				
				//System.setProperty("javax.net.ssl.keyStore", keyStore);

				String keyStorePassword = (String) ConfigurationServ.getConfigProperty(Constants.PROP_KEYSTORE_PASSWORD, "string");
				if (keyStorePassword == null) {
					throw new RuntimeException("Variable KEYSTORE_PASSWORD nulo");
				}
				// javax.net.ssl.keyStorePassword: Password to access the
				// private key from the keystore file specified by
				// javax.net.ssl.keyStore. This password is used twice:
				// To unlock the keystore file (store password), and
				// To decrypt the private key stored in the keystore (key
				// password).
				// In other words, the JSSE framework requires these passwords
				// to be identical.				
				//System.setProperty("javax.net.ssl.keyStorePassword", keyStorePassword);

				ConfigurationServ.setParamsSystem("ALADI_WS_USER",
						((String) ConfigurationServ.getConfigProperty(Constants.ALADI_WS_USER, "string")).trim());
				ConfigurationServ.setParamsSystem("ALADI_WS_PASSWORD",
						((String) ConfigurationServ.getConfigProperty(Constants.ALADI_WS_PASSWORD, "string")).trim());

				try {
					ClientAladiTLS.createInstance(trustStore, trustStorePassword, keyStore, keyStorePassword,
							keyStorePassword);
					
				} catch (Exception e) {
					throw new RuntimeException(e);
				}

				log.info("Seteo de propiedades de sistema para acceso a Web Services PERU ... hecho");
				configInitialized = true;
				log.info("Inicializando objetos de configuraciï¿½n ConfigurationServ ... hecho");
			}
		} else {
			throw new RuntimeException(
					"Error al iniciar la Configuracion del sistema, no fue seteado variables home o name del archivo de configuracion");
		}
	}

	public static boolean isConfigured() {
		if (home == null)
			return false;
		log.info("Config filename: " + name);
		File config = new File(home, name);
		return config.exists();
	}

	public static void setHomeProperty(String home) {
		if (home == null) {
			home = System.getProperty("user.home") + "/.aladiprops";
		}

		File h = new File(home);
		if (h.exists() && !h.isDirectory()) {
			throw new IllegalStateException(home + " no es un directorio");
		} else if (!h.exists()) {
			log.info("Creando un directorio vacio " + home);
			try {
				FileUtils.forceMkdir(h);
			} catch (IOException e) {
				throw new IllegalStateException(h + " no puede ser creado");
			}
		}
		log.info("Configuration.home seteado a " + home);
		ConfigurationServ.home = home;
	}

	public static String getConfigurationHome() {
		return home;
	}

	public static XMLConfiguration getConfig() {
		return config;
	}

	public static Object getConfigProperty(String expXpath, String typeValRet) {
		Object propResult = null;

		Document document = getConfig().getDocument();
		try {
			XPathFactory xFactory = XPathFactory.newInstance();
			XPath xpath = xFactory.newXPath();
			XPathExpression exp = null;

			exp = xpath.compile(expXpath);

			if (typeValRet.equalsIgnoreCase("STRING")) {
				propResult = exp.evaluate(document, XPathConstants.STRING);
			} else if (typeValRet.equalsIgnoreCase("NUMBER")) {
				propResult = exp.evaluate(document, XPathConstants.NUMBER);
			} else if (typeValRet.equalsIgnoreCase("NODE")) {
				propResult = exp.evaluate(document, XPathConstants.NODE);
			} else if (typeValRet.equalsIgnoreCase("DOM")) {
				propResult = exp.evaluate(document);
			}

		} catch (XPathExpressionException e) {
			document = null;
			throw new RuntimeException(e);
		} catch (Exception e) {
			document = null;
			throw new RuntimeException(e);
		}
		document = null;
		return propResult;
	}

	public boolean isConfigInitialized() {
		return configInitialized;
	}

	public static ClassHandlerTOper findHandlerByCodTipoOper(String codTipoOperacion) {
		for (Iterator<?> i = ConfigurationServ.getKeys(); i.hasNext();) {
			String key = (String) i.next();
			// if (!key.startsWith("bcb.gob.siraladi.service.")) continue;
			ClassHandlerTOper classHandlerTOper = ConfigurationServ.getClassHandler(key);
			List<OperacionAladi> operacionAladiList = classHandlerTOper.getOperacionAladi();
			for (OperacionAladi operacionAladi : operacionAladiList) {
				if (operacionAladi.getCodTipoOperacion().equalsIgnoreCase(codTipoOperacion)) {
					return classHandlerTOper;
				}
			}
		}
		return null;
	}

	public static void setServiceName(String serviceName) {
		ConfigurationServ.serviceName = serviceName;
	}

	public static String getServiceName() {
		return serviceName;
	}

	public static void setParamsSystem(String key, String value) {
		if (ConfigurationServ.paramsSystem == null)
			ConfigurationServ.paramsSystem = new ConcurrentHashMap<String, String>();
		getParamsSystem().put(key, value);
	}

	public static Map<String, String> getParamsSystem() {
		return paramsSystem;
	}

	public static void main1(String[] args) throws IOException {
		URL url = new URL("https://sicap1.bcrp.gob.pe/servlet/asicap_ccb_ws?wsdl");

		URLConnection conn = url.openConnection();
		log.info("11111111111111111111111111");
		if (conn instanceof HttpsURLConnection) {

			HttpsURLConnection conn1 = (HttpsURLConnection) url.openConnection();

			conn1.setHostnameVerifier(new HostnameVerifier() {
				public boolean verify(String hostname, SSLSession session) {
					return true;
				}
			});

		}

		// ConfigurationServ configurationServ = new ConfigurationServ();
		// ConfigurationServ.setHomeProperty("e:/siraladi");
		// ConfigurationServ.init("e:/siraladi");
		//
		// System.out.println(ConfigurationServ.findHandlerByCodTipoOper("AL0501"));
		//
		// String exp1 =
		// Constants.PROP_DB_HANDLER_FACTORY.replaceFirst("ID-DATABASE",
		// "coid");
		// System.out.println(exp1);
		// XPathFactory xFactory = XPathFactory.newInstance();
		// XPath xpath = xFactory.newXPath();
		// XPathExpression exp = null;
		// try {
		// exp =
		// xpath.compile("repositorio/configdb/database[@id='aladi']/jdbcurl");
		// } catch (XPathExpressionException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		// Document document = ConfigurationServ.getConfig().getDocument();
		// try {
		// String elemPasaporte = (String) exp.evaluate(document,
		// XPathConstants.STRING);
		// System.out.println("elemPasaporte " + elemPasaporte);
		// } catch (XPathExpressionException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		//
		// String elemPasaporte = (String)
		// ConfigurationServ.getConfigProperty(Constants.PROP_DB_HANDLER_FACTORY.replaceFirst("ID-DATABASE",
		// "coin"),
		// "string");
		// System.out.println("asd " + elemPasaporte);
		// elemPasaporte = (String)
		// ConfigurationServ.getConfigProperty(Constants.PROP_TRUSTSTORE_LOCATION,
		// "string");
		// System.out.println(elemPasaporte);

	}

	public static void main() throws Exception {
		System.out.println("11111111111111111111111");
		URL url = new URL("https://sicap1.bcrp.gob.pe/servlet/asicap_ccb_ws?wsdl");
		HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
		System.out.println("222222222222");
		httpURLConnection.setRequestMethod("POST");
		httpURLConnection.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
		httpURLConnection.setDoOutput(true);
		DataOutputStream wr = new DataOutputStream(httpURLConnection.getOutputStream());
		System.out.println("333333");
		String serializedMessage = "{}";
		wr.writeBytes(serializedMessage);
		System.out.println("5555555555555");
		wr.flush();
		wr.close();

		int responseCode = httpURLConnection.getResponseCode();
		System.out.println(responseCode);
		System.out.println("666666666666");
	}

	private static class DefaultTrustManager implements X509TrustManager {

		public void checkClientTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
		}

		public void checkServerTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
		}

		public X509Certificate[] getAcceptedIssuers() {
			return null;
		}
	}
}
