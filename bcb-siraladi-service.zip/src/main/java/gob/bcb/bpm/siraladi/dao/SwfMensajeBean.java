package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Param;
import gob.bcb.bpm.siraladi.jpa.SwfDetmensaje;
import gob.bcb.bpm.siraladi.jpa.SwfMensaje;
import gob.bcb.bpm.siraladi.jpa.SwfMttransfer;
import gob.bcb.bpm.siraladi.service.ClienteLvdSir;
import gob.bcb.bpm.siraladi.utils.Constants;
import gob.bcb.core.utils.UtilsFile;
import gob.bcb.swift.exception.SwiftAdminException;
import gob.bcb.swift.pojos.SwiftDatos;
import gob.bcb.swift.pojos.SwiftMessageBcb;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.persistence.Query;
import javax.persistence.TemporalType;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("swfMensajeLocal")
@Transactional
public class SwfMensajeBean extends GenericDAO<Integer, SwfMensaje> implements SwfMensajeLocal {
	private static Logger log = Logger.getLogger(SwfMensajeBean.class);

	private SwfDetmensajeLocal swfDetmensajeLocal;
	@Autowired
	private ParamsLocal paramsLocal;
	
	public SwfMensaje findByCodigo(Integer menCodmen) {
		String jpql = "SELECT t FROM SwfMensaje t WHERE t.menCodmen = :menCodmen ";

		Query query = getEntityManager().createQuery(jpql);

		query.setParameter("menCodmen", menCodmen);
		List lista = query.getResultList();
		if (lista.size() > 0) {
			return (SwfMensaje) lista.get(0);
		}
		return null;
	}

	public List<SwfMensaje> findByEstMen(String menCveestswift) {
		String jpql = "SELECT t FROM SwfMensaje t ";
		jpql = jpql.concat("WHERE t.menCveestswift = :menCveestswift ");

		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("menCveestswift", menCveestswift);
		List lista = query.getResultList();
		return lista;
	}

	public List<SwfMensaje> findOperaciones(String menCodoperacion, String menCveestswift) {
		String jpql = "SELECT t FROM SwfMensaje t ";
		jpql = jpql.concat("WHERE t.menCodoperacion = :menCodoperacion ");

		if (!StringUtils.isBlank(menCveestswift)) {
			jpql = jpql.concat("AND t.menCveestswift = :menCveestswift ");
		} else {
			// si es nulo es el estado (A,P)
			jpql = jpql.concat("AND t.menCveestswift in ('P','1','A') ");
		}

		Query query = getEntityManager().createQuery(jpql);

		query.setParameter("menCodoperacion", menCodoperacion);

		if (!StringUtils.isBlank(menCveestswift)) {
			query.setParameter("menCveestswift", menCveestswift);
		}

		List lista = query.getResultList();
		return lista;
	}

	public SwfMensaje findByCodoperacion(String menCodoperacion, String menCveestswift) {
		String jpql = "SELECT t FROM SwfMensaje t ";
		jpql = jpql.concat("WHERE t.menCodoperacion = :menCodoperacion ");

		if (!StringUtils.isBlank(menCveestswift)) {
			jpql = jpql.concat("AND t.menCveestswift = :menCveestswift ");
		} else {
			// si es nulo es el estado (A,P)
			jpql = jpql.concat("AND t.menCveestswift in ('P','1','A') ");
		}

		Query query = getEntityManager().createQuery(jpql);

		query.setParameter("menCodoperacion", menCodoperacion);

		if (!StringUtils.isBlank(menCveestswift)) {
			query.setParameter("menCveestswift", menCveestswift);
		}

		List lista = query.getResultList();
		if (lista.size() == 1) {
			return (SwfMensaje) lista.get(0);
		}
		return null;
	}

	private SwfMensaje nuevoMensaje(SwfMensaje swfMensaje) {
		log.info("En  nuevoMensaje SwfMensaje " + swfMensaje.toString());

		validarEstado(swfMensaje);

		Integer perCodigo = getCodigo();
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(new Date());

		swfMensaje.setMenCveestswift(Constants.PAR_ESTSWIFT_PEND);
		swfMensaje.setMenCodmen(perCodigo);
		swfMensaje.setMenFecreg(new Date());
		swfMensaje.setMenGestion(calendar.get(Calendar.YEAR));

		validarDatos(swfMensaje);

		persist(swfMensaje);
		// entityManager.persist(swfMensaje);
		SwfMensaje swfMensajeNew = findByCodigo(perCodigo);
		log.info("XXX:nuevo " + swfMensajeNew.getMenCodmen());
		// swfMensaje = findByCodigo(swfMensaje.getMenCodmen());

		return swfMensajeNew;
	}

	private SwfMensaje updateMensaje(SwfMensaje swfMensaje) {
		log.info("En  updateMensaje SwfMensaje " + swfMensaje.getMenCodoperacion() + " - " + swfMensaje.getMenCodmen());

		makePersistent(swfMensaje);

		log.info("actualizado mensaje " + swfMensaje.toString());

		swfMensaje = findByCodigo(swfMensaje.getMenCodmen());

		return swfMensaje;
	}

	public SwfMensaje saveorupdate(SwfMensaje swfMensaje) {
		log.info("En  saveorupdate SwfMensaje " + swfMensaje.toString());

		// SwfMensaje swfMensajeOld =
		// findByCodoperacion(swfMensaje.getMenCodoperacion(),
		// Constants.PAR_ESTSWIFT_AUTO);
		SwfMensaje swfMensajeOld = findByCodigo(swfMensaje.getMenCodmen());

		if (swfMensajeOld == null) {
			swfMensaje = nuevoMensaje(swfMensaje);
		} else {
			validarDatos(swfMensaje);
			validarEstado(swfMensajeOld);
			swfMensaje = updateMensaje(swfMensaje);
		}
		log.info("Actualizado " + swfMensaje.getMenCodmen());
		return swfMensaje;
	}

	public SwfMensaje actualizarSwift(SwfMensaje swfMensaje, List<SwfDetmensaje> swfDetmensajeList) {
		log.info("En actualizarSwift SwfMensaje " + swfMensaje.getMenCodoperacion() + " " + swfMensaje.toString() + " " + swfDetmensajeList.size());
		SwfMensaje swfMensajeNew = saveorupdate(swfMensaje);

		log.info("XXX:En actualizarSwift SwfMensaje " + swfMensajeNew.getMenCodoperacion() + " " + swfMensajeNew.getMenCodmen());

		swfDetmensajeLocal = new SwfDetmensajeBean();
		swfDetmensajeLocal.setEntityManager(getEntityManager());

		swfDetmensajeLocal.actualizarDetalles(swfMensajeNew, swfDetmensajeList);

		log.info("XXX:222En actualizarSwift SwfMensaje " + swfMensajeNew.getMenCodoperacion() + " " + swfMensajeNew.getMenCodmen());
		return swfMensajeNew;
	}

	public SwiftDatos swiftDatosFromSwfMensaje(SwfMensaje swfMensajePar) {
		log.info("En swiftDatosFromSwfMensaje " + swfMensajePar.getMenCodmen());

		SwfMensaje swfMensaje = findByCodigo(swfMensajePar.getMenCodmen());
		if (swfMensaje == null) {
			throw new SwiftAdminException("Swift: mensaje  " + swfMensajePar.getMenCodmen() + " inexistente");
		}
		SwiftDatos swiftDatos = new SwiftDatos();

		swiftDatos.setSwfMensaje(swfMensaje);

		InstitucionLocal institucionLocal = new InstitucionBean();
		institucionLocal.setEntityManager(getEntityManager());

		SwfMttransferLocal swfMttransferLocal = new SwfMttransferBean();
		swfMttransferLocal.setEntityManager(getEntityManager());
		SwfMttransfer swfMttransfer = swfMttransferLocal.findByCodigo(swfMensaje.getMenCodmt());

		swiftDatos.setSwfMttransfer(swfMttransfer);

		Institucion institucionSender = institucionLocal.findByBIC(swfMensaje.getMenBicemisor(), null);
		if (institucionSender == null) {
			throw new SwiftAdminException("Swift: Error de parametrización institucion emisora BIC " + swfMensaje.getMenBicemisor() + " inexistente");
		}

		swiftDatos.newSwfBicsSender(institucionSender.getBic(), "", institucionSender.getNomInst(), null, institucionSender.getNomPlaza(),
				institucionSender.getPais().getNomPais());

		Institucion institucionReceiver = institucionLocal.findByBIC(swfMensaje.getMenBic(), null);
		if (institucionReceiver == null) {
			throw new SwiftAdminException("Swift: Error de parametrización institucion receptora BIC " + institucionSender.getCodInst() + " inexistente");
		}

		swiftDatos.newSwfBicsReceiver(institucionReceiver.getBic(), "", institucionReceiver.getNomInst(), null, institucionReceiver.getNomPlaza(),
				institucionReceiver.getPais().getNomPais());

		return swiftDatos;
	}

	public SwfMensaje autorizarSwift(SwfMensaje swfMensajePar, String pathSwift) {
		log.info("En autorizarSwift " + swfMensajePar.getMenCodmen());

		// SwfMensaje swfMensaje =
		// findByCodoperacion(swfMensajePar.getMenCodoperacion(),
		// Constants.PAR_ESTSWIFT_PEND);
		if (StringUtils.isBlank(pathSwift)) {
			throw new SwiftAdminException("Parametro de ruta de mensajes swift nulo, avise a sistemas");
		}

		SwfMensaje swfMensaje = findByCodigo(swfMensajePar.getMenCodmen());
		if (swfMensaje == null) {
			throw new SwiftAdminException("Swift: mensaje  " + swfMensajePar.getMenCodmen() + " inexistente");
		}

		validarDatos(swfMensaje);

		if (!swfMensaje.getMenCveestswift().equals(Constants.PAR_ESTSWIFT_PEND)) {
			throw new SwiftAdminException("Swift: mensaje  " + swfMensajePar.getMenCodmen() + " con estado " + swfMensaje.getMenCveestswift() + " invalido");
		}
		validarEstado(swfMensaje);

		if (swfMensaje.getMenNrocorr() == null || swfMensaje.getMenNrocorr().compareTo(0) <= 0) {
			throw new SwiftAdminException("Error al autorizar mensaje " + swfMensaje.getMenCodmen() + " sin nro swift asignado ");
		}

		if (StringUtils.isBlank(swfMensaje.getMenPlano())) {
			throw new SwiftAdminException(
					"Error al autorizar mensaje " + swfMensaje.getMenCodmen() + " texto del mensaje swift nulo, actualice o verifique la operación");
		}

		log.info("Autorizando swift Codmen:" + swfMensaje.getMenCodmen() + " Codoperacion:" + swfMensaje.getMenCodoperacion() + " Codmt:"
				+ swfMensaje.getMenCodmt() + " Nrocorr:" + swfMensaje.getMenNrocorr());
		log.info(swfMensaje.getMenPlano());

		SwiftMessageBcb swiftMessageBcbEval = new SwiftMessageBcb();
		swiftMessageBcbEval.verificarPlano(swfMensaje.getMenPlano());

		swfMensaje.setMenCveestswift(Constants.PAR_ESTSWIFT_AUTO);
		swfMensaje.setMenFecauto(new Date());

		swfMensaje.setMenAuditusr(swfMensajePar.getMenAuditusr());
		swfMensaje.setMenAuditwst(swfMensajePar.getMenAuditwst());

		makePersistent(swfMensaje);

		flush();

		swfMensaje = findByCodigo(swfMensaje.getMenCodmen());
		log.info("actualizado mensaje " + swfMensaje.toString());

		String nameFile = "sir" + swfMensaje.getMenGestion() + String.format("%06d", swfMensaje.getMenNrocorr()) + ".dos";
		String pathFileBck = pathSwift + "Backup/" + nameFile;
		String ptmp = UtilsFile.grabaEnArchivo(swfMensaje.getMenPlano(), pathFileBck);

		log.info("Swift backup generado!!! en " + ptmp);
//		paramsLocal = new ParamsBean();
//		paramsLocal.setEntityManager(entityManager);
		Param param = paramsLocal.findByCodigo(Constants.LAVADO_VERIFICA_LAVADO);
		log.info("==>>>>>EEEEEEEEEEEEEEN AUTOOOOOOOOO");
		log.info("==>>>>>param.getValparam() " + param.getValparam());
		
		ClienteLvdSir clienteLvdSir = new ClienteLvdSir(entityManager);
		clienteLvdSir.initClienteLvd(paramsLocal);
		clienteLvdSir.getSessionLavado(swfMensajePar.getMenAuditwst());

		if (clienteLvdSir.getClienteLvd() != null && (swfMensaje.getMenNrolavado() != null && swfMensaje.getMenNrolavado().compareTo(0) > 0)) {
			clienteLvdSir.preautorizarSwift(swfMensaje);
		} else {
			String pathFile = pathSwift + "/" + nameFile;
			try {
				String p = UtilsFile.copiarArchivo(pathFileBck, pathFile, true);
				log.info("Swift generado!!! en " + p);
			} catch (Exception e) {
				log.error("Swift: error al guardar archivo swift " + pathFileBck + ": " + e.getMessage(), e);
				throw new SwiftAdminException("Swift: error al guardar archivo swift " + pathFileBck + ": " + e.getMessage(), e);
			}
		}
		clienteLvdSir.cerrarSession(swfMensajePar.getMenAuditusr());
		return swfMensaje;
	}

	public void rechazarSwift(String menCodoperacion, String menAuditusr, String menAuditwst) {
		log.info("En rechazar Swift " + menCodoperacion);

		// SwfMensaje swfMensaje =
		// findByCodoperacion(swfMensajePar.getMenCodoperacion(),
		// Constants.PAR_ESTSWIFT_PEND);
		if (StringUtils.isBlank(menCodoperacion)) {
			return;
			// throw new SwiftAdminException("Parametro de codOperacion nulo");
		}

		SwfMensaje swfMensaje = findByCodoperacion(menCodoperacion, Constants.PAR_ESTSWIFT_AUTO);
		if (swfMensaje != null) {
			throw new SwiftAdminException("Swift: mensaje " + swfMensaje.getMenCodmen() + " con operacion[" + menCodoperacion + "] en estado "
					+ swfMensaje.getMenCveestswift() + " invalido");
		}

		String jsql = "UPDATE SwfMensaje t ";
		jsql = jsql.concat("set t.menCveestswift = :menCveestswift, ");
		jsql = jsql.concat("t.menAuditfho = :menAuditfho, ");
		jsql = jsql.concat("t.menAuditusr = :menAuditusr, ");
		jsql = jsql.concat("t.menAuditwst = :menAuditwst ");
		jsql = jsql.concat("WHERE t.menCodoperacion = :menCodoperacion ");
		jsql = jsql.concat("and t.menCveestswift in ('P','1') ");

		Query query = getEntityManager().createQuery(jsql);
		query.setParameter("menCveestswift", Constants.PAR_ESTSWIFT_RECH);
		query.setParameter("menAuditfho", new Date(), TemporalType.TIMESTAMP);
		query.setParameter("menAuditusr", menAuditusr);
		query.setParameter("menAuditwst", menAuditwst);
		query.setParameter("menCodoperacion", menCodoperacion);

		int result = query.executeUpdate();
		log.info("Modificados: " + result + " para " + menCodoperacion);

	}

	public void rechazarSwift(Integer menCodmen, String menAuditusr, String menAuditwst) {
		log.info("En rechazar Swift " + menCodmen);

		SwfMensaje swfMensaje = findByCodigo(menCodmen);
		if (swfMensaje == null) {
			throw new SwiftAdminException("Mensaje " + menCodmen + " inexistente");
		}

		if (swfMensaje.getMenCveestswift().trim().equals(Constants.PAR_ESTSWIFT_AUTO)
				|| swfMensaje.getMenCveestswift().trim().equals(Constants.PAR_ESTSWIFT_RECH)) {
			throw new SwiftAdminException("Swift: mensaje " + swfMensaje.getMenCodmen() + " en estado " + swfMensaje.getMenCveestswift() + " invalido");
		}

		String jsql = "UPDATE SwfMensaje t ";
		jsql = jsql.concat("set t.menCveestswift = :menCveestswift, ");
		jsql = jsql.concat("t.menAuditfho = :menAuditfho, ");
		jsql = jsql.concat("t.menAuditusr = :menAuditusr, ");
		jsql = jsql.concat("t.menAuditwst = :menAuditwst ");
		jsql = jsql.concat("WHERE t.menCodmen = :menCodmen ");
		jsql = jsql.concat("and t.menCveestswift in ('P','1') ");

		Query query = getEntityManager().createQuery(jsql);
		query.setParameter("menCveestswift", Constants.PAR_ESTSWIFT_RECH);
		query.setParameter("menAuditfho", new Date(), TemporalType.TIMESTAMP);
		query.setParameter("menAuditusr", menAuditusr);
		query.setParameter("menAuditwst", menAuditwst);
		query.setParameter("menCodmen", menCodmen);

		int result = query.executeUpdate();
		log.info("Modificados: " + result + " para " + menCodmen);

	}

	private void validarDatos(SwfMensaje swfMensaje) {
		log.info("validando mensaje");
		if (swfMensaje == null) {
			throw new SwiftAdminException("Swift: mensaje  parametro nulo");
		}

		if (StringUtils.isBlank(swfMensaje.getMenCveestswift())) {
			throw new SwiftAdminException("Swift: mensaje  " + swfMensaje.getMenCodmen() + " con estado nulo");
		}
		if (StringUtils.isBlank(swfMensaje.getMenBic())) {
			throw new SwiftAdminException("Swift: mensaje  " + swfMensaje.getMenCodmen() + " Bic receptor nulo");
		}
		if (StringUtils.isBlank(swfMensaje.getMenBicemisor())) {
			throw new SwiftAdminException("Swift: mensaje  " + swfMensaje.getMenCodmen() + " Bic emisor nulo");
		}
		if (StringUtils.isBlank(swfMensaje.getMenCodoperacion())) {
			throw new SwiftAdminException("Swift: mensaje  " + swfMensaje.getMenCodmen() + " con nro operacion nulo");
		}
		if (StringUtils.isBlank(swfMensaje.getMenCodmt())) {
			throw new SwiftAdminException("Swift: mensaje  " + swfMensaje.getMenCodmen() + " con tipo mensaje nulo");
		}
		if (swfMensaje.getMenFecvalor() == null) {
			throw new SwiftAdminException("Swift: mensaje  " + swfMensaje.getMenCodmen() + " con fecha valor nulo");
		}
		if (swfMensaje.getMenGestion() == null) {
			throw new SwiftAdminException("Swift: mensaje  " + swfMensaje.getMenCodmen() + " con gestion nulo");
		}
		if (StringUtils.isBlank(swfMensaje.getMenCodusrswf())) {
			throw new SwiftAdminException("Swift: mensaje  " + swfMensaje.getMenCodmen() + " con usuario nulo");
		}
		if (swfMensaje.getMenMonto() == null || swfMensaje.getMenMonto().compareTo(BigDecimal.ZERO) <= 0) {
			throw new SwiftAdminException("Swift: mensaje  " + swfMensaje.getMenCodmen() + " con monto invalido");
		}
	}

	private void validarEstado(SwfMensaje swfMensajePar) {
		log.info("validando Estado mensaje");
		if (swfMensajePar == null) {
			throw new SwiftAdminException("Swift: parametro mensaje nulo");
		}
		if (swfMensajePar.getMenCodmen() == null) {

			List<SwfMensaje> swfMensajeLista = findOperaciones(swfMensajePar.getMenCodoperacion(), null);

			if (swfMensajeLista.size() > 0) {
				throw new SwiftAdminException("Swift: mensaje con operación " + swfMensajePar.getMenCodoperacion()
						+ " ya tiene registrados otros mensajes con estado valido, verifique los mismos ");
			}
			return;
		}

		List<SwfMensaje> swfMensajeLista = findOperaciones(swfMensajePar.getMenCodoperacion(), null);

		if (swfMensajeLista.size() > 1) {
			// si es mayor a uno quiere decir que existe duplicacion de
			// operacion
			throw new SwiftAdminException("Swift: mensaje con operación " + swfMensajePar.getMenCodoperacion()
					+ " ya tiene registrados otros mensajes con estado valido, verifique los mismos ");
		}

		SwfMensaje swfMensaje = findByCodigo(swfMensajePar.getMenCodmen());

		if (swfMensaje == null) {
			throw new SwiftAdminException("Mensaje  " + swfMensajePar.getMenCodmen() + " inexistente");
		}

		if (StringUtils.isBlank(swfMensaje.getMenCveestswift())) {
			throw new SwiftAdminException("Swift: mensaje  " + swfMensaje.getMenCodmen() + " con estado nulo");
		}

		if (!swfMensaje.getMenCveestswift().equals(Constants.PAR_ESTSWIFT_PEND) && !swfMensaje.getMenCveestswift().equals(Constants.PAR_ESTSWIFT_AUTO)
				&& !swfMensaje.getMenCveestswift().equals(Constants.PAR_ESTSWIFT_PREAUT)) {
			throw new SwiftAdminException("Swift: mensaje  " + swfMensaje.getMenCodmen() + " con estado " + swfMensaje.getMenCveestswift() + " invalido");
		}

		if (swfMensaje.getMenCveestswift().equals(Constants.PAR_ESTSWIFT_AUTO)) {
			throw new SwiftAdminException("Swift: mensaje  " + swfMensaje.getMenCodmen() + " autorizado");
		}

	}

	private Integer getCodigo() {
		Integer codigo = null;
		StringBuilder query = new StringBuilder();
		query.append("select max(m.menCodmen) from SwfMensaje m ");

		List result = getEntityManager().createQuery(query.toString()).getResultList();
		if (result.size() > 0)
			codigo = (Integer) result.get(0);

		if (codigo == null) {
			codigo = 0;
		}
		codigo++;
		log.info("Nuevo codigo : " + codigo);
		return codigo;

	}

}
