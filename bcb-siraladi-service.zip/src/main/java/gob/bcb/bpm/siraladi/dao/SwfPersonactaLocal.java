package gob.bcb.bpm.siraladi.dao;

import java.util.List;

import gob.bcb.bpm.siraladi.jpa.SwfPersonacta;
import gob.bcb.bpm.siraladi.jpa.SwfPersonactaPK;




public interface SwfPersonactaLocal extends DAO<SwfPersonactaPK, SwfPersonacta>{

	SwfPersonacta findByCodigo(String pecCodpersona, String pecCodinst, String pecNrocta);

	void guardarCuenta(SwfPersonacta swfPersonacta);

	void guardarCuentaPersona(SwfPersonacta swfPersonacta, SwfPersonacta swfPersonactaInter);

	List<SwfPersonacta> buscarCtasPersona(String pecCodpersona, String pecCodinst, String pecNrocta, String pecTipoctainst, String pecCodinstinter,
			String pecNroctainter, String pecEstadocta);

	SwfPersonacta recuperarCuentaActiva(String pecCodpersona, String pecCodinst, String pecEstadocta);

}
