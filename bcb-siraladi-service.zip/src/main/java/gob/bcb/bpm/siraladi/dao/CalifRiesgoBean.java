package gob.bcb.bpm.siraladi.dao;

import java.util.List;


import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import gob.bcb.bpm.siraladi.exceptions.AladiException;
import gob.bcb.bpm.siraladi.jpa.CalifRiesgo;
import gob.bcb.bpm.siraladi.jpa.Param;

@Repository("califRiesgoLocal")
@Transactional
public class CalifRiesgoBean extends GenericDAO<String, CalifRiesgo> implements CalifRiesgoLocal {
	private static Logger log = Logger.getLogger(CalifRiesgoBean.class);
	
	public CalifRiesgo findByCodigo(String nomparam) {
		String jpql = "SELECT t FROM CalifRiesgo t ";
		jpql = jpql.concat("WHERE t.codCalif = :codCalif ");

		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("codCalif", nomparam);

		List lista = query.getResultList();
		if (lista.size() > 0) {
			return (CalifRiesgo) lista.get(0);
		}
		return null;
	}
	
	public CalifRiesgo saveorupdate(CalifRiesgo params ) {
		CalifRiesgo horarioOld = findByCodigo(params.getCodCalif());
	
		if (horarioOld == null){
			makePersistent(params);
		} else {
			
			makePersistent(params);
		}
		horarioOld = findByCodigo(params.getCodCalif());
		log.info("Actualizando Param " + horarioOld.toString());		
		return horarioOld; 
	}	
}
