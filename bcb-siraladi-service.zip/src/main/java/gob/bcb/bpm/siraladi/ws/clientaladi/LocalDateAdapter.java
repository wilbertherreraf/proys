package gob.bcb.bpm.siraladi.ws.clientaladi;

import javax.xml.bind.annotation.adapters.XmlAdapter;

import org.apache.log4j.Logger;
import org.joda.time.LocalDate;

public class LocalDateAdapter extends XmlAdapter<String, LocalDate> {
	private static Logger log = Logger.getLogger(LocalDateAdapter.class);
	
	public LocalDate unmarshal(String inputDate) throws Exception {
		log.debug("inputDateinputDate " + inputDate);
		if (inputDate.equals("0000-00-00")){
			inputDate = "2016-01-01";
		}
		return LocalDate.parse(inputDate);
	}

	
	public String marshal(LocalDate inputDate) throws Exception {
		log.debug("inputDate.toString() " + inputDate.toString());		
		return inputDate.toString();
	}
}
