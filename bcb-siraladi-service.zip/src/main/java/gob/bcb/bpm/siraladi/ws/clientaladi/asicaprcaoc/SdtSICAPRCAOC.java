
package gob.bcb.bpm.siraladi.ws.clientaladi.asicaprcaoc;

import gob.bcb.bpm.siraladi.ws.clientaladi.LocalDateAdapter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import javax.xml.datatype.XMLGregorianCalendar;

import org.joda.time.LocalDate;


/**
 * <p>Java class for sdtSICAPRCAOC complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="sdtSICAPRCAOC">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="CodigoRpta" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="FecVal" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="NroDeb" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "sdtSICAPRCAOC", propOrder = {

})
public class SdtSICAPRCAOC {

    @XmlElement(name = "CodigoRpta", required = true)
    protected String codigoRpta;
    
    @XmlElement(name = "FecVal", required = true)
    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    @XmlSchemaType(name = "date")
    protected LocalDate fecVal;
    //protected XMLGregorianCalendar fecVal;
    @XmlElement(name = "NroDeb")
    protected short nroDeb;

    /**
     * Gets the value of the codigoRpta property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigoRpta() {
        return codigoRpta;
    }

    /**
     * Sets the value of the codigoRpta property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigoRpta(String value) {
        this.codigoRpta = value;
    }

    /**
     * Gets the value of the fecVal property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public LocalDate getFecVal() {
        return fecVal;
    }

    /**
     * Sets the value of the fecVal property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFecVal(LocalDate value) {
        this.fecVal = value;
    }

    /**
     * Gets the value of the nroDeb property.
     * 
     */
    public short getNroDeb() {
        return nroDeb;
    }

    /**
     * Sets the value of the nroDeb property.
     * 
     */
    public void setNroDeb(short value) {
        this.nroDeb = value;
    }

}
