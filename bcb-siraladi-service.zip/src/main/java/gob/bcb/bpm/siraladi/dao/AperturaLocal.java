package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.Apertura;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;

public interface AperturaLocal extends DAO<Integer, Apertura> {
    Apertura findByCodReembolso(String codInst, String codId, String anio, String secuencia, Integer dav);

	/**
	 * Calcula el saldo de un instrumento
	 * @param nroMov
	 * @return
	 */
	BigDecimal getSaldo(Integer nroMov);

	void controlUsuarioOperacion(Apertura apertura);

	Apertura findByNroMovCveEstado(Integer nroMov, String cveEstadoApe);

	/**
	 * Busca en la base el instrumento segun los parametros dados, y ademas se
	 * especifica si se har un control de acceso o no
	 * 
	 * @param codInst
	 * @param codId
	 * @param anio
	 * @param secuencia
	 * @param dav
	 * @param control
	 *            si es true se realiza un control de acceso seg n el id de
	 *            usuario y a la entidad IFA que pertenece para realizar o no
	 *            una operaci n sobre la misma
	 * @return instrumento de la base o nulo si no fue encontrada
	 */
	Apertura findByCodReembolso(String codInst, String codId, String anio, String secuencia, Integer dav, boolean control);
}
