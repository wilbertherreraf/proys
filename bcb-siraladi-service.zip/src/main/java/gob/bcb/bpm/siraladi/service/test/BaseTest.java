package gob.bcb.bpm.siraladi.service.test;

import gob.bcb.bpm.siraladi.pojo.StatusResponse;

import gob.bcb.bpm.siraladi.service.DispatcherSirAladi;
import gob.bcb.core.jms.BcbRequestImpl;
import gob.bcb.service.siraladi.ServerListener;

import javax.jms.Connection;
import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.persistence.EntityManager;
import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public abstract class BaseTest {
	private static final Log log = LogFactory.getLog(BaseTest.class);
	private String requestQueue = "GOB.BCB.SERVICE.SIRALADI";
	private EntityManager entityManager ;
	public void enviarMensaje(String message) {
		long t0 = System.currentTimeMillis();
		log.info("Mensaje a enviar: \n" + message);
		ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory();
		try {
			Connection connection = connectionFactory.createConnection();
			Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			MessageProducer producer = session.createProducer(null);
			producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
			
			TextMessage textMessage = session.createTextMessage();
			textMessage.setText(message);
			
			Destination destination = session.createQueue(requestQueue);
			producer.send(destination, textMessage);			
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	public StatusResponse invocarServicioAladi(String codTipoOperacion, Object parametrosRequest) {
		StatusResponse statusResponse = null;

		log.info("Realizando llamada al servicio, operaci�n: " + codTipoOperacion);
		gob.bcb.core.jms.BcbRequest bcbRequest = BcbRequestImpl.newInstance("asdf", "asdf", "idDestinatario",
				"service", codTipoOperacion, "requestID", "wherrera", "del 1 al 8", "nroOperacion", parametrosRequest);
		try {
			String xmlRequest = bcbRequest.toString(bcbRequest.getMsgbcb());
			enviarMensaje(xmlRequest);
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		log.info("La llamada al servicio se realizo con exito.");
		return statusResponse;
	}
	public void setupEM(){
		ServerListener serverListener = new ServerListener();
		serverListener.init();
		entityManager = ServerListener.getEntityMgrFactory().createEntityManager();
	}


	public EntityManager getEntityManager() {
		return entityManager;
	}


	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

}
