package gob.bcb.bpm.siraladi.service.test;

import gob.bcb.bpm.siraladi.jpa.TPagoImp;
import gob.bcb.bpm.siraladi.logic.PagoServiceBean;
import gob.bcb.bpm.siraladi.utils.UtilsDate;
import gob.bcb.bpm.siraladi.ws.clientaladi.ClientAladiWSHandler;
import gob.bcb.bpm.siraladi.ws.clientaladi.asicapccb.SdtSICAPCCB;
import gob.bcb.bpm.siraladi.ws.clientaladi.asicapccb.SdtSICAPCCBSdtSICAPCCBItem;
import gob.bcb.bpm.siraladi.ws.clientaladi.asicapccb.SicapCcbWsExecuteResponse;
import gob.bcb.core.utils.JAXBHelper;
import gob.bcb.core.utils.UtilsFile;
import gob.bcb.core.utils.XmlUtils;
import gob.bcb.siraladi.xml.Contenidotype;
import gob.bcb.siraladi.xml.operaciones.Aladirequesttipo02Type;
import gob.bcb.siraladi.xml.operaciones.ObjectFactory;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class PagoServiceTest extends BaseTest {
	private static final Log log = LogFactory.getLog(PagoServiceTest.class);	
	//private static DocumentBuilderFactory documentBuilderFactory;
	public void pago() {
		Aladirequesttipo02Type aladirequesttipo02Type = new Aladirequesttipo02Type();
		JAXBElement<? extends Contenidotype> contenido = null;
		aladirequesttipo02Type.setFechaDesde(UtilsDate.StrToXMLGregoCal(UtilsDate.stringFromDate(new Date(), "yyyy-MM-dd"), "-"));

		ObjectFactory of = new ObjectFactory();
		contenido = of.createAladirequesttipo02(aladirequesttipo02Type);

		invocarServicioAladi("AL0308", contenido);
	}

	public void al308Test(String filePath) throws Exception {
		setupEM();
		String mensajeXML = UtilsFile.readFileAsString2(filePath);		
		JAXBContext context = JAXBContext.newInstance("gob.bcb.bpm.siraladi.ws.clientaladi.asicapccb");
		System.out.println(mensajeXML);
		Object mensajeJAXB = JAXBHelper.convertXMLToMsgBcb(mensajeXML, context);
		SicapCcbWsExecuteResponse sicapCcbWsExecuteResponse =(gob.bcb.bpm.siraladi.ws.clientaladi.asicapccb.SicapCcbWsExecuteResponse) mensajeJAXB ;
		List<TPagoImp> tPagoImpList = ClientAladiWSHandler.sicapCcbResponseToTPagoImp(sicapCcbWsExecuteResponse);
		System.out.println(tPagoImpList.size());		
		for (TPagoImp tPagoImp : tPagoImpList) {
			System.out.println(tPagoImp.toString());
		}
		PagoServiceBean pagoServiceBean = new PagoServiceBean(getEntityManager());
		pagoServiceBean.registrarPagoImport(tPagoImpList, true);
	}

	public SicapCcbWsExecuteResponse genSicapCcbWsExecuteResponse() throws JAXBException, ParserConfigurationException, TransformerException{
		SicapCcbWsExecuteResponse result = new SicapCcbWsExecuteResponse();
		SdtSICAPCCB sdtSICAPCCB = new SdtSICAPCCB();
		result.setSdtsicap(sdtSICAPCCB);
		
		SdtSICAPCCBSdtSICAPCCBItem sdtSICAPCCBSdtSICAPCCBItem = new SdtSICAPCCBSdtSICAPCCBItem();
		sdtSICAPCCBSdtSICAPCCBItem.setCodigoRpta("af");
		sdtSICAPCCBSdtSICAPCCBItem.setConvenio("asssas");
//		sdtSICAPCCBSdtSICAPCCBItem.setFecha(UtilsDate.StrToXMLGregoCal(UtilsDate.stringFromDate(new Date(), "yyyy-MM-dd"), "-"));
//		sdtSICAPCCBSdtSICAPCCBItem.setFechaCargo(UtilsDate.StrToXMLGregoCal(UtilsDate.stringFromDate(new Date(), "yyyy-MM-dd"), "-"));		
		sdtSICAPCCB.getSdtSICAPCCBSdtSICAPCCBItem().add(sdtSICAPCCBSdtSICAPCCBItem);
		
		sdtSICAPCCBSdtSICAPCCBItem = new SdtSICAPCCBSdtSICAPCCBItem();
		sdtSICAPCCBSdtSICAPCCBItem.setCodigoRpta("af22");
		sdtSICAPCCBSdtSICAPCCBItem.setConvenio("asssas333");
//		sdtSICAPCCBSdtSICAPCCBItem.setFecha(UtilsDate.StrToXMLGregoCal(UtilsDate.stringFromDate(new Date(), "yyyy-MM-dd"), "-"));
//		sdtSICAPCCBSdtSICAPCCBItem.setFechaCargo(UtilsDate.StrToXMLGregoCal(UtilsDate.stringFromDate(new Date(), "yyyy-MM-dd"), "-"));
		sdtSICAPCCB.getSdtSICAPCCBSdtSICAPCCBItem().add(sdtSICAPCCBSdtSICAPCCBItem);
		return result;

		
	}
	public static void main(String[] args) throws Exception {
		PagoServiceTest pagoServiceTest = new PagoServiceTest();
//		SicapCcbWsExecuteResponse result = pagoServiceTest.genSicapCcbWsExecuteResponse();
//		String mensajeXML = XmlUtils.objectJAXBToString(result);
//		System.out.println(mensajeXML);
		pagoServiceTest.al308Test("e://sdtSICAPCCB.xml");		
	
	}
	static  String cad = "";
	{
		cad = "<sdtSICAPCCB>";
		cad = cad + "<sdtSICAPCCBSdtSICAPCCBItem>";
		cad = cad + "<SdtSICAPCCBSdtSICAPCCBItem>";
		cad = cad + "<codigoRpta>1001</codigoRpta>";
		cad = cad + "<convenio>03</convenio>";
		cad = cad + "<instEmisora>0698</instEmisora>";
		cad = cad + "<fechaCargo class=\"com.sun.org.apache.xerces.internal.jaxp.datatype.XMLGregorianCalendarImpl\">";
		cad = cad + "<year>2015</year>";
		cad = cad + "<month>4</month>";
		cad = cad + "<day>23</day>";
		cad = cad + "<timezone>-2147483648</timezone>";
		cad = cad + "<hour>-2147483648</hour>";
		cad = cad + "<minute>-2147483648</minute>";
		cad = cad + "<second>-2147483648</second>";
		cad = cad + "</fechaCargo>";
		cad = cad + "<nroDebito>49</nroDebito>";
		cad = cad + "<instPagadora>1257</instPagadora>";
		cad = cad + "<nroReembolso>06981201506945180000</nroReembolso>";
		cad = cad + "<instrumento>CC</instrumento>";
		cad = cad + "<fecha class=\"com.sun.org.apache.xerces.internal.jaxp.datatype.XMLGregorianCalendarImpl\">";
		cad = cad + "<year>2015</year>";
		cad = cad + "<month>4</month>";
		cad = cad + "<day>23</day>";
		cad = cad + "<timezone>-2147483648</timezone>";
		cad = cad + "<hour>-2147483648</hour>";
		cad = cad + "<minute>-2147483648</minute>";
		cad = cad + "<second>-2147483648</second>";
		cad = cad + "</fecha>";
		cad = cad + "<monto>22709.03</monto>";
		cad = cad + "<observaciones></observaciones>";
		cad = cad + "</SdtSICAPCCBSdtSICAPCCBItem>";
		cad = cad + "</sdtSICAPCCBSdtSICAPCCBItem>";
		cad = cad +"</sdtSICAPCCB>";		
	}
}
