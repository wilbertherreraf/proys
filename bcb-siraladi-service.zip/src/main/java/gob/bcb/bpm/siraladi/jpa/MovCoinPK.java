package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * The primary key class for the mov_coin database table.
 * 
 */

@Embeddable
public class MovCoinPK implements Serializable {
	@Column(name="nro_mov", unique=true, nullable=false)
	private int nroMov;

	@Column(name="nro_reng", unique=true, nullable=false)
	private short nroReng;

    public MovCoinPK() {
    }
	public int getNroMov() {
		return this.nroMov;
	}
	public void setNroMov(int nroMov) {
		this.nroMov = nroMov;
	}
	public short getNroReng() {
		return this.nroReng;
	}
	public void setNroReng(short nroReng) {
		this.nroReng = nroReng;
	}

	
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof MovCoinPK)) {
			return false;
		}
		MovCoinPK castOther = (MovCoinPK)other;
		return 
			(this.nroMov == castOther.nroMov)
			&& (this.nroReng == castOther.nroReng);

    }
    
	
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.nroMov;
		hash = hash * prime + (this.nroReng);
		
		return hash;
    }
}
