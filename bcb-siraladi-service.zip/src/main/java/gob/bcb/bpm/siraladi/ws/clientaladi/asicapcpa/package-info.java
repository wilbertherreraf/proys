@javax.xml.bind.annotation.XmlSchema(namespace = "BCRP", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package gob.bcb.bpm.siraladi.ws.clientaladi.asicapcpa;
