package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;

import java.util.Date;


/**
 * The persistent class for the params database table.
 * 
 */
@Entity
@Table(name="params")
@NamedQueries({ @NamedQuery(name = "Param.findAll", query = "SELECT a FROM Param a") })
public class Param implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="nomparam")
	private String nomparam;

	@Column(name="cod_usuario")
	private String codUsuario;

	@Column(name="descparam")
	private String descparam;

	@Column(name="estacion")
	private String estacion;

	@Column(name="fecha_hora")
	private Date fechaHora;

	@Column(name="valparam")
	private String valparam;

    public Param() {
    }

	public String getNomparam() {
		return this.nomparam;
	}

	public void setNomparam(String nomparam) {
		this.nomparam = nomparam;
	}

	public String getCodUsuario() {
		return this.codUsuario;
	}

	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}

	public String getDescparam() {
		return this.descparam;
	}

	public void setDescparam(String descparam) {
		this.descparam = descparam;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getValparam() {
		return this.valparam;
	}

	public void setValparam(String valparam) {
		this.valparam = valparam;
	}

	
	public String toString() {
		return "Param [nomparam=" + nomparam + ", codUsuario=" + codUsuario
				+ ", descparam=" + descparam + ", estacion=" + estacion
				+ ", fechaHora=" + fechaHora + ", valparam=" + valparam + "]";
	}

}
