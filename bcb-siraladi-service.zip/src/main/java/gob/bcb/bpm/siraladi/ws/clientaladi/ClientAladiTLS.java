package gob.bcb.bpm.siraladi.ws.clientaladi;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;

import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509KeyManager;

import org.apache.cxf.configuration.jsse.TLSClientParameters;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.apache.log4j.Logger;

public class ClientAladiTLS {
	private static Logger log = Logger.getLogger(ClientAladiTLS.class);
	private SSLContext context;
    private X509KeyManager keyManager = null;
    private KeyStore trustKeyStore = null;
    private static ClientAladiTLS clientTLSInstance;
    private final String trustStore;
    private final String trustStorePassword; 
    private final String keyStore;
    private final String keyStorePassword; 
    private final String keypass;
    
    private ClientAladiTLS(String trustStore, String trustStorePassword, String keyStore, String keyStorePassword, String keypass) {
    	this.trustStore= trustStore;
    	this.trustStorePassword = trustStorePassword;
    	this.keyStore = keyStore;
    	this.keyStorePassword = keyStorePassword;
    	this.keypass = keypass;
    	
    }

    public void init() {
        try {
            TrustManagerFactory tmf = TrustManagerFactory.getInstance("PKIX");
            // use cacerts truststore bits by default
            // but you should be able to use a non-null value to inform the context about server certs not in cacerts
            tmf.init(trustKeyStore);
            KeyManager[] keyManagers = {keyManager};
            context = SSLContext.getInstance("TLS");
            context.init(keyManagers, tmf.getTrustManagers(), null);
        } catch (KeyManagementException ex) {
            throw new RuntimeException(ex);
        } catch (KeyStoreException ex) {
            throw new RuntimeException(ex);
        } catch (NoSuchAlgorithmException ex) {
            throw new RuntimeException(ex);
        }
    }	
    
	public static ClientAladiTLS createInstance(String trustStore, String trustStorePassword, String keyStore, String keyStorePassword, String keypass ) throws Exception {
		if (getInstance() == null){
			log.info("Creando nueva instancia TLS trustStore: " + trustStore + "; keyStore:" + keyStore + " keyStorePassword:" + keyStorePassword + " keypass:" + keypass);
			clientTLSInstance = new ClientAladiTLS(trustStore, trustStorePassword, keyStore, keyStorePassword, keypass);
		}
        //System.setProperty("javax.net.debug", "ssl,handshake,verbose");				
//		KeyManager[] myKeyManagers = createKeyManagers(keyStore, keyStorePassword, keypass);
//		TrustManager[] myTrustStoreKeyManagers = createTrustManagers(trustStore, trustStorePassword);		
		return getInstance();

	}
	public static ClientAladiTLS getInstance(){
		return clientTLSInstance;
	}
	
	public static void setupTLSWSClient(Object port) throws Exception{
		if (getInstance() == null){
			throw new RuntimeException("Instancia TLS no iniciada.");			
		}
		log.info("Config. TLS Context: " + port.toString());
		HTTPConduit httpConduit = (HTTPConduit) ClientProxy.getClient(port).getConduit();
		KeyManager[] myKeyManagers = createKeyManagers(getInstance().keyStore, getInstance().keyStorePassword, getInstance().keypass);
		
		TLSClientParameters tlsCP = new TLSClientParameters();

		/****************/
		tlsCP.setDisableCNCheck(true);
		/****************/
		tlsCP.setKeyManagers(myKeyManagers);
		
		TrustManager[] myTrustStoreKeyManagers = createTrustManagers(getInstance().trustStore, getInstance().trustStorePassword);		
		tlsCP.setTrustManagers(myTrustStoreKeyManagers);
		
		httpConduit.setTlsClientParameters(tlsCP);
		
		/*******/
		HTTPClientPolicy hTTPClientPolicy = new HTTPClientPolicy();
		hTTPClientPolicy.setAllowChunking(false);
		httpConduit.setClient(hTTPClientPolicy);
		/*******/
		
		SSLContext context = SSLContext.getInstance("TLS");
        context.init(myKeyManagers, myTrustStoreKeyManagers, null);
		log.info("Config. TLS Context ...... hecho ");        
	}
	
	public static void setupTLS(Object port) throws FileNotFoundException, IOException, GeneralSecurityException {
		log.info("Config. TLS Context: " + port.toString());
		String keyStoreLoc = "resources/clientKeystore.jks";
		HTTPConduit httpConduit = (HTTPConduit) ClientProxy.getClient(port).getConduit();

		TLSClientParameters tlsCP = new TLSClientParameters();
		String keyPassword = "ckpass";

		KeyStore keyStore = KeyStore.getInstance("JKS");
		keyStore.load(new FileInputStream(keyStoreLoc), "cspass".toCharArray());

		KeyManager[] myKeyManagers = getKeyManagers(keyStore, keyPassword);

		tlsCP.setKeyManagers(myKeyManagers);

		KeyStore trustStore = KeyStore.getInstance("JKS");
		trustStore.load(new FileInputStream(keyStoreLoc), "cspass".toCharArray());

		TrustManager[] myTrustStoreKeyManagers = getTrustManagers(trustStore);
		tlsCP.setTrustManagers(myTrustStoreKeyManagers);

		httpConduit.setTlsClientParameters(tlsCP);
	}
	
	/**
	 * Creates the trust managers required to initiate the {@link SSLContext},
	 * using a JKS keystore as an input.
	 * 
	 * @param filepath
	 *            - the path to the JKS keystore.
	 * @param keystorePassword
	 *            - the keystore's password.
	 * @return {@link TrustManager} array, that will be used to initiate the
	 *         {@link SSLContext}.
	 * @throws Exception
	 */
	protected static TrustManager[] createTrustManagers(String filepath, String keystorePassword) throws Exception {
		// KeyStore trustStore = KeyStore.getInstance("JKS");
		KeyStore trustStore = keyStoreFromFile(filepath, keystorePassword);
		TrustManagerFactory trustFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
		trustFactory.init(trustStore);
		return trustFactory.getTrustManagers();
	}

	/**
	 * Creates the key managers required to initiate the {@link SSLContext},
	 * using a JKS keystore as an input.
	 * 
	 * @param filepath
	 *            - the path to the JKS keystore.
	 * @param keystorePassword
	 *            - the keystore's password.
	 * @param keyPassword
	 *            - the key's passsword.
	 * @return {@link KeyManager} array that will be used to initiate the
	 *         {@link SSLContext}.
	 * @throws Exception
	 */
	protected static KeyManager[] createKeyManagers(String filepath, String keystorePassword, String keyPassword) throws Exception {
		KeyStore keyStore = keyStoreFromFile(filepath, keystorePassword);
		// keyStore.load(keyStoreIS, keystorePassword.toCharArray());
		KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
		kmf.init(keyStore, keyPassword.toCharArray());

		return kmf.getKeyManagers();
	}

	private static TrustManager[] getTrustManagers(KeyStore trustStore) throws NoSuchAlgorithmException, KeyStoreException {
		String alg = KeyManagerFactory.getDefaultAlgorithm();

		TrustManagerFactory fac = TrustManagerFactory.getInstance(alg);

		fac.init(trustStore);
		return fac.getTrustManagers();
	}

	private static KeyManager[] getKeyManagers(KeyStore keyStore, String keyPassword) throws GeneralSecurityException, IOException {
		String alg = KeyManagerFactory.getDefaultAlgorithm();

		char[] keyPass = keyPassword != null ? keyPassword.toCharArray() : null;

		KeyManagerFactory fac = KeyManagerFactory.getInstance(alg);

		fac.init(keyStore, keyPass);
		return fac.getKeyManagers();
	}

	private static KeyStore keyStoreFromFile(String filepath, String storepass) throws KeyStoreException, IOException, NoSuchAlgorithmException,
			CertificateException {
		KeyStore keyStore = KeyStore.getInstance("JKS");
		InputStream trustStoreIS = new FileInputStream(filepath);
		try {
			keyStore.load(trustStoreIS, storepass.toCharArray());
		} finally {
			if (trustStoreIS != null) {
				trustStoreIS.close();
			}
		}

		return keyStore;
	}
	
	public SSLContext getContext() {
        return context;
    }

    public void setKeyManager(X509KeyManager keyManager) {
        this.keyManager = keyManager;
    }

    public void setTrustStore(KeyStore trustStore) {
        this.trustKeyStore = trustStore;
    }	
}
