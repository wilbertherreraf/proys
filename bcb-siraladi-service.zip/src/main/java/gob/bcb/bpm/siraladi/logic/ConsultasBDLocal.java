package gob.bcb.bpm.siraladi.logic;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.EntityManager;

public interface ConsultasBDLocal {

	EntityManager getEntityManager();

	void setEntityManager(EntityManager entityManager);

	/**
	 * Consulta a la base del saldo contingente mediante la ejecucin del proc almacenado saldo_cont_mo
	 * @param codPersona codigo de IFA
	 * @param fecha fecha a la cual se calcula el saldo
	 * @param cveTipoApe tipo de apertura del instrumento I importacion, E exportacion
	 * @return saldo contingente 
	 */
	BigDecimal getSaldoCont(String codPersona, Date fecha, String cveTipoApe);

}