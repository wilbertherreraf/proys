package gob.bcb.bpm.siraladi.logic;

import gob.bcb.bpm.siraladi.dao.EntityUserTransaction;
import gob.bcb.bpm.siraladi.dao.EstadoMovBean;
import gob.bcb.bpm.siraladi.dao.EstadoMovLocal;
import gob.bcb.bpm.siraladi.dao.InstitucionBean;
import gob.bcb.bpm.siraladi.dao.InstitucionLocal;
import gob.bcb.bpm.siraladi.dao.InstrumentoBean;
import gob.bcb.bpm.siraladi.dao.InstrumentoLocal;
import gob.bcb.bpm.siraladi.dao.PagoBean;
import gob.bcb.bpm.siraladi.dao.PagoLocal;
import gob.bcb.bpm.siraladi.dao.PlanPagoBean;
import gob.bcb.bpm.siraladi.dao.RegAnticipadoBean;
import gob.bcb.bpm.siraladi.dao.RegistroBean;
import gob.bcb.bpm.siraladi.dao.RegistroLocal;
import gob.bcb.bpm.siraladi.dao.TPagoImpBean;
import gob.bcb.bpm.siraladi.exceptions.AladiException;
import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.EstadoMov;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Movimiento;
import gob.bcb.bpm.siraladi.jpa.Pago;
import gob.bcb.bpm.siraladi.jpa.PlanPago;
import gob.bcb.bpm.siraladi.jpa.RegAnticipado;
import gob.bcb.bpm.siraladi.jpa.Registro;
import gob.bcb.bpm.siraladi.jpa.TPagoImp;
import gob.bcb.bpm.siraladi.msgmail.MsgLogic;
import gob.bcb.bpm.siraladi.service.session.UserSessionHolder;
import gob.bcb.bpm.siraladi.utils.Constants;
import gob.bcb.bpm.siraladi.utils.NumeroDAV;
import gob.bcb.bpm.siraladi.utils.UtilsDate;
import gob.bcb.bpm.siraladi.ws.clientaladi.ClientAladiWSHandler;
import gob.bcb.bpm.siraladi.ws.clientaladi.RespWSAladi;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.transaction.SystemException;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;

/**
 * @author wilherrera Wilbert Herrera Flores Banco Central de Bolivia
 *         Departamento de Desarrollo
 */
public class PagoServiceBean extends EntityUserTransaction implements PagoServiceLocal {
	private static Logger log = Logger.getLogger(PagoServiceBean.class);

	private PagoLocal pagoLocal;

	private Map<String, Object> warnnings = new HashMap<String, Object>();

	public PagoServiceBean(EntityManager em) {
		super(em);
		pagoLocal = new PagoBean();
		pagoLocal.setEntityManager(em);
	}

	
	public Pago crearReg(Pago pago, Apertura apertura) {
		String codReembolso = apertura.getNroReembLiteral();

		List<Pago> pagoList = pagoLocal.getByNroMovApeCveEstadoPago(apertura.getNroMov(), "P", true);
		for (Pago pago2 : pagoList) {
			if (pago.getNroMov() != null && pago2.getNroMov().compareTo(pago.getNroMov()) != 0) {
				throw new AladiException("DEBREEM_PENDIENTES", new Object[] { codReembolso });
			}
		}

		if (!pago.getInstrumento().getCodInstrumento().trim().equals("EXT") && !pago.getInstrumento().getCodInstrumento().trim().equals("AEX")
				&& !pago.getInstrumento().getCodInstrumento().trim().equals("ALE") && !pago.getInstrumento().getCodInstrumento().trim().equals("AUM")) {
			pago.setFechaReg(new Date());
			isValidData(pago, apertura);

			MovimientoServiceLocal movimientoService = new MovimientoServiceBean(getEntityManager());
			Movimiento movimiento = movimientoService.crearMovimiento("P", apertura.getCodMoneda(), new Date(), apertura.getNroMov());
			Integer nroMov = movimiento.getNroMov();

			if (nroMov == null || nroMov <= 0) {
				throw new AladiException("ERROR_GENERANDO_NRO_MOV", new Object[] { apertura.getNroReembLiteral() });
			}
			pago.setNroSecReemb(movimiento.getNroSecReemb());
			pago.setNroMovApe(apertura.getNroMov());
			pago.setNroMov(nroMov);
			pago.setCveEstadoPago("P");

			AperturaServiceLocal aperturaService = new AperturaServiceBean(getEntityManager());
			String nit = aperturaService.obtenerNIT(apertura, pago.getNit(), pago.getInstitucion().getCodInst(), "P");
			pago.setNit(nit);

			pago = pagoLocal.makePersistent(pago);
			pagoLocal.flush();
			pago = controlConPlanPagos(pago, apertura);
			pago = pagoLocal.makePersistent(pago);
			pagoLocal.flush();

			// verifica datos contables
			// OpersContaServiceLocal opersContaService = new
			// OpersContaServiceBean();
			// opersContaService.setEntityManager(getEntityManager());
			// opersContaService.contabilizaPago(pago, 0);
			return pago;
		} else {
			if (apertura.getCveTipoApe().equals("E")) {
				// si la operacion es de reverso de una operacion se crea un
				// nuevo registro con los datos del pago que viene en nro mov
				Pago pagoReverso = pagoLocal.findById(pago.getNroMov(), false);
				if (pagoReverso == null) {
					throw new AladiException("PAGO_INEXISTENTE", new Object[] { pago.getNroMov() });
				}
				MovimientoServiceLocal movimientoService = new MovimientoServiceBean(getEntityManager());
				Integer nroMov = null;
				Movimiento movimiento = null;
				if (pago.getInstrumento().getCodInstrumento().trim().equals("EXT")) {
					movimiento = movimientoService.crearMovimiento("P", apertura.getCodMoneda(), new Date(), apertura.getNroMov());
					nroMov = movimiento.getNroMov();
				}
				if (pago.getInstrumento().getCodInstrumento().trim().equals("ALE")) {
					movimiento = movimientoService.crearMovimiento("P", apertura.getCodMoneda(), new Date(), apertura.getNroMov());
					nroMov = movimiento.getNroMov();
				}

				if (movimiento == null || nroMov == null || nroMov <= 0) {
					throw new AladiException("ERROR_GENERANDO_NRO_MOV", new Object[] { apertura.getNroReembLiteral() });
				}

				pago.setNroMovApe(apertura.getNroMov());
				pago.setNroMov(nroMov);
				pago.setCveEstadoPago("P");
				pago.setDebeMo(pagoReverso.getHaberMo());
				pago.setHaberMo(BigDecimal.ZERO);
				pago.setInstitucion(pagoReverso.getInstitucion());
				pago.setFechaReg(pagoReverso.getFechaReg());
				pago.setNroSecReemb(pagoReverso.getNroSecReemb());
				pago.setNroExtorno(apertura.getNroReembLiteral(true)
						+ String.format("%04d", (pagoReverso.getNroSecReemb() == null ? 0 : pagoReverso.getNroSecReemb()))
						+ pagoReverso.getInstrumento().getCodInstrumento().trim());

				AperturaServiceLocal aperturaService = new AperturaServiceBean(getEntityManager());
				String nit = aperturaService.obtenerNIT(apertura, pago.getNit(), pago.getInstitucion().getCodInst(), "P");
				pago.setNit(nit);
				pago = pagoLocal.makePersistent(pago);
				pagoLocal.flush();

				return pago;
			} else {
				throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Las operaciones de reverso estan permitidas solo para importacion" });
			}

		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gob.bcb.bpm.siraladi.logic.PagoServiceLocal#isValidData(gob.bcb.bpm.siraladi
	 * .jpa.Pago)
	 */
	
	public boolean isValidData(Pago pago, Apertura apertura) {
		boolean result = false;

		if (!apertura.getCveEstadoApe().equalsIgnoreCase("V")) {
			throw new AladiException("INVALIDO_PARA_MODIFICACION", new Object[] { apertura.getNroReembLiteral(), apertura.getCveEstadoApe() });
		}
		RegistroLocal registroLocal = new RegistroBean();
		registroLocal.setEntityManager(getEntityManager());

		List<Registro> registroList = registroLocal.getByNroMovApeCveEstadoReg(apertura.getNroMov(), "P");
		if (registroList.size() > 0)
			throw new AladiException("ENMIENDAS_PENDIENTES", new Object[] { apertura.getNroReembLiteral() });

		if (pago.getInstitucion() == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Institucion NULO" });
		}
		if (pago.getInstitucion().getCodInst() == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Codigo institucion NULO" });
		}

		if (pago.getInstrumento() == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Instrumento NULO" });
		}
		if (pago.getInstrumento().getCodInstrumento() == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Codigo instrumento NULO" });
		}

		InstitucionLocal institucionLocal = new InstitucionBean();
		institucionLocal.setEntityManager(getEntityManager());

		Institucion institucion = institucionLocal.findById(pago.getInstitucion().getCodInst(), false);

		if (institucion == null) {
			throw new AladiException("INSTITUCION_NO_ENCONTRADA", new Object[] { pago.getInstitucion().getCodInst() });
		}

		if (pago.getFechaReg() == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Fecha operacion nulo" });
		}

		if (!apertura.getCveTipoApe().equals("I")) {
			Date fecha = DateUtils.truncate(pago.getFechaReg(), Calendar.DAY_OF_MONTH);
			if (fecha.before(apertura.getFechaEmis()) || fecha.after(apertura.getFechaVtoPag())) {
				throw new AladiException("FECHA_FUERA_RANGO", new Object[] { UtilsDate.stringFromDate(pago.getFechaReg(), Constants.FORMAT_DATE_DB),
						UtilsDate.stringFromDate(apertura.getFechaEmis(), Constants.FORMAT_DATE_DB),
						UtilsDate.stringFromDate(apertura.getFechaVtoPag(), Constants.FORMAT_DATE_DB) });
			}

			if (pago.getFechaCargo() != null && fecha.after(pago.getFechaCargo())) {
				throw new AladiException("FECHA_REG_INCORRECTA", new Object[] {
						UtilsDate.stringFromDate(pago.getFechaReg(), Constants.FORMAT_DATE_DB),
						UtilsDate.stringFromDate(pago.getFechaCargo(), Constants.FORMAT_DATE_DB) });
			}
		}

		if (pago.getDebeMo().compareTo(BigDecimal.valueOf(0)) != 0 && pago.getHaberMo().compareTo(BigDecimal.valueOf(0)) != 0) {
			throw new AladiException("MONTO_TRANS_PAGREEM_INCORRECTO");
		}

		BigDecimal montoP = null;

		if (pago.getNroMov() != null && pago.getNroMov().compareTo(Integer.valueOf(0)) > 0) {
			montoP = pagoLocal.getMontoSinNroMov(apertura.getNroMov(), pago.getNroMov());
		} else {
			montoP = pagoLocal.getMontoPago(apertura.getNroMov());
		}

		BigDecimal montoR = registroLocal.getSaldoRegistro(apertura.getNroMov());
		montoR = (montoR == null ? BigDecimal.ZERO : montoR);
		BigDecimal suma = new BigDecimal(0);
		suma = montoP.add(pago.getHaberMo().subtract(pago.getDebeMo()));

		if (suma.compareTo(BigDecimal.valueOf(0)) < 0) {
			throw new AladiException("SUMA_EMISIONES_NEGATIVO", new Object[] { suma.toPlainString(), apertura.getNroReembLiteral() });
		}
		if (montoP.compareTo(montoR) > 0) {
			throw new AladiException("EMISIONES_MENOR_A_DEBREEM", new Object[] { montoR.toPlainString(), montoP.toPlainString() });
		}
		AperturaServiceLocal aperturaService = new AperturaServiceBean(getEntityManager());
		BigDecimal saldo = aperturaService.getAperturaLocal().getSaldo(apertura.getNroMov());

		if (saldo.compareTo(BigDecimal.valueOf(0)) < 0) {
			throw new AladiException("IMPORTE_MAYOR_SALDO", new Object[] { saldo.toPlainString(), apertura.getNroReembLiteral() });
		}

		result = true;
		return result;
	}

	
	public Pago modificar(Pago pago, Apertura apertura) {
		log.info("Entrando a modificar debito reembolso: nromovape[" + pago.getNroMov() + "] nuevoestado[" + pago.getCveEstadoPago() + "]");
		if (pago.getNroMov() == null || pago.getNroMov().compareTo(Integer.valueOf(0)) <= 0) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Codigo de pago NULO o invalido" });
		}

		if (pago.getCveEstadoPago() == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Codigo estado pago NULO" });
		}
		String cveEstadoPago = pago.getCveEstadoPago().trim();
		Pago pagoOld = pagoLocal.findById(pago.getNroMov(), false);

		if (pagoOld == null) {
			throw new AladiException("PAGO_INEXISTENTE", new Object[] { pago.getNroMov() });
		}
		if (pagoOld.getCveEstadoPago().equals("C") || pagoOld.getCveEstadoPago().equals("R")) {
			throw new AladiException("REEMDEB_NO_VALIDO_PARA_MODIF", new Object[] { pagoOld.getNroMov().toString(), pagoOld.getCveEstadoPago(),
					apertura.getNroReembLiteral() });
		}

		// las modificaciones de datos deben existir en estado P si es otro
		// estado se supone que antes ya se valido los datos
		if (pagoOld.getCveEstadoPago().trim().equals("P") && cveEstadoPago.equals("P")) {
			pagoOld.setDebeMo(pago.getDebeMo());
			pagoOld.setHaberMo(pago.getHaberMo());
			pagoOld.setInstitucion(pago.getInstitucion());
			pagoOld.setInstrumento(pago.getInstrumento());
			pagoOld.setFechaReg(pago.getFechaReg());
			pagoOld.setGlosa(pago.getGlosa());
			pagoOld.setNit(pago.getNit());
			AperturaServiceLocal aperturaService = new AperturaServiceBean(getEntityManager());
			String nit = aperturaService.obtenerNIT(apertura, pago.getNit(), pagoOld.getInstitucion().getCodInst(), "P");
			pagoOld.setNit(nit);
		} else if (cveEstadoPago.equals("R")) {
			pagoOld.setCveEstadoPago(cveEstadoPago);
			pagoOld = pagoLocal.makePersistent(pagoOld);
			pagoLocal.flush();
			return pagoOld;
		}
		// bug: se autoriza automaticamente desde el usuario
		// se verifica si la operacion es exportacion y el estado es C el
		// usuario que genera debe ser del BCB
		if (apertura.getCveTipoApe().trim().equals("E") && cveEstadoPago.equals("C")
				&& !UserSessionHolder.get("codIFARequest").toString().trim().equals("900")) {
			if (pagoOld.getCveEstadoPago().trim().equals("1")) {
				throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "La operacion ya fue pre-autorizada" });
			}
			throw new AladiException("ERROR_DE_VALIDACION",
					new Object[] { "Operacion no valida, revise el estado de la operacion, posible reenvio de datos" });
		}

		if ((pagoOld.getCveEstadoPago().trim().equals("P") && cveEstadoPago.equals("C"))
				|| (pagoOld.getCveEstadoPago().trim().equals("1") && cveEstadoPago.equals("C"))) {
			// si se pasa a un estado de contabilizacion
			log.info("Contabilizando Pago " + pagoOld.toString());
			pagoOld.setFechaCargo(new Date());
			pagoOld.setCveEstadoPago(cveEstadoPago);
			pagoOld = pagoLocal.makePersistent(pagoOld);
			pagoLocal.flush();

			// tarea adicional si no hay problemas marcamos el plan de pagos
			// marcamos en el plan de pagos como cancelado, las operaciones
			// canceladas pueden extornarse
			PlanPagoBean planPagoBean = new PlanPagoBean();
			planPagoBean.setEntityManager(getEntityManager());

			List<PlanPago> planPagoList = planPagoBean.findPlanPagos(apertura.getNroMov(), null, pagoOld.getFechaReg());
			for (PlanPago planPago : planPagoList) {
				if (planPago.getNroMovK() != null && planPago.getNroMovK().equals(pagoOld.getNroMov())) {
					planPago.setCveEstadoPlan("C");
					planPago = planPagoBean.makePersistent(planPago);
				}
				if (planPago.getNroMovI() != null && planPago.getNroMovI().equals(pagoOld.getNroMov())) {
					planPago.setCveEstadoPlan("C");
					planPago = planPagoBean.makePersistent(planPago);
				}
			}
			planPagoBean.flush();
			pagoLocal.flush();

			registroWSPorExport(pagoOld, apertura);
			pagoLocal.flush();

			if (apertura.getCveTipoApe().trim().equals("I")) {
				// solo cuando se aprueba un debito
				Object[] parameters = new Object[] { "Reembolso: " + apertura.getNroReembLiteral() + "\nMonto: "
						+ pagoOld.getDebeMo().add(pagoOld.getHaberMo()) };
				MsgLogic.envioMail(getEntityManager(), "REGISOPERACION", (apertura.getCveTipoApe().trim().equals("I") ? apertura.getInstitucion()
						.getCodInst() : pagoOld.getInstitucion().getCodInst()), "Dobito Autorizado", false, parameters);
			}
			return pagoOld;
		} else {
			isValidData(pagoOld, apertura);
			boolean enviarMail = false;
			if (apertura.getCveTipoApe().trim().equals("E")) {
				if (pagoOld.getCveEstadoPago().trim().equals("P") && cveEstadoPago.equals("1")) {
					enviarMail = true;
				}
			}
			// intentar crear el plan de pago al crear registro reembolso solo
			// para export
			// controlar que nrosecreemb al recivir debito no se sobreescriba
			// debe ser el que se recibe
			pagoOld = controlConPlanPagos(pagoOld, apertura);
			pagoOld.setCveEstadoPago(cveEstadoPago);
			pagoOld = pagoLocal.makePersistent(pagoOld);
			pagoLocal.flush();

			if (enviarMail) {
				Object[] parameters = new Object[] { "Reembolso: " + apertura.getNroReembLiteral() + "\nMonto: "
						+ pagoOld.getDebeMo().add(pagoOld.getHaberMo()) };
				MsgLogic.envioMail(getEntityManager(), "REGISOPERACION", (apertura.getCveTipoApe().trim().equals("I") ? apertura.getInstitucion()
						.getCodInst() : pagoOld.getInstitucion().getCodInst()), "Reembolso Autorizado IFA", false, parameters);
			}
			return pagoOld;
		}
	}

	
	public void eliminar(Pago pago, Apertura apertura) {
		Movimiento movimiento = null;

		if (pago == null) {
			throw new AladiException("OBJETO_NULO", new Object[] { "pago" });
		}

		if (pago.getNroMov() == null || pago.getNroMov().compareTo(Integer.valueOf(0)) <= 0) {
			throw new AladiException("CODIGO_NRO_MOV_NULO", new Object[] { "pago" });
		}

		Pago pagoOld = pagoLocal.findById(pago.getNroMov(), false);

		if (pagoOld == null) {
			throw new AladiException("PAGO_INEXISTENTE", new Object[] { pago.getNroMov() });
		}

		if (pagoOld.getCveEstadoPago().equals("C")) {
			throw new AladiException("PAGO_INVALIDO_BAJA", new Object[] { pago.getNroMov() });
		}
		MovimientoServiceLocal movimientoService = new MovimientoServiceBean(getEntityManager());
		movimiento = movimientoService.getMovimientoLocal().getByNroMov(pago.getNroMov());

		if (movimiento.getFechoraRegaladi() != null) {
			throw new AladiException("PAGO_INVALIDO_BAJA", new Object[] { pago.getNroMov() });
		}

		if (!pagoOld.getNroMovApe().equals(apertura.getNroMov())) {
			throw new AladiException("PAGO_INEXISTENTE", new Object[] { pago.getNroMov() });
		}

		PlanPagoBean planPagoBean = new PlanPagoBean();
		planPagoBean.setEntityManager(getEntityManager());

		List<PlanPago> planPagoList = planPagoBean.findPlanPagos(apertura.getNroMov(), null, pago.getFechaReg());
		for (PlanPago planPago : planPagoList) {
			if (planPago.getNroMovK() != null && planPago.getNroMovK().equals(pago.getNroMov())) {
				planPago.setNroMovK(null);
				planPago = planPagoBean.makePersistent(planPago);
			}
			if (planPago.getNroMovI() != null && planPago.getNroMovI().equals(pago.getNroMov())) {
				planPago.setNroMovI(null);
				planPago = planPagoBean.makePersistent(planPago);
			}
		}
		planPagoBean.flush();

		EstadoMovLocal estadoMovLocal = new EstadoMovBean();
		estadoMovLocal.setEntityManager(getEntityManager());
		List<EstadoMov> estadoMovList = estadoMovLocal.getByNroMovEstado(pago.getNroMov(), null);
		// se verifica que los cambios de estado que haya realizado no fueron
		// importantes
		if (estadoMovList.size() > 0) {
			for (EstadoMov estadoMov : estadoMovList) {
				if (!estadoMov.getId().getCveEstadoMov().trim().equals("P")) {
					throw new AladiException("PAGO_INVALIDO_BAJA", new Object[] { pago.getNroMov() });
				}
			}
		}

		pagoLocal.makeTransient(pagoOld);
		pagoLocal.flush();

		// movimientoService.getMovimientoLocal().makeTransient(movimiento);
	}

	
	public Pago registrarPagoImport(TPagoImp tPagoImp, boolean isProcesoAutomatico) {

		log.info("Inicio registrarPagoImport " + tPagoImp.getNroReg() + " " + tPagoImp.getCodInstrumento() + " " + tPagoImp.getNroDebito());

		AperturaServiceLocal aperturaService = new AperturaServiceBean(getEntityManager());
		Apertura apertura = null;
		if (tPagoImp.getCodInstrumento().trim().equals("EXT") && tPagoImp.getCodId().trim().equals("9")) {
			Pago pago = new Pago();
			// si es extorno
			String nroReemb = tPagoImp.getObs().trim();
			String codInst = nroReemb.substring(0, 4);
			String codId = nroReemb.substring(4, 5);
			String anio = nroReemb.substring(5, 9);
			String secuencia = nroReemb.substring(9, 15);
			Integer dav = 0;
			try {
				dav = Integer.valueOf(nroReemb.substring(15, 16));
			} catch (Exception e) {
				dav = NumeroDAV.generaDAV(codInst, codId, anio, secuencia);
			}
			String corr = nroReemb.substring(16, 20);
			String nroReembolso = tPagoImp.getCodInst().trim() + tPagoImp.getCodId().trim() + tPagoImp.getAnio().trim()
					+ tPagoImp.getSecuencia().trim();
			log.info("registrando EXTORNO debito con nro reembolso " + nroReembolso + " para nro reembolso original a afectar: " + nroReemb
					+ " con datos: " + tPagoImp.toString());

			apertura = aperturaService.getAperturaLocal().findByCodReembolso(codInst, codId, anio, secuencia, dav, false);

			if (apertura == null) {
				throw new AladiException("REEMBOLSO_INEXISTENTE", new Object[] { nroReembolso });
			}

			nroReembolso = apertura.getNroReembLiteral();

			Pago pagoOld = pagoLocal.findByPagoImport(apertura.getNroMov(), tPagoImp.getNroDebito(), tPagoImp.getCodInstrumento().trim(), null, null);

			if (pagoOld != null) {
				log.info("REEMBOLSO REGISTRADO: " + nroReembolso + " DEBITO: " + tPagoImp.getNroDebito() + " INSTRUMENTO: "
						+ tPagoImp.getCodInstrumento());
				if (!isProcesoAutomatico)
					throw new AladiException("NRO_REEMBOLSO_REGISTRADO", new Object[] { nroReembolso, tPagoImp.getNroDebito(),
							tPagoImp.getCodInstrumento() });
				else
					return null;
			}

			InstrumentoLocal instrumentoLocal = new InstrumentoBean();
			instrumentoLocal.setEntityManager(getEntityManager());

			InstitucionLocal institucionLocal = new InstitucionBean();
			institucionLocal.setEntityManager(getEntityManager());

			pago.setNroDebito(tPagoImp.getNroDebito());
			pago.setInstrumento(instrumentoLocal.findById(tPagoImp.getCodInstrumento(), false));
			pago.setInstitucion(institucionLocal.findById(tPagoImp.getCodInstRecep(), false));
			pago.setFechaCargo(tPagoImp.getFecha1());
			pago.setFechaReg(tPagoImp.getFecha2());
			pago.setDebeMo((tPagoImp.getMontoMo().compareTo(BigDecimal.ZERO) < 0) ? tPagoImp.getMontoMo().abs() : BigDecimal.ZERO);
			pago.setHaberMo((tPagoImp.getMontoMo().compareTo(BigDecimal.ZERO) > 0) ? tPagoImp.getMontoMo().abs() : BigDecimal.ZERO);
			pago.setNroExtorno(codInst + codId + anio + secuencia + dav + tPagoImp.getCorr());
			try {
				pago.setNroSecReemb(Integer.valueOf(corr));
			} catch (Exception e) {
			}

			String nit = aperturaService.obtenerNIT(apertura, pago.getNit(), pago.getInstitucion().getCodInst(), "P");
			pago.setNit(nit);
			// se registra la hora de ingreso a la base del debito
			pago.setHoraingdebito(new Date());

			MovimientoServiceLocal movimientoService = new MovimientoServiceBean(getEntityManager());
			Integer nroMov = null;
			Movimiento movimiento = null;
			movimiento = movimientoService.crearMovimiento("P", apertura.getCodMoneda(), new Date(), apertura.getNroMov());
			nroMov = movimiento.getNroMov();

			if (movimiento == null || nroMov == null || nroMov <= 0) {
				throw new AladiException("ERROR_GENERANDO_NRO_MOV", new Object[] { apertura.getNroReembLiteral() });
			}

			pago.setNroMovApe(apertura.getNroMov());
			pago.setNroMov(nroMov);
			pago.setCveEstadoPago("P");
			pago = pagoLocal.makePersistent(pago);
			pagoLocal.flush();

			Object[] parameters = new Object[] { "Reembolso: " + apertura.getNroReembLiteral() + "\nMonto: " + tPagoImp.getMontoMo() };
			MsgLogic.envioMail(getEntityManager(), "REGISOPERACION", (apertura.getCveTipoApe().trim().equals("I") ? apertura.getInstitucion()
					.getCodInst() : pago.getInstitucion().getCodInst()), "Extorno registrado", true, parameters);
			log.info("creado registro pago con nro mov " + pago.getNroMov());

			return pago;
		} else if (tPagoImp.getCodInstrumento().trim().equals("LEX") && tPagoImp.getCodId().trim().equals("9")) {
			// los debitos llegado como LEX son solo validos para importacion
			String nroReembolso = tPagoImp.getCodInst().trim() + tPagoImp.getCodId().trim() + tPagoImp.getAnio().trim()
					+ tPagoImp.getSecuencia().trim() + tPagoImp.getDav() + tPagoImp.getCorr();

			RegAnticipadoBean regAnticipadoBean = new RegAnticipadoBean();
			regAnticipadoBean.setEntityManager(getEntityManager());

			// buscamos si ya fue liquidado en registros anticipados
			RegAnticipado regAnticipadoOld = regAnticipadoBean.findByCodReembolsoAladi("I", nroReembolso, "L", tPagoImp.getNroDebito(),
					tPagoImp.getCodInstrumento());

			if (regAnticipadoOld != null) {
				// el nro reembolso ALADI esta registrado
				log.info("PAGO ANTICIPADO REGISTRADO: " + nroReembolso + " DEBITO: " + tPagoImp.getNroDebito() + " INSTRUMENTO: "
						+ tPagoImp.getCodInstrumento());
				if (!isProcesoAutomatico)
					throw new AladiException("NRO_REEMBOLSO_REGISTRADO", new Object[] { nroReembolso, tPagoImp.getNroDebito(),
							tPagoImp.getCodInstrumento() });
				else
					return null;
			}

			log.info("registrando pago anticipado con nro reembolso " + nroReembolso + " para nro debito : " + tPagoImp.getNroDebito()
					+ " con datos: " + tPagoImp.toString());

			// se busca el nro reembolso que se genero con el numero fuicticio
			// verificar que el registro haya sido registrado anteriormente con
			// nro reembolso ficticio
			regAnticipadoOld = regAnticipadoBean.getRegistroFicticio("I", tPagoImp.getCodInstRecep(), tPagoImp.getMontoMo(), tPagoImp.getFecha2(),
					"C", tPagoImp.getCodInstrumento().trim(), "D");
			// si es ale en obs esta la operacion original que se revierte
			if (regAnticipadoOld == null) {
				// no existe un registro ficticio por lo tanto no se puede
				// matchear si no existe el reembolso quiere decir que no fue
				// registrado el instrumento
				// o ya es UN ERROR y el mismo fue corregido con un ALE
				// para ello primero buscamos en el historico si tiene un ALE

				TPagoImpBean tPagoImpBean = new TPagoImpBean();
				tPagoImpBean.setEntityManager(getEntityManager());
				TPagoImp tPagoImpALE = tPagoImpBean.findALEofLEX("ALE", tPagoImp.getMontoMo(), nroReembolso.concat("LEX"));

				if (tPagoImpALE != null) {
					log.info("la operacion de LEX " + tPagoImp.getNroReg() + " tiene su ALE en tPagoImp nro mov " + tPagoImpALE.getNroReg()
							+ " no hacemos nada");
					return null;
				}

				log.error("Reembolso " + nroReembolso + " inexistente, posiblemente no exista o este en estado diferente a contabilizado");
				throw new AladiException("REEMBOLSO_INEXISTENTE", new Object[] { nroReembolso });
			}
			// es de importacion ya que en exportacion no llegan en debitos
			regAnticipadoOld.setCveEstadoAnt("L");
			regAnticipadoOld.setSecuencia(tPagoImp.getSecuencia());
			regAnticipadoOld.setFechaVal(tPagoImp.getFecha1());
			regAnticipadoOld.setNroDebito(tPagoImp.getNroDebito());
			regAnticipadoOld.setNroReembolso(nroReembolso);
			regAnticipadoOld.setDav(NumeroDAV.generaDAV(regAnticipadoOld.getCodInst(), regAnticipadoOld.getCodId(), regAnticipadoOld.getAnio(),
					regAnticipadoOld.getSecuencia()));

			regAnticipadoOld = regAnticipadoBean.makePersistent(regAnticipadoOld);
			regAnticipadoBean.flush();

			Object[] parameters = new Object[] { "Reembolso: " + regAnticipadoOld.getNroReembLiteral() + "\nMonto: " + tPagoImp.getMontoMo() };
			MsgLogic.envioMail(getEntityManager(), "REGISOPERACION", regAnticipadoOld.getCodInstRecep(), "LEX registrado", false, parameters);

			return null;

		} else if (tPagoImp.getCodInstrumento().trim().equals("ALE") && tPagoImp.getCodId().trim().equals("9")) {
			// un ALE es una anulacion de un LEX por lo tanto no se registra en
			// reg_anicipado
			// solo se registra en tPagoImp para control de anulaciones y no
			// envios de correos
			String nroReembolso = tPagoImp.getCodInst().trim() + tPagoImp.getCodId().trim() + tPagoImp.getAnio().trim()
					+ tPagoImp.getSecuencia().trim() + tPagoImp.getCorr();

			// se debe buscar si el lex que se esta anulando existe
			TPagoImpBean tPagoImpBean = new TPagoImpBean();
			tPagoImpBean.setEntityManager(getEntityManager());

			String codInstLex = tPagoImp.getObs().substring(0, 4);
			String codIdLex = tPagoImp.getObs().substring(4, 5);
			String anioLex = tPagoImp.getObs().substring(5, 9);
			String secuenciaLex = tPagoImp.getObs().substring(9, 15);
			String davLex = tPagoImp.getObs().substring(15, 16);
			String corrLex = tPagoImp.getObs().substring(16, 20);
			String codInsLex = tPagoImp.getObs().substring(20).trim();

			TPagoImp tPagoImpLex = tPagoImpBean.findLEXofALE("LEX", codInstLex, codIdLex, anioLex, secuenciaLex, Integer.valueOf(davLex), corrLex,
					tPagoImp.getMontoMo());

			if (tPagoImpLex == null) {
				// no existe un registro de operacion a revertir registrado
				throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Registro de operacion ALE [" + nroReembolso + "] sin su operacion ["
						+ codInsLex + "] registrado:  " + tPagoImp.getObs() });

			}

			log.info("operacion ALE " + tPagoImp.getNroReg() + " con su LEX registrado " + tPagoImpLex.getNroReg()
					+ " en la base aladi se registra solo en tPagoImp con datos: " + tPagoImp.toString());

			return null;
		} else {
			Pago pago = new Pago();
			String nroReembolso = tPagoImp.getCodInst() + "-" + tPagoImp.getCodId() + "-" + tPagoImp.getAnio() + "-" + tPagoImp.getSecuencia();
			log.info("registrando debito para nro reembolso: " + nroReembolso + " con datos: " + tPagoImp.toString());

			apertura = aperturaService.getAperturaLocal().findByCodReembolso(tPagoImp.getCodInst(), tPagoImp.getCodId(), tPagoImp.getAnio(),
					tPagoImp.getSecuencia(), tPagoImp.getDav(), false);

			if (apertura == null) {
				log.info("Apertura INEXISTENTE para nro reembolso: " + nroReembolso + " con datos: " + tPagoImp.toString());
				registroTPagoImp(tPagoImp);
				throw new AladiException("REEMBOLSO_INEXISTENTE", new Object[] { nroReembolso });
			}

			nroReembolso = apertura.getNroReembLiteral();
			Integer corr = 0;
			if (!StringUtils.isBlank(tPagoImp.getCorr())) {
				if (NumberUtils.isNumber(tPagoImp.getCorr())) {
					corr = Integer.valueOf(tPagoImp.getCorr().trim());
				}
			}
			Pago pagoOld = pagoLocal.findByPagoImport(apertura.getNroMov(), tPagoImp.getNroDebito(), tPagoImp.getCodInstrumento(),
					tPagoImp.getMontoMo(), corr);
			if (pagoOld != null) {
				if (!isProcesoAutomatico)
					throw new AladiException("NRO_REEMBOLSO_REGISTRADO", new Object[] { nroReembolso, tPagoImp.getNroDebito(),
							tPagoImp.getCodInstrumento() });
				else {
					log.info("el debito ya fue registrado nro mov pago " + pagoOld.getNroMov() + " datos debito" + tPagoImp.toString());
					return null;
				}
			}

			InstrumentoLocal instrumentoLocal = new InstrumentoBean();
			instrumentoLocal.setEntityManager(getEntityManager());

			InstitucionLocal institucionLocal = new InstitucionBean();
			institucionLocal.setEntityManager(getEntityManager());

			pago.setNroDebito(tPagoImp.getNroDebito());
			pago.setInstrumento(instrumentoLocal.findById(tPagoImp.getCodInstrumento(), false));
			pago.setInstitucion(institucionLocal.findById(tPagoImp.getCodInstRecep(), false));
			pago.setFechaCargo(tPagoImp.getFecha1());
			pago.setFechaReg(tPagoImp.getFecha1());
			pago.setDebeMo((tPagoImp.getMontoMo().compareTo(BigDecimal.ZERO) < 0) ? tPagoImp.getMontoMo().abs() : BigDecimal.ZERO);
			pago.setHaberMo((tPagoImp.getMontoMo().compareTo(BigDecimal.ZERO) > 0) ? tPagoImp.getMontoMo().abs() : BigDecimal.ZERO);
			pago.setNroExtorno(tPagoImp.getObs());
			pago.setNroSecReemb(corr);

			String nit = aperturaService.obtenerNIT(apertura, pago.getNit(), pago.getInstitucion().getCodInst(), "P");
			pago.setNit(nit);

			// se registra la hora de ingreso a la base del debito
			pago.setHoraingdebito(new Date());

			MovimientoServiceLocal movimientoService = new MovimientoServiceBean(getEntityManager());
			Movimiento movimiento = movimientoService.crearMovimiento("P", apertura.getCodMoneda(), new Date(), apertura.getNroMov());
			Integer nroMov = movimiento.getNroMov();

			if (nroMov == null || nroMov <= 0) {
				throw new AladiException("ERROR_GENERANDO_NRO_MOV", new Object[] { apertura.getNroReembLiteral() });
			}
			pago.setNroMovApe(apertura.getNroMov());
			pago.setNroMov(nroMov);
			pago.setCveEstadoPago("P");

			pago = pagoLocal.makePersistent(pago);
			pagoLocal.flush();

			Object[] parameters = new Object[] { "Reembolso: " + nroReembolso + "\nMonto: " + tPagoImp.getMontoMo() };
			MsgLogic.envioMail(getEntityManager(), "REGISOPERACION", apertura.getInstitucion().getCodInst(), "Debito registrado", true, parameters);
			log.info("creado registro pago con nro mov " + pago.toString());
			return pago;
		}
	}

	public void eliminarPagoImport(TPagoImp tPagoImp) {
		if (tPagoImp == null) {
			throw new AladiException("OBJETO_NULO", new Object[] { "tPagoImp" });
		}

		TPagoImpBean tPagoImpBean = new TPagoImpBean();
		tPagoImpBean.setEntityManager(getEntityManager());

		if (tPagoImp.getNroReg() == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Valor de codigo de registro nulo" });
		}
		TPagoImp tPagoImpOld = tPagoImpBean.findById(tPagoImp.getNroReg(), false);

		if (tPagoImpOld == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "registro nro " + tPagoImp.getNroReg() + " inexistente" });
		}
		tPagoImpBean.makeTransient(tPagoImpOld);
		tPagoImpBean.flush();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gob.bcb.bpm.siraladi.logic.PagoServiceLocal#registrarPagoImport(java.
	 * util.List)
	 */
	
	public List<Pago> registrarPagoImport(List<TPagoImp> tPagoImpList, boolean isProcesoAutomatico) {
		log.info("Inicio de registro de Pagos por importacion registrarPagoImport " + tPagoImpList.size());

		// ciclo para guardar en la tabla temporal TPagoImp todo lo que se
		// consulta a SICAP

		List<TPagoImp> tPagoImpListTempo = new ArrayList<TPagoImp>();
		List<Pago> pagoList = new ArrayList<Pago>();
		for (TPagoImp tPagoImp : tPagoImpList) {
			TPagoImp tPagoImpNew = null;
			// String nroReembolso = tPagoImp.getCodInst() + "-" +
			// tPagoImp.getCodId() + "-" + tPagoImp.getAnio() + "-" +
			// tPagoImp.getSecuencia();
			try {
				begin();
				tPagoImpNew = registroTPagoImp(tPagoImp);
				commit();
				log.info("Registro de consulta " + tPagoImpNew.toString());
				tPagoImpListTempo.add(tPagoImpNew);
			} catch (Exception e) {
				try {
					rollback();
				} catch (SystemException e1) {
					log.error("Error al realizar rollback en base de datos : " + e1.getMessage(), e1);
				}
			}
		}

		// ciclo que depura ALE

		// ciclo que registra efectivamente en las tablas transaccionales
		for (TPagoImp tPagoImpNew : tPagoImpListTempo) {
			String nroReembolso = tPagoImpNew.getCodInst() + "-" + tPagoImpNew.getCodId() + "-" + tPagoImpNew.getAnio() + "-"
					+ tPagoImpNew.getSecuencia();
			try {

				begin();
				Pago pago = registrarPagoImport(tPagoImpNew, isProcesoAutomatico);
				if (pago != null)
					pagoList.add(pago);

				if (!tPagoImpNew.getCodInstrumento().trim().equals("LEX") && !tPagoImpNew.getCodInstrumento().trim().equals("ALE")) {
					// no se eliminan operaciones de LEX ni ALE ya que estos se
					// deben controlar cuando lleguen
					eliminarPagoImport(tPagoImpNew);
				}
				commit();

			} catch (Exception e) {
				try {
					rollback();
				} catch (SystemException e1) {
					log.error("Error al realizar rollback en base de datos : " + e1.getMessage(), e1);
				}
				log.error("Error en registrarPagoImport : " + e.getMessage(), e);
				Object[] parameters = new Object[] { "Reembolso: " + nroReembolso + "\nMonto: " + tPagoImpNew.getMontoMo() + "\nNro Dobito: "
						+ tPagoImpNew.getNroDebito() + "\nConvenio: " + tPagoImpNew.getCodPais() + "\nCodigo Interno: " + tPagoImpNew.getNroReg()
						+ "\nError Reportado: " + e.getMessage() };
				MsgLogic.envioMail(getEntityManager(), "REGISOPERACION", tPagoImpNew.getCodInstRecep(), "Operacion NO registrada", false, parameters);
				if (!isProcesoAutomatico)
					throw new AladiException("ERROR_DE_SISTEMA", new Object[] { e.getMessage() });
			}
		}
		return pagoList;
	}

	
	public void registroWSPorExport(Pago pago, Apertura apertura) {
		log.info("Inicio registroWSPorExport " + pago.toString());
		String tipoOperacion = "RE";
		String nroReembolso = "";
		Integer secNroreembolso = pago.getNroSecReemb();
		if (pago.getCveEstadoPago().trim().equals("C") && apertura.getCveTipoApe().trim().equals("E")) {
			Date fecPagoOValor = pago.getFechaReg();
			String obs = "";
			nroReembolso = apertura.getNroReembLiteral(true);
			if (pago.getInstrumento().getCodInstrumento().trim().equals("OP")) {
				fecPagoOValor = pago.getFechaReg();
			}
			if (pago.getInstrumento().getCodInstrumento().trim().equals("EXT") || pago.getInstrumento().getCodInstrumento().trim().equals("AEX")
					|| pago.getInstrumento().getCodInstrumento().trim().equals("ALE")
					|| pago.getInstrumento().getCodInstrumento().trim().equals("AUM")) {
				// sero obligatorio cuando se registre un extorno (EXT) y las
				// anulaciones de croditos (AEX, ALE y AUM) en los que se
				// debero colocar el reembolso e instrumento original.
				// en el cliente en el campo nroExtorno se arma el contenido con
				// el nro de reembolso + codInstrumneto
				obs = pago.getNroExtorno();
				nroReembolso = String.format("%04d", Integer.valueOf(apertura.getInstitucion().getCodInst()));
				nroReembolso = nroReembolso.concat("9");
				nroReembolso = nroReembolso.concat(String.format("%04d", (Integer.valueOf(apertura.getAnio().trim()))));
				// nroReembolso = nroReembolso.concat(String.format("%06d",
				// (Integer.valueOf(apertura.getSecuencia().trim()))));
				nroReembolso = nroReembolso.concat(String.format("%06d", pago.getNroMov()));
				nroReembolso = nroReembolso.concat(String.format("%01d",
						NumeroDAV.generaDAV(String.format("%04d", Integer.valueOf(apertura.getInstitucion().getCodInst())), "9",
						// String.format("%04d",
						// (Integer.valueOf(apertura.getAnio().trim()))),
						// String.format("%06d",
						// (Integer.valueOf(apertura.getSecuencia().trim()))))));
								String.format("%04d", (Integer.valueOf(apertura.getAnio().trim()))), String.format("%06d", pago.getNroMov()))));
				secNroreembolso = 0;
			}
			if (!apertura.getIdentificador().getCodId().trim().equals("1") && !apertura.getIdentificador().getCodId().trim().equals("5")) {
				// las Cartas de credito tienen negociacion pero el resto no
				// y cuando se registra el nro de reembolso es cero
				secNroreembolso = 0;
			}
			BigDecimal monto = new BigDecimal(0);
			if (pago.getHaberMo().compareTo(pago.getDebeMo()) > 0) {
				// si haber es mayor a debe proceso normal
				monto = pago.getHaberMo().subtract(pago.getDebeMo());
			} else {
				// verificamos que sea un extorno
				if (pago.getInstrumento().getCodInstrumento().trim().equals("EXT")) {
					monto = pago.getHaberMo().subtract(pago.getDebeMo());
				} else {
					throw new AladiException("ERROR_DE_VALIDACION",
							new Object[] { "El monto a enviar es negativo y no es un extorno. Revise los datos" });
				}
			}

			RespWSAladi respWSAladi = ClientAladiWSHandler.execWSSicapRcaoc(nroReembolso, pago.getInstitucion().getCodInst(), apertura
					.getInstitucion().getPais().getCodPais(), pago.getInstrumento().getCodInstrumento(), fecPagoOValor, monto, obs, "0000",
					secNroreembolso);
			try {
				pago.setNroDebito((Integer) respWSAladi.getDatosAdicionales().get("nroDeb"));
				pago.setFechaReg(respWSAladi.getFechaHoraReg());

			} catch (Exception e) {
			}
			MovimientoServiceLocal movimientoService = new MovimientoServiceBean(getEntityManager());
			movimientoService.actualizarRegAladi(pago.getNroMov(), tipoOperacion + ":Sicap:Rcaoc", respWSAladi.getFechaHoraReg());
		}
	}

	/**
	 * controla que exista en plan de pagos registrado el monto del debito o
	 * reembolso pero solo se controla para las operaciones que se emiten y
	 * negocian(los instrumentos con identificador 1) y que sean posteriores a
	 * la fecha de corte y es de exportacion
	 * 
	 * @param pago
	 * @param apertura
	 * @return
	 */
	public Pago controlConPlanPagos(Pago pago, Apertura apertura) {
		// al contabilizar si n esta negociado negociar inmediatamente
		// si esta negociado recuperar el nrosecreem de plan de pagos
		if (!pago.getInstrumento().getCodInstrumento().trim().equals("CG")
				&& (apertura.getIdentificador().getCodId().trim().equals("1") || apertura.getIdentificador().getCodId().trim().equals("5"))
				&& apertura.getCveTipoApe().trim().equals("E")) {
			// control que el pago o reembolso exista en el plan de pago
			if (!pago.getInstrumento().getCodInstrumento().trim().equals("EXT") && !pago.getInstrumento().getCodInstrumento().trim().equals("AEX")
					&& !pago.getInstrumento().getCodInstrumento().trim().equals("ALE")
					&& !pago.getInstrumento().getCodInstrumento().trim().equals("AUM")) {

				PlanPagoBean planPagoBean = new PlanPagoBean();
				planPagoBean.setEntityManager(getEntityManager());

				pago.setHaberMo(pago.getHaberMo().setScale(2, BigDecimal.ROUND_HALF_UP));

				List<PlanPago> planPagoList = planPagoBean.findPlanPagos(apertura.getNroMov(), null, pago.getFechaReg());
				log.info("===== PLAN " + planPagoList.size() + " : " + apertura.getNroMov() + " : " + pago.getFechaReg() + " : "
						+ pago.getInstrumento().getCodInstrumento() + " : " + (pago.getInstrumento().getCodInstrumento().trim() + "I"));
				boolean found = false;
				// buscamos en plan de pagos el registro del cobro respectivo
				// por fecha y monto
				if (!pago.getInstrumento().getCodInstrumento().trim().equals("CDI")
						&& !pago.getInstrumento().getCodInstrumento().trim().equals("CCI")
						&& !pago.getInstrumento().getCodInstrumento().trim().equals("ODI")
						&& !pago.getInstrumento().getCodInstrumento().trim().equals("LAI")) {
					// el concepto es diferente a Intereses se compara
					// capital
					for (PlanPago pPago : planPagoList) {
						if (pago.getNroSecReemb() != null && pago.getNroSecReemb() > 0) {
							// si es dif a nulo y mayor a cero nos aseguramos
							// que en
							// plan exista el codigo y este habilitado

							if (pPago.getNroMovK() != null
									&& pago.getNroSecReemb().equals(pPago.getNroSecReemb())
									&& (pPago.getCapital().compareTo(pago.getHaberMo()) == 0)
									&& (pPago.getNroMovK().equals(pago.getNroMov()))
									&& (pPago.getCveEstadoPlan().equals("N") || pPago.getCveEstadoPlan().equals("C") || pPago.getCveEstadoPlan()
											.equals("E")) && (pPago.getFechoraRegaladi() != null)) {
								// si esta negociado y tiene la fecha de
								// registro en aladi el registro del plan de
								// pagos es el correcto
								found = true;
								break;
							}
						}

						if (pPago.getNroMovK() == null) {
							if ((pPago.getCapital().compareTo(pago.getHaberMo()) == 0)
									&& (pPago.getCveEstadoPlan().equals("N") || pPago.getCveEstadoPlan().equals("C") || pPago.getCveEstadoPlan()
											.equals("E")) && (pPago.getFechoraRegaladi() != null)) {
								found = true;
								pPago.setNroMovK(pago.getNroMov());
								pPago = planPagoBean.makePersistent(pPago);
								pago.setNroSecReemb(pPago.getNroSecReemb());
								planPagoBean.flush();
								log.info("debito-reembolso para capital encontrado en plan de pagos para nro mov " + pago.getNroMov()
										+ " codigo plan pareado " + pPago.getId().getNroPlan());
								break;
							}
						}
					}

					PlanPago planPago = planPagoBean.findPlanPagoByReembolso(apertura.getNroMov(), pago.getFechaReg(), pago.getHaberMo(), "K");
					if (planPago != null) {
						found = true;
						planPago.setNroMovK(pago.getNroMov());
						planPago = planPagoBean.makePersistent(planPago);
						pago.setNroSecReemb(planPago.getNroSecReemb());
						planPagoBean.flush();

						log.info("debito-reembolso para capital encontrado en plan de pagos para nro mov " + pago.getNroMov()
								+ " codigo plan pareado " + planPago.getId().getNroPlan());

					}

				} else {
					for (PlanPago pPago : planPagoList) {
						if (pago.getNroSecReemb() != null && (pago.getNroSecReemb().compareTo(Integer.valueOf(0)) > 0)) {
							// si es dif a nulo y mayor a cero nos aseguramos
							// que en
							// plan exista el codigo y este habilitado

							if (pPago.getNroMovI() != null
									&& pago.getNroSecReemb().equals(pPago.getNroSecReemb())
									&& (pPago.getInteres().compareTo(pago.getHaberMo()) == 0)
									&& (pPago.getNroMovI().equals(pago.getNroMov()))
									&& (pPago.getCveEstadoPlan().equals("N") || pPago.getCveEstadoPlan().equals("C") || pPago.getCveEstadoPlan()
											.equals("E")) && (pPago.getFechoraRegaladi() != null)) {
								// si esta negociado y tiene la fecha de
								// registro en aladi el registro del plan de
								// pagos es el correcto
								found = true;
								break;
							}
						}
						log.info("===== PLAN INTERS " + pPago.getCapital() + " : " + pPago.getCveEstadoPlan() + " : " + pago.getHaberMo());
						if (pPago.getNroMovI() == null) {
							if ((pPago.getInteres().compareTo(pago.getHaberMo()) == 0)
									&& (pPago.getCveEstadoPlan().equals("N") || pPago.getCveEstadoPlan().equals("C") || pPago.getCveEstadoPlan()
											.equals("E")) && (pPago.getFechoraRegaladi() != null)) {
								found = true;
								pPago.setNroMovI(pago.getNroMov());
								pPago = planPagoBean.makePersistent(pPago);
								pago.setNroSecReemb(pPago.getNroSecReemb());
								planPagoBean.flush();
								log.info("debito-reembolso para interes encontrado en plan de pagos para nro mov " + pago.getNroMov()
										+ " codigo plan pareado " + pPago.getId().getNroPlan());
								break;
							}
						}
					}
					PlanPago planPago = planPagoBean.findPlanPagoByReembolso(apertura.getNroMov(), pago.getFechaReg(), pago.getHaberMo(), "I");
					if (planPago != null) {
						found = true;
						planPago.setNroMovI(pago.getNroMov());
						planPago = planPagoBean.makePersistent(planPago);
						pago.setNroSecReemb(planPago.getNroSecReemb());
						planPagoBean.flush();
						log.info("debito-reembolso para capital encontrado en plan de pagos para nro mov " + pago.getNroMov()
								+ " codigo plan pareado " + planPago.getId().getNroPlan());

					}
				}

				if (!found) {
					// solo los tipos de instrumento 1 permiten plan de pagos el
					// resto es a vista
					// throw new
					// AladiException("DEBREEM_NO_DEFINIDO_EN_PLAN_PAGOS", new
					// Object[] { apertura.getNroReembLiteral(),
					// pago.getHaberMo() });
				}
			} // fin !EXT !ALE
		}
		return pago;
	}

	public TPagoImp registroTPagoImp(TPagoImp tPagoImp) {
		// no existe un registro ficticio por lo tanto no se puede
		// matchear
		// si no existe el reembolso quiere decir que no fue
		// registrado el instrumento
		TPagoImpBean tPagoImpBean = new TPagoImpBean();
		tPagoImpBean.setEntityManager(getEntityManager());

		TPagoImp tPagoImpOld = tPagoImpBean.findByNroReembolso(tPagoImp.getCodInst().trim(), tPagoImp.getCodId().trim(), tPagoImp.getAnio().trim(),
				tPagoImp.getSecuencia().trim(), tPagoImp.getDav(), tPagoImp.getNroDebito(), tPagoImp.getCodInstrumento(), tPagoImp.getCorr());

		if (tPagoImpOld != null) {
			// el registro ya fue registrado y se encuentra en la tabla temporal
			return tPagoImpOld;
		}

		TPagoImp tPagoImpMax = tPagoImpBean.getMaxMovimiento();
		Integer nroReg = 0;
		if (tPagoImpMax != null) {
			nroReg = tPagoImpMax.getNroReg();
		}
		nroReg++;

		tPagoImp.setNroReg(nroReg);
		TPagoImp tPagoImpNew = tPagoImpBean.makePersistent(tPagoImp);
		tPagoImpBean.flush();
		log.info("Registro de un nuevo debito temporal " + tPagoImp.toString());
		return tPagoImpNew;
	}

	
	public PagoLocal getPagoLocal() {
		return pagoLocal;
	}

	
	public Map<String, Object> getWarnnings() {
		return warnnings;
	}

	public static void main(String[] args) {
		BigDecimal a = new BigDecimal("9");
		a = a.setScale(2, BigDecimal.ROUND_HALF_UP);
		BigDecimal b = new BigDecimal("1.3360");

		BigDecimal c = a.subtract(b).setScale(2, BigDecimal.ROUND_HALF_UP);
		System.out.println(a + " : " + b);
		if (a.compareTo(b) > 0) {
			System.out.println("== " + a + " : " + b + " : " + c);
		} else {
			System.out.println("<> " + a + " : " + b);
		}
		Integer i = 10;
		Integer j = 11;
		System.out.println(i.equals(j) + " " + i.compareTo(j));
		Integer k = j;
		j = new Integer(10);
		System.out.println(k.equals(j) + " " + k.compareTo(j));
		int l = 10;
		System.out.println(j.equals(l) + " " + j.compareTo(l));
		//
		// Calendar fvto = GregorianCalendar.getInstance();
		// fvto.set(Calendar.DAY_OF_MONTH, 31);
		// fvto.set(Calendar.MONTH, 0);
		// fvto.set(Calendar.YEAR, 2012);
		//
		// Date vt = fvto.getTime();
		//
		// try {
		// Thread.sleep(1000);
		// } catch (InterruptedException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		// Calendar pago = GregorianCalendar.getInstance();
		// pago.set(Calendar.DAY_OF_MONTH, 31);
		// pago.set(Calendar.MONTH, 0);
		// pago.set(Calendar.YEAR, 2012);
		//
		// Date p = pago.getTime();
		// p = DateUtils.truncate(p, Calendar.DAY_OF_MONTH);
		// Calendar FechaEmis = GregorianCalendar.getInstance();
		// FechaEmis.set(Calendar.DAY_OF_MONTH, 6);
		// FechaEmis.set(Calendar.MONTH, 5);
		// FechaEmis.set(Calendar.YEAR, 2011);
		//
		// Date femis = FechaEmis.getTime();
		//
		// if (p.before(femis) || p.after(vt)) {
		// System.out.println("error");
		// }
	}
}
