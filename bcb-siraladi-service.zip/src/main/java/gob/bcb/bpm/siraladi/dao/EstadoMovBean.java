package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.EstadoMov;
import gob.bcb.bpm.siraladi.jpa.EstadoMovPK;

import java.util.Date;
import java.util.List;


import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("estadoMovLocal")
@Transactional
public class EstadoMovBean extends GenericDAO<EstadoMovPK, EstadoMov> implements EstadoMovLocal {
	
	public EstadoMov crearReg(Integer nroMov, String cveEstadoMov) {
		log.debug("Creando estado movimiento nroMov " + nroMov + " cveEstadoMov:" + cveEstadoMov);
		EstadoMovPK estadoMovPK = new EstadoMovPK();
		estadoMovPK.setCveEstadoMov(cveEstadoMov);
		estadoMovPK.setFechaHora(new Date());
		estadoMovPK.setNroMov(nroMov);

		EstadoMov estadoMov = new EstadoMov();
		estadoMov.setId(estadoMovPK);
		makePersistent(estadoMov);

		return estadoMov;

	}
	
	public List<EstadoMov> getByNroMovEstado(Integer nroMov, String cveEstado){
		String jpql = "SELECT p FROM EstadoMov p " + " WHERE p.id.nroMov = :nroMov "; 
		
		if (cveEstado != null)
			jpql += "and p.id.cveEstadoMov = :cveEstadoMov ";
		
		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("nroMov", nroMov);
		
		if (cveEstado != null)
			query.setParameter("cveEstadoMov", cveEstado);
		
		return query.getResultList();		
	}
}
