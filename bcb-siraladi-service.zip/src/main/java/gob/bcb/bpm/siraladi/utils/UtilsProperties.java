package gob.bcb.bpm.siraladi.utils;

import gob.bcb.bpm.siraladi.service.ConfigurationServ;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class UtilsProperties {
	public static Properties loadFileMsgProperties(String pathFile) {
		Properties properties = new Properties();
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(new File(pathFile));
			properties.load(fis);
		} catch (FileNotFoundException e) {
			throw new RuntimeException("Archivo de propiedades " + pathFile + " inexistente", e);
		} catch (IOException e) {
			throw new RuntimeException(e);
		} finally {
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException e) {
					// ignore
				}
			}
		}

		return properties;
	}
}
