package gob.bcb.bpm.siraladi.service;

import gob.bcb.bpm.siraladi.pojo.OperacionAladi;

import java.util.List;

/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public class ClassHandlerTOper {
	private String codClassHandler;
	private String classHandler;
	private List<OperacionAladi> operacionAladi;

	public ClassHandlerTOper() {
		
	}
	public ClassHandlerTOper(String codClassHandler, String classHandler, List<OperacionAladi> operacionAladi) {
		this.codClassHandler = codClassHandler;
		this.classHandler = classHandler;
		this.operacionAladi = operacionAladi;
	}
	
	public String findClassHandlerByCodTipoOper(String codTipoOperacion){
		
		return null;
	}
	public void setCodClassHandler(String codClassHandler) {
		this.codClassHandler = codClassHandler;
	}
	public String getCodClassHandler() {
		return codClassHandler;
	}
	public void setClassHandler(String classHandler) {
		this.classHandler = classHandler;
	}
	public String getClassHandler() {
		return classHandler;
	}
	public void setOperacionAladi(List<OperacionAladi> operacionAladi) {
		this.operacionAladi = operacionAladi;
	}
	public List<OperacionAladi> getOperacionAladi() {
		return operacionAladi;
	}
	
}
