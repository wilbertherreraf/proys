package gob.bcb.bpm.siraladi.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import gob.bcb.bpm.siraladi.exceptions.SystemInternalException;
import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Pago;
import gob.bcb.bpm.siraladi.jpa.PlanPago;
import gob.bcb.bpm.siraladi.jpa.RegAnticipado;
import gob.bcb.bpm.siraladi.jpa.Registro;
import gob.bcb.bpm.siraladi.jpa.TPagoImp;
import gob.bcb.core.jms.BcbRequest;
import gob.bcb.siraladi.xml.operaciones.Aladirequesttipo01Type;
import gob.bcb.siraladi.xml.operaciones.Aladirequesttipo02Type;
import gob.bcb.siraladi.xml.operaciones.Aladireqresptipo01Type;
import gob.bcb.siraladi.xml.operaciones.Aladireqresptipo01Type;
import gob.bcb.bpm.siraladi.pojo.SaldoConvenio;
import gob.bcb.bpm.siraladi.utils.Constants;

import java.lang.reflect.Field;
import org.apache.log4j.Logger;
import javax.persistence.EntityManager;

/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public class RequestContext {
	private static Logger log = Logger.getLogger(RequestContext.class);
	private final BcbRequest bcbRequest;
	private final ResponseContext responseContext;
	private final EntityManager entityManager;

	/**
	 * Inicializa los campos dentro de las diferentes operaciones y los inserta
	 * en un mapa, este método debe crecer y ser modificado cada vez que se
	 * modifica o agrega una nueva operacion
	 * 
	 * @param bcbRequest
	 * @param servicioRespuesta
	 * @param entityManager
	 */
	public RequestContext(BcbRequest bcbRequest, ResponseContext servicioRespuesta, EntityManager entityManager) {
		this.responseContext = servicioRespuesta;
		this.entityManager = entityManager;
		this.bcbRequest = bcbRequest;
	}

	/**
	 * Pobla el mapa de objetos contenidos en un request, dichos parametros se
	 * almacenan en bcbRequest.getRequestElements
	 */
	public void populateRequestParameters() {
		Map<String, Object> parameters = new HashMap<String, Object>();
		String codTipoOperacion = bcbRequest.getMsgbcb().getMsgsistema().getIdoperacion();
		Aladirequesttipo01Type aladirequesttipo01Type = null;
		Aladirequesttipo02Type aladirequesttipo02Type = null;
		Aladireqresptipo01Type aladireqresptipo01Type = null;
		try {
			if (bcbRequest == null) log.info("bcbRequest");
			if (bcbRequest.getMsgbcb() == null) log.info("bcbRequest.getMsgbcb()");
			if (bcbRequest.getMsgbcb().getMsgsistema() == null) log.info("bcbRequest.getMsgbcb().getMsgsistema()");
			if (bcbRequest.getMsgbcb().getMsgsistema().getContenido() == null) log.info("bcbRequest.getMsgbcb().getMsgsistema().getContenido()");
			if (bcbRequest.getMsgbcb().getMsgsistema().getContenido().getDeclaredType() == null) log.info("bcbRequest.getMsgbcb().getMsgsistema().getContenido().getDeclaredType()");
			if (bcbRequest.getMsgbcb().getMsgsistema().getContenido().getDeclaredType().getDeclaredFields() == null) log.info("bcbRequest.getMsgbcb().getMsgsistema().getContenido().getDeclaredType().getDeclaredFields()");
			
			Field[] campos = bcbRequest.getMsgbcb().getMsgsistema().getContenido().getDeclaredType().getDeclaredFields();

			if (bcbRequest.getMsgbcb().getMsgsistema().getContenido().getValue() instanceof Aladirequesttipo01Type) {
				aladirequesttipo01Type = (Aladirequesttipo01Type) bcbRequest.getMsgbcb().getMsgsistema().getContenido().getValue();
			} else if (bcbRequest.getMsgbcb().getMsgsistema().getContenido().getValue() instanceof Aladirequesttipo02Type) {
				aladirequesttipo02Type = (Aladirequesttipo02Type) bcbRequest.getMsgbcb().getMsgsistema().getContenido().getValue();
			} else if (bcbRequest.getMsgbcb().getMsgsistema().getContenido().getValue() instanceof Aladireqresptipo01Type) {
				aladireqresptipo01Type = (Aladireqresptipo01Type) bcbRequest.getMsgbcb().getMsgsistema().getContenido().getValue();
			}
			
			for (Field field : campos) {
				log.info("field.getName() "  + field.getName());
				// ------------------PARAMETROS DE OBJETO
				// al0101Type-------------------------------
				if (field.getName().equalsIgnoreCase("apertura")) {
					if (aladirequesttipo01Type.getApertura() != null)
						parameters.put(field.getName(), new Apertura(aladirequesttipo01Type.getApertura()));
				} else if (field.getName().equalsIgnoreCase("registro")) {
					if (aladirequesttipo01Type.getRegistro() != null)
						parameters.put(field.getName(), new Registro(aladirequesttipo01Type.getRegistro()));
				} else if (field.getName().equalsIgnoreCase("pago")) {
					if (aladirequesttipo01Type.getPago() != null)
						parameters.put(field.getName(), new Pago(aladirequesttipo01Type.getPago()));
				} else if (field.getName().equalsIgnoreCase("reganticipado")) {
					if (aladireqresptipo01Type.getReganticipado() != null)
						parameters.put(field.getName(), new RegAnticipado(aladireqresptipo01Type.getReganticipado()));
				} else if (field.getName().equalsIgnoreCase("tpagoimport")) {
					if (aladireqresptipo01Type.getTpagoimport() != null)
						parameters.put(field.getName(), new TPagoImp(aladireqresptipo01Type.getTpagoimport()));					
				} else if (field.getName().equalsIgnoreCase("saldoconvenio")) {
					if (aladireqresptipo01Type.getSaldoconvenio() != null)
						parameters.put(field.getName(), new SaldoConvenio(aladireqresptipo01Type.getSaldoconvenio()));
				} else if (field.getName().equalsIgnoreCase("planpago")) {
					if (aladirequesttipo01Type.getPlanpago() != null)
						parameters.put(field.getName(), new PlanPago(aladirequesttipo01Type.getPlanpago()));
				} else if (field.getName().equalsIgnoreCase("listaplanpagos")) {
					// convertimos todo el arreglo de objetos JAXB a objetos
					// array JPA
					if (aladirequesttipo01Type.getListaplanpagos() != null) {
						List<PlanPago> listaplanpagosJPA = new ArrayList<PlanPago>();
						List<gob.bcb.siraladi.xml.model.Planpago> listaplanpagos = aladirequesttipo01Type.getListaplanpagos().getPlanpago();
						for (gob.bcb.siraladi.xml.model.Planpago planpagoXML : listaplanpagos) {
							listaplanpagosJPA.add(new PlanPago(planpagoXML));
						}

						if (listaplanpagosJPA.size() > 0)
							parameters.put(field.getName(), listaplanpagosJPA);
					}
				} else if (field.getName().equalsIgnoreCase("listareganticipado")) {
					// convertimos todo el arreglo de objetos JAXB a objetos
					// array JPA
					if (aladireqresptipo01Type.getListareganticipado() != null) {
						List<RegAnticipado> objetoJPA = new ArrayList<RegAnticipado>();
						List<gob.bcb.siraladi.xml.model.Reganticipado> listaplanpagos = aladireqresptipo01Type.getListareganticipado().getReganticipado();
						for (gob.bcb.siraladi.xml.model.Reganticipado objetoXML : listaplanpagos) {
							objetoJPA.add(new RegAnticipado(objetoXML));
						}

						if (objetoJPA.size() > 0)
							parameters.put(field.getName(), objetoJPA);
					}					
					// -------------------------------------------------
				} else if (field.getName().equalsIgnoreCase("listatpagoimport")) {
					// convertimos todo el arreglo de objetos JAXB a objetos
					// array JPA
					if (aladireqresptipo01Type.getListatpagoimport() != null) {
						List<TPagoImp> listaObjetoJPA = new ArrayList<TPagoImp>();
						List<gob.bcb.siraladi.xml.model.Tpagoimport> listaobjetoXML = aladireqresptipo01Type.getListatpagoimport().getTpagoimport();
						for (gob.bcb.siraladi.xml.model.Tpagoimport objetoXML : listaobjetoXML) {
							listaObjetoJPA.add(new TPagoImp(objetoXML));
						}

						if (listaObjetoJPA.size() > 0)
							parameters.put(field.getName(), listaObjetoJPA);
					}					
				} else if (field.getName().equalsIgnoreCase("listasaldoconvenio")) {
					// convertimos todo el arreglo de objetos JAXB a objetos
					// array JPA
					if (aladireqresptipo01Type.getListasaldoconvenio() != null) {
						List<SaldoConvenio> listaObjetoJPA = new ArrayList<SaldoConvenio>();
						List<gob.bcb.siraladi.xml.model.Saldoconvenio> listaobjetoXML = aladireqresptipo01Type.getListasaldoconvenio().getSaldoconvenio();
						for (gob.bcb.siraladi.xml.model.Saldoconvenio objetoXML : listaobjetoXML) {
							listaObjetoJPA.add(new SaldoConvenio(objetoXML));
						}

						if (listaObjetoJPA.size() > 0)
							parameters.put(field.getName(), listaObjetoJPA);
					}
				} else if (field.getName().equalsIgnoreCase("listainstitucion")) {
					// convertimos todo el arreglo de objetos JAXB a objetos
					// array JPA
					if (aladireqresptipo01Type.getListainstitucion() != null) {
						List<Institucion> listaObjetoJPA = new ArrayList<Institucion>();
						List<gob.bcb.siraladi.xml.model.Institucion> listaobjetoXML = aladireqresptipo01Type.getListainstitucion().getInstitucion();
						for (gob.bcb.siraladi.xml.model.Institucion objetoXML : listaobjetoXML) {
							listaObjetoJPA.add(new Institucion(objetoXML));
						}

						if (listaObjetoJPA.size() > 0)
							parameters.put(field.getName(), listaObjetoJPA);
					}
				} else if (field.getName().equalsIgnoreCase("listareganticipado")) {
					// convertimos todo el arreglo de objetos JAXB a objetos
					// array JPA
					if (aladireqresptipo01Type.getListareganticipado() != null) {
						List<RegAnticipado> listaObjetoJPA = new ArrayList<RegAnticipado>();
						List<gob.bcb.siraladi.xml.model.Reganticipado> listaobjetoXML = aladireqresptipo01Type.getListareganticipado().getReganticipado();
						for (gob.bcb.siraladi.xml.model.Reganticipado objetoXML : listaobjetoXML) {
							listaObjetoJPA.add(new RegAnticipado(objetoXML));
						}

						if (listaObjetoJPA.size() > 0)
							parameters.put(field.getName(), listaObjetoJPA);
					}					
				} else if (field.getName().equalsIgnoreCase("fechaDesde")) {
					if (aladirequesttipo02Type.getFechaDesde() != null)
						parameters.put(field.getName(), (aladirequesttipo02Type.getFechaDesde().toGregorianCalendar().getTime()));
				} else if (field.getName().equalsIgnoreCase("fechaHasta")) {
					if (aladirequesttipo02Type.getFechaHasta() != null)
						parameters.put(field.getName(), (aladirequesttipo02Type.getFechaHasta().toGregorianCalendar().getTime()));
				} else if (field.getName().equalsIgnoreCase("fechaAl")) {
					if (aladirequesttipo02Type.getFechaAl() != null)
						parameters.put(field.getName(), (aladirequesttipo02Type.getFechaAl().toGregorianCalendar().getTime()));					
				}
			}
		} catch (Exception e) {
			log.error(e.getMessage(),e);
			throw new SystemInternalException("ERROR_RECUPERANDO_PARAMS_REQUEST", new Object[] { codTipoOperacion });			
		}

		if (parameters.size() == 0) {
			throw new SystemInternalException("REQUEST_SIN_PARAMETROS", new Object[] { codTipoOperacion });			
		}
		bcbRequest.setRequestElements(parameters);
	}

	public ResponseContext getResponseContext() {
		return responseContext;
	}

	public EntityManager getEntityManager() {
		return entityManager;
	}

	/**
	 * @return the bcbRequest
	 */
	public BcbRequest getBcbRequest() {
		return bcbRequest;
	}

}
