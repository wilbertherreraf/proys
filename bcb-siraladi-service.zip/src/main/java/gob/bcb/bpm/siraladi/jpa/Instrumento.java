package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The persistent class for the instrumento database table.
 * 
 */
@Entity
@Table(name = "instrumento")
public class Instrumento implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	// @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "cod_instrumento", unique = true, nullable = false)
	private String codInstrumento;

	@Column(name = "nom_instrumento")
	private String nomInstrumento;

	@Column(name = "cod_id")
	private String codId;
	
	public Instrumento() {
	}

	public String getCodInstrumento() {
		return this.codInstrumento;
	}

	public void setCodInstrumento(String codInstrumento) {
		this.codInstrumento = codInstrumento;
	}

	public String getNomInstrumento() {
		return this.nomInstrumento;
	}

	public void setNomInstrumento(String nomInstrumento) {
		this.nomInstrumento = nomInstrumento;
	}

	public void setCodId(String codId) {
		this.codId = codId;
	}

	public String getCodId() {
		return codId;
	}

}
