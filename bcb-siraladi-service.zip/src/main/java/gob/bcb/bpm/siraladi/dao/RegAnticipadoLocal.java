package gob.bcb.bpm.siraladi.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


import javax.persistence.EntityManager;

import gob.bcb.bpm.siraladi.jpa.RegAnticipado;

//
public interface RegAnticipadoLocal extends DAO<Integer, RegAnticipado> {

	List<RegAnticipado> getRegAnticipadoByEstado(String cveEstadoAnt);

	RegAnticipado getRegistroFicticio(String cveTipoApe, String codInstRecep, BigDecimal monto, Date fecha, String cveEstadoAnt,
			String codInstrumento, String tipoDH);

	RegAnticipado guardar(RegAnticipado regAnticipado);

	boolean isValidData(RegAnticipado regAnticipado);

	RegAnticipado findByCodReembolso(String codInst, String codId, String anio, String secuencia, Integer dav);

	RegAnticipado findByNroMov(Integer nroMov);

	List<RegAnticipado> registrosAntBy(String cveTipoApe, String codInstRecep, Date fecha, String cveEstadoAnt,
			String codInstrumento);
}
