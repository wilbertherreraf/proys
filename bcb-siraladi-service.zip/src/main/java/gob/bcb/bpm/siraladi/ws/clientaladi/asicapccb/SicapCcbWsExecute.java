
package gob.bcb.bpm.siraladi.ws.clientaladi.asicapccb;

import gob.bcb.bpm.siraladi.ws.clientaladi.LocalDateAdapter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import javax.xml.datatype.XMLGregorianCalendar;

import org.joda.time.LocalDate;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Login" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Contrasena" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Fecvalfrom" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="Fecvalto" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "login",
    "contrasena",
    "fecvalfrom",
    "fecvalto"
})
@XmlRootElement(name = "sicap_ccb_ws.Execute")
public class SicapCcbWsExecute {

    @XmlElement(name = "Login", required = false)
    protected String login;
    @XmlElement(name = "Contrasena", required = false)
    protected String contrasena;
    
//    @XmlElement(name = "Fecvalfrom", required = false)
//    @XmlSchemaType(name = "date")
    @XmlElement(name = "Fecvalfrom")
    //@XmlJavaTypeAdapter(LocalDateAdapter.class)
    @XmlSchemaType(name = "date")    
    protected XMLGregorianCalendar fecvalfrom;
    //protected LocalDate fecvalfrom;
    @XmlElement(name = "Fecvalto")
    //@XmlJavaTypeAdapter(LocalDateAdapter.class)
    @XmlSchemaType(name = "date")    
    protected XMLGregorianCalendar fecvalto;
    //protected LocalDate fecvalto;

    /**
     * Gets the value of the login property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLogin() {
        return login;
    }

    /**
     * Sets the value of the login property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLogin(String value) {
        this.login = value;
    }

    /**
     * Gets the value of the contrasena property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContrasena() {
        return contrasena;
    }

    /**
     * Sets the value of the contrasena property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContrasena(String value) {
        this.contrasena = value;
    }

    /**
     * Gets the value of the fecvalfrom property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getFecvalfrom() {
    //public LocalDate getFecvalfrom() {
        return fecvalfrom;
    }

    /**
     * Sets the value of the fecvalfrom property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFecvalfrom(XMLGregorianCalendar value) {
        this.fecvalfrom = value;
    }

    /**
     * Gets the value of the fecvalto property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getFecvalto() {
        return fecvalto;
    }

    /**
     * Sets the value of the fecvalto property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFecvalto(XMLGregorianCalendar value) {
        this.fecvalto = value;
    }

}
