package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the dia_especial database table.
 * 
 */
@Entity
@Table(name="dia_especial")
public class DiaEspecial implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private DiaEspecialPK id;

	@Column(name="cod_usuario")
	private String codUsuario;

	private String estacion;

    @Temporal( TemporalType.TIMESTAMP)
	@Column(name="fecha_hora")
	private Date fechaHora;

    @Temporal( TemporalType.TIME)
	@Column(name="hora_fin")
	private Date horaFin;

    @Temporal( TemporalType.TIME)
	@Column(name="hora_ini")
	private Date horaIni;

    public DiaEspecial() {
    }

	public DiaEspecialPK getId() {
		return this.id;
	}

	public void setId(DiaEspecialPK id) {
		this.id = id;
	}
	
	public String getCodUsuario() {
		return this.codUsuario;
	}

	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public Date getHoraFin() {
		return this.horaFin;
	}

	public void setHoraFin(Date horaFin) {
		this.horaFin = horaFin;
	}

	public Date getHoraIni() {
		return this.horaIni;
	}

	public void setHoraIni(Date horaIni) {
		this.horaIni = horaIni;
	}

}