package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;


/**
 * The persistent class for the categoria database table.
 * 
 */
@Entity
@Table(name="categoria")
public class Categoria implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@EmbeddedId
	private CategoriaPK id; 

	@Column(name="cod_usuario")
	private String codUsuario;

	@Column(name="cve_vigente")
	private String cveVigente;

	@Column(name="estacion")
	private String estacion;

	@Column(name="fecha_hora")
	private Date fechaHora;

	//bi-directional many-to-one association to CalifRiesgo
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="cod_calif", nullable=false, insertable=false, updatable=false)
	private CalifRiesgo califRiesgo;

	//bi-directional many-to-one association to Persona
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="cod_persona", nullable=false, insertable=false, updatable=false)
	private Persona persona;

    public Categoria() {
    }

	public CategoriaPK getId() {
		return this.id;
	}

	public void setId(CategoriaPK id) {
		this.id = id;
	}
	
	public String getCodUsuario() {
		return this.codUsuario;
	}

	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}

	public String getCveVigente() {
		return this.cveVigente;
	}

	public void setCveVigente(String cveVigente) {
		this.cveVigente = cveVigente;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public CalifRiesgo getCalifRiesgo() {
		return this.califRiesgo;
	}

	public void setCalifRiesgo(CalifRiesgo califRiesgo) {
		this.califRiesgo = califRiesgo;
	}
	
	public Persona getPersona() {
		return this.persona;
	}

	public void setPersona(Persona persona) {
		this.persona = persona;
	}

	@Override
	public String toString() {
		return "Categoria [id=" + id + ", codUsuario=" + codUsuario + ", cveVigente=" + cveVigente + ", estacion=" + estacion + ", fechaHora=" + fechaHora + ", califRiesgo="
				+ califRiesgo + ", persona=" + persona + "]";
	}
	
}
