package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.Patrimonio;

import java.util.List;


import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("patrimonioLocal")
@Transactional
public class PatrimonioBean extends GenericDAO<Integer, Patrimonio> implements PatrimonioLocal {
	
	public Patrimonio getMaxPatrimonio() {
		Patrimonio patrimonio = null;
		String jpql = "SELECT p FROM Patrimonio p where p.nroOrden = (select max(m.nroOrden) from Patrimonio m)";
		Query query = getEntityManager().createQuery(jpql);
		List result = query.getResultList();
		if (result.size() > 0)
			patrimonio = (Patrimonio) result.get(0);

		return patrimonio;

	}	
}
