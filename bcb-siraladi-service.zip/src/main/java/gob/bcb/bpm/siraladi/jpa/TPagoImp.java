package gob.bcb.bpm.siraladi.jpa;

import gob.bcb.bpm.siraladi.utils.UtilsDate;

import java.io.Serializable;
import javax.persistence.*;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import java.math.BigDecimal;
import java.util.Date;

/**
 * The persistent class for the t_pago_imp database table.
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@Entity
@Table(name = "t_pago_imp")
@XmlRootElement(name = "tPagoImp")
public class TPagoImp implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "nro_reg", unique = true, nullable = false)
	private Integer nroReg;

	@Column(length = 4)
	private String anio;

	@Column(name = "cod_id", length = 1)
	private String codId;

	@Column(name = "cod_inst", length = 4)
	private String codInst;

	@Column(name = "cod_inst_recep", length = 4)
	private String codInstRecep;

	@Column(name = "cod_instrumento", length = 3)
	private String codInstrumento;

	@Column(name = "cod_pais", length = 2)
	private String codPais;

	private String corr;

	private Integer dav;

	@Temporal(TemporalType.TIMESTAMP)
	private Date fecha1;

	@Temporal(TemporalType.TIMESTAMP)
	private Date fecha2;

	@Column(name = "monto_mo", precision = 15, scale = 2)
	private BigDecimal montoMo;

	@Column(name = "nro_debito", nullable = false)
	private int nroDebito;

	@Column(length = 40)
	private String obs;

	@Column(length = 6)
	private String secuencia;

	public TPagoImp() {
	}

	public TPagoImp(Integer nroReg, int nroDebito, String codInst, String codId, String anio, String secuencia, Integer dav, String corr,
			String codInstrumento, Date fecha1, String codPais, String codInstRecep, Date fecha2, BigDecimal montoMo, String obs) {
		this.nroReg = nroReg;
		this.anio = anio;
		this.codId = codId;
		this.codInst = codInst;
		this.codInstRecep = codInstRecep;
		this.codInstrumento = codInstrumento;
		this.codPais = codPais;
		this.corr = corr;
		this.dav = dav;
		this.fecha1 = fecha1;
		this.fecha2 = fecha2;
		this.montoMo = montoMo;
		this.nroDebito = nroDebito;
		this.obs = obs;
		this.secuencia = secuencia;
	}

	public TPagoImp(gob.bcb.siraladi.xml.model.Tpagoimport tpagoimport) {
		try {
			this.nroReg = tpagoimport.getNroReg();
		} catch (Exception e) {
		}
		this.anio = tpagoimport.getAnio();
		this.codId = tpagoimport.getCodId();
		this.codInst = tpagoimport.getCodInst();
		this.codInstRecep = tpagoimport.getCodInstRecep();
		this.codInstrumento = tpagoimport.getCodInstrumento();
		this.codPais = tpagoimport.getCodPais();
		this.corr = tpagoimport.getCorr();
		this.dav = tpagoimport.getDav();
		try {
			this.fecha1 = tpagoimport.getFecha1().toGregorianCalendar().getTime();
		} catch (Exception e) {
		}
		try {
			this.fecha2 = tpagoimport.getFecha2().toGregorianCalendar().getTime();
		} catch (Exception e) {
		}
		this.montoMo = tpagoimport.getMontoMo();
		this.nroDebito = tpagoimport.getNroDebito();
		this.obs = tpagoimport.getObs();
		this.secuencia = tpagoimport.getSecuencia();
	}

	public gob.bcb.siraladi.xml.model.Tpagoimport getObjectJAXB() {
		gob.bcb.siraladi.xml.model.Tpagoimport tpagoimport = new gob.bcb.siraladi.xml.model.Tpagoimport();
		tpagoimport.setNroReg((int) nroReg);
		tpagoimport.setAnio(anio);
		tpagoimport.setCodId(codId);
		tpagoimport.setCodInst(codInst);
		tpagoimport.setCodInstRecep(codInstRecep);
		tpagoimport.setCodInstrumento(codInstrumento);
		tpagoimport.setCodPais(codPais);
		tpagoimport.setCorr(corr);
		tpagoimport.setDav(dav);
		try {
			tpagoimport.setFecha1(UtilsDate.StrToXMLGregoCal(UtilsDate.stringFromDate(fecha1, "yyyy-MM-dd"), "-"));
		} catch (Exception e) {
		}
		try {
			tpagoimport.setFecha2(UtilsDate.StrToXMLGregoCal(UtilsDate.stringFromDate(fecha2, "yyyy-MM-dd"), "-"));
		} catch (Exception e) {
		}

		tpagoimport.setMontoMo(montoMo);
		tpagoimport.setNroDebito(nroDebito);
		tpagoimport.setObs(obs);
		tpagoimport.setSecuencia(secuencia);
		return tpagoimport;
	}

	public Integer getNroReg() {
		return this.nroReg;
	}

	public void setNroReg(Integer nroReg) {
		this.nroReg = nroReg;
	}

	public String getAnio() {
		return this.anio;
	}

	public void setAnio(String anio) {
		this.anio = anio;
	}

	public String getCodId() {
		return this.codId;
	}

	public void setCodId(String codId) {
		this.codId = codId;
	}

	public String getCodInst() {
		return this.codInst;
	}

	public void setCodInst(String codInst) {
		this.codInst = codInst;
	}

	public String getCodInstRecep() {
		return this.codInstRecep;
	}

	public void setCodInstRecep(String codInstRecep) {
		this.codInstRecep = codInstRecep;
	}

	public String getCodInstrumento() {
		return this.codInstrumento;
	}

	public void setCodInstrumento(String codInstrumento) {
		this.codInstrumento = codInstrumento;
	}

	public String getCodPais() {
		return this.codPais;
	}

	public void setCodPais(String codPais) {
		this.codPais = codPais;
	}

	public String getCorr() {
		return this.corr;
	}

	public void setCorr(String corr) {
		this.corr = corr;
	}

	public Integer getDav() {
		return this.dav;
	}

	public void setDav(Integer dav) {
		this.dav = dav;
	}

	public Date getFecha1() {
		return this.fecha1;
	}

	public void setFecha1(Date fecha1) {
		this.fecha1 = fecha1;
	}

	public Date getFecha2() {
		return this.fecha2;
	}

	public void setFecha2(Date fecha2) {
		this.fecha2 = fecha2;
	}

	public BigDecimal getMontoMo() {
		return this.montoMo;
	}

	public void setMontoMo(BigDecimal montoMo) {
		this.montoMo = montoMo;
	}

	public int getNroDebito() {
		return this.nroDebito;
	}

	public void setNroDebito(int nroDebito) {
		this.nroDebito = nroDebito;
	}

	public String getObs() {
		return this.obs;
	}

	public void setObs(String obs) {
		this.obs = obs;
	}

	public String getSecuencia() {
		return this.secuencia;
	}

	public void setSecuencia(String secuencia) {
		this.secuencia = secuencia;
	}

	
	public String toString() {
		return "TPagoImp [nroReg=" + nroReg + ", anio=" + anio + ", codId=" + codId + ", codInst=" + codInst + ", codInstRecep=" + codInstRecep
				+ ", codInstrumento=" + codInstrumento + ", codPais=" + codPais + ", corr=" + corr + ", dav=" + dav + ", fecha1=" + fecha1 + ", fecha2="
				+ fecha2 + ", montoMo=" + montoMo + ", nroDebito=" + nroDebito + ", obs=" + obs + ", secuencia=" + secuencia + "]";
	}
	
	/**/
	transient private boolean seleccionado;

	public boolean isSeleccionado()
	{
		return seleccionado;
	}

	public void setSeleccionado(boolean seleccionado)
	{
		this.seleccionado = seleccionado;
	}	
	/**/
	
	public String getCodigoReembolso()
	{
		String codReembolso = null;
		try
		{
			codReembolso = this.codInst.trim() + "-" + 
			this.codId.trim() + "-" + this.anio.trim() + "-" + 
			this.secuencia.trim() + "-" + this.dav;
		}
		catch(Exception e)
		{
			;
		}
		return codReembolso;
	}

}
