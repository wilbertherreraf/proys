package gob.bcb.bpm.siraladi.jpa;

import gob.bcb.bpm.siraladi.utils.UtilsDate;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.apache.commons.lang.StringUtils;

/**
 * The persistent class for the registro database table.
 * 
 */
@Entity
@Table(name = "registro")
public class Registro implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	// @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "nro_mov", unique = true, nullable = false)
	private Integer nroMov;

	@Column(name = "cod_usuario")
	private String codUsuario;

	@Column(name = "cve_estado_reg")
	private String cveEstadoReg;

	@Column(name = "cve_tipo_emis")
	private String cveTipoEmis;

	@Column(name = "debe_mo")
	private BigDecimal debeMo;

	@Column(length = 20)
	private String estacion;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "fecha_hora")
	private Date fechaHora;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "fecha_trans")
	private Date fechaTrans;

	@Column(name = "haber_mo")
	private BigDecimal haberMo;

	@Column(name = "nro_mov_ape")
	private Integer nroMovApe;

	@Column(name = "nit")
	private String nit;

	@Column(name = "reg_obs")
	private String regObs;

	@Column(name = "nro_sec_reemb")
	private Integer nroSecReemb;
	
	// bi-directional many-to-one association to Institucion
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "cod_inst_recep")
	private Institucion institucion;

	// bi-directional many-to-one association to Instrumento
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "cod_instrumento")
	private Instrumento instrumento;

	public Registro() {
	}

	public Registro(Integer nroMov, String codUsuario, String cveEstadoReg, String cveTipoEmis, BigDecimal debeMo, String estacion, Date fechaHora,
			Date fechaTrans, BigDecimal haberMo, Integer nroMovApe, String nit, String regObs, Institucion institucion, Instrumento instrumento) {
		this.nroMov = nroMov;
		this.codUsuario = codUsuario;
		this.cveEstadoReg = cveEstadoReg;
		this.cveTipoEmis = cveTipoEmis;
		this.debeMo = debeMo;
		this.estacion = estacion;
		this.fechaHora = fechaHora;
		this.fechaTrans = fechaTrans;
		this.haberMo = haberMo;
		this.nroMovApe = nroMovApe;
		this.nit = nit;
		this.regObs = regObs;
		this.institucion = institucion;
		this.instrumento = instrumento;
	}

	public Registro(gob.bcb.siraladi.xml.model.Registro registro) {
		this.nroMov = registro.getNromov();
		this.cveTipoEmis = registro.getTipoemis();
		this.debeMo = registro.getDebe();
		this.haberMo = registro.getHaber();
		this.nit = registro.getNit();
		this.regObs = registro.getObs();
		try {
			this.fechaTrans = registro.getFechatrans().toGregorianCalendar().getTime();
		} catch (Exception e) {
		}
		this.institucion = new Institucion();
		this.institucion.setCodInst(registro.getCodinstrecep());
		this.instrumento = new Instrumento();
		this.instrumento.setCodInstrumento(registro.getCodinstrumento());
		this.cveEstadoReg = registro.getEstadotrans();
	}

	public gob.bcb.siraladi.xml.model.Registro getObjectJAXB() {
		gob.bcb.siraladi.xml.model.Registro registro = new gob.bcb.siraladi.xml.model.Registro();
		registro.setNromov(nroMov);
		registro.setTipoemis(cveTipoEmis);
		registro.setCodinstrumento(instrumento.getCodInstrumento());
		registro.setCodinstrecep(institucion.getCodInst());
		registro.setDebe(this.debeMo);
		registro.setHaber(this.haberMo);
		registro.setEstadotrans(cveEstadoReg);
		registro.setFechatrans(UtilsDate.StrToXMLGregoCal(UtilsDate.stringFromDate(fechaTrans, "yyyy-MM-dd"), "-"));
		registro.setNit(nit);
		registro.setObs((StringUtils.isEmpty(regObs)) ? null : regObs.toUpperCase());
		return registro;
	}

	public Integer getNroMov() {
		return this.nroMov;
	}

	public void setNroMov(Integer nroMov) {
		this.nroMov = nroMov;
	}

	public String getCodUsuario() {
		return this.codUsuario;
	}

	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}

	public String getCveEstadoReg() {
		return this.cveEstadoReg;
	}

	public void setCveEstadoReg(String cveEstadoReg) {
		this.cveEstadoReg = cveEstadoReg;
	}

	public String getCveTipoEmis() {
		return this.cveTipoEmis;
	}

	public void setCveTipoEmis(String cveTipoEmis) {
		this.cveTipoEmis = cveTipoEmis;
	}

	public BigDecimal getDebeMo() {
		return this.debeMo;
	}

	public void setDebeMo(BigDecimal debeMo) {
		this.debeMo = debeMo;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public Date getFechaTrans() {
		return this.fechaTrans;
	}

	public void setFechaTrans(Date fechaTrans) {
		this.fechaTrans = fechaTrans;
	}

	public BigDecimal getHaberMo() {
		return this.haberMo;
	}

	public void setHaberMo(BigDecimal haberMo) {
		this.haberMo = haberMo;
	}

	public Integer getNroMovApe() {
		return this.nroMovApe;
	}

	public String getNit() {
		return nit;
	}

	public void setNit(String nit) {
		this.nit = nit;
	}

	public void setNroMovApe(Integer nroMovApe) {
		this.nroMovApe = nroMovApe;
	}

	public String getRegObs() {
		return this.regObs;
	}

	public void setRegObs(String regObs) {
		this.regObs = regObs;
	}

	public Institucion getInstitucion() {
		return this.institucion;
	}

	public void setInstitucion(Institucion institucion) {
		this.institucion = institucion;
	}

	public Instrumento getInstrumento() {
		return this.instrumento;
	}

	public void setInstrumento(Instrumento instrumento) {
		this.instrumento = instrumento;
	}

	
	public String toString() {
		return "Registro [nroMov=" + nroMov + ", codUsuario=" + codUsuario + ", cveEstadoReg=" + cveEstadoReg + ", cveTipoEmis=" + cveTipoEmis
				+ ", debeMo=" + debeMo + ", estacion=" + estacion + ", fechaHora=" + fechaHora + ", fechaTrans=" + fechaTrans + ", haberMo="
				+ haberMo + ", nroMovApe=" + nroMovApe + ", nit=" + nit + ", regObs=" + regObs + ", institucion=" + institucion + ", instrumento="
				+ instrumento + "]";
	}

	public void setNroSecReemb(Integer nroSecReemb) {
		this.nroSecReemb = nroSecReemb;
	}

	public Integer getNroSecReemb() {
		return nroSecReemb;
	}
	
}
