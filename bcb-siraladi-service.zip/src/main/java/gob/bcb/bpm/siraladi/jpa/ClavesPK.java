package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the claves database table.
 * 
 */
@Embeddable
public class ClavesPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(unique=true, nullable=false)
	private String nomdato;

	@Column(unique=true, nullable=false)
	private String valdato;

    public ClavesPK() {
    }
	public String getNomdato() {
		return this.nomdato;
	}
	public void setNomdato(String nomdato) {
		this.nomdato = nomdato;
	}
	public String getValdato() {
		return this.valdato;
	}
	public void setValdato(String valdato) {
		this.valdato = valdato;
	}

	
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof ClavesPK)) {
			return false;
		}
		ClavesPK castOther = (ClavesPK)other;
		return 
			this.nomdato.equals(castOther.nomdato)
			&& this.valdato.equals(castOther.valdato);

    }
    
	
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.nomdato.hashCode();
		hash = hash * prime + this.valdato.hashCode();
		
		return hash;
    }
}
