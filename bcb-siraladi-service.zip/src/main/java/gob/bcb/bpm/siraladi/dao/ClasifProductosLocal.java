package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.ClasifProductos;
import gob.bcb.bpm.siraladi.jpa.Param;

public interface ClasifProductosLocal extends DAO<Integer, ClasifProductos>{

	public abstract ClasifProductos findByCodigo(Integer nomparam);

	public abstract ClasifProductos saveorupdate(ClasifProductos params);

}