package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the claves database table.
 * 
 */
@Entity
@Table(name="claves")
public class Claves implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private ClavesPK id;

	@Column(nullable=false)
	private String interp;

    public Claves() {
    }

	public ClavesPK getId() {
		return this.id;
	}

	public void setId(ClavesPK id) {
		this.id = id;
	}
	
	public String getInterp() {
		return this.interp;
	}

	public void setInterp(String interp) {
		this.interp = interp;
	}

}