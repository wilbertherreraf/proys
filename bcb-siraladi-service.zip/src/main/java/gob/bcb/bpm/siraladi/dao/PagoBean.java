package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.Pago;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


import javax.persistence.Query;
import javax.persistence.TemporalType;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("pagoLocal")
@Transactional
public class PagoBean extends GenericDAO<Integer, Pago> implements PagoLocal {

	
	public BigDecimal getMontoPago(Integer nroMovApe) {
		String jpql = "SELECT sum(nvl(p.haberMo, 0) - nvl(p.debeMo, 0)) FROM Pago p " + " WHERE p.nroMovApe = :nroMovApe and p.cveEstadoPago <> 'R' "
				+ "and p.instrumento.codInstrumento <> 'CG' ";
		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("nroMovApe", nroMovApe);

		List result = query.getResultList();
		if (result.size() > 0) {
			Double valor = (Double) result.get(0);
			return (BigDecimal.valueOf((valor == null ? Double.valueOf(0) : valor)));
		}

		return BigDecimal.ZERO;
	}

	
	public BigDecimal getMontoSinNroMov(Integer nroMovApe, Integer nroMov) {
		String jpql = "SELECT sum(nvl(p.haberMo, 0) - nvl(p.debeMo, 0)) FROM Pago p "
				+ " WHERE p.nroMovApe = :nroMovApe and p.nroMov <> :nroMov and p.cveEstadoPago <> 'R' and p.instrumento.codInstrumento <> 'CG' ";
		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("nroMovApe", nroMovApe);
		query.setParameter("nroMov", nroMov);

		List result = query.getResultList();
		if (result.size() > 0) {
			Double valor = (Double) result.get(0);
			return (BigDecimal.valueOf((valor == null ? Double.valueOf(0) : valor)));
		}

		return BigDecimal.ZERO;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.bpm.siraladi.dao.PagoLocal#getByNroMovApeCveEstadoPago(java.lang .Integer, java.lang.String, boolean)
	 */
	
	public List<Pago> getByNroMovApeCveEstadoPago(Integer nroMovApe, String cveEstadoPago, boolean sinGastosYComisiones) {
		String jpql = "SELECT p FROM Pago p " + " WHERE p.nroMovApe = :nroMovApe ";
		if (sinGastosYComisiones)
			jpql += "and p.instrumento.codInstrumento <> 'CG' ";

		if (cveEstadoPago != null)
			jpql += "and p.cveEstadoPago = :cveEstadoPago ";

		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("nroMovApe", nroMovApe);
		if (cveEstadoPago != null)
			query.setParameter("cveEstadoPago", cveEstadoPago);

		return query.getResultList();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.bpm.siraladi.dao.PagoLocal#getSaldoPago(int, javax.persistence.EntityManager)
	 */
	
	public BigDecimal getSaldoPago(Integer nroMovApe) {
		String jpql = "SELECT sum(nvl(p.debeMo, 0) - nvl(p.haberMo, 0)) FROM Pago p " + " WHERE p.nroMovApe = :nroMovApe "
				+ "and p.instrumento.codInstrumento <> 'CG' " + "and p.cveEstadoPago = 'C'";
		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("nroMovApe", nroMovApe);

		List result = query.getResultList();

		if (result.size() > 0) {
			Double valor = (Double) result.get(0);
			return (BigDecimal.valueOf((valor == null ? Double.valueOf(0) : valor)));
		}
		return BigDecimal.ZERO;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.bpm.siraladi.dao.PagoLocal#getSaldoCont(java.lang.String, java.util.Date, java.lang.String)
	 */
	
	public BigDecimal getSaldoCont(String codPersona, Date fechaCargo, String cveTipoApe) {
		if (!cveTipoApe.equals("I") && !cveTipoApe.equals("E")) {
			return new BigDecimal(0);
		}

		String jpql = "SELECT sum(nvl(p.debeMo, 0) - nvl(p.haberMo, 0)) FROM Apertura a, Pago p, PersonaInst c " + " WHERE a.nroMov = p.nroMovApe " + "and "
				+ (cveTipoApe.equals("I") ? "a.institucion.codInst" : "p.institucion.codInst") + " = c.id.codInst "
				+ "and a.cveTipoApe = :cveTipoApe and c.id.codPersona = :codPersona " + "and p.cveEstadoPago = 'C' and p.fechaCargo <= :fechaCargo "
				+ "and p.instrumento.codInstrumento <> 'CG' ";

		if ((codPersona.equals("900") && cveTipoApe.equals("I")) || cveTipoApe.equals("E")) {
			jpql += "and a.identificador.codId <> '9' ";
		}
		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("cveTipoApe", cveTipoApe);
		query.setParameter("codPersona", codPersona);
		query.setParameter("fechaCargo", fechaCargo, TemporalType.DATE);
		List result = query.getResultList();
		if (result.size() > 0) {
			Double valor = (Double) result.get(0);
			return (BigDecimal.valueOf((valor == null ? Double.valueOf(0) : valor)));
		}

		return BigDecimal.ZERO;
	}

	
	public Pago findByPagoImport(Integer nroMovApe, Integer nroDebito, String codInstrumento, BigDecimal monto, Integer nroSecReemb) {
		Pago pago = null;
		String jpql = "SELECT p FROM Pago p WHERE p.nroMovApe = :nroMovApe and p.nroDebito = :nroDebito "
				+ "and p.instrumento.codInstrumento = :codInstrumento ";
		if (monto != null){
			if (monto.compareTo(BigDecimal.ZERO) < 0)
				jpql += " and p.debeMo = :monto ";
			else
				jpql += " and p.haberMo = :monto ";
		}
		if (nroSecReemb != null){
			jpql += "and p.nroSecReemb = :nroSecReemb ";			
		}
		
		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("nroMovApe", nroMovApe);
		query.setParameter("nroDebito", nroDebito);
		query.setParameter("codInstrumento", codInstrumento);
		if (monto != null)
			query.setParameter("monto", monto);
		
		if (nroSecReemb != null){
			query.setParameter("nroSecReemb", nroSecReemb);
		}
		List result = query.getResultList();
		if (result.size() > 0)
			pago = (Pago) result.get(0);

		return pago;
	}

	public Pago getByNroMov(Integer nroMov) {
		String jpql = "SELECT p FROM Pago p " + " WHERE p.nroMov = :nroMov";
		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("nroMov", nroMov);

		List result = query.getResultList();
		if (result.size() > 0) {
			return (Pago) result.get(0);
		}

		return null;
	}
}
