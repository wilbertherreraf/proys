package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;

import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "clasif_productos")
public class ClasifProductos implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "cod_clasifprod")
	private Integer codClasifprod;
	
	@Column(name = "descrip")
	private String descrip;

	public void setCodClasifprod(Integer codClasifprod) {
		this.codClasifprod = codClasifprod;
	}

	public Integer getCodClasifprod() {
		return codClasifprod;
	}

	public void setDescrip(String descrip) {
		this.descrip = descrip;
	}

	public String getDescrip() {
		return descrip;
	}

}
