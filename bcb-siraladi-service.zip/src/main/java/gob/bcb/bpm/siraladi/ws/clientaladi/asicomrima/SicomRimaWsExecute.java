
package gob.bcb.bpm.siraladi.ws.clientaladi.asicomrima;

import gob.bcb.bpm.siraladi.ws.clientaladi.LocalDateAdapter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import javax.xml.datatype.XMLGregorianCalendar;

import org.joda.time.LocalDate;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Login" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Contrasena" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Codcon" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Nroreemb" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Instr" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Tpooper" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Ifarecep" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Fchemi" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="Fchvenc" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="Monto" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="Obs" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "login",
    "contrasena",
    "codcon",
    "nroreemb",
    "instr",
    "tpooper",
    "ifarecep",
    "fchemi",
    "fchvenc",
    "monto",
    "obs"
})
@XmlRootElement(name = "sicom_rima_ws.Execute")
public class SicomRimaWsExecute {

    @XmlElement(name = "Login", required = true)
    protected String login;
    @XmlElement(name = "Contrasena", required = true)
    protected String contrasena;
    @XmlElement(name = "Codcon", required = true)
    protected String codcon;
    @XmlElement(name = "Nroreemb", required = true)
    protected String nroreemb;
    @XmlElement(name = "Instr", required = true)
    protected String instr;
    @XmlElement(name = "Tpooper", required = true)
    protected String tpooper;
    @XmlElement(name = "Ifarecep")
    protected String ifarecep;
    @XmlElement(name = "Fchemi")
    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    @XmlSchemaType(name = "date")
    protected LocalDate fchemi;
    //protected XMLGregorianCalendar fchemi;
    @XmlElement(name = "Fchvenc")
    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    @XmlSchemaType(name = "date")
    protected LocalDate fchvenc;
    @XmlElement(name = "Monto")
    protected Double monto;
    @XmlElement(name = "Obs")
    protected String obs;

    /**
     * Gets the value of the login property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLogin() {
        return login;
    }

    /**
     * Sets the value of the login property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLogin(String value) {
        this.login = value;
    }

    /**
     * Gets the value of the contrasena property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContrasena() {
        return contrasena;
    }

    /**
     * Sets the value of the contrasena property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContrasena(String value) {
        this.contrasena = value;
    }

    /**
     * Gets the value of the codcon property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodcon() {
        return codcon;
    }

    /**
     * Sets the value of the codcon property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodcon(String value) {
        this.codcon = value;
    }

    /**
     * Gets the value of the nroreemb property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNroreemb() {
        return nroreemb;
    }

    /**
     * Sets the value of the nroreemb property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNroreemb(String value) {
        this.nroreemb = value;
    }

    /**
     * Gets the value of the instr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInstr() {
        return instr;
    }

    /**
     * Sets the value of the instr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInstr(String value) {
        this.instr = value;
    }

    /**
     * Gets the value of the tpooper property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTpooper() {
        return tpooper;
    }

    /**
     * Sets the value of the tpooper property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTpooper(String value) {
        this.tpooper = value;
    }

    /**
     * Gets the value of the ifarecep property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIfarecep() {
        return ifarecep;
    }

    /**
     * Sets the value of the ifarecep property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIfarecep(String value) {
        this.ifarecep = value;
    }

    /**
     * Gets the value of the fchemi property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public LocalDate getFchemi() {
        return fchemi;
    }

    /**
     * Sets the value of the fchemi property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFchemi(LocalDate value) {
        this.fchemi = value;
    }

    /**
     * Gets the value of the fchvenc property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public LocalDate getFchvenc() {
        return fchvenc;
    }

    /**
     * Sets the value of the fchvenc property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFchvenc(LocalDate value) {
        this.fchvenc = value;
    }

    /**
     * Gets the value of the monto property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getMonto() {
        return monto;
    }

    /**
     * Sets the value of the monto property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setMonto(Double value) {
        this.monto = value;
    }

    /**
     * Gets the value of the obs property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getObs() {
        return obs;
    }

    /**
     * Sets the value of the obs property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setObs(String value) {
        this.obs = value;
    }

}
