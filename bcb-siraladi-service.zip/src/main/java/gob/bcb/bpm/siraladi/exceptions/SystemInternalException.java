package gob.bcb.bpm.siraladi.exceptions;

import gob.bcb.bpm.siraladi.common.MsgManager;
import gob.bcb.bpm.siraladi.utils.StatusCode;

import java.util.ResourceBundle;

import javax.xml.namespace.QName;

import org.apache.log4j.Logger;

public class SystemInternalException extends UncheckedException{
	private static final long serialVersionUID = 397003421340404801L;
	private String message;
	public static final ResourceBundle BUNDLE;
	static {
		ResourceBundle bundle = null;
		try {
			bundle = ResourceBundle.getBundle("errorssystem");
			BUNDLE = bundle;
		} catch (Exception e) {
			throw new RuntimeException("No se pudo cargar archivo de mensajes 'errorssystem'");
		}
	}
	/**
	 * Constructor
	 * 
	 * @param message
	 *            Mensaje de la excepcion
	 * @param ex
	 *            La excpecion como tal
	 */
	public SystemInternalException(String msg, Throwable t) {
		this(msg, BUNDLE, t);
	}

	/**
	 * Constructor
	 * 
	 * @param message
	 *            Mensaje para crear la nueva excepcion
	 */

	public SystemInternalException(String message) {
		//this(new MsgManager(message, BUNDLE));
		// whf ojooo eliminar cuando todas las excepciones esten codificadas
		// mensaje personalizado si el codigo no existe en la configuracion lo
		// setea a
		this(BUNDLE.containsKey(message) ? (new MsgManager(message, BUNDLE)) : (new MsgManager(StatusCode.DATABASE_EXCEPTION, BUNDLE,
				new Object[] { message })));
	}

	public SystemInternalException(String message, Object... params) {
		this(new MsgManager(message, BUNDLE, params));
	}

	public SystemInternalException(MsgManager message, Throwable throwable) {
		super(message, throwable);
		this.message = message.toString();
		// code = FAULT_CODE_SERVER;
	}

	public SystemInternalException(MsgManager message) {
		super(message);
		this.message = message.toString();
		// code = FAULT_CODE_SERVER;
	}

	public SystemInternalException(String message, Logger log) {
		this(new MsgManager(message, log));
	}

	public SystemInternalException(String message, ResourceBundle b) {
		this(new MsgManager(message, b));
	}

	public SystemInternalException(String message, Logger log, Throwable t) {
		this(new MsgManager(message, log), t);
	}

	public SystemInternalException(String message, ResourceBundle b, Throwable t) {
		this(new MsgManager(message, b), t);
	}

	public SystemInternalException(String message, Logger log, Throwable t, Object... params) {
		this(new MsgManager(message, log, params), t);
	}

	public SystemInternalException(String message, ResourceBundle b, Throwable t, Object... params) {
		this(new MsgManager(message, b, params), t);
	}

	public SystemInternalException(Throwable t) {
		super(t);
        if (super.getMessage() != null) {
            message = super.getMessage();
		} else {
			message = t == null ? null : t.getMessage();
		}
	}

	public SystemInternalException(MsgManager message, Throwable throwable, QName fc) {
		super(message, throwable);
		this.message = message.toString();
	}

	public SystemInternalException(MsgManager message, QName fc) {
		super(message);
		this.message = message.toString();
	}

	public SystemInternalException(Throwable t, QName fc) {
		super(t);
		if (super.getMessage() != null) {
			message = super.getMessage();
		} else {
			message = t == null ? null : t.getMessage();
		}
	}

	public String getMsgManager() {
		return message;
	}

	public void setMsgManager(String message) {
		this.message = message;
	}

	public static String getDescription(String message, Object... params){
		return new MsgManager(message, BUNDLE, params).toString();
	}	
}
