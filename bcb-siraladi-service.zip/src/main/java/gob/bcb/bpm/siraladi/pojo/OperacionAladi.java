package gob.bcb.bpm.siraladi.pojo;

import java.util.Date;

public class OperacionAladi {
	private String codTipoOperacion;
	private String descrip;
	private Date fecha;

	public OperacionAladi() {
	}	
	public OperacionAladi(String codTipoOperacion, String descrip) {
		this.codTipoOperacion = codTipoOperacion;
		this.descrip = descrip;
	}
	
	/**
	 * @param codOperacion the codOperacion to set
	 */
	public void setCodTipoOperacion(String codOperacion) {
		this.codTipoOperacion = codOperacion;
	}
	/**
	 * @return the codOperacion
	 */
	public String getCodTipoOperacion() {
		return codTipoOperacion;
	}
	/**
	 * @param fecha the fecha to set
	 */
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	/**
	 * @return the fecha
	 */
	public Date getFecha() {
		return fecha;
	}
	public void setDescrip(String descrip) {
		this.descrip = descrip;
	}
	public String getDescrip() {
		return descrip;
	}
}
