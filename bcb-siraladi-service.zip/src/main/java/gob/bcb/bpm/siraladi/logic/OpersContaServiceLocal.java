package gob.bcb.bpm.siraladi.logic;

import gob.bcb.bpm.siraladi.jpa.Pago;
import gob.bcb.bpm.siraladi.jpa.RegAnticipado;
import gob.bcb.bpm.siraladi.jpa.Registro;

import java.util.Date;
import java.util.Map;

import javax.persistence.EntityManager;

/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public interface OpersContaServiceLocal {
	public EntityManager getEntityManager();

	public void setEntityManager(EntityManager entityManager);
	
	public String contabilizaPago(Pago pago, int tipo); 
	public String contabilizaRegistro(Registro registro, int tipo) ;
	public String contabilizaPagoAnt(RegAnticipado regAnticipado, int tipo);
	public Map<String, Object> getWarnnings();	
	/**
	 * whf objeto del servicio de conta 
	 * @param fecha
	 * @return boolean true si la fecha esta abierta en el sistema de lo contrario false
	 */
	public boolean getDiaHabil(Date fecha);
}
