package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the mod_obs database table.
 * 
 */
//@Entity
//@Table(name="mod_obs")
public class ModOb implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private ModObPK id;

	@Column(name="cod_usuario")
	private String codUsuario;

	@Column(name="desc_obs")
	private String descObs;

    public ModOb() {
    }

	public ModObPK getId() {
		return this.id;
	}

	public void setId(ModObPK id) {
		this.id = id;
	}
	
	public String getCodUsuario() {
		return this.codUsuario;
	}

	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}

	public String getDescObs() {
		return this.descObs;
	}

	public void setDescObs(String descObs) {
		this.descObs = descObs;
	}

}
