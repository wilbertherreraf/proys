package gob.bcb.bpm.siraladi.common;

import org.apache.log4j.Logger;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * @author wilherrera Wilbert Herrera Flores Banco Central de Bolivia
 *         Departamento de Desarrollo
 */
public class UtilsQNatives {
	private static Logger log = Logger.getLogger(UtilsQNatives.class);

	public static Object convertResultSetToMap(ResultSet rs) throws SQLException {
		Map<String, Object> result = new HashMap<String, Object>();
		// whf evaluar si es posible con entrys
		// Set<Map.Entry<String, Object>> listaRS0 = result.entrySet();

		Set<Map<String, Object>> listaRS = new HashSet<Map<String, Object>>();

		while (rs.next()) {
			result = new HashMap<String, Object>();
			for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
				String key = rs.getMetaData().getColumnName(i);

				if (key != null) {
					result.put(key, rs.getObject(i));
					log.debug(i + " - " + key + " - " + rs.getObject(i));
				}
			}
			listaRS.add(result);
		}
		/*
		 * } catch (SQLException e) { e.printStackTrace(); }
		 */
		return listaRS;
	}
}
