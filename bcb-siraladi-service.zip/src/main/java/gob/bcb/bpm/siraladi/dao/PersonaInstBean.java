package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.Categoria;
import gob.bcb.bpm.siraladi.jpa.Persona;
import gob.bcb.bpm.siraladi.jpa.PersonaInst;
import gob.bcb.bpm.siraladi.jpa.PersonaInstPK;

import java.util.List;


import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("personaInstLocal")
@Transactional
public class PersonaInstBean extends GenericDAO<PersonaInstPK, PersonaInst> implements PersonaInstLocal {
	private final static String SELECT_PERSONAINST = "SELECT a FROM PersonaInst a " + "where a.id.codInst = :codInst ";
	private final static String SELECT_PERSONA = "SELECT p FROM Persona p, PersonaInst a where p.codPersona = a.id.codPersona " +
			"and a.id.codInst = :codInst ";	
	public PersonaInst findByCodInst(String codInst) {
		PersonaInst personaInst = null;
		Query query = getEntityManager().createQuery(SELECT_PERSONAINST);
		query.setParameter("codInst", codInst.trim());

		List result = query.getResultList();
		if (result.size() > 0)
			personaInst = (PersonaInst) result.get(0);

		return personaInst;
	}
	public Persona findPersonaByCodInst(String codInst) {
		Persona persona = null;
		Query query = getEntityManager().createQuery(SELECT_PERSONA);
		query.setParameter("codInst", codInst.trim());

		List result = query.getResultList();
		if (result.size() > 0)
			persona = (Persona) result.get(0);

		return persona;
	}
	
	public List<PersonaInst> findByCodPersona(String codPersona) {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT a ");
		sb.append("FROM PersonaInst a ");
		sb.append("where a.id.codPersona = :codPersona ");		
		Query query = getEntityManager().createQuery(sb.toString());
		query.setParameter("codPersona", codPersona.trim());

		List result = query.getResultList();
		return result;
	}
	
	public PersonaInst findByCod(String codPersona, String codInst) {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT a ");
		sb.append("FROM PersonaInst a ");
		sb.append("where a.id.codPersona = :codPersona ");
		sb.append("and a.id.codInst = :codInst ");
		Query query = getEntityManager().createQuery(sb.toString());
		query.setParameter("codPersona", codPersona.trim());
		query.setParameter("codInst", codInst.trim());		

		List result = query.getResultList();
		if (result.size() > 0)
			return (PersonaInst) result.get(0);

		return null;

	}
	
	public PersonaInst saveorupdate(PersonaInst params) {
		PersonaInst horarioOld = findByCod(params.getId().getCodPersona(), params.getId().getCodInst());

		if (horarioOld == null) {
			makePersistent(params);
		} else {
			makePersistent(params);
		}

		horarioOld = findByCod(params.getId().getCodPersona(), params.getId().getCodInst());
		log.info("Actualizando Categoria " + horarioOld.toString());
		return horarioOld;
	}

	
}
