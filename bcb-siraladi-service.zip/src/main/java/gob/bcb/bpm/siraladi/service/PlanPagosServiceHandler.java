package gob.bcb.bpm.siraladi.service;

import gob.bcb.bpm.siraladi.exceptions.AladiException;
import gob.bcb.bpm.siraladi.exceptions.Layer;
import gob.bcb.bpm.siraladi.exceptions.SystemInternalException;
import gob.bcb.bpm.siraladi.exceptions.WrappedException;
import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.PlanPago;
import gob.bcb.bpm.siraladi.logic.AperturaServiceBean;
import gob.bcb.bpm.siraladi.logic.AperturaServiceLocal;
import gob.bcb.bpm.siraladi.logic.PlanPagosServiceBean;
import gob.bcb.bpm.siraladi.logic.PlanPagosServiceLocal;
import gob.bcb.bpm.siraladi.utils.Constants;
import gob.bcb.bpm.siraladi.utils.StatusCode;

import java.util.List;
import java.util.Map;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;

import org.apache.log4j.Logger;

/**
 * @author wilherrera Wilbert Herrera Flores Banco Central de Bolivia Departamento de Desarrollo
 */
public class PlanPagosServiceHandler implements ServiceAladiHandler {
	private static Logger log = Logger.getLogger(PlanPagosServiceHandler.class);

	
	private PlanPagosServiceLocal planPagosService;
	private EntityManager entityManager;

	public PlanPagosServiceHandler(EntityManager entityManager) {
		this.entityManager = entityManager;
		planPagosService = new PlanPagosServiceBean(entityManager);
	}

	
	public void handlerProcesarMsg(RequestContext requestContext) throws AladiException, NotSupportedException, SystemException, SecurityException,
			IllegalStateException, RollbackException, HeuristicMixedException, HeuristicRollbackException {
		String statusCode = StatusCode.OPERACION_RECEIVED;
		String consent = null;
		AperturaServiceLocal aperturaService = new AperturaServiceBean(entityManager);

		Map<String, Object> parametros = requestContext.getBcbRequest().getRequestElements();

		String codTipoOperacion = requestContext.getResponseContext().getOperacionAladi().getCodTipoOperacion();

		ResponseContext response = requestContext.getResponseContext();

		if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0502)) {
			throw new AladiException("TIPO_DE_OPERACION_NO_IMPLEMENTADA", new Object[] { requestContext.getResponseContext().getOperacionAladi()
					.getCodTipoOperacion() });
		} else if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0503)) {
			Apertura apertura = (Apertura) parametros.get("apertura");

			Apertura aperturaOut = aperturaService.getAperturaLocal().findByCodReembolso(apertura.getInstitucion().getCodInst(),
					apertura.getIdentificador().getCodId(), apertura.getAnio(), apertura.getSecuencia(), apertura.getDav());

			if (aperturaOut == null) {
				throw new AladiException("REEMBOLSO_INEXISTENTE", new Object[] { apertura.getNroReembLiteral() });
			}

			List<PlanPago> planPagoList = planPagosService.getPlanPagoLocal().findPlanPagos(aperturaOut.getNroMov(), null, null);
			response.addDescripcionParametro(codTipoOperacion, "listaplanpagos", "Custom", planPagoList);

			statusCode = StatusCode.OPERACION_SUCCESS;
			consent = "Operacion efectuada existosamente nroMov : " + aperturaOut.getNroMov();			
		} else if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0504)) {
			// crear o modificar un plan de pagos 
			Apertura apertura = (Apertura) parametros.get("apertura");
			String nroReembolso = apertura.getNroReembLiteral();
			apertura = aperturaService.getAperturaLocal().findByCodReembolso(apertura.getInstitucion().getCodInst(),
					apertura.getIdentificador().getCodId(), apertura.getAnio(), apertura.getSecuencia(), apertura.getDav());

			if (apertura == null) {
				throw new AladiException("REEMBOLSO_INEXISTENTE", new Object[] { nroReembolso});
			}
			
			List<PlanPago> planPagoList = (List<PlanPago>) parametros.get("listaplanpagos");
			if (planPagoList.size() == 0) {
				throw new AladiException("OBJETO_NULO", new Object[] { "listaplanpagos" });
			}
			if (planPagoList.size() > 1) {
				throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Lista de plan de pagos requiere solo un elemento" });
			}			
			planPagosService.begin();
			PlanPago planPago = planPagosService.modificar(planPagoList.get(0), apertura);
			
			planPagosService.commit();
			
			statusCode = StatusCode.OPERACION_SUCCESS;
			consent = "Plan de pagos modificado exitósamente con nro plan: " + planPagoList.get(0).getId().getNroMov();
			
			planPagoList.set(0, planPago);			
			response.addDescripcionParametro(codTipoOperacion, "apertura", "Custom", apertura);			
			response.addDescripcionParametro(codTipoOperacion, "listaplanpagos", "Custom", planPagoList);
			response.addTaskDescripAdicional(planPagosService.getWarnnings());

		} else {
			throw new AladiException("TIPO_DE_OPERACION_NO_IMPLEMENTADA", new Object[] { requestContext.getResponseContext().getOperacionAladi()
					.getCodTipoOperacion() });
		}
		response.updateReponse(statusCode, consent);
		log.info("Operacion realizada exitosamente operacion " + codTipoOperacion);
	}

}
