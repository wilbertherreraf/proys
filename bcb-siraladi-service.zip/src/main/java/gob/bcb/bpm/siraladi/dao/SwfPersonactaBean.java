package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.exceptions.AladiException;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.SwfPersonacta;
import gob.bcb.bpm.siraladi.jpa.SwfPersonactaPK;
import gob.bcb.bpm.siraladi.utils.Constants;

import java.util.List;


import javax.persistence.Query;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("swfPersonactaLocal")
@Transactional
public class SwfPersonactaBean extends GenericDAO<SwfPersonactaPK, SwfPersonacta> implements SwfPersonactaLocal {

	public SwfPersonacta findByCodigo(String pecCodpersona, String pecCodinst, String pecNrocta) {
		String jpql = "SELECT t FROM SwfPersonacta t ";
		jpql = jpql.concat("WHERE t.id.pecCodpersona = :pecCodpersona ");
		jpql = jpql.concat("and t.id.pecCodinst = :pecCodinst ");
		jpql = jpql.concat("and t.id.pecNrocta = :pecNrocta ");

		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("pecCodpersona", pecCodpersona);
		query.setParameter("pecCodinst", pecCodinst);
		query.setParameter("pecNrocta", pecNrocta);

		List lista = query.getResultList();
		if (lista.size() > 0) {
			return (SwfPersonacta) lista.get(0);
		}

		return null;
	}

	public SwfPersonacta recuperarCuentaActiva(String pecCodpersona, String pecCodinst, String pecEstadocta) {

		String jpql = "SELECT t FROM SwfPersonacta t ";
		jpql = jpql.concat("WHERE t.id.pecCodpersona = :pecCodpersona ");

		if (!StringUtils.isBlank(pecCodinst)) {
			jpql = jpql.concat("and t.id.pecCodinst = :pecCodinst ");
		}

		jpql = jpql.concat("and t.pecEstadocta = :pecEstadocta ");
		log.info("Buscando cuenta activa " + pecCodpersona + " " + pecCodinst + " " + pecEstadocta + " => " + jpql);
		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("pecCodpersona", pecCodpersona);

		if (!StringUtils.isBlank(pecCodinst)) {
			query.setParameter("pecCodinst", pecCodinst);
		}
		query.setParameter("pecEstadocta", pecEstadocta);

		List lista = query.getResultList();
		if (lista.size() == 0) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Cuenta activa inexistentes " + pecCodpersona
					+ " verifique en cuentas instituciones" });
		}
		if (lista.size() > 1) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Existen mas de Una Cuenta activa " + pecCodpersona
					+ " verifique en cuentas instituciones" });
		}

		return (SwfPersonacta) lista.get(0);
	}

	public List<SwfPersonacta> buscarCtasPersona(String pecCodpersona, String pecCodinst, String pecNrocta, String pecTipoctainst,
			String pecCodinstinter, String pecNroctainter, String pecEstadocta) {
		String jpql = "SELECT t FROM SwfPersonacta t ";
		jpql = jpql.concat("WHERE t.id.pecCodpersona = :pecCodpersona ");

		if (!StringUtils.isBlank(pecCodinst)) {
			jpql = jpql.concat("and t.id.pecCodinst = :pecCodinst ");
		}
		if (!StringUtils.isBlank(pecNrocta)) {
			jpql = jpql.concat("and t.id.pecNrocta = :pecNrocta ");
		}
		if (!StringUtils.isBlank(pecTipoctainst)) {
			jpql = jpql.concat("and t.pecTipoctainst = :pecTipoctainst ");
		}
		if (!StringUtils.isBlank(pecCodinstinter)) {
			jpql = jpql.concat("and t.pecCodinstinter = :pecCodinstinter ");
		}
		if (!StringUtils.isBlank(pecNroctainter)) {
			jpql = jpql.concat("and t.pecNroctainter = :pecNroctainter ");
		}

		if (!StringUtils.isBlank(pecEstadocta)) {
			jpql = jpql.concat("and t.pecEstadocta = :pecEstadocta ");
		}

		log.info("Query buscarCtasPersona " + jpql);
		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("pecCodpersona", pecCodpersona);

		if (!StringUtils.isBlank(pecCodinst)) {
			query.setParameter("pecCodinst", pecCodinst);
		}

		if (!StringUtils.isBlank(pecNrocta)) {
			query.setParameter("pecNrocta", pecNrocta);
		}
		if (!StringUtils.isBlank(pecTipoctainst)) {
			query.setParameter("pecTipoctainst", pecTipoctainst);
		}
		if (!StringUtils.isBlank(pecCodinstinter)) {
			query.setParameter("pecCodinstinter", pecCodinstinter);
		}
		if (!StringUtils.isBlank(pecNroctainter)) {
			query.setParameter("pecNroctainter", pecNroctainter);
		}
		if (!StringUtils.isBlank(pecEstadocta)) {
			query.setParameter("pecEstadocta", pecEstadocta);
		}
		List lista = query.getResultList();

		return lista;
	}

	public void guardarCuenta(SwfPersonacta swfPersonacta) {
		// agregar cuenta intermediario
		// validar camposº
		SwfPersonacta swfPersonactaOld = findByCodigo(swfPersonacta.getId().getPecCodpersona(), swfPersonacta.getId().getPecCodinst(), swfPersonacta
				.getId().getPecNrocta());
		if (swfPersonactaOld == null) {
			log.info("Muevo cuenta ");
			//cambiarEstados(swfPersonacta.getId().getPecCodpersona(), swfPersonacta.getId().getPecCodinst(), null,Constants.PAR_ESTADOCTANOAACTIVA);
			
			swfPersonacta.setPecEstadocta(Constants.PAR_ESTADOCTAACTIVA);
			persist(swfPersonacta);

			log.info("Muevo cuenta salvado " + swfPersonacta.getId().getPecNrocta());
		} else {
			log.info("modidfica cuenta " + swfPersonacta.getId().getPecNrocta());
			makePersistent(swfPersonacta);
			log.info("modidfica cuenta salvado " + swfPersonacta.getId().getPecNrocta());
		}
	}

	public void guardarCuentaPersona(SwfPersonacta swfPersonacta, SwfPersonacta swfPersonactaInter) {
		log.info("Agregando cuenta institucion ");
		// agregar cuenta intermediario
		// validar campos
		
		InstitucionLocal institucionLocal = new InstitucionBean();
		institucionLocal.setEntityManager(getEntityManager());
		
		SwfPersonacta swfPersonactaOld = findByCodigo(swfPersonacta.getId().getPecCodpersona(), swfPersonacta.getId().getPecCodinst(), swfPersonacta
				.getId().getPecNrocta());

		Institucion institucion = institucionLocal.findByCodInst(swfPersonacta.getId().getPecCodpersona());
		
		if (institucion == null){
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Institucion " + swfPersonacta.getId().getPecCodpersona()
					+ " inexistente" });			
		}
		
		if (StringUtils.isBlank(swfPersonacta.getId().getPecCodpersona())) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "codigo Persona nulo" });			
		}
		
		if (StringUtils.isBlank(swfPersonacta.getId().getPecCodinst())) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "codigo Institucion nulo" });			
		}		
		
		if (StringUtils.isBlank(swfPersonacta.getId().getPecNrocta())) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Nro cuenta nulo" });			
		}

		if (swfPersonacta.getId().getPecCodpersona().equals(swfPersonacta.getId().getPecCodinst())) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Codigo de persona y banco identicos" });
		}
		
		if (!StringUtils.isBlank(swfPersonacta.getPecCodinstinter())) {
			Institucion institucionInter = institucionLocal.findByCodInst(swfPersonacta.getPecCodinstinter());
			
			if (institucionInter == null){
				throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Institucion (intermediario) " + swfPersonacta.getPecCodinstinter()
						+ " inexistente" });			
			}		
		}
		
		if (swfPersonactaOld == null) {
			log.info("Muevo cuenta ");
			
			//cambiarEstados(swfPersonacta.getId().getPecCodpersona(), swfPersonacta.getId().getPecCodinst(), null,Constants.PAR_ESTADOCTANOAACTIVA);
			if (swfPersonactaInter != null) {
				if (swfPersonacta.getPecTipoctainst().equals("I")) {
					
					if (!StringUtils.isBlank(swfPersonacta.getPecCodinstinter()) && !StringUtils.isBlank(swfPersonacta.getPecNroctainter())) {
						log.info("Parametrizando para cta intermediaria " + swfPersonacta.getPecNroctainter()  + " " + swfPersonacta.getPecCodinstinter());
						
						swfPersonactaInter.getId().setPecNrocta(swfPersonacta.getPecNroctainter());
						swfPersonactaInter.getId().setPecCodinst(swfPersonacta.getPecCodinstinter());
						swfPersonactaInter.getId().setPecCodpersona(swfPersonacta.getId().getPecCodinst());

						SwfPersonacta swfPersonactaInterOld = findByCodigo(swfPersonactaInter.getId().getPecCodpersona(), swfPersonactaInter.getId().getPecCodinst(), swfPersonactaInter
								.getId().getPecNrocta());
						
						if (swfPersonactaInterOld == null){
							log.info("Registro de NUEVA cta intermediaria " + swfPersonacta.getPecNroctainter()  + " " + swfPersonacta.getPecCodinstinter());
							persist(swfPersonactaInter);
						}
					}
				}
			}
			//swfPersonacta.setPecEstadocta(Constants.PAR_ESTADOCTAACTIVA);
			persist(swfPersonacta);
			
			// definimos la nueva cuenta como la predeterminada para la institucion
			if (institucion.getCveTipoInst().equals("S")){
				institucion.setCtaCodinst(swfPersonacta.getId().getPecCodinst());
				institucion.setCtaNumero(swfPersonacta.getId().getPecNrocta());
				
				institucionLocal.makePersistent(institucion);
			}
			
			log.info("Muevo cuenta salvado " + swfPersonacta.getId().getPecNrocta());
		} else {
			log.info("modidfica cuenta " + swfPersonacta.getId().getPecNrocta());
			makePersistent(swfPersonacta);
			if (swfPersonactaInter != null) {
				if (swfPersonacta.getPecTipoctainst().equals("I")) {
					
					if (!StringUtils.isBlank(swfPersonacta.getPecCodinstinter()) && !StringUtils.isBlank(swfPersonacta.getPecNroctainter())) {
						log.info("Parametrizando para cta intermediaria " + swfPersonacta.getPecNroctainter()  + " " + swfPersonacta.getPecCodinstinter());
						
						swfPersonactaInter.getId().setPecNrocta(swfPersonacta.getPecNroctainter());
						swfPersonactaInter.getId().setPecCodinst(swfPersonacta.getPecCodinstinter());
						swfPersonactaInter.getId().setPecCodpersona(swfPersonacta.getId().getPecCodinst());

						SwfPersonacta swfPersonactaInterOld = findByCodigo(swfPersonactaInter.getId().getPecCodpersona(), swfPersonactaInter.getId().getPecCodinst(), swfPersonactaInter
								.getId().getPecNrocta());
						
						if (swfPersonactaInterOld == null){
							log.info("Registro de NUEVA cta intermediaria " + swfPersonacta.getPecNroctainter()  + " " + swfPersonacta.getPecCodinstinter());
							persist(swfPersonactaInter);
						} else {
							makePersistent(swfPersonactaInter);
						}
					}
				}
			}
			
		}
	}

	private void cambiarEstados(String pecCodpersona, String pecCodinst, String pecNrocta, String pecEstadocta) {
		log.info("En cambiarEstados: para " + pecCodpersona + " pecCodinst " + pecCodinst + " nuevo " + pecEstadocta);

		String jsql = "UPDATE SwfPersonacta c ";
		jsql = jsql.concat("SET c.pecEstadocta = :pecEstadocta ");
		jsql = jsql.concat("WHERE t.id.pecCodpersona = :pecCodpersona ");

		// if (!StringUtils.isBlank(pecCodinst)) {
		jsql = jsql.concat("and t.id.pecCodinst = :pecCodinst ");
		// }
		if (!StringUtils.isBlank(pecNrocta)) {
			jsql = jsql.concat("and t.id.pecNrocta = :pecNrocta ");
		}
		Query query = getEntityManager().createQuery(jsql);
		query.setParameter("pecEstadocta", pecEstadocta);
		query.setParameter("pecCodpersona", pecCodpersona);

		// if (!StringUtils.isBlank(pecCodinst)) {
		query.setParameter("pecCodinst", pecCodinst);
		// }
		if (!StringUtils.isBlank(pecNrocta)) {
			query.setParameter("pecNrocta", pecNrocta);
		}
		int result = query.executeUpdate();
		log.info("Modificados: " + result + " para " + pecCodpersona + " pecCodinst " + pecCodinst + " nuevo " + pecEstadocta);

	}

}
