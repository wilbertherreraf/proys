package gob.bcb.bpm.siraladi.exceptions;

import gob.bcb.bpm.siraladi.common.MsgManager;
import gob.bcb.bpm.siraladi.utils.StatusCode;

import java.util.ResourceBundle;

import javax.xml.namespace.QName;

import org.apache.log4j.Logger;
import org.w3c.dom.Element;

/**
 * This exception is used to mark business rule violations.
 * 
 * @author Christian Bauer <christian@hibernate.org>
 */
public class BusinessException extends UncheckedException {

	private String message;

	public static final ResourceBundle BUNDLE;
	static {
		ResourceBundle bundle = null;
		try {
			bundle = ResourceBundle.getBundle("messagesruntime");
			BUNDLE = bundle;
		} catch (Exception e) {
			throw new RuntimeException("No se pudo cargar archivo de mensajes 'messagesruntime'");
		}
	}

	/**
	 * Constructor
	 * 
	 * @param message
	 *            Mensaje de la excepcion
	 * @param ex
	 *            La excpecion como tal
	 */
	public BusinessException(String msg, Throwable t) {
		this(msg, BUNDLE, t);
	}

	/**
	 * Constructor
	 * 
	 * @param message
	 *            Mensaje para crear la nueva excepcion
	 */

	public BusinessException(String message) {
		// this(new MsgManager(message, BUNDLE));
		// whf ojooo eliminar cuando todas las excepciones esten codificadas
		// mensaje personalizado si el codigo no existe en la configuracion lo
		// setea a
		this(BUNDLE.containsKey(message) ? (new MsgManager(message, BUNDLE)) : (new MsgManager(StatusCode.ALADI_EXCEPTION, BUNDLE,
				new Object[] { message })));
	}

	public BusinessException(String message, Object... params) {
		this(new MsgManager(message, BUNDLE, params));
	}

	public BusinessException(MsgManager message, Throwable throwable) {
		super(message, throwable);
		this.message = message.toString();
		// code = FAULT_CODE_SERVER;
	}

	public BusinessException(MsgManager message) {
		super(message);
		this.message = message.toString();
		// code = FAULT_CODE_SERVER;
	}

	public BusinessException(String message, Logger log) {
		this(new MsgManager(message, log));
	}

	public BusinessException(String message, ResourceBundle b) {
		this(new MsgManager(message, b));
	}

	public BusinessException(String message, Logger log, Throwable t) {
		this(new MsgManager(message, log), t);
	}

	public BusinessException(String message, ResourceBundle b, Throwable t) {
		this(new MsgManager(message, b), t);
	}

	public BusinessException(String message, Logger log, Throwable t, Object... params) {
		this(new MsgManager(message, log, params), t);
	}

	public BusinessException(String message, ResourceBundle b, Throwable t, Object... params) {
		this(new MsgManager(message, b, params), t);
	}

	public BusinessException(Throwable t) {
		super(t);
        if (super.getMessage() != null) {
            message = super.getMessage();
		} else {
			message = t == null ? null : t.getMessage();
		}
		// code = FAULT_CODE_SERVER;
	}

	public BusinessException(MsgManager message, Throwable throwable, QName fc) {
		super(message, throwable);
		this.message = message.toString();
		// code = fc;
	}

	public BusinessException(MsgManager message, QName fc) {
		super(message);
		this.message = message.toString();
		// code = fc;
	}

	public BusinessException(Throwable t, QName fc) {
		super(t);
		if (super.getMessage() != null) {
			message = super.getMessage();
		} else {
			message = t == null ? null : t.getMessage();
		}
		// code = fc;
	}

	public String getMsgManager() {
		return message;
	}

	public void setMsgManager(String message) {
		this.message = message;
	}
}
