package gob.bcb.bpm.siraladi.logic;

import gob.bcb.bpm.siraladi.dao.AperturaLocal;
import gob.bcb.bpm.siraladi.dao.PlanPagoLocal;
import gob.bcb.bpm.siraladi.dao.UserTransactionServ;
import gob.bcb.bpm.siraladi.jpa.Apertura;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;



/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */

public interface AperturaServiceLocal extends UserTransactionServ{
	Apertura crearReg(Apertura apertura);	
	Apertura modificar(Apertura apertura);
	Apertura modificaSinValidacion(Apertura apertura);	
	boolean isValidData(Apertura apertura);

	/**
	 * valida la calificacion de riesgo segun la fecha de emision, actualizando el objeto apertura.
	 * Lanza una excepcion si hay error en datos
	 * 
	 * @param apertura objeto que pasa por referencia se actualiza el valor codCalif
	 */
	String validarCalifRiesgo(Apertura apertura, Date fechaTrans);

	Apertura liquidar(Apertura apertura);
	AperturaLocal getAperturaLocal() ;
	Map<String, Object> getWarnnings();
	void eliminar(Apertura apertura);
	
	/**
	 * control de saldos: el saldo del instrumento debe ser igual al saldo de pagos pendientes del plan de pagos
	 * @param apertura instrumento 
	 * @param cveEstadoPlan estado del plan para agregar al filtro
	 * @param fechaVal fecha hasta la cual sumar
	 */
	void controlSaldoPlanPagos(Apertura apertura, String cveEstadoPlan, Date fechaVal);
	Apertura anularInstrumento(Apertura apertura);
	String obtenerNIT(Apertura apertura, String nit, String codInstitucion, String tipoRegistro);
	
}
