package gob.bcb.bpm.siraladi.logic;

import gob.bcb.bpm.siraladi.exceptions.AladiException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TemporalType;

import org.apache.log4j.Logger;

public class ConsultasBD implements ConsultasBDLocal {
	private static Logger log = Logger.getLogger(ConsultasBD.class);
	private EntityManager entityManager;

	public ConsultasBD() {
	}
	public ConsultasBD(EntityManager entityManager) {
		this.entityManager = entityManager;		
	}	
	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.bpm.siraladi.logic.ConsultasBDLocal#getEntityManager()
	 */
	
	public EntityManager getEntityManager() {
		return entityManager;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.bpm.siraladi.logic.ConsultasBDLocal#setEntityManager(javax.
	 * persistence.EntityManager)
	 */
	
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gob.bcb.bpm.siraladi.logic.ConsultasBDLocal#getSaldoCont(java.lang.String
	 * , java.util.Date, java.lang.String)
	 */
	
	public BigDecimal getSaldoCont(String codPersona, Date fecha, String cveTipoApe) {
		BigDecimal resultProc = null;
		try {
			Query query = getEntityManager().createNativeQuery("execute procedure saldo_cont_mo(:cod_persona, :fecha, :cve_tipo_ape)");

			query.setParameter("cod_persona", codPersona);
			query.setParameter("fecha", fecha, TemporalType.DATE);
			query.setParameter("cve_tipo_ape", cveTipoApe);

			resultProc = (BigDecimal) query.getSingleResult();
		} catch (Exception e) {
			StringBuilder sb = new StringBuilder();
			int count = 0;
			for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
				if (cause instanceof SQLException) {
					count++;
					sb.append(cause.getMessage());
					sb.append(" , ");
				}
			}
			log.error("Error al ejecutar procedimiento almacenado saldo_cont_mo " + e.getMessage(), e);
			throw new AladiException((count > 0 ? sb.toString() : e.getMessage()));
		}
		return resultProc;
	}

}
