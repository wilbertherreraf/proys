package gob.bcb.bpm.siraladi.utils;

import java.io.File;
import java.sql.Connection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.XMLConfiguration;
import org.apache.log4j.Logger;

import gob.bcb.bpm.siraladi.service.ConfigurationServ;

/**
 * @author wilherrera Wilbert Herrera Flores Banco Central de Bolivia
 *         Departamento de Desarrollo
 */
public final class UtilsPersist {
	private static Logger log = Logger.getLogger(UtilsPersist.class);

	/**
	 * The name of the default persistence context. * {@value}
	 */
	// public static final String DEFAULT_PERSISTENCE_CONTEXT =
	// Constants.PERSISTENCE_UNIT_NAME_ALADI;
 
	private UtilsPersist() {
	}

	/**
	 * Crea un entity manager con valores por defecto
	 * 
	 * @return
	 */
	public static EntityManagerFactory createEntityManagerFactory(String serviceName) {
		String idDBConfigNameDefault = (String) ConfigurationServ.getConfigProperty(
				Constants.PROP_ID_DB_CONFIG_NAME_DEFAULT.replaceFirst("ID-SERVICENAME", serviceName), "string");
		Map<String, String> options = new HashMap<String, String>();
		
		final String propPersistenceUnitName = (String) ConfigurationServ.getConfigProperty(
				Constants.PROP_PERSISTENCE_UNIT_NAME.replaceFirst("ID-SERVICENAME", serviceName), "string");
		String url = (String) ConfigurationServ.getConfigProperty(Constants.PROP_DB_JDBC_URL.replaceFirst("ID-DATABASE", idDBConfigNameDefault), "string");
		String username = (String) ConfigurationServ.getConfigProperty(Constants.PROP_DB_JDBC_USER.replaceFirst("ID-DATABASE", idDBConfigNameDefault),
				"string");
		String password = (String) ConfigurationServ.getConfigProperty(Constants.PROP_DB_JDBC_PASSWORD.replaceFirst("ID-DATABASE", idDBConfigNameDefault),
				"string");
		String driver = (String) ConfigurationServ.getConfigProperty(Constants.PROP_DB_JDBC_DRIVER.replaceFirst("ID-DATABASE", idDBConfigNameDefault),
				"string");

		// propiedades por defecto
		options.put("hibernate.show_sql", "false");
		options.put("hibernate.format_sql", "true");		
		options.put("hibernate.dialect", "org.hibernate.dialect.InformixDialect");
		options.put("hibernate.connection.autocommit", "false");
		options.put("hibernate.connection.driver_class", driver);
		options.put("hibernate.connection.url", url);
		options.put("hibernate.connection.username", username);
		options.put("hibernate.connection.password", password);
		
		options.put("hibernate.c3p0.min_size", String.valueOf(5));
		options.put("hibernate.c3p0.max_size", String.valueOf(50));
		options.put("hibernate.c3p0.timeout", String.valueOf(300));		
		//options.put("hibernate.c3p0.acquire_increment", String.valueOf(1));
		options.put("hibernate.c3p0.max_statements", String.valueOf(50));
		options.put("hibernate.c3p0.idle_test_period", String.valueOf(3000));
		options.put("hibernate.connection.isolation", String.valueOf(Connection.TRANSACTION_SERIALIZABLE));		
		//options.put("hibernate.cache.provider_class","net.sf.ehcache.hibernate.EhCacheProvider");
		
		EntityManagerFactory factory;
		try {
			factory = Persistence.createEntityManagerFactory(propPersistenceUnitName, options);
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
			throw new RuntimeException(e);
		}
		log.info("Unidad de persistencia JPA configurado con " + propPersistenceUnitName + " en URL " + url + ", username " + username);
		return factory;
	}

	/**
	 * Creates an entity manager with the compile-time default name, as derived
	 * from {@link #DEFAULT_PERSISTENCE_CONTEXT}
	 * 
	 * @return a new entity manager
	 */

	public static EntityManagerFactory createEntityManagerFactory(Map options) {
		EntityManagerFactory factory;
		final String propPersistenceUnitName = (String) ConfigurationServ.getConfigProperty(
				Constants.PROP_PERSISTENCE_UNIT_NAME.replaceFirst("ID-SERVICENAME", ConfigurationServ.getServiceName()), "string");		
		factory = Persistence.createEntityManagerFactory(propPersistenceUnitName, options);
		return factory;
	}

	/**
	 * Create an entity manager
	 * 
	 * @param manager
	 *            name of the manager to retrieve from the persistence.xml
	 * @param options
	 *            any other options
	 * @return an EntityManagerFactory implementation
	 */
	public static EntityManagerFactory createManagerFactory(String manager, Map options) {
		EntityManagerFactory factory;
		factory = Persistence.createEntityManagerFactory(manager, options);
		return factory;
	}

	/**
	 * extract all properties from source with the given prefix, strip the
	 * prefix and return a new Properties instance with the values bound to the
	 * stripped keys
	 * 
	 * @param source
	 *            source properties
	 * @param prefix
	 *            prefix to match for and strip
	 * @return the set of matching and stripped properties (may be size 0, but
	 *         never null)
	 */
	public static Properties extractOptionsWithPrefix(Properties source, String prefix) {
		Properties result = new Properties();
		Enumeration keys = source.propertyNames();
		while (keys.hasMoreElements()) {
			String key = (String) keys.nextElement();
			if (key.startsWith(prefix)) {
				String tail = key.substring(prefix.length());
				result.setProperty(tail, source.getProperty(key));
			}
		}
		return result;
	}

	/**
	 * Roll back a transaction
	 * 
	 * @param tx
	 */

	public static void rollback(EntityTransaction tx) {
		if (tx != null && tx.isActive()) {
			tx.rollback();
		}
	}
	
	public static EntityManagerFactory createEntityManagerFactory2(String path, String idDBSource, final String persistenceUnit) {
		XMLConfiguration config = null;
		try {
			File f = new File(path);
			if (f.isDirectory() || !f.exists()){
				throw new RuntimeException("Error archivo inexistente " + path);
			}
			config = new XMLConfiguration(f);
		} catch (ConfigurationException e) {
			throw new RuntimeException(e);
		}
		String url = (String) Utils.getValueFromXML(config,Constants.PROP_DB_JDBC_URL.replaceFirst("ID-DATABASE", idDBSource), "string");
		String username = (String) Utils.getValueFromXML(config,Constants.PROP_DB_JDBC_USER.replaceFirst("ID-DATABASE", idDBSource),
				"string");
		String password = (String) Utils.getValueFromXML(config,Constants.PROP_DB_JDBC_PASSWORD.replaceFirst("ID-DATABASE", idDBSource),
				"string");
		String driver = (String) Utils.getValueFromXML(config,Constants.PROP_DB_JDBC_DRIVER.replaceFirst("ID-DATABASE", idDBSource),
				"string");
		
		Map<String, String> options = new HashMap<String, String>();
		
		// propiedades por defecto
		options.put("hibernate.show_sql", "false");
		options.put("hibernate.format_sql", "true");		
		options.put("hibernate.dialect", "org.hibernate.dialect.InformixDialect");
		options.put("hibernate.connection.autocommit", "false");
		options.put("hibernate.connection.driver_class", driver);
		options.put("hibernate.connection.url", url);
		options.put("hibernate.connection.username", username);
		options.put("hibernate.connection.password", password);
		
		options.put("hibernate.c3p0.min_size", String.valueOf(5));
		options.put("hibernate.c3p0.max_size", String.valueOf(50));
		options.put("hibernate.c3p0.timeout", String.valueOf(300));		
		//options.put("hibernate.c3p0.acquire_increment", String.valueOf(1));
		options.put("hibernate.c3p0.max_statements", String.valueOf(50));
		options.put("hibernate.c3p0.idle_test_period", String.valueOf(3000));
		options.put("hibernate.connection.isolation", String.valueOf(Connection.TRANSACTION_SERIALIZABLE));
		//options.put("hibernate.cache.provider_class","net.sf.ehcache.hibernate.EhCacheProvider");

		EntityManagerFactory factory;
		try {
			factory = Persistence.createEntityManagerFactory(persistenceUnit, options);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		log.info("Unidad de persistencia JPA configurado con " + idDBSource + " en URL " + url + ", username " + username);
		return factory;
	}
	
}
