package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the identificador database table.
 * 
 */
@Entity
@Table(name = "identificador")
public class Identificador implements Serializable{
	// private static final long serialVersionUID = 1L;
	// implements Serializable

	@Id
	@Column(name = "cod_id", unique = true, nullable = false, length = 1)
	private String codId;

	@Column(name = "cod_usuario")
	private String codUsuario;

	@Column(name = "estacion")
	private String estacion;

	@Column(name = "fecha_hora")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fechaHora;

	@Column(name = "nom_id")
	private String nomId;

	/*
	 * //bi-directional many-to-one association to Apertura
	 * 
	 * @OneToMany(mappedBy="identificador") private List<Apertura> aperturas;
	 * 
	 * //bi-directional many-to-many association to Instrumento
	 * 
	 * @ManyToMany(mappedBy="identificadors") private List<Instrumento> instrumentos;
	 */
	public Identificador() {
	}

	public String getCodId() {
		return this.codId;
	}

	public void setCodId(String codId) {
		this.codId = codId;
	}

	public String getCodUsuario() {
		return this.codUsuario;
	}

	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getNomId() {
		return this.nomId;
	}

	public void setNomId(String nomId) {
		this.nomId = nomId;
	}
	/*
	 * public List<Apertura> getAperturas() { return this.aperturas; }
	 * 
	 * public void setAperturas(List<Apertura> aperturas) { this.aperturas = aperturas; }
	 * 
	 * public List<Instrumento> getInstrumentos() { return this.instrumentos; }
	 * 
	 * public void setInstrumentos(List<Instrumento> instrumentos) { this.instrumentos = instrumentos; }
	 */
}
