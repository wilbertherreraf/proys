package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.dao.qnative.QCoinCommos;
import gob.bcb.bpm.siraladi.exceptions.AladiException;
//import gob.bcb.bpm.siraladi.jpa.DiaEspecial;
import gob.bcb.bpm.siraladi.jpa.Horario;
import gob.bcb.bpm.siraladi.jpa.HorarioPK;
import gob.bcb.bpm.siraladi.jpa.Usuario;
import gob.bcb.bpm.siraladi.service.session.UserSessionHolder;
import gob.bcb.bpm.siraladi.utils.Constants;
import gob.bcb.bpm.siraladi.utils.UtilsDate;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;


import javax.persistence.Query;
import javax.persistence.TemporalType;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("horarioLocal")
@Transactional
public class HorarioBean extends GenericDAO<HorarioPK, Horario> implements HorarioLocal {
	private static Logger log = Logger.getLogger(HorarioBean.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gob.bcb.bpm.siraladi.dao.HorarioLocal#operacionEstaEnHorario(java.lang
	 * .String, java.lang.String, java.lang.String, java.util.Date)
	 */
	public boolean operacionEstaEnHorario(String codTipoOper, String codHorario, Date hora) {

		if (UserSessionHolder.get("codIFARequest").equals("900")) {
			return true;
		}

		// determinar si la operacion esta como controlada por horario
		List<Horario> horarioList = findListByTOper(codTipoOper);
		if (horarioList.size() == 0) {
			return true;
		}

		// determinar si el dia es habil
		QCoinCommos qCoinCommos = new QCoinCommos("coin");
		if (!qCoinCommos.isHabil(hora)) {
			return false;
		}

		// determinar si esta en tabla de horarios especiales
//		DiaEspecial diaEspecial = diaEspByTOperCodHorario(codTipoOper, codHorario, hora, false);
//		// si la fecha esta registrada quiere decir que se evalua por la misma
//		if (diaEspecial != null) {
//			log.info("Fecha dia con horario especial "
//					+ UtilsDate.stringFromDate((Date) UserSessionHolder.get(Constants.AUDIT_HORA_RECEPCION), Constants.FORMAT_DATE_TIME));
//			DiaEspecial diaEsp = diaEspByTOperCodHorario(codTipoOper, codHorario, hora, true);
//			return (diaEsp != null);
//		}

		// determinar si esta en horario
		Horario horario = findByTOper(codTipoOper, codHorario, hora);
		return (horario != null);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gob.bcb.bpm.siraladi.dao.HorarioLocal#findHorarioByTOper(java.lang.String
	 * , java.lang.String, java.util.Date)
	 */
	public Horario findByTOper(String codTipoOper, String codHorario, Date hora) {
		String jpql = "SELECT h FROM Horario h where h.id.codOperacion = :codTipoOper and h.id.codHorario = :codHorario and h.cveEstadoHor = 'V' "
				+ "and :hora between h.horaIni and h.horaFin ";

		Calendar horaParam = GregorianCalendar.getInstance();

		if (hora != null) {
			horaParam.setTime(hora);
		}

		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("codTipoOper", codTipoOper);
		query.setParameter("codHorario", codHorario);
		query.setParameter("hora", horaParam.getTime(), TemporalType.TIME);

		List result = query.getResultList();
		if (result.size() > 0) {
			return (Horario) result.get(0);
		}

		return null;

	}
	public Horario findByCodigo(String codTipoOper, String codHorario) {
		String jpql = "SELECT h FROM Horario h where h.id.codOperacion = :codTipoOper and h.id.codHorario = :codHorario ";

		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("codTipoOper", codTipoOper);
		query.setParameter("codHorario", codHorario);

		List result = query.getResultList();
		if (result.size() > 0) {
			return (Horario) result.get(0);
		}

		return null;

	}
//	public DiaEspecial diaEspByTOperCodHorario(String codTipoOper, String codHorario, Date hora, boolean addCondicionHora) {
//		String jpql = "SELECT h FROM DiaEspecial h where h.id.codOperacion = :codTipoOper and h.id.codHorario = :codHorario " +
//				"and h.id.fecha = :fecha ";
//		
//		if (addCondicionHora)
//			jpql += "and :hora between h.horaIni and h.horaFin ";
//
//		Query query = getEntityManager().createQuery(jpql);
//		query.setParameter("codTipoOper", codTipoOper);
//		query.setParameter("codHorario", codHorario);
//		query.setParameter("fecha", hora, TemporalType.DATE);
//		
//		if (addCondicionHora)
//			query.setParameter("hora", hora, TemporalType.TIME);
//
//		List result = query.getResultList();
//		if (result.size() > 0) {
//			return (DiaEspecial) result.get(0);
//		}
//
//		return null;
//
//	}

	public List<Horario> findListByTOper(String codTipoOper) {
		String jpql = "SELECT h FROM Horario h where h.id.codOperacion = :codTipoOper and h.cveEstadoHor = 'V' ";

		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("codTipoOper", codTipoOper);

		return query.getResultList();
	}
	
	public List<Horario> getSocHorarioList() {
		String jpql = "SELECT h FROM Horario h order by h.id.codOperacion ";

		Query query = getEntityManager().createQuery(jpql);

		return query.getResultList();
	}
	
	public Horario saveorupdate(Horario horario ) {
		log.info("Actualizando Horario " + horario.toString());
		Horario horarioOld = findByCodigo(horario.getId().getCodOperacion(), horario.getId().getCodHorario());
		
		if (horarioOld == null){
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Horario inexistente" });
		} else {
			makePersistent(horario);
		}
		horarioOld = findByCodigo(horario.getId().getCodOperacion(), horario.getId().getCodHorario());
		
		return horarioOld; 
	}	
}
