package gob.bcb.bpm.siraladi.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


import gob.bcb.bpm.siraladi.jpa.Registro;


public interface RegistroLocal extends DAO<Integer, Registro> {
	/**
	 * Retorna Suma entre debeMo - p.haberMo de una emision menos gastos y
	 * comisiones y que esten contabilizados
	 * 
	 * @param nroMov
	 *            codigo de apertura
	 * @param em
	 *            Enitiy manager de la sesi n
	 * @return Suma de registro, si la apertura no existe retorna CERO
	 */
	BigDecimal getSaldoRegistro(Integer nroMov);

	/**
	 * Retorna la lista de registros por nro mov de apertura y estado del
	 * registro, si cveEstadoReg es nulo retorna todos
	 * 
	 * @param nroMovApe
	 * @param cveEstadoReg
	 * @return
	 */
	List<Registro> getByNroMovApeCveEstadoReg(Integer nroMovApe, String cveEstadoReg);

	BigDecimal getMontoSinNroMov(Integer nroMovApe, Integer nroMov);

	/**
	 * Retorna el saldo contingente sobre una apertura Suma entre debeMo -
	 * p.haberMo sobre transacciones antes de una fecha y para una persona
	 * 
	 * @param codPersona
	 *            codigo de entidad
	 * @param fechaTrans
	 *            fecha hasta la cual se calcula solo de contabilizados
	 * @param cveTipoApe
	 *            tipo de apertura, si es Importacion se matchea con
	 *            apertura.codInst de lo contrario con PersonaInst.codInst
	 * @return
	 */
	BigDecimal getSaldoCont(String codPersona, Date fechaTrans, String cveTipoApe);

	/**
	 * Retorna los registros segun el tipo de emision(Incremento, Decremento,
	 * Emision) de una emision
	 * 
	 * @param nroMov
	 *            nro de apertura o emsion
	 * @param cveTipoEmis
	 *            'I'ncremento, 'D'ecremento, 'E'mision, ver Claves
	 * @param em
	 * @return retorna una lista de valores Registros
	 */
	List<Registro> getRegistroByTipoEmis(Integer nroMov, String cveTipoEmis);

	Registro getByNroMov(Integer nroMov);
}
