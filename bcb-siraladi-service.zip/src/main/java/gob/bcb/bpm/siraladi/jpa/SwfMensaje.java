package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the swf_mensaje database table.
 * 
 */
@Entity
@Table(name = "swf_mensaje")
public class SwfMensaje implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "men_codmen")
	private Integer menCodmen;

	@Column(name = "men_codoperacion")
	private String menCodoperacion;

	@Column(name = "men_codmt")
	private String menCodmt;

	@Column(name = "men_nrocorr")
	private Integer menNrocorr;

	@Column(name = "men_plano")
	private String menPlano;

	@Column(name = "men_bic")
	private String menBic;

	@Column(name = "men_bicemisor")
	private String menBicemisor;
	
	@Column(name = "men_codmon")
	private Integer menCodmon;

	@Column(name = "men_monto")
	private BigDecimal menMonto;

	@Column(name = "men_codmonswift")
	private String menCodmonswift;

	@Column(name = "men_cveestswift")
	private String menCveestswift;

	@Column(name = "men_nrolavado")
	private Integer menNrolavado;
	
	@Column(name = "men_codusrswf")
	private String menCodusrswf;

	@Column(name = "men_gestion")
	private Integer menGestion;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "men_fecreg")
	private Date menFecreg;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "men_fecauto")
	private Date menFecauto;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "men_fecvalor")
	private Date menFecvalor;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "men_auditfho")
	private Date menAuditfho;

	@Column(name = "men_auditusr")
	private String menAuditusr;

	@Column(name = "men_auditwst")
	private String menAuditwst;

	public SwfMensaje() {
	}

	public Integer getMenCodmen() {
		return this.menCodmen;
	}

	public void setMenCodmen(Integer menCodmen) {
		this.menCodmen = menCodmen;
	}

	public String getMenCodmt() {
		return this.menCodmt;
	}

	public void setMenCodmt(String menCodmt) {
		this.menCodmt = menCodmt;
	}

	public String getMenPlano() {
		return this.menPlano;
	}

	public void setMenPlano(String menPlano) {
		this.menPlano = menPlano;
	}

	public Integer getMenCodmon() {
		return menCodmon;
	}

	public void setMenCodmon(Integer menCodmon) {
		this.menCodmon = menCodmon;
	}

	public Date getMenFecreg() {
		return menFecreg;
	}

	public void setMenFecreg(Date menFecreg) {
		this.menFecreg = menFecreg;
	}

	public Integer getMenNrocorr() {
		return menNrocorr;
	}

	public void setMenNrocorr(Integer menNrocorr) {
		this.menNrocorr = menNrocorr;
	}

	public Integer getMenGestion() {
		return menGestion;
	}

	public void setMenGestion(Integer menGestion) {
		this.menGestion = menGestion;
	}

	public Date getMenAuditfho() {
		return menAuditfho;
	}

	public void setMenAuditfho(Date menAuditfho) {
		this.menAuditfho = menAuditfho;
	}

	public String getMenAuditusr() {
		return menAuditusr;
	}

	public void setMenAuditusr(String menAuditusr) {
		this.menAuditusr = menAuditusr;
	}

	public String getMenAuditwst() {
		return menAuditwst;
	}

	public void setMenAuditwst(String menAuditwst) {
		this.menAuditwst = menAuditwst;
	}

	public String getMenBic() {
		return menBic;
	}

	public void setMenBic(String menBic) {
		this.menBic = menBic;
	}

	public String getMenCodoperacion() {
		return menCodoperacion;
	}

	public void setMenCodoperacion(String menCodoperacion) {
		this.menCodoperacion = menCodoperacion;
	}

	public BigDecimal getMenMonto() {
		return menMonto;
	}

	public void setMenMonto(BigDecimal menMonto) {
		this.menMonto = menMonto;
	}

	public String getMenCodmonswift() {
		return menCodmonswift;
	}

	public void setMenCodmonswift(String menCodmonswift) {
		this.menCodmonswift = menCodmonswift;
	}

	public String getMenCveestswift() {
		return menCveestswift;
	}

	public void setMenCveestswift(String menCveestswift) {
		this.menCveestswift = menCveestswift;
	}

	public String getMenCodusrswf() {
		return menCodusrswf;
	}

	public void setMenCodusrswf(String menCodusrswf) {
		this.menCodusrswf = menCodusrswf;
	}

	public Date getMenFecvalor() {
		return menFecvalor;
	}

	public void setMenFecvalor(Date menFecvalor) {
		this.menFecvalor = menFecvalor;
	}

	public String getMenBicemisor() {
		return menBicemisor;
	}

	public void setMenBicemisor(String menBicemisor) {
		this.menBicemisor = menBicemisor;
	}

	public Date getMenFecauto() {
		return menFecauto;
	}

	public void setMenFecauto(Date menFecauto) {
		this.menFecauto = menFecauto;
	}

	public Integer getMenNrolavado() {
		return menNrolavado;
	}

	public void setMenNrolavado(Integer menNrolavado) {
		this.menNrolavado = menNrolavado;
	}

	@Override
	public String toString() {
		return "SwfMensaje [menCodmen=" + menCodmen + ", menCodoperacion=" + menCodoperacion + ", menCodmt=" + menCodmt
				+ ", menNrocorr=" + menNrocorr + ", menBic=" + menBic + ", menBicemisor="
				+ menBicemisor + ", menCodmon=" + menCodmon + ", menMonto=" + menMonto + ", menCodmonswift="
				+ menCodmonswift + ", menCveestswift=" + menCveestswift + ", menNrolavado=" + menNrolavado
				+ ", menCodusrswf=" + menCodusrswf + ", menGestion=" + menGestion + ", menFecreg=" + menFecreg
				+ ", menFecauto=" + menFecauto + ", menFecvalor=" + menFecvalor + ", menAuditfho=" + menAuditfho
				+ ", menAuditusr=" + menAuditusr + ", menAuditwst=" + menAuditwst + "]";
	}

	
}