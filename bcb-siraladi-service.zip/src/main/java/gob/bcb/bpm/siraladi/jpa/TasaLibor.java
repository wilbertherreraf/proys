package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;



/**
 * The persistent class for the tasa_libor database table.
 * 
 */
@Entity
@Table(name="tasa_libor")
public class TasaLibor implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
    @Temporal( TemporalType.TIMESTAMP)
	@Column(name="fecha_tasa", unique=true, nullable=false)
	private Date fechaTasa;

	@Column(name="tasa_libor", precision=8, scale=5)
	private BigDecimal tasaLibor;

    public TasaLibor() {
    }

	public Date getFechaTasa() {
		return this.fechaTasa;
	}

	public void setFechaTasa(Date fechaTasa) {
		this.fechaTasa = fechaTasa;
	}

	public BigDecimal getTasaLibor() {
		return this.tasaLibor;
	}

	public void setTasaLibor(BigDecimal tasaLibor) {
		this.tasaLibor = tasaLibor;
	}

}
