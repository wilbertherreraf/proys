package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the cargo database table.
 * 
 */
@Entity
@Table(name="cargo")
public class Cargo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="cod_cargo")
	private Integer codCargo;

	@Column(name="cod_moneda")
	private String codMoneda;

	@Column(name="cod_persona")
	private String codPersona;

	@Column(name="cta_coin")
	private String ctaCoin;

	@Column(name="cve_tipo_ape")
	private String cveTipoApe;

	@Column(name="cve_tipo_cargo")
	private String cveTipoCargo;

	@Column(name="descrip")
	private String descrip;

	@Column(name="valor")
	private String valor;

	@ManyToOne
	@JoinColumn(name="cod_moneda", insertable = false, updatable=false)
	private Moneda moneda ;
	
    public Cargo() {
    }

	public Integer getCodCargo() {
		return this.codCargo;
	}

	public void setCodCargo(Integer codCargo) {
		this.codCargo = codCargo;
	}

	public String getCodMoneda() {
		return this.codMoneda;
	}

	public void setCodMoneda(String codMoneda) {
		this.codMoneda = codMoneda;
	}

	public String getCodPersona() {
		return this.codPersona;
	}

	public void setCodPersona(String codPersona) {
		this.codPersona = codPersona;
	}

	public String getCtaCoin() {
		return this.ctaCoin;
	}

	public void setCtaCoin(String ctaCoin) {
		this.ctaCoin = ctaCoin;
	}

	public String getCveTipoApe() {
		return this.cveTipoApe;
	}

	public void setCveTipoApe(String cveTipoApe) {
		this.cveTipoApe = cveTipoApe;
	}

	public String getCveTipoCargo() {
		return this.cveTipoCargo;
	}

	public void setCveTipoCargo(String cveTipoCargo) {
		this.cveTipoCargo = cveTipoCargo;
	}

	public String getDescrip() {
		return this.descrip;
	}

	public void setDescrip(String descrip) {
		this.descrip = descrip;
	}

	public String getValor() {
		return this.valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	public Moneda getMoneda() {
		return moneda;
	}

	public void setMoneda(Moneda moneda) {
		this.moneda = moneda;
	}

	
	public String toString() {
		return "Cargo [codCargo=" + codCargo + ", codMoneda=" + codMoneda + ", codPersona=" + codPersona + ", ctaCoin=" + ctaCoin + ", cveTipoApe="
				+ cveTipoApe + ", cveTipoCargo=" + cveTipoCargo + ", descrip=" + descrip + ", valor=" + valor + ", moneda=" + moneda + "]";
	}

}
