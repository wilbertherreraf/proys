
package gob.bcb.bpm.siraladi.ws.clientaladi.asicapccb;

import gob.bcb.bpm.siraladi.ws.clientaladi.LocalDateAdapter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import org.joda.time.LocalDate;


/**
 * <p>Java class for sdtSICAPCCB.sdtSICAPCCBItem complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="sdtSICAPCCB.sdtSICAPCCBItem">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="CodigoRpta" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Convenio" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="InstEmisora" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="FechaCargo" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="NroDebito" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="InstPagadora" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="NroReembolso" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Instrumento" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Fecha" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="Monto" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="Observaciones" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "sdtSICAPCCB.sdtSICAPCCBItem", propOrder = {

})
public class SdtSICAPCCBSdtSICAPCCBItem {

    @XmlElement(name = "CodigoRpta", required = false)
    protected String codigoRpta;
    @XmlElement(name = "Convenio", required = false)
    protected String convenio;
    @XmlElement(name = "InstEmisora", required = false)
    protected String instEmisora;
//    @XmlElement(name = "FechaCargo", required = false)
//    @XmlSchemaType(name = "date")
    @XmlElement(name = "FechaCargo")
    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    @XmlSchemaType(name = "date")    
    protected LocalDate fechaCargo;
    @XmlElement(name = "NroDebito")
    protected int nroDebito;
    @XmlElement(name = "InstPagadora", required = false)
    protected String instPagadora;
    @XmlElement(name = "NroReembolso", required = false)
    protected String nroReembolso;
    @XmlElement(name = "Instrumento", required = false)
    protected String instrumento;
//    @XmlElement(name = "Fecha", required = false)
//    @XmlSchemaType(name = "date")
//    protected XMLGregorianCalendar fecha;
    
    @XmlElement(name = "Fecha")
    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    @XmlSchemaType(name = "date")    
    protected LocalDate fecha;
    
    @XmlElement(name = "Monto")
    protected double monto;
    @XmlElement(name = "Observaciones", required = false)
    protected String observaciones;

    /**
     * Gets the value of the codigoRpta property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigoRpta() {
        return codigoRpta;
    }

    /**
     * Sets the value of the codigoRpta property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigoRpta(String value) {
        this.codigoRpta = value;
    }

    /**
     * Gets the value of the convenio property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConvenio() {
        return convenio;
    }

    /**
     * Sets the value of the convenio property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConvenio(String value) {
        this.convenio = value;
    }

    /**
     * Gets the value of the instEmisora property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInstEmisora() {
        return instEmisora;
    }

    /**
     * Sets the value of the instEmisora property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInstEmisora(String value) {
        this.instEmisora = value;
    }

    /**
     * Gets the value of the fechaCargo property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public LocalDate getFechaCargo() {
        return fechaCargo;
    }

    /**
     * Sets the value of the fechaCargo property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFechaCargo(LocalDate value) {
        this.fechaCargo = value;
    }

    /**
     * Gets the value of the nroDebito property.
     * 
     */
    public int getNroDebito() {
        return nroDebito;
    }

    /**
     * Sets the value of the nroDebito property.
     * 
     */
    public void setNroDebito(int value) {
        this.nroDebito = value;
    }

    /**
     * Gets the value of the instPagadora property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInstPagadora() {
        return instPagadora;
    }

    /**
     * Sets the value of the instPagadora property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInstPagadora(String value) {
        this.instPagadora = value;
    }

    /**
     * Gets the value of the nroReembolso property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNroReembolso() {
        return nroReembolso;
    }

    /**
     * Sets the value of the nroReembolso property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNroReembolso(String value) {
        this.nroReembolso = value;
    }

    /**
     * Gets the value of the instrumento property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInstrumento() {
        return instrumento;
    }

    /**
     * Sets the value of the instrumento property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInstrumento(String value) {
        this.instrumento = value;
    }

    /**
     * Gets the value of the fecha property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public LocalDate getFecha() {
        return fecha;
    }

    /**
     * Sets the value of the fecha property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFecha(LocalDate value) {
        this.fecha = value;
    }

    /**
     * Gets the value of the monto property.
     * 
     */
    public double getMonto() {
        return monto;
    }

    /**
     * Sets the value of the monto property.
     * 
     */
    public void setMonto(double value) {
        this.monto = value;
    }

    /**
     * Gets the value of the observaciones property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getObservaciones() {
        return observaciones;
    }

    /**
     * Sets the value of the observaciones property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setObservaciones(String value) {
        this.observaciones = value;
    }

}
