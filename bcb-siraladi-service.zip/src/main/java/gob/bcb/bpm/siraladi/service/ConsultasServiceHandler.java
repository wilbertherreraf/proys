package gob.bcb.bpm.siraladi.service;

import java.util.Date;

import java.util.List;
import java.util.Map;

import gob.bcb.bpm.siraladi.exceptions.AladiException;
import gob.bcb.bpm.siraladi.exceptions.Layer;
import gob.bcb.bpm.siraladi.exceptions.WrappedException;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.TPagoImp;
import gob.bcb.bpm.siraladi.logic.InstitucionServiceBean;
import gob.bcb.bpm.siraladi.logic.InstitucionServiceLocal;
import gob.bcb.bpm.siraladi.utils.Constants;
import gob.bcb.bpm.siraladi.utils.StatusCode;
import gob.bcb.bpm.siraladi.ws.clientaladi.ClientAladiWSHandler;

import javax.persistence.EntityManager;

import org.apache.log4j.Logger;

/**
 * @author wilherrera Wilbert Herrera Flores Banco Central de Bolivia
 *         Departamento de Desarrollo
 */
public class ConsultasServiceHandler implements ServiceAladiHandler {
	private static Logger log = Logger.getLogger(ConsultasServiceHandler.class);
	private InstitucionServiceLocal institucionService;

	private EntityManager entityManager;

	public ConsultasServiceHandler(EntityManager entityManager) {
		this.entityManager = entityManager;
		institucionService = new InstitucionServiceBean(entityManager);
	}

	public void handlerProcesarMsg(RequestContext requestContext) throws AladiException {
		// procesa consultas a la base
		String statusCode = StatusCode.OPERACION_RECEIVED;
		String consent = null;

		Map<String, Object> parametros = requestContext.getBcbRequest().getRequestElements();

		String codTipoOperacion = requestContext.getResponseContext().getOperacionAladi().getCodTipoOperacion();

		ResponseContext response = requestContext.getResponseContext();

		log.info("inicio tipo de operacion " + codTipoOperacion);

			if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0601)) {
				// consulta a ws sobre instituciones
				Date fechaDesde = (Date) parametros.get("fechaDesde");
				Date fechaHasta = (Date) parametros.get("fechaHasta");

				List<Institucion> institucionList = ClientAladiWSHandler.execWSAifacif("A", entityManager);
				institucionList.addAll(ClientAladiWSHandler.execWSAifacif("F", entityManager));
				response.addDescripcionParametro(codTipoOperacion, "listainstitucion", "Custom", institucionList);

				statusCode = StatusCode.OPERACION_SUCCESS;
				consent = "Operacion efectuada exist samente";

			} else if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0602)) {
 
				List<Institucion> institucionList = (List<Institucion>) parametros.get("listainstitucion");
				
				institucionList = institucionService.crearReg(institucionList);
				
				if (institucionList.size() == 0){
					throw new AladiException("ERROR_ACTUALIZAR_INSTITUCIONES", new Object[]{ "El proceso no registro ninguna instituci n"});					
				}
				
				statusCode = StatusCode.OPERACION_SUCCESS;
				consent = "Operaci n de registro instituciones efectuada exist samente";

			} else if (codTipoOperacion.equalsIgnoreCase(Constants.TIPO_OPERACION_AL0603)) {
				List<Institucion> institucionList = ClientAladiWSHandler.execWSAifacif("A", entityManager);
				institucionList.addAll(ClientAladiWSHandler.execWSAifacif("F", entityManager));
				
				institucionService.suspenderInstituciones();
				institucionList = institucionService.crearReg(institucionList);
				if (institucionList.size() == 0){
					throw new AladiException("ERROR_ACTUALIZAR_INSTITUCIONES", new Object[]{ "El proceso no registro ninguna instituci n"});
				}
				statusCode = StatusCode.OPERACION_SUCCESS;
				consent = "Operaci n de registro instituciones efectuada exist samente";
			} else {
				throw new AladiException("TIPO_DE_OPERACION_NO_IMPLEMENTADA", new Object[] { requestContext.getResponseContext().getOperacionAladi()
						.getCodTipoOperacion() });
			}
			response.updateReponse(statusCode, consent);
			log.info("Operacion realizada exitosamente operacion " + codTipoOperacion);
			log.info(response.toString());
	}
}
