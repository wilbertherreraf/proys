package gob.bcb.bpm.siraladi.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public final class UtilsDate {
	/**
	 * Retorna un objeto Date a partir de un formato definido, si el formato es
	 * incorrecto se lanza una excepcion Ejemplos: dd/MM/yyyy 12/10/2011,
	 * dd.MM.yy 09.04.98, yyyy.MM.dd G 'at' hh:mm:ss z 1998.04.09 AD at 06:15:55
	 * PDT EEE, MMM d, ''yy Thu, Apr 9, '98 h:mm a 6:15 PM H:mm 18:15
	 * H:mm:ss:SSS 18:15:55:624 K:mm a,z 6:15 PM,PDT yyyy.MMMMM.dd GGG hh:mm aaa
	 * 
	 * @param date
	 *            cadena fecha
	 * @param format
	 *            formato de la fecha introducida
	 * @return objeto Date
	 */
	public static Date dateFromString(String date, String format) {
		SimpleDateFormat formatoDelTexto = new SimpleDateFormat(format);
		Date fecha = null;
		try {
			fecha = formatoDelTexto.parse(date);
		} catch (ParseException ex) {
			try{
				SimpleDateFormat formatoDelTexto1 = new SimpleDateFormat(format, new Locale("es", "ES"));
				fecha = formatoDelTexto1.parse(date);
			}catch (Exception e) {
				ex.printStackTrace();
			}
		}
		return fecha;
	}

	/**
	 * Retorna una cadena con formato fecha. Ejemplos: dd/MM/yyyy 12/10/2011
	 * dd.MM.yy 09.04.98 yyyy.MM.dd G 'at' hh:mm:ss z 1998.04.09 AD at 06:15:55
	 * PDT EEE, MMM d, ''yy Thu, Apr 9, '98 h:mm a 6:15 PM H:mm 18:15
	 * H:mm:ss:SSS 18:15:55:624 K:mm a,z 6:15 PM,PDT yyyy.MMMMM.dd GGG hh:mm aaa
	 * 
	 * @param date
	 *            fecha a dar formato
	 * @param format
	 *            formato de fecha segun los ejemplos u otros
	 * @return
	 */
	public static String stringFromDate(Date date, String format) {
		SimpleDateFormat formatoDelTexto = new SimpleDateFormat(format);
		String fecha = null;
		// try {
		fecha = formatoDelTexto.format(date);
		/*
		 * } catch (ParseException ex) { ex.printStackTrace(); }
		 */
		return fecha;
	}

	/**
	 * retorna un objeto XML de formato fecha para intercambio de fechas en
	 * objetos xml
	 * 
	 * @param fecha
	 * @param delimitador
	 * @return
	 */
	public static XMLGregorianCalendar StrToXMLGregoCal(String fecha, String delimitador) {

		String[] fec_YYYYMMDD = null;
		GregorianCalendar gcal = new GregorianCalendar();
		Date fecha1 = dateFromString(fecha, "yyyy-MM-dd") ;
		XMLGregorianCalendar fecGregoCal = null;
		try {
			fecGregoCal = DatatypeFactory.newInstance().newXMLGregorianCalendar(gcal);

			fec_YYYYMMDD = fecha.split(delimitador);

			fecGregoCal.setYear(Integer.parseInt(fec_YYYYMMDD[0]));
			fecGregoCal.setMonth(Integer.parseInt(fec_YYYYMMDD[1]));
			fecGregoCal.setDay(Integer.parseInt(fec_YYYYMMDD[2]));

		} catch (DatatypeConfigurationException ex) {
			// Logger.getLogger(WSasicap_ccb_ws.class.getName()).log(Level.SEVERE,
			// null, ex);
			System.out.println(ex.getMessage());
		}
		Calendar c = GregorianCalendar.getInstance();
		c.setTime(fecha1);
		DatatypeFactory factory = null;
		try {
			factory = DatatypeFactory.newInstance();
		} catch (DatatypeConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//whf definir cual es el optimo
		XMLGregorianCalendar calendar = factory.newXMLGregorianCalendar((GregorianCalendar) c);
		//return fecGregoCal;
		return calendar; 
	}

	/**
	 * Compara fechas retorna -1 si fecha1 es menor a fecha2, 1 si fecha1 es mayor a fecha2 y cero si son iguales 
	 * @param fecha1
	 * @param fecha2
	 * @return
	 */
	
	public static int compara(Date fecha1, Date fecha2) {
		Calendar c = GregorianCalendar.getInstance();
		c.setTime(fecha1);
		c.set(Calendar.HOUR_OF_DAY, 0);
		c.set(Calendar.MINUTE, 0);		
		c.set(Calendar.SECOND, 0);		
		c.set(Calendar.MILLISECOND, 0);		
		Calendar c2 = GregorianCalendar.getInstance();
		c2.setTime(fecha2);
		c2.set(Calendar.HOUR_OF_DAY, 0);
		c2.set(Calendar.MINUTE, 0);		
		c2.set(Calendar.SECOND, 0);		
		c2.set(Calendar.MILLISECOND, 0);
		return c.compareTo(c2);
	}

	public static Date restarDias(Date fecha, int dias) {
		throw new RuntimeException("no implementado");
		// return null;
	}

	public static void main(String[] args) {
		System.out.println(UtilsDate.stringFromDate(new Date(), "yyyyMMdd"));
	}
}
