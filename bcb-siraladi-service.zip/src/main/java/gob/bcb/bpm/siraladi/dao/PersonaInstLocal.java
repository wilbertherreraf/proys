package gob.bcb.bpm.siraladi.dao;

import java.util.List;

import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.Persona;
import gob.bcb.bpm.siraladi.jpa.PersonaInst;
import gob.bcb.bpm.siraladi.jpa.PersonaInstPK;

public interface PersonaInstLocal extends DAO<PersonaInstPK, PersonaInst>{
	PersonaInst findByCodInst(String codInst);
	Persona findPersonaByCodInst(String codInst);
	List<PersonaInst> findByCodPersona(String codPersona);
	PersonaInst saveorupdate(PersonaInst params);
	PersonaInst findByCod(String codPersona, String codInst);
}
