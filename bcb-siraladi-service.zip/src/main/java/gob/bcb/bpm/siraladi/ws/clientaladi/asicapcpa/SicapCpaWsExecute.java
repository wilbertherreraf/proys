
package gob.bcb.bpm.siraladi.ws.clientaladi.asicapcpa;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Login" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Contrasena" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Convenio" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Fecvaldesde" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="Fecvalhasta" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="Cuentaab" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "login",
    "contrasena",
    "convenio",
    "fecvaldesde",
    "fecvalhasta",
    "cuentaab"
})
@XmlRootElement(name = "sicap_cpa_ws.Execute")
public class SicapCpaWsExecute {

    @XmlElement(name = "Login", required = true)
    protected String login;
    @XmlElement(name = "Contrasena", required = true)
    protected String contrasena;
    @XmlElement(name = "Convenio")
    protected String convenio;
    @XmlElement(name = "Fecvaldesde", required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar fecvaldesde;
    @XmlElement(name = "Fecvalhasta", required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar fecvalhasta;
    @XmlElement(name = "Cuentaab", required = true)
    protected String cuentaab;

    /**
     * Gets the value of the login property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLogin() {
        return login;
    }

    /**
     * Sets the value of the login property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLogin(String value) {
        this.login = value;
    }

    /**
     * Gets the value of the contrasena property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContrasena() {
        return contrasena;
    }

    /**
     * Sets the value of the contrasena property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContrasena(String value) {
        this.contrasena = value;
    }

    /**
     * Gets the value of the convenio property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConvenio() {
        return convenio;
    }

    /**
     * Sets the value of the convenio property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConvenio(String value) {
        this.convenio = value;
    }

    /**
     * Gets the value of the fecvaldesde property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getFecvaldesde() {
        return fecvaldesde;
    }

    /**
     * Sets the value of the fecvaldesde property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFecvaldesde(XMLGregorianCalendar value) {
        this.fecvaldesde = value;
    }

    /**
     * Gets the value of the fecvalhasta property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getFecvalhasta() {
        return fecvalhasta;
    }

    /**
     * Sets the value of the fecvalhasta property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFecvalhasta(XMLGregorianCalendar value) {
        this.fecvalhasta = value;
    }

    /**
     * Gets the value of the cuentaab property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCuentaab() {
        return cuentaab;
    }

    /**
     * Sets the value of the cuentaab property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCuentaab(String value) {
        this.cuentaab = value;
    }

}
