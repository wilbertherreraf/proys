
package gob.bcb.bpm.siraladi.ws.clientaladi.aifacif;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for sdtIFACIF.sdtIFACIFItem complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="sdtIFACIF.sdtIFACIFItem">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="CodRpta" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Estado" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="FechaEstado" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="Convenio" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CodInsFin" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="RazonSocial" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Plaza" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="InstFinTitular" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="FechaModif" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "sdtIFACIF.sdtIFACIFItem", propOrder = {

})
public class SdtIFACIFSdtIFACIFItem {

    @XmlElement(name = "CodRpta", required = true)
    protected String codRpta;
    @XmlElement(name = "Estado", required = true)
    protected String estado;
    @XmlElement(name = "FechaEstado", required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar fechaEstado;
    @XmlElement(name = "Convenio", required = true)
    protected String convenio;
    @XmlElement(name = "CodInsFin", required = true)
    protected String codInsFin;
    @XmlElement(name = "RazonSocial", required = true)
    protected String razonSocial;
    @XmlElement(name = "Plaza", required = true)
    protected String plaza;
    @XmlElement(name = "InstFinTitular", required = true)
    protected String instFinTitular;
    @XmlElement(name = "FechaModif", required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar fechaModif;

    /**
     * Gets the value of the codRpta property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodRpta() {
        return codRpta;
    }

    /**
     * Sets the value of the codRpta property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodRpta(String value) {
        this.codRpta = value;
    }

    /**
     * Gets the value of the estado property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEstado() {
        return estado;
    }

    /**
     * Sets the value of the estado property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEstado(String value) {
        this.estado = value;
    }

    /**
     * Gets the value of the fechaEstado property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getFechaEstado() {
        return fechaEstado;
    }

    /**
     * Sets the value of the fechaEstado property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFechaEstado(XMLGregorianCalendar value) {
        this.fechaEstado = value;
    }

    /**
     * Gets the value of the convenio property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConvenio() {
        return convenio;
    }

    /**
     * Sets the value of the convenio property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConvenio(String value) {
        this.convenio = value;
    }

    /**
     * Gets the value of the codInsFin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodInsFin() {
        return codInsFin;
    }

    /**
     * Sets the value of the codInsFin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodInsFin(String value) {
        this.codInsFin = value;
    }

    /**
     * Gets the value of the razonSocial property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRazonSocial() {
        return razonSocial;
    }

    /**
     * Sets the value of the razonSocial property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRazonSocial(String value) {
        this.razonSocial = value;
    }

    /**
     * Gets the value of the plaza property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPlaza() {
        return plaza;
    }

    /**
     * Sets the value of the plaza property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPlaza(String value) {
        this.plaza = value;
    }

    /**
     * Gets the value of the instFinTitular property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInstFinTitular() {
        return instFinTitular;
    }

    /**
     * Sets the value of the instFinTitular property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInstFinTitular(String value) {
        this.instFinTitular = value;
    }

    /**
     * Gets the value of the fechaModif property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getFechaModif() {
        return fechaModif;
    }

    /**
     * Sets the value of the fechaModif property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFechaModif(XMLGregorianCalendar value) {
        this.fechaModif = value;
    }

}
