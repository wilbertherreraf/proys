package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the usuario database table.
 * 
 */
@Entity
@Table(name="usuario")
public class Usuario implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="cod_usuario")
	private String codUsuario;

	@Column(name="cod_usuario_ha")
	private String codUsuarioHa;

	@Column(name="cve_vigente")
	private String cveVigente;

	@Column(name="estacion")
	private String estacion;

	@Column(name="fecha_hora")
	private Date fechaHora;

	@Column(name="nom_usuario")
	private String nomUsuario;

	@Column(name="usr_iniciales")
	private String usrIniciales;
	
	@Column(name="perfil")
	private String perfil;

    public Usuario() {
    }

	public String getCodUsuario() {
		return this.codUsuario;
	}

	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}

	public String getCodUsuarioHa() {
		return this.codUsuarioHa;
	}

	public void setCodUsuarioHa(String codUsuarioHa) {
		this.codUsuarioHa = codUsuarioHa;
	}

	public String getCveVigente() {
		return this.cveVigente;
	}

	public void setCveVigente(String cveVigente) {
		this.cveVigente = cveVigente;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getNomUsuario() {
		return this.nomUsuario;
	}

	public void setNomUsuario(String nomUsuario) {
		this.nomUsuario = nomUsuario;
	}

	public String getPerfil() {
		return this.perfil;
	}

	public void setPerfil(String perfil) {
		this.perfil = perfil;
	}

	public String getUsrIniciales() {
		return usrIniciales;
	}

	public void setUsrIniciales(String usrIniciales) {
		this.usrIniciales = usrIniciales;
	}

	@Override
	public String toString() {
		return "Usuario [codUsuario=" + codUsuario + ", codUsuarioHa=" + codUsuarioHa + ", cveVigente=" + cveVigente + ", estacion=" + estacion + ", fechaHora=" + fechaHora
				+ ", nomUsuario=" + nomUsuario + ", usrIniciales=" + usrIniciales + ", perfil=" + perfil + "]";
	}

}
