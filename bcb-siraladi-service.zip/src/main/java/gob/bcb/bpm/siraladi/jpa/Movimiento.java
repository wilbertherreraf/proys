package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;

import java.util.Date;
import javax.persistence.ManyToOne;

/**
 * The persistent class for the movimiento database table.
 * 
 */
@Entity
@Table(name = "movimiento")
public class Movimiento implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "nro_mov", unique = true, nullable = false)
	private Integer nroMov;

	@Column(name = "cve_tipo_mov")
	private String cveTipoMov;

	@Temporal(TemporalType.DATE)
	@Column(name = "fecha_mov")
	private Date fechaMov;
	
	@Column(name = "nro_sec_reemb")
	private Integer nroSecReemb;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "fechora_regaladi")
	private Date fechoraRegaladi;

	@Column(name = "tipo_oper_aladi")
	private String tipoOperAladi;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "cod_moneda")
	private Moneda moneda;

	
	public Movimiento() {
	}

	public Integer getNroMov() {
		return this.nroMov;
	}

	public void setNroMov(Integer nroMov) {
		this.nroMov = nroMov;
	}

	public String getCveTipoMov() {
		return this.cveTipoMov;
	}

	public void setCveTipoMov(String cveTipoMov) {
		this.cveTipoMov = cveTipoMov;
	}

	public Date getFechaMov() {
		return this.fechaMov;
	}

	public void setFechaMov(Date fechaMov) {
		this.fechaMov = fechaMov;
	}

	public Moneda getMoneda() {
		return this.moneda;
	}

	public void setMoneda(Moneda moneda) {
		this.moneda = moneda;
	}

	public void setFechoraRegaladi(Date fechoraRegaladi) {
		this.fechoraRegaladi = fechoraRegaladi;
	}

	public Date getFechoraRegaladi() {
		return fechoraRegaladi;
	}

	public void setTipoOperAladi(String tipoOperAladi) {
		this.tipoOperAladi = tipoOperAladi;
	}

	public String getTipoOperAladi() {
		return tipoOperAladi;
	}

	public void setNroSecReemb(Integer nroSecReemb) {
		this.nroSecReemb = nroSecReemb;
	}

	public Integer getNroSecReemb() {
		return nroSecReemb;
	}
}
