package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.SwfDetmensaje;
import gob.bcb.bpm.siraladi.jpa.SwfDetmensajePK;
import gob.bcb.bpm.siraladi.jpa.SwfMensaje;

import java.util.List;


import javax.persistence.Query;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("swfDetmensajeLocal")
@Transactional
public class SwfDetmensajeBean extends GenericDAO<SwfDetmensajePK, SwfDetmensaje> implements SwfDetmensajeLocal {

	public SwfDetmensaje findByCodigo(Integer demCodmen, Integer demNrocorr) {
		String jpql = "SELECT t FROM SwfDetmensaje t ";
		jpql = jpql.concat("WHERE t.id.demCodmen = :demCodmen ");
		jpql = jpql.concat("and t.id.demNrocorr = :demNrocorr ");

		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("demCodmen", demCodmen);
		query.setParameter("demNrocorr", demNrocorr);

		List lista = query.getResultList();
		if (lista.size() > 0) {
			return (SwfDetmensaje) lista.get(0);
		}

		return null;
	}
	public SwfDetmensaje findByCampo(Integer demCodmen, String demCodcampo, Integer demBloque) {
		String jpql = "SELECT t FROM SwfDetmensaje t ";
		jpql = jpql.concat("WHERE t.id.demCodmen = :demCodmen ");
		jpql = jpql.concat("and t.demCodcampo = :demCodcampo ");

		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("demCodmen", demCodmen);
		query.setParameter("demCodcampo", demCodcampo);

		List lista = query.getResultList();
		if (lista.size() > 0) {
			return (SwfDetmensaje) lista.get(0);
		}

		return null;
	}
	public List<SwfDetmensaje> findByCodMen(Integer demCodmen) {
		String jpql = "SELECT t FROM SwfDetmensaje t ";
		jpql = jpql.concat("WHERE t.id.demCodmen = :demCodmen ");
		
		Query query = getEntityManager().createQuery(jpql);
		
		query.setParameter("demCodmen", demCodmen);
		
		List lista = query.getResultList();
		return lista;
	}
	
	public SwfDetmensaje saveorupdate(SwfMensaje swfMensaje, SwfDetmensaje swfDetmensaje){
		log.info("en saveorupdate " + swfMensaje.getMenCodmen() + " :: " + swfDetmensaje.getId().getDemCodmen() + " " + swfDetmensaje.getId().getDemNrocorr());
		SwfDetmensaje swfDetmensajeOld = findByCodigo(swfDetmensaje.getId().getDemCodmen(), swfDetmensaje.getId().getDemNrocorr());
		if (swfDetmensajeOld == null){
			swfDetmensaje.getId().setDemCodmen(swfMensaje.getMenCodmen());
			swfDetmensaje = nuevoDetmensaje(swfDetmensaje) ;
		} else {
			swfDetmensaje = updateDetmensaje(swfDetmensaje);
		}
		log.info("salvado Detmensaje: " + swfDetmensaje.toString());		
		return swfDetmensaje;
	}
	
	public SwfDetmensaje nuevoDetmensaje(SwfDetmensaje swfDetmensaje) {
		log.info("en nuevoDetmensaje " + swfDetmensaje.toString());		
		Integer codigo = getCodigo(swfDetmensaje.getId().getDemCodmen());
		swfDetmensaje.getId().setDemNrocorr(codigo);
		persist(swfDetmensaje);
		
		return findByCodigo(swfDetmensaje.getId().getDemCodmen(), codigo);
	}

	public SwfDetmensaje updateDetmensaje(SwfDetmensaje swfDetmensaje) {
		log.info("en updateDetmensaje " + swfDetmensaje.toString());		
		makePersistent(swfDetmensaje);
		
		return findByCodigo(swfDetmensaje.getId().getDemCodmen(), swfDetmensaje.getId().getDemNrocorr());
	}
	
	public List<SwfDetmensaje> actualizarDetalles(SwfMensaje swfMensaje, List<SwfDetmensaje> swfDetmensajeList){
		log.info("en actualizarDetalles " + swfMensaje.getMenCodmen());
		borrarDetalles(swfMensaje.getMenCodmen());
		
		for (SwfDetmensaje swfDetmensaje : swfDetmensajeList) {
			saveorupdate(swfMensaje, swfDetmensaje);
		}
		return findByCodMen(swfMensaje.getMenCodmen()) ;
	}

	private void borrarDetalles(Integer demCodmen) {
		log.info("En cambiarEstados: para demCodmen " + demCodmen);

		String jsql = "DELETE from SwfDetmensaje c ";
		jsql = jsql.concat("WHERE c.id.demCodmen = :demCodmen ");

		Query query = getEntityManager().createQuery(jsql);
		query.setParameter("demCodmen", demCodmen);

		int result = query.executeUpdate();
		log.info("Modificados: " + result + " para " + demCodmen);

	}
	
	public SwfDetmensaje actualizarCampo(Integer demCodmen, String demCodcampo, Integer demBloque, String demValor, String auditUsr, String auditWst) {
		log.info("actualizarCampo:: "+ demCodmen + " demCodcampo: " + demCodcampo + " demBloque: " + demBloque + " demValor: " + demValor);
		
		SwfDetmensaje swfDetmensaje = findByCampo(demCodmen, demCodcampo, demBloque);

		if (swfDetmensaje == null) {
			swfDetmensaje = new SwfDetmensaje();
			SwfDetmensajePK swfDetmensajePK = new SwfDetmensajePK();
			swfDetmensajePK.setDemCodmen(demCodmen);
			swfDetmensajePK.setDemNrocorr(0);

			swfDetmensaje.setId(swfDetmensajePK);
			swfDetmensaje.setDemValor(demValor);
			swfDetmensaje.setDemCodcampo(demCodcampo);
			
			swfDetmensaje = nuevoDetmensaje(swfDetmensaje); 
		} else {
			swfDetmensaje.setDemValor(demValor);
			swfDetmensaje = updateDetmensaje(swfDetmensaje);
		}

		return swfDetmensaje;
	}

	
	private Integer getCodigo(Integer demCodmen) {
		Integer codigo = null;
		String jpql = "select max(m.id.demNrocorr) ";
		jpql = jpql.concat("from SwfDetmensaje m ");
		jpql = jpql.concat("where m.id.demCodmen = :demCodmen ");

		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("demCodmen", demCodmen);

		List result = query.getResultList();

		if (result.size() > 0)
			codigo = (Integer) result.get(0);

		if (codigo == null) {
			codigo = 0;
		}
		codigo++;
		log.info("Nuevo codigo : " + codigo);
		return codigo;

	}
}
