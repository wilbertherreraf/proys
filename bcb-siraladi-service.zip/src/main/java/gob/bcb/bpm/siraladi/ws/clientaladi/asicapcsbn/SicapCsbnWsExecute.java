
package gob.bcb.bpm.siraladi.ws.clientaladi.asicapcsbn;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import javax.xml.datatype.XMLGregorianCalendar;

import org.joda.time.LocalDate;

import gob.bcb.bpm.siraladi.ws.clientaladi.LocalDateAdapter;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Login" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Contrasena" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Fechavalordesde" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="Fechavalorhasta" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "login",
    "contrasena",
    "fechavalordesde",
    "fechavalorhasta"
})
@XmlRootElement(name = "sicap_csbn_ws.Execute")
public class SicapCsbnWsExecute {

    @XmlElement(name = "Login", required = true)
    protected String login;
    @XmlElement(name = "Contrasena", required = true)
    protected String contrasena;
//    @XmlElement(name = "Fechavalordesde", required = true)
//    @XmlSchemaType(name = "date")
//    protected XMLGregorianCalendar fechavalordesde;    
    @XmlElement(name = "Fechavalordesde")
    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    @XmlSchemaType(name = "date")
    protected LocalDate fechavalordesde;    
    @XmlElement(name = "Fechavalorhasta", required = true)
    @XmlJavaTypeAdapter(LocalDateAdapter.class)    
    @XmlSchemaType(name = "date")
    protected LocalDate fechavalorhasta;

    /**
     * Gets the value of the login property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLogin() {
        return login;
    }

    /**
     * Sets the value of the login property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLogin(String value) {
        this.login = value;
    }

    /**
     * Gets the value of the contrasena property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContrasena() {
        return contrasena;
    }

    /**
     * Sets the value of the contrasena property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContrasena(String value) {
        this.contrasena = value;
    }

    /**
     * Gets the value of the fechavalordesde property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public LocalDate getFechavalordesde() {
        return fechavalordesde;
    }

    /**
     * Sets the value of the fechavalordesde property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFechavalordesde(LocalDate value) {
        this.fechavalordesde = value;
    }

    /**
     * Gets the value of the fechavalorhasta property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public LocalDate getFechavalorhasta() {
        return fechavalorhasta;
    }

    /**
     * Sets the value of the fechavalorhasta property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFechavalorhasta(LocalDate value) {
        this.fechavalorhasta = value;
    }

}
