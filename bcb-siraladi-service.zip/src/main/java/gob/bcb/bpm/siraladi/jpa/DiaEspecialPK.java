package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the dia_especial database table.
 * 
 */
@Embeddable
public class DiaEspecialPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

    @Temporal( TemporalType.DATE)
	private java.util.Date fecha;

	@Column(name="cod_operacion")
	private String codOperacion;

	@Column(name="cod_horario")
	private String codHorario;

    public DiaEspecialPK() {
    }
	public java.util.Date getFecha() {
		return this.fecha;
	}
	public void setFecha(java.util.Date fecha) {
		this.fecha = fecha;
	}
	public String getCodOperacion() {
		return this.codOperacion;
	}
	public void setCodOperacion(String codOperacion) {
		this.codOperacion = codOperacion;
	}
	public String getCodHorario() {
		return this.codHorario;
	}
	public void setCodHorario(String codHorario) {
		this.codHorario = codHorario;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof DiaEspecialPK)) {
			return false;
		}
		DiaEspecialPK castOther = (DiaEspecialPK)other;
		return 
			this.fecha.equals(castOther.fecha)
			&& this.codOperacion.equals(castOther.codOperacion)
			&& this.codHorario.equals(castOther.codHorario);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.fecha.hashCode();
		hash = hash * prime + this.codOperacion.hashCode();
		hash = hash * prime + this.codHorario.hashCode();
		
		return hash;
    }
}