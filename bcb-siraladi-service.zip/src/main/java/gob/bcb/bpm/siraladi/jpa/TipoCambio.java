package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;



/**
 * The persistent class for the tipo_cambio database table.
 * 
 */
@Entity
@Table(name="tipo_cambio")
public class TipoCambio implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
    @Temporal( TemporalType.TIMESTAMP)
	@Column(name="fecha_tc", unique=true, nullable=false)
	private Date fechaTc;

	@Column(name="tipo_compra", precision=15, scale=2)
	private BigDecimal tipoCompra;

	@Column(name="tipo_venta", precision=15, scale=2)
	private BigDecimal tipoVenta;

    public TipoCambio() {
    }

	public Date getFechaTc() {
		return this.fechaTc;
	}

	public void setFechaTc(Date fechaTc) {
		this.fechaTc = fechaTc;
	}

	public BigDecimal getTipoCompra() {
		return this.tipoCompra;
	}

	public void setTipoCompra(BigDecimal tipoCompra) {
		this.tipoCompra = tipoCompra;
	}

	public BigDecimal getTipoVenta() {
		return this.tipoVenta;
	}

	public void setTipoVenta(BigDecimal tipoVenta) {
		this.tipoVenta = tipoVenta;
	}

}
