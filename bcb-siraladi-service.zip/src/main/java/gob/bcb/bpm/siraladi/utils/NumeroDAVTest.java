package gob.bcb.bpm.siraladi.utils;

public class NumeroDAVTest {
	public static void generaDAV(String cod_inst, String cod_id, String anio, String secuencia){
		int dav = NumeroDAV.generaDAV(cod_inst, cod_id, anio, secuencia);
		System.out.println("dav " + dav);
	}
	public static void main(String[] args) {
		generaDAV("0660","1","","05");
	}
}
