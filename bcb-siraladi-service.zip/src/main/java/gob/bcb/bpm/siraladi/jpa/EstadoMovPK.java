package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

/**
 * The primary key class for the estado_mov database table.
 * 
 */

@Embeddable
public class EstadoMovPK implements Serializable {

	@Column(name="nro_mov", unique=true, nullable=false)
	private Integer nroMov;

	@Column(name="cve_estado_mov", unique=true, nullable=false)
	private String cveEstadoMov;

    @Temporal( TemporalType.TIMESTAMP)
	@Column(name="fecha_hora", unique=true, nullable=false)
	private  Date fechaHora;

    public EstadoMovPK() {
    }
	public Integer getNroMov() {
		return this.nroMov;
	}
	public void setNroMov(Integer nroMov) {
		this.nroMov = nroMov;
	}
	public String getCveEstadoMov() {
		return this.cveEstadoMov;
	}
	public void setCveEstadoMov(String cveEstadoMov) {
		this.cveEstadoMov = cveEstadoMov;
	}
	public Date getFechaHora() {
		return this.fechaHora;
	}
	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof EstadoMovPK)) {
			return false;
		}
		EstadoMovPK castOther = (EstadoMovPK)other;
		return 
			(this.nroMov == castOther.nroMov)
			&& this.cveEstadoMov.equals(castOther.cveEstadoMov)
			&& this.fechaHora.equals(castOther.fechaHora);

    }
    
	
	public int hashCode() {
		final Integer prime = 31;
		Integer hash = 17;
		hash = hash * prime + this.nroMov;
		hash = hash * prime + this.cveEstadoMov.hashCode();
		hash = hash * prime + this.fechaHora.hashCode();
		
		return hash;
    }
}
