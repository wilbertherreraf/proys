package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the tasa_comp_aladi database table.
 * 
 */
@Entity
@Table(name="tasa_comp_aladi")
public class TasaCompAladi implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TasaCompAladiPK id;

	@Column(precision=8, scale=5)
	private BigDecimal tasa;

    public TasaCompAladi() {
    }

	public TasaCompAladiPK getId() {
		return this.id;
	}

	public void setId(TasaCompAladiPK id) {
		this.id = id;
	}
	
	public BigDecimal getTasa() {
		return this.tasa;
	}

	public void setTasa(BigDecimal tasa) {
		this.tasa = tasa;
	}

}
