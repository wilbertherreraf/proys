package gob.bcb.bpm.siraladi.dao;

import java.util.List;

import gob.bcb.bpm.siraladi.jpa.EstadoMov;
import gob.bcb.bpm.siraladi.jpa.EstadoMovPK;

public interface EstadoMovLocal extends DAO<EstadoMovPK, EstadoMov>{
	EstadoMov crearReg(Integer nroMov, String cveEstadoMov);

	List<EstadoMov> getByNroMovEstado(Integer nroMov, String cveEstado);
}
