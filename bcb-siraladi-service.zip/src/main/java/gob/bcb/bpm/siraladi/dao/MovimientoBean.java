package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.Movimiento;

import java.util.List;


import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("movimientoLocal")
@Transactional
public class MovimientoBean extends GenericDAO<Integer, Movimiento> implements MovimientoLocal {
	/* (non-Javadoc)
	 * @see gob.bcb.bpm.siraladi.dao.MovimientoLocal#getByNroMov(java.lang.Integer)
	 */
	
	public Movimiento getByNroMov(Integer nroMov){
		Movimiento movimiento = null;
		String jpql = "SELECT p FROM Movimiento p " + " WHERE p.nroMov = :nroMov "; 
		
		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("nroMov", nroMov);
		
		List result = query.getResultList();
		if (result.size() > 0)
			movimiento = (Movimiento) result.get(0);

		return movimiento;		
	}
	/* (non-Javadoc)
	 * @see gob.bcb.bpm.siraladi.dao.MovimientoLocal#getMaxMovimiento()
	 */
	
	public Movimiento getMaxMovimiento() {
		Movimiento movimiento = null;
		String jpql = "SELECT p FROM Movimiento p where p.nroMov = "
		+ "(select max(m.nroMov) from Movimiento m)";
		Query query = getEntityManager().createQuery(jpql);
		
		List result = query.getResultList();
        if (result.size() > 0) movimiento = (Movimiento) result.get(0);
        
		return movimiento;
	}
}
