package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.DiaEspecial;
import gob.bcb.bpm.siraladi.jpa.DiaEspecialPK;

public interface DiaEspecialLocal extends DAO<DiaEspecialPK, DiaEspecial>{

}