package gob.bcb.bpm.siraladi.dao;

import java.util.Date;

import gob.bcb.bpm.siraladi.jpa.Categoria;
import gob.bcb.bpm.siraladi.jpa.CategoriaPK;

public interface CategoriaLocal extends DAO<CategoriaPK, Categoria>{
	/**
	 * Calcula la calificacion vigente a una fecha de una institucion, si existe varias para la fecha extrae el ultimo que se haya modificado
	 * @param codInst codigo de institucion
	 * @param fechaVig fecha a la cual se consulta
	 * @param em
	 * @return objeto Categoria con datos de la calificaion
	 */
	public Categoria getCalifVig(String codInst, Date fechaVig);

	Categoria findByCodigo(String codPersona, Date fechaVig, String codCalif);

	Categoria saveorupdate(Categoria params);

	Categoria getCalifVigByPersona(String codPersona, Date fechaVig);
}
