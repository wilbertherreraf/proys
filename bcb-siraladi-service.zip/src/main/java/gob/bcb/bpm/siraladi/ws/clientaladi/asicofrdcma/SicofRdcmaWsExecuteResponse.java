
package gob.bcb.bpm.siraladi.ws.clientaladi.asicofrdcma;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Sicof" type="{BCRP}sdtSICOFRDCMA"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "sicof"
})
@XmlRootElement(name = "sicof_rdcma_ws.ExecuteResponse")
public class SicofRdcmaWsExecuteResponse {

    @XmlElement(name = "Sicof", required = true)
    protected SdtSICOFRDCMA sicof;

    /**
     * Gets the value of the sicof property.
     * 
     * @return
     *     possible object is
     *     {@link SdtSICOFRDCMA }
     *     
     */
    public SdtSICOFRDCMA getSicof() {
        return sicof;
    }

    /**
     * Sets the value of the sicof property.
     * 
     * @param value
     *     allowed object is
     *     {@link SdtSICOFRDCMA }
     *     
     */
    public void setSicof(SdtSICOFRDCMA value) {
        this.sicof = value;
    }

}
