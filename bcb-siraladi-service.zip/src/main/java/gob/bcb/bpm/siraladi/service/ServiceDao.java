package gob.bcb.bpm.siraladi.service;

import gob.bcb.bpm.siraladi.dao.AperturaLocal;
import gob.bcb.bpm.siraladi.dao.CalifRiesgoLocal;
import gob.bcb.bpm.siraladi.dao.CargoLocal;
import gob.bcb.bpm.siraladi.dao.CategoriaLocal;
import gob.bcb.bpm.siraladi.dao.ClasifProductosLocal;
import gob.bcb.bpm.siraladi.dao.ClavesLocal;
import gob.bcb.bpm.siraladi.dao.DetPatrimonioLocal;
import gob.bcb.bpm.siraladi.dao.DiaEspecialLocal;
import gob.bcb.bpm.siraladi.dao.EstadoMovLocal;
import gob.bcb.bpm.siraladi.dao.HorarioLocal;
import gob.bcb.bpm.siraladi.dao.IdentificadorLocal;
import gob.bcb.bpm.siraladi.dao.InstitucionLocal;
import gob.bcb.bpm.siraladi.dao.InstrumentoLocal;
import gob.bcb.bpm.siraladi.dao.MonedaLocal;
import gob.bcb.bpm.siraladi.dao.MovCoinLocal;
import gob.bcb.bpm.siraladi.dao.MovimientoLocal;
import gob.bcb.bpm.siraladi.dao.PagoLocal;
import gob.bcb.bpm.siraladi.dao.PaisLocal;
import gob.bcb.bpm.siraladi.dao.ParamsLocal;
import gob.bcb.bpm.siraladi.dao.PatrimonioLocal;
import gob.bcb.bpm.siraladi.dao.PerTipoCuentaLocal;
import gob.bcb.bpm.siraladi.dao.PersonaInstLocal;
import gob.bcb.bpm.siraladi.dao.PersonaLocal;
import gob.bcb.bpm.siraladi.dao.PlanPagoLocal;
import gob.bcb.bpm.siraladi.dao.RegAnticipadoLocal;
import gob.bcb.bpm.siraladi.dao.RegistroLocal;
import gob.bcb.bpm.siraladi.dao.SwfDetmensajeLocal;
import gob.bcb.bpm.siraladi.dao.SwfMensajeLocal;
import gob.bcb.bpm.siraladi.dao.SwfMttransferLocal;
import gob.bcb.bpm.siraladi.dao.SwfMttransferdetLocal;
import gob.bcb.bpm.siraladi.dao.SwfPersonactaLocal;
import gob.bcb.bpm.siraladi.dao.TPagoImpLocal;
import gob.bcb.bpm.siraladi.dao.UsuarioLocal;
import gob.bcb.bpm.siraladi.jpa.RegAnticipado;
import gob.bcb.bpm.siraladi.jpa.Usuario;
import gob.bcb.bpm.siraladi.logic.RegAnticipadoServiceLocal;
import gob.bcb.bpm.siraladi.pojo.UsuarioSirAladi;
import gob.bcb.swift.service.SwiftMessageServiceLocal;

public interface ServiceDao {

	void setUsuarioAudit(UsuarioSirAladi usuarioAudit);

	UsuarioSirAladi getUsuarioAudit();

	AperturaLocal getAperturaLocal();

	CalifRiesgoLocal getCalifRiesgoLocal();

	CategoriaLocal getCategoriaLocal();

	DetPatrimonioLocal getDetPatrimonioLocal();

	//DiaEspecialLocal getDiaEspecialLocal();

	EstadoMovLocal getEstadoMovLocal();

	HorarioLocal getHorarioLocal();

	IdentificadorLocal getIdentificadorLocal();

	InstitucionLocal getInstitucionLocal();

	InstrumentoLocal getInstrumentoLocal();

	MonedaLocal getMonedaLocal();

	MovCoinLocal getMovCoinLocal();

	MovimientoLocal getMovimientoLocal();

	PagoLocal getPagoLocal();

	PaisLocal getPaisLocal();

	ParamsLocal getParamsLocal();

	PatrimonioLocal getPatrimonioLocal();

	PersonaInstLocal getPersonaInstLocal();

	PersonaLocal getPersonaLocal();

	PerTipoCuentaLocal getPerTipoCuentaLocal();

	PlanPagoLocal getPlanPagoLocal();

	RegAnticipadoLocal getRegAnticipadoLocal();

	RegistroLocal getRegistroLocal();

	SwfDetmensajeLocal getSwfDetmensajeLocal();

	SwfMensajeLocal getSwfMensajeLocal();

	SwfMttransferdetLocal getSwfMttransferdetLocal();

	SwfMttransferLocal getSwfMttransferLocal();

	SwfPersonactaLocal getSwfPersonactaLocal();

	TPagoImpLocal getTPagoImpLocal();

	ClavesLocal getClavesLocal();

	RegAnticipadoServiceLocal getRegAnticipadoServiceLocal();

	SwiftMessageServiceLocal getSwiftMessageServiceLocal();

	UsuarioLocal getUsuarioLocal();

	CargoLocal getCargoLocal();

	ClasifProductosLocal getClasifProductosLocal();
}
