package gob.bcb.bpm.siraladi.logic;

import gob.bcb.bpm.siraladi.common.ConsComunesNegocio;
import gob.bcb.bpm.siraladi.dao.AperturaBean;
import gob.bcb.bpm.siraladi.dao.AperturaLocal;
import gob.bcb.bpm.siraladi.dao.CalifRiesgoBean;
import gob.bcb.bpm.siraladi.dao.CalifRiesgoLocal; 
import gob.bcb.bpm.siraladi.dao.CategoriaBean;
import gob.bcb.bpm.siraladi.dao.EntityUserTransaction;
import gob.bcb.bpm.siraladi.dao.InstitucionBean;
import gob.bcb.bpm.siraladi.dao.InstitucionLocal;
import gob.bcb.bpm.siraladi.dao.PagoBean;
import gob.bcb.bpm.siraladi.dao.PagoLocal;
import gob.bcb.bpm.siraladi.dao.ParamsBean;
import gob.bcb.bpm.siraladi.dao.ParamsLocal;
import gob.bcb.bpm.siraladi.dao.PersonaInstBean;
import gob.bcb.bpm.siraladi.dao.PersonaInstLocal;
import gob.bcb.bpm.siraladi.dao.PlanPagoBean;
import gob.bcb.bpm.siraladi.dao.PlanPagoLocal;
import gob.bcb.bpm.siraladi.dao.RegistroBean;
import gob.bcb.bpm.siraladi.dao.RegistroLocal;

import gob.bcb.bpm.siraladi.dao.CategoriaLocal;
import gob.bcb.bpm.siraladi.dao.qnative.QCoinCommos;
import gob.bcb.bpm.siraladi.exceptions.AladiException;
import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.CalifRiesgo;
import gob.bcb.bpm.siraladi.jpa.Categoria;
import gob.bcb.bpm.siraladi.jpa.ClasifProductos;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Instrumento;
import gob.bcb.bpm.siraladi.jpa.Movimiento;
import gob.bcb.bpm.siraladi.jpa.Pago;
import gob.bcb.bpm.siraladi.jpa.Pais;
import gob.bcb.bpm.siraladi.jpa.Param;
import gob.bcb.bpm.siraladi.jpa.PersonaInst;
import gob.bcb.bpm.siraladi.jpa.PlanPago;
import gob.bcb.bpm.siraladi.jpa.Registro;
import gob.bcb.bpm.siraladi.msgmail.MsgLogic;
import gob.bcb.bpm.siraladi.service.ConfigurationServ;
import gob.bcb.bpm.siraladi.utils.Constants;
import gob.bcb.bpm.siraladi.utils.JhDate;
import gob.bcb.bpm.siraladi.utils.NumeroDAV;
import gob.bcb.bpm.siraladi.utils.UtilsDate;

import java.math.BigDecimal;
import java.text.MessageFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.joda.time.Days;

import javax.annotation.Resource;


import javax.persistence.EntityManager;
import javax.transaction.UserTransaction;

/**
 * @author wilherrera Wilbert Herrera Flores Banco Central de Bolivia
 *         Departamento de Desarrollo
 */

public class AperturaServiceBean extends EntityUserTransaction implements AperturaServiceLocal {

	private static Logger log = Logger.getLogger(AperturaServiceBean.class);

	private AperturaLocal aperturaLocal;

	private Map<String, Object> warnnings = new HashMap<String, Object>();

	public AperturaServiceBean(EntityManager entityManager) {
		super(entityManager);
		aperturaLocal = new AperturaBean();
		aperturaLocal.setEntityManager(entityManager);
	}

	
	public Apertura crearReg(Apertura apertura) {

		apertura.setCveEstadoApe("V");

		String codReembolso = apertura.getNroReembLiteral();
		log.info("ingresando a crearApertura para " + codReembolso);

		Apertura aperturaExist = aperturaLocal.findByCodReembolso(apertura.getInstitucion().getCodInst(), apertura.getIdentificador().getCodId(),
				apertura.getAnio(), apertura.getSecuencia(), apertura.getDav());

		if (aperturaExist != null) {
			throw new AladiException("NRO_REEMBOLSO_REGISTRADO", new Object[] { codReembolso });
		} else {
			aperturaExist = null;
		}

		// Verificacion de la fecha de vencimiento
		if (apertura.getFechaEmis() == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Fecha de emision/operacion NULO o invalida" });
		}

		if (apertura.getFechaVtoPag() == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Fecha de vencimiento NULO o invalida" });
		}

		// campos calculados

		isValidData(apertura);

		MovimientoServiceLocal movimientoService = new MovimientoServiceBean(getEntityManager());
		// como una de las ultimas tareas es crear el numero de movimiento
		Movimiento movimiento = movimientoService.crearMovimiento("A", apertura.getCodMoneda(), new Date(), null);
		Integer nroMov = movimiento.getNroMov();
		if (nroMov == null || nroMov <= 0) {
			throw new AladiException("ERROR_GENERANDO_NRO_MOV", new Object[] { codReembolso });
		}

		apertura.setNroMov(nroMov);
		if (apertura.getClasifProductos() == null || apertura.getClasifProductos().getCodClasifprod() == null) {
			ClasifProductos clasifProductos = new ClasifProductos();
			clasifProductos.setCodClasifprod(0);
			apertura.setClasifProductos(clasifProductos);
		}

		aperturaLocal.controlUsuarioOperacion(apertura);

		apertura = aperturaLocal.makePersistent(apertura);
		aperturaLocal.flush();
		log.info("NroMov creado " + nroMov + " para " + codReembolso);
		return apertura;
	}

	
	public boolean isValidData(Apertura apertura) throws AladiException {

		if (apertura.getInstitucion() == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "codigo institucion nulo" });
		}

		if (apertura.getCveEstadoApe() == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Estado de la apertura nulo." });
		}

		if (!apertura.getCveEstadoApe().equalsIgnoreCase("V")) {
			throw new AladiException("INVALIDO_PARA_MODIFICACION", new Object[] { apertura.getNroReembLiteral(), apertura.getCveEstadoApe() });
		}

		Institucion institucion = getEntityManager().find(Institucion.class, apertura.getInstitucion().getCodInst());
		if (institucion == null) {
			throw new AladiException("INSTITUCION_NO_ENCONTRADA", new Object[] { apertura.getInstitucion().getCodInst() });
		}

		if (!institucion.getCveEstado().equals("0")) {
			throw new AladiException("INSTITUCION_NO_ENCONTRADA", new Object[] { apertura.getInstitucion().getCodInst() });
		}

		if (apertura.getIdentificador() == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "codigo identificador nulo o invalido" });
		}
		Pais paisConv = getEntityManager().find(Pais.class, apertura.getPais().getCodPais());
		if (paisConv == null) {
			throw new AladiException("PAIS_NO_ENCONTRADO", new Object[] { apertura.getPais().getCodPais() });
		}

		if (apertura.getAnio() == null || apertura.getAnio().trim().isEmpty()) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Valor de campo Anio NULO o invalido" });
		}

		if (apertura.getSecuencia() == null || apertura.getSecuencia().trim().isEmpty()) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Valor de campo secuencia-correlativo NULO o invalido " });
		}

		if (apertura.getDav() < 0 || String.valueOf(apertura.getDav()) == null || String.valueOf(apertura.getDav()).trim().equals("")) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Valor de digito autoverificador invalido" });
		}

		// validar el c�digo de reembolso
		if (!NumeroDAV.verificaDAV(apertura.getInstitucion().getCodInst(), apertura.getIdentificador().getCodId(), apertura.getAnio(),
				apertura.getSecuencia(), apertura.getDav())) {
			throw new AladiException("DAV_INCORRECTO", new Object[] {
					apertura.getDav(),
					NumeroDAV.generaDAV(apertura.getInstitucion().getCodInst(), apertura.getIdentificador().getCodId(), apertura.getAnio(),
							apertura.getSecuencia()) });
		}

		if (apertura.getCodMoneda() == null || apertura.getCodMoneda().trim().isEmpty()) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Valor de codigo moneda NULO o invalido" });
		}

		// Verificacion del tipo de operacion
		if (apertura.getCveTipoApe() == null || apertura.getCveTipoApe().trim().isEmpty()) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Valor tipo de operacion NULO o invalido" });
		}

		if (!apertura.getCveTipoApe().trim().equalsIgnoreCase("I") && !apertura.getCveTipoApe().trim().equalsIgnoreCase("E")) {
			throw new AladiException("TIPO_OPER_INVALIDO");
		}

		if (apertura.getNomExportador() == null || apertura.getNomExportador().trim().isEmpty()) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Nombre Exportador valor NULO o inv�lido" });
		}

		if (apertura.getNomImportador() == null || apertura.getNomImportador().trim().isEmpty()) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Nombre importador valor NULO o inv�lido" });
		}

		// Verificacion del plazo
		// Verificacion de la fecha de vencimiento
		if (apertura.getFechaVtoPag() == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Fecha de vencimiento NULO o inv�lida" });
		}

		// Verificacion de la fecha de operacion
		if (apertura.getFechaEmis() == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Fecha de emision/operacion NULO o inv�lida" });
		}

		if (apertura.getFechaVtoPag().compareTo(apertura.getFechaEmis()) <= 0) {
			throw new AladiException("FECHA_VENC_MENOR_EMIS", new Object[] {
					UtilsDate.stringFromDate(apertura.getFechaVtoPag(), Constants.FORMAT_DATE_DB),
					UtilsDate.stringFromDate(apertura.getFechaEmis(), Constants.FORMAT_DATE_DB) });
		}

		ParamsLocal paramsLocal = new ParamsBean();
		paramsLocal.setEntityManager(getEntityManager());

		Param param = null;
		Integer diasHabilPlazo = -6;
		param = paramsLocal.findById("diashabfueraplazo", false);
		if (param != null) {
			try {
				diasHabilPlazo = Integer.valueOf(param.getValparam());
				if (diasHabilPlazo.compareTo(Integer.valueOf(0)) == 0) {
					diasHabilPlazo = -6;
				}
				if (diasHabilPlazo.compareTo(Integer.valueOf(0)) > 0) {
					// si es positivo
					diasHabilPlazo = diasHabilPlazo * (-1);
				}
			} catch (Exception e) {
				// no hacer nada se asume que los dias son 6
				diasHabilPlazo = -6;
			}
		}
		// si la fecha de emision es mayor a d7 dias emitir un mensaje de aviso
		Date fechaAntes = ConsComunesNegocio.fecHabilAntesDespuesDe(new Date(), diasHabilPlazo);

		if (fechaAntes == null || apertura.getFechaEmis().before(fechaAntes)) {
			warnnings.put("AVISO_FUERA_DE_PLAZO", AladiException.getDescription("AVISO_FUERA_DE_PLAZO",
					UtilsDate.stringFromDate(apertura.getFechaEmis(), Constants.FORMAT_DATE_DB)));
			log.info("Instrumento " + apertura.getNroReembLiteral() + " FUERA DE PLAZO " + warnnings.values().toString());
		}

		Integer diasCalenPlazo = -20;
		param = paramsLocal.findById("diascalenfueraplazo", false);
		if (param != null) {
			try {
				diasCalenPlazo = Integer.valueOf(param.getValparam());
				if (diasCalenPlazo.compareTo(Integer.valueOf(0)) == 0) {
					diasCalenPlazo = -20;
				}
				if (diasCalenPlazo.compareTo(Integer.valueOf(0)) > 0) {
					// si es positivo
					diasCalenPlazo = diasCalenPlazo * (-1);
				}
			} catch (Exception e) {
				// no hacer nada se asume que los dias son 20
				diasCalenPlazo = -20;
			}
		}
		// la fecha de registro del instrumento debe ser 30 dias antes de la
		// fecha de registro (fecha hoy, fecha de llenado del form)
		GregorianCalendar dias30Antes = new GregorianCalendar();
		dias30Antes.add(Calendar.DATE, diasCalenPlazo);

		if (apertura.getFechaEmis().before(dias30Antes.getTime())) {
			// si la fecha de emision emitir un warnning
			warnnings.put("PENDIENTE_DE_ACEPTACION", AladiException.getDescription("PENDIENTE_DE_ACEPTACION", apertura.getNroReembLiteral()));
			warnnings.remove("AVISO_FUERA_DE_PLAZO");
			log.info("Instrumento " + apertura.getNroReembLiteral() + " PENDIENTE DE ACEPTACION " + warnnings.values().toString());
		}

		// Extraemos el codigo de bolivia del sistema
		String codBolivia = ConfigurationServ.getParamsSystem().get("cod_bolivia");

		// si es importacion
		if (apertura.getCveTipoApe().equalsIgnoreCase("I")) {
			// la institucion que impiorta debe ser de bolivia
			// control de si la institucion es de bolivia
			if (!institucion.getPais().getCodPais().trim().equalsIgnoreCase(codBolivia)) {
				throw new AladiException("INSTITUCION_INVALIDA_NO_ES_BOL", new Object[] { institucion.getPais().getCodPais() });
			}
			// control de que cod_pais sea diferente de bolivia
			if (paisConv.getCodPais().equalsIgnoreCase(codBolivia)) {
				throw new AladiException("PAIS_INVALIDO_DIF_BOL", new Object[] { paisConv.getCodPais() });
			}
		} else if (apertura.getCveTipoApe().equalsIgnoreCase("E")) {
			// si es exportacion
			// control de si la institucion NO es de bolivia
			if (institucion.getPais().getCodPais().trim().equalsIgnoreCase(codBolivia)) {
				throw new AladiException("INSTITUCION_INVALIDA_DIF_BOL", new Object[] { institucion.getPais().getCodPais() });
			}

			// control de que cod_pais sea igual a bolivia
			if (!paisConv.getCodPais().equalsIgnoreCase(codBolivia)) {
				throw new AladiException("PAIS_INVALIDO_NO_ES_BOL", new Object[] { paisConv.getCodPais() });
			}
		}
		return true;
	}

	
	public Apertura modificar(Apertura apertura) {

		if (apertura == null) {
			throw new AladiException("OBJETO_NULO", new Object[] { "apertura" });
		}

		if (apertura.getCveEstadoApe() == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Estado de la apertura nulo." });
		}

		// se modifica solo los campos permitidos
		Apertura aperturaOld = aperturaLocal.findByCodReembolso(apertura.getInstitucion().getCodInst(), apertura.getIdentificador().getCodId(),
				apertura.getAnio(), apertura.getSecuencia(), apertura.getDav());

		if (aperturaOld == null) {
			throw new AladiException("REEMBOLSO_INEXISTENTE", new Object[] { apertura.getNroReembLiteral() });
		}

		if (!aperturaOld.getCveEstadoApe().equalsIgnoreCase("V")) {
			throw new AladiException("INVALIDO_PARA_MODIFICACION", new Object[] { apertura.getNroReembLiteral(), aperturaOld.getCveEstadoApe() });
		}
		Date fechVto = aperturaOld.getFechaVtoPag();
		aperturaOld.setFechaEmis(apertura.getFechaEmis());
		aperturaOld.setFechaVtoPag(apertura.getFechaVtoPag());
		aperturaOld.setNomProducto(apertura.getNomProducto());
		aperturaOld.setNroDias(apertura.getNroDias());
		aperturaOld.setNomImportador(apertura.getNomImportador());
		if (apertura.getClasifProductos() != null)
			aperturaOld.setClasifProductos(apertura.getClasifProductos());
		aperturaOld.setNomExportador(apertura.getNomExportador());

		isValidData(aperturaOld);
		aperturaOld = aperturaLocal.makePersistent(aperturaOld);
		aperturaLocal.flush();

		if (fechVto != null && fechVto.compareTo(apertura.getFechaVtoPag()) != 0) {
			if (aperturaOld.getIdentificador().getCodId().trim().equals("1") || aperturaOld.getIdentificador().getCodId().trim().equals("5")) {
				warnnings.put(
						"AVISO_CAMBIO_FECHA_VTO",
						AladiException.getDescription("AVISO_CAMBIO_FECHA_VTO",
								UtilsDate.stringFromDate(apertura.getFechaVtoPag(), Constants.FORMAT_DATE_DB)));
			}
		}

		return aperturaOld;
	}

	public Apertura modificaSinValidacion(Apertura apertura) {

		if (apertura == null) {
			throw new AladiException("OBJETO_NULO", new Object[] { "apertura" });
		}

		if (apertura.getCveEstadoApe() == null) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Estado de la apertura nulo." });
		}

		// se modifica solo los campos permitidos
		Apertura aperturaOld = aperturaLocal.findByCodReembolso(apertura.getInstitucion().getCodInst(), apertura.getIdentificador().getCodId(),
				apertura.getAnio(), apertura.getSecuencia(), apertura.getDav());

		if (aperturaOld == null) {
			throw new AladiException("REEMBOLSO_INEXISTENTE", new Object[] { apertura.getNroReembLiteral() });
		}

		aperturaOld.setCveEstadoApe(apertura.getCveEstadoApe());
		aperturaOld.setNomImportador(apertura.getNomImportador());
		if (apertura.getClasifProductos() != null && apertura.getClasifProductos().getCodClasifprod() != null)
			aperturaOld.setClasifProductos(apertura.getClasifProductos());

		if (aperturaOld.getCveEstadoApe().equalsIgnoreCase("V")) {
			aperturaOld.setNomExportador(apertura.getNomExportador());
			aperturaOld.setNomProducto(apertura.getNomProducto());
			aperturaOld.setNroDias(apertura.getNroDias());
		}

		aperturaOld = aperturaLocal.makePersistent(aperturaOld);
		aperturaLocal.flush();

		return aperturaOld;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gob.bcb.bpm.siraladi.logic.AperturaServiceLocal#validarCalifRiesgo(gob
	 * .bcb.bpm.siraladi.jpa .Apertura)
	 */
	
	public String validarCalifRiesgo(Apertura apertura, Date fechaTrans) {
		String codCalif = "";
		if (apertura.getCveTipoApe().trim().equals("I")) {
			log.info("Validacion de calificacion riesgo " + apertura.getInstitucion().getCodInst());
			if (!apertura.getInstitucion().getCodInst().trim().equals(ConfigurationServ.getParamsSystem().get("BCB"))) {
				CategoriaLocal categoriaLocal = new CategoriaBean();
				categoriaLocal.setEntityManager(getEntityManager());
				Categoria categoria = categoriaLocal.getCalifVig(apertura.getInstitucion().getCodInst(), fechaTrans);
				if (categoria == null) {
					throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Categoria de Calificacion invalido, NULO para inst "
							+ apertura.getInstitucion().getCodInst() + " fecha " + new Date() });
				}
				CalifRiesgoLocal califRiesgoLocal = new CalifRiesgoBean();
				califRiesgoLocal.setEntityManager(getEntityManager());
				CalifRiesgo califRiesgo = califRiesgoLocal.findById(categoria.getId().getCodCalif().trim(), false);
				if (califRiesgo == null) {
					throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Calificacion de riesgo invalido para calif. "
							+ categoria.getId().getCodCalif().trim() });
				}

				DateTime fechaVtoPag = new DateTime(apertura.getFechaVtoPag());
				DateTime fechaEmis = new DateTime(apertura.getFechaEmis());
				Days days = Days.daysBetween(fechaEmis, fechaVtoPag);

				if (califRiesgo.getPlazo() >= days.getDays()) {
					return califRiesgo.getCodCalif();
				} else {
					throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Nro de dias: " + days.getDays()
							+ " del instrumento es mayor al plazo permitido: " + califRiesgo.getPlazo() + " d�as" });
				}
			}
		}
		return codCalif;
	}

	
	public void eliminar(Apertura apertura) {
		Movimiento movimiento = null;
		if (apertura == null) {
			throw new AladiException("OBJETO_NULO", new Object[] { "apertura" });
		}

		PagoLocal pagoLocal = new PagoBean();
		pagoLocal.setEntityManager(getEntityManager());
		List<Pago> pagoList = null;
		if (apertura.getCveTipoApe().trim().equals("I")) {
			// en import se controla los debitos pendientes a pagar
			pagoList = pagoLocal.getByNroMovApeCveEstadoPago(apertura.getNroMov(), "P", false);

			if (pagoList.size() == 0)
				// en import se controla los debitos autrizados
				pagoList = pagoLocal.getByNroMovApeCveEstadoPago(apertura.getNroMov(), "C", false);
		} else if (apertura.getCveTipoApe().trim().equals("E")) {
			// en export se controla los reembolsos autorizados
			pagoList = pagoLocal.getByNroMovApeCveEstadoPago(apertura.getNroMov(), "C", false);
		}

		if (pagoList != null && pagoList.size() > 0) {
			throw new AladiException("INVALIDO_PARA_ANULACION", new Object[] { apertura.getNroReembLiteral(),
					"instrumento con operaciones registradas" });
		}

		if (!apertura.getCveEstadoApe().equals("V")) {
			throw new AladiException("INVALIDO_PARA_MODIFICACION", new Object[] { apertura.getNroReembLiteral(), apertura.getCveEstadoApe() });
		}

		MovimientoServiceLocal movimientoService = new MovimientoServiceBean(getEntityManager());
		movimiento = movimientoService.getMovimientoLocal().getByNroMov(apertura.getNroMov());

		if (movimiento.getFechoraRegaladi() != null) {
			throw new AladiException("INVALIDO_PARA_MODIFICACION", new Object[] { apertura.getNroReembLiteral(), apertura.getCveEstadoApe() });
		}

		aperturaLocal.makeTransient(apertura);
		movimientoService.getMovimientoLocal().makeTransient(movimiento);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gob.bcb.bpm.siraladi.logic.AperturaServiceLocal#controlSaldoPlanPagos
	 * (java.lang.Integer)
	 */
	
	public void controlSaldoPlanPagos(Apertura apertura, String cveEstadoPlan, Date fechaVal) {
		// control de saldos: el salo del instrumento debe ser igual al saldo de
		// pagos pendientes del plan de pagos

		if (apertura.getIdentificador().getCodId() != null) {
			if (!apertura.getIdentificador().getCodId().trim().equals("1") && !apertura.getIdentificador().getCodId().trim().equals("5")) {
				// si el instrumento no permite negociaciones no se controla el
				// saldo
				return;
			}
		}

		PlanPagoLocal planPagoLocal = new PlanPagoBean();
		planPagoLocal.setEntityManager(getEntityManager());

		RegistroLocal registroLocal = new RegistroBean();
		registroLocal.setEntityManager(getEntityManager());
		BigDecimal montoTotalEmision = registroLocal.getSaldoRegistro(apertura.getNroMov());

		// control de saldos: el salo del instrumento debe ser igual al saldo de
		// pagos pendientes del plan de pagos

		BigDecimal saldoPlanPagos = planPagoLocal.getSumaPlanPagos(apertura.getNroMov(), cveEstadoPlan, fechaVal);

		if (saldoPlanPagos.compareTo(montoTotalEmision) != 0) {
			throw new AladiException("MONTO_NEGOCIACION_DIF_EMISION", new Object[] { apertura.getNroReembLiteral(),
					montoTotalEmision.toPlainString(), saldoPlanPagos.toPlainString() });
		}
	}

	
	public Apertura liquidar(Apertura apertura) {
		RegistroLocal registroLocal = new RegistroBean();
		registroLocal.setEntityManager(getEntityManager());

		PagoLocal pagoLocal = new PagoBean();
		pagoLocal.setEntityManager(getEntityManager());

		PlanPagoLocal planPagoLocal = new PlanPagoBean();
		planPagoLocal.setEntityManager(getEntityManager());

		if ((registroLocal.getByNroMovApeCveEstadoReg(apertura.getNroMov(), "C").size() > 0)
				&& pagoLocal.getByNroMovApeCveEstadoPago(apertura.getNroMov(), "C", true).size() > 0) {
			BigDecimal saldo = aperturaLocal.getSaldo(apertura.getNroMov());
			if ((saldo != null) && (saldo.compareTo(BigDecimal.ZERO) == 0)) {
				log.info("Liquidando Apertura " + apertura.getNroReembLiteral());
				// si es cero liquidar cve_estado_ape = "L"
				apertura.setCveEstadoApe("L");
				apertura = aperturaLocal.makePersistent(apertura);
				// actualizamos plan de pagos todos suspendidos
				List<PlanPago> planPagosList = planPagoLocal.findPlanPagos(apertura.getNroMov(), null, null);
				for (PlanPago planPago : planPagosList) {
					planPago.setCveEstadoPlan("C");
					planPagoLocal.makePersistent(planPago);
				}
			}
		}
		return apertura;
	}

	
	public Apertura anularInstrumento(Apertura apertura) {

		if (!apertura.getCveEstadoApe().equalsIgnoreCase("V")) {
			throw new AladiException("INVALIDO_PARA_MODIFICACION", new Object[] { apertura.getNroReembLiteral(), apertura.getCveEstadoApe() });
		}

		PagoLocal pagoLocal = new PagoBean();
		pagoLocal.setEntityManager(getEntityManager());
		List<Pago> pagoList = null;
		if (apertura.getCveTipoApe().trim().equals("I")) {
			// en import se controla los debitos pendientes a pagar
			pagoList = pagoLocal.getByNroMovApeCveEstadoPago(apertura.getNroMov(), "P", false);

			if (pagoList.size() == 0)
				// en import se controla los debitos autrizados
				pagoList = pagoLocal.getByNroMovApeCveEstadoPago(apertura.getNroMov(), "C", false);
		} else if (apertura.getCveTipoApe().trim().equals("E")) {
			// en export se controla los reembolsos autorizados
			pagoList = pagoLocal.getByNroMovApeCveEstadoPago(apertura.getNroMov(), "C", false);
		}

		if (pagoList != null && pagoList.size() > 0) {
			throw new AladiException("INVALIDO_PARA_ANULACION", new Object[] { apertura.getNroReembLiteral(),
					"instrumento con operaciones registradas" });
		}

		apertura.setCveEstadoApe("A");
		apertura = aperturaLocal.makePersistent(apertura);
		log.info("Anulacion de instrumento " + apertura.getNroReembLiteral() + " exitoso");
		return apertura;
	}

	
	public String obtenerNIT(Apertura apertura, String nit, String codInstitucion, String tipoRegistro) {
		log.info("obetniendo nit para codInstitucion " + codInstitucion + " tipoRegistro " + tipoRegistro);
		String nitReturn = null;
		String codInst = null;
		if (codInstitucion == null || codInstitucion.trim().isEmpty()) {
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Error al obener NIT, Codigo de institucion nulo" });
		}

		PersonaInstLocal personaInstLocal = new PersonaInstBean();
		personaInstLocal.setEntityManager(getEntityManager());
		if (apertura.getCveTipoApe().equalsIgnoreCase("I")) {
			// si el nit del importador es nulo se emite la factura a
			// con el nit y a nombre de la institucion codInst
			codInst = apertura.getInstitucion().getCodInst();
		} else if (apertura.getCveTipoApe().equalsIgnoreCase("E")) {
			codInst = codInstitucion;
		}
		// buscamos la IFA por codigo de institucion
		PersonaInst personaInst = personaInstLocal.findByCodInst(codInst);
		if (personaInst == null) {
			throw new AladiException("INSTITUCION_NO_ENCONTRADA", new Object[] { codInst });
		}
		if (codInst.trim().equals(ConfigurationServ.getParamsSystem().get("BCB"))) {
			if (StringUtils.isBlank(nit)){
				RegistroLocal registroLocal = new RegistroBean();
				registroLocal.setEntityManager(getEntityManager());

				List<Registro> registroList = registroLocal.getRegistroByTipoEmis(apertura.getNroMov(), "E");

				if (registroList.size() == 1) {
					if (!StringUtils.isBlank(registroList.get(0).getNit())){
						nit = registroList.get(0).getNit().trim();						
					}
				}
			}
			
			return nit;
		}

		if (StringUtils.isBlank(nit)) {
			if (tipoRegistro.trim().equals("E")) {
				// si es emision se recupera de persona
				QCoinCommos qCoinCommos = new QCoinCommos("coin");
				log.debug("persona " + personaInst.getId().getCodPersona().trim() + " para institucion " + apertura.getInstitucion().getCodInst());

				Map<String, Object> persona = qCoinCommos.getPersona(personaInst.getId().getCodPersona().trim());
				if (persona == null || persona.size() == 0) {
					throw new AladiException("INSTITUCION_NO_ENCONTRADA", new Object[] { apertura.getInstitucion().getCodInst() });
				}

				nitReturn = (String) persona.get("ruc");
			} else {
				// se recupera de la emision
				RegistroLocal registroLocal = new RegistroBean();
				registroLocal.setEntityManager(getEntityManager());

				List<Registro> registroList = registroLocal.getRegistroByTipoEmis(apertura.getNroMov(), "E");
				if (registroList.size() == 0) {
					throw new AladiException("NO_EXISTE_EMIS", new Object[] { apertura.getNroReembLiteral() });
				}

				if (registroList.size() > 1) {
					throw new AladiException("NRO_EMIS_MAYOR_1", new Object[] { apertura.getNroReembLiteral() });
				}

				nitReturn = registroList.get(0).getNit();
				log.info("nit nit nit nit : " + nitReturn);
				if (nitReturn == null || nitReturn.trim().isEmpty()) {
					// si no se ha definido en el
					throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "La Emision no tiene registro de NIT para "
							+ apertura.getNroReembLiteral() });
				}
			}
		} else {
			// si es emision se recupera de persona
			QCoinCommos qCoinCommos = new QCoinCommos("coin");

			Map<String, Object> persona = qCoinCommos.getPersona(personaInst.getId().getCodPersona().trim());
			nitReturn = (String) persona.get("ruc");
			if (nitReturn == null || nitReturn.trim().isEmpty() || !nitReturn.trim().equalsIgnoreCase(nit.trim())) {
				// si no se econtro la persona o el nit es diferente con el de
				// la persona se verifica en ruc
				Map<String, Object> ruc = qCoinCommos.getRuc(nit.trim());
				if (ruc == null || ruc.size() == 0) {
					throw new AladiException("NIT_NO_REGISTRADO", new Object[] { codInst });
				}
			}
			nitReturn = nit.trim();
		}
		if (nitReturn == null || nitReturn.trim().isEmpty()) {
			throw new AladiException("NIT_NO_REGISTRADO", new Object[] { codInst });
		}

		nitReturn = nitReturn.trim();

		return nitReturn;
	}

	public static boolean esOperacionNueva(Apertura apertura) {
		boolean result = false;

		String fechaCorteStr = ConfigurationServ.getParamsSystem().get("fechaCorte");
		Date fechaCorte = UtilsDate.dateFromString(fechaCorteStr, "dd/MM/yyyy");
		if (apertura.getFechaEmis() != null) {
			return apertura.getFechaEmis().after(fechaCorte);
		}
		return result;

	}

	
	public AperturaLocal getAperturaLocal() {
		return aperturaLocal;
	}

	
	public Map<String, Object> getWarnnings() {
		return warnnings;
	}
}
