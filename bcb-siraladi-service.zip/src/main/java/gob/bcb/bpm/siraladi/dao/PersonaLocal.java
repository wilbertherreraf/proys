package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.Persona;

public interface PersonaLocal extends DAO<String, Persona>{

	Persona findForUser(String login);

	Persona findByCodigo(String nomparam);

	Persona saveorupdate(Persona params);

}