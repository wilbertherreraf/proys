package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the persona_inst database table.
 * 
 */
@Embeddable
public class PersonaInstPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="cod_inst")
	private String codInst;

	@Column(name="cod_persona")
	private String codPersona;

    public PersonaInstPK() {
    }
	public String getCodInst() {
		return this.codInst;
	}
	public void setCodInst(String codInst) {
		this.codInst = codInst;
	}
	public String getCodPersona() {
		return this.codPersona;
	}
	public void setCodPersona(String codPersona) {
		this.codPersona = codPersona;
	}

	
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof PersonaInstPK)) {
			return false;
		}
		PersonaInstPK castOther = (PersonaInstPK)other;
		return 
			this.codInst.equals(castOther.codInst)
			&& this.codPersona.equals(castOther.codPersona);

    }
    
	
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.codInst.hashCode();
		hash = hash * prime + this.codPersona.hashCode();
		
		return hash;
    }
}
