package gob.bcb.bpm.siraladi.utils;

import java.util.Arrays;
import java.util.List;

import javax.xml.namespace.QName;

/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public interface Constants {
	// ########## INICIO: VALORES DESTINADOS A SERVICIOS WEB ALADI ########//
	static final String NOMBRE_APP  = "SIRALADI";
	
	static final String CVE_ESTADOCTA  = "pec_estadocta";
	
	static final String CODIGO_MONEDA_DOLARES = "34";
	static final String CODIGO_MONEDA_DOLARES_SWF = "USD";
	static final String EST_MEN_SWFT = "P";
	

	static final String CODIGO_PAIS_BOLIVIA = "02";
	static final String CODIGO_PERSONA_BCB = "900";
	static final String CODIGO_INSTITUCION_BCB = "0660";
	static final String CODIGO_ID_PAGO_ANTICIPADO = "9";
	static final String CODIGO_INSTRUMENTO_PAGO_ANTICIPADO = "LEX";

	static final String PAR_ESTADOCTAACTIVA  = "A";
	static final String PAR_ESTADOCTANOAACTIVA  = "N";
	static final String PAR_ESTSWIFT_AUTO  = "A";	
	static final String PAR_ESTSWIFT_PEND  = "P";	
	static final String PAR_ESTSWIFT_RECH  = "R";	
	static final String PAR_ESTSWIFT_PREAUT  = "1";	
	
	static final String PARAM_PATHSWIFT  = "pathswift";
	static final String PARAM_OTP_RESOURCE  = "url-otp";
	/**
	 * Nombre del directorio donde se almacenana los archivos WS WSDL de aladi peru
	 */
	static final String WSDL_DIR_NAME = "wsdl";

	static final String PROP_TRUSTSTORE_LOCATION = "repositorio/certificados/trustStoreLocation";
	static final String PROP_TRUSTSTORE_PASSWORD = "repositorio/certificados/trustStorePassword";
	static final String PROP_KEYSTORE_LOCATION = "repositorio/certificados/keyStoreLocation";
	static final String PROP_KEYSTORE_PASSWORD = "repositorio/certificados/keyStorePassword";
	static final String ALADI_WS_USER = "repositorio/certificados/useraladi";
	static final String ALADI_WS_PASSWORD = "repositorio/certificados/passwordaladi";

	/**
	 * Instituciones Financieras   Consulta
	 */
	static final String FILE_NAME_WSDL_AIFACIF = "aifa_cif_ws.wsdl";	
	/**
	 * SICAP - Consulta de Saldos Bilaterales y Numerales
	 */
	static final String FILE_NAME_WSDL_ASICAPCSBN = "asicap_csbn_ws.wsdl";

	static final String FILE_NAME_WSDL_SICAPCCB = "asicap_ccb_ws.wsdl";
	static final String FILE_NAME_WSDL_SICAPCPA = "asicap_cpa_ws.wsdl";	
	static final String FILE_NAME_WSDL_SICOMRIMA = "asicom_rima_ws.wsdl";
	static final String FILE_NAME_WSDL_SICAPRCAOC = "asicap_rcaoc_ws.wsdl";
	static final String FILE_NAME_WSDL_SICOFRDCMA = "asicof_rdcma_ws.wsdl";

	static final QName SERVICE_NAME_IFACIF = new QName("BCRP", "ifa_cif_ws");	
	static final QName SERVICE_NAME_ASICAPCSBN = new QName("BCRP", "sicap_csbn_ws");	
	static final QName SERVICE_NAME_SICAPCCB = new QName("BCRP", "sicap_ccb_ws");
	static final QName SERVICE_NAME_SICAPCPA = new QName("BCRP", "sicap_cpa_ws");	
	static final QName SERVICE_NAME_SICOMRIMA = new QName("BCRP", "sicom_rima_ws");
	static final QName SERVICE_NAME_SICAPRCAOC = new QName("BCRP", "sicap_rcaoc_ws");
	static final QName SERVICE_NAME_SICOFRDCMA = new QName("BCRP", "sicof_rdcma_ws");
	
	static final String FILE_MESSAGES_RESP_ALADI = "repositorio/certificados/filemsgrespaladi";
	
	static final List<String> CODES_SUCCESS_ALADI = Arrays.asList("1000 1001 1016 1046 1056 1108 1109 1134 1142 3026 3068".split(" "));
	// ########## FIN: VALORES DESTINADOS A SERVICIOS WEB ALADI ########//

	// ########## INICIO: VALORES DESTINADOS A AUDITORIA ########//
	static final String AUDIT_HORA_RECEPCION = "ReceivedDate";
	static final String AUDIT_COD_TIPO_OPERACION = "codTipoOperacion";	
	static final String AUDIT_USER_ESTACION = "estacion";
	static final String AUDIT_USER_SESSION_ID = "userID";
	static final String AUDIT_USER_DATABASE_ID = "userDatabase";	
	// ########## FIN: VALORES DESTINADOS A AUDITORIA ########//

	// ########## INICIO: CONSTANTES DE ACCESO A DATOS DE BASES DE DATOS ########//
	static final String PROP_DB_JDBC_DRIVER = "repositorio/configdb/database[@id='ID-DATABASE']/jdbcdriver";
	static final String PROP_DB_JDBC_URL = "repositorio/configdb/database[@id='ID-DATABASE']/jdbcurl";
	static final String PROP_DB_JDBC_USER = "repositorio/configdb/database[@id='ID-DATABASE']/jdbcuser";
	static final String PROP_DB_JDBC_PASSWORD = "repositorio/configdb/database[@id='ID-DATABASE']/jdbcpassword";
	static final String PROP_DB_JNDI = "repositorio/configdb/database[@id='ID-DATABASE']/jndi";
	static final String PROP_DB_HANDLER_FACTORY = "repositorio/configdb/database[@id='ID-DATABASE']/handlerfactory";
	// ########## FIN: CONSTANTES DE ACCESO A DATOS DE BASES DE DATOS ########//
	/**
	 * Valor que define la ubicacion del paquete para estructura de parseo XML mediante JAXB
	 */
	static final String XML_PACKAGE_JAXB_IMPORTACION = "gob.bcb.bpm.siraladi.xml.importacion";
	/**
	 * valor del contexto de persistencia para la base de datos ALADI
	 */
	static final String PROP_PERSISTENCE_UNIT_NAME = "repositorio/servicios/servicio[@name='ID-SERVICENAME']/persistenceUnitName";
	static final String PROP_ID_DB_CONFIG_NAME_DEFAULT = "repositorio/servicios/servicio[@name='ID-SERVICENAME']/idDBConfigDefault";	
	static final String ATTRIBUTE_ERROR = "error";
	static final String ATTRIBUTE_EXCEPTION = "exception";
	static final String DESCRIP_PARAM_STATUS_NAME = "status";
	/**
	 * Formato fecha en la base de datos
	 */
	static final String FORMAT_DATE_DB = "dd/MM/yyyy";
	
	/**
	 * Formato de fecha hora para datos que requieran hora
	 */
	static final String FORMAT_DATE_TIME = "yyyy-MM-dd HH:mm:ss:SSS";
	/**
	 * tripo de transaccion temporal local
	 */	
	static final String TIPO_OPERACION_ALTMP00 = "ALTMP00";
	/**
	 * tipo de operacion creacion de apertura
	 */

	static final String TIPO_OPERACION_AL0101 = "AL0101";
	static final String TIPO_OPERACION_AL0102 = "AL0102";
	/**
	 * Consulta a apertura por codigo reembolso
	 */
	static final String TIPO_OPERACION_AL0103 = "AL0103";
	static final String TIPO_OPERACION_AL0104 = "AL0104";	
	/**
	 * Eliminacion de instrumento
	 */
	static final String TIPO_OPERACION_AL0105 = "AL0105";	
	/**
	 * Anulacion de instrumento
	 */
	static final String TIPO_OPERACION_AL0106 = "AL0106";
	
	/**
	 * Modificacion de solo instrumento . apertura
	 */
	static final String TIPO_OPERACION_AL0107 = "AL0107";	
	/**
	 * Modificacion de solo instrumento sin envio de datos
	 */
	static final String TIPO_OPERACION_AL0108 = "AL0108";	
	/**
	 * tipo de operacion Modificar Registro
	 */
	static final String TIPO_OPERACION_AL0201 = "AL0201";
	static final String TIPO_OPERACION_AL0202 = "AL0202";
	static final String TIPO_OPERACION_AL0203 = "AL0203";
	
	/**
	 * Operacion para crear y contabilizar directamente
	 */
	static final String TIPO_OPERACION_AL0204 = "AL0204";	
	/**
	 * Eliminacion de registro
	 */
	static final String TIPO_OPERACION_AL0205 = "AL0205";	
	/**
	 * tipo de operacion Modificar pago
	 */
	static final String TIPO_OPERACION_AL0301 = "AL0301";
	static final String TIPO_OPERACION_AL0302 = "AL0302";
	static final String TIPO_OPERACION_AL0303 = "AL0303";
	static final String TIPO_OPERACION_AL0304 = "AL0304";
	static final String TIPO_OPERACION_AL0305 = "AL0305";
	/**
	 * Operacion de almacenado en BDD individual de registros sobre operaciones consultadas anteriormente a WS Aladi
	 */
	static final String TIPO_OPERACION_AL0306 = "AL0306";
	/**
	 * Operacion de almacenado en BDD por lote de registros sobre operaciones consultadas anteriormente a WS Aladi
	 */	
	static final String TIPO_OPERACION_AL0307 = "AL0307";
	/**
	 * Operacion de consulta a WS Aladi y posterior almacenado en BDD por lote de registros sobre operaciones consultadas anteriormente 
	 */	
	static final String TIPO_OPERACION_AL0308 = "AL0308";
	/**
	 * eliminar un pago
	 */
	static final String TIPO_OPERACION_AL0309 = "AL0309";
	/**
	 * eliminar un t_pago_imp
	 */
	static final String TIPO_OPERACION_AL0310 = "AL0310";	
	/**
	 * tipo de operacion pagos anticipados
	 */
	static final String TIPO_OPERACION_AL0401 = "AL0401";
	static final String TIPO_OPERACION_AL0402 = "AL0402";
	/**
	 * consulta de saldo por convenio
	 * */
	static final String TIPO_OPERACION_AL0403 = "AL0403";
	/**
	 * consulta de saldo por convenio
	 * */
	static final String TIPO_OPERACION_AL0404 = "AL0404";	
	/**
	 * Eliminar anticipado 
	 */
	static final String TIPO_OPERACION_AL0405 = "AL0405";	
	/**
	 * tipo de operacion plan de pagos
	 */
	static final String TIPO_OPERACION_AL0501 = "AL0501";
	static final String TIPO_OPERACION_AL0502 = "AL0502";
	static final String TIPO_OPERACION_AL0503 = "AL0503";
	static final String TIPO_OPERACION_AL0504 = "AL0504";
	/**
	 * Eliminacion de plan de pagos por nro reembolso
	 */
	static final String TIPO_OPERACION_AL0505 = "AL0505";	
	
	// servicios de consultas
	/**
	 * Consulta de instituciones en ALADI
	 */
	static final String TIPO_OPERACION_AL0601 = "AL0601";	
	static final String TIPO_OPERACION_AL0602 = "AL0602";
	static final String TIPO_OPERACION_AL0603 = "AL0603";
	
	/******** lavado parametros ******/
	public static final String LAVADO_VERIFICA_LAVADO  = "verifica-lavado";	
	public static final String PAR_LAVADO_VERIFICA  = "S";
	public static final String LAVADO_RESOURCE = "url-lavado";
	/**
	 * Resp 000 : exito en scaneo
	 */
	public static final String COD_RESP_EXITO = "000";	
	/**
	 * error 01: scaneo con registros positivos
	 */
	public static final String COD_RESP_ERR_01 = "E01";
	/**
	 * Error 02 :excepcion en proceso scaneo
	 */
	public static final String COD_RESP_ERR_02 = "E02";		
}
