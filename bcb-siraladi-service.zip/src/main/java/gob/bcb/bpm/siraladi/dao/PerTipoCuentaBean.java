package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.PerTipoCuenta;
import gob.bcb.bpm.siraladi.jpa.PerTipoCuentaPK;


import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("perTipoCuentaLocal")
@Transactional
public class PerTipoCuentaBean extends GenericDAO<PerTipoCuentaPK, PerTipoCuenta> implements PerTipoCuentaLocal {
	/* (non-Javadoc)
	 * @see gob.bcb.bpm.siraladi.dao.PerTipoCuentaLocal#getPerTipoCuenta(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	
	public PerTipoCuenta getPerTipoCuenta(String cveTipoApe, String codInst, String codId, String codMoneda) {
		PerTipoCuenta perTipoCuenta = null; 
		String jpql = "";
		jpql = "SELECT p FROM PerTipoCuenta p, PersonaInst b "
				+ " WHERE p.id.codPersona = b.id.codPersona and b.id.codInst = :codInst and p.id.codId = :codId "
				+ "and p.id.cveTipoApe = :cveTipoApe and p.id.codMoneda = :codMoneda ";

		Query query = getEntityManager().createQuery(jpql);
		try {
			query.setParameter("codInst", codInst);
			query.setParameter("codId", codId);
			query.setParameter("cveTipoApe", cveTipoApe);
			query.setParameter("codMoneda", codMoneda);

			perTipoCuenta = (PerTipoCuenta) query.getSingleResult();
		} catch (NoResultException e) {
			perTipoCuenta = null;
		}
		return perTipoCuenta;
	}

}
