package gob.bcb.bpm.siraladi.msgmail;

import gob.bcb.bpm.siraladi.dao.InstitucionBean;
import gob.bcb.bpm.siraladi.dao.PersonaInstBean;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Param;
import gob.bcb.bpm.siraladi.jpa.Persona;
import gob.bcb.bpm.siraladi.service.ConfigurationServ;
import gob.bcb.bpm.siraladi.service.session.UserSessionHolder;
import gob.bcb.bpm.siraladi.utils.CorreoUtils;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;

import org.apache.commons.lang.ArrayUtils;
import org.apache.log4j.Logger;

public class MsgLogic {
	private static Logger log = Logger.getLogger(MsgLogic.class);
	private final static String AVISO_DEBITO_RECIBIDO[] = {
			"Comunicado Sist. SIR-ALADI: D�bito registrado",
			"Estimado(a) usuario(a),\n\n" + "Le comunicamos que se registr� en el sistema SIRALADI del Banco Central de Bolivia\n"
					+ "debitos por concepto de importaci�n\n" + "---------------------------------------------------------\n" + "Nro Reembolso: {0}\n"
					+ "Monto: {1}\n" + "---------------------------------------------------------\n" + "Atte. \nAdministrador SIR SIRALADI" };

	private final static String AVISO_DEBITO_NO_REGISTRADO[] = {
			"Comunicado Sist. SIR-ALADI: D�bito NO registrado",
			"Estimado(a) usuario(a),\n\n"
					+ "Le comunicamos que NO SE registr� en el sistema SIRALADI del Banco Central de Bolivia\n"
					+ "debito por concepto de importaci�n\n"
					+ "---------------------------------------------------------\n"
					+ "Nro Reembolso: {0}\n"
					+ "Monto: {1}\n"
					+ "---------------------------------------------------------\nFavor comunicarse con el Administrador del sistema para verificar el estado del mismo\n\n"
					+ "Atte. \nAdministrador SIR SIRALADI" };

	private final static String AVISO_OPERACION_REGISTRADA[] = { "Aviso SIRALADI: {0}",
			"{0}\n\n---------------------------------------------------------\n\n\n" + "Atte. \nAdministrador SIR SIRALADI" };

	private final static String ENCABEZADO = "Estimado(a) usuario(a),\n\n"
			+ "Le comunicamos que en el sistema SIRALADI del Banco Central de Bolivia \nse registro una operaci�n \n"
			+ "\n---------------------------------------------------------\n";
	private final static String ENTIDAD = "Entidad: {0}\n";
	private final static String ACTIVIDAD = "Actividad: {0}\n";

	public static String IP_SMTP = null;
	public static int PORT_SMTP;

	public static void envioMail(EntityManager entityManager, String tipo, String codInstitucion, String accion, boolean enviarAIFA, Object... parameters) {
		log.info("inicio de envio de correos " + tipo + " codInstitucion " + codInstitucion + " accion " + accion);
		List<String> correos = new ArrayList<String>();

		PersonaInstBean personaInstBean = new PersonaInstBean();
		personaInstBean.setEntityManager(entityManager);

		Param param = entityManager.find(Param.class, "BCB");		
		Persona personaBCB = personaInstBean.findPersonaByCodInst(param.getValparam().trim());
		if (personaBCB != null)
			correos.addAll(Arrays.asList(personaBCB.getCorreos().split(",")));

		Persona personaIFA = null;
		Institucion institucion = null;
		if (codInstitucion != null && !codInstitucion.isEmpty()) {
			// se evia a IFA
			codInstitucion = codInstitucion.trim();
			personaIFA = personaInstBean.findPersonaByCodInst(codInstitucion);
			if (personaIFA != null) {
				if (personaIFA.getCorreos() != null) {
					if (enviarAIFA)
						correos.addAll(Arrays.asList(personaIFA.getCorreos().split(",")));
				}
			}
			InstitucionBean institucionBean = new InstitucionBean();
			institucionBean.setEntityManager(entityManager);
			institucion = institucionBean.findById(codInstitucion, false);
		}
		log.info("Correos destinatarios " + ArrayUtils.toString(correos));
		CorreoUtils correoUtils = new CorreoUtils(IP_SMTP, PORT_SMTP);
		StringBuilder mensaje = new StringBuilder();
		if (tipo.equalsIgnoreCase("REGISOPERACION")) {
			mensaje.append(ENCABEZADO);
			if (institucion != null)
				mensaje.append(MessageFormat.format(ENTIDAD, institucion.getNomInst()));

			mensaje.append(MessageFormat.format(ACTIVIDAD, accion));
			mensaje.append(MessageFormat.format(AVISO_OPERACION_REGISTRADA[1], parameters));
		}
		try {
			for (String email : correos) {
				if (tipo.equalsIgnoreCase("DEBITO")) {
					correoUtils.enviaAlServidorSMTP((String) UserSessionHolder.get("correoremitente"), email, AVISO_DEBITO_RECIBIDO[0],
							MessageFormat.format(AVISO_DEBITO_RECIBIDO[1], parameters));
				} else if (tipo.equalsIgnoreCase("NOREGISTRADO")) {
					correoUtils.enviaAlServidorSMTP((String) UserSessionHolder.get("correoremitente"), email, AVISO_DEBITO_NO_REGISTRADO[0],
							MessageFormat.format(AVISO_DEBITO_NO_REGISTRADO[1], parameters));
				} else if (tipo.equalsIgnoreCase("REGISOPERACION")) {
					correoUtils.enviaAlServidorSMTP((String) UserSessionHolder.get("correoremitente"), email,
							MessageFormat.format(AVISO_OPERACION_REGISTRADA[0], new Object[] { accion }), mensaje.toString());
				}

			}
		} catch (Exception e1) {
			log.error("Error al enviar mail " + e1.getMessage(), e1);
		}
	}

	public static void envioMailLibre(String emailRemitente, String emailDest, String asunto, String mensaje) {
		CorreoUtils correoUtils = new CorreoUtils(IP_SMTP, PORT_SMTP);
		try {
			correoUtils.enviaAlServidorSMTP(emailRemitente, emailDest, asunto, mensaje);
		} catch (Exception e1) {
			log.error("Error al enviar mail " + e1.getMessage(), e1);
		}
	}

	public static void main(String[] args) {
		for (int i = 0; i < 1000; i++) {
			try {
				System.out.println("asdf");
				MsgLogic.IP_SMTP = "10.2.11.27";
				MsgLogic.PORT_SMTP = 25;
				MsgLogic.envioMailLibre("siraladi@bcb.gob.bo", "olobaton@bcb.gob.bo", "prueba siraladi", "prueba de envio de correo automaticos");
				MsgLogic.envioMailLibre("siraladi@bcb.gob.bo", "wherrera@bcb.gob.bo", "prueba siraladi", "prueba de envio de correo automaticos");
				MsgLogic.envioMailLibre("siraladi@bcb.gob.bo", "rcondori@bcb.gob.bo", "prueba siraladi", "prueba de envio de correo automaticos");
				MsgLogic.envioMailLibre("siraladi@bcb.gob.bo", "lordonez@bcb.gob.bo", "prueba siraladi", "prueba de envio de correo automaticos");
				System.out.println("Meils enviados nuevo.....");
			} catch (Exception e) {
				e.printStackTrace();
			}

			try {
				Thread.sleep(30000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
