package gob.bcb.bpm.siraladi.dao.qnative;

/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public interface QCoinCommosLocal extends DBSourceHandler{

}
