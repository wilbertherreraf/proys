package gob.bcb.bpm.siraladi.dao;

import java.util.List;


import javax.persistence.Query;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import gob.bcb.bpm.siraladi.jpa.Usuario;
import gob.bcb.bpm.siraladi.jpa.Usuario;
import gob.bcb.bpm.siraladi.jpa.Usuario;


@Repository("usuarioLocal")
@Transactional
public class UsuarioBean extends GenericDAO<String, Usuario> implements UsuarioLocal {
	private static Logger log = Logger.getLogger(UsuarioBean.class);

	public Usuario findByCodigo(String codUsuario) {
		String jpql = "SELECT t FROM Usuario t WHERE t.codUsuario = :codUsuario ";

		Query query = getEntityManager().createQuery(jpql);

		query.setParameter("codUsuario", codUsuario);
		List lista = query.getResultList();
		if (lista.size() > 0) {
			return (Usuario) lista.get(0);
		}
		return null;
	}

	public List<Usuario> findByEstado(String cveVigente) {
		String jpql = "SELECT t FROM Usuario t ";

		if (!StringUtils.isBlank(cveVigente)) {
			jpql = jpql.concat("WHERE t.cveVigente = :cveVigente ");
		}
		Query query = getEntityManager().createQuery(jpql);

		if (!StringUtils.isBlank(cveVigente)) {
			query.setParameter("cveVigente", cveVigente);
		}
		List lista = query.getResultList();
		return lista;
	}
	
	public Usuario saveorupdate(Usuario usuario ) {
		log.info("Actualizando usuario " + usuario.toString());
		Usuario usuarioOld = findByCodigo(usuario.getCodUsuario());
		
		if (usuarioOld == null){
			persist(usuario);
		} else {
			makePersistent(usuario);
		}
		usuarioOld = findByCodigo(usuario.getCodUsuario());
		
		return usuarioOld; 
	}
}
