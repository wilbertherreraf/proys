package gob.bcb.bpm.siraladi.dao;

import java.util.Date;
import java.util.List;




import gob.bcb.bpm.siraladi.jpa.DiaEspecial;
import gob.bcb.bpm.siraladi.jpa.Horario;
import gob.bcb.bpm.siraladi.jpa.HorarioPK;

public interface HorarioLocal extends DAO<HorarioPK, Horario>{

	boolean operacionEstaEnHorario(String codTipoOper, String codHorario, Date hora);

	/**
	 * Busca el horario que se encuentra entre horaIni y HoraFin 
	 * @param codTipoOper tipo de operacion a buscar
	 * @param subTipoOperacion
	 * @param hora parametro fecha solo se considera los campos de hora, minuto y segundo, si es nulo por defecto es la hora actual
	 * @return retorna el primer registro encontrado si hubiera mas de un registro no se las considera
	 */
	Horario findByTOper(String codTipoOper, String subTipoOperacion, Date hora);

	Horario saveorupdate(Horario horario);

	List<Horario> getSocHorarioList();

	Horario findByCodigo(String codTipoOper, String codHorario);

	//DiaEspecial diaEspByTOperCodHorario(String codTipoOper, String codHorario, Date hora, boolean addCondicionHora);

}
