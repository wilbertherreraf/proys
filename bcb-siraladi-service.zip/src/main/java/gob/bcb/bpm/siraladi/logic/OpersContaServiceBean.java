package gob.bcb.bpm.siraladi.logic;

import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import gob.bcb.bpm.siraladi.dao.MovCoinBean;
import gob.bcb.bpm.siraladi.dao.MovCoinLocal;
import gob.bcb.bpm.siraladi.exceptions.AladiException;
import gob.bcb.bpm.siraladi.jpa.MovCoin;
import gob.bcb.bpm.siraladi.jpa.Pago;
import gob.bcb.bpm.siraladi.jpa.RegAnticipado;
import gob.bcb.bpm.siraladi.jpa.Registro;
import gob.bcb.bpm.siraladi.service.session.UserSessionHolder;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TemporalType;

import org.apache.log4j.Logger;
import gob.bcb.bpm.siraladi.utils.Constants;

/**
 * @author wilherrera Wilbert Herrera Flores Banco Central de Bolivia Departamento de Desarrollo
 */
public class OpersContaServiceBean implements OpersContaServiceLocal {
	private static Logger log = Logger.getLogger(OpersContaServiceBean.class);

	@PersistenceContext(unitName = "ALADI_PU")
	private EntityManager entityManager;
	private Map<String, Object> warnnings = new HashMap<String, Object>();

	public OpersContaServiceBean() {
	}

	public OpersContaServiceBean(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	
	public EntityManager getEntityManager() {
		return entityManager;
	}

	
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	
	public String contabilizaPago(Pago pago, int tipo) {

		String resultProc = null;

		try {
			log.info("Ejecutando contabilizaPago para nro mov : " + pago.getNroMov() + " tipo: " + tipo);
			Query query = getEntityManager().createNativeQuery(
					"execute procedure p_contapago(:nro_mov, :nro_mov_ape, :cve_est_reg, :cod_instrumento, :cod_inst_recep, "
							+ ":debe_mo, :haber_mo, :nit, :cod_usuario, :estacion, :tipo)");

			query.setParameter("nro_mov", pago.getNroMov());
			query.setParameter("nro_mov_ape", pago.getNroMovApe());
			// whf registro.getCveEstadoReg() se parametriza P ya que el estado
			// anterior ya no es 1
			// sino
			// P
			query.setParameter("cve_est_reg", "P");
			query.setParameter("cod_instrumento", pago.getInstrumento().getCodInstrumento());
			query.setParameter("cod_inst_recep", pago.getInstitucion().getCodInst());
			query.setParameter("debe_mo", pago.getDebeMo());
			query.setParameter("haber_mo", pago.getHaberMo());
			query.setParameter("nit", pago.getNit());
			query.setParameter("cod_usuario", UserSessionHolder.get(Constants.AUDIT_USER_DATABASE_ID));
			query.setParameter("estacion", UserSessionHolder.get(Constants.AUDIT_USER_ESTACION));
			query.setParameter("tipo", tipo);
			resultProc = (String) query.getSingleResult();

		} catch (Exception e) {
			StringBuilder sb = new StringBuilder();
			int count = 0;
			for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
				if (cause instanceof SQLException) {
					count++;
					sb.append(cause.getMessage());
					sb.append(" , ");
				}
			}
			log.error("Error al contabilizar debito-reembolso " + e.getMessage(), e);
			throw new AladiException("ERROR_SPL_BDD_CONTABLE", new Object[] { (count > 0 ? sb.toString().replace(", null ,", "") : e.getMessage().replace(
					", null ,", "")) });
		}

		if (resultProc == null && tipo == 1) {
			throw new AladiException("ERROR_EN_BDD_CONTABLE", new Object[] { "p_contapago", pago.getNroMov() });
		}
		if (tipo == 1) {
			MovCoinLocal movCoinLocal = new MovCoinBean();
			movCoinLocal.setEntityManager(entityManager);
			List<MovCoin> movCoinList = movCoinLocal.findByNroMov(pago.getNroMov());
			if (movCoinList.size() == 0) {
				throw new AladiException("ERROR_EN_BDD_CONTABLE", new Object[] { "p_contapago", pago.getNroMov() });
			}
			for (MovCoin movCoin : movCoinList) {
				log.info("Debitos-reembolsos: Comprobantes creados para nro mov " + pago.getNroMov() + "[Tipo: " + movCoin.getCveTipoComprob() + " - Nro: "
						+ movCoin.getNroComprob() + "]");
			}

		}
		return resultProc;
	}

	
	public String contabilizaRegistro(Registro registro, int tipo) {
		String resultProc = null;
		try {
			log.info("Inicio de llamada a procedimiento p_contaregistro " + registro.getNroMov() + " tipo = " + tipo);
			Query query = getEntityManager().createNativeQuery(
					"execute procedure p_contaregistro(:nro_mov, :nro_mov_ape, :cve_est_reg, :cve_tipo_emis, :cod_instrumento, :cod_inst_recep, "
							+ ":fecha_trans, :debe_mo, :haber_mo, :nit, :reg_obs, :cod_usuario, :estacion, :tipo)");

			query.setParameter("nro_mov", registro.getNroMov());
			query.setParameter("nro_mov_ape", registro.getNroMovApe());
			// whf registro.getCveEstadoReg() se parametriza P ya que el estado
			// anterior ya no es 1
			// sino
			// P
			query.setParameter("cve_est_reg", "P");
			query.setParameter("cve_tipo_emis", registro.getCveTipoEmis());
			query.setParameter("cod_instrumento", registro.getInstrumento().getCodInstrumento());
			query.setParameter("cod_inst_recep", registro.getInstitucion().getCodInst());
			query.setParameter("fecha_trans", registro.getFechaTrans(), TemporalType.DATE);
			query.setParameter("debe_mo", registro.getDebeMo());
			query.setParameter("haber_mo", registro.getHaberMo());
			query.setParameter("nit", registro.getNit());
			query.setParameter("reg_obs", registro.getRegObs());
			query.setParameter("cod_usuario", UserSessionHolder.get(Constants.AUDIT_USER_DATABASE_ID));
			query.setParameter("estacion", UserSessionHolder.get(Constants.AUDIT_USER_ESTACION));
			query.setParameter("tipo", tipo);
			resultProc = (String) query.getSingleResult();

		} catch (Exception e) {
			StringBuilder sb = new StringBuilder();
			int count = 0;
			for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
				if (cause instanceof SQLException) {
					count++;
					sb.append(cause.getMessage());
					sb.append(" , ");
				}
			}
			log.error("==>EXCEPCION EN contabilizaRegistro: ", e);
			throw new AladiException("ERROR_SPL_BDD_CONTABLE", new Object[] { (count > 0 ? sb.toString().replace(", null ,", "") : e.getMessage().replace(
					", null ,", "")) });
		}

		if (resultProc == null && tipo == 1) {
			throw new AladiException("ERROR_EN_BDD_CONTABLE", new Object[] { "p_contaregistro", registro.getNroMov() });
		}

		if (tipo == 1) {
			MovCoinLocal movCoinLocal = new MovCoinBean();
			movCoinLocal.setEntityManager(entityManager);
			List<MovCoin> movCoinList = movCoinLocal.findByNroMov(registro.getNroMov());
			if (movCoinList.size() == 0) {
				throw new AladiException("ERROR_EN_BDD_CONTABLE", new Object[] { "p_contaregistro", registro.getNroMov() });
			}
			log.info("Emisiones-pagos: Comprobantes creados " + movCoinList.size() + " para " + registro.getNroMov());
			for (MovCoin movCoin : movCoinList) {
				log.info("Emisiones-pagos: Comprobantes creados para nro mov " + registro.getNroMov() + "[Tipo: " + movCoin.getCveTipoComprob() + " - Nro: "
						+ movCoin.getNroComprob() + "]");
			}
		}
		return resultProc;
	}

	
	public String contabilizaPagoAnt(RegAnticipado regAnticipado, int tipo) {

		String resultProc = null;
		try {
			Query query = getEntityManager().createNativeQuery(
					"execute procedure p_contareganticipado(:nro_mov, :cve_tipo_ape, :cod_inst, :anio, :secuencia, "
							+ ":cod_instrumento, :cod_moneda, :cod_inst_recep, :debe_mo, :haber_mo, :cod_usuario, :estacion, :tipo)");

			query.setParameter("nro_mov", regAnticipado.getNroMov());
			query.setParameter("cve_tipo_ape", regAnticipado.getCveTipoApe());
			query.setParameter("cod_inst", regAnticipado.getCodInst());
			query.setParameter("anio", regAnticipado.getAnio());
			query.setParameter("secuencia", regAnticipado.getSecuencia());
			query.setParameter("cod_instrumento", regAnticipado.getCodInstrumento());
			query.setParameter("cod_moneda", regAnticipado.getCodMoneda());
			query.setParameter("cod_inst_recep", regAnticipado.getCodInstRecep());
			query.setParameter("debe_mo", regAnticipado.getDebeMo());
			query.setParameter("haber_mo", regAnticipado.getHaberMo());
			query.setParameter("cod_usuario", UserSessionHolder.get(Constants.AUDIT_USER_DATABASE_ID));
			query.setParameter("estacion", UserSessionHolder.get(Constants.AUDIT_USER_ESTACION));
			query.setParameter("tipo", tipo);

			resultProc = (String) query.getSingleResult();

		} catch (Exception e) {
			StringBuilder sb = new StringBuilder();
			int count = 0;
			for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
				if (cause instanceof SQLException) {
					count++;
					sb.append(cause.getMessage());
					sb.append(" , ");
				}
			}
			log.error("==>DESCRIPCION EXCEPCION: ", e);
			throw new AladiException("ERROR_SPL_BDD_CONTABLE", new Object[] { (count > 0 ? sb.toString().replace(", null ,", "") : e.getMessage().replace(
					", null ,", "")) });
		}

		if (resultProc == null && tipo == 1) {
			throw new AladiException("ERROR_EN_BDD_CONTABLE", new Object[] { "p_contareganticipado", regAnticipado.getNroMov() });
		}

		if (tipo == 1) {
			MovCoinLocal movCoinLocal = new MovCoinBean();
			movCoinLocal.setEntityManager(entityManager);
			List<MovCoin> movCoinList = movCoinLocal.findByNroMov(regAnticipado.getNroMov());
			if (movCoinList.size() == 0) {
				throw new AladiException("ERROR_EN_BDD_CONTABLE", new Object[] { "p_contareganticipado", regAnticipado.getNroMov() });
			}
			for (MovCoin movCoin : movCoinList) {
				log.info("pagos Anticipados: Comprobantes creados para nro mov " + regAnticipado.getNroMov() + " " + movCoin.getNroComprob());
			}
		}
		return resultProc;
	}

	
	public boolean getDiaHabil(Date fecha) {
		// whf verificar el dia habil por ahora siempre es habil
		return true;
	}

	
	public Map<String, Object> getWarnnings() {
		return warnnings;
	}
}
