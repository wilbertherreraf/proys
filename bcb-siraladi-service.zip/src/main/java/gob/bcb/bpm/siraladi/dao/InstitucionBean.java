package gob.bcb.bpm.siraladi.dao;

import java.util.List;


import javax.persistence.Query;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Pais;


@Repository("institucionLocal")
// @Transactional
@Transactional(propagation = Propagation.REQUIRED)
public class InstitucionBean extends GenericDAO<String, Institucion> implements InstitucionLocal {

	public InstitucionBean() {
		super();
		log.info("creado dao " + this.getClass().getName());
	}

	public Institucion findByCodInst(String codInst) {
		Institucion institucion = null;
		String jpql = "select i from Institucion i ";
		jpql = jpql.concat("where i.codInst = :codInst ");

		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("codInst", codInst);

		List result = query.getResultList();
		if (result.size() > 0)
			institucion = (Institucion) result.get(0);

		return institucion;
	}

	public Institucion findByPaisCodInst(String codPais, String codInst) {
		Institucion institucion = null;
		String jpql = "select i from Institucion i,  Pais p ";
		jpql = jpql.concat("where i.pais.codPais = p.codPais ");
		jpql = jpql.concat("and i.cveEstado = '0' ");
		jpql = jpql.concat("and p.codPais = :codPais ");
		jpql = jpql.concat("and i.codInst = :codInst ");

		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("codPais", codPais);
		query.setParameter("codInst", codInst);

		List result = query.getResultList();
		if (result.size() > 0)
			institucion = (Institucion) result.get(0);

		return institucion;
	}

	public Institucion findByBIC(String bic, String bicBranch) {
		String jpql = "select i from Institucion i ";
		jpql = jpql.concat("where i.bic = :bic ");

		if (!StringUtils.isBlank(bicBranch)) {
			//jpql = jpql.concat("and i.bic = :bic ");
		}
		
		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("bic", bic);
		
		if (!StringUtils.isBlank(bicBranch)) {
			query.setParameter("bicBranch", bicBranch);
		}
		
		List result = query.getResultList();
		if (result.size() == 1)
			return (Institucion) result.get(0);

		return null;
	}

	
	public List<Institucion> findByCveEstado(String cveEstado, String codPais) {
		String jpql = "select i from Institucion i,  Pais p ";
		jpql = jpql.concat("where i.pais.codPais = p.codPais ");
		jpql = jpql.concat("and i.cveEstado = :cveEstado ");

		if (codPais != null) {
			jpql += "and p.codPais = :codPais ";
		}

		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("cveEstado", cveEstado);
		if (codPais != null) {
			query.setParameter("codPais", codPais);
		}

		return query.getResultList();
	}

	public List<Institucion> findInstituciones(Institucion institucion) {
		String jpql = "select i from Institucion i ";
		jpql = jpql.concat("where i.nomInst is not null ");

		if (institucion != null) {
			if (!StringUtils.isBlank(institucion.getCveEstado())) {
				jpql = jpql.concat("and i.cveEstado = :cveEstado ");
			}

			if (institucion.getPais() != null && !StringUtils.isBlank(institucion.getPais().getCodPais())) {
				jpql = jpql.concat("and i.pais.codPais = :codPais ");
			}
			if (!StringUtils.isBlank(institucion.getCveTipoInst())) {
				jpql = jpql.concat("and i.cveTipoInst = :cveTipoInst ");
			}
			if (!StringUtils.isBlank(institucion.getBic())) {
				jpql = jpql.concat("and i.bic = :bic ");
			}

			if (!StringUtils.isBlank(institucion.getCtaNumero())) {
				jpql = jpql.concat("and i.ctaNumero = :ctaNumero ");
			}
		}

		log.info("Buscar instituciones " + jpql);
		Query query = getEntityManager().createQuery(jpql);
		if (institucion != null) {
			if (!StringUtils.isBlank(institucion.getCveEstado())) {
				query.setParameter("cveEstado", institucion.getCveEstado());
			}

			if (institucion.getPais() != null && !StringUtils.isBlank(institucion.getPais().getCodPais())) {
				query.setParameter("codPais", institucion.getPais().getCodPais());
			}
			if (!StringUtils.isBlank(institucion.getCveTipoInst())) {
				query.setParameter("cveTipoInst", institucion.getCveTipoInst());
			}
			if (!StringUtils.isBlank(institucion.getBic())) {
				jpql = jpql.concat("and i.bic = :bic ");
				query.setParameter("bic", institucion.getBic());
			}

			if (!StringUtils.isBlank(institucion.getCtaNumero())) {
				jpql = jpql.concat("and i.ctaNumero = :ctaNumero ");
				query.setParameter("ctaNumero", institucion.getCtaNumero());
			}
		}

		return query.getResultList();
	}

	public List<Institucion> findIntermediario(String codPais, String codInst) {
		String jpql = "select i from Institucion i";
		jpql = jpql.concat("where i.cveEstado = '0' ");
		jpql = jpql.concat("and i.codInst = :codInst ");

		Query query = getEntityManager().createQuery(jpql);
		// query.setParameter("codPais", codPais);
		query.setParameter("codInst", codInst);

		List result = query.getResultList();

		return result;
	}

	public Institucion guardarInstitucion(Institucion institucion) {
		Institucion institucionOld = findByCodInst(institucion.getCodInst());
		if (institucionOld == null) {
			log.info("Nueva inst " + institucion.getBic());

			if (institucion.getCveTipoInst() != null && institucion.getCveTipoInst().equals("E")) {
				PaisBean paisBean = new PaisBean();
				paisBean.setEntityManager(getEntityManager());
				Pais pais = paisBean.findById("01", false);

				institucion.setPais(pais);

				String codigo = getcodigo("E");
				institucion.setCodInst(codigo);
			}
			log.info("XXX: antes salvado " + institucion.getCodInst());
			// entityManager.persist(institucion);
			persist(institucion);
			log.info("Nueva inst salvado " + institucion.getCodInst());
		} else {
			log.info("modifica inst " + institucion.getCodInst());

			// getEntityManager().merge(institucion);
			makePersistent(institucion);
			log.info("modfiica inst salvado " + institucion.getCodInst());
		}

		institucionOld = findByCodInst(institucion.getCodInst());
		return institucionOld;
	}

	private String getcodigo(String cveTipoInst) {
		String jpql = "select i from Institucion i ";
		jpql = jpql.concat("where i.cveTipoInst = :cveTipoInst ");

		Query query = getEntityManager().createQuery(jpql);

		query.setParameter("cveTipoInst", cveTipoInst);

		Integer codigo = 0;
		List<Institucion> institucionLista = query.getResultList();
		for (Institucion institucion : institucionLista) {
			if (institucion.getCodInst().startsWith("E")) {
				String num = institucion.getCodInst().substring(1);
				if (NumberUtils.isNumber(num)) {
					Integer cod = Integer.valueOf(num);
					if (cod.compareTo(codigo) > 0) {
						codigo = cod;
					}
				}
			}
		}
		codigo++;
		log.info("nuevo codigo inst ");
		return "E" + String.format("%03d", codigo);
	}
}
