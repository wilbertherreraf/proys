package gob.bcb.bpm.siraladi.dao.qnative;

import org.apache.log4j.Logger;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import gob.bcb.bpm.siraladi.common.UtilsQNatives;

/**
 * @author wilherrera Wilbert Herrera Flores Banco Central de Bolivia
 *         Departamento de Desarrollo
 */
public class QCoinCommos extends QNatives {
	private static Logger log = Logger.getLogger(QCoinCommos.class);
//	private static final String SELECT_COUNT_FERIADO = "select count(*) from contbcb@bcbux02:feriado where fecha_feriado = ?";
//	private static final String SELECT_PERSONA = "SELECT cve_tipo_persona, nom_persona, direccion1, "
//			+ "direccion2, cve_ciudad, telefono1, telefono2, telefono3, " + "fax, casilla, ruc, cve_vigente, cod_usuario, "
//			+ "fecha_hora, estacion, cve_tipo_juridica, pagina_web, email " + "FROM contbcb@bcbux02:persona where cod_persona = ? and cve_vigente = 'V'";
	private static final String SELECT_COUNT_FERIADO = "select count(*) from feriado where fecha_feriado = ?";
	private static final String SELECT_PERSONA = "SELECT cve_tipo_persona, nom_persona, direccion1, "
			+ "direccion2, cve_ciudad, telefono1, telefono2, telefono3, fax, casilla, ruc, cve_vigente, cod_usuario, "
			+ "fecha_hora, estacion, cve_tipo_juridica, pagina_web, email " + "FROM persona where cod_persona = ? and cve_vigente = 'V'";
	private static final String SELECT_RUC = "SELECT ruc, nombre FROM ruc where ruc = ? and cve_vigente = 'V' ";
	
	public QCoinCommos(String idDBSource) {
		super(idDBSource);
	}

	public boolean isHabil(java.util.Date fecha) {
		boolean resp = false;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = getConnection().prepareStatement(SELECT_COUNT_FERIADO);
			Date d = new Date(fecha.getTime());
			ps.setDate(1, d);
			rs = ps.executeQuery();

			resp = true;
			if (rs.next()) {
				if (rs.getInt(1) == 0) {
					Calendar fec = Calendar.getInstance();
					fec.setTime(fecha);

					if (fec.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY) {
						resp = false;
					} else if (fec.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
						resp = false;
					}
				} else {
					resp = false;
				}
			}
		} catch (SQLException e) {
			resp = false;
			throw new RuntimeException(e);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					log.error("EXCEPCION DE BDD: " + e.getMessage(), e);
				}
			}
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					log.error("EXCEPCION DE BDD: " + e.getMessage(), e);
				}
			}
			closeConnection();
		}
		return resp;
	}

	public Map<String, Object> getPersona(String codPersona) {
		Set<Map<String, Object>> result = null;
		Map<String, Object> persona = new HashMap<String, Object>();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = getConnection().prepareStatement(SELECT_PERSONA);
			ps.setString(1, codPersona);
			rs = ps.executeQuery();
			result = (Set<Map<String, Object>>) UtilsQNatives.convertResultSetToMap(rs);
			if (result.size() > 0)
				persona = (Map<String, Object>) result.iterator().next(); 
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					log.error("EXCEPCION DE BDD: " + e.getMessage(), e);
				}
			}
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					log.error("EXCEPCION DE BDD: " + e.getMessage(), e);
				}
			}
			closeConnection();
		}
		return persona;
	}
	 
	public Map<String, Object> getRuc(String nit) {
		Set<Map<String, Object>> result = null;
		Map<String, Object> regTabla = new HashMap<String, Object>();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = getConnection().prepareStatement(SELECT_RUC);
			ps.setString(1, nit);
			rs = ps.executeQuery();
			result = (Set<Map<String, Object>>) UtilsQNatives.convertResultSetToMap(rs);
			if (result.size() > 0)
				regTabla = (Map<String, Object>) result.iterator().next(); 
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					log.error("EXCEPCION DE BDD: " + e.getMessage(), e);
				}
			}
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					log.error("EXCEPCION DE BDD: " + e.getMessage(), e);

				}
			}
			closeConnection();
		}
		return regTabla;
	}	
}
