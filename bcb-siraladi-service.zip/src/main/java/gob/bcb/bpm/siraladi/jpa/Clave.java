package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the clave database table.
 * 
 */
@Entity
@Table(name="clave")
public class Clave implements Serializable{
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="nomdato", unique=true, nullable=false)
	private String nomdato;

	@Column(name="descdato")
	private String descdato;

    public Clave() {
    }

	public String getNomdato() {
		return this.nomdato;
	}

	public void setNomdato(String nomdato) {
		this.nomdato = nomdato;
	}

	public String getDescdato() {
		return this.descdato;
	}

	public void setDescdato(String descdato) {
		this.descdato = descdato;
	}

}