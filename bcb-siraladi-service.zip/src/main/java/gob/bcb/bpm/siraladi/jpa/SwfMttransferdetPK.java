package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class SwfMttransferdetPK implements Serializable {
	// default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name = "dtt_codttransfer")
	private String dttCodttransfer;

	@Column(name = "dtt_codcampo")
	private String dttCodcampo;
	
	@Column(name = "dtt_bloque")
	private Integer dttBloque;
	
	public SwfMttransferdetPK() {
	}

	public String getDttCodttransfer() {
		return dttCodttransfer;
	}

	public void setDttCodttransfer(String dttCodttransfer) {
		this.dttCodttransfer = dttCodttransfer;
	}

	public String getDttCodcampo() {
		return dttCodcampo;
	}

	public void setDttCodcampo(String dttCodcampo) {
		this.dttCodcampo = dttCodcampo;
	}

	public Integer getDttBloque() {
		return dttBloque;
	}

	public void setDttBloque(Integer dttBloque) {
		this.dttBloque = dttBloque;
	}

	
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dttBloque == null) ? 0 : dttBloque.hashCode());
		result = prime * result + ((dttCodcampo == null) ? 0 : dttCodcampo.hashCode());
		result = prime * result + ((dttCodttransfer == null) ? 0 : dttCodttransfer.hashCode());
		return result;
	}

	
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SwfMttransferdetPK other = (SwfMttransferdetPK) obj;
		if (dttBloque == null) {
			if (other.dttBloque != null)
				return false;
		} else if (!dttBloque.equals(other.dttBloque))
			return false;
		if (dttCodcampo == null) {
			if (other.dttCodcampo != null)
				return false;
		} else if (!dttCodcampo.equals(other.dttCodcampo))
			return false;
		if (dttCodttransfer == null) {
			if (other.dttCodttransfer != null)
				return false;
		} else if (!dttCodttransfer.equals(other.dttCodttransfer))
			return false;
		return true;
	}

	
}
