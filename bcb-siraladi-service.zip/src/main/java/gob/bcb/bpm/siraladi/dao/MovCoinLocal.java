package gob.bcb.bpm.siraladi.dao;

import gob.bcb.bpm.siraladi.jpa.MovCoin;
import gob.bcb.bpm.siraladi.jpa.MovCoinPK;
import java.util.List;

public interface MovCoinLocal extends DAO<MovCoinPK, MovCoin> {

	public abstract List<MovCoin> findByNroMov(Integer nroMov);

}