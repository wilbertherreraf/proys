package gob.bcb.bpm.siraladi.dao;

import java.util.List;

import javax.persistence.Query;

import gob.bcb.bpm.siraladi.exceptions.AladiException;
import gob.bcb.bpm.siraladi.jpa.ClasifProductos;
import gob.bcb.bpm.siraladi.jpa.Param;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("clasifProductosLocal")
@Transactional
public class ClasifProductosBean extends GenericDAO<Integer, ClasifProductos> implements ClasifProductosLocal {

	/* (non-Javadoc)
	 * @see gob.bcb.bpm.siraladi.dao.ClasifProductosLocal#findByCodigo(java.lang.Integer)
	 */
	
	public ClasifProductos findByCodigo(Integer nomparam) {
		String jpql = "SELECT t FROM ClasifProductos t ";
		jpql = jpql.concat("WHERE t.codClasifprod = :codClasifprod ");

		Query query = getEntityManager().createQuery(jpql);
		query.setParameter("codClasifprod", nomparam);

		List lista = query.getResultList();
		if (lista.size() > 0) {
			return (ClasifProductos) lista.get(0);
		}
		return null;
	}
	/* (non-Javadoc)
	 * @see gob.bcb.bpm.siraladi.dao.ClasifProductosLocal#saveorupdate(gob.bcb.bpm.siraladi.jpa.ClasifProductos)
	 */
	
	public ClasifProductos saveorupdate(ClasifProductos params ) {
		ClasifProductos horarioOld = findByCodigo(params.getCodClasifprod());
	
		if (horarioOld == null){
			makePersistent(params);			
		} else {
			makePersistent(params);
		}
		horarioOld = findByCodigo(params.getCodClasifprod());
		log.info("Actualizando Param " + horarioOld.toString());		
		return horarioOld; 
	}	
}
