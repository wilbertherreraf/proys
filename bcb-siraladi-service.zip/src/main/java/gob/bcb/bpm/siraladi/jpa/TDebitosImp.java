package gob.bcb.bpm.siraladi.jpa;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;



/**
 * The persistent class for the t_debitos_imp database table.
 * 
 */
@Entity
@Table(name="t_debitos_imp")
public class TDebitosImp implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="nro_reg")
	private int nroReg;

	@Column(name="anio")
	private String anio;

	@Column(name="cod_id")
	private String codId;

	@Column(name="cod_inst")
	private String codInst;

	@Column(name="cod_inst_recep")
	private String codInstRecep;

	@Column(name="cod_instrumento")
	private String codInstrumento;

	@Column(name="cod_pais")
	private String codPais;

	private short corr;

	private short dav;

    @Temporal( TemporalType.TIMESTAMP)
	@Column(name="fecha_emis")
	private Date fechaEmis;

	@Column(name="monto_mo", precision=15, scale=2)
	private BigDecimal montoMo;

	@Column(name="nro_edicion")
	private int nroEdicion;

	@Column(name="obs")
	private String obs;

	@Column(name="secuencia")
	private String secuencia;

    public TDebitosImp() {
    }

	public int getNroReg() {
		return this.nroReg;
	}

	public void setNroReg(int nroReg) {
		this.nroReg = nroReg;
	}

	public String getAnio() {
		return this.anio;
	}

	public void setAnio(String anio) {
		this.anio = anio;
	}

	public String getCodId() {
		return this.codId;
	}

	public void setCodId(String codId) {
		this.codId = codId;
	}

	public String getCodInst() {
		return this.codInst;
	}

	public void setCodInst(String codInst) {
		this.codInst = codInst;
	}

	public String getCodInstRecep() {
		return this.codInstRecep;
	}

	public void setCodInstRecep(String codInstRecep) {
		this.codInstRecep = codInstRecep;
	}

	public String getCodInstrumento() {
		return this.codInstrumento;
	}

	public void setCodInstrumento(String codInstrumento) {
		this.codInstrumento = codInstrumento;
	}

	public String getCodPais() {
		return this.codPais;
	}

	public void setCodPais(String codPais) {
		this.codPais = codPais;
	}

	public short getCorr() {
		return this.corr;
	}

	public void setCorr(short corr) {
		this.corr = corr;
	}

	public short getDav() {
		return this.dav;
	}

	public void setDav(short dav) {
		this.dav = dav;
	}

	public Date getFechaEmis() {
		return this.fechaEmis;
	}

	public void setFechaEmis(Date fechaEmis) {
		this.fechaEmis = fechaEmis;
	}

	public BigDecimal getMontoMo() {
		return this.montoMo;
	}

	public void setMontoMo(BigDecimal montoMo) {
		this.montoMo = montoMo;
	}

	public int getNroEdicion() {
		return this.nroEdicion;
	}

	public void setNroEdicion(int nroEdicion) {
		this.nroEdicion = nroEdicion;
	}

	public String getObs() {
		return this.obs;
	}

	public void setObs(String obs) {
		this.obs = obs;
	}

	public String getSecuencia() {
		return this.secuencia;
	}

	public void setSecuencia(String secuencia) {
		this.secuencia = secuencia;
	}

}
