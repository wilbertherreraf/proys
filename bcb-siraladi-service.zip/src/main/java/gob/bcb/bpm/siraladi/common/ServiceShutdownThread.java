package gob.bcb.bpm.siraladi.common;

import gob.bcb.service.siraladi.Server;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public class ServiceShutdownThread extends Thread {
	private static Log log = LogFactory.getLog(ServiceShutdownThread.class);
	private Server _serviceManager;

	public ServiceShutdownThread(Server mgr) {
		_serviceManager = mgr;
	}

	/**
	 * Call the destroy method of the service manager, log any exceptions thrown.
	 */
	
	public void run() {
		try {
			log.info("Parando el servicio...");
			System.err.println("Parando el servicio...");
			System.out.println("Parando el servicio...");			
			_serviceManager.stop();
		} catch (Exception e) {
			try {
				log.error("Exception al parar el servicio...", e);
			} catch (Throwable t) {
				// If somehow the logging got shutdown before this was called....
				System.err.println("ServiceShutdownThread: Error destroying service.  Exception Message = " + t.getMessage());
			}
		}
	}
}
