package gob.bcb.bpm.siraladi.ws.clientaladi;

import gob.bcb.bpm.siraladi.common.ConsComunesNegocio;
import gob.bcb.bpm.siraladi.dao.PaisBean;
import gob.bcb.bpm.siraladi.exceptions.AladiException;
import gob.bcb.bpm.siraladi.exceptions.SystemInternalException;
import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Pais;
import gob.bcb.bpm.siraladi.jpa.TPagoImp;
import gob.bcb.bpm.siraladi.pojo.SaldoConvenio;
import gob.bcb.bpm.siraladi.service.ConfigurationServ;
import gob.bcb.bpm.siraladi.utils.Constants;
import gob.bcb.bpm.siraladi.utils.Utils;
import gob.bcb.bpm.siraladi.utils.UtilsDate;
import gob.bcb.bpm.siraladi.ws.clientaladi.aifacif.IfaCifWs;
import gob.bcb.bpm.siraladi.ws.clientaladi.aifacif.IfaCifWsExecute;
import gob.bcb.bpm.siraladi.ws.clientaladi.aifacif.IfaCifWsExecuteResponse;
import gob.bcb.bpm.siraladi.ws.clientaladi.aifacif.IfaCifWsSoapPort;
import gob.bcb.bpm.siraladi.ws.clientaladi.aifacif.SdtIFACIF;
import gob.bcb.bpm.siraladi.ws.clientaladi.aifacif.SdtIFACIFSdtIFACIFItem;
import gob.bcb.bpm.siraladi.ws.clientaladi.asicapccb.SdtSICAPCCB;
import gob.bcb.bpm.siraladi.ws.clientaladi.asicapccb.SdtSICAPCCBSdtSICAPCCBItem;
import gob.bcb.bpm.siraladi.ws.clientaladi.asicapccb.SicapCcbWs;
import gob.bcb.bpm.siraladi.ws.clientaladi.asicapccb.SicapCcbWsExecute;
import gob.bcb.bpm.siraladi.ws.clientaladi.asicapccb.SicapCcbWsExecuteResponse;
import gob.bcb.bpm.siraladi.ws.clientaladi.asicapccb.SicapCcbWsSoapPort;
import gob.bcb.bpm.siraladi.ws.clientaladi.asicapcsbn.SdtSICAPCSBN;
import gob.bcb.bpm.siraladi.ws.clientaladi.asicapcsbn.SdtSICAPCSBNSdtSICAPCSBNItem;
import gob.bcb.bpm.siraladi.ws.clientaladi.asicapcsbn.SicapCsbnWs;
import gob.bcb.bpm.siraladi.ws.clientaladi.asicapcsbn.SicapCsbnWsExecute;
import gob.bcb.bpm.siraladi.ws.clientaladi.asicapcsbn.SicapCsbnWsExecuteResponse;
import gob.bcb.bpm.siraladi.ws.clientaladi.asicapcsbn.SicapCsbnWsSoapPort;
import gob.bcb.bpm.siraladi.ws.clientaladi.asicaprcaoc.SdtSICAPRCAOC;
import gob.bcb.bpm.siraladi.ws.clientaladi.asicaprcaoc.SicapRcaocWs;
import gob.bcb.bpm.siraladi.ws.clientaladi.asicaprcaoc.SicapRcaocWsExecute;
import gob.bcb.bpm.siraladi.ws.clientaladi.asicaprcaoc.SicapRcaocWsExecuteResponse;
import gob.bcb.bpm.siraladi.ws.clientaladi.asicaprcaoc.SicapRcaocWsSoapPort;
import gob.bcb.bpm.siraladi.ws.clientaladi.asicofrdcma.SdtSICOFRDCMA;
import gob.bcb.bpm.siraladi.ws.clientaladi.asicofrdcma.SicofRdcmaWs;
import gob.bcb.bpm.siraladi.ws.clientaladi.asicofrdcma.SicofRdcmaWsExecute;
import gob.bcb.bpm.siraladi.ws.clientaladi.asicofrdcma.SicofRdcmaWsExecuteResponse;
import gob.bcb.bpm.siraladi.ws.clientaladi.asicofrdcma.SicofRdcmaWsSoapPort;
import gob.bcb.bpm.siraladi.ws.clientaladi.asicomrima.SdtSICOMRIMA;
import gob.bcb.bpm.siraladi.ws.clientaladi.asicomrima.SicomRimaWs;
import gob.bcb.bpm.siraladi.ws.clientaladi.asicomrima.SicomRimaWsExecute;
import gob.bcb.bpm.siraladi.ws.clientaladi.asicomrima.SicomRimaWsExecuteResponse;
import gob.bcb.bpm.siraladi.ws.clientaladi.asicomrima.SicomRimaWsSoapPort;
import gob.bcb.core.utils.XmlUtils;

import java.io.File;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.persistence.EntityManager;
//import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.ws.BindingProvider;

import org.apache.log4j.Logger;
import org.joda.time.Instant;
import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;

public class ClientAladiWSHandler {
	private static Logger log = Logger.getLogger(ClientAladiWSHandler.class);
	private static Map<String, URL> urlsWSDL = new ConcurrentHashMap<String, URL>();

	public static URL genURLPort(String fileNameWsdl) {
		if (urlsWSDL.containsKey(fileNameWsdl)) {
			return urlsWSDL.get(fileNameWsdl);
		}

		URL baseUrl = null;
		try {
			baseUrl = new URL("file:///" + ConfigurationServ.getConfigurationHome().concat("//").concat(Constants.WSDL_DIR_NAME).concat("//"));
			log.debug(" configurando url wsdl baseUrl : " + baseUrl.getPath() + " directori " + "file:/" + ConfigurationServ.getConfigurationHome()
					+ "/" + Constants.WSDL_DIR_NAME);
		} catch (MalformedURLException e) {
			throw new SystemInternalException("ERROR_CLIENTE_WS", new Object[] { fileNameWsdl, e.getMessage() });
		}
		URL wsdlURL = null;
		try {
			wsdlURL = new URL(baseUrl, fileNameWsdl);
			File h = new File(wsdlURL.getPath());
			if (!h.exists() || h.isDirectory()) {
				throw new SystemInternalException("ERROR_CLIENTE_WS",
						new Object[] { h.getAbsolutePath(), "archivo de configuraci n WSDL inexistente" });
			}
			log.debug("wsdlURL : " + wsdlURL.getPath());
		} catch (MalformedURLException e) {
			throw new SystemInternalException("ERROR_CLIENTE_WS", new Object[] { fileNameWsdl, e.getMessage() });
		}
		urlsWSDL.put(fileNameWsdl, wsdlURL);
		return wsdlURL;
	}

	/**
	 * Permite realizar una consulta de los datos en las Cuentas  B 
	 * 
	 * @param fechaDesde
	 * @param fechaHasta
	 * @return
	 */
	public static List<TPagoImp> execWSSicapCcb(Date fechaDesde, Date fechaHasta) {

		if (fechaDesde == null || fechaHasta == null) {
			throw new AladiException("PARAMETROS_INVALIDOS", new Object[] { "fechaDesde, fechaHasta", "Consulta de cuentas B" });
		}
		URL wsdlURL = ClientAladiWSHandler.genURLPort(Constants.FILE_NAME_WSDL_SICAPCCB);
		log.info("En consulta WS: " + wsdlURL.getFile() );
		List<TPagoImp> tPagoImpList = new ArrayList<TPagoImp>();
		SicapCcbWs service = null;
		SicapCcbWsSoapPort port = null;

		try {
			javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(new javax.net.ssl.HostnameVerifier() {
				public boolean verify(String hostname, javax.net.ssl.SSLSession sslSession) {
					if (hostname.equals("sicap.bcra.gov.ar")) {
						return true;
					}
					return true;
				}
			});
			
			service = new SicapCcbWs(wsdlURL, Constants.SERVICE_NAME_SICAPCCB);
			port = service.getSicapCcbWsSoapPort();
			((BindingProvider)port).getRequestContext().put("org.apache.cxf.http.no_io_exceptions", "true");			
			ClientAladiTLS.setupTLSWSClient(port);			
		} catch (Exception e) {
			log.error("Error en llamada al preparar WS " + e.getMessage(), e);
			throw new SystemInternalException("ERROR_CLIENTE_WS", new Object[] { Constants.FILE_NAME_WSDL_SICAPCCB, e.getMessage() });
		}
		{

			SicapCcbWsExecute parameters = new SicapCcbWsExecute();

			parameters.setContrasena(ConfigurationServ.getParamsSystem().get("ALADI_WS_PASSWORD"));
			parameters.setLogin(ConfigurationServ.getParamsSystem().get("ALADI_WS_USER"));
			
			Calendar cfdesde = GregorianCalendar.getInstance();
			cfdesde.setTime(fechaDesde);			
			LocalDate fecdesdeLd = LocalDateTime.fromCalendarFields(cfdesde).toLocalDate();
			
			parameters.setFecvalfrom(UtilsDate.StrToXMLGregoCal(UtilsDate.stringFromDate(fechaDesde, "yyyy-MM-dd"), "-"));
			parameters.setFecvalto(UtilsDate.StrToXMLGregoCal(UtilsDate.stringFromDate(fechaHasta, "yyyy-MM-dd"), "-"));			
			
			SicapCcbWsExecuteResponse result = null;
			log.info("Consulta iniciada para execWSSicapCcb de " + UtilsDate.stringFromDate(fechaDesde, Constants.FORMAT_DATE_DB) + " a "
					+ UtilsDate.stringFromDate(fechaHasta, Constants.FORMAT_DATE_DB));
			log.info("====INICIO: XML REQUEST WS CONVENIO ALADI=======" + UtilsDate.stringFromDate(new Date(), Constants.FORMAT_DATE_TIME));
			log.info(Utils.objectToXML(parameters));
			log.info("====FIN: XML REQUEST WS CONVENIO ALADI====");
			try {
				result = port.execute(parameters);
			} catch (Exception e) {
				log.error("Error en llamada a WS ", e);
				throw new AladiException("ERROR_EN_LLAMADA_WS_CONV_ALADI", new Object[] { wsdlURL.getHost(), e.getMessage() });
			}

			SdtSICAPCCB sdtSICAPCCB = new SdtSICAPCCB();
			sdtSICAPCCB = result.getSdtsicap();

			RespWSAladi respWSAladi = new RespWSAladi();
			respWSAladi.setCode(result.getSdtsicap().getSdtSICAPCCBSdtSICAPCCBItem().get(0).getCodigoRpta());

			try {
				respWSAladi.setContentXML(XmlUtils.objectJAXBToString(result));
			} catch (Exception e1) {
				log.warn("Error al desparseo de mensaje recibido se intenta con Utils.objectToXML");
				respWSAladi.setContentXML(Utils.objectToXML(sdtSICAPCCB));
			}

			log.info("====INICIO: XML respuesta WS CONVENIO ALADI=======");
			log.info(respWSAladi.getContentXML());
			log.info("=================FIN: XML respuesta WS CONVENIO ALADI=================");

			log.info("Resultado cod respuesta WS: " + respWSAladi.getCode() + " - " + respWSAladi.getDescripResp() + " con "
					+ result.getSdtsicap().getSdtSICAPCCBSdtSICAPCCBItem().size() + " registros retornados");

			if (!respWSAladi.isSuccessMsg()) {
				log.error("Mensaje de error desde aladi [" + respWSAladi.getCode() + respWSAladi.getDescripResp() + "]");
				throw new AladiException("ERROR_CONVENIO_ALADI", new Object[] { respWSAladi.getCode(), respWSAladi.getDescripResp() });
			}

			if (sdtSICAPCCB.getSdtSICAPCCBSdtSICAPCCBItem().size() > 0) {
				tPagoImpList = sicapCcbResponseToTPagoImp(result);
			} else {
				throw new AladiException("ERROR_CONVENIO_ALADI", new Object[] { respWSAladi.getCode(), respWSAladi.getDescripResp() });
			}
		}
		return tPagoImpList;
	}

	/**
	 * Permite el registro de las operaciones en las Cuentas  A  y los Cr ditos
	 * del SICAP.
	 * 
	 * @param apertura
	 * @param pago
	 * @return
	 */
	public static RespWSAladi execWSSicapRcaoc(String nroReembLiteral, String institucionPagadora, String convenio, String instrumento,
			Date fecPagoOValor, BigDecimal monto, String obs, String nroSolicitud, Integer secNroreembolso) {
		RespWSAladi respWSAladi = null;
		URL wsdlURL = genURLPort(Constants.FILE_NAME_WSDL_SICAPRCAOC);
		log.info("En consulta WS: " + wsdlURL.getFile());
		SicapRcaocWs ss = new SicapRcaocWs(wsdlURL, Constants.SERVICE_NAME_SICAPRCAOC);
		SicapRcaocWsSoapPort port = ss.getSicapRcaocWsSoapPort();

		{
			SicapRcaocWsExecute parameters = new SicapRcaocWsExecute();

			parameters.setContrasena(ConfigurationServ.getParamsSystem().get("ALADI_WS_PASSWORD"));
			parameters.setLogin(ConfigurationServ.getParamsSystem().get("ALADI_WS_USER"));
			parameters.setInspag(institucionPagadora);
			parameters.setConv(convenio);
			parameters.setNroreemb(nroReembLiteral + String.format("%04d", (secNroreembolso == null ? 0 : secNroreembolso))); // pago.getCorrDebpag()
			parameters.setInst(instrumento);
			
			Calendar cfchemi = GregorianCalendar.getInstance();
			cfchemi.setTime(fecPagoOValor);			
			LocalDate fecEmisLd = LocalDateTime.fromCalendarFields(cfchemi).toLocalDate();			
			parameters.setFchemi(fecEmisLd); 
			parameters.setMonto(monto.doubleValue());
			// Observaciones, Permite el registro de
			// observaciones adicionales para el detalle.
			// Solo ser  obligatorio cuando se registre
			// un extorno (EXT) y las anulaciones de
			// cr ditos (AEX, ALE y AUM) en los que se
			// deber  colocar el reembolso e
			// instrumento original.
			parameters.setObs(obs);
			parameters.setNrosol(nroSolicitud);

			log.info("Invocando WS execWSSicapRcaoc para cod reembolso: " + nroReembLiteral);
			log.info("====INICIO: XML REQUEST WS CONVENIO ALADI=======" + UtilsDate.stringFromDate(new Date(), Constants.FORMAT_DATE_TIME));
			log.info(Utils.objectToXML(parameters));
			log.info("====FIN: XML REQUEST WS CONVENIO ALADI====");

			SicapRcaocWsExecuteResponse executeReturn = null;
			try {
				javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(new javax.net.ssl.HostnameVerifier() {
					public boolean verify(String hostname, javax.net.ssl.SSLSession sslSession) {
						if (hostname.equals("sicap.bcra.gov.ar")) {
							return true;
						}
						return true;
					}
				});
				
				((BindingProvider)port).getRequestContext().put("org.apache.cxf.http.no_io_exceptions", "true");			
				ClientAladiTLS.setupTLSWSClient(port);				
				executeReturn = port.execute(parameters);
			} catch (Exception e) {
				log.error("Error en llamada a WS " + e.getMessage(), e);
				throw new AladiException("ERROR_EN_LLAMADA_WS_CONV_ALADI", new Object[] { wsdlURL.getHost(), e.getMessage() });
			}

			SdtSICAPRCAOC sdtSICAPRCAOC = new SdtSICAPRCAOC();
			sdtSICAPRCAOC = executeReturn.getSicap();
			// preparamos la respuesta
			respWSAladi = new RespWSAladi();
			respWSAladi.setCode(sdtSICAPRCAOC.getCodigoRpta());
			respWSAladi.getDatosAdicionales().put("nroDeb", sdtSICAPRCAOC.getNroDeb());
			try {
				respWSAladi.setContentXML(XmlUtils.objectJAXBToString(executeReturn));
			} catch (Exception e1) {
				log.warn("Error al desparseo de mensaje recibido se intenta con Utils.objectToXML");
				respWSAladi.setContentXML(Utils.objectToXML(sdtSICAPRCAOC));
			}

			try {
				respWSAladi.setFechaHoraReg(sdtSICAPRCAOC.getFecVal().toDate(), null);
			} catch (Exception e) {
			}
			log.info("SICAPRCAOC: Resultado cod respuesta WS: " + respWSAladi.getCode() + " - " + respWSAladi.getDescripResp());
			log.info("====INICIO: XML respuesta WS CONVENIO ALADI=======");
			log.info(respWSAladi.getContentXML());
			log.info("=================FIN: XML respuesta WS CONVENIO ALADI=================");

			if (!respWSAladi.isSuccessMsg()) {
				
				//throw new AladiException("ERROR_CONVENIO_ALADI", new Object[] { respWSAladi.getCode(), respWSAladi.getDescripResp() });
			}
		}

		return respWSAladi;
	}

	/**
	 * Registro de Derechos de Cobro Donde: Login, usuario y contrase a del
	 * cliente web service. C digo de Convenio, es el convenio contraparte.
	 * N mero de Reembolso; c digo de reembolso de la operaci n, ver detalle de
	 * la estructura del c digo de reembolso en la Tabla 1.1.1. Instrumento:
	 * puede ser dependiendo de la categorizaci n: 1(CC,CD,CCI,CDI), 2(LA,LAI),
	 * 3(PA,PAI,PE), 4(OP), 5(OD) y 6(GN). Tipo de Operaci n, puede ser Emisi n
	 * (E), Negociaci n (N), Modificaci n (X) o Anulaci n (X). Instituci n
	 * Receptora, el c digo de la Instituci n receptora. * Fecha Emisi n, es la
	 * fecha de registro del cobro. Fecha de Vencimiento, fecha de vencimiento
	 * del Cobro Monto, importe del Cobro * Observaciones, para el caso de las
	 * modificaciones y negociaciones es obligatorio poner en la primera
	 * posici n de este campo el Tipo de Operaci n que se Modifica/Anula de la
	 * operaci n original: Emisi n (E) o Negociaci n (N).
	 * 
	 * @param apertura
	 * @param codcon
	 * @param instr
	 * @param tipoOperacionAladi
	 * @param ifarecep
	 * @param fecEmisONego
	 * @param fecVencOPago
	 * @param montoOper
	 * @param obs
	 * @return
	 */
	public static RespWSAladi execWSSicofrdcma(Apertura apertura, String codcon, String instr, String tipoOperacionAladi, String ifarecep,
			Date fecEmisONego, Date fecVencOPago, BigDecimal montoOper, String obs, Integer secNroreembolso) {
		String observaciones = obs;
		Double monto = null;
		if (montoOper != null)
			monto = montoOper.doubleValue();

		RespWSAladi respWSAladi = null;
		URL wsdlURL = genURLPort(Constants.FILE_NAME_WSDL_SICOFRDCMA);
		log.info("En consulta WS: " + wsdlURL.getFile());
		SicofRdcmaWs ss = new SicofRdcmaWs(wsdlURL, Constants.SERVICE_NAME_SICOFRDCMA);
		SicofRdcmaWsSoapPort port = ss.getSicofRdcmaWsSoapPort();

		{
			SicofRdcmaWsExecute parameters = new SicofRdcmaWsExecute();

			parameters.setContrasena(ConfigurationServ.getParamsSystem().get("ALADI_WS_PASSWORD"));
			parameters.setLogin(ConfigurationServ.getParamsSystem().get("ALADI_WS_USER"));
			parameters.setCodcon(codcon);

			parameters.setNroreemb(apertura.getNroReembLiteral(true) + String.format("%04d", (secNroreembolso != null ? secNroreembolso : 0)));
			parameters.setInstr(instr);
			parameters.setTpooper(tipoOperacionAladi);
			parameters.setIfarecep(ifarecep);
			log.info("XXXXXXXX: Current DateTime: " + fecEmisONego + " " + fecVencOPago);
			
			Calendar cfchemi = GregorianCalendar.getInstance();
			if (fecEmisONego != null)
				cfchemi.setTime(fecEmisONego);
			LocalDate fecEmisLd = LocalDateTime.fromCalendarFields(cfchemi).toLocalDate();
			log.info("Current DateTime: " + fecEmisLd);
			Calendar cfchvenc = GregorianCalendar.getInstance();
			if (fecVencOPago != null)
				cfchvenc.setTime(fecVencOPago);
			LocalDate cfchvencLd = LocalDateTime.fromCalendarFields(cfchvenc).toLocalDate();
			log.info("Current DateTime: " + cfchvencLd);
			if (fecEmisONego != null)
				parameters.setFchemi(fecEmisLd);
			if (fecVencOPago != null)
				parameters.setFchvenc(cfchvencLd);			
//			parameters.setFchemi(fchemi);
//			parameters.setFchvenc(fchvenc);
			parameters.setMonto(monto);
			parameters.setObs(observaciones);

			log.info("Invocando WS SicofRdcmaWsSoapPort para cod reembolso: " + apertura.getNroReembLiteral());
			log.info("====INICIO: XML REQUEST WS CONVENIO ALADI=======" + UtilsDate.stringFromDate(new Date(), Constants.FORMAT_DATE_TIME));
			log.info(Utils.objectToXML(parameters));
			log.info("====FIN: XML REQUEST WS CONVENIO ALADI====");

			SicofRdcmaWsExecuteResponse executeReturn = null;
			try {
				javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(new javax.net.ssl.HostnameVerifier() {
					public boolean verify(String hostname, javax.net.ssl.SSLSession sslSession) {
						if (hostname.equals("sicap.bcra.gov.ar")) {
							return true;
						}
						return true;
					}
				});
				
				((BindingProvider)port).getRequestContext().put("org.apache.cxf.http.no_io_exceptions", "true");			
				ClientAladiTLS.setupTLSWSClient(port);				
				executeReturn = port.execute(parameters);
			} catch (Exception e) {
				log.error("Error en llamada a WS " + e.getMessage(), e);
				throw new AladiException("ERROR_EN_LLAMADA_WS_CONV_ALADI", new Object[] { wsdlURL.getHost(), e.getMessage() });
			}
			SdtSICOFRDCMA sdtSICOFRDCMA = new SdtSICOFRDCMA();
			sdtSICOFRDCMA = executeReturn.getSicof();

			// preparamos la respuesta
			respWSAladi = new RespWSAladi();
			respWSAladi.setCode(sdtSICOFRDCMA.getCodigoRpta());
			try {
				respWSAladi.setContentXML(XmlUtils.objectJAXBToString(executeReturn));
			} catch (Exception e1) {
				log.warn("Error al desparseo de mensaje recibido se intenta con Utils.objectToXML");
				respWSAladi.setContentXML(Utils.objectToXML(sdtSICOFRDCMA));
			}

			try {
				//respWSAladi.setFechaHoraReg(sdtSICOFRDCMA.getFechaValor().toGregorianCalendar().getTime(), sdtSICOFRDCMA.getHora());
			} catch (Exception e) {
			}

			log.info("SICOFRDCMA: Resultado cod respuesta WS: " + respWSAladi.getCode() + " - " + respWSAladi.getDescripResp());
			log.info("====INICIO: XML respuesta WS CONVENIO ALADI=======");
			log.info(respWSAladi.getContentXML());
			log.info("=================FIN: XML respuesta WS CONVENIO ALADI=================");

			if (!respWSAladi.isSuccessMsg()) {
				log.info("OOOOOOOOOOOOOOOOOOOOO JJJJJJJJJJJJJJJJJJJJJJ OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO C");				
				throw new AladiException("ERROR_CONVENIO_ALADI", new Object[] { respWSAladi.getCode(), respWSAladi.getDescripResp() });
			}
		}

		return respWSAladi;
	}

	/**
	 * SICOM Registro de Importaciones, Modificaciones y Anulaciones
	 * Donde:Login, usuario y contrase a del cliente web service Contrase a,
	 * contrase a del usuario web service C digo del Convenio, convenio
	 * contraparte. N mero de Reembolso, c digo de reembolso de la operaci n,
	 * ver detalle de la estructura del c digo de reembolso en la Tabla 1.1.1.
	 * Instrumento, puede ser dependiendo de la categorizaci n: 1(CC, CD, CCI,
	 * CDI), 2(LA, LAI), 3 (PA, PAI, PE), 4(OP), 5(OD) y 6(GN). Tipo de
	 * Operaci n, Emisi n (E) o Negociaci n (N). Los instrumentos CC, CD y OD
	 * solo se registran las emisiones. Para las modificaciones o anulaciones el
	 * tipo de operaci n es (X), teniendo en este caso que especificar en el
	 * campo Tipo de Operaci n que se registra el Tipo de Operaci n original.
	 * Instituci n Receptora, Instituci n financiera receptora autorizada. Fecha
	 * de Emisi n/Negociaci n, fecha de emisi n. Fecha de Vencimiento/Pago,
	 * fecha de vencimiento. Monto, importe de la Emisi n o Negociaci n.
	 * Observaciones, comentarios adicionales de la operaciones. Solo es
	 * obligatorio para el caso de modificaciones o anulaciones, en que se
	 * valida la primera posici n de este campo que debe especificar el Tipo de
	 * Operaci n original (E)misi n o (N)egociaci n de la operaci n.
	 * 
	 * @param apertura
	 * @param registro
	 * @param tipoOperacionAladi
	 *            Tipo de Operaci n, Emisi n (E) o Negociaci n (N). Los
	 *            instrumentos CC, CD y OD solo se registran las emisiones. Para
	 *            las modificaciones o anulaciones el tipo de operaci n es (X),
	 *            teniendo en este caso que especificar en el campo Tipo de
	 *            Operaci n que se registra el Tipo de Operaci n original.
	 * @return
	 */
	public static RespWSAladi execWSSicomrima(Apertura apertura, String codcon, String instr, String tipoOperacionAladi, String ifarecep,
			Date fecEmisONego, Date fecVencOPago, BigDecimal montoOper, String obs, Integer secNroreembolso) {
		if (tipoOperacionAladi.equals("E")) {
		} else if (tipoOperacionAladi.equals("N")) {
		} else if (tipoOperacionAladi.equals("X")) {
		} else {
			throw new AladiException("TIPO_OPERACION_CONVENIO_INCORRECTO", new Object[] { tipoOperacionAladi, apertura.getCveTipoApe(),
					apertura.getNroReembLiteral() });
		}

		String observaciones = obs;

		Double monto = null;
		if (montoOper != null)
			monto = montoOper.doubleValue();

		RespWSAladi respWSAladi = null;
		URL wsdlURL = genURLPort(Constants.FILE_NAME_WSDL_SICOMRIMA);
		log.info("En consulta WS: " + wsdlURL.getFile());		
		SicomRimaWs ss = new SicomRimaWs(wsdlURL, Constants.SERVICE_NAME_SICOMRIMA);
		SicomRimaWsSoapPort port = ss.getSicomRimaWsSoapPort();

		{
			SicomRimaWsExecute parameters = new SicomRimaWsExecute();

			parameters.setContrasena(ConfigurationServ.getParamsSystem().get("ALADI_WS_PASSWORD"));
			parameters.setLogin(ConfigurationServ.getParamsSystem().get("ALADI_WS_USER"));
			parameters.setCodcon(codcon);
			parameters.setNroreemb(apertura.getNroReembLiteral(true) + String.format("%04d", (secNroreembolso != null ? secNroreembolso : 0)));
			parameters.setInstr(instr);
			parameters.setTpooper(tipoOperacionAladi);
			parameters.setIfarecep(ifarecep);
			
			Calendar cfchemi = GregorianCalendar.getInstance();
			cfchemi.setTime(fecEmisONego);			
			LocalDate fecEmisLd = LocalDateTime.fromCalendarFields(cfchemi).toLocalDate();			
			parameters.setFchemi(fecEmisLd);
			
			Calendar cfchvenc = GregorianCalendar.getInstance();
			cfchvenc.setTime(fecVencOPago);			
			LocalDate fecvencLd = LocalDateTime.fromCalendarFields(cfchvenc).toLocalDate();			
			parameters.setFchvenc(fecvencLd);

			parameters.setMonto(monto);
			parameters.setObs(observaciones);

			log.info("Invocando WS SicomRimaWsSoapPort_SicomRimaWsSoapPort_Client para cod reembolso: " + apertura.getNroReembLiteral());
			log.info("====INICIO: XML REQUEST WS CONVENIO ALADI=======" + UtilsDate.stringFromDate(new Date(), Constants.FORMAT_DATE_TIME));
			log.info(Utils.objectToXML(parameters));
			log.info("====FIN: XML REQUEST WS CONVENIO ALADI====");

			SicomRimaWsExecuteResponse executeReturn = null;
			try {
				javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(new javax.net.ssl.HostnameVerifier() {
					public boolean verify(String hostname, javax.net.ssl.SSLSession sslSession) {
						if (hostname.equals("sicap.bcra.gov.ar")) {
							return true;
						}
						return true;
					}
				});
				
				((BindingProvider)port).getRequestContext().put("org.apache.cxf.http.no_io_exceptions", "true");			
				ClientAladiTLS.setupTLSWSClient(port);				
				executeReturn = port.execute(parameters);
			} catch (Exception e) {
				log.error("Error en llamada a WS " + e.getMessage(), e);
				throw new AladiException("ERROR_EN_LLAMADA_WS_CONV_ALADI", new Object[] { wsdlURL.getHost(), e.getMessage() });
			}
			SdtSICOMRIMA sdtSICOMRIMA = new SdtSICOMRIMA();
			sdtSICOMRIMA = executeReturn.getSicom();

			// preparamos la respuesta
			respWSAladi = new RespWSAladi();
			// log.info("recibido " + Utils.objectToXML(sdtSICOMRIMA));
			respWSAladi.setCode(sdtSICOMRIMA.getCodigoRpta());
			try {
				respWSAladi.setContentXML(XmlUtils.objectJAXBToString(executeReturn));
			} catch (Exception e1) {
				log.warn("Error al desparseo de mensaje recibido se intenta con Utils.objectToXML");
				respWSAladi.setContentXML(Utils.objectToXML(sdtSICOMRIMA));
			}

			try {
				respWSAladi.setFechaHoraReg(sdtSICOMRIMA.getFechaValor().toGregorianCalendar().getTime(), sdtSICOMRIMA.getHora());
			} catch (Exception e) {
			}

			log.info("SICOMRIMA: Resultado cod respuesta WS: " + respWSAladi.getCode() + " - " + respWSAladi.getDescripResp());
			log.info("====INICIO: XML respuesta WS CONVENIO ALADI=======");
			log.info(respWSAladi.getContentXML());
			log.info("=================FIN: XML respuesta WS CONVENIO ALADI=================");

			if (!respWSAladi.isSuccessMsg()) {
				throw new AladiException("ERROR_CONVENIO_ALADI", new Object[] { respWSAladi.getCode(), respWSAladi.getDescripResp() });
			}
		}

		return respWSAladi;
	}

	/**
	 * retorna el cuadro de estado de deuda por convenio, realiza la consulta a
	 * WS de consultad de saldos bilaterales y numerales, y posteriormente se
	 * calcula el saldo de pagos y cobros pendientes
	 * 
	 * @param fDesdeConsWS
	 *            fecha desde la cual se consulta a WS aladi generalmente es
	 *            desde el inicio del cuatrimestre
	 * @param fHastaConsWS
	 *            fecha hasta el fin de periodo a consulta dentro el
	 *            cuatrimestre, debe ser una fecha anterior a la de hoy ya que
	 *            los saldos en Aladi no son reales pues el saldo debe ser
	 *            complementado con las operaciones realizadas hoy
	 * @param fAlOpersSirAladi
	 *            fecha hasta la cual se calcula los saldos de pagos y cobros
	 *            pendientes
	 * @param entityManager
	 *            conexi n a base de datos
	 * @return lista de saldos por convenio
	 */
	public static List<SaldoConvenio> execWSasicapCsbn(Date fDesdeConsWS, Date fHastaConsWS, Date fAlOpersSirAladi, EntityManager entityManager) {

		URL wsdlURL = ClientAladiWSHandler.genURLPort(Constants.FILE_NAME_WSDL_ASICAPCSBN);
		log.info("En consulta WS execWSasicapCsbn: " + wsdlURL.getFile());
		List<SaldoConvenio> saldoConvenioList = new ArrayList<SaldoConvenio>();
		List<SdtSICAPCSBNSdtSICAPCSBNItem> item = new ArrayList<SdtSICAPCSBNSdtSICAPCSBNItem>();
		SicapCsbnWs service = null;
		SicapCsbnWsSoapPort port = null;
		try {
			javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(new javax.net.ssl.HostnameVerifier() {
				public boolean verify(String hostname, javax.net.ssl.SSLSession sslSession) {
					if (hostname.equals("sicap.bcra.gov.ar")) {
						return true;
					}
					return true;
				}
			});
			
			service = new SicapCsbnWs(wsdlURL, Constants.SERVICE_NAME_ASICAPCSBN);
			port = service.getSicapCsbnWsSoapPort();
			((BindingProvider)port).getRequestContext().put("org.apache.cxf.http.no_io_exceptions", "true");			
			ClientAladiTLS.setupTLSWSClient(port);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SystemInternalException("ERROR_CLIENTE_WS", new Object[] { Constants.FILE_NAME_WSDL_ASICAPCSBN, e.getMessage() },e);
		}
		{

			SicapCsbnWsExecute parameters = new SicapCsbnWsExecute();

			parameters.setContrasena(ConfigurationServ.getParamsSystem().get("ALADI_WS_PASSWORD"));
			parameters.setLogin(ConfigurationServ.getParamsSystem().get("ALADI_WS_USER"));
			
			Calendar cfdesde = GregorianCalendar.getInstance();
			cfdesde.setTime(fDesdeConsWS);			
			LocalDate fecdesdeLd = LocalDateTime.fromCalendarFields(cfdesde).toLocalDate();			
			parameters.setFechavalordesde(fecdesdeLd);

			Calendar cfhasta = GregorianCalendar.getInstance();
			cfhasta.setTime(fHastaConsWS);			
			LocalDate fechastaLd = LocalDateTime.fromCalendarFields(cfhasta).toLocalDate();			
			parameters.setFechavalorhasta(fechastaLd);
			
//			parameters.setFechavalordesde(UtilsDate.StrToXMLGregoCal(UtilsDate.stringFromDate(fDesdeConsWS, "yyyy-MM-dd"), "-"));
//			parameters.setFechavalorhasta(UtilsDate.StrToXMLGregoCal(UtilsDate.stringFromDate(fHastaConsWS, "yyyy-MM-dd"), "-"));
			SicapCsbnWsExecuteResponse result = null;
			log.info("Consulta iniciada para execWSasicapCsbn de " + UtilsDate.stringFromDate(fDesdeConsWS, Constants.FORMAT_DATE_DB) + " a "
					+ UtilsDate.stringFromDate(fHastaConsWS, Constants.FORMAT_DATE_DB));
			log.info("====INICIO: XML REQUEST WS CONVENIO ALADI=======" + UtilsDate.stringFromDate(new Date(), Constants.FORMAT_DATE_TIME));
			log.info(Utils.objectToXML(parameters));
			log.info("====FIN: XML REQUEST WS CONVENIO ALADI====");
			try {
				result = port.execute(parameters);
			} catch (Exception e) {
				throw new AladiException("ERROR_EN_LLAMADA_WS_CONV_ALADI", new Object[] { wsdlURL.getHost(), e.getMessage() });
			}

			SdtSICAPCSBN resp = new SdtSICAPCSBN();
			resp = result.getSicap();

			RespWSAladi respWSAladi = new RespWSAladi();
			respWSAladi.setCode(result.getSicap().getSdtSICAPCSBNSdtSICAPCSBNItem().get(0).getCodigoRpta());

			try {
				respWSAladi.setContentXML(XmlUtils.objectJAXBToString(result));
			} catch (Exception e1) {
				log.warn("Error al desparseo de mensaje recibido se intenta con Utils.objectToXML " + e1.getMessage());

			}
			log.info(respWSAladi.getContentXML());
			
			log.info("Resultado cod respuesta WS: " + respWSAladi.getCode() + " - " + respWSAladi.getDescripResp() + " con "
					+ result.getSicap().getSdtSICAPCSBNSdtSICAPCSBNItem().size() + " registros retornados");

			if (!respWSAladi.isSuccessMsg()) {
				throw new AladiException("ERROR_CONVENIO_ALADI", new Object[] { respWSAladi.getCode(), respWSAladi.getDescripResp() });
			}
			// para el calculo de pagos y cobros a la fecha es la fecha Hasta
			// mas un dia habil
			Date fechAl = ConsComunesNegocio.fecHabilAntesDespuesDe(fHastaConsWS, 1);
			item = resp.getSdtSICAPCSBNSdtSICAPCSBNItem();
			if (item.size() > 0) {
				for (SdtSICAPCSBNSdtSICAPCSBNItem sdtSICAPCSBNSdtSICAPCSBNItem : item) {
					PaisBean paisBean = new PaisBean();
					paisBean.setEntityManager(entityManager);

					SaldoConvenio saldoConvenio = new SaldoConvenio();
					saldoConvenio.setCodPais(sdtSICAPCSBNSdtSICAPCSBNItem.getConvenio());
					saldoConvenio.setNomPais(paisBean.findById(sdtSICAPCSBNSdtSICAPCSBNItem.getConvenio(), false).getNomPais());
					saldoConvenio.setDebitoA(BigDecimal.valueOf(sdtSICAPCSBNSdtSICAPCSBNItem.getSaldoA()));
					saldoConvenio.setMontoCuentaA(BigDecimal.valueOf(sdtSICAPCSBNSdtSICAPCSBNItem.getNumeralA()));
					saldoConvenio.setDebitoB(BigDecimal.valueOf(sdtSICAPCSBNSdtSICAPCSBNItem.getSaldoB()));
					saldoConvenio.setMontoCuentaB(BigDecimal.valueOf(sdtSICAPCSBNSdtSICAPCSBNItem.getNumeralB()));

					try {
						saldoConvenio.setSaldoDiaCtaA(paisBean.montoPagosFecha(sdtSICAPCSBNSdtSICAPCSBNItem.getConvenio(), fechAl));
					} catch (Exception e) {
						throw new AladiException("ERROR_CONSULTA_A_BASE_DE_DATOS", new Object[] { "montoPagosFecha", e.getMessage() });
					}

					saldoConvenio.setSaldoDiaCtaB(BigDecimal.ZERO);

					try {
						// calculamos los saldos pendientes de
						saldoConvenio.setPagosPendientes(paisBean.montoPagosPendientes(sdtSICAPCSBNSdtSICAPCSBNItem.getConvenio(), fAlOpersSirAladi));
					} catch (Exception e) {
						log.error("Error al calcular saldo pendiente montoPagosPendientes: " + e.getMessage(), e);
						throw new AladiException("ERROR_CONSULTA_A_BASE_DE_DATOS", new Object[] { "montoPagosPendientes", e.getMessage() });
					}
					try {
						saldoConvenio
								.setCobrosPendientes(paisBean.montoCobrosPendientes(sdtSICAPCSBNSdtSICAPCSBNItem.getConvenio(), fAlOpersSirAladi));
					} catch (Exception e) {
						log.error("Error al calcular saldo pendiente montoCobrosPendientes: " + e.getMessage(), e);
						throw new AladiException("ERROR_CONSULTA_A_BASE_DE_DATOS", new Object[] { "montoCobrosPendientes", e.getMessage() });
					}

					saldoConvenioList.add(saldoConvenio);
				}
			} else {
				throw new AladiException("ERROR_CONVENIO_ALADI", new Object[] { respWSAladi.getCode(), respWSAladi.getDescripResp() });
			}
		}
		return saldoConvenioList;
	}

	/**
	 * Retorna la lista de entidades registradas en el convenio aladi a la fecha
	 * segun estado
	 * 
	 * @param estadoInstitucion
	 *            permite seleccionar el estado de la IFA que desea consultarse,
	 *            puede ser Registrado, Autorizado,Desautorizado, Fusionado o
	 *            Todos; aceptando el sistema los caracteres en may sculas R, A,
	 *            D, F o T respectivamente.
	 * @param entityManager
	 * @return Lista de instituciones
	 */
	public static List<Institucion> execWSAifacif(String estadoInstitucion, EntityManager entityManager) {

		URL wsdlURL = ClientAladiWSHandler.genURLPort(Constants.FILE_NAME_WSDL_AIFACIF);
		log.info("En consulta WS: " + wsdlURL.getFile());
		List<Institucion> institucionList = new ArrayList<Institucion>();
		List<SdtIFACIFSdtIFACIFItem> item = new ArrayList<SdtIFACIFSdtIFACIFItem>();
		IfaCifWs service = null;
		IfaCifWsSoapPort port = null;
		try {
			javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(new javax.net.ssl.HostnameVerifier() {
				public boolean verify(String hostname, javax.net.ssl.SSLSession sslSession) {
					if (hostname.equals("sicap.bcra.gov.ar")) {
						return true;
					}
					return true;
				}
			});
			
			service = new IfaCifWs(wsdlURL, Constants.SERVICE_NAME_IFACIF);
			port = service.getIfaCifWsSoapPort();
			((BindingProvider)port).getRequestContext().put("org.apache.cxf.http.no_io_exceptions", "true");			
			ClientAladiTLS.setupTLSWSClient(port);			
		} catch (Exception e) {
			log.error("Error en llamada a WS ", e);
			throw new SystemInternalException("ERROR_CLIENTE_WS", new Object[] { Constants.FILE_NAME_WSDL_AIFACIF, e.getMessage() });
		}
		{

			IfaCifWsExecute parameters = new IfaCifWsExecute();

			parameters.setContrasena(ConfigurationServ.getParamsSystem().get("ALADI_WS_PASSWORD"));
			parameters.setLogin(ConfigurationServ.getParamsSystem().get("ALADI_WS_USER"));
			parameters.setConvenio("T");
			parameters.setEstado(estadoInstitucion);
			// parameters.setFecini(UtilsDate.StrToXMLGregoCal(UtilsDate.stringFromDate(fechaDesde,
			// "yyyy-MM-dd"), "-"));
			// parameters.setFecfin(UtilsDate.StrToXMLGregoCal(UtilsDate.stringFromDate(fechaHasta,
			// "yyyy-MM-dd"), "-"));
			// parameters.setRanifadesde("0000");
			// parameters.setRanifahasta("9999");

			IfaCifWsExecuteResponse result = null;
			log.info("Consulta iniciada para execWSAifacif ");
			log.info("====INICIO: XML REQUEST WS CONVENIO ALADI=======" + UtilsDate.stringFromDate(new Date(), Constants.FORMAT_DATE_TIME));
			log.info(Utils.objectToXML(parameters));
			log.info("====FIN: XML REQUEST WS CONVENIO ALADI====");
			try {
				result = port.execute(parameters);
			} catch (Exception e) {
				log.error("ERROR_EN_LLAMADA_WS_CONV_ALADI " + e.getMessage(), e);
				throw new AladiException("ERROR_EN_LLAMADA_WS_CONV_ALADI", new Object[] { wsdlURL.getHost(), e.getMessage() });
			}

			SdtIFACIF resp = new SdtIFACIF();
			resp = result.getIfa();

			RespWSAladi respWSAladi = new RespWSAladi();
			respWSAladi.setCode(result.getIfa().getSdtIFACIFSdtIFACIFItem().get(0).getCodRpta());
			// respWSAladi.setContentXML(Utils.objectToXML(resp));
			/*
			 * log.debug("====INICIO: XML respuesta WS CONVENIO ALADI=======");
			 * log.debug(respWSAladi.getContentXML()); log.debug(
			 * "=================FIN: XML respuesta WS CONVENIO ALADI================="
			 * );
			 */

			// MessagesRespAladi.main(null);

			log.info("Resultado cod respuesta WS: " + respWSAladi.getCode() + " - " + respWSAladi.getDescripResp() + " con "
					+ result.getIfa().getSdtIFACIFSdtIFACIFItem().size() + " registros retornados");

			if (!respWSAladi.isSuccessMsg()) {
				throw new AladiException("ERROR_CONVENIO_ALADI", new Object[] { respWSAladi.getCode(), respWSAladi.getDescripResp() });
			}

			item = resp.getSdtIFACIFSdtIFACIFItem();
			if (item.size() > 0) {
				for (SdtIFACIFSdtIFACIFItem sdtIFACIFSdtIFACIFItem : item) {
					// agregamos codigos inexistente para evitar un error
					// java.lang.StringIndexOutOfBoundsException que no
					// permitiria
					// retornar una repuesta

					Institucion institucion = new Institucion();
					institucion.setCodInst(sdtIFACIFSdtIFACIFItem.getCodInsFin());

					PaisBean paisBean = new PaisBean();
					paisBean.setEntityManager(entityManager);
					Pais pais = new Pais();
					pais.setCodPais(sdtIFACIFSdtIFACIFItem.getConvenio());
					institucion.setPais(pais);
					institucion.setNomInst(sdtIFACIFSdtIFACIFItem.getRazonSocial());
					institucion.setNomPlaza(sdtIFACIFSdtIFACIFItem.getPlaza());

					String estado = null;
					if (sdtIFACIFSdtIFACIFItem.getEstado().trim().equalsIgnoreCase("A")) {
						estado = "0";
					} else if (sdtIFACIFSdtIFACIFItem.getEstado().trim().equalsIgnoreCase("F")) {
						estado = "F";
					} else {
						estado = "1";
					}
					institucion.setCveEstado(estado);
					institucion.setTitular(sdtIFACIFSdtIFACIFItem.getInstFinTitular());
					try {
						institucion.setFechaApe(sdtIFACIFSdtIFACIFItem.getFechaEstado().toGregorianCalendar().getTime());
					} catch (Exception e) {
					}
					// no existe informaci n al momento sobre si el banco es
					// banco central o no
					institucion.setCveTipoInst("N");
					institucionList.add(institucion);
				}
			} else {
				throw new AladiException("El servicio web produjo una respuesta [" + respWSAladi.getCode() + " - " + respWSAladi.getDescripResp()
						+ "] sin datos a mostrar");
			}
		}
		return institucionList;
	}

	public static List<TPagoImp> sicapCcbResponseToTPagoImp(SicapCcbWsExecuteResponse result) {
		List<TPagoImp> tPagoImpList = new ArrayList<TPagoImp>();
		Integer i = 1;
		for (SdtSICAPCCBSdtSICAPCCBItem sdtSICAPCCBSdtSICAPCCBItem : result.getSdtsicap().getSdtSICAPCCBSdtSICAPCCBItem()) {
			if (BigDecimal.valueOf(sdtSICAPCCBSdtSICAPCCBItem.getMonto()).compareTo(BigDecimal.ZERO) == 0) {
				// si el monto es cero no se considera
				continue;
			}
			sdtSICAPCCBSdtSICAPCCBItem.setNroReembolso(sdtSICAPCCBSdtSICAPCCBItem.getNroReembolso().concat("                    "));
			TPagoImp tPagoImp = new TPagoImp();
			tPagoImp.setNroReg(i++);
			tPagoImp.setNroDebito(sdtSICAPCCBSdtSICAPCCBItem.getNroDebito());
			tPagoImp.setCodInst(sdtSICAPCCBSdtSICAPCCBItem.getNroReembolso().substring(0, 4));
			tPagoImp.setCodId(sdtSICAPCCBSdtSICAPCCBItem.getNroReembolso().substring(4, 5));
			tPagoImp.setAnio(sdtSICAPCCBSdtSICAPCCBItem.getNroReembolso().substring(5, 9));
			tPagoImp.setSecuencia(sdtSICAPCCBSdtSICAPCCBItem.getNroReembolso().substring(9, 15));
			Integer valor = 0;
			try {
				valor = Integer.valueOf(sdtSICAPCCBSdtSICAPCCBItem.getNroReembolso().substring(15, 16));
			} catch (Exception e) {
				valor = 0;
			}
			tPagoImp.setDav(valor);
			tPagoImp.setCorr(sdtSICAPCCBSdtSICAPCCBItem.getNroReembolso().substring(16, 20).trim());
			tPagoImp.setCodInstrumento(sdtSICAPCCBSdtSICAPCCBItem.getInstrumento().trim());
			try {
				// Fecha de Cargo, fecha valor o de registro
				Date fecha1 = null;
				if (sdtSICAPCCBSdtSICAPCCBItem.getFechaCargo() != null) {
					fecha1 = sdtSICAPCCBSdtSICAPCCBItem.getFechaCargo().toDate();
					tPagoImp.setFecha1(fecha1);
				} else {
					tPagoImp.setFecha1(new Date());
				}

			} catch (Exception e) {
				log.error("Error al parsear tPagoImp.setFecha1 " + e.getMessage());
			}

			tPagoImp.setCodPais(sdtSICAPCCBSdtSICAPCCBItem.getConvenio());
			tPagoImp.setCodInstRecep(sdtSICAPCCBSdtSICAPCCBItem.getInstPagadora());
			try {
				// Fecha de Emisi n, fecha para la emisi n de la orden de pago.
				if (sdtSICAPCCBSdtSICAPCCBItem.getFecha() != null) {
					tPagoImp.setFecha2(sdtSICAPCCBSdtSICAPCCBItem.getFecha().toDate());
				} else {
					tPagoImp.setFecha2(new Date());
				}
			} catch (Exception e) {
				log.error("Error al parsear tPagoImp.setFecha2 " + e.getMessage());
			}
			tPagoImp.setMontoMo(BigDecimal.valueOf(sdtSICAPCCBSdtSICAPCCBItem.getMonto()));
			tPagoImp.setObs(sdtSICAPCCBSdtSICAPCCBItem.getObservaciones());

			tPagoImpList.add(tPagoImp);
		}
		return tPagoImpList;
	}
	public static void main(String[] args) {
		Date fecEmisONego = UtilsDate.dateFromString("23/12/2017", "dd/MM/yyyy");
		Calendar cfchvenc = GregorianCalendar.getInstance();
		cfchvenc.setTime(fecEmisONego);
		LocalDate cfchvencLd = LocalDateTime.fromCalendarFields(cfchvenc).toLocalDate();
		log.info("Current DateTime: " + cfchvencLd);
		
		//ISOChronology
	}
}


























