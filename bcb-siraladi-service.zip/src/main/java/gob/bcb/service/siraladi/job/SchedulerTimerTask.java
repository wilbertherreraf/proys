package gob.bcb.service.siraladi.job;

import java.util.TimerTask;

/**
 * A TimeTask for a Runnable object
 *
 */
/**
 * @author wherrera
 *
 */
public class SchedulerTimerTask extends TimerTask {
    private final Runnable task;

    public SchedulerTimerTask(Runnable task) {
        this.task = task;
    }

    public void run() {
        this.task.run();                         
    }
}
