package gob.bcb.service.siraladi;

import gob.bcb.bpm.siraladi.service.ConfigurationServ;
import gob.bcb.bpm.siraladi.utils.Constants;
import gob.bcb.lavado.client.HandlerGeneratorLauCli;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.jms.JMSException;

import org.apache.log4j.Logger;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.util.StringUtils;

public class Server {
	private static Logger log = Logger.getLogger(Server.class);
	
	public void stop(){
		
	}
	
	public static void main(String[] args) {
		log.info("Iniciando servicio ...");
		InputStream in = ClassLoader.getSystemResourceAsStream("service.properties");
		Properties properties = new Properties();
		try {
			properties.load(in);
			in.close();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}

		String pathHome = properties.getProperty("path.home");
		ConfigurationServ.setServiceName(properties.getProperty("service.name"));
		if (pathHome == null) {
			throw new RuntimeException("Par metro [path.home] requerido no est  definido");
		}
		File f = new File(pathHome,"colita-config.xml");
		String fileColitaConfig = StringUtils.cleanPath(f.getAbsolutePath());
		f = new File(pathHome);
		pathHome = StringUtils.cleanPath(f.getAbsolutePath());
		log.info("pathHome: " + pathHome);
		
		FileSystemXmlApplicationContext appContext = new FileSystemXmlApplicationContext("file:///" + fileColitaConfig);
		ServerListener publisher = (ServerListener)appContext.getBean("ServiceListener");
		try {
			publisher.setupConsumer();
			log.info("La configuraci n termin  de cargar exit samente. Servicio en espera de mensajes ...");			
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}

	}

}
