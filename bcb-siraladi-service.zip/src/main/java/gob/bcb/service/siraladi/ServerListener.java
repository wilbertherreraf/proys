package gob.bcb.service.siraladi;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.Properties;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.springframework.jms.listener.SessionAwareMessageListener;
import org.springframework.util.StringUtils;

import gob.bcb.bpm.siraladi.dao.ParamsBean;
import gob.bcb.bpm.siraladi.exceptions.WrappedException;
import gob.bcb.bpm.siraladi.jpa.Param;
import gob.bcb.bpm.siraladi.msgmail.MsgLogic;
import gob.bcb.bpm.siraladi.service.ConfigurationServ;
import gob.bcb.bpm.siraladi.service.DispatcherSirAladi;
import gob.bcb.bpm.siraladi.service.ResponseContext;
import gob.bcb.bpm.siraladi.utils.Constants;
import gob.bcb.bpm.siraladi.utils.StatusCode;
import gob.bcb.bpm.siraladi.utils.Utils;
import gob.bcb.bpm.siraladi.utils.UtilsDate;
import gob.bcb.bpm.siraladi.utils.UtilsPersist;
import gob.bcb.core.jms.BcbRequest;
import gob.bcb.core.jms.BcbResponse;
import gob.bcb.service.siraladi.job.GenerateTasks;
import gob.bcb.service.siraladi.job.SchedulerSir;

//import dk.itst.oiosaml.configuration.SAMLConfiguration;

/**
 * @author wilherrera Wilbert Herrera Flores Banco Central de Bolivia
 *         Departamento de Desarrollo
 */
public class ServerListener implements SessionAwareMessageListener {
	private static final Log log = LogFactory.getLog(ServerListener.class);
	//private String brokerUrl = null;
	// private String brokerUrl = "tcp://10.2.11.91:61616";
	private final static String requestQueue = "GOB.BCB.SERVICE.SIRALADI";

	private static boolean initialized = false;
	private static EntityManagerFactory entityMgrFactory;
	//private static EntityManagerFactory entityMgrFactoryPortia;	
	//private static String pathFilecommon;
	private Runnable periodicCheckDebitosTask;
	private long checkDebitosDelay = 1000L * 50;
	private static SchedulerSir schedulerSir ;
	
	private Runnable periodicCheckInstitucionesTask;
	String respuestaFATAL = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" standalone=\"no\"?><responses count=\"1\" "
			+ "date=\"mar 02 ago, 2011 - 09:02:57.041 BOT\" serviceId=\"aladi\"><clientId>aladi</clientId><request>"
			+ "<sequence>1</sequence><count>1</count><date>mar 02 ago, 2011 - 09:02:55.290 BOT</date>"
			+ "<receivedon>mar 02 ago, 2011 - 09:02:57.025 BOT</receivedon></request>"
			+ "<response name=\"status\" sequence=\"1\" type=\"Custom\"><value name=\"status\"><![CDATA[<gob.bcb.bpm.siraladi.pojo.StatusResponse>"
			+ "  <codTipoOperacion>ERROR</codTipoOperacion>" + "  <statusCode>AladiException</statusCode>"
			+ "  <descrip>ERROR INESPERADO!!! HUBO UN ERROR AL PROCESAR EL MENSAJE, FAVOR COMUNICAR AL ADMINISTRADOR DEL SISTEMA</descrip>"
			+ "  <codResponse>" + Utils.generateUUID() + "</codResponse>"
			+ "</gob.bcb.bpm.siraladi.pojo.StatusResponse>]]></value></response></responses>";


	public final void init() {
		if (!initialized) {
			log.info("Iniciando Dispatcher");

			/*********************************************/
			InputStream in = ClassLoader.getSystemResourceAsStream("service.properties");
			Properties properties = new Properties();
			try {
				properties.load(in);
				in.close();
			} catch (IOException e) {
				log.error("Error al cargar propiedades de servicio", e);
				throw new RuntimeException(e);
			}

			String pathHome = properties.getProperty("path.home");
			File f = new File(pathHome,"colita-config.xml");
			pathHome = StringUtils.cleanPath(f.getAbsolutePath());
			f = new File(pathHome);
			pathHome = StringUtils.cleanPath(f.getParent());
			log.info("Home de configuracion del sistema: " + pathHome);
			ConfigurationServ.setServiceName(properties.getProperty("service.name"));
			if (pathHome == null) {
				throw new RuntimeException("Parametro [path.home] requerido no esta definido");
			}
			/*********************************************/
			ConfigurationServ.setHomeProperty(pathHome);
			ConfigurationServ.init(pathHome);

			try {
				log.info("Inicializando objetos de persistencia a la base para servicio " + ConfigurationServ.getServiceName());
				entityMgrFactory = UtilsPersist.createEntityManagerFactory(ConfigurationServ.getServiceName());
				//entityMgrFactoryPortia= UtilsPersist.createEntityManagerFactory("portia");
				
				
//				pathFilecommon = (String) ConfigurationServ.getConfigProperty(
//						"repositorio/servicios/servicio[@name='ID-SERVICENAME']/pathFilecommon".replaceFirst("ID-SERVICENAME",
//								ConfigurationServ.getServiceName()), "string");
				// recuperamos el path del archivo comun de configuracion
//				SAMLConfiguration.setPathFileCommon(pathFilecommon, false);
//				SAMLConfiguration.setNameApplication(ConfigurationServ.getServiceName());
				log.info("Instancia factory de persistencia para conexiones a la base de datos creada");
			} catch (Exception e) {
				log.error("Error :: " + e.getMessage(), e);
				throw new RuntimeException(e);
			}
		
			initialized = true;
			log.info("Iniciando Dispatcher ... hecho");
		}
	}
	
	public String execServicioToString(BcbRequest bcbRequest) {
		String result = respuestaFATAL;
		log.info("=======ooooOO00inicio servicio00OOooo======= " + UtilsDate.stringFromDate(new Date(), Constants.FORMAT_DATE_TIME));
		DispatcherSirAladi dispatcherSirAladi = null;
		try {
			ResponseContext responseContext = new ResponseContext(bcbRequest);
			try {
				// whf cerrar conexiones a base y otros
				EntityManager entityManager = entityMgrFactory.createEntityManager();
				//EntityManager entityManagerPortia = entityMgrFactoryPortia.createEntityManager();
				
				dispatcherSirAladi = new DispatcherSirAladi(entityManager);
				dispatcherSirAladi.doService(bcbRequest, responseContext);

				responseContext.getBcbResponse().updateMsgsistemaresp(null, null, null);
				result = responseContext.objectBcbRequestToXML();
			} catch (Throwable t) {
				// String consent = t instanceof WrappedException ?
				// t.getCause().getMessage() : t.getMessage();
				t.printStackTrace();
				String consent = t instanceof WrappedException ? t.getCause().getMessage() : t.getMessage();
				log.error("ERROR INESPERADO: " + UtilsDate.stringFromDate(new Date(), Constants.FORMAT_DATE_TIME) + " :: " + consent);
				if (responseContext.isInitialized()) {
					responseContext.updateReponse(StatusCode.RUNTIME_EXCEPTION, consent);
					try {
						result = responseContext.getBcbResponse().stringFromObjectJAXB(responseContext.getBcbResponse().getMsgBcbresp());
					} catch (Exception e) {
						result = respuestaFATAL;
						log.error(e.getMessage());
					}
				} else {
					// error FATAL !!!! se genera un mensaje de error
					BcbResponse respuesta = ResponseContext.errorRequest(StatusCode.UNKNOWN_EXCEPTION, "ERROR INESPERADO: " + consent
							+ ". Comunique a sistemas");
					try {
						result = responseContext.getBcbResponse().stringFromObjectJAXB(respuesta.getMsgBcbresp());
					} catch (Exception e) {
						result = respuestaFATAL;
						log.error(e.getMessage());
					}
				}
				t.printStackTrace();
			}
		} finally {
			if (result == null) {
				// OPSSS!!!! FATALITY
				result = respuestaFATAL;
				log.error("&&&&&&&&&&&&&&&&&&&&ERROR INESPERADO&&&&&&&&&&&&&&&&&&&&&&&&&&&"
						+ UtilsDate.stringFromDate(new Date(), Constants.FORMAT_DATE_TIME));
				return result;
			}
			dispatcherSirAladi.closeEntityManager();			
		}
		log.info("=======ooooOO00Fin servicio00OOooo======= " + UtilsDate.stringFromDate(new Date(), Constants.FORMAT_DATE_TIME));
		return result;
	}

	public String execServicio(Message mensaje) {
		BcbRequest request = null;
		String respuesta = "";
		try {
			request = BcbRequest.Factory.createRequest(mensaje);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			respuesta = e.getMessage();
			return respuesta;
		}
		// /////////////////////////////////////////////
		try {
			// ##############INICIO:EJECUTAR SERVICIO DE
			// NEGOCIO#######################
			// ConsumerMsg consumidorMsg = new ConsumerMsg();
			// respuesta = consumidorMsg.execServicioToString(request);
			respuesta = execServicioToString(request);
			// ##############FIN:EJECUTAR SERVICIO DE
			// NEGOCIO##########################
		} catch (Exception e) {
			e.printStackTrace();
			log.error("==>DESCRIPCION EXCEPCION: ", e);
			respuesta = e.getMessage();
		}
		// ////////////////////////////////////////

		return respuesta;
	}

	public void setupConsumer() throws JMSException {
		// esta linea es para inicializar y verificar los parametros iniciales
		init();
		EntityManager entityManager = entityMgrFactory.createEntityManager();
		// ////////////////////////////////////////////
		entityManager.getTransaction().begin();
		ParamsBean paramsBean= new ParamsBean();
		paramsBean.setEntityManager(entityManager);
		Param param = paramsBean.findByCodigo("ip-correo");
		log.info("param " + param.getValparam());
		
		//Param param = entityManager.find(Param.class, "ip-correo");
	
		String ipCorreo = param.getValparam().trim();
		if (ipCorreo != null){
			String[] configMails = ipCorreo.split(" ");
			MsgLogic.IP_SMTP = configMails[0]; 
			try{
				MsgLogic.PORT_SMTP = Integer.valueOf(configMails[1]);
			}catch (Exception e) {
				MsgLogic.PORT_SMTP = 25;
			}
			log.info("Configuracion de SMTP " + MsgLogic.PORT_SMTP + " puerto"  + MsgLogic.PORT_SMTP + " hecho...");
		}
		param = paramsBean.findByCodigo("usuarioTask");		
		//param = entityManager.find(Param.class, "usuarioTask");		
		ConfigurationServ.setParamsSystem("usuarioTask", param.getValparam().trim());
		
		param = paramsBean.findByCodigo("cod_bolivia");
		//param = entityManager.find(Param.class, "cod_bolivia");
		ConfigurationServ.setParamsSystem("cod_bolivia", param.getValparam().trim());
		
		param = paramsBean.findByCodigo("BCB");
		//param = entityManager.find(Param.class, "BCB");		
		ConfigurationServ.setParamsSystem("BCB", param.getValparam().trim());
		
		param = paramsBean.findByCodigo("fechaCorte");
		//param = entityManager.find(Param.class, "fechaCorte");		
		ConfigurationServ.setParamsSystem(param.getNomparam().trim(), param.getValparam().trim());
		
		startScheduler(entityManager);
		// ////////////////////////////////////////////
		log.info("%~~~~~~~~aaaaaaantes~~~~~~~~%");		
		entityManager.getTransaction().commit();		
		entityManager.close();
		log.info("%~~~~~~~~" + requestQueue + " INICIADA A ESPERA DE SOLICITUDES DE MENSAJE~~~~~~~~%");
	}

	
	
	public void onMessage(Message message, Session session) throws JMSException {
		String resp = null;
		init();
		log.info("===========INICIO MENSAJE RECIBIDO===========");
		try {
			log.info(((TextMessage) message).getText());
		} catch (JMSException e) {
			e.printStackTrace();
			resp = "Error al recibir mensaje " + e.getMessage();
		}
		log.info("===========FIN MENSAJE RECIBIDO===========");

		try {
			if (resp == null)
				resp = execServicio(message);

			MessageProducer sender = session.createProducer(message.getJMSReplyTo());
			
			TextMessage response = session.createTextMessage();
			if (message instanceof TextMessage) {
				response.setJMSCorrelationID(message.getJMSMessageID());
				response.setText(resp);				
				response.setJMSCorrelationID(message.getJMSCorrelationID());
			}

			sender.send(response);
			
			log.info("@@@@@@@@@@@@INICIO MENSAJE ENVIADO@@@@@@@@@@@@");
			log.info(resp);
			log.info("@@@@@@@@@@@@FIN MENSAJE ENVIADO@@@@@@@@@@@@");
		} catch (JMSException e) {
			e.printStackTrace();
			log.error("ERROR AL RECIBIR MENSAJE " + e.getMessage(), e);
			TextMessage response;
			MessageProducer sender = session.createProducer(message.getJMSReplyTo());			
			try {
				response = session.createTextMessage();

				if (message instanceof TextMessage) {
					response.setJMSCorrelationID(message.getJMSMessageID());
					response.setText("ERROR AL RECIBIR MENSAJE " + e.getMessage());
					response.setJMSCorrelationID(message.getJMSCorrelationID());
				}
				sender.send(response);
			} catch (JMSException e1) {
				e1.printStackTrace();
				log.error("ESTO ES HORRRIBLE ERROR FATAL!!!!!: no se pudo enviar mensaje de respuesta " + e1.getMessage(), e1);
			}
		} 
	}
	
	public static void startScheduler(EntityManager entityManager){
		schedulerSir = new SchedulerSir();
		try {
			schedulerSir.run(entityManager);
		} catch (Exception e) {
			log.error("Error en schedulerSir " + e.getMessage(), e);
			throw new RuntimeException(e);
		}
	}
	public static void stopScheduler(){
		log.info("stopScheduler ...");		
		final String prefJob = "job_";		
		JobDetail jobDebitosAuto = JobBuilder.newJob(GenerateTasks.class).withIdentity(prefJob + gob.bcb.bpm.siraladi.utils.Constants.TIPO_OPERACION_AL0308, "group1").build();
		JobDetail jobInstAuto = JobBuilder.newJob(GenerateTasks.class).withIdentity(prefJob + gob.bcb.bpm.siraladi.utils.Constants.TIPO_OPERACION_AL0603, "group1").build();		
	
		try {
			schedulerSir.getScheduler().interrupt(jobDebitosAuto.getKey());
			schedulerSir.getScheduler().interrupt(jobInstAuto.getKey());			
		} catch (Exception e) {
			log.error("Ocurrio un error al interrumpir JOb " + e.getMessage(), e);
		}
		try {
			schedulerSir.getScheduler().shutdown();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.error("Ocurrio un error al shutdown JObs " + e.getMessage(), e);
		}
		log.info("Jobs interrumpidos ...");
		
	}
	
	public static EntityManagerFactory getEntityMgrFactory() {
		return entityMgrFactory;
	}	

}
