package gob.bcb.service.siraladi.job;

import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.log4j.Logger;

/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public final class Scheduler {
	private static Logger log = Logger.getLogger(Scheduler.class);
	public static final Timer CLOCK_DAEMON = new Timer("SirAladi Scheduler", true);
	private static final HashMap<Runnable, TimerTask> TIMER_TASKS = new HashMap<Runnable, TimerTask>();

	private Scheduler() {
	}

	public static synchronized void executePeriodically(final Runnable task, long delay, long period) {
		TimerTask timerTask = new SchedulerTimerTask(task);
		CLOCK_DAEMON.scheduleAtFixedRate(timerTask, delay, period);
		TIMER_TASKS.put(task, timerTask);
		log.info("Configurado tarea periodica Delay: " + delay + ", period: " + period);
	}

	public static synchronized void cancel(Runnable task) {
		log.info("Cancelando tarea " + task.getClass().getName());
		TimerTask ticket = TIMER_TASKS.remove(task);
		if (ticket != null) {
			ticket.cancel();
			CLOCK_DAEMON.purge();// remove cancelled TimerTasks
		}
	}

	public static void executeAfterDelay(final Runnable task, long redeliveryDelay) {
		TimerTask timerTask = new SchedulerTimerTask(task);
		CLOCK_DAEMON.schedule(timerTask, redeliveryDelay);
	}

	public static void shutdown() {
		log.info("shutdown Scheluder");
		CLOCK_DAEMON.cancel();
	}

}
