package gob.bcb.service.siraladi;

import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.Registro;
import gob.bcb.bpm.siraladi.pojo.OperacionAladi;
import gob.bcb.bpm.siraladi.pojo.StatusResponse;
import gob.bcb.bpm.siraladi.utils.Utils;
import gob.bcb.core.jms.BcbResponse;
import gob.bcb.core.jms.DescripcionParametro;
import gob.bcb.siraladi.xml.operaciones.Aladirequesttipo01Type;
import gob.bcb.siraladi.xml.operaciones.ObjectFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.jms.Connection;
import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.xml.bind.JAXBElement;

import org.apache.activemq.ActiveMQConnectionFactory;

/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public class ClientTest implements MessageListener {

	private String brokerUrl = "tcp://localhost:61616";
	//private String brokerUrl = "tcp://112.2.11.13:61616";	
	private String requestQueue = "GOB.BCB.SERVICE.SIRALADI";

	Connection connection;
	private Session session;
	private MessageProducer producer;
	private MessageConsumer consumer;

	private Destination tempDest;
	
	public void start() throws JMSException {
		ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory(brokerUrl);
		connection = connectionFactory.createConnection();
		connection.start();
		session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
		Destination adminQueue = session.createQueue(requestQueue);

		producer = session.createProducer(adminQueue); //connection.begintransaction
		producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
		// producer.setTimeToLive(10000);

		tempDest = session.createTemporaryQueue();
		consumer = session.createConsumer(tempDest);

		consumer.setMessageListener(this);
	}

	public void stop() throws JMSException {
		producer.close();
		consumer.close();
		session.close();
		connection.close();
	}

	public void request(String request) throws JMSException {
		System.out.println("CONSULTA INICIADA1: ");
		try {
			request = Utils.readFileAsString("request02.xml");
		} catch (IOException e) {
			e.printStackTrace();
		}
		String mensajeSAML= "";
		try {
			mensajeSAML = Utils.readFileAsString("mensajeSAML.xml");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		

		TextMessage txtMessage = session.createTextMessage();
		txtMessage.setText(request);

		txtMessage.setStringProperty("recipient", "servicioBpmSirAladi");
		txtMessage.setStringProperty("responder", "responder");
		txtMessage.setStringProperty("IP_ORIGEN", "IP_ORIGEN");
		txtMessage.setStringProperty("MessageSAML", mensajeSAML);
		txtMessage.setJMSReplyTo(tempDest);

		String correlationId = UUID.randomUUID().toString();
		txtMessage.setJMSCorrelationID(correlationId);
		this.producer.send(txtMessage);
	}

	
	public void onMessage(Message message) {
		System.out.println("CLIENTE MENSAJE RECIBIDO: ");
		String xml = null;
		BcbResponse respuestaResponse = null;

		try {
			xml = ((TextMessage) message).getText();
			System.out.println(xml);
		} catch (JMSException e) {
			e.printStackTrace();
		}
/*
		Map<String, LinkedHashMap<String, Object>> mapa = respuestaResponse.getResult();
		StatusResponse status = (StatusResponse) mapa.get("status").get("status");
		System.out.println("========" + status.getCodResponse());
		Apertura apertura = (Apertura) mapa.get("apertura").get("apertura");
		System.out.println("========" + apertura.getNroMov() + " " + apertura.getIdentificador().getCodId());
		
		 * Registro registro = (Registro) mapa.get("registro").get("registro"); System.out.println("========" + registro.getNroMov());
		 */
		System.out.println("==========================FIN MENSAJE RECIBIDO==========================");
	}

	public static void main(String[] args) throws Exception {

		ClientTest client = new ClientTest();

		client.start();
		client.request("REQUEST-");
		Thread.sleep(20000);
		client.stop();

	}
}
