package gob.bcb.service.siraladi.job;

import gob.bcb.bpm.siraladi.service.ConfigurationServ;
import gob.bcb.bpm.siraladi.service.DispatcherSirAladi;
import gob.bcb.bpm.siraladi.service.ResponseContext;
import gob.bcb.bpm.siraladi.utils.Constants;
import gob.bcb.bpm.siraladi.utils.Utils;
import gob.bcb.bpm.siraladi.utils.UtilsDate;
import gob.bcb.core.jms.BcbRequest;
import gob.bcb.service.siraladi.ServerListener;
import gob.bcb.siraladi.xml.Contenidotype;
import gob.bcb.siraladi.xml.operaciones.Aladirequesttipo02Type;
import gob.bcb.siraladi.xml.operaciones.ObjectFactory;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.persistence.EntityManager;
import javax.xml.bind.JAXBElement;

import org.apache.log4j.Logger;

import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobKey;

import java.io.*;
import java.net.*;
import java.util.*;

public final class GenerateTasks implements Job {
	private static Logger log = Logger.getLogger(GenerateTasks.class);

	public static final String NAME_TASK = "name_task";
	public static final String TIPO_OPERACION = "tipo_operacion";

	public GenerateTasks() {
		log.info("Objeto GenerateTasks creado ...");
	}

	
	public void execute(JobExecutionContext context) throws JobExecutionException {
		JobDataMap data = context.getJobDetail().getJobDataMap();
		JobKey jobKey = context.getJobDetail().getKey();
		String codTipoOperacion = data.getString(TIPO_OPERACION);

		log.info("$$$$$$INICIO tarea periodica " + jobKey + " tipo de operacion " + codTipoOperacion);
		EntityManager entityManager = ServerListener.getEntityMgrFactory().createEntityManager();
		
		String usuarioTask = ConfigurationServ.getParamsSystem().get("usuarioTask");
		usuarioTask = usuarioTask.concat("|").concat(usuarioTask).concat("|").concat(Constants.CODIGO_PERSONA_BCB);
		Aladirequesttipo02Type aladirequesttipo02Type = new Aladirequesttipo02Type();
		Calendar calen = GregorianCalendar.getInstance();
		calen.set(2011, 8, 1);
		aladirequesttipo02Type.setFechaDesde(UtilsDate.StrToXMLGregoCal(UtilsDate.stringFromDate(new Date(), "yyyy-MM-dd"), "-"));
		aladirequesttipo02Type.setFechaHasta(UtilsDate.StrToXMLGregoCal(UtilsDate.stringFromDate(new Date(), "yyyy-MM-dd"), "-"));

		JAXBElement<? extends Contenidotype> contenido = null;

		ObjectFactory of = new ObjectFactory();
		contenido = of.createAladirequesttipo02(aladirequesttipo02Type);

		final BcbRequest bcbRequest = BcbRequest.Factory.createRequest("servLocal" + ConfigurationServ.getServiceName(),
				ConfigurationServ.getServiceName(), "BCB", ConfigurationServ.getServiceName(), codTipoOperacion, "", usuarioTask, "12345678",
				ConfigurationServ.getServiceName() + UtilsDate.stringFromDate(new Date(), "yyyyMMdd") + Utils.generateUUID(), contenido);
		final ResponseContext responseContext = new ResponseContext(bcbRequest);

		log.info("Ejecutando tarea periodica " + codTipoOperacion + " para tipo de operacion " + bcbRequest.getIdTipoOperacion());

		final DispatcherSirAladi dispatcherDebitosChecker = new DispatcherSirAladi(entityManager);
		try {
			dispatcherDebitosChecker.doService(bcbRequest, responseContext);
		} catch (Exception e) {
			log.error("Error en proceso automatico " + responseContext.getCodTipoOperacion(), e);
		}

		try {
			log.info("==========================================================================================");
			log.info(responseContext.getBcbResponse().toString(responseContext.getBcbResponse().getMsgBcbresp()));
			log.info("==========================================================================================");
		} catch (Exception e) {
			log.error("Error al leer repuesta job " + e.getMessage());
		}

		log.info("$$$$$$FIN tarea periodica " + jobKey + " tipo de operacion " + codTipoOperacion);

	}

	public static Runnable genTaskForMsgDispatcher(String codTipoOperacion, Date fechaDesde, Date fechaHasta, final String nameTask) {

		Runnable periodicCheckDebitos;

		Aladirequesttipo02Type aladirequesttipo02Type = new Aladirequesttipo02Type();
		Calendar calen = GregorianCalendar.getInstance();
		calen.set(2011, 8, 1);
		aladirequesttipo02Type.setFechaDesde(UtilsDate.StrToXMLGregoCal(UtilsDate.stringFromDate(fechaDesde, "yyyy-MM-dd"), "-"));
		aladirequesttipo02Type.setFechaHasta(UtilsDate.StrToXMLGregoCal(UtilsDate.stringFromDate(fechaHasta, "yyyy-MM-dd"), "-"));

		JAXBElement<? extends Contenidotype> contenido = null;

		ObjectFactory of = new ObjectFactory();
		contenido = of.createAladirequesttipo02(aladirequesttipo02Type);

		String usuarioTask = ConfigurationServ.getParamsSystem().get("usuarioTask");
		final BcbRequest bcbRequest = BcbRequest.Factory.createRequest("servLocal" + ConfigurationServ.getServiceName(),
				ConfigurationServ.getServiceName(), "BCB", ConfigurationServ.getServiceName(), codTipoOperacion, "", usuarioTask, "12345678",
				ConfigurationServ.getServiceName() + UtilsDate.stringFromDate(new Date(), "yyyyMMdd") + Utils.generateUUID(), contenido);
		final ResponseContext responseContext = new ResponseContext(bcbRequest);

		periodicCheckDebitos = new Runnable() {
			public void run() {
				log.info("Ejecutando tarea periodica " + nameTask + " para tipo de operacion " + bcbRequest.getIdTipoOperacion());
				EntityManager entityManager = ServerListener.getEntityMgrFactory().createEntityManager();
				final DispatcherSirAladi dispatcherDebitosChecker = new DispatcherSirAladi(entityManager);
				try {
					dispatcherDebitosChecker.doService(bcbRequest, responseContext);
				} catch (Exception e) {
					log.error("Error en proceso automatico " + responseContext.getCodTipoOperacion(), e);
				}

				try {
					log.info("==========================================================================================");
					log.info(responseContext.getBcbResponse().toString(responseContext.getBcbResponse().getMsgBcbresp()));
					log.info("==========================================================================================");
				} catch (Exception e) {
					// e.printStackTrace();
				}
			}
		};
		return periodicCheckDebitos;
	}
	
	public static void main(String args[]) throws SocketException {

		Enumeration<NetworkInterface> nets = NetworkInterface.getNetworkInterfaces();
		for (NetworkInterface netint : Collections.list(nets)) {
			System.out.println("Display name: %s%n" + netint.getDisplayName());
			System.out.println("Name: %s%n" + netint.getName());
			System.out.println("Hardware address: %s%n" + Arrays.toString(netint.getHardwareAddress()));
			System.out.println("Parent: %s%n" + netint.getParent());
			System.out.println("MTU: %s%n" + netint.getMTU());
			System.out.println("Loopback? %s%n" + netint.isLoopback());
			System.out.println("PointToPoint? %s%n" + netint.isPointToPoint());
			System.out.println("Up? %s%n" + netint.isUp());
			System.out.println("Virtual? %s%n" + netint.isVirtual());
			System.out.println("Supports multicast? %s%n" + netint.isVirtual());
			List<InterfaceAddress> addrs = netint.getInterfaceAddresses();
			for (InterfaceAddress addr : addrs) {
				System.out.println("InterfaceAddress: %s --- %s%n" + addr.getAddress() + " - " + addr.getBroadcast());
			}
			System.out.println("%n");
		}
	}


}
