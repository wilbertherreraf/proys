package gob.bcb.service.siraladi.job;

import gob.bcb.bpm.siraladi.dao.ParamsBean;
import gob.bcb.bpm.siraladi.jpa.Param;
import gob.bcb.bpm.siraladi.utils.Constants;
import gob.bcb.service.siraladi.ServerListener;

import java.util.Date;

import javax.persistence.EntityManager;

import org.apache.log4j.Logger;
import org.quartz.CronScheduleBuilder;
import org.quartz.DateBuilder;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerFactory;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;

/**
 * @author wilherrera Wilbert Herrera Flores Banco Central de Bolivia
 *         Departamento de Desarrollo
 */
public final class SchedulerSir {
	private static Logger log = Logger.getLogger(SchedulerSir.class);
	private Scheduler scheduler;

	public SchedulerSir() {
	}

	public void run(EntityManager entityManager) throws Exception {
		log.info("Inicializando Programador de tareas");
		final String prefJob = "job_";
		final String prefTrigger = "trigger_";

		// First we must get a reference to a scheduler
		SchedulerFactory sf = new StdSchedulerFactory();
		scheduler = sf.getScheduler();

		//EntityManager entityManager = ServerListener.getEntityMgrFactory().createEntityManager();
		ParamsBean paramsBean= new ParamsBean();
		paramsBean.setEntityManager(entityManager);
		Param param = paramsBean.findByCodigo("intervalodebitos");
		//Param param = entityManager.find(Param.class, "intervalodebitos");
		String intervalDebitos = param.getValparam().trim();

		param = paramsBean.findByCodigo("intervaloinstituciones");
		//param = entityManager.find(Param.class, "intervaloinstituciones");
		String horaInst = param.getValparam().trim();
		String[] horaAInst = horaInst.split(":");
		String cronExprInst = "";
		if (horaAInst.length == 1) {
			cronExprInst = "0 0 17 ? * 2-6";
		} else {
			cronExprInst = "0 " + horaAInst[1] + " " + horaAInst[0] + " ? * 2-6";
		}

		String cronExprDebitos = "0 0/" + intervalDebitos + " 7-21 ? * 2-6";
		//cronExprDebitos = "0 0/" + intervalDebitos + " * ? * 2-6";
		
		// computer a time that is on the next round minute
		Date runTimeDebitos = DateBuilder.nextGivenSecondDate(new Date(), 10);
		Date runTimeInst = DateBuilder.nextGivenSecondDate(new Date(), 30);
		log.info("Scheduling Job: " + Constants.TIPO_OPERACION_AL0308 + " desde " + runTimeDebitos
				+ " cronExprDebitos: " + cronExprDebitos);
		log.info("Scheduling Job: " + Constants.TIPO_OPERACION_AL0603 + " desde " + runTimeInst + " cronExprInst: "
				+ cronExprInst);

		// define the job
		JobDetail jobDebitos = JobBuilder.newJob(GenerateTasks.class)
				.withIdentity(prefJob + Constants.TIPO_OPERACION_AL0308, "group1").build();
		JobDetail jobInst = JobBuilder.newJob(GenerateTasks.class)
				.withIdentity(prefJob + Constants.TIPO_OPERACION_AL0603, "group1").build();

		Trigger triggerDebitos = TriggerBuilder.newTrigger()
				.withIdentity(prefTrigger + Constants.TIPO_OPERACION_AL0308, "group1").startAt(runTimeDebitos)
				.withSchedule(CronScheduleBuilder.cronSchedule(cronExprDebitos)).build();

		Trigger triggerInst = TriggerBuilder.newTrigger()
				.withIdentity(prefTrigger + Constants.TIPO_OPERACION_AL0603, "group1").startAt(runTimeInst)
				.withSchedule(CronScheduleBuilder.cronSchedule(cronExprInst)).build();

		jobDebitos.getJobDataMap().put(GenerateTasks.TIPO_OPERACION, Constants.TIPO_OPERACION_AL0308);
		jobInst.getJobDataMap().put(GenerateTasks.TIPO_OPERACION, Constants.TIPO_OPERACION_AL0603);

		scheduler.start();
		log.info("Programacion de tareas inicializado...");
		scheduler.scheduleJob(jobDebitos, triggerDebitos);
		scheduler.scheduleJob(jobInst, triggerInst);

		log.info(jobDebitos.getKey() + " croncito se ejecutara en: " + runTimeDebitos + " "
				+ triggerDebitos.getNextFireTime());
		log.info(jobInst.getKey() + " croncito se ejecutara en: " + runTimeInst + " " + triggerInst.getNextFireTime());

		log.info("Programacion de tareas finalizado...");
	}

	public Scheduler getScheduler() {
		return scheduler;
	}

	public void setScheduler(Scheduler scheduler) {
		this.scheduler = scheduler;
	}
}
