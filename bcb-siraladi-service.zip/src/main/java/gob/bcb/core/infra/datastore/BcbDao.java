package gob.bcb.core.infra.datastore;

public interface BcbDao {
	  // Method descriptor #6 (Lgob/bcb/core/infra/datastore/BcbEntity;)V
	  public void saveOrUpdate(gob.bcb.core.infra.datastore.BcbEntity arg0);
	  
	  // Method descriptor #8 (Ljava/util/Collection;)V
	  // Signature: (Ljava/util/Collection<Lgob/bcb/core/infra/datastore/BcbEntity;>;)V
	  public void saveOrUpdateAll(java.util.Collection<BcbEntity> arg0);
	  
	  // Method descriptor #12 ()Ljava/util/List;
	  // Signature: ()Ljava/util/List<Lgob/bcb/core/infra/datastore/BcbEntity;>;
	  public java.util.List getAll();
	  
	  // Method descriptor #15 (Ljava/lang/Long;)Lgob/bcb/core/infra/datastore/BcbEntity;
	  public gob.bcb.core.infra.datastore.BcbEntity find(java.lang.Long arg0);
}
