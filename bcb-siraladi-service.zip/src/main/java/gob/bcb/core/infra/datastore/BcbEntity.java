package gob.bcb.core.infra.datastore;

import java.io.Serializable;

public class BcbEntity implements Serializable{

}
