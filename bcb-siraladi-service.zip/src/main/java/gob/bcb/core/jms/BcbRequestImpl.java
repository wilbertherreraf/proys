package gob.bcb.core.jms;

import gob.bcb.core.utils.XmlUtils;
import gob.bcb.siraladi.xml.Contenidotype;
import gob.bcb.siraladi.xml.Msgbcb;
import gob.bcb.siraladi.xml.Msgcabecera;
import gob.bcb.siraladi.xml.Msgsistema;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;

/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public class BcbRequestImpl implements BcbRequest { 
	private static Logger log = Logger.getLogger(BcbRequestImpl.class);
	private final String ipOrigen;
	/**
	 * nombre del servicio de negocios o BPM receptor de este request
	 */
	private final String requesterName;
	private final String serviceDestination;
	/**
	 * nombre del feature dentro del servicio de negocio o BPM
	 */
	private final String idTipoOperacion;
	private final String requestId;
	private final Date requestDate;
	private Map<String, Object> parameters = new HashMap<String, Object>();
	private Map<String, Object> propiedades = new HashMap<String, Object>();

	private final Msgbcb msgbcb;
	private final static JAXBContext ctx;
	static {
		try {
			ctx = JAXBContext.newInstance("gob.bcb.siraladi.xml:gob.bcb.siraladi.xml.model:gob.bcb.siraladi.xml.operaciones");
			log.info("Contexto objetos JAXB iniciado...");			
		} catch (JAXBException e) {
			log.error("Error al inicializar contexto JAXB " + e.getMessage() , e);
			throw new RuntimeException(e);
		}
	}
    private final static Map<Class<?>, JAXBContext> contexts = new HashMap<Class<?>, JAXBContext>();
    private static DocumentBuilderFactory documentBuilderFactory;
    
	public BcbRequestImpl(String ipOrigen, Msgbcb msgbcb) {
		this.ipOrigen = ipOrigen;
		this.requesterName = msgbcb.getMsgcabecera().getIdemisor();
		this.serviceDestination = msgbcb.getMsgcabecera().getIdsistema();
		this.idTipoOperacion = msgbcb.getMsgsistema().getIdoperacion();
		this.requestId = msgbcb.getMsgcabecera().getNrooperacion();
		this.requestDate = new Date();
		this.msgbcb = msgbcb;
	}

	/**
	 * Crea una nueva instancia de bcbRequest desde paramatros basse
	 * @param ipOrigen IP de la pc que realiza la consulta
	 * @param requesterName nombre del sistema que consulta
	 * @param idDestinatario nombre de la institucion que recepciona el mensaje, gralmente ser� BCB pero puede existir ocaciones donde sea el TGN por ejmplo
	 * @param serviceDestination id del servicio / aplicacion que consume el mensaje
	 * @param idTipoOperacion codigo de tipo de operacion que realiza la operacion
	 * @param requestId no se usa actualmente
	 * @param idUsuario id del usuario que ejecuta el servicio
	 * @param password password en MD5 
	 * @param nroOperacion codigo interno del emisor del mensaje
	 * @param tipoJAXBEleASubtituir objeto que contiene los parametros del mensaje
	 * @return un objeto bcbrequest que contiene el objeto JAXB 
	 */
	public static BcbRequest newInstance(String ipOrigen, String requesterName, String idDestinatario, String serviceDestination,
			String idTipoOperacion, String requestId, String idUsuario, String password, String nroOperacion, Object tipoJAXBEleASubtituir) {

		Msgcabecera msgcabecera = new Msgcabecera();
		msgcabecera.setIdemisor(requesterName);
		msgcabecera.setIddestinatario(idDestinatario);
		msgcabecera.setIdusuario(idUsuario);
		msgcabecera.setPasswmd5(password);
		msgcabecera.setIdsistema(serviceDestination);
		msgcabecera.setNrooperacion(nroOperacion);

		Msgbcb msgBcb = new Msgbcb();
		msgBcb.setMsgcabecera(msgcabecera);

		Msgsistema msgsistema = new Msgsistema();
		msgsistema.setIdoperacion(idTipoOperacion);

		if (tipoJAXBEleASubtituir != null)		
			msgsistema.setContenido((JAXBElement<? extends Contenidotype>)tipoJAXBEleASubtituir);

		msgBcb.setMsgsistema(msgsistema);

		return new BcbRequestImpl(ipOrigen, msgBcb);
	}

	public static BcbRequest newInstance(Message mensajeXML) {
		BcbRequest bcbReq = null;
		try {
			bcbReq = BcbRequestImpl.newInstance(((TextMessage) mensajeXML).getText());
		} catch (JMSException e) {
			log.error(e.getMessage(), e);
			throw new RuntimeException(e);
		}
		return bcbReq;
	}

	public static BcbRequest newInstance(String xmlRequest) {
		Msgbcb msgBcb = null;
		try {
			Unmarshaller u = ctx.createUnmarshaller();
			Msgbcb value = (Msgbcb) u.unmarshal(new StringReader(xmlRequest));

			if (value == null) {
				throw new RuntimeException("Request no contiene objeto definido en el servicio");
			}

			msgBcb = (Msgbcb) value;

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new RuntimeException(e);
		}
		return new BcbRequestImpl(msgBcb.getMsgcabecera().getIdemisor() + "IP", msgBcb);
	}

	
	public Msgbcb getMsgbcb() {
		return msgbcb;
	}
	
	public String toString(Object value) throws JAXBException, ParserConfigurationException, TransformerException {
		Document doc = toDocument(value);
		return XmlUtils.getStringFromDom(doc);		
	}
	public Document toDocument(Object value) throws JAXBException, ParserConfigurationException {
		if (value == null) {
			throw new IllegalArgumentException("Cannot convert from null value to JAXBSource");
		}
		if (value.getClass().getAnnotation(XmlRootElement.class) != null) {
			JAXBContext context = getJaxbContext(value);
			
			// must create a new instance of marshaller as its not thread safe

			Marshaller marshaller = context.createMarshaller();
			
			Document doc = createDocument();

			marshaller.marshal(value, doc);
			return doc;
		} else {
			return null;
		}

	}
	
    public DocumentBuilderFactory getDocumentBuilderFactory() {
        if (documentBuilderFactory == null) {
            documentBuilderFactory = createDocumentBuilderFactory();
        }
        return documentBuilderFactory;
    }
	
    public DocumentBuilder createDocumentBuilder() throws ParserConfigurationException {
        DocumentBuilderFactory factory = getDocumentBuilderFactory();
        return factory.newDocumentBuilder();
    }	
    public Document createDocument() throws ParserConfigurationException {
        DocumentBuilder builder = createDocumentBuilder();
        return builder.newDocument();
    }
    
    public DocumentBuilderFactory createDocumentBuilderFactory() {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        factory.setIgnoringElementContentWhitespace(true);
        factory.setIgnoringComments(true);
        return factory;
    }    
    
    private synchronized JAXBContext getJaxbContext(Object value) throws JAXBException {
        Class<?> type = value.getClass();
        JAXBContext context = contexts.get(type);
        if (context == null) {
            context = JAXBContext.newInstance(type);
            contexts.put(type, context);
        }
        return context;
    }
	
	
	// ---------------------------------------------------------------------------
	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#getRequestId()
	 */
	
	public String getRequestId() {
		return requestId;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#getServiceName()
	 */
	
	public String getIdTipoOperacion() {
		return idTipoOperacion;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#getRequestDate()
	 */
	
	public Date getRequestDate() {
		return new Date(this.requestDate.getTime());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#getRequesterName()
	 */
	
	public String getRequesterName() {
		return requesterName;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#getParameters()
	 */
	
	public Map<String, Object> getRequestElements() {
		return this.parameters;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#setParameters(java.util.LinkedHashMap )
	 */
	
	public void setRequestElements(Map<String, Object> parameters) {
		this.parameters = parameters;
	}

	/**
	 * @return the ipOrigen
	 */
	
	public final String getIpOrigen() {
		return ipOrigen;
	}

	// ---------------------------------------------------------------------------
	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#setProperties(java.util.Map)
	 */
	
	public void setProperties(Map<String, Object> properties) {
		propiedades = new HashMap<String, Object>(properties);
	}

	// ---------------------------------------------------------------------------
	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#addProperties(java.util.Map)
	 */
	
	public void addProperties(Map<String, Object> properties) {
		propiedades.putAll(properties);
	}

	// ---------------------------------------------------------------------------
	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#getPropertyNamesIterator()
	 */
	
	public Iterator<String> getPropertyNamesIterator() {
		Map<String, Object> local = new HashMap<String, Object>(propiedades);
		return local.keySet().iterator();
	}

	// ---------------------------------------------------------------------------
	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#getPropertyNamesList()
	 */
	
	public List<String> getPropertyNamesList() {
		Set<String> keySet = propiedades.keySet();
		List<String> lista = new ArrayList<String>(keySet);
		return lista;
	}

	// ---------------------------------------------------------------------------
	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#clearProperties()
	 */
	
	public void clearProperties() {
		propiedades.clear();
	}

	// ---------------------------------------------------------------------------
	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#getBooleanProperty(java.lang.String)
	 */
	
	public boolean getBooleanProperty(String name) {
		Boolean local = (Boolean) propiedades.get(name);
		return local.booleanValue();
	}

	// ---------------------------------------------------------------------------
	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#getByteProperty(java.lang.String)
	 */
	
	public byte getByteProperty(String name) {
		Byte local = (Byte) propiedades.get(name);
		return local.byteValue();
	}

	// ---------------------------------------------------------------------------
	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#getDoubleProperty(java.lang.String)
	 */
	
	public double getDoubleProperty(String name) {
		Double local = (Double) propiedades.get(name);
		return local.doubleValue();
	}

	// ---------------------------------------------------------------------------
	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#getIntProperty(java.lang.String)
	 */
	
	public int getIntProperty(String name) {
		Integer local = (Integer) propiedades.get(name);
		return local.intValue();
	}

	// ---------------------------------------------------------------------------
	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#getFloatProperty(java.lang.String)
	 */
	
	public float getFloatProperty(String name) {
		Float local = (Float) propiedades.get(name);
		return local.floatValue();
	}

	// ---------------------------------------------------------------------------
	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#getLongProperty(java.lang.String)
	 */
	
	public long getLongProperty(String name) {
		Long local = (Long) propiedades.get(name);
		return local.longValue();
	}

	// ---------------------------------------------------------------------------
	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#getObjectProperty(java.lang.String)
	 */
	
	public Object getObjectProperty(String name) {
		return propiedades.get(name);
	}

	// ---------------------------------------------------------------------------
	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#getShortProperty(java.lang.String)
	 */
	
	public short getShortProperty(String name) {
		Short local = (Short) propiedades.get(name);
		return local.shortValue();
	}

	// ---------------------------------------------------------------------------
	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#getStringProperty(java.lang.String)
	 */
	
	public String getStringProperty(String name) {
		String local = (String) propiedades.get(name);
		return local;
	}

	// ---------------------------------------------------------------------------
	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#propertyExists(java.lang.String)
	 */
	
	public boolean propertyExists(String name) {
		return propiedades.containsKey(name);
	}

	// ---------------------------------------------------------------------------
	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#removeProperty(java.lang.String)
	 */
	
	public Object removeProperty(String name) {
		return propiedades.remove(name);
	}

	// ---------------------------------------------------------------------------
	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#setBooleanProperty(java.lang.String, boolean)
	 */
	
	public void setBooleanProperty(String name, boolean value) {
		propiedades.put(name, Boolean.valueOf(value));
	}

	// ---------------------------------------------------------------------------
	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#setByteProperty(java.lang.String, byte)
	 */
	
	public void setByteProperty(String name, byte value) {
		propiedades.put(name, Byte.valueOf((value)));
	}

	// ---------------------------------------------------------------------------
	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#setDoubleProperty(java.lang.String, double)
	 */
	
	public void setDoubleProperty(String name, double value) {
		propiedades.put(name, Double.valueOf((value)));
	}

	// ---------------------------------------------------------------------------
	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#setFloatProperty(java.lang.String, float)
	 */
	
	public void setFloatProperty(String name, float value) {
		propiedades.put(name, Float.valueOf((value)));
	}

	// ---------------------------------------------------------------------------
	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#setIntProperty(java.lang.String, int)
	 */
	
	public void setIntProperty(String name, int value) {
		propiedades.put(name, Integer.valueOf((value)));
	}

	// ---------------------------------------------------------------------------
	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#setLongProperty(java.lang.String, long)
	 */
	
	public void setLongProperty(String name, long value) {
		propiedades.put(name, Long.valueOf((value)));
	}

	// ---------------------------------------------------------------------------
	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#setObjectProperty(java.lang.String, java.lang.Object)
	 */
	
	public void setObjectProperty(String name, Object value) {
		propiedades.put(name, value);
	}

	// ---------------------------------------------------------------------------
	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#setShortProperty(java.lang.String, short)
	 */
	
	public void setShortProperty(String name, short value) {
		propiedades.put(name, Short.valueOf((value)));
	}

	// ---------------------------------------------------------------------------
	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#setStringProperty(java.lang.String, java.lang.String)
	 */
	
	public void setStringProperty(String name, String value) {
		propiedades.put(name, value);
	}

	// ---------------------------------------------------------------------------
	
	public BcbRequest clone() {
		BcbRequest local = null;
		try {
			local = (BcbRequest) super.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
			log.error("No se pudo clonar request [" + this.getRequestId() + "]");
		}

		return local;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbRequest#getServiceDestination()
	 */
	
	public String getServiceDestination() {
		return this.serviceDestination;
	}

}
