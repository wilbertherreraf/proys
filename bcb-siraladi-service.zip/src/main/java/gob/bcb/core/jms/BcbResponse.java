package gob.bcb.core.jms;

import gob.bcb.siraladi.xml.Msgbcbresp;

import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.w3c.dom.Document;

/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public interface BcbResponse {

	public Iterator<DescripcionParametro> getDescripcionParametroIterator();

	void addDescripcionParametro(DescripcionParametro respuesta);

	List<DescripcionParametro> getRespuestas();

	/**
	 * Obtiene el id de esta respuesta. En algunos casos podr a ser el mismo Id
	 * del request.
	 * 
	 * @return El id de esta respuesta
	 */
	String getResponseId();

	/**
	 * Obtiene el Id del request correspondiente a esta respuesta. Tambi n puede
	 * indicar el n mero de secuencia del request.
	 * 
	 * @return El id del request que di  origen a esta respuesta.
	 */
	String getRequestId();

	/**
	 * Obtiene la fecha de recepci n del request seg n el servicio que atendi 
	 * el requerimiento.
	 * 
	 * @return fecha de recepci n del requerimiento.
	 */
	Date getReceivedDate();

	/**
	 * Obtiene la fecha en la cual se gener  esta respuesta.
	 * 
	 * @return La fecha de generaci n de esta respuesta
	 */
	Date getResponseDate();

	String getStatusCode();

	String getStatusDescription();

	/**
	 * Determina si este objeto respuesta representa un error de proceso como
	 * respuesta a un objeto tipo {@link BcbRequest}
	 * 
	 * @return <code>true</code> si este objeto representa un error de proceso
	 */
	boolean isErrorResponse();

	/**
	 * Si {@link BcbResponse#isErrorResponse()} retorna <code>true</code>,
	 * entonces este m todo retorna {@link DescripcionError} que contiene la
	 * descripci n del error generado en el servidor como resultado de un
	 * {@link BcbRequest}
	 * 
	 * @return {@link DescripcionError} cuyo contenido es la descripci n del
	 *         error generado en el servidor como respuesta a un
	 *         {@link BcbRequest}
	 */
	DescripcionError getErrorDescription();
	void updateMsgsistemaresp(String statusCode, String statusDescription, Object tipoJAXBEleASubtituir);
	Document toDocument(Object value) throws JAXBException, ParserConfigurationException;
	String toString(Object value) throws JAXBException, ParserConfigurationException;
	String stringFromObjectJAXB(Object value) throws JAXBException, ParserConfigurationException, TransformerException;

	Msgbcbresp getMsgBcbresp();

	public static final class Factory {

		public static BcbResponse createFromBcbRequest(BcbRequest bcbRequest, String statusCode, String consent) {
			return BcbResponseImpl.newInstance(bcbRequest, statusCode, consent);

		}
		public static BcbResponse createFromStringXML(String xml){
			return BcbResponseImpl.newInstance(xml);			
		}
		public static BcbResponse createDefaultResponse(String idEmisor, String serviceId, String clientId, String nroOperacion, String statusCode,
				String statusDescription, String idOperacion){
				return BcbResponseImpl.newInstance(idEmisor, serviceId, clientId, nroOperacion, statusCode,
						statusDescription, idOperacion);
		}
	}
}
