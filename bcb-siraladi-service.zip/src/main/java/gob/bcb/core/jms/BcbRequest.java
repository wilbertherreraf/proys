package gob.bcb.core.jms;

import gob.bcb.siraladi.xml.Msgbcb;

import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.jms.Message;
import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public interface BcbRequest {

	/**
	 * Especifica el contenido de las propiedades de este request. Si hab a
	 * previamente especificados valores,  stos ser n reemplazados completamente
	 * 
	 * @param properties
	 */
	void setProperties(Map<String, Object> properties);

	/**
	 * Adiciona estas propiedades a las ya existentes. Si hubiera duplicidad,
	 * las  ltimas propiedades en ingresar tienen precedencia
	 * 
	 * @param properties
	 */
	void addProperties(Map<String, Object> properties);

	/**
	 * Elimina el atributo especificado por <code>name</code> del repositorio de
	 * propiedades de este objeto request
	 * 
	 * @param name
	 *            de la propiedad
	 * @return el {@link Object} que est  siendo eliminado del repositorio de
	 *         propiedades. <code>null</code> si el atributo no existe
	 */
	Object removeProperty(String name);

	/**
	 * Retorna un {@link Iterator} a la lista de nombres de las propiedades
	 * especificadas para este request. Operaciones de borrado sobre este
	 * iterador no tienen efecto en el repositorio de propiedades original
	 * 
	 * @return
	 */
	Iterator<String> getPropertyNamesIterator();

	/**
	 * Retorna una lista cuya contenido son los nombres de las propiedades
	 * especificadas para este request
	 * 
	 * @return
	 */
	List<String> getPropertyNamesList();

	/**
	 * Elimina las propiedades almacenadas en este request.
	 * 
	 */
	void clearProperties();

	/**
	 * Retorna el valor de la propiedad especificada con <code>name</code>
	 * 
	 * @param name
	 *            Nombre de la propiedad
	 * @return El valor booleano almacenado bajo <code>name</code>
	 */
	boolean getBooleanProperty(String name);

	/**
	 * Retorna el valor de tipo <code>byte</code> asociado al par metro
	 * <code>name</code>
	 * 
	 * @param name
	 * @return
	 */
	byte getByteProperty(String name);

	/**
	 * Retorna el valor <code>double</code> de la propiedad especificada por
	 * <code>name</code>
	 * 
	 * @param name
	 * @return
	 */
	double getDoubleProperty(String name);

	/**
	 * Retorna el valor <code>int</code> de la propiedad especificada por
	 * <code>name</code>
	 * 
	 * @param name
	 * @return
	 */
	int getIntProperty(String name);

	/**
	 * Retorna el valor <code>float</code> de la propiedad especificada por
	 * <code>name</code>
	 * 
	 * @param name
	 * @return
	 */
	float getFloatProperty(String name);

	/**
	 * Retorna el valor <code>long</code> de la propiedad especificada por
	 * <code>name</code>
	 * 
	 * @param name
	 * @return
	 */
	long getLongProperty(String name);

	/**
	 * Retorna el valor {@link Object} de la propiedad especificada por
	 * <code>name</code>
	 * 
	 * @param name
	 * @return
	 */
	Object getObjectProperty(String name);

	/**
	 * Retorna el valor <code>short</code> de la propiedad especificada por
	 * <code>name</code>
	 * 
	 * @param name
	 * @return
	 */
	short getShortProperty(String name);

	/**
	 * Retorna el valor {@link String} de la propiedad especificada por
	 * <code>name</code>
	 * 
	 * @param name
	 * @return
	 */
	String getStringProperty(String name);

	/**
	 * Indica si existe un valor asociado a la propiedad especificada por
	 * <code>name</code>
	 * 
	 * @param name
	 * @return
	 */
	boolean propertyExists(String name);

	/**
	 * Establece una propiedad <code>boolean</code> asignada a <code>name</code>
	 * dentro de este request
	 * 
	 * @param name
	 * @param codigo
	 */
	void setBooleanProperty(String name, boolean value);

	/**
	 * Establece una propiedad <code>byte</code> asignada a <code>name</code>
	 * dentro de este request
	 * 
	 * @param name
	 * @param codigo
	 */
	void setByteProperty(String name, byte value);

	/**
	 * Establece una propiedad <code>double</code> asignada a <code>name</code>
	 * dentro de este request
	 * 
	 * @param name
	 * @param codigo
	 */
	void setDoubleProperty(String name, double value);

	/**
	 * Establece una propiedad <code>float</code> asignada a <code>name</code>
	 * dentro de este request
	 * 
	 * @param name
	 * @param codigo
	 */
	void setFloatProperty(String name, float value);

	/**
	 * Establece una propiedad <code>int</code> asignada a <code>name</code>
	 * dentro de este request
	 * 
	 * @param name
	 * @param codigo
	 */
	void setIntProperty(String name, int value);

	/**
	 * Establece una propiedad <code>long</code> asignada a <code>name</code>
	 * dentro de este request
	 * 
	 * @param name
	 * @param codigo
	 */
	void setLongProperty(String name, long value);

	/**
	 * Establece una propiedad {@link Object} asignada a <code>name</code>
	 * dentro de este request
	 * 
	 * @param name
	 * @param codigo
	 */
	void setObjectProperty(String name, Object value);

	/**
	 * Establece una propiedad <code>short</code> asignada a <code>name</code>
	 * dentro de este request
	 * 
	 * @param name
	 * @param codigo
	 */
	void setShortProperty(String name, short value);

	/**
	 * Establece una propiedad {@link String} asignada a <code>name</code>
	 * dentro de este request
	 * 
	 * @param name
	 * @param codigo
	 */
	void setStringProperty(String name, String value);

	/**
	 * Este m todo devuelve el IP de la m quina donde se origin  el request.
	 * Este IP no necesariamente pertence a la m quina previa que envia este
	 * mensaje.
	 * 
	 * @return
	 */
	String getIpOrigen();

	Date getRequestDate();

	/**
	 * Obtiene el nombre del m dulo que origin  este request.
	 * 
	 * @return
	 */
	String getRequesterName();

	/**
	 * Obtiene el nombre del servicio destino de este request. Este es el nombre
	 * del servicio de negocio   BPM receptor de este requerimiento
	 * 
	 * @return nombre del servicio de negocio o BPM destino de este
	 *         requerimiento
	 */
	String getServiceDestination();

	/**
	 * Este es el nombre del feature destino dentro del servicio de negocio o
	 * BPM
	 * 
	 * @return El nombre del feature del servicio destino al cual se est 
	 *         invocando
	 */
	String getIdTipoOperacion();

	/**
	 * Obtiene los elementos request almacenados seg n el tipo de su m todo.
	 * 
	 * @return un {@link LinkedHashMap} cuyo contenido son los elementos
	 *         requests almacenados seg n el tipo de su m todo.
	 */
	Map<String, Object> getRequestElements();

	/**
	 * Establece los elementos request que este objecto {@link BcbRequest}
	 * contendr .
	 * 
	 * <code>NOTA</code>. Este m todo sobreescribir  cualquier otro contenido
	 * que este repositorio haya tenido.
	 * 
	 * @param requestElements
	 *            los elementos requests contenidos en un mapa ordenado
	 */
	void setRequestElements(Map<String, Object> requestElements);

	/**
	 * Obtiene el Id de este request.
	 * 
	 * @return El Id de este request.
	 */
	String getRequestId();

	String toString(Object value) throws JAXBException, ParserConfigurationException, TransformerException;
	Msgbcb getMsgbcb();
	
	public static final class Factory {
		public static BcbRequest createRequest(Message mensajeXML) {
			return BcbRequestImpl.newInstance(mensajeXML);
		}
		public static BcbRequest createRequest(String mensajeXML) {
			return BcbRequestImpl.newInstance(mensajeXML);
		}		
		public static BcbRequest createRequest(String ipOrigen, String requesterName, String idDestinatario, String serviceDestination,
				String idTipoOperacion, String requestId, String idUsuario, String password, String nroOperacion, Object tipoJAXBEleASubtituir) {
			return BcbRequestImpl.newInstance(ipOrigen, requesterName, idDestinatario, serviceDestination,
					idTipoOperacion, requestId, idUsuario, password, nroOperacion, tipoJAXBEleASubtituir);
		}
	}

}
