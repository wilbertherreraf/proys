package gob.bcb.core.jms;

import gob.bcb.bpm.siraladi.utils.Constants;
import gob.bcb.bpm.siraladi.utils.Utils;
import gob.bcb.bpm.siraladi.utils.UtilsDate;
import gob.bcb.siraladi.xml.Msgbcbresp;
import gob.bcb.siraladi.xml.Msgcabecera;
import gob.bcb.siraladi.xml.Msgcabeceraresp;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public class ResponseHeader {
	private final Msgcabeceraresp msgcabeceraresp;

	public ResponseHeader(Msgcabecera msgcabecera) {
		this(msgcabecera.getIddestinatario(), msgcabecera.getIdsistema(), msgcabecera.getIdemisor(), msgcabecera.getNrooperacion());
	}

	/**
	 * @param serviceId
	 * @param clientId
	 * @param sequence
	 * @param count
	 *            N mero de requests recibidos
	 * @param requestDate
	 * @param receivedOn
	 * @param responseDate
	 * @param countResponses
	 *            N mero de requests procesados
	 */

	public ResponseHeader(String idEmisor, String serviceId, String clientId, String nroOperacion) {
		this.msgcabeceraresp = new Msgcabeceraresp();
		this.msgcabeceraresp.setFecharecepcion(UtilsDate.stringFromDate(new Date(), Constants.FORMAT_DATE_TIME));
		this.msgcabeceraresp.setFecharespuesta(UtilsDate.stringFromDate(new Date(), Constants.FORMAT_DATE_TIME));
		this.msgcabeceraresp.setIddestinatario(clientId);
		this.msgcabeceraresp.setIdemisor(idEmisor);
		this.msgcabeceraresp.setIdrespuesta(serviceId + UtilsDate.stringFromDate(new Date(), "yyyyMMdd") + Utils.generateUUID());
		this.msgcabeceraresp.setIdsistema(serviceId);
		this.msgcabeceraresp.setNrooperacion(nroOperacion);
	}

	// ---------------------------------------------------------------------------
	/**
	 * @return the serviceId
	 */
	public String getServiceId() {
		return msgcabeceraresp.getIdsistema();
	}

	/**
	 * @return the clientId
	 */
	public String getClientId() {
		return msgcabeceraresp.getIddestinatario();
	}

	/**
	 * @return the sequence
	 */
	public String getSequence() {
		return msgcabeceraresp.getIdrespuesta();
	}

	public String getNroOperacion() {
		return msgcabeceraresp.getNrooperacion();
	}

	/**
	 * @return the requestDate
	 */
	public Date getRequestDate() {
		return new Date(msgcabeceraresp.getFecharecepcion());
	}

	/**
	 * @return the responseDate
	 */
	public Date getResponseDate() {
		return new Date(msgcabeceraresp.getFecharespuesta());
	}

	public Msgcabeceraresp getMsgcabeceraresp() {
		return msgcabeceraresp;
	}
}
