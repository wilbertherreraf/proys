package gob.bcb.core.jms;

import gob.bcb.bpm.siraladi.jpa.TPagoImp;

import gob.bcb.bpm.siraladi.utils.Constants;
import gob.bcb.bpm.siraladi.utils.Utils;
import gob.bcb.bpm.siraladi.utils.UtilsDate;
import gob.bcb.core.utils.XmlUtils;

import gob.bcb.siraladi.xml.Contenidotype;
import gob.bcb.siraladi.xml.Contenidotype.Valorcompuesto;
import gob.bcb.siraladi.xml.Msgbcb;
import gob.bcb.siraladi.xml.Msgbcbresp;
import gob.bcb.siraladi.xml.Msgcabecera;
import gob.bcb.siraladi.xml.Msgcabeceraresp;
import gob.bcb.siraladi.xml.Msgsistema;
import gob.bcb.siraladi.xml.Msgsistemaresp;
import gob.bcb.siraladi.xml.model.Apertura;
import gob.bcb.siraladi.xml.operaciones.Aladirequesttipo01Type;
import gob.bcb.siraladi.xml.operaciones.Aladiresponsetipo01Type;
import gob.bcb.siraladi.xml.operaciones.ObjectFactory;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.util.JAXBSource;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.w3c.dom.Document;

/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public class BcbResponseImpl implements BcbResponse {
	private final List<DescripcionParametro> respuestas = new ArrayList<DescripcionParametro>();
	private final Msgbcbresp msgBcbresp;
	private Map<Class<?>, JAXBContext> contexts = new HashMap<Class<?>, JAXBContext>();
	private DocumentBuilderFactory documentBuilderFactory;

	public BcbResponseImpl(Msgbcbresp msgBcbresp) {
		this.msgBcbresp = msgBcbresp;
	}

	public static BcbResponse newInstance(Msgcabeceraresp msgcabeceraresp, Msgsistemaresp msgsistemaresp) {
		Msgbcbresp msgBcbresp = new Msgbcbresp();
		msgBcbresp.setMsgcabeceraresp(msgcabeceraresp);
		msgBcbresp.setMsgsistemaresp(msgsistemaresp);
		return new BcbResponseImpl(msgBcbresp);
	}

	public static BcbResponse newInstance(String idEmisor, String serviceId, String clientId, String nroOperacion, String statusCode,
			String statusDescription, String idOperacion) {
		ResponseHeader responseHeader = new ResponseHeader(idEmisor, serviceId, clientId, nroOperacion);

		return BcbResponseImpl.newInstance(responseHeader.getMsgcabeceraresp(), statusCode, statusDescription, idOperacion);
	}

	public static BcbResponse newInstance(Msgcabeceraresp msgcabeceraresp, String statusCode, String statusDescription, String idOperacion) {

		Msgsistemaresp msgsistemaresp = new Msgsistemaresp();
		msgsistemaresp.setIdoperacion(idOperacion);
		msgsistemaresp.setCodestadoresp(statusCode);
		msgsistemaresp.setDescripcion(statusDescription);

		return BcbResponseImpl.newInstance(msgcabeceraresp, msgsistemaresp, null);
	}

	public static BcbResponse newInstance(Msgcabeceraresp msgcabeceraresp, Msgsistemaresp msgsistemaresp, Object tipoJAXBEleASubtituir) {

		BcbResponse bcbResponse = BcbResponseImpl.newInstance(msgcabeceraresp, msgsistemaresp);
		bcbResponse.updateMsgsistemaresp(null, null, tipoJAXBEleASubtituir);
		return bcbResponse;
	}

	public static BcbResponse newInstance(BcbRequest bcbRequest, String statusCode, String statusDescription) {
		return BcbResponseImpl
				.newInstance(bcbRequest.getMsgbcb().getMsgcabecera().getIddestinatario(), bcbRequest.getMsgbcb().getMsgcabecera()
						.getIdsistema(), bcbRequest.getMsgbcb().getMsgcabecera().getIdemisor(), bcbRequest.getMsgbcb().getMsgcabecera()
						.getNrooperacion(), statusCode, statusDescription, bcbRequest.getMsgbcb().getMsgsistema().getIdoperacion());
	}

	public static BcbResponse newInstance(String xmlRequest) {
		Msgbcbresp msgBcbresp = null;
		try {
			JAXBContext ctx = JAXBContext.newInstance("gob.bcb.siraladi.xml:gob.bcb.siraladi.xml.model:gob.bcb.siraladi.xml.operaciones");

			Unmarshaller u = ctx.createUnmarshaller();
			Msgbcbresp value = (Msgbcbresp) u.unmarshal(new StringReader(xmlRequest));

			if (value == null) {
				throw new RuntimeException("Request no contiene objeto definido en el servicio");
			}

			msgBcbresp = (Msgbcbresp) value;

		} catch (JAXBException e) {
			// log.error(e.getMessage(), e);
			throw new RuntimeException(e);
		}
		return new BcbResponseImpl(msgBcbresp);
	}

	public void updateMsgsistemaresp(String statusCode, String statusDescription, Object tipoJAXBEleASubtituir) {
		if (statusCode != null) {
			msgBcbresp.getMsgsistemaresp().setCodestadoresp(statusCode);
		}
		if (statusDescription != null) {
			msgBcbresp.getMsgsistemaresp().setDescripcion(statusDescription);
		}
		if (tipoJAXBEleASubtituir != null) {
			msgBcbresp.getMsgsistemaresp().setContenido((JAXBElement<? extends Contenidotype>) tipoJAXBEleASubtituir);
		}
		msgBcbresp.getMsgcabeceraresp().setFecharespuesta(UtilsDate.stringFromDate(new Date(), Constants.FORMAT_DATE_TIME));
	}

	public Document toDocument(Object value) throws JAXBException, ParserConfigurationException {
		if (value == null) {
			throw new IllegalArgumentException("Cannot convert from null value to JAXBSource");
		}
		if (value.getClass().getAnnotation(XmlRootElement.class) != null) {
			JAXBContext context = getJaxbContext(value);
			// must create a new instance of marshaller as its not thread safe
			Marshaller marshaller = context.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_ENCODING, "ISO-8859-1");
			Document doc = createDocument();
			marshaller.marshal(value, doc);
			return doc;
		} else {
			return null;
		}

	}

	public String toString(Object value) throws JAXBException, ParserConfigurationException {
		if (value == null) {
			throw new IllegalArgumentException("Cannot convert from null value to JAXBSource");
		}
		if (value.getClass().getAnnotation(XmlRootElement.class) != null) {
			// lets convert the object to a JAXB source and try convert that to
			// the required source
			JAXBContext context = getJaxbContext(value);
			// must create a new instance of marshaller as its not thread safe
			Marshaller marshaller = context.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_ENCODING, "ISO-8859-1");
			Writer buffer = new StringWriter();
			// whf setear si la impresion es pretty o no isPrettyPrint() ? Boolean.TRUE : Boolean.FALSE
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			marshaller.marshal(value, buffer);
			return buffer.toString();
		} else {
			return null;
		}

	}

	public String stringFromObjectJAXB(Object value) throws JAXBException, ParserConfigurationException, TransformerException {
		Document doc = toDocument(value);

		return XmlUtils.getStringFromDom(doc); 
	}

	public DocumentBuilderFactory getDocumentBuilderFactory() {
		if (documentBuilderFactory == null) {
			documentBuilderFactory = createDocumentBuilderFactory();
		}
		return documentBuilderFactory;
	}

	public DocumentBuilder createDocumentBuilder() throws ParserConfigurationException {
		DocumentBuilderFactory factory = getDocumentBuilderFactory();
		return factory.newDocumentBuilder();
	}

	public Document createDocument() throws ParserConfigurationException {
		DocumentBuilder builder = createDocumentBuilder();
		return builder.newDocument();
	}

	public DocumentBuilderFactory createDocumentBuilderFactory() {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		factory.setIgnoringElementContentWhitespace(true);
		factory.setIgnoringComments(true);
		return factory;
	}

	private synchronized JAXBContext getJaxbContext(Object value) throws JAXBException {
		Class<?> type = value.getClass();
		JAXBContext context = contexts.get(type);
		if (context == null) {
			context = JAXBContext.newInstance(type);
			contexts.put(type, context);
		}
		return context;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbResponse#getResponseDate()
	 */
	
	public Date getResponseDate() {
		return new Date(msgBcbresp.getMsgcabeceraresp().getFecharespuesta());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbResponse#getStatusCode()
	 */
	
	public String getStatusCode() {
		return msgBcbresp.getMsgsistemaresp().getCodestadoresp();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbResponse#getStatusDescription()
	 */
	
	public String getStatusDescription() {
		return msgBcbresp.getMsgsistemaresp().getDescripcion();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbResponse#getRequestId()
	 */
	
	public String getRequestId() {
		return msgBcbresp.getMsgcabeceraresp().getNrooperacion();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbResponse#getResponseId()
	 */
	
	public String getResponseId() {
		return msgBcbresp.getMsgcabeceraresp().getIdrespuesta();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbResponse#getReceivedDate()
	 */
	
	public Date getReceivedDate() {
		return UtilsDate.dateFromString(msgBcbresp.getMsgcabeceraresp().getFecharecepcion(), Constants.FORMAT_DATE_TIME);
	}

	// ---------------------------------------------------------------------------
	/**
	 * Devuelve iterador de una copia de la lista original
	 * 
	 * @return
	 */
	
	public Iterator<DescripcionParametro> getDescripcionParametroIterator() {
		ArrayList<DescripcionParametro> local = new ArrayList<DescripcionParametro>(respuestas);
		return local.iterator();
	}

	// ---------------------------------------------------------------------------
	/**
	 * @return the respuestas
	 */
	
	public List<DescripcionParametro> getRespuestas() {
		return new ArrayList<DescripcionParametro>(respuestas);
	}

	// ---------------------------------------------------------------------------
	
	public void addDescripcionParametro(DescripcionParametro respuesta) {
		respuestas.add(respuesta);
	}

	
	public boolean isErrorResponse() {
		// TODO Auto-generated method stub
		return false;
	}

	
	public DescripcionError getErrorDescription() {
		// TODO Auto-generated method stub
		return null;
	}

	public Msgbcbresp getMsgBcbresp() {
		return msgBcbresp;
	}

	public static void main(String[] args) {
		String result = null;
		try {
			// result = Utils.readFileAsString("e:/ala0101examplepuro.xml");
			result = Utils.readFileAsString("e:/ala0101example.xml");
			result = Utils.readFileAsString("e:/ala0305respexample.xml");
			// result = Utils.readFileAsString("e:/ala0101respexample2.xml");
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		BcbResponse bcbResponse = BcbResponseImpl.newInstance(result);

		Aladirequesttipo01Type al0103Type = (Aladirequesttipo01Type) bcbResponse.getMsgBcbresp().getMsgsistemaresp().getContenido().getValue();
		List<Valorcompuesto> valorcompuesto = al0103Type.getValorcompuesto();
		JAXBContext context;
		Unmarshaller u = null ;
		try {
			context = JAXBContext.newInstance(TPagoImp.class);
			u = context.createUnmarshaller();			
		} catch (JAXBException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		for (Valorcompuesto valorcompuesto2 : valorcompuesto) {
			List<String> listaValorRenglon = valorcompuesto2.getValorreglon();
			for (String string : listaValorRenglon) {
			      
			    String theStrArray[] = string.split("CDATA");
			    
			    String theWantedData = theStrArray[1].substring(0, theStrArray[1].length() - 3);
				//try {
					//TPagoImp tPagoImp2 = (TPagoImp) u.unmarshal(new StringReader(string));
					//System.out.println(tPagoImp2.getSecuencia());
					System.out.println(string);
					System.out.println(theWantedData);
				//} catch (JAXBException e1) {
					// TODO Auto-generated catch block
					//e1.printStackTrace();
				//}				
					break;
			}
			break;
		}

		if (bcbResponse != null) {
			return;
		}

		System.out.println(bcbResponse.getMsgBcbresp().getMsgcabeceraresp().getNrooperacion());
		System.out.println(((Aladirequesttipo01Type) bcbResponse.getMsgBcbresp().getMsgsistemaresp().getContenido().getValue()).getApertura()
				.getFechaemis());
		System.out.println(bcbResponse.getMsgBcbresp().getMsgsistemaresp().getContenido().getValue().getValor().get(0));
		if (bcbResponse != null) {
			return;
		}
		Apertura apertura = ((Aladirequesttipo01Type) bcbResponse.getMsgBcbresp().getMsgsistemaresp().getContenido().getValue()).getApertura();
		System.out.println(apertura.getFechavto().toGregorianCalendar().getTime());
		System.out.println(UtilsDate.stringFromDate(apertura.getFechavto().toGregorianCalendar().getTime(), "dd/MM/yyyy"));

		Aladirequesttipo01Type al0101Type = new Aladirequesttipo01Type();
		al0101Type.setApertura(apertura);

		ObjectFactory of = new ObjectFactory();
		JAXBElement<? extends Contenidotype> contenido = of.createAladirequesttipo01(al0101Type);
		bcbResponse.getMsgBcbresp().getMsgsistemaresp().setContenido(contenido);

		bcbResponse.getMsgBcbresp().getMsgsistemaresp().getContenido().getValue().getValor()
				.add("<![CDATA[" + Utils.objectToXML(apertura) + "]]>");
		/*
		 * System.out.println(apertura.getNomimportador());
		 * System.out.println(bcbResponse.getMsgBcbresp().getMsgsistemaresp().getContenido().getName().getLocalPart());
		 */
		System.out.println(bcbResponse.getMsgBcbresp().getMsgsistemaresp().getContenido().getValue().getValor().get(0));
		System.out.println("---------------------------------");
		try {
			System.out.println(bcbResponse.toString(bcbResponse.getMsgBcbresp()));
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// procedimiento para realizar la substitucion de un grupo

		// /fin

	}
}
