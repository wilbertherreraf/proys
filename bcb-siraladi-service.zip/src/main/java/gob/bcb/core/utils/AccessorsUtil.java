package gob.bcb.core.utils;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.*;

/**
 * @author Mauro
 * 
 */
public class AccessorsUtil {

	// convenience enumerations
	public final static int READ_ONLY = 0;
	public final static int READ_WRITE = 1;
	public final static String[] ACCESSORS = new String[] { "get", "set", "is" };
	public final static int GETTER = 0;
	public final static int SETTER = 1;
	public final static int GETTER_BOOLEAN = 2;

	public static final Class EMPTY_CLASS_ARRAY[] = new Class[0];

	/**
	 * private constructor - this class is not meant to be instantiated
	 */
	private AccessorsUtil() {
	}

	/**
	 * primitive types are not supported <br>
	 * <emph>all the available getter fields are returned</emph>
	 */
	public static String[] extractFields(Class anPojoClass) {
		List columnHeaders = new ArrayList();
		Method[] methods = anPojoClass.getDeclaredMethods();

		for (int i = 0; i < methods.length; i++) {
			String methodName = methods[i].getName();
			if (methodName.startsWith(ACCESSORS[GETTER]) && methodName.length() > 3)
				columnHeaders.add(extractFieldNameFromMethod(methodName));
			// cut "get"
		} // for

		String[] s = new String[columnHeaders.size()];
		columnHeaders.toArray(s);
		return s;
	}
	public static List extractFieldsList(Class anPojoClass) {
		List columnHeaders = new ArrayList();
		Method[] methods = anPojoClass.getDeclaredMethods();

		for (int i = 0; i < methods.length; i++) {
			String methodName = methods[i].getName();
			if (methodName.startsWith(ACCESSORS[GETTER]) && methodName.length() > 3)
				columnHeaders.add(extractFieldNameFromMethod(methodName));
			// cut "get"
		} // for

		String[] s = new String[columnHeaders.size()];
		columnHeaders.toArray(s);
		return columnHeaders;
	}	
	/**
	 * set a value into an FDT - whether an aggregate (i.e. dynamic) or static
	 * one.
	 * 
	 * @param field
	 *            the field in the FDT
	 * @param value
	 *            can be null
	 * @param data
	 */
	public static void set(String field, Object value, Object data) {
		String methodName = extractMethodNameFromField(field, ACCESSORS[SETTER]);
		Class valueClass = null;
		if (value == null) {
			valueClass = findInputTypeForMethod(methodName, data.getClass());
			value = null;
		} else
			valueClass = value.getClass();

		// static set
		Method m = null;
		try {
			m = data.getClass().getDeclaredMethod(methodName, new Class[] { valueClass });
		} catch (SecurityException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (NoSuchMethodException e1) {
			System.out.println("field \"" + field + "\" in " + data.getClass().getName() + " not found.");
			e1.printStackTrace();
		}
		invokeMethod(data, m, new Object[] { value });
	}

	/**
	 * returns the return type of the first method encountered in the definition
	 * of the given class, with the given name
	 * 
	 * <emph>at least one input parameter class is expected</emph>
	 * 
	 * @param methodName
	 *            "setName"
	 * @param class1
	 *            "AnExampleFDT"
	 * @return "java.lang.String"
	 */
	private static Class findInputTypeForMethod(String methodName, Class class1) {

		Method[] methpds = class1.getMethods();
		// System.out.println("findInputTypeForMethod("+methodName+", "+class1.getName());
		for (int i = 0; i < methpds.length; i++) {
			// System.out.println("findInputTypeForMethod("+i+")="+methpds[i].getName());
			if (methpds[i].getName().equals(methodName)) {
				// System.out.println("findInputTypeForMethod("+methodName+")= "+methpds[i].getParameterTypes()[0]);
				return methpds[i].getParameterTypes()[0];
			}
		}
		return null; //
	}

	/**
	 * basic get, with null default value
	 * 
	 * @param field
	 *            the field
	 * @param data
	 *            data
	 * @return teh value for that field
	 */
	public static Object get(String field, Object data) {
		return get(field, data, null);
	}

	/**
	 * 
	 * return the type of the given field name in the given FDT <br>
	 * <emph>all the available getter fields are returned</emph>
	 * 
	 * @param field
	 *            the field
	 * @param data
	 *            the data
	 * @return the returned class (null if not found)
	 */
	public static Class getClass(String field, Object data) {
		// assuming at least one can read that field
		// setXXX()-only methods are not permitted

		Class fieldTypeClass = null;

		// static set
		Method m = null;
		String methodName = extractMethodNameFromField(field, ACCESSORS[GETTER]);
		try {
			m = data.getClass().getDeclaredMethod(methodName, null);
		} catch (SecurityException e1) {
			e1.printStackTrace();
		} catch (NoSuchMethodException e1) {
			System.out.println("field \"" + field + "\" in " + data.getClass().getName() + " not found.");
			e1.printStackTrace();
		}
		fieldTypeClass = m != null ? m.getReturnType() : null;

		return fieldTypeClass;
	}

	/**
	 * extract a method name from a field name
	 * 
	 * @param field
	 *            "name"
	 * @param setOrGet
	 *            "set"
	 * @return "setName"
	 */
	private static String extractMethodNameFromField(String field, String setOrGet) {

		String localField = field.substring(field.indexOf('.') + 1);
		String methodName = setOrGet + Character.toUpperCase(localField.charAt(0)) + localField.substring(1);
		return methodName;
	}

	/**
	 * extract a field name from a method name <br>
	 * fields must be spelled as in the Java source file, (i.e. lowercase)
	 * 
	 * @param method
	 *            "isVisible"
	 * @return "visible"
	 */
	private static String extractFieldNameFromMethod(String method) {
		String localField = null;
		if (method.startsWith(ACCESSORS[GETTER]) || method.startsWith(ACCESSORS[SETTER]))
			localField = method.substring(3);
		else if (method.startsWith(ACCESSORS[GETTER_BOOLEAN]))
			localField = method.substring(2);

		return AccessorsUtil.decapitalizeFirst(localField);
	}

	/**
	 * get the value of a given field
	 * 
	 * @param field
	 *            "visible"
	 * @param data
	 *            "ExampleFDT"
	 * @param defaultValue
	 *            "true"
	 * @return the value for the given field in field
	 */
	public static Object get(String field, Object data, Object defaultValue) {
		String methodName = extractMethodNameFromField(field, ACCESSORS[GETTER]);

		Object returnedObj = null;
		Method m = null;

		// static get

		try {
			m = data.getClass().getMethod(methodName, null);
		} catch (SecurityException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (NoSuchMethodException e1) {
			System.out.println("FDTHAndler.get() NO such method accessing method " + m + " with method " + methodName + " on " + data);
			// e1.printStackTrace();
		} catch (Exception e1) {
			System.out.println("FDTHAndler.get() accessing method " + m + " with method " + methodName + " on " + data);
			e1.printStackTrace();

			returnedObj = invokeMethod(data, m, null);
		}
		return returnedObj == null ? defaultValue : returnedObj;
	}

	/**
	 * invoke a given method with the given input parameters
	 * 
	 * @param data
	 * @param m
	 *            method
	 * @param args
	 *            the arguments - null if none
	 * @return the result of the method invocation - null if void
	 */
	private static Object invokeMethod(Object data, Method m, Object[] args) {

		try {
			return m.invoke(data, args);
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			// System.out.println("FDTHAndler.get() accessing method "+m+" with method "+methodName);
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 
	 * 
	 * @param anFDTClass
	 * @return the classes of the fields in the given FDT
	 */
	public static Class[] extractFieldsClass(Object pojo) {
		return extractFieldsClass(pojo.getClass());
	}

	/**
	 * only getters modifiers are available
	 * 
	 * @param anFDTClass
	 * @return the classes of the fields in the given FDT
	 */
	public static Class[] extractFieldsClass(Class anFDTClass) {
		return AccessorsUtil.methodReturnTypesForPrefix(anFDTClass, ACCESSORS[GETTER]);
	}

	/**
	 * 
	 * @param aPojo
	 * @param globalFieldName
	 * @return
	 */
	public static String getLocalFieldName(Object aPojo, String globalFieldName) {
		String className = "";
		if (aPojo != null)
			className = aPojo.getClass().getName();
		int index = globalFieldName.indexOf('.') + 1;
		if (index == 0)
			return globalFieldName;
		String local = globalFieldName.substring(index);
		// System.out.println(local);
		return local;
	}

	/**
	 * convenience method that copies values from source to destination
	 * 
	 * @param string
	 * @param customerStuffFDT
	 * @param av
	 */
	public static void copy(String srcField, Object source, String destField, Object dest) {
		set(destField, get(srcField, source), dest);
	}

	public static String decapitalizeFirst(String aString) {
		char first = aString.charAt(0);
		if (Character.isLowerCase(first))
			return aString;
		return Character.toLowerCase(first) + aString.substring(1);
	}

	public static Class[] methodReturnTypesForPrefix(Class aClass, String prefix) {

		Collection returnTypes = new ArrayList();
		Method[] methods = aClass.getDeclaredMethods();

		for (int i = 0; i < methods.length; i++) {
			if (methods[i].getName().startsWith(prefix))
				returnTypes.add(methods[i].getReturnType());
		}

		Class[] s = new Class[returnTypes.size()];
		returnTypes.toArray(s);
		return s;
	}
public static void main(String[] args) {

}
}
