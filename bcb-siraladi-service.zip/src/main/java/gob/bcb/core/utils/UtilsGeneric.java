package gob.bcb.core.utils;

import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;

public final class UtilsGeneric {
	private static final String IP_REGEX = ".+@.+\\.[a-z]+";

	/**
	 * Generate a valid xs:ID string.
	 */

	public static String generateUUID() {
		return UUID.randomUUID().toString();
	}

	public static Object newInstance(String name) {
		try {
			Class<?> c = Class.forName(name);
			return c.newInstance();
		} catch (Exception e) {
			throw new RuntimeException("No se puede crear instancia de " + name, e);
		}
	}

	public static void validarEmail(String emailAddress) {
		if (StringUtils.isBlank(emailAddress)) {
			return;
		}
		Pattern mask = null;

		mask = Pattern.compile(IP_REGEX);
		Matcher matcher = mask.matcher(emailAddress);

		if (!matcher.matches()) {
			throw new RuntimeException("Direccion de correo invalido");
		}

	}

	public static String truncate(String string0, int maxLength, String suffix, boolean defaultTruncateAtWord) {
		if (StringUtils.isBlank(string0)){
			return null;
		}
		String string = StringUtils.trimToEmpty(string0);
		if (string.length() <= maxLength) {
			return string + suffix;
		}
		//System.out.println("VALOR:[" + string);		
		if (suffix == null || maxLength - suffix.length() <= 0) {
			// either no need or no room for suffix
			//System.out.println("AAAAA " + string.substring(0, maxLength));
			return StringUtils.trimToEmpty(string.substring(0, maxLength));
		}
		
		if (defaultTruncateAtWord) {
			// find the latest space within maxLength
			String sc = string.substring(0, maxLength+1);
			int lastSpace = sc.lastIndexOf(" ");			
			//int lastSpace = string.substring(0, maxLength - suffix.length() + 1).lastIndexOf(" ");
			//System.out.println(lastSpace + "] {" +sc+ "} ");			
			if (lastSpace > 0) {
				//return StringUtils.trimToEmpty(string.substring(0, lastSpace)) +suffix;
				//System.out.println(lastSpace + "] {" +sc+ "} " + StringUtils.trimToEmpty(string.substring(0, lastSpace)));
				return StringUtils.trimToEmpty(string.substring(0, lastSpace)) +suffix;
			}
		}
		// truncate to exact character and append suffix
		//System.out.println("CCC " + StringUtils.trimToEmpty(string.substring(0, maxLength - suffix.length())) + suffix);		
		return StringUtils.trimToEmpty(string.substring(0, maxLength)) + suffix;

	}

	public static String cell(Object obj, int cellsize, String suffix) {
		if (obj == null || cellsize <= 0) {
			return null;
		}

		String value = String.valueOf(obj);
		if (value.length() == cellsize) {
			return value;
		} else if (value.length() > cellsize) {
			return truncate(value, cellsize, suffix, true);
		} else {
			return value + space(cellsize - value.length());
		}
	}

	public static String space(int length) {
		if (length < 0) {
			return null;
		}

		StringBuilder space = new StringBuilder();
		for (int i = 0; i < length; i++) {
			space.append(' ');
		}
		return space.toString();
	}
	public static String newStringFromBytes(byte[] bytes, String charsetName) {
        try {
            return new String(bytes, charsetName);
        } catch (UnsupportedEncodingException e) {
            throw 
                new RuntimeException("Impossible failure: Charset.forName(\""
                                     + charsetName + "\") returns invalid name.");

        }
    }
	public static final Charset ISO_CHARSET = Charset.forName("UTF-8");
	public static String newStringFromString(String  cadena) {
		if (cadena == null)
			return null;
		return newStringFromBytes(cadena.getBytes(), ISO_CHARSET.name());
	}
	
	public static Map<String, String> paramsLista(String text) {
		// byte[] valueDecoded= Base64.decode(bytesEncoded);
		String params = new String(text);
		Map<String, String> map = new LinkedHashMap<String, String>();
		for (String keyValue : params.split(" *& *")) {
			String[] pairs = keyValue.split(" *= *", 2);
			map.put(pairs[0], pairs.length == 1 ? "" : pairs[1]);
		}
		return map;
	}
	
	public static void main(String[] args) throws UnsupportedEncodingException {
		String cad = "Ã‘JSLKJJKSJFLÑIFADAD";
		byte[] b = "Ã‘JSLKJJKSJFLÑIFADAD".getBytes("ISO-8859-1");
		System.out.println(new String(b,"ISO-8859-1"));
		System.out.println(new String(b,"UTF-8"));
		String encoding = System.getProperty("file.encoding", "Cp1252");
		System.out.println(encoding);
		String a = newStringFromString(cad);
		String at = newStringFromBytes(cad.getBytes(),"UTF-8");
		String aa = newStringFromString(a);		
		System.out.println(newStringFromBytes(cad.getBytes(),"UTF-8"));		
		System.out.println(newStringFromBytes(cad.getBytes(),"ISO-8859-1"));
		System.out.println(newStringFromBytes(cad.getBytes(),"Cp1252"));		
		  
		
	}

}
