package gob.bcb.core.utils;
import javax.xml.crypto.*;
import javax.xml.crypto.dsig.*;
import javax.xml.crypto.dom.*;
import javax.xml.crypto.dsig.dom.DOMValidateContext;
import javax.xml.crypto.dsig.keyinfo.*;
import java.io.FileInputStream;
import java.security.*;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

class SimpleKeySelectorResult implements KeySelectorResult {
   private PublicKey publicKey;

   SimpleKeySelectorResult(PublicKey pubKey)
   {
      publicKey = pubKey;
   }

   public Key getKey()
   {
      return(publicKey);
   }
}

public class KeyValueSelector extends KeySelector {
    public KeySelectorResult select(KeyInfo keyInfo, KeySelector.Purpose purpose, AlgorithmMethod algMethod, XMLCryptoContext xmlContext)
    throws KeySelectorException {

      if (keyInfo == null) {
        throw new KeySelectorException("keyInfo cannot be null");
      }

      SignatureMethod signatureMethod = (SignatureMethod)algMethod;
      List list = keyInfo.getContent();

      for (int i=0; i<list.size(); i++) {
         XMLStructure xmlStructure = (XMLStructure)list.get(i);

         if (xmlStructure instanceof KeyValue) {
            PublicKey pubKey = null;

            try {
               pubKey = ((KeyValue)xmlStructure).getPublicKey();
            } catch (KeyException ke) {
               throw new KeySelectorException(ke);
            }

            return new SimpleKeySelectorResult(pubKey);
         }
      }

      throw new KeySelectorException("KeyValue element not found");
   }
}

