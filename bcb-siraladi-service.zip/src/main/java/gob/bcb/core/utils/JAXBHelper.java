package gob.bcb.core.utils;

import javax.xml.bind.JAXBContext;
 
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;

import java.io.StringReader;
import java.net.URI;
import java.net.URISyntaxException;

/**
 * Created by IntelliJ IDEA. User: Kishore G Date: Jan 7, 2006 Time: 8:45:42 PM
 * To change this template use File | Settings | File Templates.
 */
public class JAXBHelper {

	public static String convertPackageFromXmlType(QName xmlType) throws Exception {
		StringBuffer stringBuffer = new StringBuffer();
		try {
			String host = new URI(xmlType.getNamespaceURI()).getHost();
			String[] strs = host.split("\\.");
			for (int i = strs.length - 1; i >= 0; i--) {
				String str = strs[i];

				stringBuffer.append(str + ((i == 0) ? "" : "."));
			}
			String path = new URI(xmlType.getNamespaceURI()).getPath();
			stringBuffer.append(path.replace('/', '.'));

		} catch (URISyntaxException e) {
			throw new Exception("Exception while getting package name from xmlType", e);
		}
		return stringBuffer.toString();
	}

	public static String getFullyQualifiedClassName(QName xmlType) throws Exception {

		return JAXBHelper.convertPackageFromXmlType(xmlType) + "." + getInitCap(xmlType.getLocalPart());
	}

	public static Object convertXMLToMsgBcb(String xmlRequest, JAXBContext jAXBContext) {
		Object value = null;
		try {
			Unmarshaller u = jAXBContext.createUnmarshaller();
			value = u.unmarshal(new StringReader(xmlRequest));

			if (value == null) {
				throw new RuntimeException("Request no contiene objeto definido en el servicio");
			}

		} catch (JAXBException e) {
			// log.error(e.getMessage(), e);
			throw new RuntimeException(e);
		}
		return value;
	}

	public static String getInitCap(String str) {

		return String.valueOf(str.charAt(0)).toUpperCase() + str.substring(1);
	}

	public static Document toDocument(Object value, DocumentBuilderFactory documentBuilderFactory, JAXBContext context) throws JAXBException,
			ParserConfigurationException {
		if (value == null) {
			throw new IllegalArgumentException("Cannot convert from null value to JAXBSource");
		}
		if (value.getClass().getAnnotation(XmlRootElement.class) != null) {
			// must create a new instance of marshaller as its not thread safe
			Marshaller marshaller = context.createMarshaller();

			Document doc = JAXBHelper.createDocument(documentBuilderFactory);

			marshaller.marshal(value, doc);
			return doc;
		} else {
			return null;
		}

	}

	public static Document createDocument(DocumentBuilderFactory factory) throws ParserConfigurationException {
		DocumentBuilder builder = createDocumentBuilder(factory);
		return builder.newDocument();
	}

	public static DocumentBuilder createDocumentBuilder(DocumentBuilderFactory factory) throws ParserConfigurationException {
		if (factory == null) {
			factory = JAXBHelper.createDocumentBuilderFactory();
		}
		return factory.newDocumentBuilder();
	}

	public static DocumentBuilderFactory createDocumentBuilderFactory() {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		factory.setIgnoringElementContentWhitespace(true);
		factory.setIgnoringComments(true);
		return factory;
	}

}
