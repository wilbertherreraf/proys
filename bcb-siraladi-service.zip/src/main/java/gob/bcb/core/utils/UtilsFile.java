package gob.bcb.core.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;

public final class UtilsFile {
	private static final Logger log = Logger.getLogger(UtilsFile.class);

	public static String readFileAsString(String filePath) throws java.io.IOException {
		String result = null;
		BufferedReader reader = null;
		try {
			StringBuffer fileData = new StringBuffer(1000);
			reader = new BufferedReader(new FileReader(filePath));
			char[] buf = new char[1024];
			int numRead = 0;
			while ((numRead = reader.read(buf)) != -1) {
				fileData.append(buf, 0, numRead);
			}
			reader.close();
			result = fileData.toString();
		} finally {
			try {
				reader.close();
			} catch (Exception e) {
				// no hacer nada
			}
		}
		return result;
	}

	public static String readFileAsString2(String filePath) {
		String result = null;
		File h = new File(filePath);
		if (!h.exists()) {
			throw new RuntimeException("Archivo inexistente " + filePath);
		}
		try {
			InputStream is = new FileInputStream(h);
			result = IOUtils.toString(is, "ISO-8859-1");
			is.close();
		} catch (FileNotFoundException e) {
			throw new RuntimeException("Archivo inexistente " + filePath);
		} catch (IOException e) {
			throw new RuntimeException("Error al leer " + filePath);
		}
		return result;
	}

	public static String copy(String filePath, String filePathO) throws IOException {
		FileReader fr = new FileReader(filePath);
		FileOutputStream archResp = new FileOutputStream(filePathO);
		IOUtils.copy(fr, archResp);
		fr.close();
		archResp.close();

		fr = new FileReader(filePath);
		FileReader fr2 = new FileReader(filePathO);
		boolean b = IOUtils.contentEquals(fr, fr2);

		System.out.println("Con IOUtils.copy FileReader " + b);

		fr.close();
		archResp.close();

		InputStream is = new FileInputStream(new File(filePath));
		InputStream iso = new FileInputStream(new File(filePathO));
		b = IOUtils.contentEquals(is, iso);

		System.out.println("Con IOUtils.copy FileReader " + b);

		is.close();
		iso.close();

		is = new FileInputStream(new File(filePath));

		OutputStream os = new FileOutputStream(new File(filePathO));
		IOUtils.copy(is, os);

		is.close();
		os.close();

		is = new FileInputStream(new File(filePath));
		iso = new FileInputStream(new File(filePathO));
		b = IOUtils.contentEquals(is, iso);

		System.out.println(b);

		is.close();
		iso.close();

		return null;
	}

	public static String copiarArchivo(String fileSource, String fileTarget, boolean compareFiles) throws IOException {
		log.info("Copiando archivo de " + fileSource + " => " + fileTarget);

		InputStream is = new FileInputStream(new File(fileSource));
		OutputStream os = new FileOutputStream(new File(fileTarget));
		try {
			int resp = IOUtils.copy(is, os);
			log.info("Copiando archivo resp " + resp);
		} finally {

			os.close();
			is.close();
		}
		
		if (compareFiles) {
			InputStream isin = new FileInputStream(new File(fileSource));
			InputStream iso = new FileInputStream(new File(fileTarget));
			boolean b = IOUtils.contentEquals(isin, iso);

			isin.close();
			iso.close();
			log.info("Archivo copiado (contentEquals) " + b);
		}

		return fileTarget;
		// } catch (Exception e) {
		// log.error("Exception al salvar archivo " + fileSource, e);
		// throw new RuntimeException(e.getMessage(), e);
		// }
	}

	public static String grabaEnArchivo(String mensaje, String path) throws RuntimeException {
		log.info("grabaEnArchivo: Guardando cadena en archivo " + path);
		FileOutputStream archResp = null;
		try {
			File d = new File(path);
			String directory = d.getParent();
			d = new File(directory);
			d.mkdirs();

			archResp = new FileOutputStream(path);
			byte buffer[] = mensaje.getBytes("ISO-8859-1");
			archResp.write(buffer);
			archResp.close();

			File h = new File(path);
			if (!h.exists() || h.isDirectory()) {
				throw new RuntimeException("Archivo no fue creado " + path);
			}
			log.info("Archivo salvado " + h.getAbsolutePath());
			log.info("Archivo salvado " + h.getCanonicalPath());			
			log.info("Archivo salvado " + h.getPath());
			return h.getCanonicalPath();
		} catch (IOException e) {
			log.error("Error al salvar archivo " + path, e);
			throw new RuntimeException(e.getMessage(), e);
		} catch (Exception e) {
			log.error("Exception al salvar archivo " + path, e);
			throw new RuntimeException(e.getMessage(), e);
		} 
		
	}

	public static String grabaEnArchivo2(InputStream is, String path) throws RuntimeException {
		FileOutputStream archResp = null;
		try {
			archResp = new FileOutputStream(path);
			byte buffer[] = null;

			archResp.write(buffer);
			archResp.close();

			File h = new File(path);
			if (!h.exists() || h.isDirectory()) {
				throw new RuntimeException("Archivo no fue creado " + path);
			}

		} catch (IOException exE) {
			throw new RuntimeException(exE);
		} finally {
			try {
				if (archResp != null)
					archResp.close();
			} catch (Exception e) {
				// no hacer nada
			}
		}
		return path;
	}

	public static String grabaStringEnArchivo(String mensaje, String path) {
		log.info("Guardando cadena en archivo " + path);
		InputStream is = IOUtils.toInputStream(mensaje);
		String pathNew = grabaEnArchivo(is, path);
		return pathNew;
	}

	public static String grabaEnArchivo(InputStream is, String path) throws RuntimeException {
		FileOutputStream archResp = null;
		try {
			log.info("Salvando archivo " + path);
			File d = new File(path);
			String directory = d.getParent();
			d = new File(directory);
			d.mkdirs();

			archResp = new FileOutputStream(path);
			int resp = IOUtils.copy(is, archResp);
			File h = new File(path);
			if (!h.exists() || h.isDirectory()) {
				throw new RuntimeException("Archivo no fue creado " + path);
			}
			return path;
		} catch (FileNotFoundException e) {
			throw new RuntimeException("Archivo no encontrado " + path, e);
		} catch (IOException e) {
			throw new RuntimeException("Archivo no fue creado " + path, e);
		} catch (Exception e) {
			throw new RuntimeException("Archivo no fue creado " + path, e);
		} finally {
			if (archResp != null) {
				try {
					archResp.close();
				} catch (IOException e) {
					log.warn("Error al cerrar stream " + e.getMessage());
				}
			}
		}

	}

	public static String getBasedir() {
		String basedirPath = System.getProperty("basedir");

		if (basedirPath == null) {
			basedirPath = new File("").getAbsolutePath();
		}

		return basedirPath;
	}

	public static List<String> listFilesForFolder(final File folder) {
		List<String> files = new ArrayList<String>();
		for (final File fileEntry : folder.listFiles()) {
			if (fileEntry.isDirectory()) {
				listFilesForFolder(fileEntry);
			} else {
				System.out.println(fileEntry.getName());
				files.add(fileEntry.getAbsolutePath());
			}
		}
		return files;
	}

	public static void main(String[] args) throws IOException {
		System.out.println(getBasedir());
		String archivoOut = "e://tmp//CL01FM.docx";
		copy(archivoOut, "e://tmp//CL01FM_copy.docx");
	}
}
