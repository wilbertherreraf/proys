function padSecuencia(obj, siguiente) {
	var txt = obj.value.toString();
	if (txt.length > 0) {
		obj.value = ('000000' + txt).substring(('000000' + txt).length - 6);
		document.getElementById(siguiente).value = "";
		document.getElementById(siguiente).focus();
	}
}

function saltar(obj, siguiente) {
	if (obj.value.length == obj.maxLength)
		document.getElementById(siguiente).focus();
}