package gob.bcb.core.jms.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.jms.Connection;
import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Session;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.MessageAvailableConsumer;
import org.apache.activemq.pool.PooledConnection;
import org.apache.activemq.pool.PooledConnectionFactory;
import org.apache.log4j.Logger;

public class JMSConnectionHandler {
	private static Logger log = Logger.getLogger(JMSConnectionHandler.class);
	private static PooledConnection connection;
	private Session session;
	private MessageProducer producer;
	private static PooledConnectionFactory pooledConnectionFactory;
	private int deliveryMode = DeliveryMode.NON_PERSISTENT;
	private transient Map<Destination, MessageConsumer> consumers = new HashMap<Destination, MessageConsumer>();

	public JMSConnectionHandler() {
		if (pooledConnectionFactory == null) {
			throw new IllegalStateException("initContext no fue ejecutado");
		}
	}

	public static synchronized void initContext(Map<String, String> prop) throws JMSException {
		if (pooledConnectionFactory == null) {
			log.info("inicializando objeto de conecciones JMS");
			ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory();
			if (!prop.containsKey("BrokerURL")) {
				throw new IllegalStateException("URL de ActiveMQ nulo");
			}
			connectionFactory.setBrokerURL(prop.get("BrokerURL"));

			if (prop.containsKey("UserName")) {
				connectionFactory.setUserName(prop.get("UserName"));
			}
			if (prop.containsKey("Password")) {
				connectionFactory.setPassword(prop.get("Password"));
			}
			if (prop.containsKey("prefetch")) {
				int prefetch = Integer.valueOf(prop.get("prefetch")).intValue();
				connectionFactory.getPrefetchPolicy().setAll(prefetch);
			} else {
				//connectionFactory.getPrefetchPolicy().setAll(10);
				connectionFactory.getPrefetchPolicy().setQueuePrefetch(1);
				connectionFactory.getPrefetchPolicy().setTopicPrefetch(100);
			}
			
			// OptimizeAcknowledge tiene valor de true o false
			if (prop.containsKey("OptimizeAcknowledge")) {
				boolean optimizeAck = Boolean.valueOf(prop.get("OptimizeAcknowledge")).booleanValue();
				connectionFactory.setOptimizeAcknowledge(optimizeAck);
			} else {
				connectionFactory.setOptimizeAcknowledge(false);
			}

			if (prop.containsKey("CopyMessageOnSend")) {
				boolean value = Boolean.valueOf(prop.get("CopyMessageOnSend")).booleanValue();
				connectionFactory.setCopyMessageOnSend(value);
			} else {
				connectionFactory.setCopyMessageOnSend(false);
			}

			if (prop.containsKey("AlwaysSessionAsync")) {
				boolean value = Boolean.valueOf(prop.get("AlwaysSessionAsync")).booleanValue();
				connectionFactory.setAlwaysSessionAsync(value);
			}

			try {
				log.info("Trying to build a PooledConnectionFactory");

				PooledConnectionFactory pcf = new PooledConnectionFactory();

				if (prop.containsKey("MaxConnections")) {
					int value = Integer.valueOf(prop.get("MaxConnections")).intValue();
					pcf.setMaxConnections(value);
				} else {
					pcf.setMaxConnections(3);
				}
				if (prop.containsKey("MaximumActive")) {
					int value = Integer.valueOf(prop.get("MaximumActive")).intValue();
					pcf.setMaximumActive(value);
				} else {
					pcf.setMaximumActive(5);
				}
				pcf.setConnectionFactory(connectionFactory);
				pooledConnectionFactory = pcf;
			} catch (Throwable t) {
				log.error("Could not create pooled connection factory: " + t, t);
			}

			if (pooledConnectionFactory == null) {
				throw new IllegalStateException("Unable to create pooled connection factory.  Enable DEBUG log level for more informations");
			}
			// pooledConnectionFactory.start();
			connection = (PooledConnection) pooledConnectionFactory.createConnection();
			connection.start();
			log.info("conexion JMS iniciada con ID " + connection.getClientID() + "\nMetadata: " + connection.getMetaData());
		}
	}

	public static synchronized void reConnect() throws JMSException {
		log.info("Intento de conexion JMS reconectar ");
		connection = (PooledConnection) pooledConnectionFactory.createConnection();
		connection.start();
		log.info("conexion JMS reconectada con ID " + connection.getClientID() + "\nMetadata: " + connection.getMetaData());
	}

	public static synchronized PooledConnectionFactory getPooledConnectionFactory() throws JMSException {
		log.debug("Obteniendo PooledConnectionFactory: brokerURL: ");

		if (pooledConnectionFactory == null) {
			throw new IllegalStateException("Metodo initContext no fue ejecutado");
		}

		return pooledConnectionFactory;
	}

	public Connection getConnection() throws JMSException {
		// if (connection == null) {
		try {
			log.info("Obteniendo nuevo objeto conection a broker JMS");
			// connection = (PooledConnection)
			// pooledConnectionFactory.createConnection();
			// connection.start();
			// log.info("nuevo objeto conection a broker JMS CREADO " +
			// connection.getMetaData());
		} catch (Exception e) {
			log.error("Error al obtener conecci�n a broker JMS " + e.getMessage(), e);
			throw new JMSException("Error al obtener conecci�n a broker JMS " + e.getMessage());
		}
		// }
		return connection;
	}

	public Session getSession() throws JMSException {
		if (session == null) {
			session = createSession();
		}
		return session;
	}

	protected Session createSession() throws JMSException {
		log.info("Solicitud de Nueva session JMS.");
		Session ses = null;
		ses = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
		session = ses;
		if (session == null) {
			throw new JMSException("No se pudo obtener session, posiblemente el servidor de Mensajer�a no este activo comunique al administrador");
		}
		return session;

	}

	/*
	 *  protected void finalize() throws Throwable {
	 * log.info("cerrando pool de conexiones a broker JMS");
	 * pooledConnectionFactory.stop(); super.finalize();
	 * 
	 * }
	 */

	public void destroy() throws Exception {
		log.info("cerrando pool de conexiones a broker JMS");

		if (pooledConnectionFactory != null) {
			pooledConnectionFactory.stop();
			pooledConnectionFactory = null;
		}
	}

	public void send(Destination destination, Message message) throws JMSException {
		getProducer().send(destination, message);
		if (log.isDebugEnabled()) {
			log.info("connection.getClientID() " + connection.getClientID() + "\nSent! to destination: " + destination + " message: " + message);
		}
	}

	public void send(Destination destination, Message message, boolean persistent, int priority, long timeToLive) throws JMSException {
		int deliveryMode = persistent ? DeliveryMode.PERSISTENT : DeliveryMode.NON_PERSISTENT;
		getProducer().send(destination, message, deliveryMode, priority, timeToLive);
		if (log.isDebugEnabled()) {
			log.debug("Sent! to destination: " + destination + " message: " + message);
		}
	}

	public synchronized MessageProducer getProducer() throws JMSException {
		if (producer == null) {
			producer = getSession().createProducer(null);
			producer.setDeliveryMode(deliveryMode);
			log.info("Producer message creado");
		}
		return producer;
	}

	public void setProducer(MessageProducer producer) {
		this.producer = producer;
	}

	public synchronized MessageConsumer getConsumer(Destination destination) throws JMSException {
		return getConsumer(destination, true);
	}

	public synchronized MessageConsumer getConsumer(Destination destination, boolean create) throws JMSException {
		MessageConsumer consumer = consumers.get(destination);
		if (create && consumer == null) {
			consumer = getSession().createConsumer(destination);
			consumers.put(destination, consumer);
			log.info("Consumer message creado: " + consumer);			
		}
		return consumer;
	}

	public synchronized void closeConsumers() {
		for (Iterator<MessageConsumer> it = consumers.values().iterator(); it.hasNext();) {
			MessageConsumer consumer = it.next();
			it.remove();
			try {
				consumer.setMessageListener(null);
				if (consumer instanceof MessageAvailableConsumer) {
					((MessageAvailableConsumer) consumer).setAvailableListener(null);
				}
				consumer.close();
				log.info("Consumers cerrados");				
			} catch (JMSException e) {
				log.error("caught exception closing consumer", e);
			}
		}
	}

	public synchronized void closeConsumer(Destination destination) throws JMSException {
		MessageConsumer consumer = consumers.get(destination);
		if (consumer != null) {
			consumers.remove(destination);
			consumer.setMessageListener(null);
			if (consumer instanceof MessageAvailableConsumer) {
				((MessageAvailableConsumer) consumer).setAvailableListener(null);
			}
			consumer.close();
		}
	}

	public synchronized void close() {
		try {
			closeConsumers();
			if (connection != null) {
				connection.close();
			}
		} catch (Exception e) {
			log.error("caught exception closing consumer", e);
		} finally {
			producer = null;
			session = null;
			connection = null;
			if (consumers != null) {
				consumers.clear();
			}
			consumers = null;
		}
	}

	public boolean isClosed() {
		return consumers == null;
	}

	public synchronized List<MessageConsumer> getConsumers() {
		return new ArrayList<MessageConsumer>(consumers.values());
	}

	public int getDeliveryMode() {
		return deliveryMode;
	}

	public void setDeliveryMode(int deliveryMode) {
		this.deliveryMode = deliveryMode;
	}

	public static void main(String[] args) {
		AtomicBoolean ai = new AtomicBoolean(false);
		System.out.println(ai);
		ai.get();
		System.out.println(ai);
	}
}
