package gob.bcb.portal.sirAladi.view.parametricas;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import gob.bcb.bpm.siraladi.jpa.Horario;
import gob.bcb.bpm.siraladi.jpa.HorarioPK;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;

import org.apache.log4j.Logger;

public class HorarioController extends BaseBeanController {
	private static Logger log = Logger.getLogger(HorarioController.class);
	
	private Horario horarioSelected = new Horario();
	private List<Horario> horarioLista = new ArrayList<Horario>();

	@PostConstruct
	public void init() {
		log.info("Iniciando el modulo de adm swift");
		recuperarVisit();

		recuperarDatos();
	}

	private void recuperarDatos() {
		horarioLista = getServiceDao().getHorarioLocal().getSocHorarioList();
		
		HorarioPK horarioPK = new HorarioPK();
		horarioSelected = new Horario();
		horarioSelected.setId(horarioPK);
		
	}

	public void botonSelectItemEdit(Horario horarioSel) {
		log.info("botonSelectItemEdit " + horarioSel.toString());
		horarioSelected = getServiceDao().getHorarioLocal().findByCodigo(horarioSel.getId().getCodOperacion(), horarioSel.getId().getCodHorario());
	}

	public void guardarRegistro() {
		try {
			log.info("Salvando registro " + horarioSelected.getId().getCodOperacion());
			horarioSelected.setEstacion(getVisit().getAddress());
			horarioSelected.setCodUsuario(getVisit().getUsuarioSirAladi().getLogin());
			horarioSelected = getServiceDao().getHorarioLocal().saveorupdate(horarioSelected);
			log.info("Registro actualizado " + horarioSelected.getId().getCodOperacion());
			addMessageInfo("Aviso", "Registro actualizado " + horarioSelected.getId().getCodOperacion());
		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
		recuperarDatos();
	}

	public Horario getHorarioSelected() {
		return horarioSelected;
	}

	public void setHorarioSelected(Horario HorarioSelected) {
		this.horarioSelected = HorarioSelected;
	}

	public List<Horario> getHorarioLista() {
		return horarioLista;
	}

	public void setHorarioLista(List<Horario> HorarioLista) {
		this.horarioLista = HorarioLista;
	}

}
