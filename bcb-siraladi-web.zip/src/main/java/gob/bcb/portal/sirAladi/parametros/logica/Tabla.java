/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-portletBase
 * gob.bcb.portal.sirAladi.parametros.logica.Tabla
 * 08/06/2011 - 15:34:27
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.parametros.logica;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.SerializationUtils;

/**
 * Clase que representa los datos generales de una
 * tabla parametrica.
 *
 * @author wherrera
 *
 */

public class Tabla
{
	private String idTabla;
	private String nombreTabla;
	private String descripcionTabla;
	private boolean visible;
	private boolean insert;
	private boolean update;
	private boolean delete;
	private String where;
	private List<Columna> columnas;
	private MaestroDetalle maestroDetalle;
	
	public Tabla(){}
	
	public Tabla(Object idTabla, Object nombreTabla, Object descripcionTabla,
			Object visible, Object insert, Object update, Object delete, Object where,
			List<Columna> columnas, MaestroDetalle maestroDetalle)
	{
		this.idTabla = ((String) idTabla).trim();
		this.nombreTabla = ((String) nombreTabla).trim();
		this.descripcionTabla = ((String) descripcionTabla).trim();
		String strVisible = ((String) visible).trim();
		String strInsert = ((String) insert).trim();
		String strUpdate = ((String) update).trim();
		String strDelete = ((String) delete).trim();
		this.visible = strVisible.equalsIgnoreCase("SI");
		this.insert = strInsert.equalsIgnoreCase("SI");
		this.update = strUpdate.equalsIgnoreCase("SI");
		this.delete = strDelete.equalsIgnoreCase("SI");
		this.where = ((String) where).trim();
		if (this.where.length() == 0)
			this.where = null;
		this.columnas = columnas;
		this.maestroDetalle = maestroDetalle;
	}

	public String getIdTabla()
	{
		return idTabla;
	}
	public String getNombreTabla()
	{
		return nombreTabla;
	}
	public String getDescripcionTabla()
	{
		return descripcionTabla;
	}
	public boolean isVisible()
	{
		return visible;
	}
	public boolean isInsert()
	{
		return insert;
	}
	public boolean isUpdate()
	{
		return update;
	}
	public boolean isDelete()
	{
		return delete;
	}
	public String getWhere()
	{
		return where;
	}
	public List<Columna> getColumnas()
	{
		return columnas;
	}
	public MaestroDetalle getMaestroDetalle()
	{
		return maestroDetalle;
	}
	
	public boolean esMaestroDetalle() {
		return (this.maestroDetalle != null);
	}

	/**
	 * Metodo que obtiene el numero de columnas visibles.
	 *
	 * @return
	 */
	public int getNroColumnasVisibles()
	{
		int nroColumnas = 0;
		for (Columna columna : this.columnas)
		{
			if(columna.isVisible())			
				nroColumnas ++;
		}
		return nroColumnas;
	}
	
	/**
	 * Metodo que obtiene el numero de permisos para realizar operaciones sobre una tabla	 
	 *
	 * @return
	 */
	public int getNroPermisosABM()
	{
		int nroPermisos = 0;
		if (this.isUpdate())
			nroPermisos++;
		if (this.isDelete())
			nroPermisos++;
		return nroPermisos;
	}

	/**
	 * Metodo que realiza una copia de las columans de una tabla	 
	 *
	 * @return
	 */
	public List<Columna> clonarColumnas()
	{
		List<Columna> copiaColumnas = new ArrayList<Columna>();
		copiaColumnas.add(null);
		for (Columna columna : this.columnas)		
			copiaColumnas.add((Columna) SerializationUtils.clone(columna));
		return copiaColumnas;
	}
}
