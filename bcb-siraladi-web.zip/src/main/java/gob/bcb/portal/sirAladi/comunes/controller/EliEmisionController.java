/**
 * La Paz - Bolivia
 * bcb-portal-sirAladi
 * gob.bcb.portal.sirAladi.comunes.controller.EliEmisionController
 * 15/07/2011 - 15:30:12
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.comunes.controller;

import static gob.bcb.portal.sirAladi.commons.AladiUtils.getAlertJS;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.getCierreModalPanelJS;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTADO_VIGENTE;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTILO_INVISIBLE;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTILO_VISIBLE;
import static gob.bcb.portal.sirAladi.commons.Constantes.SUCCESS;
import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.Identificador;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Instrumento;
import gob.bcb.bpm.siraladi.jpa.Registro;
import gob.bcb.bpm.siraladi.pojo.StatusResponse;
import gob.bcb.bpm.siraladi.pojo.UsuarioSirAladi;
import gob.bcb.portal.sirAladi.commons.Servicios;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;
import gob.bcb.portal.sirAladi.controller.MainAladiController;
import gob.bcb.portal.sirAladi.dao.DaoFactory;
import gob.bcb.portal.sirAladi.dao.SirAladiDao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

/**
 * Backing Bean de la vista de emisi�n de exportaci�n.
 * 
 * @author wherrera
 * 
 */
public class EliEmisionController extends BaseBeanController {
	private String tipoOperacion;
	private String filtro;
	private String msj;
	private boolean mostrarModal;

	private Apertura apertura;
	private Registro registro;
	private UsuarioSirAladi usuario;

	private SirAladiDao sirAladiDao;
	private List<Apertura> aperturas;
	private List<Apertura> aperturasInicial;

	private static Logger log = Logger.getLogger(EliEmisionController.class);

	public EliEmisionController() {

	}

	@PostConstruct
	public void init() {
		log.info("Iniciando el modulo de eliminacion de emisiones pendientes.");
		recuperarVisit();
		this.sirAladiDao = DaoFactory.getInstance().getSirAladiDao();
		this.usuario = MainAladiController.getDatosDelUsuario();
		this.tipoOperacion = MainAladiController.getTipoOperacionPaginaActual();
		this.crearObjetosPorDefecto();
		this.consultarAperturas();
		if (this.aperturas == null || this.aperturas.size() == 0)
			mostrarModal = false;
	}

	public Apertura getApertura() {
		return apertura;
	}

	public void setApertura(Apertura apertura) {
		this.apertura = apertura;
	}

	public Registro getRegistro() {
		return registro;
	}

	public void setRegistro(Registro registro) {
		this.registro = registro;
	}

	public String getMsj() {
		return msj;
	}

	public void setMsj(String msj) {
		this.msj = msj;
	}

	public boolean isMostrarModal() {
		return mostrarModal;
	}

	public String getFiltro() {
		return filtro;
	}

	public void setFiltro(String filtro) {
		this.filtro = filtro;
	}

	public String getTipoOperacion() {
		return tipoOperacion;
	}

	public List<Apertura> getAperturas() {
		return aperturas;
	}

	public void setAperturas(List<Apertura> aperturas) {
		this.aperturas = aperturas;
	}

	public String getEstiloMostrarEmision() {
		return (this.apertura != null && this.apertura.getNroMov() != null && this.apertura.getNroMov() > 0) ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	public String getEstiloPaginacionAperturas() {
		return (this.aperturas != null && this.aperturas.size() > 10) ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	public String getEstiloGrillaPendientes() {
		return (this.aperturas != null && this.aperturas.size() > 0) ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	public String getEstiloMsjSinPendientes() {
		return (this.aperturas != null && this.aperturas.size() > 0) ? ESTILO_INVISIBLE : ESTILO_VISIBLE;
	}

	public void eliminarAnularEmision(ActionEvent event) {
		this.msj = "";
		boolean esEliminacion = event.getComponent().getId().equals("btnEliminar");
		StatusResponse statusResponse = null;
		try {
			if (esEliminacion)
				statusResponse = Servicios.eliminarEmision(this.apertura);
			else
				statusResponse = Servicios.anularEmision(this.apertura);
			if (SUCCESS.equalsIgnoreCase(statusResponse.getStatusCode()) && esEliminacion)
				this.apertura = new Apertura();
			log.info(statusResponse.getDescrip());
		} catch (Exception e) {
			statusResponse = new StatusResponse("Error al eliminar la emisi�n.");
			e.printStackTrace();
		}
		this.msj = getAlertJS(statusResponse);
	}

	public void consultarAperturas(ActionEvent event) {
		this.consultarAperturas();
	}

	private void consultarAperturas() {
		this.msj = "";
		this.filtro = "";
		this.aperturasInicial = this.sirAladiDao.getAperturas(this.tipoOperacion, ESTADO_VIGENTE, null, null, this.usuario.getPersona(), null, null, null);
		this.aperturas = this.aperturasInicial;
	}

	public void seleccionarApertura(Apertura aperturaSel)
	{
		log.info("XXX: aperturaSel " + aperturaSel.getCodigoReembolsoCorrido());
		this.msj = "";
		this.mostrarModal = false;
		this.apertura = aperturaSel;
		this.registro = this.sirAladiDao.getRegistroEmision(this.apertura.getNroMov());
		this.aperturas.clear();
		this.aperturasInicial.clear();
		this.msj = getCierreModalPanelJS("modalPanelEmisiones");
	}

	public void mostrarReporte(ActionEvent event) {
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("NRO_MOV", this.apertura.getNroMov());
		parametros.put("TITULO", "EMISION DE INSTRUMENTO");
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("pathTranslated", request.getPathTranslated());
		request.getSession().setAttribute("nombreReporte", "repApertura.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}

	public void mostrarAdjunto(ActionEvent event) {
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("nroMov", this.apertura.getNroMov());
	}

	public void filtrar(ActionEvent event) {
		if (StringUtils.isEmpty(this.filtro))
			this.aperturas = this.aperturasInicial;
		else {
			this.aperturas = new ArrayList<Apertura>();
			for (Apertura ap : this.aperturasInicial) {
				if (ap.getCodigoReembolso().indexOf(this.filtro.trim()) >= 0)
					this.aperturas.add(ap);
			}
		}
	}

	private void crearObjetosPorDefecto() {
		this.msj = "";
		this.mostrarModal = true;

		// Pendientes
		this.aperturas = new ArrayList<Apertura>();

		// Apertura
		this.apertura = new Apertura();
		this.apertura.setIdentificador(new Identificador());
		this.apertura.setInstitucion(new Institucion());

		// Registro
		this.registro = new Registro();
		this.registro.setInstrumento(new Instrumento());
		this.registro.setInstitucion(new Institucion());
	}

}
