/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-web-sirAladi
 * gob.bcb.portal.sirAladi.consultas.controller.ActualizarInstitucionesController
 * 04/10/2011 - 10:56:28
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.operacionesBCB.controller;

import static gob.bcb.portal.sirAladi.commons.AladiUtils.getAlertJS;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTILO_INVISIBLE;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTILO_VISIBLE;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.pojo.StatusResponse;
import gob.bcb.portal.sirAladi.commons.Servicios;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.event.ActionEvent;

import org.apache.log4j.Logger;

/**
 * Backing bean de la vista de consulta de instituciones Autorizadas
 * 
 * @author wherrera
 * 
 */
public class ActualizarInstitucionesController extends BaseBeanController {
	private String msj;
	private boolean desabilitado;

	private List<Institucion> listaInstituciones;

	private static Logger log = Logger.getLogger(ActualizarInstitucionesController.class);

	public ActualizarInstitucionesController() {
	}

	@PostConstruct
	public void init() {
		log.info("Iniciando el modulo de actualizacion de instituciones.");
		recuperarVisit();
		this.setearValoresPorDefecto();

	}

	public List<Institucion> getListaInstituciones() {
		return listaInstituciones;
	}

	public void setListaInstituciones(List<Institucion> listaInstituciones) {
		this.listaInstituciones = listaInstituciones;
	}

	public boolean isDesabilitado() {
		return desabilitado;
	}

	public void setDesabilitado(boolean desabilitado) {
		this.desabilitado = desabilitado;
	}

	public boolean isHabilitado() {
		return !desabilitado;
	}

	public String getMsj() {
		return msj;
	}

	public void setMsj(String msj) {
		this.msj = msj;
	}

	public String getEstiloPaginacionInstituciones() {
		return (this.listaInstituciones != null && this.listaInstituciones.size() > 15) ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	public String getEstiloBuscar() {
		return this.desabilitado ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	public String getEstiloLimpiar() {
		return this.desabilitado ? ESTILO_INVISIBLE : ESTILO_VISIBLE;
	}

	@SuppressWarnings("unchecked")
	public void recuperarInstituciones(ActionEvent event) {
		this.msj = "";
		StatusResponse statusResponse = Servicios.getInstitucionesAutorizadas();
		this.listaInstituciones = (List<Institucion>) statusResponse.getContenido().get("institucionesAutorizadas");
		if (this.listaInstituciones != null && this.listaInstituciones.size() > 0)
			this.desabilitado = false;
		else
			this.msj = getAlertJS(statusResponse);
	}

	public void aceptarInstituciones(ActionEvent event) {
		StatusResponse statusResponse = Servicios.guardarInstitucionesAutorizadas(this.listaInstituciones);
		this.msj = getAlertJS(statusResponse);
	}

	public void limpiar(ActionEvent event) {
		this.msj = "";
		this.setearValoresPorDefecto();
	}

	private void setearValoresPorDefecto() {
		this.msj = null;
		this.desabilitado = true;
		this.listaInstituciones = null;
	}

}
