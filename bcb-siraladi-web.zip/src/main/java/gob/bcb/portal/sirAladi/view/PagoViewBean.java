package gob.bcb.portal.sirAladi.view;

import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarMapDescripcionClaves;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarMapInstrumentos;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.getAlertConCierreModalJS;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.getAlertJS;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_ESTADO_APERTURA;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_ESTADO_PAGO;
import static gob.bcb.portal.sirAladi.commons.Constantes.SUCCESS;
import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.Instrumento;
import gob.bcb.bpm.siraladi.jpa.Pago;
import gob.bcb.bpm.siraladi.jpa.Registro;
import gob.bcb.bpm.siraladi.pojo.StatusResponse;
import gob.bcb.portal.sirAladi.commons.Servicios;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

public class PagoViewBean extends BaseBeanController {
	private static Logger log = Logger.getLogger(PagoViewBean.class);
	private Apertura apertura;
	private Registro registro;
	private Pago pago;
	private List<Pago> pagoList;
	private List<SelectItem> itemsConcepto;

	private BigDecimal totalDebito;
	private String concepto;
	private String msj;
	private boolean esAnulacion;

	private Map<String, Instrumento> mapInstrumentos;
	private Map<String, String> mapClavesEstadoPago;
	private Map<String, String> mapClavesEstadoApertura;

	private static final String CAPITAL = "CA";
	private static final String INTERES = "IN";
	private static final String COMISIONES_Y_GASTOS = "CG";
	private static final String EXTORNO = "EXT";
	private static final String REVERSO_LEX = "ALE";

	public PagoViewBean() {
	}

	@PostConstruct
	public void init() {
		log.info("Iniciando el modulo de pagos/cobros.");
		recuperarVisit();
		crearObjetosPorDefecto();
		if (getVisit().getParametro("SIRWEB_TMP_OBJECT") != null) {
			if (!(getVisit().getParametro("SIRWEB_TMP_OBJECT") instanceof PagoViewBean)) {
				//getVisit().removeParametro("SIRWEB_TMP_OBJECT");
			} else {
				PagoViewBean objeto = (PagoViewBean) getVisit().getParametro("SIRWEB_TMP_OBJECT");
				pago = objeto.getPago();
				concepto = objeto.getConcepto();
			}
		}

		if (getVisit().getCurrentApertura() != null) {
			apertura = getSirAladiDao().getApertura(getVisit().getCurrentApertura().getNroMov());
			recuperarPagos();
		}
	}

	private void recuperarPagos() {
		registro = getSirAladiDao().getRegistroEmision(apertura.getNroMov());
		pagoList = getSirAladiDao().getPagos(apertura.getNroMov());
		this.totalDebito = BigDecimal.ZERO;
		if (pagoList != null && pagoList.size() > 0) {
			for (Pago p : pagoList)
				this.totalDebito = this.totalDebito.add(p.getHaberMo().subtract(p.getDebeMo()));
		}
		// obtenerDatosParametricos();
		String codInstrumento = this.registro.getInstrumento().getCodInstrumento().trim();
		this.itemsConcepto = new ArrayList<SelectItem>();
		this.itemsConcepto.add(new SelectItem(CAPITAL, "Capital"));
		if (codInstrumento.equals("CC") || codInstrumento.equals("CD") || codInstrumento.equals("OD") || codInstrumento.equals("LA"))
			this.itemsConcepto.add(new SelectItem(INTERES, "Inter�s"));
		this.itemsConcepto.add(new SelectItem(COMISIONES_Y_GASTOS, "Comisi�n y Gastos"));

	}
	public void nuevoDebito() {
		log.info("nuevo pago ");		
		this.esAnulacion = false;
			pago = new Pago();
			pago.setCodUsuario(getVisit().getUsuarioSirAladi().getLogin());
			pago.setEstacion(getVisit().getAddress());
			pago.setInstitucion(this.registro.getInstitucion());
			pago.setInstrumento(new Instrumento());
			pago.setNit(this.registro.getNit());
			this.concepto = null;
		getVisit().setParametro("SIRWEB_TMP_OBJECT", this);
	}
	
	public void modificarDebito(Pago pagoSel) {
		log.info("modificar pago " + pagoSel.getNroMov());		
		this.esAnulacion = false;
			pago = pagoSel;
			if (pago.getDebeMo().compareTo(BigDecimal.ZERO) > 0) {
				pago.setHaberMo(pago.getDebeMo().multiply(new BigDecimal(-1)));
				pago.setDebeMo(BigDecimal.ZERO);
			}
			String codInstrumento = pago.getInstrumento().getCodInstrumento().trim();

			if (((codInstrumento.equals(EXTORNO) || codInstrumento.equals(REVERSO_LEX)))) {
				this.esAnulacion = true;
				pago.setInstrumento(this.mapInstrumentos.get(EXTORNO));
			} else {
				if (codInstrumento.equals(COMISIONES_Y_GASTOS))
					this.concepto = COMISIONES_Y_GASTOS;
				else if (codInstrumento.endsWith("I"))
					this.concepto = INTERES;
				else
					this.concepto = CAPITAL;
			}


		getVisit().setParametro("SIRWEB_TMP_OBJECT", this);
	}
	public void anularDebito(Pago pagoSel) {
		log.info("anular pago " + pagoSel.getNroMov());		
		this.esAnulacion = false;
			pago = pagoSel;
			if (pago.getDebeMo().compareTo(BigDecimal.ZERO) > 0) {
				pago.setHaberMo(pago.getDebeMo().multiply(new BigDecimal(-1)));
				pago.setDebeMo(BigDecimal.ZERO);
			}

				this.esAnulacion = true;
				pago.setInstrumento(this.mapInstrumentos.get(EXTORNO));

		getVisit().setParametro("SIRWEB_TMP_OBJECT", this);
	}
	
	public void registrarDebito(ActionEvent event) {
		this.msj = "";

		if (pago.getHaberMo().compareTo(BigDecimal.ZERO) >= 0)
			pago.setDebeMo(BigDecimal.ZERO);
		else {
			pago.setDebeMo(pago.getHaberMo().abs());
			pago.setHaberMo(BigDecimal.ZERO);
		}

		StatusResponse statusResponse;
		if (pago.getNroMov() != null && pago.getNroMov() > 0 && !this.esAnulacion)
			statusResponse = Servicios.modificarDebitoReembolso(this.apertura, pago);
		else
			statusResponse = Servicios.registrarDebitoReembolso(this.apertura, pago);

		if (SUCCESS.equals(statusResponse.getStatusCode())) {
			this.msj = getAlertConCierreModalJS("panelDebito", statusResponse);
			getVisit().removeParametro("SIRWEB_TMP_OBJECT");
		} else
			this.msj = getAlertJS(statusResponse);
	}
	public void autorizarDebito(Pago pagoSel) {
		log.info("Autorizar Pago " + pagoSel.getNroMov());
		this.msj = "";
		pago = pagoSel;
		StatusResponse statusResponse = null;

			pago.setCveEstadoPago("C");
			statusResponse = Servicios.modificarDebitoReembolso(this.apertura, pago);

		if (statusResponse != null && statusResponse.getStatusCode().equals(SUCCESS)) {
			this.recuperarPagos();
		}
		this.msj = getAlertJS(statusResponse);
	}

	public void eliminarDebito(Pago pagoSel) {
		log.info("eliminar Pago " + pagoSel.getNroMov());		
		this.msj = "";
		pago = pagoSel;
		StatusResponse statusResponse = null;

			statusResponse = Servicios.eliminarDebitoReembolso(this.apertura, pago);

		if (statusResponse != null && statusResponse.getStatusCode().equals(SUCCESS)) {
			this.recuperarPagos();
		}
		this.msj = getAlertJS(statusResponse);
	}	

	public void preAutorizarDebito(Pago pagoSel) {
		log.info("pre autorizar Pago " + pagoSel.getNroMov());		
		this.msj = "";
		pago = pagoSel;
		StatusResponse statusResponse = null;

		pago.setCveEstadoPago("1");
		statusResponse = Servicios.modificarDebitoReembolso(this.apertura, pago);

		if (statusResponse != null && statusResponse.getStatusCode().equals(SUCCESS)) {
			this.recuperarPagos();
		}
		this.msj = getAlertJS(statusResponse);
	}

	public boolean isPuedeNegociar() {
		return (this.apertura != null && this.apertura.getIdentificador() != null && this.apertura.getIdentificador().getCodId() != null && "1"
				.equals(this.apertura.getIdentificador().getCodId().trim()));
	}

	private void crearObjetosPorDefecto() {
		// Debitos (Pagos)
		pagoList = new ArrayList<Pago>();
		// combos vacios
		this.itemsConcepto = new ArrayList<SelectItem>();
		// mapas de estados e instrumentos
		this.mapInstrumentos = armarMapInstrumentos(getSirAladiDao().getInstrumentos());
		this.mapClavesEstadoPago = armarMapDescripcionClaves(getSirAladiDao().getClaves(CVE_ESTADO_PAGO));
		this.mapClavesEstadoApertura = armarMapDescripcionClaves(getSirAladiDao().getClaves(CVE_ESTADO_APERTURA));
	}

	public void seleccionarConcepto(ActionEvent event) {
		if (this.concepto.equals(CAPITAL))
			pago.setInstrumento(this.registro.getInstrumento());
		else if (this.concepto.equals(INTERES))
			pago.setInstrumento(this.mapInstrumentos.get(registro.getInstrumento().getCodInstrumento().trim() + "I"));
		else if (this.concepto.equals(COMISIONES_Y_GASTOS))
			pago.setInstrumento(mapInstrumentos.get(COMISIONES_Y_GASTOS));

		getVisit().setParametro("SIRWEB_TMP_OBJECT", this);
	}

	public void mostrarReporte(ActionEvent event) {
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("NRO_MOV", this.apertura.getNroMov());
		parametros.put("TITULO", (apertura.getCveTipoApe().trim().equals("I")) ? "DEBITOS" : "REEMBOLSOS");
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("pathTranslated", request.getPathTranslated());
		request.getSession().setAttribute("nombreReporte", "repPagosCobros.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}

	public Apertura getApertura() {
		return apertura;
	}

	public void setApertura(Apertura apertura) {
		this.apertura = apertura;
	}

	public Registro getRegistro() {
		return registro;
	}

	public void setRegistro(Registro registro) {
		this.registro = registro;
	}

	public Pago getPago() {
		return pago;
	}

	public void setPago(Pago pago) {
		this.pago = pago;
	}

	public List<Pago> getPagoList() {
		return pagoList;
	}

	public void setPagoList(List<Pago> pagoList) {
		this.pagoList = pagoList;
	}

	public List<SelectItem> getItemsConcepto() {
		return itemsConcepto;
	}

	public void setItemsConcepto(List<SelectItem> itemsConcepto) {
		this.itemsConcepto = itemsConcepto;
	}

	public BigDecimal getTotalDebito() {
		return totalDebito;
	}

	public void setTotalDebito(BigDecimal totalDebito) {
		this.totalDebito = totalDebito;
	}

	public String getConcepto() {
		return concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public String getMsj() {
		return msj;
	}

	public void setMsj(String msj) {
		this.msj = msj;
	}

	public boolean isEsAnulacion() {
		return esAnulacion;
	}

	public void setEsAnulacion(boolean esAnulacion) {
		this.esAnulacion = esAnulacion;
	}

	public Map<String, Instrumento> getMapInstrumentos() {
		return mapInstrumentos;
	}

	public void setMapInstrumentos(Map<String, Instrumento> mapInstrumentos) {
		this.mapInstrumentos = mapInstrumentos;
	}

	public Map<String, String> getMapClavesEstadoPago() {
		return mapClavesEstadoPago;
	}

	public void setMapClavesEstadoPago(Map<String, String> mapClavesEstadoPago) {
		this.mapClavesEstadoPago = mapClavesEstadoPago;
	}

	public Map<String, String> getMapClavesEstadoApertura() {
		return mapClavesEstadoApertura;
	}

	public void setMapClavesEstadoApertura(Map<String, String> mapClavesEstadoApertura) {
		this.mapClavesEstadoApertura = mapClavesEstadoApertura;
	}

}
