/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-sirAladi
 * gob.bcb.portal.sirAladi.commons.Servicios
 * 26/07/2011 - 14:35:05
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.commons;

import static gob.bcb.portal.sirAladi.commons.Constantes.ANULAR_EMISION;
import static gob.bcb.portal.sirAladi.commons.Constantes.CONSULTAR_INSTITUCIONES_AUTORIZADAS;
import static gob.bcb.portal.sirAladi.commons.Constantes.CONSULTAR_PAGOS_ALADI;
import static gob.bcb.portal.sirAladi.commons.Constantes.CONSULTAR_SALDOS_CONVENIO;
import static gob.bcb.portal.sirAladi.commons.Constantes.ELIMIAR_PAGO_ANTICIPADO;
import static gob.bcb.portal.sirAladi.commons.Constantes.ELIMINAR_DEBITO_REEMBOLSO;
import static gob.bcb.portal.sirAladi.commons.Constantes.ELIMINAR_EMISION;
import static gob.bcb.portal.sirAladi.commons.Constantes.ELIMINAR_OPERACION_NO_REGISTRADA;
import static gob.bcb.portal.sirAladi.commons.Constantes.ELIMINAR_REGISTRO;
import static gob.bcb.portal.sirAladi.commons.Constantes.ENVIAR_PLAN_PAGOS_A_ALADI;
import static gob.bcb.portal.sirAladi.commons.Constantes.GUARDAR_INSTITUCIONES_AUTORIZADAS;
import static gob.bcb.portal.sirAladi.commons.Constantes.GUARDAR_OPERACION_NO_REGISTRADA;
import static gob.bcb.portal.sirAladi.commons.Constantes.MODIFICAR_APERTURA;
import static gob.bcb.portal.sirAladi.commons.Constantes.MODIFICAR_CUOTA_PLAN_PAGO;
import static gob.bcb.portal.sirAladi.commons.Constantes.MODIFICAR_DEBITO_REEMBOLSO;
import static gob.bcb.portal.sirAladi.commons.Constantes.MODIFICAR_EMISION;
import static gob.bcb.portal.sirAladi.commons.Constantes.MODIFICAR_PAGO_ANTICIPADO;
import static gob.bcb.portal.sirAladi.commons.Constantes.MODIFICAR_REGISTRO;
import static gob.bcb.portal.sirAladi.commons.Constantes.REGISTRAR_DEBITO_REEMBOLSO;
import static gob.bcb.portal.sirAladi.commons.Constantes.REGISTRAR_EMISION;
import static gob.bcb.portal.sirAladi.commons.Constantes.REGISTRAR_PAGOS_ALADI;
import static gob.bcb.portal.sirAladi.commons.Constantes.REGISTRAR_PAGOS_ANTICIPADOS;
import static gob.bcb.portal.sirAladi.commons.Constantes.REGISTRAR_REGISTRO;
import static gob.bcb.portal.sirAladi.commons.Constantes.SUCCESS;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.xml.bind.JAXBElement;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Pago;
import gob.bcb.bpm.siraladi.jpa.PlanPago;
import gob.bcb.bpm.siraladi.jpa.RegAnticipado;
import gob.bcb.bpm.siraladi.jpa.Registro;
import gob.bcb.bpm.siraladi.jpa.TPagoImp;
import gob.bcb.bpm.siraladi.pojo.SaldoConvenio;
import gob.bcb.bpm.siraladi.pojo.StatusResponse;
import gob.bcb.core.jms.BcbRequestImpl;
import gob.bcb.core.seguridad.web.AuthnHandler;
import gob.bcb.siraladi.xml.model.Listainstitucion;
import gob.bcb.siraladi.xml.model.Listareganticipado;
import gob.bcb.siraladi.xml.model.Listatpagoimport;
import gob.bcb.siraladi.xml.model.Reganticipado;
import gob.bcb.siraladi.xml.model.Saldoconvenio;
import gob.bcb.siraladi.xml.model.Tpagoimport;
import gob.bcb.siraladi.xml.operaciones.Aladireqresptipo01Type;
import gob.bcb.siraladi.xml.operaciones.Aladirequesttipo01Type;
import gob.bcb.siraladi.xml.operaciones.Aladirequesttipo02Type;
import gob.bcb.siraladi.xml.operaciones.Aladiresponsetipo01Type;
import gob.bcb.siraladi.xml.operaciones.ObjectFactory;

/**
 * Clase que contiene los mtodos asociados interaccin con la capa de servicio
 * del Sir Aladi.
 * 
 * @author wherrera
 * 
 */
public class Servicios {

	private static Logger log = Logger.getLogger(Servicios.class);

	/**
	 * Mtodo que invoca al servicio para realizar el guardado de una emisin.
	 * 
	 * @param apertura
	 *            objeto Apertura
	 * @param registro
	 *            objeto Registro
	 * @return objeto StatusResponse, contiene la respuesta del servicio.
	 */
	public static StatusResponse guardarEmision(Apertura apertura, Registro registro) {
		StatusResponse statusResponse = null;
		try {
			gob.bcb.siraladi.xml.model.Apertura aperturaXml = apertura.getObjectJAXB();
			gob.bcb.siraladi.xml.model.Registro registroXml = null;
			if (registro != null)
				registroXml = registro.getObjectJAXB();

			Aladirequesttipo01Type request = new Aladirequesttipo01Type();
			request.setApertura(aperturaXml);
			request.setRegistro(registroXml);
			ObjectFactory of = new ObjectFactory();
			JAXBElement<?> requestTypeJAXBElement = of.createAladirequesttipo01(request);
			String tipoOperacion = (aperturaXml.getNromov() != null && aperturaXml.getNromov() > 0) ? MODIFICAR_EMISION : REGISTRAR_EMISION;
			statusResponse = invocarServicioAladi(tipoOperacion, requestTypeJAXBElement);
		} catch (Exception e) {
			statusResponse = new StatusResponse("Error al guardar la emisin." + e.getMessage());
			log.error("Error al guardar la emisin " + e.getMessage(), e);
		}
		return statusResponse;
	}

	/**
	 * Mtodo que modifica una apertura.
	 * 
	 * @param apertura
	 * @return
	 */
	public static StatusResponse modificarApertura(gob.bcb.bpm.siraladi.jpa.Apertura apertura) {
		StatusResponse statusResponse = null;
		try {
			gob.bcb.siraladi.xml.model.Apertura aperturaXml = apertura.getObjectJAXB();

			Aladirequesttipo01Type request = new Aladirequesttipo01Type();
			request.setApertura(aperturaXml);
			ObjectFactory of = new ObjectFactory();
			JAXBElement<?> requestTypeJAXBElement = of.createAladirequesttipo01(request);
			statusResponse = invocarServicioAladi(MODIFICAR_APERTURA, requestTypeJAXBElement);
		} catch (Exception e) {
			statusResponse = new StatusResponse("Error al guardar la emisin." + e.getMessage());
			log.error("Error al guardar la emisin " + e.getMessage(), e);
		}
		return statusResponse;
	}

	public static StatusResponse modificarAperturaSinValidacion(gob.bcb.bpm.siraladi.jpa.Apertura apertura) {
		StatusResponse statusResponse = null;
		try {
			gob.bcb.siraladi.xml.model.Apertura aperturaXml = apertura.getObjectJAXB();

			Aladirequesttipo01Type request = new Aladirequesttipo01Type();
			request.setApertura(aperturaXml);
			ObjectFactory of = new ObjectFactory();
			JAXBElement<?> requestTypeJAXBElement = of.createAladirequesttipo01(request);
			statusResponse = invocarServicioAladi("AL0108", requestTypeJAXBElement);
		} catch (Exception e) {
			statusResponse = new StatusResponse("Error al guardar la emisin." + e.getMessage());
			log.error("Error al guardar la emisin " + e.getMessage(), e);
		}
		return statusResponse;
	}

	/**
	 * Mtodo que invoca al servicio para eliminar una emisin.
	 * 
	 * @param apertura
	 * @return objeto StatusResponse, contiene la respuesta del servicio.
	 */
	public static StatusResponse eliminarEmision(Apertura apertura) {
		return eliminarAnularEmision(apertura, ELIMINAR_EMISION);
	}

	/**
	 * Mtodo que invoca al servicio para anular una emisin.
	 * 
	 * @param apertura
	 * @return objeto StatusResponse, contiene la respuesta del servicio.
	 */
	public static StatusResponse anularEmision(Apertura apertura) {
		return eliminarAnularEmision(apertura, ANULAR_EMISION);
	}

	/**
	 * Mtodo que invoca al servicio para realizar la eliminacion de una
	 * emision.
	 * 
	 * @param apertura
	 *            objeto Apertura
	 * @return objeto StatusResponse, contiene la respuesta del servicio.
	 */
	private static StatusResponse eliminarAnularEmision(Apertura apertura, String tipoOperacion) {
		StatusResponse statusResponse = null;
		try {
			gob.bcb.siraladi.xml.model.Apertura aperturaXml = apertura.getObjectJAXB();
			Aladirequesttipo01Type request = new Aladirequesttipo01Type();
			request.setApertura(aperturaXml);
			ObjectFactory of = new ObjectFactory();
			JAXBElement<?> requestTypeJAXBElement = of.createAladirequesttipo01(request);
			statusResponse = invocarServicioAladi(tipoOperacion, requestTypeJAXBElement);
		} catch (Exception e) {
			statusResponse = new StatusResponse("Error al elimiar/anular la emisin." + e.getMessage());
			log.error("Error al elimiar/anular la emisin." + e.getMessage(), e);
		}
		return statusResponse;
	}

	public static StatusResponse registrarRegistro(Apertura apertura, Registro registro) {
		return procesarRegistro(apertura, registro, REGISTRAR_REGISTRO);
	}

	public static StatusResponse modificarRegistro(Apertura apertura, Registro registro) {
		return procesarRegistro(apertura, registro, MODIFICAR_REGISTRO);
	}

	public static StatusResponse eliminarRegistro(Apertura apertura, Registro registro) {
		return procesarRegistro(apertura, registro, ELIMINAR_REGISTRO);
	}

	/**
	 * Mtodo que invoca al servicio para realizar la operacin de un registro.
	 * 
	 * @param apertura
	 *            objeto Apertura
	 * @param registro
	 *            objeto Registro
	 * @param tipoOperacion
	 *            codigo de operacion
	 * @return objeto StatusResponse, contiene la respuesta del servicio.
	 */
	private static StatusResponse procesarRegistro(Apertura apertura, Registro registro, String tipoOperacion) {
		StatusResponse statusResponse = null;
		try {
			gob.bcb.siraladi.xml.model.Apertura aperturaXml = apertura.getObjectJAXB();
			gob.bcb.siraladi.xml.model.Registro registroXml = registro.getObjectJAXB();

			Aladirequesttipo01Type request = new Aladirequesttipo01Type();
			request.setApertura(aperturaXml);
			request.setRegistro(registroXml);
			ObjectFactory of = new ObjectFactory();
			JAXBElement<?> requestTypeJAXBElement = of.createAladirequesttipo01(request);
			statusResponse = invocarServicioAladi(tipoOperacion, requestTypeJAXBElement);
		} catch (Exception e) {
			statusResponse = new StatusResponse("Error al guardar el registro." + e.getMessage());
			log.error("Error al guardar el registro " + e.getMessage(), e);
		}
		return statusResponse;
	}

	public static StatusResponse registrarDebitoReembolso(Apertura apertura, Pago pago) {
		return guardarDebitoReembolso(apertura, pago, REGISTRAR_DEBITO_REEMBOLSO);
	}

	public static StatusResponse modificarDebitoReembolso(Apertura apertura, Pago pago) {
		return guardarDebitoReembolso(apertura, pago, MODIFICAR_DEBITO_REEMBOLSO);
	}

	public static StatusResponse eliminarDebitoReembolso(Apertura apertura, Pago pago) {
		return guardarDebitoReembolso(apertura, pago, ELIMINAR_DEBITO_REEMBOLSO);
	}

	/**
	 * Mtodo que invoca al servicio para guardar un dbito (un pago).
	 * 
	 * @param apertura
	 *            objeto Apertura
	 * @param pago
	 *            objeto Pago
	 * @return objeto StatusResponse, contiene la respuesta del servicio.
	 */
	private static StatusResponse guardarDebitoReembolso(Apertura apertura, Pago pago, String tipoOperacion) {
		StatusResponse statusResponse = null;
		try {
			gob.bcb.siraladi.xml.model.Apertura aperturaXml = apertura.getObjectJAXB();
			gob.bcb.siraladi.xml.model.Pago pagoXml = pago.getObjectJAXB();
			Aladirequesttipo01Type request = new Aladirequesttipo01Type();
			request.setApertura(aperturaXml);
			request.setPago(pagoXml);
			ObjectFactory of = new ObjectFactory();
			JAXBElement<?> requestTypeJAXBElement = of.createAladirequesttipo01(request);
			statusResponse = invocarServicioAladi(tipoOperacion, requestTypeJAXBElement);
		} catch (Exception e) {
			statusResponse = new StatusResponse("Error al guardar el dbito." + e.getMessage());
			log.error("Error al guardar el dbito " + e.getMessage(), e);
		}
		return statusResponse;
	}

	/**
	 * Mtodo que invoca al servicio para guardar plan de pagos.
	 * 
	 * @param apertura
	 *            objeto Apertura
	 * @param listaPlanPagos
	 *            objeto Lista de objetos PlanPago
	 * @return objeto StatusResponse, contiene la respuesta del servicio.
	 */
	public static StatusResponse guardarPlanPago(Apertura apertura, PlanPago planPago) {
		StatusResponse statusResponse = null;
		try {
			gob.bcb.siraladi.xml.model.Apertura aperturaXml = apertura.getObjectJAXB();
			gob.bcb.siraladi.xml.model.Listaplanpagos listaPlanPagosXml = new gob.bcb.siraladi.xml.model.Listaplanpagos();
			listaPlanPagosXml.getPlanpago().add(planPago.getObjectJAXB());
			Aladirequesttipo01Type request = new Aladirequesttipo01Type();
			request.setApertura(aperturaXml);
			request.setListaplanpagos(listaPlanPagosXml);
			ObjectFactory of = new ObjectFactory();
			JAXBElement<?> requestTypeJAXBElement = of.createAladirequesttipo01(request);
			statusResponse = invocarServicioAladi(MODIFICAR_CUOTA_PLAN_PAGO, requestTypeJAXBElement);
		} catch (Exception e) {
			statusResponse = new StatusResponse("Error al guardar el plan de pagos." + e.getMessage());
			log.error("Error al guardar el plan de pagos " + e.getMessage(), e);
		}
		return statusResponse;
	}

	/**
	 * Mtodo que invoca al servicio para guardar plan de pagos.
	 * 
	 * @param apertura
	 *            objeto Apertura
	 * @param listaPlanPagos
	 *            objeto Lista de objetos PlanPago
	 * @return objeto StatusResponse, contiene la respuesta del servicio.
	 */
	public static StatusResponse enviarPlanPagosAladi(Apertura apertura, List<PlanPago> listaPlanPagos) {
		StatusResponse statusResponse = null;
		try {
			gob.bcb.siraladi.xml.model.Apertura aperturaXml = apertura.getObjectJAXB();
			gob.bcb.siraladi.xml.model.Listaplanpagos listaPlanPagosXml = new gob.bcb.siraladi.xml.model.Listaplanpagos();
			for (PlanPago planPago : listaPlanPagos)
				listaPlanPagosXml.getPlanpago().add(planPago.getObjectJAXB());

			Aladirequesttipo01Type request = new Aladirequesttipo01Type();
			request.setApertura(aperturaXml);
			request.setListaplanpagos(listaPlanPagosXml);
			ObjectFactory of = new ObjectFactory();
			JAXBElement<?> requestTypeJAXBElement = of.createAladirequesttipo01(request);
			statusResponse = invocarServicioAladi(ENVIAR_PLAN_PAGOS_A_ALADI, requestTypeJAXBElement);
		} catch (Exception e) {
			statusResponse = new StatusResponse("Error al guardar el plan de pagos." + e.getMessage());
			log.error("Error al guardar el plan de pagos " + e.getMessage(), e);
		}
		return statusResponse;
	}

	/**
	 * Mtodo que realiza una consulta de Pagos Aladi al servicio Aladi.
	 * 
	 * @param fechaDesde
	 *            fecha inicial
	 * @param fechaHasta
	 *            fecha final
	 * @return objeto StatusResponse, contiene la respuesta del servicio.
	 */
	public static StatusResponse getPagosAladi(Date fechaDesde, Date fechaHasta) {
		StatusResponse statusResponse = null;
		try {
			Aladirequesttipo02Type request = new Aladirequesttipo02Type();
			request.setFechaDesde(AladiUtils.dateToXMLGregorianCalendar(fechaDesde));
			request.setFechaHasta(AladiUtils.dateToXMLGregorianCalendar(fechaHasta));
			ObjectFactory of = new ObjectFactory();
			JAXBElement<?> requestTypeJAXBElement = of.createAladirequesttipo02(request);
			statusResponse = invocarServicioAladi(CONSULTAR_PAGOS_ALADI, requestTypeJAXBElement);
			if (SUCCESS.equals(statusResponse.getStatusCode())) {
				List<Tpagoimport> listaTpagoImportXml = ((Aladireqresptipo01Type) statusResponse.getResponse()).getListatpagoimport()
						.getTpagoimport();
				List<TPagoImp> listaPagosAladi = new ArrayList<TPagoImp>();
				for (Tpagoimport tpagoimportXml : listaTpagoImportXml)
					listaPagosAladi.add(new TPagoImp(tpagoimportXml));
				statusResponse.getContenido().put("pagosAladi", listaPagosAladi);
			}
		} catch (Exception e) {
			statusResponse = new StatusResponse("Error al consultar pagos aladi." + e.getMessage());
			log.error("Error al consultar pagos aladi " + e.getMessage(), e);
		}
		return statusResponse;
	}

	/**
	 * Mtodo que registra pagoa aladi.
	 * 
	 * @param pagosAladi
	 *            Lista de objetos TPagoImp
	 * 
	 * @return objeto StatusResponse, contiene la respuesta del servicio.
	 */
	public static StatusResponse guardarPagosAladi(List<TPagoImp> pagosAladi) {
		StatusResponse statusResponse = null;
		try {
			Listatpagoimport listaPagoImportXml = new Listatpagoimport();
			for (TPagoImp pagoAladi : pagosAladi) {
				if (pagoAladi.isSeleccionado())
					listaPagoImportXml.getTpagoimport().add(pagoAladi.getObjectJAXB());
			}

			Aladireqresptipo01Type request = new Aladireqresptipo01Type();
			request.setListatpagoimport(listaPagoImportXml);
			ObjectFactory of = new ObjectFactory();
			JAXBElement<?> alabcbInternoTypeJAXBElement = of.createAladireqresptipo01(request);
			statusResponse = invocarServicioAladi(REGISTRAR_PAGOS_ALADI, alabcbInternoTypeJAXBElement);
			if (SUCCESS.equals(statusResponse.getStatusCode())) {

				List<gob.bcb.siraladi.xml.model.Pago> listaPagosXml = ((Aladiresponsetipo01Type) statusResponse.getResponse()).getListapagos()
						.getPago();
				List<Pago> listaPagos = new ArrayList<Pago>();
				for (gob.bcb.siraladi.xml.model.Pago pagoXml : listaPagosXml)
					listaPagos.add(new Pago(pagoXml));
				statusResponse.getContenido().put("pagos", listaPagos);
			}
		} catch (Exception e) {
			statusResponse = new StatusResponse("Error al guardar pagos aladi." + e.getMessage());
			log.error("Error al guardar pagos aladi " + e.getMessage(), e);
		}
		return statusResponse;
	}

	/**
	 * Mtodo que realiza una consulta de Saldos por importacion al servicio del
	 * Aladi.
	 * 
	 * @param fechaDesde
	 *            fecha inicial
	 * @param fechaHasta
	 *            fecha final
	 * @return objeto StatusResponse, contiene la respuesta del servicio.
	 */
	public static StatusResponse getSaldosConvenioImportacion(Date fechaDesde, Date fechaHasta, Date fechaAl) {
		StatusResponse statusResponse = null;
		try {
			Aladirequesttipo02Type request = new Aladirequesttipo02Type();
			request.setFechaDesde(AladiUtils.dateToXMLGregorianCalendar(fechaDesde));
			request.setFechaHasta(AladiUtils.dateToXMLGregorianCalendar(fechaHasta));
			request.setFechaAl(AladiUtils.dateToXMLGregorianCalendar(fechaAl));
			ObjectFactory of = new ObjectFactory();
			JAXBElement<?> requestTypeJAXBElement = of.createAladirequesttipo02(request);
			statusResponse = invocarServicioAladi(CONSULTAR_SALDOS_CONVENIO, requestTypeJAXBElement);
			if (SUCCESS.equals(statusResponse.getStatusCode())) {
				List<Saldoconvenio> listaSaldosConvenioXml = ((Aladireqresptipo01Type) statusResponse.getResponse()).getListasaldoconvenio()
						.getSaldoconvenio();
				List<SaldoConvenio> listaSaldosConvenio = new ArrayList<SaldoConvenio>();
				for (Saldoconvenio saldoXml : listaSaldosConvenioXml) {
					SaldoConvenio saldo = new SaldoConvenio(saldoXml);
					if (saldo.getDebitoA() == null)
						saldo.setDebitoA(BigDecimal.ZERO);
					if (saldo.getDebitoB() == null)
						saldo.setDebitoB(BigDecimal.ZERO);
					if (saldo.getCobrosPendientes() == null)
						saldo.setCobrosPendientes(BigDecimal.ZERO);
					if (saldo.getPagosPendientes() == null)
						saldo.setPagosPendientes(BigDecimal.ZERO);
					if (saldo.getSaldoDiaCtaA() == null)
						saldo.setSaldoDiaCtaA(BigDecimal.ZERO);
					saldo.setSaldoAladi(saldo.getDebitoA().subtract(saldo.getDebitoB()));
					saldo.setTotal((saldo.getSaldoAladi().add(saldo.getPagosPendientes())).subtract(saldo.getCobrosPendientes()));
					saldo.setSaldoDiaCtaB(saldo.getSaldoAladi().add(saldo.getSaldoDiaCtaA()));
					listaSaldosConvenio.add(saldo);
				}
				statusResponse.getContenido().put("saldosConvenio", listaSaldosConvenio);
			}
		} catch (Exception e) {
			statusResponse = new StatusResponse("Error al obtener saldos del convenio." + e.getMessage());
			log.error("Error al obtener saldos del convenio " + e.getMessage(), e);
		}
		return statusResponse;
	}

	/**
	 * Mtodo que registra pagos anticipados
	 * 
	 * @param pagosAnticipados
	 *            Lista de objetos RegAnticipado
	 * 
	 * @return objeto StatusResponse, contiene la respuesta del servicio.
	 */
	public static StatusResponse guardarPagosAnticipados(List<RegAnticipado> pagosAnticipados) {
		StatusResponse statusResponse = null;
		try {
			Listareganticipado listaRegAnticipadoXml = new Listareganticipado();
			for (RegAnticipado pagoAnticipado : pagosAnticipados)
				listaRegAnticipadoXml.getReganticipado().add(pagoAnticipado.getObjectJAXB());

			Aladireqresptipo01Type request = new Aladireqresptipo01Type();
			request.setListareganticipado(listaRegAnticipadoXml);
			ObjectFactory of = new ObjectFactory();
			JAXBElement<?> alabcbInternoTypeJAXBElement = of.createAladireqresptipo01(request);
			statusResponse = invocarServicioAladi(REGISTRAR_PAGOS_ANTICIPADOS, alabcbInternoTypeJAXBElement);
		} catch (Exception e) {
			statusResponse = new StatusResponse("Error al guardar pago(s) anticipado(s)." + e.getMessage());
			log.error("Error al guardar pago(s) anticipado(s) " + e.getMessage(), e);
		}
		return statusResponse;
	}

	/**
	 * Mtodo que guarda un pago anticipado.
	 * 
	 * @param pagoAnticipado
	 * @return
	 */
	public static StatusResponse registrarPagoAnticipado(RegAnticipado pagoAnticipado) {
		return guardarPagosAnticipados(Arrays.asList(new RegAnticipado[] { pagoAnticipado }));
	}

	/**
	 * Mtodo que guarda un pago anticipado.
	 * 
	 * @param pagoAnticipado
	 * @return
	 */
	public static StatusResponse modificarPagoAnticipado(RegAnticipado pagoAnticipado) {
		return procesarPagoAnticipado(pagoAnticipado, MODIFICAR_PAGO_ANTICIPADO);
	}

	/**
	 * Mtodo que elimina un pago anticipado.
	 * 
	 * @param pagoAnticipado
	 * @return
	 */
	public static StatusResponse eliminarPagoAnticipado(RegAnticipado pagoAnticipado) {
		return procesarPagoAnticipado(pagoAnticipado, ELIMIAR_PAGO_ANTICIPADO);
	}

	/**
	 * Mtodo que procesa un pago anticipado.
	 * 
	 * @param pagoAnticipado
	 * @return objeto StatusResponse, contiene la respuesta del servicio.
	 */
	public static StatusResponse procesarPagoAnticipado(RegAnticipado pagoAnticipado, String tipoOperacion) {
		StatusResponse statusResponse = null;
		try {
			Reganticipado pagoAnticipadoXml = pagoAnticipado.getObjectJAXB();

			Aladireqresptipo01Type request = new Aladireqresptipo01Type();
			request.setReganticipado(pagoAnticipadoXml);
			ObjectFactory of = new ObjectFactory();
			JAXBElement<?> alaBcbInternoTypeJAXBElement = of.createAladireqresptipo01(request);
			statusResponse = invocarServicioAladi(tipoOperacion, alaBcbInternoTypeJAXBElement);
		} catch (Exception e) {
			statusResponse = new StatusResponse("Error al guardar pago anticipado." + e.getMessage());
			log.error("Error al guardar pago anticipado " + e.getMessage(), e);
		}
		return statusResponse;
	}

	/**
	 * Mtodo que procesa una operacin ono registrada.
	 * 
	 * @param tPagoImp
	 * @param guardar
	 *            si es true guarda, caso contrario elimina la operacion no
	 *            registrada
	 * @return objeto StatusResponse, contiene la respuesta del servicio.
	 */
	public static StatusResponse guardarOperacionNoRegistrada(TPagoImp tPagoImp, boolean guardar) {
		StatusResponse statusResponse = null;
		try {
			Tpagoimport tpagoimportXml = tPagoImp.getObjectJAXB();
			Aladireqresptipo01Type request = new Aladireqresptipo01Type();
			request.setTpagoimport(tpagoimportXml);
			ObjectFactory of = new ObjectFactory();
			JAXBElement<?> alaBcbInternoTypeJAXBElement = of.createAladireqresptipo01(request);
			statusResponse = invocarServicioAladi(guardar ? GUARDAR_OPERACION_NO_REGISTRADA : ELIMINAR_OPERACION_NO_REGISTRADA,
					alaBcbInternoTypeJAXBElement);
		} catch (Exception e) {
			statusResponse = new StatusResponse("Error al guardar operacin no registrada." + e.getMessage());
			log.error("Error al guardar operacin no registrada " + e.getMessage(), e);
		}
		return statusResponse;
	}

	/**
	 * Mtodo que realiza una consulta de instituciones autorizadas al servicio
	 * del Aladi.
	 * 
	 * @param fechaDesde
	 *            fecha inicial
	 * @param fechaHasta
	 *            fecha final
	 * @return objeto StatusResponse, contiene la respuesta del servicio.
	 */
	public static StatusResponse getInstitucionesAutorizadas() {
		StatusResponse statusResponse = null;
		try {
			Aladirequesttipo02Type request = new Aladirequesttipo02Type();
			request.setFechaDesde(AladiUtils.dateToXMLGregorianCalendar(new Date()));
			request.setFechaHasta(AladiUtils.dateToXMLGregorianCalendar(new Date()));
			ObjectFactory of = new ObjectFactory();
			JAXBElement<?> ala0305TypeJAXBElement = of.createAladirequesttipo02(request);
			statusResponse = invocarServicioAladi(CONSULTAR_INSTITUCIONES_AUTORIZADAS, ala0305TypeJAXBElement);
			if (SUCCESS.equals(statusResponse.getStatusCode())) {
				List<gob.bcb.siraladi.xml.model.Institucion> listaInstitucionesXml = ((Aladireqresptipo01Type) statusResponse.getResponse())
						.getListainstitucion().getInstitucion();
				List<Institucion> listaInstituciones = new ArrayList<Institucion>();
				for (gob.bcb.siraladi.xml.model.Institucion institucionXml : listaInstitucionesXml)
					listaInstituciones.add(new Institucion(institucionXml));
				statusResponse.getContenido().put("institucionesAutorizadas", listaInstituciones);
			}
		} catch (Exception e) {
			statusResponse = new StatusResponse("Error al consultar instituciones autorizadas." + e.getMessage());
			log.error("Error al consultar instituciones autorizadas " + e.getMessage(), e);
		}
		return statusResponse;
	}

	/**
	 * Mtodo que registra instituciones autorizadas
	 * 
	 * @param pagosAnticipados
	 *            Lista de objetos Institucion
	 * 
	 * @return objeto StatusResponse, contiene la respuesta del servicio.
	 */
	public static StatusResponse guardarInstitucionesAutorizadas(List<Institucion> listaInstituciones) {
		StatusResponse statusResponse = null;
		try {
			Listainstitucion listaInstitucionesXml = new Listainstitucion();
			for (Institucion institucion : listaInstituciones)
				listaInstitucionesXml.getInstitucion().add(institucion.getObjectJAXB());

			Aladireqresptipo01Type request = new Aladireqresptipo01Type();
			request.setListainstitucion(listaInstitucionesXml);
			ObjectFactory of = new ObjectFactory();
			JAXBElement<?> alabcbInternoTypeJAXBElement = of.createAladireqresptipo01(request);
			statusResponse = invocarServicioAladi(GUARDAR_INSTITUCIONES_AUTORIZADAS, alabcbInternoTypeJAXBElement);
		} catch (Exception e) {
			statusResponse = new StatusResponse("Error al guardar instituciones autorizadas." + e.getMessage());
			log.error("Error al guardar instituciones autorizadas " + e.getMessage(), e);
		}
		return statusResponse;
	}

	/**
	 * Mtodo que realiza una llamada al servicio del sir aladi.
	 * 
	 * @param codTipoOperacion
	 *            cdigo tipo de operacin.
	 * @param parametros
	 *            parametros para enviar al servicio.
	 * @return objeto StatusResponse, indica la respuesta de la operacin en el
	 *         servicio.
	 */
	public static StatusResponse invocarServicioAladi(String codTipoOperacion, Object parametrosRequest) {
		StatusResponse statusResponse = null;
		try {
			String idUsuario = AuthnHandler.getUserPrincipal();
			String codEmp = (AuthnHandler.getCodEmpleado() == null || AuthnHandler.getCodEmpleado().trim().isEmpty()) ? AuthnHandler.getUserPrincipal() : AuthnHandler.getCodEmpleado();
			String codParticipante = AuthnHandler.getCodParticipante();
			idUsuario = idUsuario.concat("|").concat(StringUtils.trimToEmpty(codEmp)).concat("|").concat(StringUtils.trimToEmpty(codParticipante));

			log.info("Realizando llamada al servicio, operacin: " + codTipoOperacion + " idUsuario: " + idUsuario);			
			gob.bcb.core.jms.BcbRequest bcbRequest = BcbRequestImpl.newInstance(AuthnHandler.getAddress(), AuthnHandler.getAddress(),
					"idDestinatario", "service", codTipoOperacion, "requestID", idUsuario, "del 1 al 8", "nroOperacion",
					parametrosRequest);
			String xmlRequest = bcbRequest.toString(bcbRequest.getMsgbcb());

			Mensajeria mensajeria = new Mensajeria();
			mensajeria.enviarMensaje(xmlRequest);
			statusResponse = mensajeria.getStatusResponse();
			log.info("La llamada al servicio se realizo con exito.");
		} catch (Exception e) {
			statusResponse = new StatusResponse("ocurrio un error al invocar el servicio " + codTipoOperacion + " ERROR: " + e.getMessage());
			log.error("ocurrio un error al invocar el servicio " + codTipoOperacion + " ERROR: " + e.getMessage(), e);
		}
		return statusResponse;
	}

}
