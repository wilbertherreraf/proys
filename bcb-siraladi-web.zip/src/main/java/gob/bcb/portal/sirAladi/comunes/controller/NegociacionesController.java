/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-sirAladi
 * gob.bcb.portal.sirAladi.comunes.controller.NegociacionesController
 * 10/08/2011 - 09:46:40
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.comunes.controller;

import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarMapDescripcionClaves;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.getAlertConCierreModalJS;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.getAlertJS;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_ESTADO_PLAN_PAGO;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTADO_PENDIENTE;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTADO_SUSPENDIDO;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTILO_INVISIBLE;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTILO_VISIBLE;
import static gob.bcb.portal.sirAladi.commons.Constantes.SUCCESS;
import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.PlanPago;
import gob.bcb.bpm.siraladi.jpa.PlanPagoPK;
import gob.bcb.bpm.siraladi.pojo.StatusResponse;
import gob.bcb.portal.sirAladi.commons.Servicios;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

/**
 * Backing Bean de la vista de Plan de Pagos.
 * 
 * @author wherrera
 * 
 */
public class NegociacionesController extends BaseBeanController {
	private String msj;
	private Apertura apertura;
	private PlanPago planPago;

	private List<PlanPago> planPagos;
	private Map<String, String> mapClavesEstadoPlan;
	private BigDecimal totalCapital;
	private BigDecimal totalInteres;
	private BigDecimal totalMonto;

	private static Logger log = Logger.getLogger(NegociacionesController.class);

	public NegociacionesController() {
	}

	@PostConstruct
	public void init() {
		log.info("Iniciando el modulo de plan de pagos.");
		recuperarVisit();
		this.crearObjetosPorDefecto();
		if (getVisit().getParametro("SIRWEB_TMP_OBJECT") != null) {
			if (!(getVisit().getParametro("SIRWEB_TMP_OBJECT") instanceof NegociacionesController)) {
				// getVisit().removeParametro("SIRWEB_TMP_OBJECT");
			} else {
				NegociacionesController objeto = (NegociacionesController) getVisit().getParametro("SIRWEB_TMP_OBJECT");
				planPago = objeto.getPlanPago();
			}
		}

		if (getVisit().getCurrentApertura() != null) {
			this.apertura = getSirAladiDao().getApertura(getVisit().getCurrentApertura().getNroMov());
			this.recuperarDatos();
		}
	}

	public Apertura getApertura() {
		return apertura;
	}

	public void setApertura(Apertura apertura) {
		this.apertura = apertura;
	}

	public List<PlanPago> getPlanPagos() {
		return planPagos;
	}

	public void setPlanPagos(List<PlanPago> planPagos) {
		this.planPagos = planPagos;
	}

	public PlanPago getPlanPago() {
		return planPago;
	}

	public void setPlanPago(PlanPago planPago) {
		this.planPago = planPago;
	}

	public Map<String, String> getMapClavesEstadoPlan() {
		return mapClavesEstadoPlan;
	}

	public void setMapClavesEstadoPlan(Map<String, String> mapClavesEstadoPlan) {
		this.mapClavesEstadoPlan = mapClavesEstadoPlan;
	}

	public boolean isPuedeNegociar() {
		return (this.apertura != null && this.apertura.getIdentificador() != null && this.apertura.getIdentificador().getCodId() != null && "1"
				.equals(this.apertura.getIdentificador().getCodId().trim()));
	}

	public String getEstiloHayCambios() {
		boolean hayCuotasPendientes = false;
		if (this.planPagos != null && this.planPagos.size() > 0) {
			for (PlanPago cuota : this.planPagos) {
				if (cuota.getCveEstadoPlan().equals(ESTADO_PENDIENTE)) {
					hayCuotasPendientes = true;
					break;
				}
			}
		}
		return hayCuotasPendientes ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	private void recuperarDatos() {
		this.planPagos = getSirAladiDao().getPlanPagos(this.apertura.getNroMov());
		this.calcularTotalPlanPago();
		// descripcion de claves
		this.mapClavesEstadoPlan = armarMapDescripcionClaves(getSirAladiDao().getClaves(CVE_ESTADO_PLAN_PAGO));
	}

	public void nuevoCuota() {
		log.info("nuevo plan pagos NroMov: " + apertura.getNroMov());		
		PlanPagoPK pk = new PlanPagoPK();
		pk.setNroMov(this.apertura.getNroMov());
		this.planPago = new PlanPago();
		this.planPago.setId(pk);
		this.planPago.setCveEstadoPlan(ESTADO_PENDIENTE);
		getVisit().setParametro("SIRWEB_TMP_OBJECT", this);
	}

	public void editarCuota(PlanPago planPagoSel) {
		log.info("editando plan pagos " + planPagoSel.getId().getNroMov() + " " + planPagoSel.getId().getNroPlan());		
		this.planPago = planPagoSel;
		log.info(planPago.getCveEstadoPlan());
		getVisit().setParametro("SIRWEB_TMP_OBJECT", this);
	}

	public void eliminarPlanCuotas(PlanPago planPagoSel) {
		log.info("eliminando plan pagos " + planPagoSel.getId().getNroMov() + " " + planPagoSel.getId().getNroPlan());
		this.msj = null;
		// que sucede al guardar

		this.planPago = planPagoSel;
		this.planPago.setCveEstadoPlan(ESTADO_SUSPENDIDO);

		StatusResponse statusResponse = Servicios.guardarPlanPago(this.apertura, this.planPago);
		if (statusResponse.getStatusCode().equals(SUCCESS)) {
			this.recuperarDatos();
			String msg = statusResponse.getDescrip();
			log.debug(msg);
			// FacesContextUtil.addInfoMessage(msg);
			this.msj = getAlertConCierreModalJS("panelCuota", statusResponse);
		} else {
			String msg = "Error al actualizar la negociacion " + statusResponse.getDescrip();
			log.error(msg);
			// FacesContextUtil.addErrorMessage(msg + ": Error Servicio.");
			this.msj = getAlertJS(statusResponse);
		}

	}

	public void cancelarPlanCuotas(PlanPago planPagoSel) {
		log.info("cancelando plan pagos " + planPagoSel.getId().getNroMov() + " " + planPagoSel.getId().getNroPlan());
		this.msj = null;
		// que sucede al guardar

		this.planPago = planPagoSel;
		this.planPago.setCveEstadoPlan("C");
		StatusResponse statusResponse = Servicios.guardarPlanPago(this.apertura, this.planPago);
		if (statusResponse.getStatusCode().equals(SUCCESS)) {
			this.recuperarDatos();
			String msg = statusResponse.getDescrip();
			log.debug(msg);
			// FacesContextUtil.addInfoMessage(msg);
			this.msj = getAlertConCierreModalJS("panelCuota", statusResponse);
		} else {
			String msg = "Error al actualizar la negociacion " + statusResponse.getDescrip();
			log.error(msg);
			// FacesContextUtil.addErrorMessage(msg + ": Error Servicio.");
			this.msj = getAlertJS(statusResponse);
		}

	}

	public void modificarPlanCuotas() {
		log.info("Actualizando plan pagos " + planPago.toString());
		this.msj = null;
		// que sucede al guardar

		this.calcularMontoCuota();
		StatusResponse statusResponse = Servicios.guardarPlanPago(this.apertura, this.planPago);
		if (statusResponse.getStatusCode().equals(SUCCESS)) {
			this.recuperarDatos();
			String msg = statusResponse.getDescrip();
			log.debug(msg);
			// FacesContextUtil.addInfoMessage(msg);
			this.msj = getAlertConCierreModalJS("panelCuota", statusResponse);
		} else {
			String msg = "Error al actualizar la negociacion " + statusResponse.getDescrip();
			log.error(msg);
			// FacesContextUtil.addErrorMessage(msg + ": Error Servicio.");
			this.msj = getAlertJS(statusResponse);
		}

	}

	private void calcularMontoCuota() {
		if (this.planPago.getInteres() == null)
			this.planPago.setInteres(BigDecimal.ZERO);
		if (this.planPago.getCapital() == null)
			this.planPago.setCapital(BigDecimal.ZERO);
		this.planPago.setMonto(this.planPago.getCapital().add(this.planPago.getInteres()));
	}

	private void calcularTotalPlanPago() {
		totalCapital = BigDecimal.ZERO;
		totalInteres = BigDecimal.ZERO;
		totalMonto = BigDecimal.ZERO;
		if (this.planPagos.size() > 0) {
			for (PlanPago cuota : this.planPagos) {
				if (cuota.getCveEstadoPlan() != null && (cuota.getCveEstadoPlan().trim().equals("N") || cuota.getCveEstadoPlan().trim().equals("P"))) {
					setTotalCapital(getTotalCapital().add(cuota.getCapital()));
					setTotalInteres(getTotalInteres().add(cuota.getInteres()));
					setTotalMonto(getTotalMonto().add(cuota.getMonto()));
				}
			}
		}
	}

	public void mostrarReporte(ActionEvent event) {
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("NRO_MOV", this.apertura.getNroMov());
		parametros.put("TITULO", "PLAN DE PAGOS");
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("pathTranslated", request.getPathTranslated());
		request.getSession().setAttribute("nombreReporte", "repPlanPagos.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}

	public void mostrarAdjunto(ActionEvent event) {
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("nroMov", this.apertura.getNroMov());
	}

	private void crearObjetosPorDefecto() {
		// Aperturas
		this.planPago = new PlanPago();
		this.planPago.setId(new PlanPagoPK());

		// Plan Pagos
		this.planPagos = new ArrayList<PlanPago>();
	}

	public void setTotalCapital(BigDecimal totalCapital) {
		this.totalCapital = totalCapital;
	}

	public BigDecimal getTotalCapital() {
		return totalCapital;
	}

	public void setTotalInteres(BigDecimal totalInteres) {
		this.totalInteres = totalInteres;
	}

	public BigDecimal getTotalInteres() {
		return totalInteres;
	}

	public void setTotalMonto(BigDecimal totalMonto) {
		this.totalMonto = totalMonto;
	}

	public BigDecimal getTotalMonto() {
		return totalMonto;
	}

	public String getMsj() {
		return msj;
	}

}
