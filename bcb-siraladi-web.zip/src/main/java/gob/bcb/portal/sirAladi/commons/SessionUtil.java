package gob.bcb.portal.sirAladi.commons;
import java.util.Enumeration;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

public class SessionUtil {
    /**
     * Elimina todos los objetos de sesion cuya llave comienze con "PTL_TMP"
     * @param fc FacesContext para obtener el contexto
     */
    public static void removerTemporales(FacesContext fc) {
        HttpSession session = (HttpSession) fc.getExternalContext().getSession(false);
        if (session != null) {
            Enumeration e = session.getAttributeNames();
            while (e.hasMoreElements()) {
                String key = e.nextElement().toString();
                if (key.startsWith("SIRWEB_TMP")) {
                    session.removeAttribute(key);
                }
            }
        }
    }

    /**
     * Elimina los objetos de sesion cuyas llaves sean proporcionadas en el vector args
     * @param fc FacesContext para obtener el contexto
     * @param args Vector con las llaves de los objetos a ser eliminados
     */
    public static void remover(FacesContext fc, String... args) {
        HttpSession session = (HttpSession) fc.getExternalContext().getSession(false);
        if (session != null) {
            for (int i = 0; i < args.length; i++) {
                String string = args[i];
                session.removeAttribute(string);

            }
        }
    }

    /**
     * Elimina todos los objetos de sesion cuya llave comienze con "PTL_TMP", excepto
     * los especificados en el vector args
     * @param fc FacesContext para obtener el contexto
     * @param args Vector con las llaves de los objetos que NO seran eliminados
     */
    public static void removerTemporalesExcepto(FacesContext fc, String... args) {
        HttpSession session = (HttpSession) fc.getExternalContext().getSession(false);
        if (session != null) {
            Enumeration e = session.getAttributeNames();
            while (e.hasMoreElements()) {
                String key = e.nextElement().toString();
                if (key.startsWith("SIRWEB_TMP") && !isStringInArray(key, args)) {
                    session.removeAttribute(key);

                }
            }
        }
    }

    private static boolean isStringInArray(String source, String[] args) {
        boolean result = false;
        for (int i = 0; i < args.length; i++) {

            if (source.equals(args[i])) {
                result = true;
                break;
            }
        }
        return result;
    } 
}
