/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-web-sirAladi
 * gob.bcb.portal.sirAladi.reportes.controller.RepSaldosExpController
 * 04/10/2011 - 10:56:28
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.reportes.controller;

import static gob.bcb.portal.sirAladi.commons.Constantes.FORMATO_FECHA_JAVA;
import gob.bcb.bpm.siraladi.jpa.Persona;
import gob.bcb.portal.sirAladi.commons.AladiUtils;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;
import gob.bcb.portal.sirAladi.dao.DaoFactory;
import gob.bcb.portal.sirAladi.dao.SirAladiDao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

/**
 * Backing bean de la vista de consulta de control diario saldos exportaciones.
 * 
 * @author wherrera
 * 
 */
public class RepSaldosExpController extends BaseBeanController {
	private String codPersona;
	private String query;
	private Date fechaAl;

	private SirAladiDao sirAladiDao;
	private List<List<Object>> listaSaldosExp;
	private List<SelectItem> itemsPersonas;
	private BigDecimal total;

	private static Logger log = Logger.getLogger(RepSaldosExpController.class);

	public RepSaldosExpController() {
	}

	@PostConstruct
	public void init() {
		log.info("Iniciando el modulo de control diario de saldos exportaciones.");
		recuperarVisit();
		this.sirAladiDao = DaoFactory.getInstance().getSirAladiDao();
		this.crearObjetosPorDefecto();

	}

	public String getCodPersona() {
		return codPersona;
	}

	public void setCodPersona(String codPersona) {
		this.codPersona = codPersona;
	}

	public Date getFechaAl() {
		return fechaAl;
	}

	public void setFechaAl(Date fechaAl) {
		this.fechaAl = fechaAl;
	}

	public String getTxtFechaAl() {
		return AladiUtils.dateToString(this.fechaAl, FORMATO_FECHA_JAVA);
	}

	public List<List<Object>> getListaSaldosExp() {
		return listaSaldosExp;
	}

	public List<SelectItem> getItemsPersonas() {
		return itemsPersonas;
	}

	public BigDecimal getTotal() {
		return total;
	}

	public void consultarRelacionPatrimonio(ActionEvent event) {
		String codigoPersona = StringUtils.isEmpty(this.codPersona) ? "%" : this.codPersona;
		String fecha = AladiUtils.dateToString(this.fechaAl, FORMATO_FECHA_JAVA);
		StringBuffer sb = new StringBuffer("SELECT cod_persona, nom_persona, saldo ");
		sb.append("FROM (SELECT c.cod_persona, c.nom_persona, ");
		sb.append("saldo_cont_mo(c.cod_persona, TO_DATE('" + fecha + "','%d/%m/%Y'), 'E') saldo ");
		sb.append("FROM persona  c WHERE c.cod_persona LIKE '" + codigoPersona + "' AND c.cve_vigente = 'V') ");
		sb.append("WHERE saldo > 0 ORDER BY 1 ");
		this.query = sb.toString();
		this.listaSaldosExp = this.sirAladiDao.ejecutarQueryListas(this.query);

		// calculo de totales
		this.total = BigDecimal.ZERO;
		for (List<Object> reg : this.listaSaldosExp)
			this.total = this.total.add((BigDecimal) reg.get(2));
	}

	public void mostrarReporte(ActionEvent event) {
		String fecha = AladiUtils.dateToString(this.fechaAl, FORMATO_FECHA_JAVA);
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("TITULO", "CONTRO DIARIO DE SALDOS (EXPORTACIONES)");
		parametros.put("QUERY", this.query);
		parametros.put("FECHA_AL", fecha);
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("pathTranslated", request.getPathTranslated());
		request.getSession().setAttribute("nombreReporte", "repSaldosExp.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}

	public void limpiar(ActionEvent event) {
		this.crearObjetosPorDefecto();
	}

	private void crearObjetosPorDefecto() {
		this.codPersona = null;
		this.fechaAl = this.sirAladiDao.getFechaActual();
		this.listaSaldosExp = new ArrayList<List<Object>>();

		// combos
		if (this.itemsPersonas == null) {
			this.itemsPersonas = new ArrayList<SelectItem>();
			List<Persona> personas = this.sirAladiDao.getEntidades();
			for (Persona persona : personas)
				this.itemsPersonas.add(new SelectItem(persona.getCodPersona(), persona.getNomPersona().trim()));
		}
	}

}
