/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-sirAladi
 * gob.bcb.portal.sirAladi.exportacion.controller.ModEmisionExpController
 * 15/07/2011 - 15:30:12
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.exportacion.controller;

import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarItemsPersonaBCB;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarSelectItemsPlazasInstituciones;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.getAlertJS;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.getCierreModalPanelJS;
import static gob.bcb.portal.sirAladi.commons.Constantes.CODIGO_MONEDA_DOLARES;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTADO_PENDIENTE;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTADO_VIGENTE;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTILO_INVISIBLE;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTILO_VISIBLE;
import static gob.bcb.portal.sirAladi.commons.Constantes.SUCCESS;
import static gob.bcb.portal.sirAladi.commons.Constantes.TIPO_APERTURA_EXPORTACION;
import static gob.bcb.portal.sirAladi.commons.Constantes.TIPO_EMISION_EMISION;
import static gob.bcb.portal.sirAladi.commons.Constantes.TIPO_MOVIMIENTO_APERTURA;
import gob.bcb.bpm.siraladi.jpa.Adjunto;
import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.Identificador;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Instrumento;
import gob.bcb.bpm.siraladi.jpa.Pais;
import gob.bcb.bpm.siraladi.jpa.Persona;
import gob.bcb.bpm.siraladi.jpa.Registro;
import gob.bcb.bpm.siraladi.pojo.StatusResponse;
import gob.bcb.portal.sirAladi.commons.Archivo;
import gob.bcb.portal.sirAladi.commons.Servicios;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.richfaces.event.UploadEvent;
import org.richfaces.model.UploadItem;

/**
 * Backing Bean de la vista de modificacion de emisi�n de exportacin.
 * 
 * @author wherrera
 * 
 */
public class ModEmisionExpController extends BaseBeanController {
	private static Logger log = Logger.getLogger(EmisionExpController.class);	
	private String filtro;
	private String msj;
	private boolean mostrarModal;

	private Apertura apertura;
	private Registro registro;
	private Adjunto adjunto;
	private Archivo archivo;
	private Pais paisConvenio;
	private Persona persona;	

	private List<Apertura> emisionesPendientes;
	private List<Apertura> emisionesInicial;
	private List<SelectItem> itemsInstitucionesLocales;
	private List<SelectItem> itemsPaisesExterior;
	private List<SelectItem> itemsInstitucionesExterior;
	private List<SelectItem> itemsInstrumentos;
	private List<SelectItem> itemsPersonasBCB;

	@PostConstruct
	public void init() {
		log.info("Iniciando el modulo de autorizacion de emisiones para Exportacion.");
		recuperarVisit();
		this.crearObjetosPorDefecto();
		this.consultarPendientes();
		if (this.emisionesPendientes == null || this.emisionesPendientes.size() == 0)
			mostrarModal = false;

	}

	public void registrarAperturaModif(ActionEvent event) {
		this.msj = "";
		StatusResponse statusResponse = null;
		if (adjunto == null)
			statusResponse = new StatusResponse("Debe adjuntar mensaje swift.");
		else {
			try {
				Integer.valueOf(this.apertura.getAnio());
				Integer.valueOf(this.apertura.getSecuencia());
				this.completarDatos();
				statusResponse = Servicios.guardarEmision(this.apertura, this.registro);
				if (SUCCESS.equalsIgnoreCase(statusResponse.getStatusCode()))
					this.recuperarDatos(this.apertura.getNroMov(), true);
				log.info(statusResponse.getDescrip());
			} catch (Exception e) {
				statusResponse = new StatusResponse("Error al guardar la emisi�n.");
				log.error(statusResponse.getDescrip(), e);
				e.printStackTrace();
			}
		}
		this.msj = getAlertJS(statusResponse);
	}

	private void recuperarDatos(Integer nroMovApertura, boolean consultarApertura) {
		this.apertura = getSirAladiDao().getApertura(nroMovApertura);
		this.registro = getSirAladiDao().getRegistroEmision(nroMovApertura);
		this.paisConvenio = this.apertura.getInstitucion().getPais();
		adjunto = getSirAladiDao().getAdjunto(nroMovApertura);
	}

	public void mostrarReporte(ActionEvent event) {
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("NRO_MOV", this.apertura.getNroMov());
		parametros.put("TITULO", "EMISION DE INSTRUMENTO");
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("pathTranslated", request.getPathTranslated());
		request.getSession().setAttribute("nombreReporte", "repApertura.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}

	public void adjuntar(UploadEvent event) {
		this.msj = "";
		UploadItem item = event.getUploadItem();
		StatusResponse statusResponse = new StatusResponse("");
		this.archivo = new Archivo();
		this.archivo.setLength(item.getData().length);
		this.archivo.setNombreMimeExtension(item.getFileName(), this.apertura.getCodigoReembolsoCorrido());
		this.archivo.setData(item.getData());
		if (this.apertura != null && this.apertura.getNroMov() != null && this.apertura.getNroMov() > 0) {
			try {
				this.archivo.guardarAdjunto(this.apertura.getNroMov(), TIPO_MOVIMIENTO_APERTURA);
				this.archivo = null;
				adjunto = getSirAladiDao().getAdjunto(apertura.getNroMov());
				//statusResponse = new StatusResponse("Archivo adjunto actualizado exit�samente");
			} catch (Exception e) {
				statusResponse = new StatusResponse("Hubo un error al modificar el archivo adjunto " + e.getMessage());
				log.error("Hubo un error al modificar el archivo adjunto " + e.getMessage(), e);
			}
			this.msj = getAlertJS(statusResponse);
		}
	}

	public void mostrarAdjunto(ActionEvent event) {
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("nroMov", this.apertura.getNroMov());
		request.getSession().setAttribute("adjunto", this.archivo);
	}

	public List<SelectItem> getItemsInstitucionesLocales() {
		return itemsInstitucionesLocales;
	}

	public void setItemsInstitucionesLocales(List<SelectItem> itemsInstitucionesLocales) {
		this.itemsInstitucionesLocales = itemsInstitucionesLocales;
	}

	public void setItemsPaisesExterior(List<SelectItem> itemsPaisesExterior) {
		this.itemsPaisesExterior = itemsPaisesExterior;
	}

	public List<SelectItem> getItemsPaisesExterior() {
		return itemsPaisesExterior;
	}

	public void setItemsInstitucionesExterior(List<SelectItem> itemsInstitucionesExterior) {
		this.itemsInstitucionesExterior = itemsInstitucionesExterior;
	}

	public List<SelectItem> getItemsInstitucionesExterior() {
		return itemsInstitucionesExterior;
	}

	public void setItemsInstrumentos(List<SelectItem> itemsInstrumentos) {
		this.itemsInstrumentos = itemsInstrumentos;
	}

	public List<SelectItem> getItemsInstrumentos() {
		return itemsInstrumentos;
	}

	public Pais getPaisConvenio() {
		return paisConvenio;
	}

	public void setPaisConvenio(Pais paisConvenio) {
		this.paisConvenio = paisConvenio;
	}

	public boolean isMostrarModal() {
		return mostrarModal;
	}

	public String getFiltro() {
		return filtro;
	}

	public void setFiltro(String filtro) {
		this.filtro = filtro;
	}

	public List<Apertura> getEmisionesPendientes() {
		return emisionesPendientes;
	}

	public void setEmisionesPendientes(List<Apertura> emisionesPendientes) {
		this.emisionesPendientes = emisionesPendientes;
	}

	public String getEstiloPaginacionPendientes() {
		return (this.emisionesPendientes != null && this.emisionesPendientes.size() > 10) ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	public String getEstiloGrillaPendientes() {
		return (this.emisionesPendientes != null && this.emisionesPendientes.size() > 0) ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	public String getEstiloMsjSinPendientes() {
		return (this.emisionesPendientes != null && this.emisionesPendientes.size() > 0) ? ESTILO_INVISIBLE : ESTILO_VISIBLE;
	}

	public String getEstiloMostrarEmision() {
		return (this.apertura != null && this.apertura.getNroMov() != null && this.apertura.getNroMov() > 0) ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	private void completarDatos() {
		Date fecha = getSirAladiDao().getFechaActual();

		// Apertura
		this.apertura.setCveTipoApe(TIPO_APERTURA_EXPORTACION);
		this.apertura.setCodMoneda(CODIGO_MONEDA_DOLARES);
		this.apertura.setFechaCalc(fecha);

		// Registro
		this.registro.setCveEstadoReg(ESTADO_PENDIENTE);
		this.registro.setCveTipoEmis(TIPO_EMISION_EMISION);
		this.registro.setHaberMo(BigDecimal.ZERO);
		this.registro.setFechaTrans(fecha);
		this.registro.setEstacion(getVisit().getAddress());
		this.registro.setCodUsuario(getVisit().getUsuarioSirAladi().getLogin());
	}
	public void abrirPanelPersonaExp(ActionEvent event) {
		getVisit().setParametro("codPersonaExp", apertura.getPersona());
	}	
	public void seleccionarPersona(ActionEvent event) {
		this.msj = "";
		if (persona == null){
			apertura.setPersona(new Persona());
			return;
		}
		String codPersona = persona.getCodPersona();
		apertura.setCodPersona(codPersona);		
		if (!StringUtils.isEmpty(codPersona)){
			apertura.setPersona(persona);
			apertura.getPersona().setCodPersona(codPersona);
		}else
			apertura.setPersona(new Persona());
		
	}
	public void cancelarPersonaExp(ActionEvent event) {
		persona = (Persona) getVisit().getParametro("codPersonaExp");
		apertura.setCodPersona(persona.getCodPersona());
		apertura.setPersona(persona);
		getVisit().removeParametro("codPersonaExp");
	}	

	public void consultarPendientes(ActionEvent event) {
		this.consultarPendientes();
	}

	private void consultarPendientes() {
		this.msj = "";
		this.emisionesPendientes = getSirAladiDao().getAperturas(TIPO_APERTURA_EXPORTACION, ESTADO_VIGENTE, "R", ESTADO_PENDIENTE,
				getVisit().getUsuarioSirAladi().getPersona(), null, null, null);
		this.emisionesInicial = this.emisionesPendientes;
	}

	public void seleccionarEmisionPendiente(Apertura aperturaSel) {
		log.info("Seleccionado apertura " + aperturaSel.getNroMov());
		this.msj = "";
		this.mostrarModal = false;
		this.apertura = aperturaSel;
		this.recuperarDatos(this.apertura.getNroMov(), true);
		this.emisionesInicial.clear();
		this.emisionesPendientes.clear();
		this.msj = getCierreModalPanelJS("modalPanelPendientes");

	}

	public void filtrar(ActionEvent event) {
		if (StringUtils.isEmpty(this.filtro))
			this.emisionesPendientes = this.emisionesInicial;
		else {
			this.emisionesPendientes = new ArrayList<Apertura>();
			for (Apertura ap : this.emisionesInicial) {
				if (ap.getCodigoReembolso().indexOf(this.filtro.trim()) >= 0)
					this.emisionesPendientes.add(ap);
			}
		}
	}

	private void crearObjetosPorDefecto() {
		this.msj = "";
		this.mostrarModal = true;
		this.paisConvenio = new Pais();
		persona = new Persona();

		// Apertura
		this.apertura = new Apertura();
		this.apertura.setIdentificador(new Identificador());
		this.apertura.setInstitucion(new Institucion());
		this.apertura.setPais(new Pais());
		this.apertura.setPersona(new Persona());

		// Registro
		this.registro = new Registro();
		this.registro.setInstrumento(new Instrumento());
		this.registro.setInstitucion(new Institucion());

		// Combos
		this.itemsInstitucionesLocales = armarSelectItemsPlazasInstituciones(getVisit().getUsuarioSirAladi().getPersona().getInstitucions());
		List<Persona> listaPersona = getSirAladiDao().getEntidadesBCB();
		this.itemsPersonasBCB = armarItemsPersonaBCB(listaPersona);
	}

	public Apertura getApertura() {
		return apertura;
	}

	public void setApertura(Apertura apertura) {
		this.apertura = apertura;
	}

	public Registro getRegistro() {
		return registro;
	}

	public void setRegistro(Registro registro) {
		this.registro = registro;
	}

	public String getMsj() {
		return msj;
	}

	public void setMsj(String msj) {
		this.msj = msj;
	}

	public void setAdjunto(Adjunto adjunto) {
		this.adjunto = adjunto;
	}

	public Adjunto getAdjunto() {
		return adjunto;
	}

	public void setArchivo(Archivo archivo) {
		this.archivo = archivo;
	}

	public Archivo getArchivo() {
		return archivo;
	}

	public void setItemsPersonasBCB(List<SelectItem> itemsPersonasBCB) {
		this.itemsPersonasBCB = itemsPersonasBCB;
	}

	public List<SelectItem> getItemsPersonasBCB() {
		return itemsPersonasBCB;
	}

	public void setPersona(Persona persona) {
		this.persona = persona;
	}

	public Persona getPersona() {
		return persona;
	}
	
}

