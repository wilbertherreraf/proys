/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-web-sirAladi
 * gob.bcb.portal.sirAladi.reportes.controller.RepPagosAnticipadosController
 * 04/10/2011 - 10:56:28
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.reportes.controller;

import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarMapDescripcionClaves;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.getAlertConCierreModalJS;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.getAlertJS;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_ESTADO_PAGO_ANT;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_TIPO_APERTURA;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTADO_LIQUIDADO;
import static gob.bcb.portal.sirAladi.commons.Constantes.FORMATO_FECHA_JAVA;
import static gob.bcb.portal.sirAladi.commons.Constantes.SUCCESS;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.RegAnticipado;
import gob.bcb.bpm.siraladi.jpa.SwfMensaje;
import gob.bcb.bpm.siraladi.pojo.StatusResponse;
import gob.bcb.bpm.siraladi.utils.NumeroDAV;
import gob.bcb.portal.sirAladi.commons.AladiUtils;
import gob.bcb.portal.sirAladi.commons.Servicios;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;
import gob.bcb.portal.sirAladi.dao.DaoFactory;
import gob.bcb.portal.sirAladi.dao.SirAladiDao;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

/**
 * Backing bean de la vista de consulta de pagos anticipados
 * 
 * @author wherrera
 * 
 */
public class RepPagosAnticipadosController extends BaseBeanController {
	private String msj;
	private Date fechaDesde;
	private Date fechaHasta;
	private boolean liquidar;
	private RegAnticipado pagoAnticipado = new RegAnticipado();
	private RegAnticipado pagoAnticipadoIni;
	private SirAladiDao sirAladiDao;
	private List<RegAnticipado> pagosAnticipados = new ArrayList<RegAnticipado>();
	private Map<String, String> mapPaisesBancos;
	private Map<String, String> mapTipoApertura;
	private Map<String, String> mapEstadoAnt;

	private static Logger log = Logger.getLogger(RepPagosAnticipadosController.class);

	public RepPagosAnticipadosController() {
	}

	@PostConstruct
	public void init() {
		log.info("Iniciando el modulo de consulta de pagos anticipados.");
		recuperarVisit();
		this.sirAladiDao = DaoFactory.getInstance().getSirAladiDao();
		this.crearObjetosPorDefecto();
	}

	public void setFechaDesde(Date fechaDesde) {
		this.fechaDesde = fechaDesde;
	}

	public Date getFechaDesde() {
		return fechaDesde;
	}

	public Date getFechaHasta() {
		return fechaHasta;
	}

	public void setFechaHasta(Date fechaHasta) {
		this.fechaHasta = fechaHasta;
	}

	public String getMsj() {
		return msj;
	}

	public void setMsj(String msj) {
		this.msj = msj;
	}

	public boolean isLiquidar() {
		return liquidar;
	}

	public void setLiquidar(boolean liquidar) {
		this.liquidar = liquidar;
	}

	public RegAnticipado getPagoAnticipado() {
		return pagoAnticipado;
	}

	public void setPagoAnticipado(RegAnticipado pagoAnticipado) {
		this.pagoAnticipado = pagoAnticipado;
	}

	public List<RegAnticipado> getPagosAnticipados() {
		return pagosAnticipados;
	}

	public void setPagosAnticipados(List<RegAnticipado> pagosAnticipados) {
		this.pagosAnticipados = pagosAnticipados;
	}

	public Map<String, String> getMapPaisesBancos() {
		return mapPaisesBancos;
	}

	public void setMapPaisesBancos(Map<String, String> mapPaisesBancos) {
		this.mapPaisesBancos = mapPaisesBancos;
	}

	public Map<String, String> getMapTipoApertura() {
		return mapTipoApertura;
	}

	public void setMapTipoApertura(Map<String, String> mapTipoApertura) {
		this.mapTipoApertura = mapTipoApertura;
	}

	public Map<String, String> getMapEstadoAnt() {
		return mapEstadoAnt;
	}

	public void setMapEstadoAnt(Map<String, String> mapEstadoAnt) {
		this.mapEstadoAnt = mapEstadoAnt;
	}

	public void consultarPagosAnticipados(ActionEvent event) {
		this.msj = "";
		this.pagosAnticipados = this.sirAladiDao.getPagosAnticipados(this.fechaDesde, this.fechaHasta);
		if (this.pagosAnticipados == null || this.pagosAnticipados.size() == 0)
			this.msj = getAlertJS("No se encontraron pagos anticipados en el rango de fechas ingresados.");
	}

	public void mostrarReporte() {
		log.info("this.fechaDesde " + this.fechaDesde);
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put(
				"TITULO",
				"PAGOS ANTICIPADOS DEL " + AladiUtils.dateToString(this.fechaDesde, FORMATO_FECHA_JAVA) + " AL "
						+ AladiUtils.dateToString(this.fechaHasta, FORMATO_FECHA_JAVA));
		parametros.put("FECHA_DESDE", fechaDesde);
		parametros.put("FECHA_HASTA", fechaHasta);

		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("pathTranslated", request.getPathTranslated());
		request.getSession().setAttribute("nombreReporte", "repPagosAnticipados.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}

	public void verPagoAnticipado(RegAnticipado regAnticipadoSel) {
		this.msj = "";
		this.pagoAnticipado = regAnticipadoSel;
		this.pagoAnticipadoIni = (RegAnticipado) SerializationUtils.clone(this.pagoAnticipado);
		this.liquidar = false;
	}

	public void irDetalleSwift(RegAnticipado regAnticipadoSel) {
		log.info("irDetalleSwift " + regAnticipadoSel.getNroMov());
		String codope = (regAnticipadoSel.getNroMov() != null ? regAnticipadoSel.getNroMov().toString() : "0");

		SwfMensaje swfMensaje = getServiceDao().getSwfMensajeLocal().findByCodoperacion(codope, null);

		if (swfMensaje != null) {
			getVisit().setParametro("SIRWEB_CODMENSAJE", swfMensaje.getMenCodmen());
			irAPagina("/view/Pagosant/swiftDetail.xhtml");
		} else {
			// this.msj = getAlertJS("Error mensaje swift inexistente");
			addMessageError("Error ", "Mensaje swift inexistente");
		}
	}

	public void liquidarPagoAnticipado(ActionEvent event) {
		this.msj = "";
		if (this.liquidar)
			this.pagoAnticipado.setCveEstadoAnt(ESTADO_LIQUIDADO);
		StatusResponse statusResponse = Servicios.modificarPagoAnticipado(this.pagoAnticipado);
		if (SUCCESS.equals(statusResponse.getStatusCode()))
			this.msj = getAlertConCierreModalJS("modalPanelPagoAnticipado", statusResponse);
		else {
			this.pagoAnticipado.setCveEstadoAnt(this.pagoAnticipadoIni.getCveEstadoAnt());
			this.pagoAnticipado.setSecuencia(this.pagoAnticipadoIni.getSecuencia());
			this.msj = getAlertJS(statusResponse);
		}
	}

	public void generarDAV(ActionEvent event) {
		this.msj = "";
		if (StringUtils.isEmpty(this.pagoAnticipado.getCodInst()) || StringUtils.isEmpty(this.pagoAnticipado.getCodId())
				|| StringUtils.isEmpty(this.pagoAnticipado.getAnio()) || StringUtils.isEmpty(this.pagoAnticipado.getSecuencia())) {
			if (!StringUtils.isEmpty(this.pagoAnticipado.getSecuencia()))
				this.pagoAnticipado.setSecuencia(StringUtils.leftPad(this.pagoAnticipado.getSecuencia(), 6, '0'));
			this.msj = getAlertJS("No se puede generar el DAV, ingrese los campos correctamente.");
		} else {
			this.pagoAnticipado.setSecuencia(StringUtils.leftPad(this.pagoAnticipado.getSecuencia(), 6, '0'));
			this.pagoAnticipado.setDav(NumeroDAV.generaDAV(this.pagoAnticipado.getCodInst(), this.pagoAnticipado.getCodId(),
					this.pagoAnticipado.getAnio(), this.pagoAnticipado.getSecuencia()));
		}
	}

	private void crearObjetosPorDefecto() {
		this.msj = "";
		this.fechaDesde = this.sirAladiDao.getFechaActual();
		this.fechaHasta = this.fechaDesde;

		if (this.mapPaisesBancos == null) {
			List<Institucion> listaBancosCentrales = this.sirAladiDao.getBancosCentralesExterior();
			this.mapPaisesBancos = new HashMap<String, String>();
			for (Institucion bc : listaBancosCentrales)
				this.mapPaisesBancos.put(bc.getCodInst(), bc.getPais().getNomPais().trim());

			this.mapEstadoAnt = armarMapDescripcionClaves(this.sirAladiDao.getClaves(CVE_ESTADO_PAGO_ANT));
			this.mapTipoApertura = armarMapDescripcionClaves(this.sirAladiDao.getClaves(CVE_TIPO_APERTURA));
		}
	}

}
