package gob.bcb.portal.sirAladi.controller;

import gob.bcb.bpm.siraladi.jpa.Param;
import gob.bcb.bpm.siraladi.jpa.Persona;
import gob.bcb.bpm.siraladi.pojo.UsuarioSirAladi;
import gob.bcb.bpm.siraladi.utils.Constants;
import gob.bcb.core.jms.client.JMSConnectionHandler;
import gob.bcb.core.seguridad.web.AuthnHandler;
import gob.bcb.lavado.client.HandlerGeneratorLauCli;
import gob.bcb.portal.sirAladi.commons.AladiUtils;
import gob.bcb.portal.sirAladi.commons.Constantes;
import gob.bcb.portal.sirAladi.dao.DaoFactory;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.jms.JMSException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.ArrayUtils;
import org.apache.log4j.Logger;
import org.springframework.util.CollectionUtils;

public class MainAladiController extends BaseBeanController {
	private static Logger log = Logger.getLogger(MainAladiController.class);	
	private String pagina;
	private String fechaLiteral;
	private String tipoOperacion;
	private Integer nroMov;

	private Persona persona;
	private List<SelectItem> itemsPersonas;
	private Map<String, List<String>> grupoMenuRecurso = new HashMap<String, List<String>>();
	private Map<String, Boolean> menuAutorizado = new HashMap<String, Boolean>();
	private static Map<String, String> prop = new HashMap<String, String>();
	
	public MainAladiController() {
		prop.put("BrokerURL", Constantes.URL_QUEUE_SERVICIO);
	}

	@PostConstruct
	public void init() {
		log.info("***** INCIANDO --------------- *****");
		this.limpiarObjetos();
		setSirAladiDao(DaoFactory.getInstance().getSirAladiDao());

		FacesContext facesContext = FacesContext.getCurrentInstance();
		Map<String, Object> sesiones = facesContext.getExternalContext().getSessionMap();
		removerSesiones(sesiones);
		sesiones.remove("mainController");
		
		HttpServletRequest request = (HttpServletRequest) facesContext.getExternalContext().getRequest();
		this.pagina = "/inicio.xhtml";
		this.fechaLiteral = AladiUtils.dateToFechaLiteral(getSirAladiDao().getFechaActual());

		UsuarioSirAladi usuarioSirAladi = new UsuarioSirAladi(AuthnHandler.getUserPrincipal());

		persona = getSirAladiDao().getEntidadPorUsuario(getCodPersona());

		usuarioSirAladi.setRecursos(CollectionUtils.arrayToList(AuthnHandler.getRecursosUser().toArray()));
		usuarioSirAladi.setRoles(AuthnHandler.getUserRoles());
		usuarioSirAladi.setPersona(persona);
		// codigo de empleado si es bcb de lo contrario sera el login
		String codEmp = (AuthnHandler.getCodEmpleado() == null || AuthnHandler.getCodEmpleado().trim().isEmpty()) ? AuthnHandler.getUserPrincipal()
				: AuthnHandler.getCodEmpleado();
		usuarioSirAladi.setCodEmp(codEmp);
		//configuracion e inicializacion para colas

		try {
			JMSConnectionHandler.initContext(prop);
		} catch (JMSException e) {
			log.error(e.getMessage(), e);
		}
		
		Visit visit = new Visit();
		visit.setUsuarioSirAladi(usuarioSirAladi);
		visit.setMainAladiController(this);
		visit.setAddress(AuthnHandler.getAddress());
		setVisit(visit);
		setAutorizado(visit.getUsuarioSirAladi().getRecAutorizadosMapa());
		getApplication().createValueBinding("#{" + Constantes.SESSION_KEY_USER + "}").setValue(facesContext, visit);
		request.getSession().setAttribute(Constantes.SESSION_KEY_USER, visit);
		this.cargarAutorizaciones();
		
		log.info("FIN PostConstruct ***** INCIANDO SESSION APPLICACION *****");
		log.info("===> Sesion iniciada, usuario[" + visit.getUsuarioSirAladi().getLogin() + "], participante["
				+ visit.getUsuarioSirAladi().getPersona().getCodPersona() + "], perfil:" + ArrayUtils.toString(AuthnHandler.getUserRoles())
				+ ", estacion[" + visit.getAddress() + "]");
	}

	public String getPagina() {
		return pagina;
	}

	public void setPagina(String pagina) {
		this.pagina = pagina;
	}

	public String getFechaLiteral() {
		return fechaLiteral;
	}

	public UsuarioSirAladi getUsuario() {
		// return usuario;
		return getVisit().getUsuarioSirAladi();
	}

	public String getServidor() {
		return Constantes.SERVIDOR;
	}

	public String getTipoOperacion() {
		return tipoOperacion;
	}

	public void setTipoOperacion(String tipoOperacion) {
		this.tipoOperacion = tipoOperacion;
	}

	public Integer getNroMov() {
		return nroMov;
	}

	public void setNroMov(Integer nroMov) {
		this.nroMov = nroMov;
	}

	public String getUrlReporte() {
		return getRaiz() + "ServletReportePDF";
	}

	public String getUrlAdjunto() {
		return getRaiz() + "ServletAdjunto";
	}

	public String getUrlLogout() {
		return getRaiz() + "saml/Logout";
	}

	private static String getRaiz() {
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		String url = request.getRequestURL().toString();
		String direccionRaiz = null;
		if (url.indexOf("/faces") > 0)
			direccionRaiz = url.substring(0, url.indexOf("/faces")) + "/";
		else
			direccionRaiz = url;
		return direccionRaiz;
	}

	public static UsuarioSirAladi getDatosDelUsuario() {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		Map<String, Object> sesiones = facesContext.getExternalContext().getSessionMap();
		MainAladiController menu = (MainAladiController) sesiones.get("mainController");
		return menu.getUsuario();
	}

	public static String getTipoOperacionPaginaActual() {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		Map<String, Object> sesiones = facesContext.getExternalContext().getSessionMap();
		MainAladiController menu = (MainAladiController) sesiones.get("mainController");
		return menu.getTipoOperacion();
	}

	public static Integer getParametroNroMov() {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		Map<String, Object> sesiones = facesContext.getExternalContext().getSessionMap();
		MainAladiController menu = (MainAladiController) sesiones.get("mainController");
		return menu.getNroMov();
	}

	public void irAlInicio(ActionEvent event) {
		irA("/inicio.xhtml");
	}

	public void listenerMenu(ActionEvent event) {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		Map<String, String> map = facesContext.getExternalContext().getRequestParameterMap();
		Map<String, Object> sesiones = facesContext.getExternalContext().getSessionMap();
		getVisit().limpiarParametros();
		getVisit().setCurrentApertura(null);
		removerSesiones(sesiones);
		this.nroMov = null;
		this.pagina = map.get("pagina");
		this.tipoOperacion = map.get("tipoOperacion");
		log.info("oOO0==>en listenerMenu " + getVisit().getCurrentApertura() + " pagina: " + pagina + " tipoOperacion:" + tipoOperacion);
	}
	
	public String ejecutarMenu() {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		Map<String, String> map = facesContext.getExternalContext().getRequestParameterMap();
		Map<String, Object> sesiones = facesContext.getExternalContext().getSessionMap();
		getVisit().limpiarParametros();
		getVisit().setCurrentApertura(null);
		removerSesiones(sesiones);
		this.nroMov = null;
		this.pagina = map.get("pagina");
		this.tipoOperacion = map.get("tipoOperacion");
		getVisit().setParametro("SIRWEB_TMP_CODRECPROT", map.get("codrecprotegido"));
		getVisit().setParametro("SIRWEB_TMP_ACTION", map.get("SIRWEB_TMP_ACTION"));
		log.info("oOO0==>en action listenerMenu " + getVisit().getCurrentApertura()+ " pagina: " + pagina+ " tipoOperacion:" + tipoOperacion);
		return null;
	}
	public void removerSesiones() {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		Map<String, Object> sesiones = facesContext.getExternalContext().getSessionMap();
		removerSesiones(sesiones);
	}	
	private static void removerSesiones(Map<String, Object> sesiones) {
		// pagina inicial
		sesiones.remove("inicioController");
		// parametros
		sesiones.remove("crudParametros");
		// importaci�n
		sesiones.remove("emisionImpController");
		sesiones.remove("modEmisionImpController");
		// exportaci�n
		sesiones.remove("emisionExpController");
		sesiones.remove("modEmisionExpController");
		// comunes
		sesiones.remove("autEmisionController");
		sesiones.remove("eliEmisionController");
		sesiones.remove("enmiendasController");
		sesiones.remove("pagosCobrosController");
		sesiones.remove("negociacionesController");
		// operaciones bcb
		sesiones.remove("clasificacionController");
		sesiones.remove("pagosAnticipadosImpController");
		sesiones.remove("pagosAnticipadosExpController");
		sesiones.remove("pagosAladiController");
		sesiones.remove("actualizarInstitucionesController");
		sesiones.remove("monitorOpeNoRegController");
		// reportes
		sesiones.remove("repInstitucionesController");
		sesiones.remove("repEstadoOpeController");
		sesiones.remove("repHistoricoController");
		sesiones.remove("repPagosAnticipadosController");
		sesiones.remove("repRelPatrominioController");
		sesiones.remove("repOperacionesController");
		sesiones.remove("repSaldosExpController");
		sesiones.remove("repCalificacionController");
		// parametros de reportes y servlets
		sesiones.remove("adjunto");
		sesiones.remove("nroMov");
		sesiones.remove("nombreReporte");
		sesiones.remove("pathTranslated");
		sesiones.remove("parametros");
		sesiones.remove("beanDataSource");
		sesiones.remove("institucionController");		
		sesiones.remove("swfMensajeController");		
		sesiones.remove("usuarioController");		
		sesiones.remove("horarioController");		
		sesiones.remove("parametrosSistController");		
		sesiones.remove("califRiesgoController");		
		sesiones.remove("personaController");		
		sesiones.remove("clasifProductosController");
	}

	public static void irA(String paginaDestino) {
		irA(paginaDestino, null, null);
	}

	public static void irA(String paginaDestino, String tipoOperacion, Integer nroMov) {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		Map<String, Object> sesiones = facesContext.getExternalContext().getSessionMap();
		removerSesiones(sesiones);
		MainAladiController menu = (MainAladiController) sesiones.get("mainController");
		menu.getVisit().limpiarParametros();
		if (nroMov == null)
			menu.getVisit().setCurrentApertura(null);		
		menu.setPagina(paginaDestino);
		menu.setTipoOperacion(tipoOperacion);
		menu.setNroMov(nroMov);
		log.info("En ir pagina " + paginaDestino + " tipoOperacion " + tipoOperacion + " nroMov " + nroMov );
	}

	private void limpiarObjetos() {
		this.pagina = null;
		this.fechaLiteral = null;
		this.tipoOperacion = null;
		this.nroMov = null;
		// this.usuario = null;
	}

	public void cargarMenu() {
		this.grupoMenuRecurso
				.put("SUBMNGRPDATOS",
						Arrays.asList("PARMCALFRI PARMCARGO PARMCATEG PARMCLASPR PARMDETPAT PARMDIAESP PARMHORA PARMINSTIT PARMINSTRU PARMMONE PARMPAIS PARMPARMS PARMPATRI PARMPERSO"
								.split(" ")));

		this.grupoMenuRecurso.put("MNGRPIMPEMIS", Arrays.asList("ALA0101A ALA0101B ALA0101C EMISDEL EMISANULAR".split(" ")));
		this.grupoMenuRecurso.put("MNGRPIMP", Arrays.asList("ALA0102 ALA0103 ALA0104".split(" ")));

		this.grupoMenuRecurso.put("MNGRPEXPEMIS", Arrays.asList("ALA0201A ALA0201B ALA0201C EMISDEL EMISANULAR".split(" ")));
		this.grupoMenuRecurso.put("MNGRPEXP", Arrays.asList("ALA0202 ALA0203 ALA0204".split(" ")));

		this.grupoMenuRecurso.put("MNGRPOPERBCB", Arrays.asList("PARMCLASPR ALA0003 ALA0004 ALA0005 ALA0006 ALA0007".split(" ")));
		this.grupoMenuRecurso
				.put("MNGRPCONSREP", Arrays.asList("ALA0301 ALA0302 ALA0303 ALA0304 ALA0305 ALA0306 ALA0307 ALA0308 ALA0309".split(" ")));
	}

	public boolean esGrpMenuVisible(String idMenu) {
		// determina si el idMenu estar� visible si encuentra al menos uno con
		// permiso
		List<String> opciones = this.grupoMenuRecurso.get(idMenu);
		for (String op : opciones) {
			if (isAuthorized(op)) {
				menuAutorizado.put(idMenu, Boolean.TRUE);
				return true;
			}
		}
		menuAutorizado.put(idMenu, Boolean.FALSE);
		return false;
	}

	public void cargarAutorizaciones() {
		cargarMenu();
		menuAutorizado.clear();
		esGrpMenuVisible("SUBMNGRPDATOS");
		menuAutorizado.put("MNGRPDATOS", menuAutorizado.get("SUBMNGRPDATOS"));
		esGrpMenuVisible("MNGRPIMPEMIS");
		if (!esGrpMenuVisible("MNGRPIMP")) {
			menuAutorizado.put("MNGRPIMP", menuAutorizado.get("MNGRPIMPEMIS"));
		}
		esGrpMenuVisible("MNGRPEXPEMIS");
		if (!esGrpMenuVisible("MNGRPEXP")) {
			menuAutorizado.put("MNGRPEXP", menuAutorizado.get("MNGRPEXPEMIS"));
		}
		esGrpMenuVisible("MNGRPOPERBCB");
		esGrpMenuVisible("MNGRPCONSREP");
	}

	public void removeSessionParams() {
		FacesContext facesContext = getFacesContext();
		log.info("Executing AuthenticationBean.logout()");

		HttpSession session = (HttpSession) facesContext.getExternalContext().getSession(false);
		session.removeAttribute(Constantes.SESSION_KEY_USER);
		if (session != null) {
			session.invalidate();
		}
	}

	public void guardarIFA(ActionEvent event) {
		getVisit().setParametro("codIFA", getVisit().getUsuarioSirAladi().getPersona().getCodPersona());
	}

	public void cambiarIFA(ActionEvent event) {
		persona = getSirAladiDao().getEntidadPorUsuario(persona.getCodPersona());
		getVisit().getUsuarioSirAladi().setPersona(persona);

		Map<String, Object> sesiones = getFacesContext().getExternalContext().getSessionMap();
		getVisit().limpiarParametros();
		getVisit().setCurrentApertura(null);
		removerSesiones(sesiones);
	}

	public void cancelarCambioIFA(ActionEvent event) {
		persona = getSirAladiDao().getEntidadPorUsuario((String) getVisit().getParametro("codIFA"));
		getVisit().getUsuarioSirAladi().setPersona(persona);
		getVisit().removeParametro("codIFA");
	}

	public Map<String, Boolean> getMenuAutorizado() {
		return menuAutorizado;
	}

	public void setPersona(Persona persona) {
		this.persona = persona;
	}

	public Persona getPersona() {
		return persona;
	}

	public String getCodPersona() {
		return AuthnHandler.getCodParticipante();
	}

	public void setItemsPersonas(List<SelectItem> itemsPersonas) {
		this.itemsPersonas = itemsPersonas;
	}

	public List<SelectItem> getItemsPersonas() {
		itemsPersonas = new ArrayList<SelectItem>();
		if (getCodPersona().equals("900")) {
			List<Persona> personaList = getSirAladiDao().getEntidades();
			for (Persona per : personaList)
				itemsPersonas.add(new SelectItem(per.getCodPersona(), per.getNomPersona()));

		}
		return itemsPersonas;
	}

}
