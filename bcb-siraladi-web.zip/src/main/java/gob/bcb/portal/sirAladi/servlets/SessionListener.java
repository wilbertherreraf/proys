package gob.bcb.portal.sirAladi.servlets;


import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.apache.log4j.Logger;

public class SessionListener implements HttpSessionListener {
	private static Logger log = Logger.getLogger(SessionListener.class);

	public void sessionDestroyed(HttpSessionEvent hse) {
//		HttpSession session = hse.getSession();
//		try {
//			Visit visit = Visit.getVisit(session);
//			if (visit != null) {
//				JMSConnectionHandler jMSConnectionHandler = visit.getjMSConnectionHandler();
//				if (jMSConnectionHandler != null){
//					jMSConnectionHandler.close();
//					log.info("Objetos de coneccion JMS cerrados");
//				}
//			} 
//		} catch (Exception e) {
//			log.warn("Error al cerrar conecciones JMS " + e.getMessage());
//		}
	}

	
	public void sessionCreated(HttpSessionEvent arg0) {
		
	}

}
