/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-sirAladi
 * gob.bcb.portal.sirAladi.operacionesBCB.controller.ClasificacionController
 * 15/07/2011 - 15:30:12
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.operacionesBCB.controller;

import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarMapDescripcionClaves;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarSelectDescripcionClaves;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.getAlertJS;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_ESTADO_APERTURA;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTILO_INVISIBLE;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTILO_VISIBLE;
import static gob.bcb.portal.sirAladi.commons.Constantes.SUCCESS;
import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Instrumento;
import gob.bcb.bpm.siraladi.jpa.Registro;
import gob.bcb.bpm.siraladi.pojo.StatusResponse;
import gob.bcb.portal.sirAladi.commons.Servicios;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

/**
 * Backing Bean de la vista de emisi�n de exportaci�n.
 * 
 * @author wherrera
 * 
 */
public class ClasificacionController extends BaseBeanController {
	private static Logger log = Logger.getLogger(ClasificacionController.class);	

	private Apertura apertura;
	private Registro registro;

	private List<Apertura> aperturas;
	private List<SelectItem> itemsClasificacionProductos;
	private Map<String, String> mapClavesEstadoApertura;
	private List<SelectItem> itemsEstadoApertura;

	public ClasificacionController() {
	}

	@PostConstruct
	public void init() {
		log.info("Iniciando el modulo de clasificaci�n.");
		recuperarVisit();

		this.crearObjetosPorDefecto();
		if (getVisit().getParametro("SIRWEB_TMP_OBJECT") != null) {
			if (!(getVisit().getParametro("SIRWEB_TMP_OBJECT") instanceof ClasificacionController)) {
				//getVisit().removeParametro("SIRWEB_TMP_OBJECT");
			} else {

			}
		}
		if (getVisit().getCurrentApertura() != null) {
			this.apertura = getVisit().getCurrentApertura();
			this.registro = getSirAladiDao().getRegistroEmision(this.apertura.getNroMov());
		}
	}

	public Apertura getApertura() {
		return apertura;
	}

	public void setApertura(Apertura apertura) {
		this.apertura = apertura;
	}

	public Registro getRegistro() {
		return registro;
	}

	public void setRegistro(Registro registro) {
		this.registro = registro;
	}

	public List<SelectItem> getItemsClasificacionProductos() {
		return itemsClasificacionProductos;
	}

	public void setItemsClasificacionProductos(List<SelectItem> itemsClasificacionProductos) {
		this.itemsClasificacionProductos = itemsClasificacionProductos;
	}

	public List<Apertura> getAperturas() {
		return aperturas;
	}

	public void setAperturas(List<Apertura> aperturas) {
		this.aperturas = aperturas;
	}

	public String getEstiloMostrarEmision() {
		return (this.apertura != null && this.apertura.getNroMov() != null && this.apertura.getNroMov() > 0) ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	public String getEstiloPaginacionAperturas() {
		return (this.aperturas != null && this.aperturas.size() > 10) ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	public boolean isClasificable() {
		return (this.apertura != null && this.apertura.getClasifProductos() != null && this.apertura.getClasifProductos().getCodClasifprod() != null);
	}

	private void recuperarApertura(Integer nroMovApertura) {
		this.apertura = getSirAladiDao().getApertura(nroMovApertura);
		getVisit().setCurrentApertura(apertura);
	}

	public void cambiarEstadoApe(ActionEvent event) {
		log.info("cambiarEstadoApe " + apertura.getNroMov());
		getVisit().setCurrentApertura(apertura);
	}

	public void guardarClasificacion(ActionEvent event) {
		Integer nroMov = this.apertura.getNroMov();
		StatusResponse statusResponse = null;
		try {
			statusResponse = Servicios.modificarApertura(this.apertura);
			if (SUCCESS.equals(statusResponse.getStatusCode()))
				recuperarApertura(nroMov);
			log.info(statusResponse.getDescrip());
		} catch (Exception e) {
			statusResponse = new StatusResponse("Error al guardar la emisi�n.");
			e.printStackTrace();
		}
		getAlertJS(statusResponse);
	}

	public void cancelarCambios(ActionEvent event) {
		Integer nroMov = this.apertura.getNroMov();
		recuperarApertura(nroMov);
	}

	public void mostrarAdjunto(ActionEvent event) {
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("nroMov", this.apertura.getNroMov());
	}

	private void crearObjetosPorDefecto() {
		// Pendientes
		this.aperturas = new ArrayList<Apertura>();
	
		// Registro
		this.registro = new Registro();
		this.registro.setInstrumento(new Instrumento());
		this.registro.setInstitucion(new Institucion());

		// combos
		this.itemsClasificacionProductos = new ArrayList<SelectItem>();
		this.mapClavesEstadoApertura = armarMapDescripcionClaves(getSirAladiDao().getClaves(CVE_ESTADO_APERTURA));
		this.itemsEstadoApertura = armarSelectDescripcionClaves(getSirAladiDao().getClaves(CVE_ESTADO_APERTURA));
	}

	public void setMapClavesEstadoApertura(Map<String, String> mapClavesEstadoApertura) {
		this.mapClavesEstadoApertura = mapClavesEstadoApertura;
	}

	public Map<String, String> getMapClavesEstadoApertura() {
		return mapClavesEstadoApertura;
	}

	public void setItemsEstadoApertura(List<SelectItem> itemsEstadoApertura) {
		this.itemsEstadoApertura = itemsEstadoApertura;
	}

	public List<SelectItem> getItemsEstadoApertura() {
		return itemsEstadoApertura;
	}

	public boolean isEditable() {
		//reservado para panel edit
		String action = (String) getVisit().getParametro("SIRWEB_TMP_ACTION");
		if (registro.getCveEstadoReg().trim().equals("P")) {
			// return getAutorizado().containsKey("ALA0101A") || getAutorizado().containsKey("ALA0101B") ;
			return action.equals("EDIT");
		}
		return (action.equals("EDIT") && (getAutorizado().containsKey("ALA0101B") || getAutorizado().containsKey("ALA0201B")));
	}
}
