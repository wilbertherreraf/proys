package gob.bcb.portal.sirAladi.view.parametricas;

import gob.bcb.bpm.siraladi.jpa.DiaEspecial;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;

import java.util.List;

import javax.annotation.PostConstruct;

public class DiaEspecialViewBean extends BaseBeanController {
	private List<DiaEspecial> diaEspecialList;

	public DiaEspecialViewBean() {
	}

	@PostConstruct
	public void init() {
		recuperarVisit();
	}

	
	public void setDiaEspecialList(List<DiaEspecial> diaEspecialList) {
		this.diaEspecialList = diaEspecialList;
	}

	public List<DiaEspecial> getDiaEspecialList() {
		return diaEspecialList;
	}

}
