package gob.bcb.portal.sirAladi.servlets;

import net.sf.jasperreports.engine.export.JRExportProgressMonitor;

public class SimpleExportProgressMonitor implements JRExportProgressMonitor{
	private String pathfile;
	
	public void afterPageExport() {

	}

	public void setPathfile(String pathfile) {
		this.pathfile = pathfile;
	}

	public String getPathfile() {
		return pathfile;
	}

}
