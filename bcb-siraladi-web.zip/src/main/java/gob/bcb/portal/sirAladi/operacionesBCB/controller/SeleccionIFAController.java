package gob.bcb.portal.sirAladi.operacionesBCB.controller;

import gob.bcb.bpm.siraladi.jpa.Persona;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.model.SelectItem;

public class SeleccionIFAController extends BaseBeanController {
	private List<SelectItem> itemsInstitucionesLocales;
	private String codInst;
	private Persona persona;
	public SeleccionIFAController() {
	}
	@PostConstruct
	public void init() {
		recuperarVisit();
		if (getVisit().getParametro("SIRWEB_TMP_OBJECT") != null){
			if (!(getVisit().getParametro("SIRWEB_TMP_OBJECT") instanceof SeleccionIFAController)){
				//getVisit().removeParametro("SIRWEB_TMP_OBJECT");
			} else {
				SeleccionIFAController seleccionIFAController = (SeleccionIFAController) getVisit().getParametro("SIRWEB_TMP_OBJECT");
				persona = seleccionIFAController.getPersona();
			}
		}
	}
	public void cambiarIFA(){
		
	}
	public void setCodInst(String codInst) {
		this.codInst = codInst;
	}
	public String getCodInst() {
		return codInst;
	}
	public void setItemsInstitucionesLocales(List<SelectItem> itemsInstitucionesLocales) {
		this.itemsInstitucionesLocales = itemsInstitucionesLocales;
	}
	public List<SelectItem> getItemsInstitucionesLocales() {
		return itemsInstitucionesLocales;
	}
	public void setPersona(Persona persona) {
		this.persona = persona;
	}
	public Persona getPersona() {
		return persona;
	}
}
