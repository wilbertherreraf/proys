package gob.bcb.portal.sirAladi.view;

import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarMapDescripcionClaves;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarSelectItemsInstituciones;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.getAlertConCierreModalJS;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.getAlertJS;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_ESTADO_APERTURA;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_ESTADO_REGISTRO;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_TIPO_EMISION;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTADO_CONTABILIZADO;
import static gob.bcb.portal.sirAladi.commons.Constantes.SUCCESS;
import static gob.bcb.portal.sirAladi.commons.Constantes.TIPO_EMISION_DECREMENTO;
import static gob.bcb.portal.sirAladi.commons.Constantes.TIPO_EMISION_INCREMENTO;
import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Registro;
import gob.bcb.bpm.siraladi.pojo.StatusResponse;
import gob.bcb.portal.sirAladi.commons.Servicios;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

public class RegistroViewBean extends BaseBeanController {
	private static Logger log = Logger.getLogger(RegistroViewBean.class);
	private String msj;
	private Apertura apertura;
	private Registro registro;
	private BigDecimal totalEmision;
	private List<Registro> registroList;
	private List<SelectItem> itemsInstituciones;
	private Map<String, String> mapClavesTipoEmision;
	private Map<String, String> mapClavesEstadoRegistro;
	private Map<String, String> mapClavesEstadoApertura;

	public RegistroViewBean() {
	}

	@PostConstruct
	public void init() {
		log.info("Iniciando el modulo de enmiendas.");
		recuperarVisit();
		crearObjetosPorDefecto();
		
		if (getVisit().getParametro("SIRWEB_TMP_OBJECT") != null) {
			if (!(getVisit().getParametro("SIRWEB_TMP_OBJECT") instanceof RegistroViewBean)) {
				// getVisit().removeParametro("SIRWEB_TMP_OBJECT");
			} else {
				RegistroViewBean objeto = (RegistroViewBean) getVisit().getParametro("SIRWEB_TMP_OBJECT");
				registro = objeto.getRegistro();
			}
		}

		if (getVisit().getCurrentApertura() != null) {
			apertura = getSirAladiDao().getApertura(getVisit().getCurrentApertura().getNroMov());
			recuperarRegistros();
		}
	}

	private void recuperarRegistros() {
		registroList = getSirAladiDao().getRegistros(apertura.getNroMov());
		totalEmision = BigDecimal.ZERO;
		if (registroList != null && registroList.size() > 0) {
			for (Registro p : registroList)
				totalEmision = totalEmision.add(p.getDebeMo().subtract(p.getHaberMo()));
		}		
		List<Institucion> listaInstituciones;
		if (apertura.getCveTipoApe().trim().equals("I"))
			listaInstituciones = getSirAladiDao().getInstitucionesPorPais(apertura.getPais().getCodPais());
		else
			listaInstituciones = getVisit().getUsuarioSirAladi().getPersona().getInstitucions();

		this.itemsInstituciones = armarSelectItemsInstituciones(listaInstituciones);

		this.mapClavesTipoEmision = armarMapDescripcionClaves(getSirAladiDao().getClaves(CVE_TIPO_EMISION));
		this.mapClavesEstadoRegistro = armarMapDescripcionClaves(getSirAladiDao().getClaves(CVE_ESTADO_REGISTRO));
		this.mapClavesEstadoApertura = armarMapDescripcionClaves(getSirAladiDao().getClaves(CVE_ESTADO_APERTURA));

	}
	public void adicionarRegistro() {
		this.msj = "";
			this.registro = new Registro();
			this.registro.setInstitucion(registroList.get(0).getInstitucion());
			this.registro.setInstrumento(registroList.get(0).getInstrumento());
			this.registro.setNit(registroList.get(0).getNit());
			this.registro.setCodUsuario(getVisit().getUsuarioSirAladi().getLogin());
		getVisit().setParametro("SIRWEB_TMP_OBJECT", this);		
	}
	public void modificarRegistro(Registro registroSel) {
		this.msj = "";
			this.registro = registroSel;
			if (this.registro.getHaberMo().compareTo(BigDecimal.ZERO) > 0) {
				this.registro.setDebeMo(this.registro.getHaberMo().multiply(new BigDecimal(-1)));
				this.registro.setHaberMo(BigDecimal.ZERO);
			}

		getVisit().setParametro("SIRWEB_TMP_OBJECT", this);		
	}

	public void registrarRegistro(ActionEvent event) {
		this.msj = "";
		if (this.registro.getDebeMo().compareTo(BigDecimal.ZERO) >= 0) {
			if (this.registro.getCveTipoEmis() == null)
				this.registro.setCveTipoEmis(TIPO_EMISION_INCREMENTO);
			this.registro.setHaberMo(BigDecimal.ZERO);
		} else {
			this.registro.setCveTipoEmis(TIPO_EMISION_DECREMENTO);
			this.registro.setHaberMo(this.registro.getDebeMo().abs());
			this.registro.setDebeMo(BigDecimal.ZERO);
		}

		StatusResponse statusResponse = null;
		this.registro.setFechaTrans(getSirAladiDao().getFechaActual());
		if (this.registro.getNroMov() != null && this.registro.getNroMov() > 0)
			statusResponse = Servicios.modificarRegistro(this.apertura, this.registro);
		else
			statusResponse = Servicios.registrarRegistro(this.apertura, this.registro);
		if (SUCCESS.equals(statusResponse.getStatusCode())) {
			registroList = getSirAladiDao().getRegistros(this.apertura.getNroMov());
			this.msj = getAlertConCierreModalJS("panelRegistro", statusResponse);
		} else
			this.msj = getAlertJS(statusResponse);
	}

	private void crearObjetosPorDefecto() {
		this.msj = "";
		// Registros
		registroList = new ArrayList<Registro>();

		// mapas y combos vacios
		this.itemsInstituciones = new ArrayList<SelectItem>();
	}

	public void autorizarRegistro(Registro registroSel) {
		log.info("autorizando registro " + registroSel.getNroMov());		
		this.msj = "";
		this.registro = registroSel;
		StatusResponse statusResponse = null;
			this.registro.setCveEstadoReg(ESTADO_CONTABILIZADO);
			statusResponse = Servicios.modificarRegistro(this.apertura, this.registro);

		if (SUCCESS.equals(statusResponse.getStatusCode()))
			registroList = getSirAladiDao().getRegistros(this.apertura.getNroMov());
		this.msj = getAlertJS(statusResponse);
		
	}

	public void eliminarRegistro(Registro registroSel) {
		log.info("Eliminando registro " + registroSel.getNroMov());
		this.msj = "";
		this.registro = registroSel;
		StatusResponse statusResponse = null;
		statusResponse = Servicios.eliminarRegistro(this.apertura, this.registro);
		if (SUCCESS.equals(statusResponse.getStatusCode()))
			registroList = getSirAladiDao().getRegistros(this.apertura.getNroMov());
		this.msj = getAlertJS(statusResponse);
		
	}

	public void mostrarReporte(ActionEvent event) {
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("NRO_MOV", this.apertura.getNroMov());
		parametros.put("TITULO", "ENMIENDAS");
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("pathTranslated", request.getPathTranslated());
		request.getSession().setAttribute("nombreReporte", "repEnmiendas.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}

	public String getMsj() {
		return msj;
	}

	public void setMsj(String msj) {
		this.msj = msj;
	}

	public Apertura getApertura() {
		return apertura;
	}

	public void setApertura(Apertura apertura) {
		this.apertura = apertura;
	}

	public Registro getRegistro() {
		return registro;
	}

	public void setRegistro(Registro registro) {
		this.registro = registro;
	}

	public List<Registro> getRegistroList() {
		return registroList;
	}

	public void setRegistroList(List<Registro> registroList) {
		this.registroList = registroList;
	}

	public List<SelectItem> getItemsInstituciones() {
		return itemsInstituciones;
	}

	public void setItemsInstituciones(List<SelectItem> itemsInstituciones) {
		this.itemsInstituciones = itemsInstituciones;
	}

	public Map<String, String> getMapClavesTipoEmision() {
		return mapClavesTipoEmision;
	}

	public void setMapClavesTipoEmision(Map<String, String> mapClavesTipoEmision) {
		this.mapClavesTipoEmision = mapClavesTipoEmision;
	}

	public Map<String, String> getMapClavesEstadoRegistro() {
		return mapClavesEstadoRegistro;
	}

	public void setMapClavesEstadoRegistro(Map<String, String> mapClavesEstadoRegistro) {
		this.mapClavesEstadoRegistro = mapClavesEstadoRegistro;
	}

	public Map<String, String> getMapClavesEstadoApertura() {
		return mapClavesEstadoApertura;
	}

	public void setMapClavesEstadoApertura(Map<String, String> mapClavesEstadoApertura) {
		this.mapClavesEstadoApertura = mapClavesEstadoApertura;
	}

	public void setTotalEmision(BigDecimal totalEmision) {
		this.totalEmision = totalEmision;
	}

	public BigDecimal getTotalEmision() {
		return totalEmision;
	}

}
