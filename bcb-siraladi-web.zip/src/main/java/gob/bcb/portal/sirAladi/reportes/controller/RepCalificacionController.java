/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-web-sirAladi
 * gob.bcb.portal.sirAladi.reportes.controller.RepCalificacionController
 * 04/10/2011 - 10:56:28
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.reportes.controller;

import gob.bcb.portal.sirAladi.controller.BaseBeanController;
import gob.bcb.portal.sirAladi.dao.DaoFactory;
import gob.bcb.portal.sirAladi.dao.SirAladiDao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

/**
 * Backing bean de la vista de consulta de calificaciones de riesgo.
 * 
 * @author wherrera
 * 
 */
public class RepCalificacionController extends BaseBeanController {
	private String query;

	private SirAladiDao sirAladiDao;
	private List<List<Object>> listaCalificaciones;

	private static Logger log = Logger.getLogger(RepCalificacionController.class);

	public RepCalificacionController() {
	}

	@PostConstruct
	public void init() {
		log.info("Iniciando el modulo de consulta de califiaciones de riesgo.");
		recuperarVisit();
		this.sirAladiDao = DaoFactory.getInstance().getSirAladiDao();
		this.consultarCalificaciones();

	}

	public List<List<Object>> getListaCalificaciones() {
		return listaCalificaciones;
	}

	private void consultarCalificaciones() {
		StringBuffer sb = new StringBuffer();
		sb.append("SELECT per.cod_persona, per.nom_persona, ");
		sb.append("cal.cod_calif, cal.plazo, cat.fecha_vig ");
		sb.append("FROM calif_riesgo cal, categoria cat, persona per ");
		sb.append("WHERE cal.cod_calif = cat.cod_calif ");
		sb.append("AND cat.cod_persona = per.cod_persona ");
		sb.append("AND cat.cve_vigente = 'V' ORDER BY 1");
		this.query = sb.toString();
		this.listaCalificaciones = this.sirAladiDao.ejecutarQueryListas(this.query);
	}

	public void mostrarReporte(ActionEvent event) {
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("TITULO", "CALIFICACIONES DE RIESGO");
		parametros.put("QUERY", this.query);
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("pathTranslated", request.getPathTranslated());
		request.getSession().setAttribute("nombreReporte", "repCalificaciones.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}

}
