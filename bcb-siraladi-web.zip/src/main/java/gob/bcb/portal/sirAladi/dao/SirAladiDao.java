/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-web-sirAladi
 * gob.bcb.portal.sirAladi.dao.SirAladiDao
 * 14/11/2011 - 14:48:32
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.dao;

import gob.bcb.bpm.siraladi.jpa.Adjunto;
import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.ClasifProductos;
import gob.bcb.bpm.siraladi.jpa.Claves;
import gob.bcb.bpm.siraladi.jpa.DetPatrimonio;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Instrumento;
import gob.bcb.bpm.siraladi.jpa.Pago;
import gob.bcb.bpm.siraladi.jpa.Pais;
import gob.bcb.bpm.siraladi.jpa.Patrimonio;
import gob.bcb.bpm.siraladi.jpa.Persona;
import gob.bcb.bpm.siraladi.jpa.PlanPago;
import gob.bcb.bpm.siraladi.jpa.RegAnticipado;
import gob.bcb.bpm.siraladi.jpa.Registro;
import gob.bcb.bpm.siraladi.jpa.TPagoImp;
import gob.bcb.bpm.siraladi.pojo.UsuarioSirAladi;
import gob.bcb.bpm.siraladi.service.ServiceDao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.orm.hibernate3.HibernateTemplate;

/**
 * Interface para acceso a datos del Sir Aladi.
 * 
 * @author wherrera
 * 
 */
public interface SirAladiDao {

	/**
	 * Recupera las claves a partir de un nombre.
	 */
	public List<Claves> getClaves(String nomDato);

	/**
	 * Recupera la descripci�n de una clave dado el nombre y valor.
	 */
	public String getDescripcionClave(String nomDato, String valDato);

	/**
	 * Recupera todas las entidades financieras.
	 */
	
	public List<Persona> getEntidades();
	public List<Persona> getEntidadesBCB();
	/**
	 * Recupera la entidad financiera de un usuario, con sus correspondientes
	 * instituciones.
	 */
	public Persona getEntidadPorUsuario(String codPersona);
	public BigDecimal getSaldoContMo(String codPersona, Date fecha);
	/**
	 * Recupera todos los paises.
	 */
	public List<Pais> getPaises();

	/**
	 * Recupera los paises del exterior.
	 */
	public List<Pais> getPaisesExterior();

	/**
	 * Recupera todos los instrumentos.
	 */
	public List<Instrumento> getInstrumentos();

	/**
	 * Recupera los instrumentos a partir de sus c�digos.
	 */
	public List<Instrumento> getInstrumentos(List<String> codigosInstrumentos);

	/**
	 * Recupera una instituciones a partir de sus c�digo.
	 */
	public Institucion getInstitucion(String codInstitucion);

	/**
	 * Recupera las instituciones a partir de sus c�digos.
	 */
	public List<Institucion> getInstituciones(List<String> codigosInstituciones);

	/**
	 * Recupera las instituciones v�lidas de un pais.
	 */
	public List<Institucion> getInstitucionesPorPais(String codPais);

	/**
	 * Recupera las instituciones que son bancos centrales de un pais;
	 */
	public List<Institucion> getBancosCentralesExterior();

	/**
	 * Recupera las instituciones de un pais, considera todos los estados.
	 */
	public List<Institucion> getInstitucionesReporte(String codPais);

	/**
	 * Recupera la Instituci�n que es Banco Central de un pais.
	 */
	public Institucion getBancoCentralPorPais(String codPais);

	/**
	 * Recupera todos la clasificaci�n de productos.
	 */
	List<ClasifProductos> getClasificacionProductos();

	/**
	 * Recupera la clasificaci�n de productos.
	 */
	ClasifProductos getClasifProductos(Integer codClasifprod);
	Persona getPersona(String codPersona);
	/**
	 * Recupera el adjunto asociado a un n�mero de movimiento.
	 */
	Adjunto getAdjunto(Integer nroMov);

	/**
	 * Recupera la Apertura a partir del c�digo de reembolso.
	 */
	public Apertura getApertura(Apertura apertura);

	public List<Apertura> getAperturas(Apertura apertura, UsuarioSirAladi usuario);

	/**
	 * Recupera la Apertura a partir del n�mero de movimiento.
	 */
	public Apertura getApertura(Integer nroMov);

	/**
	 * Recupera el Registro correspondiente a la emisi�n de un instrumento.
	 */
	public Registro getRegistroEmision(Integer nroMovApertura);

	/**
	 * Recupera los Registros a partir de un n�mero de movimiento.
	 */
	public List<Registro> getRegistros(Integer nroMovApertura);

	/**
	 * Recupera los Pagos a partir de un n�mero de movimiento.
	 */
	public List<Pago> getPagos(Integer nroMovApertura);

	/**
	 * Recupera los Planes de Pagos a partir de un n�mero de movimiento.
	 */
	public List<PlanPago> getPlanPagos(Integer nroMovApertura);

	/**
	 * Recupera un pago anticipado segun su codigo de reembolso.
	 */
	public RegAnticipado getPagoAnticipado(RegAnticipado pagoAnticipado);

	/**
	 * Recupera los Pagos Anticipados de acuerdo al tipo de apertura y estado.
	 */
	public List<RegAnticipado> getPagosAnticipados(String tipoApertura, String estado);

	/**
	 * Recupera los Pagos Anticipados entre dos fechas.
	 */
	public List<RegAnticipado> getPagosAnticipados(Date fechaDesde, Date fechaHasta);

	/**
	 * Valida si un usuario esta autorizado para ver una apertura, de acuerdo a
	 * la instituci�n a la que pertenece.
	 */
	public boolean usuarioPuedeVerApertura(UsuarioSirAladi usuario, Apertura apertura, String tipoApertura);

	/**
	 * Obtiene el monto de un instrumento.
	 */
	public BigDecimal getMontoInstrumento(Integer nroMovApertura);

	/**
	 * Obtiene el monto total pagado de un instrumento.
	 */
	public BigDecimal getMontoPagadoInstrumento(Integer nroMovApertura);

	public BigDecimal getSumaPlanPagos(Integer nroMovApertura);

	/**
	 * Obtiene el n�mero de pagos pendientes por operaciones de importaci�n.
	 */
	public int getNroPagosPendientesImportacion(Persona entidad);

	/**
	 * Obtiene las aperturas con pagos pendientes por operaciones de
	 * importaci�n.
	 */
	public List<Apertura> getAperturasConPagosPendientesImportacion(Persona entidad, String estadoPago);

	/**
	 * Obtiene las aperturas de una entidad, de acuerdo a criterios.
	 */
	public List<Apertura> getAperturas(String tipoApertura, String estadoApertura, String tipoReg, String estadoRegistro, Persona entidad,
			Date fechaDesde, Date fechaHasta, String codConvenio);

	public Patrimonio getMaxPatrimonio();

	public List<DetPatrimonio> getDetPatrimonios(Integer nroOrden);

	public Patrimonio getPatrimonio(Integer nroOrden);

	/**
	 * Obtiene las aperturas de una entidad, de acuerdo a criterios.
	 */
	public List<Patrimonio> getPatrimonios(Date fechaDesde, Date fechaHasta);

	/**
	 * Obtiene las operaciones no registradas.
	 */
	public List<TPagoImp> getOpeNoRegistradas();

	/**
	 * Obtiene una sesi�n stateless.
	 */
	public Connection getConnection();

	/**
	 * Ejecuta un query nativo, obtiene una lista de mapas.
	 */
	public List<Map<String, Object>> ejecutarQueryMapas(String query);

	/**
	 * Ejecuta un query nativo, obtiene una lista de listas de objetos.
	 */
	public List<List<Object>> ejecutarQueryListas(String query);

	/**
	 * Ejecuta una sentencia DML nativa.
	 */
	public boolean ejecutarDml(String sentenciaDml);

	/**
	 * Recupera la fecha actual de la Base de Datos.
	 */
	public Date getFechaActual();

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate);

	public HibernateTemplate getHibernateTemplate();

	public Pais getPaisConvenio(Apertura apertura);

	ServiceDao getServiceDao();

	void setServiceDao(ServiceDao serviceDao);
}
