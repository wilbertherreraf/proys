/**
 * Banco Central De Bolivia
 * La Paz - Bolivia 
 * bcb-portal-portletBase
 * gob.bcb.portal.sirAladi.parametros.logica.OperacionesParametros
 * 09/06/2011 - 13:33:52 
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.parametros.logica;

import gob.bcb.core.seguridad.web.AuthnHandler;
import gob.bcb.portal.sirAladi.dao.DaoFactory;
import gob.bcb.portal.sirAladi.dao.SirAladiDao;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.el.ValueExpression;
import javax.faces.component.UIComponent;
import javax.faces.component.UISelectItem;
import javax.faces.component.html.HtmlInputText;
import javax.faces.component.html.HtmlOutputText;
import javax.faces.component.html.HtmlSelectOneMenu;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.NumberConverter;
import javax.faces.event.ActionEvent;
import javax.faces.event.MethodExpressionActionListener;

import org.richfaces.component.html.HtmlCalendar;
import org.richfaces.component.html.HtmlDatascroller;
import org.richfaces.component.html.HtmlInplaceInput;

/**
 * 
 * Clase que contiene metodos para realizar setencias DML y procesar datos
 * correspondientes al modulo de Mmantenimiento de tablas param�tricas.
 * 
 * @author wherrera
 * 
 */
public class OperacionesParametros
{	
	public final String ENTERO = "ENTERO";
	public final String REAL = "REAL";
	public final String CADENA = "CADENA";
	public final String FECHA = "FECHA";
	public final String FECHA_HORA = "FECHA_HORA";
	
	public final String FORMATO_FECHA_IFX = "'%d/%m/%Y'";
	public final String FORMATO_FECHA_HORA_IFX = "'%d/%m/%Y %H:%M:%S'";
	public final String FORMATO_FECHA_JAVA = "dd/MM/yyyy";
	public final String FORMATO_FECHA_HORA_JAVA = "dd/MM/yyyy HH:mm";
	
	public final String SELECT = "SELECT";
	public final String INSERT = "INSERT";
	public final String UPDATE = "UPDATE";
	public final String DELETE = "DELETE";
	
	public static final String CLAVES = "claves";
	
	private SirAladiDao sirAladiDao;	
	
	public OperacionesParametros()
	{
		this.sirAladiDao = DaoFactory.getInstance().getSirAladiDao();
	}
	
	
	/**
	 * Metodo que obtiene las tablas parametricas de una base de datos apartir de
	 * una consulta al diccionario de datos
	 * 
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public List<Tabla> getTablasParametricas() throws Exception
	{
		List listaConfigTablas = this.getConfigTablas();
		Map<String, List<Columna>> mapConfigColumnas = this.getConfigColumnas();
		List<Tabla> tablas = new ArrayList<Tabla>();
		for (Object object : listaConfigTablas)
		{
			Map mapTabla = (Map) object;
			MaestroDetalle maestroDetalle = null;
			if (mapTabla.get("tabla_hijo") != null
					&& ((String) mapTabla.get("tabla_hijo")).trim().length() > 0)
			{
				maestroDetalle = new MaestroDetalle(mapTabla.get("nombre_tabla"),
						mapTabla.get("tabla_hijo"),mapTabla.get("join_columna_padre"),
						mapTabla.get("join_columna_hijo"));
			}
			tablas.add(new Tabla(mapTabla.get("id_tabla"), mapTabla.get("nombre_tabla"),
					mapTabla.get("descripcion_tabla"), mapTabla.get("visible"), 
					mapTabla.get("insert"),mapTabla.get("update"), mapTabla.get("delete"),
					mapTabla.get("where"), mapConfigColumnas.get(mapTabla.get("id_tabla")),
					maestroDetalle));
		}
		return tablas;
	}
	
	
	/**	  
	 * Metodo que obtiene en una estructura el bloque de datos de una tabla padre
	 *
	 * @param tabla
	 * @param like
	 * @return
	 */
	public List<List<String>> getDatosTablaPadre(Tabla tabla, String like) {
		String query = getQueryDatosTabla(tabla, like);
		return this.getDatosTabla(query);
	}
	
	
	/**
	 * Metodo que obtiene en una estructura el bloque de datos de una tabla hijo
	 *
	 * @param tabla
	 * @param maestroDetalle
	 * @param rowIdRegistro
	 * @param like
	 * @return
	 */
	public List<List<String>> getDatosTablaHijo(Tabla tabla,
			MaestroDetalle maestroDetalle, String rowIdRegistro, String like)
	{
		String query = getQueryDatosTabla(tabla, maestroDetalle, rowIdRegistro, like);
		return this.getDatosTabla(query);
	}

	
	/**	 
	 * Metodo que obtiene datos de una dabla parametroca apartir de un query
	 * armado dinamicamente
	 * 
	 * @param query
	 * @return
	 */
	private List<List<String>> getDatosTabla(String query)
	{				
		List<List<Object>> datosObjectos = this.sirAladiDao.ejecutarQueryListas(query);
		List<List<String>> datos = new ArrayList<List<String>>();
		for (List<Object> fila : datosObjectos)
		{
			List<String> registro = new ArrayList<String>();
			for (Object dato : fila)
				registro.add((String) dato);
			datos.add(registro);
		}
		return datos;
	}

	
	/**
	 * Metodo que ejecuta una sentencia DML
	 * 
	 * @param sentencia
	 */
	public void ejecutarSentenciaDML(String sentencia) throws Exception
	{
		if (!this.sirAladiDao.ejecutarDml(sentencia))
			throw new Exception("Error al ejecutar sentencia DML: " + sentencia);
	}

	
	/**
	 * Metodo que consulta a BD la configuracion de tablas parametricas
	 *
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	private List getConfigTablas() throws Exception
	{		
		Set<String> recursos = AuthnHandler.getRecursosUser();
		StringBuffer sb = new StringBuffer();
		if (recursos.contains("PARMCATEG"))
			sb.append("'categoria', ");
		if (recursos.contains("PARMCLASPR"))
			sb.append("'clasif_productos', ");
		if (recursos.contains("PARMDIAESP"))
			sb.append("'dia_especial', ");
		if (recursos.contains("PARMHORA"))
			sb.append("'horario', ");
		if (recursos.contains("PARMPERSO"))
			sb.append("'persona', ");
		if (recursos.contains("PARMINSTRU"))
			sb.append("'instrumento', ");
		if (recursos.contains("PARMINSTIT"))
			sb.append("'institucion', ");
		if (recursos.contains("PARMMONE"))
			sb.append("'moneda', ");
		if (recursos.contains("PARMPAIS"))
			sb.append("'pais', ");
		if (recursos.contains("PARMPARMS"))
			sb.append("'params', ");
		if (recursos.contains("PARMPATRI"))
			sb.append("'patrimonio', ");
		if (recursos.contains("PARMCALFRI"))
			sb.append("'calif_riesgo', ");
		if (recursos.contains("PARMCARGO"))
			sb.append("'cargo', ");
		String filtroTablas = null;
		if (sb.length() > 0)
			filtroTablas = "AND pt.nombre_tabla IN (" + sb.substring(0, sb.length() - 2) + ") ";
		StringBuffer query = new StringBuffer(); 
		query.append("SELECT TO_CHAR(pt.id_tabla) id_tabla, pt.nombre_tabla, ");
		query.append("pt.descripcion_tabla, pt.visible, pt.insert, pt.update, pt.delete, ");
		query.append("NVL(pt.where,'') where, NVL(pmd.tabla_hijo,'') tabla_hijo, ");
		query.append("NVL(pmd.join_columna_padre,'') join_columna_padre, ");
		query.append("NVL(pmd.join_columna_hijo,'') join_columna_hijo ");
		query.append("FROM parametros_tablas pt, ");
		query.append("OUTER parametros_maestro_detalle pmd, systables st ");
		query.append("WHERE pt.nombre_tabla = pmd.tabla_padre ");
		if (filtroTablas != null)
			query.append(filtroTablas);
		query.append("AND pt.id_tabla = st.tabid AND pt.nombre_tabla = st.tabname ");
		query.append("ORDER BY pt.nombre_tabla");
		return this.sirAladiDao.ejecutarQueryMapas(query.toString());
	}
	
	
	/**
	 * Metodo que consulta a BD la configuracion de las columnas de tablas
	 * parametricas
	 * 
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes" )
	private Map<String, List<Columna>> getConfigColumnas()
			throws Exception
	{
		String query = "SELECT TO_CHAR(pc.id_tabla) id_tabla, "
				+ "pc.nombre_columna, pc.descripcion_columna, pc.tipo_dato, "
				+ "TO_CHAR(pc.max_length) max_length, pc.visible, pc.editable, "
				+ "pc.requerido, pc.log, NVL(TO_CHAR(pc.order_by),'') order_by, "
				+ "NVL(pc.join_tabla,'') join_tabla, NVL(pc.join_codigo,'') "
				+ "join_codigo, NVL(pc.join_descripcion,'') join_descripcion "
				+ "FROM parametros_columnas pc, syscolumns sc "
				+ "WHERE pc.id_tabla = sc.tabid "
				+ "AND pc.nombre_columna = sc.colname ORDER BY pc.id_tabla, orden";		
		List listaResultado = this.sirAladiDao.ejecutarQueryMapas(query);
		if (listaResultado == null || listaResultado.size() == 0)
			throw new Exception("La configuracion de columnas no es valida.");
		Map<String, List<Columna>> mapColumnas = new HashMap<String, List<Columna>>();
		List<Columna> columnas = null;
		String tabId = "";
		for (Object object : listaResultado)
		{
			Map mapColumna = (Map) object;
			if (!tabId.equals(mapColumna.get("id_tabla")))
			{
				if (tabId.length() > 0 && columnas != null)				
					mapColumnas.put(tabId, columnas);
				tabId = (String) mapColumna.get("id_tabla");
				columnas = new ArrayList<Columna>();
			}
			columnas.add(new Columna(mapColumna.get("nombre_columna"), 
					mapColumna.get("descripcion_columna"), mapColumna.get("tipo_dato"), 
					mapColumna.get("max_length"), mapColumna.get("visible"), 
					mapColumna.get("editable"),mapColumna.get("requerido"), 
					mapColumna.get("log"), mapColumna.get("order_by"), 
					mapColumna.get("join_tabla"), mapColumna.get("join_codigo"),
					mapColumna.get("join_descripcion")));
		}
		mapColumnas.put(tabId, columnas);
		return mapColumnas;
	}
	
	
	/**	  
	 * Metodo que realiza una consulta para obtener datos permitidos en un campo
	 * para el registro y actualizacion de un registro. 
	 *
	 * @param columna
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public List<UISelectItem> getListaValoresColumna(Columna columna)
			throws Exception
	{
		List<UISelectItem> listaSelectItem = null;
		if(columna.getJoinTabla() != null)
		{
			StringBuilder query = new StringBuilder("SELECT ");
			if(columna.getJoinTabla().equals(CLAVES))
				query.append("valdato, ");
			else
				query.append(columna.getJoinCodigo()).append(", ");
			query.append(columna.getJoinDescripcion()).append(" FROM ");
			query.append(columna.getJoinTabla()).append(" ");
			if(columna.getJoinTabla().equals(CLAVES))
			{
				query.append("WHERE nomdato = '");
				query.append(columna.getJoinCodigo()).append("' ");
			}
			query.append("ORDER BY 2");
			List<Map<String, Object>> listaResultado = this.sirAladiDao.ejecutarQueryMapas(query.toString());
			if(listaResultado != null && listaResultado.size()>0)
			{
				listaSelectItem = new ArrayList<UISelectItem>();
				for (Object object : listaResultado)
				{
					Map<Object, Object> mapColumna = (Map<Object, Object>) object;
					UISelectItem selectItem = new UISelectItem();
					if(columna.getJoinTabla().equals(CLAVES))
						selectItem.setItemValue(((String) mapColumna.get("valdato")).trim());
					else
						selectItem.setItemValue(((String) mapColumna.get(columna.getJoinCodigo())).trim());
					selectItem.setItemLabel(((String) mapColumna.get(columna.getJoinDescripcion())).trim());
					listaSelectItem.add(selectItem);
				}
			}
		}
		return listaSelectItem;
	}
	
	
	/**	 
	 * Metodo que arma el query de consulta a una tabla parametrica para 
	 * desplegar los campos segun configuracion en tablas (normal y maestro-detalle).
	 *
	 * @param tabla
	 * @return
	 */
	public String getQueryDatosTabla(Tabla tabla, MaestroDetalle maestroDetalle, String rowIdRegistro, String like)
	{
		List<Columna> listaColumnas = tabla.getColumnas();
		StringBuilder query = new StringBuilder();
		StringBuilder select = new StringBuilder("SELECT TO_CHAR(ROWID) rowid, ");
		StringBuilder where = new StringBuilder();
		StringBuilder orderBy = new StringBuilder();
		String from = "FROM " + tabla.getNombreTabla() + " t ";
		Map<Integer, String> mapOrderBy = new TreeMap<Integer, String>();
		
		// recorrido de las columnas
		for (Columna columna : listaColumnas)
		{
			// armado de cada columna para la clausula select
			String col = "t." + columna.getNombreColumna();
			if(columna.getJoinTabla() != null)
			{
				select.append("(SELECT ").append(columna.getJoinDescripcion());
				select.append(" FROM ").append(columna.getJoinTabla());
				select.append(" WHERE ");
				if(columna.getJoinTabla().equals(CLAVES))
				{
					select.append(" nomdato = '").append(columna.getJoinCodigo());
					select.append("' AND valdato");
				}
				else
					select.append(columna.getJoinCodigo());
				select.append(" = ").append(col).append(") ");
			}
			else			
				select.append(darFormatoIfxOut(col, columna.getTipoDato()));
			select.append(columna.getNombreColumna()).append(", ");
			// obtiene los criterios de ordenacion
			if (columna.getOrderBy() != null)
			{
				String nombreColOrder;
				if (columna.getOrderBy().startsWith("-"))
					nombreColOrder = "t." + columna.getNombreColumna() + " DESC";
				else
					nombreColOrder = "t." + columna.getNombreColumna();
				mapOrderBy.put(Integer.valueOf(columna.getOrderBy().replaceFirst("\\-", "")), nombreColOrder);
			}
		}
		select.delete(select.length()-2, select.length()-1);
		// armado de la clausula where 
		if (maestroDetalle != null)
		{
			where.append(" WHERE ").append(maestroDetalle.getJoinColumnaHijo());
			where.append(" = (SELECT ").append(maestroDetalle.getJoinColumnaPadre());
			where.append(" FROM ").append(maestroDetalle.getTablaPadre());
			where.append(" WHERE ROWID = ").append(rowIdRegistro);
			where.append(")");
		}
		else if (tabla.getWhere() != null)
			where.append(" WHERE ").append(tabla.getWhere());
		
		// aplica el filtrado (si es que corresponde)
		if (like != null && like.trim().length() > 0)
		{
			if(where.indexOf("WHERE")>=0)
				where.append(" AND (");
			else
				where.append(" WHERE (");
			for (Columna columna : listaColumnas)
			{
				if(columna.isVisible())
				{
					String col = "t." + columna.getNombreColumna();
					if(columna.getJoinTabla() != null)
					{
						where.append("EXISTS (SELECT 1 FROM ");
						where.append(columna.getJoinTabla());
						where.append(" WHERE ");
						if(columna.getJoinTabla().equals(CLAVES))
						{
							where.append(" nomdato = '").append(columna.getJoinCodigo());
							where.append("' AND valdato");
						}
						else
							where.append(columna.getJoinCodigo());
						where.append(" = ").append(col).append(" AND UPPER(");
						where.append(columna.getJoinDescripcion()).append(")");
					}
					else			
						where.append("UPPER(").append(darFormatoIfxOut(col, columna.getTipoDato())).append(") ");
					where.append(" LIKE UPPER('%").append(like).append("%')");
					if(columna.getJoinTabla() != null)
						where.append(")");
					where.append(" OR ");
				}
			}
			where.delete(where.length()-4, where.length());
			where.append(")");
		}
		
		// armado de la clausula order by
		if(mapOrderBy.size() > 0)
		{
			orderBy.append(" ORDER BY ");
			Object[] keys = mapOrderBy.keySet().toArray();
			for(Object key : keys)
				orderBy.append(mapOrderBy.get(key)).append(", ");
			orderBy.delete(orderBy.length()-2, orderBy.length());
		}
		query.append(select);
		query.append(from);
		query.append(where);
		query.append(orderBy);
		return query.toString();
	}
	
	/**	 
	 * Sobre carga del metodo getQueryDatosTabla, enviando parametros por defecto.
	 *
	 * @param tabla
	 * @param like
	 * @return
	 */
	public String getQueryDatosTabla(Tabla tabla, String like)
	{
		return getQueryDatosTabla(tabla, null, null, like);
	}
	
	
	/**
	 * Metodo que se una para crear una expresion util en el armado dinamico de
	 * componentes JSF y RichFaces.
	 * 
	 * @param valueExpression
	 * @param valueType
	 * @return
	 */
	public ValueExpression crearValueExpression(FacesContext facesContext,
			String valueExpression, Class<?> valueType)
	{
		return facesContext.getApplication().getExpressionFactory()
				.createValueExpression(facesContext.getELContext(), valueExpression,
						valueType);
	}

	/**
	 * Metodo que se una para crear una expresion de tipo Action Listener util en
	 * el armado dinamico de componentes JSF y RichFaces.
	 * 
	 * @param actionListenerExpression
	 * @return
	 */
	public MethodExpressionActionListener crearActionListener(
			FacesContext context, String actionListenerExpression)
	{
		return new MethodExpressionActionListener(context
				.getApplication().getExpressionFactory()
				.createMethodExpression(context.getELContext(),
						actionListenerExpression, null, new Class[] { ActionEvent.class }));
	}	
	

	
	/**
	 * Metodo que retorna un componente HtmlOutputText, que contiene 
	 * codigo HTML.
	 *
	 * @param textoHtml
	 * @return
	 */
	public HtmlOutputText html(String textoHtml)
	{
		HtmlOutputText outPutHtml = new HtmlOutputText();
		outPutHtml.setValue(textoHtml);
		outPutHtml.setEscape(false);
		return outPutHtml;
	}
	
	/**
	 * Metodo que retorna el tipo de componente apropiado segun los datos ingresados	 
	 *
	 * @param facesContext
	 * @param operacion
	 * @param columna
	 * @param nroColumna
	 * @return
	 */
	public UIComponent getComponente(FacesContext facesContext,
			String operacion, Columna columna, int nroColumna)
	{
		UIComponent componente = null;
		if (columna.getJoinTabla() != null && columna.getListaValores() != null)
			componente = getComboBox(facesContext, columna, nroColumna);
		else
		{
			boolean readOnly = operacion.equals(SELECT)
					|| (operacion.equals(UPDATE) && !columna.isEditable())
					||(operacion.equals(INSERT) && !columna.isEditable() && columna.getValor() != null);
			if(columna.getTipoDato().startsWith(FECHA))
			{
				HtmlCalendar calendar = new HtmlCalendar();
				if(columna.getTipoDato().equals(FECHA))
					calendar.setDatePattern(FORMATO_FECHA_JAVA);
				else
				{
					calendar.setDatePattern(FORMATO_FECHA_HORA_JAVA);
					if (operacion.equals(INSERT))
						calendar.setValue(new Date());
				}
				calendar.setCellWidth("20px");
				calendar.setCellHeight("20px");
				calendar.setStyle("width:190px");
				calendar.setLocale("es");
				calendar.setShowWeeksBar(false);
				calendar.setDisabled(readOnly);
				componente = calendar;
				calendar = null;
			}
			else
			{
				HtmlInputText inputText = new HtmlInputText();
				inputText = new HtmlInputText();
				inputText.setStyle("width:300px;");
				inputText.setReadonly(readOnly);
				inputText.setMaxlength(Integer.valueOf(columna.getMaxLength()));
				componente = inputText;
				inputText = null;
			}
			componente.setValueExpression("value",crearValueExpression(facesContext, 
					"#{crudParametros.registro[" + nroColumna + "].valor}",
					columna.getTipoDato().startsWith(FECHA)?Date.class:String.class));
		}		
		return componente;
	}
	
	/**
	 * Metodo que retorna un componente de tipo HtmlSelectOneMenu, segun los
	 * datos ingresados.	 
	 *
	 * @param facesContext
	 * @param columna
	 * @param nroColumna
	 * @return
	 */
	public HtmlSelectOneMenu getComboBox(FacesContext facesContext,
			Columna columna, int nroColumna)
	{
		HtmlSelectOneMenu comboBox = new HtmlSelectOneMenu();
		comboBox.getChildren().add(new UISelectItem());
		String valorDefault = null;
		for(UISelectItem item : columna.getListaValores())
		{
			if(columna.getValor()!=null && columna.getValor().equals(item.getItemLabel()))
				valorDefault = (String) item.getItemValue();
			comboBox.getChildren().add(item);
		}
		columna.setValor(valorDefault);
		comboBox.setValueExpression("value",crearValueExpression(facesContext, 
				"#{crudParametros.registro[" + nroColumna + "].valor}",String.class));
		return comboBox;
	}
	
	/**	  
	 * Metodo que retorna la sentencia DML correspondiente
	 *
	 * @param operacion
	 * @param tabla
	 * @param columnas
	 * @param logs
	 * @return
	 */
	public String getSentenciaDml(String operacion, String tabla,
			List<Columna> columnas, Map<String, String> logs)
	{
		String sentenciaDml = null;
		if(operacion.equals(INSERT))
			sentenciaDml = getSentenciaInsert(tabla, columnas, logs);
		else if(operacion.equals(UPDATE))
			sentenciaDml = getSentenciaUpdate(tabla, columnas, logs);
		else if(operacion.equals(DELETE))
			sentenciaDml = getSentenciaDelete(tabla, columnas);
		return sentenciaDml;
	}
	
	
	/**
	 * Metodo que arma la sentencia INSERT, segun los datos ingresados.
	 *
	 * @param tabla
	 * @param columnas
	 * @param logs
	 * @return
	 */
	public String getSentenciaInsert(String tabla, List<Columna> columnas,
			Map<String, String> logs)
	{
		StringBuilder insert = new StringBuilder("INSERT INTO ");
		StringBuilder into = new StringBuilder(tabla).append("(");	
    StringBuilder values = new StringBuilder("VALUES(");
		for (int i = 1; i < columnas.size(); i++)
		{
			Columna columna = columnas.get(i);
			into.append(columna.getNombreColumna()).append(", ");
			if(columna.isLog())
				values.append(logs.get(columna.getNombreColumna()));
			else
				values.append(darFormatoIfxIn(columna.getValor(), columna.getTipoDato()));
			values.append(", ");
		}
		into.delete(into.length()-2, into.length());
		into.append(") ");
		values.delete(values.length()-2, values.length());
		values.append(") ");
		insert.append(into).append(values);
		return insert.toString();
	}
	
	
	/**
	 * Metodo que arma la sentencia UPDATE, segun los datos ingresados.
	 *
	 * @param tabla
	 * @param columnas
	 * @param logs
	 * @return
	 */
	public String getSentenciaUpdate(String tabla, List<Columna> columnas,
			Map<String, String> logs)
	{
		StringBuilder sentencia = new StringBuilder();		
		if(registroTieneCambios(columnas))
		{
			StringBuilder set = new StringBuilder(" SET ");
			sentencia.append("UPDATE ").append(tabla);
			for (int i = 1; i < columnas.size(); i++)
			{
				Columna columna = columnas.get(i);
				if (((columna.isVisible() && columna.isEditable())) || columna.isLog())
				{
					set.append(columna.getNombreColumna()).append(" = ");
					if (columna.isLog())
						set.append(logs.get(columna.getNombreColumna()));
					else
						set.append(darFormatoIfxIn(columna.getValor(), columna.getTipoDato()));
					set.append(", ");
				}
			}
			String where = " WHERE ROWID = " + columnas.get(0).getValor();
			set.delete(set.length()-2, set.length()-1);
			sentencia.append(set).append(where);
		}
		return sentencia.toString();
	}
	
	
	/**
	 * Metodo que arma la sentencia DELETE, segun los datos ingresados.
	 *
	 * @param tabla
	 * @param columnas
	 * @return
	 */
	public String getSentenciaDelete(String tabla, List<Columna> columnas)
	{
		StringBuilder sentencia = new StringBuilder("DELETE ");
		sentencia.append(tabla).append(" WHERE ROWID = ");
		sentencia.append(columnas.get(0).getValor());
		return sentencia.toString();
	}
		
	/**	 
	 * Metodo que arma la columna formateada para desplegar en pantalla. 
	 *
	 * @param columna
	 * @param tipoDato
	 * @return columna formateada para un query
	 */
	public StringBuilder darFormatoIfxOut(String columna, String tipoDato)
	{
		StringBuilder cadena = new StringBuilder(columna);
		if (!tipoDato.equals(CADENA))
		{
			cadena.insert(0, "TO_CHAR(");
			if(tipoDato.startsWith(FECHA))
			{
				cadena.append(",");
				if (tipoDato.equals(FECHA))
					cadena.append(FORMATO_FECHA_IFX);
				else if (tipoDato.equals(FECHA_HORA))
					cadena.append(FORMATO_FECHA_HORA_IFX);
			}
			cadena.append(")");
		}
		cadena.append(" ");
		return cadena;
	}
	
	
	/**
	 * Metodo que formateada un dato para registrar en base de batos.
	 *
	 * @param valor
	 * @param tipoDato
	 * @return
	 */
	public String darFormatoIfxIn(Object valor, String tipoDato)
	{
		StringBuilder cadena = new StringBuilder();
		if(tipoDato.startsWith(FECHA)) {
			cadena.append("TO_DATE('");
			Date fecha = (Date) valor;
			SimpleDateFormat sdf = new SimpleDateFormat();
			if(tipoDato.equals(FECHA))
				sdf.applyPattern(FORMATO_FECHA_JAVA);			
			else if(tipoDato.equals(FECHA_HORA))
				sdf.applyPattern(FORMATO_FECHA_HORA_JAVA);
			cadena.append(sdf.format(fecha)).append("',");
			if(tipoDato.equals(FECHA))
				cadena.append(FORMATO_FECHA_IFX);			
			else if(tipoDato.equals(FECHA_HORA))
				cadena.append(FORMATO_FECHA_HORA_IFX);
			cadena.append(")");
		}
		else
		{
			cadena.append("'").append(valor).append("'");
		}
		return cadena.toString();
	}
	
	
	/**
	 * Metodo que verifica si un registro tiene cambios.
	 *
	 * @param columnas
	 * @return
	 */
	public boolean registroTieneCambios(List<Columna> columnas)
	{
		boolean tieneCambios = false;
		for (int i = 1; i < columnas.size(); i++)
		{
			Columna columna = columnas.get(i);
			if(columna.tieneCambio())
			{
				tieneCambios = true;
				break;
			}
		}
		return tieneCambios;
	}
	
	
	/**
	 * metodo que retorna un componente de tipo HtmlDatascroller
	 * para la paginacion de grillas
	 *
	 * @param para
	 * @return
	 */
	public HtmlDatascroller getPaginador(String para)
	{
		HtmlDatascroller paginador = new HtmlDatascroller();
		paginador.setRenderIfSinglePage(false);
		paginador.setMaxPages(10);
		paginador.setStyle("width:400px;");
		paginador.setFor(para);
		return paginador;
	}
	
	/**
	 * Metodo que retorna un componente de tipo HtmlInplaceInput.
	 *
	 * @param facesContext
	 * @param value
	 * @return
	 */
	public HtmlInplaceInput getInplaceInput(FacesContext facesContext, String value)
	{
		HtmlInplaceInput input = new HtmlInplaceInput();
		input.setDefaultLabel(" Haga click aqui para buscar ");
		input.setValueExpression("value",crearValueExpression(facesContext, value, String.class));
		return input;
	}
	
	
	public String getAlineacionColumna(String tipoDato)
	{
		String alineacion = null;
		if (tipoDato.equals(ENTERO) || tipoDato.equals(REAL))
			alineacion = "derecha";
		else if (tipoDato.equals(FECHA) || tipoDato.equals(FECHA_HORA))
			alineacion = "centrado";
		else
			alineacion = "izquierda";
		return alineacion;
	}
	
	public Converter getFormatoConverter(String tipoDato)
	{
		Converter converter = null;
		if (tipoDato.equals(REAL))
		{
			NumberConverter nc = new NumberConverter();
			nc.setPattern("#,###,##0.00");
			converter = nc;
		}
		return converter;
	}
	
}
