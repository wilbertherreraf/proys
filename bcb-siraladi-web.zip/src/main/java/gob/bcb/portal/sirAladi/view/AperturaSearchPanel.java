package gob.bcb.portal.sirAladi.view;

import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarMapDescripcionClaves;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarSelectDescripcionClaves;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarSelectItemsPaises;
import static gob.bcb.portal.sirAladi.commons.Constantes.CODIGO_PERSONA_BCB;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_ESTADO_APERTURA;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_ESTADO_PAGO;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_ESTADO_REGISTRO;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_TIPO_APERTURA;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_TIPO_EMISION;
import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.Identificador;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Pais;
import gob.bcb.portal.sirAladi.comunes.controller.FacesContextUtil;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;

public class AperturaSearchPanel extends BaseBeanController {
	private static Logger log = Logger.getLogger(AperturaSearchPanel.class);

	private Date fechaDesde;
	private Date fechaHasta;
	private String estadoRegPago;
	private String tipoDeRegistro = null;
	private Map<String, String> mapClavesTipoEmision;
	private Map<String, String> mapClavesTipoApertura;
	private Map<String, String> mapClavesEstadoApertura;
	private Map<String, String> mapClavesEstadoRegistro;
	private Map<String, String> mapClavesEstadoPago;

	private List<SelectItem> itemsPaisesExterior;
	private List<SelectItem> itemsTipoOperacion;
	private List<SelectItem> itemsEstadoApertura;
	private List<SelectItem> itemsEstadoRegistro;
	private List<SelectItem> itemsEstadoPago;

	private Apertura apertura;
	private Apertura currApertura;
	private List<Apertura> aperturaList;
	private Pais paisConvenio;

	public AperturaSearchPanel() {
	}

	@PostConstruct
	public void init() {
		log.info("Iniciando el modulo de Consulta de Instrumentos.");
		recuperarVisit();
		crearObjetosPorDefecto();
		cargarCombos();

		if (getVisit().getParametro("SIRWEB_TMP_APERTURAS") != null) {
			if (!(getVisit().getParametro("SIRWEB_TMP_APERTURAS") instanceof AperturaSearchPanel)) {
				// getVisit().removeParametro("SIRWEB_TMP_APERTURAS");
			} else {
				AperturaSearchPanel objetoTMP = (AperturaSearchPanel) getVisit().getParametro("SIRWEB_TMP_APERTURAS");
				aperturaList = objetoTMP.getAperturaList();
				// en apertura eta los parametros de la consulta
				apertura = objetoTMP.getApertura();
				paisConvenio = objetoTMP.getPaisConvenio();
				estadoRegPago = objetoTMP.getEstadoRegPago();
				tipoDeRegistro = objetoTMP.getTipoDeRegistro();
			}
		}
		String action = FacesContextUtil.getRequestParameter(getFacesContext(), "SIRWEB_TMP_ACTION");
		if (action != null) {
			if (action.equals("CLEAR_CURRENTAPERTURA")) {
				limpiar(null);
				String tipoOperacion = FacesContextUtil.getRequestParameter(getFacesContext(), "tipoOperacion");
				String codrecprotegido = FacesContextUtil.getRequestParameter(getFacesContext(), "codrecprotegido");
				log.info("codrecprotegido search init " + codrecprotegido);
				if (tipoOperacion != null) {
					apertura.setCveTipoApe(tipoOperacion);
				} else {
					if (getVisit().getParametro("tipoOperacion") != null)
						apertura.setCveTipoApe((String) getVisit().getParametro("tipoOperacion"));
				}
				if (codrecprotegido != null) {
					if (codrecprotegido.equals("ALA0103") || codrecprotegido.equals("ALA0203")) {
						// la llamada proviene de debito o Reembolsos
						tipoDeRegistro = "P";
						estadoRegPago = "P";
						apertura.setCveEstadoApe(null);
						buscarApertura(null);
						if (apertura.getCveTipoApe() != null && apertura.getCveTipoApe().trim().equals("E")
								&& getVisit().getUsuarioSirAladi().getPersona().getCodPersona().trim().equals(CODIGO_PERSONA_BCB)) {
							// en los reembolsos de exportacion si el usuario es
							// del BCB filtrar los de estado pre-autorizado
							// se considera todos los estados  V y L ya que pueden existir tanto debitos y reembolsos que registren CG en estado liquidado
							estadoRegPago = "1";
							if (aperturaList != null) {
								List<Apertura> aperturasTmp = getSirAladiDao().getAperturas(apertura.getCveTipoApe(), apertura.getCveEstadoApe(),
										tipoDeRegistro, estadoRegPago, getVisit().getUsuarioSirAladi().getPersona(), fechaDesde, fechaHasta,
										this.paisConvenio.getCodPais());

								if (aperturasTmp != null && aperturasTmp.size() > 0) {
									aperturaList.addAll(aperturasTmp);
								}
							} else {
								aperturaList = getSirAladiDao().getAperturas(apertura.getCveTipoApe(), apertura.getCveEstadoApe(), tipoDeRegistro,
										estadoRegPago, getVisit().getUsuarioSirAladi().getPersona(), fechaDesde, fechaHasta,
										this.paisConvenio.getCodPais());
							}
						}
						estadoRegPago = "P";						
					}
					
					if (codrecprotegido.equals("ALA0104") || codrecprotegido.equals("ALA0204")) {
						// la llamada proviene de Enmiendas
						tipoDeRegistro = "R";
						estadoRegPago = "P";
						buscarApertura(null);
					}
				}
			} else if (action.equals("NAVIGATOR")) {
				getVisit().setCurrentApertura(null);
			}
		}
	}

	public void buscarApertura(ActionEvent event) {

		getVisit().setCurrentApertura(null);
		if (this.apertura != null
				&& ((apertura.getInstitucion() != null && apertura.getInstitucion().getCodInst() != null && !apertura.getInstitucion().getCodInst()
						.trim().isEmpty())
						|| (apertura.getIdentificador() != null && apertura.getIdentificador().getCodId() != null && !apertura.getIdentificador()
								.getCodId().trim().isEmpty()) || (apertura.getAnio() != null && !apertura.getAnio().trim().isEmpty()) || (apertura
						.getSecuencia() != null && !apertura.getSecuencia().trim().isEmpty()))) {
			// busqueda por valores de nro reembolsos
			this.aperturaList = getSirAladiDao().getAperturas(this.apertura, getVisit().getUsuarioSirAladi());
		} else {
			if (fechaDesde != null && fechaHasta != null) {
				fechaDesde = null;
				fechaHasta = null;
			}

			this.aperturaList = getSirAladiDao().getAperturas(apertura.getCveTipoApe(), apertura.getCveEstadoApe(), tipoDeRegistro,
						estadoRegPago, getVisit().getUsuarioSirAladi().getPersona(), fechaDesde, fechaHasta, this.paisConvenio.getCodPais());
		}
		getVisit().setParametro("SIRWEB_TMP_APERTURAS", this);
	}

	public String seleccionaApertura() {
		getVisit().setCurrentApertura(currApertura);
		aperturaList = null;
		getVisit().removeParametro("SIRWEB_TMP_APERTURAS");
		return null;
	}

	public void limpiar(ActionEvent event) {
		log.info("Evento limpiar ejecutado");
		currApertura = null;
		this.crearObjetosPorDefecto();
		getVisit().removeParametro("SIRWEB_TMP_APERTURAS");
		getVisit().setCurrentApertura(null);
	}

	private void crearObjetosPorDefecto() {
		Calendar cal = GregorianCalendar.getInstance();
		this.fechaDesde = getSirAladiDao().getFechaActual();
		aperturaList = null;
		cal.setTime(fechaDesde);
		cal.add(Calendar.YEAR, -1);
		this.fechaDesde = cal.getTime();
		this.fechaHasta = getSirAladiDao().getFechaActual();
		this.fechaDesde = null;
		this.fechaHasta = null;

		tipoDeRegistro = "P";

		this.apertura = new Apertura();
		this.apertura.setIdentificador(new Identificador());
		this.apertura.setInstitucion(new Institucion());
		this.apertura.setPais(new Pais());
		this.apertura.setCveEstadoApe("V");
		if (getVisit().getParametro("tipoOperacion") != null)
			apertura.setCveTipoApe((String) getVisit().getParametro("tipoOperacion"));
		
		this.paisConvenio = new Pais();

	}

	private void cargarCombos() {
		this.itemsPaisesExterior = armarSelectItemsPaises(getSirAladiDao().getPaisesExterior());
		this.itemsTipoOperacion = armarSelectDescripcionClaves(getSirAladiDao().getClaves(CVE_TIPO_APERTURA));
		this.itemsEstadoApertura = armarSelectDescripcionClaves(getSirAladiDao().getClaves(CVE_ESTADO_APERTURA));
		this.itemsEstadoRegistro = armarSelectDescripcionClaves(getSirAladiDao().getClaves(CVE_ESTADO_REGISTRO));
		this.itemsEstadoPago = armarSelectDescripcionClaves(getSirAladiDao().getClaves(CVE_ESTADO_PAGO));
		
		// mapas de descripciones de codigos y estados
		this.mapClavesTipoEmision = armarMapDescripcionClaves(getSirAladiDao().getClaves(CVE_TIPO_EMISION));
		this.mapClavesTipoApertura = armarMapDescripcionClaves(getSirAladiDao().getClaves(CVE_TIPO_APERTURA));
		this.mapClavesEstadoApertura = armarMapDescripcionClaves(getSirAladiDao().getClaves(CVE_ESTADO_APERTURA));
		this.mapClavesEstadoRegistro = armarMapDescripcionClaves(getSirAladiDao().getClaves(CVE_ESTADO_REGISTRO));
		this.mapClavesEstadoPago = armarMapDescripcionClaves(getSirAladiDao().getClaves(CVE_ESTADO_PAGO));		
	}

	public void setMapClavesTipoEmision(Map<String, String> mapClavesTipoEmision) {
		this.mapClavesTipoEmision = mapClavesTipoEmision;
	}

	public Map<String, String> getMapClavesTipoEmision() {
		return mapClavesTipoEmision;
	}

	public void setMapClavesTipoApertura(Map<String, String> mapClavesTipoApertura) {
		this.mapClavesTipoApertura = mapClavesTipoApertura;
	}

	public Map<String, String> getMapClavesTipoApertura() {
		return mapClavesTipoApertura;
	}

	public void setMapClavesEstadoApertura(Map<String, String> mapClavesEstadoApertura) {
		this.mapClavesEstadoApertura = mapClavesEstadoApertura;
	}

	public Map<String, String> getMapClavesEstadoApertura() {
		return mapClavesEstadoApertura;
	}

	public void setItemsPaisesExterior(List<SelectItem> itemsPaisesExterior) {
		this.itemsPaisesExterior = itemsPaisesExterior;
	}

	public List<SelectItem> getItemsPaisesExterior() {
		return itemsPaisesExterior;
	}

	public void setItemsTipoOperacion(List<SelectItem> itemsTipoOperacion) {
		this.itemsTipoOperacion = itemsTipoOperacion;
	}

	public List<SelectItem> getItemsTipoOperacion() {
		return itemsTipoOperacion;
	}

	public void setItemsEstadoApertura(List<SelectItem> itemsEstadoApertura) {
		this.itemsEstadoApertura = itemsEstadoApertura;
	}

	public List<SelectItem> getItemsEstadoApertura() {
		return itemsEstadoApertura;
	}

	public void setFechaHasta(Date fechaHasta) {
		this.fechaHasta = fechaHasta;
	}

	public Date getFechaHasta() {
		return fechaHasta;
	}

	public void setApertura(Apertura apertura) {
		this.apertura = apertura;
	}

	public Apertura getApertura() {
		return apertura;
	}

	public void setAperturaList(List<Apertura> aperturaList) {
		this.aperturaList = aperturaList;
	}

	public List<Apertura> getAperturaList() {
		return aperturaList;
	}

	public void setPaisConvenio(Pais paisConvenio) {
		this.paisConvenio = paisConvenio;
	}

	public Pais getPaisConvenio() {
		return paisConvenio;
	}

	public void setCurrApertura(Apertura currApertura) {
		this.currApertura = currApertura;
	}

	public Apertura getCurrApertura() {
		return currApertura;
	}

	public void setFechaDesde(Date fechaDesde) {
		this.fechaDesde = fechaDesde;
	}

	public Date getFechaDesde() {
		return fechaDesde;
	}

	public void setEstadoRegPago(String estadoRegPago) {
		this.estadoRegPago = estadoRegPago;
	}

	public String getEstadoRegPago() {
		return estadoRegPago;
	}

	public void setMapClavesEstadoRegistro(Map<String, String> mapClavesEstadoRegistro) {
		this.mapClavesEstadoRegistro = mapClavesEstadoRegistro;
	}

	public Map<String, String> getMapClavesEstadoRegistro() {
		return mapClavesEstadoRegistro;
	}

	public void setItemsEstadoRegistro(List<SelectItem> itemsEstadoRegistro) {
		this.itemsEstadoRegistro = itemsEstadoRegistro;
	}

	public List<SelectItem> getItemsEstadoRegistro() {
		return itemsEstadoRegistro;
	}

	public void setMapClavesEstadoPago(Map<String, String> mapClavesEstadoPago) {
		this.mapClavesEstadoPago = mapClavesEstadoPago;
	}

	public Map<String, String> getMapClavesEstadoPago() {
		return mapClavesEstadoPago;
	}

	public void setItemsEstadoPago(List<SelectItem> itemsEstadoPago) {
		this.itemsEstadoPago = itemsEstadoPago;
	}

	public List<SelectItem> getItemsEstadoPago() {
		return itemsEstadoPago;
	}

	public void setTipoDeRegistro(String tipoDeRegistro) {
		this.tipoDeRegistro = tipoDeRegistro;
	}

	public String getTipoDeRegistro() {
		return tipoDeRegistro;
	}
}
