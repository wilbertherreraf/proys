/**
 * La Paz - Bolivia
 * bcb-portal-sirAladi
 * gob.bcb.portal.sirAladi.comunes.controller.PagosCobrosController
 * 26/07/2011 - 14:49:03
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.comunes.controller;

import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarMapDescripcionClaves;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarMapInstrumentos;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.getAlertConCierreModalJS;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.getAlertJS;
import static gob.bcb.portal.sirAladi.commons.Constantes.CODIGO_PERSONA_BCB;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_ESTADO_APERTURA;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_ESTADO_PAGO;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_ESTADO_PLAN_PAGO;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_ESTADO_REGISTRO;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTADO_CONTABILIZADO;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTADO_PENDIENTE;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTADO_SUSPENDIDO;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTILO_INVISIBLE;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTILO_VISIBLE;
import static gob.bcb.portal.sirAladi.commons.Constantes.SUCCESS;
import static gob.bcb.portal.sirAladi.commons.Constantes.TIPO_APERTURA_EXPORTACION;
import static gob.bcb.portal.sirAladi.commons.Constantes.TIPO_APERTURA_IMPORTACION;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.Identificador;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Instrumento;
import gob.bcb.bpm.siraladi.jpa.Pago;
import gob.bcb.bpm.siraladi.jpa.Pais;
import gob.bcb.bpm.siraladi.jpa.Persona;
import gob.bcb.bpm.siraladi.jpa.PlanPago;
import gob.bcb.bpm.siraladi.jpa.PlanPagoPK;
import gob.bcb.bpm.siraladi.jpa.Registro;
import gob.bcb.bpm.siraladi.pojo.StatusResponse;
import gob.bcb.portal.sirAladi.commons.Servicios;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;
import gob.bcb.portal.sirAladi.controller.MainAladiController;

/**
 * Backing Bean para la vista de Pago.
 * 
 * @author wherrera
 * 
 */
public class PagosCobrosController extends BaseBeanController {
	private static Logger log = Logger.getLogger(PagosCobrosController.class);

	private String msj;
	private String estadoPagos;
	private String tipoApertura;
	private String descPagos;
	private String descEnlace;
	private String filtro;
	private String concepto;
	private BigDecimal totalEmisionInstrumento;
	private BigDecimal totalSaldoInstrumento;
	private BigDecimal totalDebito;
	private boolean esAnulacion;
	private Apertura apertura = new Apertura();
	private Registro registro;
	private Pago debito;
	private PlanPago planPago;
	private PlanPago totalPlanPago;
	private Pais paisConvenio;
	
	private List<Apertura> aperturas;
	private List<Apertura> aperturasInicial;
	private List<PlanPago> planPagos;
	private List<Pago> debitos;
	private List<SelectItem> itemsConcepto;
	private Map<String, Instrumento> mapInstrumentos;
	private Map<String, String> mapClavesEstadoPlan;
	private Map<String, String> mapClavesEstadoPago;
	private Map<String, String> mapClavesEstadoRegistro;
	private Map<String, String> mapClavesEstadoApertura;
	private static final String CAPITAL = "CA";
	private static final String INTERES = "IN";
	private static final String COMISIONES_Y_GASTOS = "CG";
	private static final String EXTORNO = "EXT";
	private static final String REVERSO_LEX = "ALE";

	public PagosCobrosController() {
	}

	@PostConstruct
	public void init() {
		log.info("Iniciando el modulo de pagos/cobros.");
		recuperarVisit();
		apertura.setPersona(new Persona());
		this.tipoApertura = MainAladiController.getTipoOperacionPaginaActual();
		this.tipoApertura = (this.tipoApertura == null) ? TIPO_APERTURA_IMPORTACION : this.tipoApertura;
		this.descPagos = (TIPO_APERTURA_IMPORTACION.equals(this.tipoApertura)) ? "Débitos" : "Cobros";
		this.descEnlace = (TIPO_APERTURA_IMPORTACION.equals(this.tipoApertura)) ? "Ver Autorizados" : "Ver Emisiones";
		this.crearObjetosPorDefecto();
		Integer nroMov = MainAladiController.getParametroNroMov();
		if (nroMov != null && nroMov > 0) {
			this.apertura = getSirAladiDao().getApertura(nroMov);
			this.cargarDatos(nroMov);
		} else
			this.recuperarAperturasConPagosPendientes();

	}

	public String getMsj() {
		return msj;
	}

	public void setMsj(String msj) {
		this.msj = msj;
	}

	public String getFiltro() {
		return filtro;
	}

	public void setFiltro(String filtro) {
		this.filtro = filtro;
	}

	public String getConcepto() {
		return concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public boolean isEsAnulacion() {
		return esAnulacion;
	}

	public void setEsAnulacion(boolean esAnulacion) {
		this.esAnulacion = esAnulacion;
	}

	public String getEstadoPagos() {
		return estadoPagos;
	}

	public void setEstadoPagos(String estadoPagos) {
		this.estadoPagos = estadoPagos;
	}

	public BigDecimal getTotalEmisionInstrumento() {
		return totalEmisionInstrumento;
	}

	public void setTotalEmisionInstrumento(BigDecimal totalEmisionInstrumento) {
		this.totalEmisionInstrumento = totalEmisionInstrumento;
	}

	public BigDecimal getTotalSaldoInstrumento() {
		return totalSaldoInstrumento;
	}

	public void setTotalSaldoInstrumento(BigDecimal totalSaldoInstrumento) {
		this.totalSaldoInstrumento = totalSaldoInstrumento;
	}

	public BigDecimal getTotalDebito() {
		return totalDebito;
	}

	public void setTotalDebito(BigDecimal totalDebito) {
		this.totalDebito = totalDebito;
	}

	public List<Apertura> getAperturas() {
		return aperturas;
	}

	public void setAperturas(List<Apertura> aperturas) {
		this.aperturas = aperturas;
	}

	public Apertura getApertura() {
		return apertura;
	}

	public void setApertura(Apertura apertura) {
		this.apertura = apertura;
	}

	public Registro getRegistro() {
		return registro;
	}

	public void setRegistro(Registro registro) {
		this.registro = registro;
	}

	public List<PlanPago> getPlanPagos() {
		return planPagos;
	}

	public void setPlanPagos(List<PlanPago> planPagos) {
		this.planPagos = planPagos;
	}

	public PlanPago getPlanPago() {
		return planPago;
	}

	public void setPlanPago(PlanPago planPago) {
		this.planPago = planPago;
	}

	public PlanPago getTotalPlanPago() {
		return totalPlanPago;
	}

	public void setTotalPlanPago(PlanPago totalPlanPago) {
		this.totalPlanPago = totalPlanPago;
	}

	public List<Pago> getDebitos() {
		return debitos;
	}

	public void setDebitos(List<Pago> debitos) {
		this.debitos = debitos;
	}

	public Pago getDebito() {
		return debito;
	}

	public void setDebito(Pago debito) {
		this.debito = debito;
	}

	public List<SelectItem> getItemsConcepto() {
		return itemsConcepto;
	}

	public void setItemsConcepto(List<SelectItem> itemsConcepto) {
		this.itemsConcepto = itemsConcepto;
	}

	public Map<String, String> getMapClavesEstadoPlan() {
		return mapClavesEstadoPlan;
	}

	public void setMapClavesEstadoPlan(Map<String, String> mapClavesEstadoPlan) {
		this.mapClavesEstadoPlan = mapClavesEstadoPlan;
	}

	public Map<String, String> getMapClavesEstadoPago() {
		return mapClavesEstadoPago;
	}

	public void setMapClavesEstadoPago(Map<String, String> mapClavesEstadoPago) {
		this.mapClavesEstadoPago = mapClavesEstadoPago;
	}

	public Map<String, String> getMapClavesEstadoRegistro() {
		return mapClavesEstadoRegistro;
	}

	public void setMapClavesEstadoRegistro(Map<String, String> mapClavesEstadoRegistro) {
		this.mapClavesEstadoRegistro = mapClavesEstadoRegistro;
	}

	public TimeZone getTimeZone() {
		return TimeZone.getDefault();
	}

	public String getEstiloVerDebito() {
		return (this.apertura.getNroMov() != null && this.apertura.getNroMov() > 0) ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	public String getEstiloVerListaPendientes() {
		return (this.apertura.getNroMov() != null && this.apertura.getNroMov() > 0) ? ESTILO_INVISIBLE : ESTILO_VISIBLE;
	}

	public String getEstiloListaPendientes() {
		return (this.aperturasInicial != null && this.aperturasInicial.size() > 0) ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	public String getEstiloMsjSinPendientes() {
		return (this.aperturasInicial == null || this.aperturasInicial.size() == 0) ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	public String getEstiloVerLinkPendientes() {
		return (this.tipoApertura.equals(TIPO_APERTURA_IMPORTACION)) ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	public boolean isEsImportacion() {
		return this.tipoApertura.equals(TIPO_APERTURA_IMPORTACION);
	}

	public boolean isEditable() {
		boolean editable = true;
		if (isEsImportacion())
			editable = getVisit().getUsuarioSirAladi().getPersona().getCodPersona().trim().equals(CODIGO_PERSONA_BCB);
		return editable;
	}

	public String getDescPagos() {
		return descPagos;
	}

	public void setDescPagos(String descPagos) {
		this.descPagos = descPagos;
	}

	public String getDescEnlace() {
		return descEnlace;
	}

	public void setDescEnlace(String descEnlace) {
		this.descEnlace = descEnlace;
	}

	public boolean isPuedeNegociar() {
		return (this.apertura != null && this.apertura.getIdentificador() != null && this.apertura.getIdentificador().getCodId() != null && "1"
				.equals(this.apertura.getIdentificador().getCodId().trim()));
	}

	public String getEstiloHayCambios() {
		boolean hayCuotasPendientes = false;
		if (this.planPagos != null && this.planPagos.size() > 0) {
			for (PlanPago cuota : this.planPagos) {
				if (cuota.getCveEstadoPlan().equals(ESTADO_PENDIENTE)) {
					hayCuotasPendientes = true;
					break;
				}
			}
		}
		return hayCuotasPendientes ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	public void buscarPagosP(ActionEvent event) {
		estadoPagos = "P";		
		buscarPagos();
	}

	public void buscarPagosC(ActionEvent event) {
		this.estadoPagos = ESTADO_CONTABILIZADO;
		this.buscarPagos();
	}

	private void buscarPagos() {
		this.apertura = new Apertura();
		this.planPagos = new ArrayList<PlanPago>();
		this.debitos = new ArrayList<Pago>();
		this.recuperarAperturasConPagosPendientes();
	}

	private void recuperarAperturasConPagosPendientes() {
		this.msj = "";
		try {
			if (tipoApertura.equals("I")) {
				this.aperturasInicial = getSirAladiDao().getAperturas(this.tipoApertura, null, "P", this.estadoPagos,
						getVisit().getUsuarioSirAladi().getPersona(), null, null, null);
			}
			if (tipoApertura.equals("E")) {
				this.aperturasInicial = getSirAladiDao().getAperturas(this.tipoApertura, null, "P", this.estadoPagos,
						getVisit().getUsuarioSirAladi().getPersona(), null, null, null);
				if (this.estadoPagos.equals("P") && getVisit().getUsuarioSirAladi().getPersona().getCodPersona().trim().equals(CODIGO_PERSONA_BCB)) {
					// si es ver pendientes y el usuario es el bcb se verifica
					// si hay pre autorizados
					if (aperturasInicial != null) {
						List<Apertura> aperturasTmp = getSirAladiDao().getAperturas(this.tipoApertura, null, "P", "1",
								getVisit().getUsuarioSirAladi().getPersona(), null, null, null);
						if (aperturasTmp != null && aperturasTmp.size()> 0){
							this.aperturasInicial.addAll(aperturasTmp);							
						}
					} else {
						aperturasInicial = getSirAladiDao().getAperturas(this.tipoApertura, null, "P", "1",
								getVisit().getUsuarioSirAladi().getPersona(), null, null, null);
					}
				}
			}
			// ojooo this.aperturasInicial =
			// getSirAladiDao().getAperturasConPagosPendientesImportacion(this.usuario.getPersona(),
			// this.estadoPagos);
			this.aperturas = this.aperturasInicial;
			if ((this.aperturas == null || this.aperturas.size() == 0) && this.estadoPagos.equals(ESTADO_CONTABILIZADO))
				this.msj = getAlertJS("No se encontraron aperturas vigentes con pagos autorizados.");
		} catch (Exception e) {
			String mensaje = "Ocurrio un error al tratar de obtener los pagos.";
			this.msj = getAlertJS(mensaje);
			log.error(mensaje, e);
			e.printStackTrace();
		}
	}

	public void seleccionarApertura(Apertura aperturaSel) {
		this.msj = "";
		
		this.apertura = aperturaSel;
		this.cargarDatos(this.apertura.getNroMov());
	}

	private void cargarDatos(Integer nroMovApertura) {
		this.recuperarPagos();
		this.registro = getSirAladiDao().getRegistroEmision(nroMovApertura);
		paisConvenio =  getSirAladiDao().getPaisConvenio(apertura);
		this.obtenerSaldos();
		this.recuperarPlanPagos();
		this.obtenerDatosParametricos();
	}

	private void recuperarPlanPagos() {
		this.planPagos = getSirAladiDao().getPlanPagos(this.apertura.getNroMov());
		this.calcularTotalPlanPago();
	}

	private void obtenerSaldos() {
		BigDecimal totalPagado = getSirAladiDao().getMontoPagadoInstrumento(this.apertura.getNroMov());
		this.totalEmisionInstrumento = getSirAladiDao().getMontoInstrumento(this.apertura.getNroMov());
		this.totalSaldoInstrumento = this.totalEmisionInstrumento.subtract(totalPagado);
	}

	public void nuevoCuota() {
		log.info("nuevo plan pagos NroMov: " + apertura.getNroMov());		
		PlanPagoPK pk = new PlanPagoPK();
		pk.setNroMov(this.apertura.getNroMov());
		this.planPago = new PlanPago();
		this.planPago.setId(pk);
		this.planPago.setCveEstadoPlan(ESTADO_PENDIENTE);
		getVisit().setParametro("SIRWEB_TMP_OBJECT", this);
	}
	
	public void editarCuota(PlanPago planPagoSel) {
		log.info("editando plan pagos " + planPagoSel.getId().getNroMov() + " " + planPagoSel.getId().getNroPlan());		
		this.planPago = planPagoSel;
		log.info(planPago.getCveEstadoPlan());
		getVisit().setParametro("SIRWEB_TMP_OBJECT", this);
	}

	public void eliminarPlanCuotas(PlanPago planPagoSel) {
		log.info("eliminando plan pagos " + planPagoSel.getId().getNroMov() + " " + planPagoSel.getId().getNroPlan());
		this.msj = null;
		// que sucede al guardar

		this.planPago = planPagoSel;
		this.planPago.setCveEstadoPlan(ESTADO_SUSPENDIDO);

		StatusResponse statusResponse = Servicios.guardarPlanPago(this.apertura, this.planPago);
		if (statusResponse.getStatusCode().equals(SUCCESS)) {
			this.recuperarPlanPagos();
			String msg = statusResponse.getDescrip();
			log.debug(msg);
			// FacesContextUtil.addInfoMessage(msg);
			this.msj = getAlertConCierreModalJS("panelCuota", statusResponse);
		} else {
			String msg = "Error al actualizar " + statusResponse.getDescrip();
			log.error(msg);
			// FacesContextUtil.addErrorMessage(msg + ": Error Servicio.");
			this.msj = getAlertJS(statusResponse);
		}

	}
	
	public void cancelarPlanCuotas(PlanPago planPagoSel) {
		log.info("cancelando plan pagos " + planPagoSel.getId().getNroMov() + " " + planPagoSel.getId().getNroPlan());
		this.msj = null;
		// que sucede al guardar

		this.planPago = planPagoSel;
		this.planPago.setCveEstadoPlan("C");
		StatusResponse statusResponse = Servicios.guardarPlanPago(this.apertura, this.planPago);
		if (statusResponse.getStatusCode().equals(SUCCESS)) {
			this.recuperarPlanPagos();
			String msg = statusResponse.getDescrip();
			log.debug(msg);
			// FacesContextUtil.addInfoMessage(msg);
			this.msj = getAlertConCierreModalJS("panelCuota", statusResponse);
		} else {
			String msg = "Error al actualizar " + statusResponse.getDescrip();
			log.error(msg);
			// FacesContextUtil.addErrorMessage(msg + ": Error Servicio.");
			this.msj = getAlertJS(statusResponse);
		}

	}
	
	public void modificarPlanCuotas() {
		log.info("Actualizando plan pagos " + planPago.toString());
		this.msj = null;
		// que sucede al guardar

		this.calcularMontoCuota();
		StatusResponse statusResponse = Servicios.guardarPlanPago(this.apertura, this.planPago);
		if (statusResponse.getStatusCode().equals(SUCCESS)) {
			this.recuperarPlanPagos();
			String msg = statusResponse.getDescrip();
			log.debug(msg);
			// FacesContextUtil.addInfoMessage(msg);
			this.msj = getAlertConCierreModalJS("panelCuota", statusResponse);
		} else {
			String msg = "Error al actualizar " + statusResponse.getDescrip();
			log.error(msg);
			// FacesContextUtil.addErrorMessage(msg + ": Error Servicio.");
			this.msj = getAlertJS(statusResponse);
		}

	}
	
	public void guardarPlanCuotas(ActionEvent event) {
		StatusResponse statusResponse = Servicios.enviarPlanPagosAladi(this.apertura, this.planPagos);
		if (SUCCESS.equals(statusResponse.getStatusCode()))
			this.recuperarPlanPagos();
		this.msj = getAlertJS(statusResponse);
	}

	private void calcularMontoCuota() {
		if (this.planPago.getInteres() == null)
			this.planPago.setInteres(BigDecimal.ZERO);
		if (this.planPago.getCapital() == null)
			this.planPago.setCapital(BigDecimal.ZERO);
		this.planPago.setMonto(this.planPago.getCapital().add(this.planPago.getInteres()));
	}

	private void calcularTotalPlanPago() {
		this.totalPlanPago = new PlanPago();
		this.totalPlanPago.setCapital(BigDecimal.ZERO);
		this.totalPlanPago.setInteres(BigDecimal.ZERO);
		this.totalPlanPago.setMonto(BigDecimal.ZERO);
		if (this.planPagos.size() > 0) {
			for (PlanPago cuota : this.planPagos) {
				this.totalPlanPago.setCapital(this.totalPlanPago.getCapital().add(cuota.getCapital()));
				this.totalPlanPago.setInteres(this.totalPlanPago.getInteres().add(cuota.getInteres()));
				this.totalPlanPago.setMonto(this.totalPlanPago.getMonto().add(cuota.getMonto()));
			}
		}
	}

	public void nuevoDebito() {
		log.info("nuevo debito ");
		this.msj = "";
		this.esAnulacion = false;
			this.debito = new Pago();
			this.debito.setCodUsuario(getVisit().getUsuarioSirAladi().getLogin());
			this.debito.setEstacion(getVisit().getAddress());
			this.debito.setInstitucion(this.registro.getInstitucion());
			this.debito.setInstrumento(new Instrumento());
			this.debito.setNit(this.registro.getNit());
			this.concepto = null;
	}

	public void modificarDebito(Pago pagoSel) {
		log.info("modificar debito " + pagoSel.getNroMov());		
		this.msj = "";
		this.esAnulacion = false;		
			this.debito = pagoSel;
			if (this.debito.getDebeMo().compareTo(BigDecimal.ZERO) > 0) {
				this.debito.setHaberMo(this.debito.getDebeMo().multiply(new BigDecimal(-1)));
				this.debito.setDebeMo(BigDecimal.ZERO);
			}
			
			String codInstrumento = this.debito.getInstrumento().getCodInstrumento().trim();
			if ((codInstrumento.equals(EXTORNO) || codInstrumento.equals(REVERSO_LEX))) {
				this.esAnulacion = true;
				this.debito.setInstrumento(this.mapInstrumentos.get(EXTORNO));
			} else {
				if (codInstrumento.equals(COMISIONES_Y_GASTOS))
					this.concepto = COMISIONES_Y_GASTOS;
				else if (codInstrumento.endsWith("I"))
					this.concepto = INTERES;
				else
					this.concepto = CAPITAL;
			}
	}
	public void anularDebito(Pago pagoSel) {
		log.info("anular debito " + pagoSel.getNroMov());		
		this.msj = "";
		this.esAnulacion = false;
			this.debito = pagoSel;
			if (this.debito.getDebeMo().compareTo(BigDecimal.ZERO) > 0) {
				this.debito.setHaberMo(this.debito.getDebeMo().multiply(new BigDecimal(-1)));
				this.debito.setDebeMo(BigDecimal.ZERO);
			}

				this.esAnulacion = true;
				this.debito.setInstrumento(this.mapInstrumentos.get(EXTORNO));

	}	

	public void registrarDebito(ActionEvent event) {
		log.info("registrar debito " );
		this.msj = "";

		if (this.debito.getHaberMo().compareTo(BigDecimal.ZERO) >= 0)
			this.debito.setDebeMo(BigDecimal.ZERO);
		else {
			this.debito.setDebeMo(this.debito.getHaberMo().abs());
			this.debito.setHaberMo(BigDecimal.ZERO);
		}

		StatusResponse statusResponse;
		if (this.debito.getNroMov() != null && this.debito.getNroMov() > 0 && !this.esAnulacion)
			statusResponse = Servicios.modificarDebitoReembolso(this.apertura, this.debito);
		else
			statusResponse = Servicios.registrarDebitoReembolso(this.apertura, this.debito);

		if (SUCCESS.equals(statusResponse.getStatusCode())) {
			this.recuperarPagos();
			this.recuperarPlanPagos();
			this.msj = getAlertConCierreModalJS("panelDebito", statusResponse);
		} else
			this.msj = getAlertJS(statusResponse);
	}

	public void autorizarDebito(Pago pagoSel) {
		log.info("Autorizar Pago " + pagoSel.getNroMov());		
		this.msj = "";
		this.debito = pagoSel;
		StatusResponse statusResponse = null;

			this.debito.setCveEstadoPago("C");
			statusResponse = Servicios.modificarDebitoReembolso(this.apertura, this.debito);

		if (statusResponse != null && statusResponse.getStatusCode().equals(SUCCESS)) {
			this.recuperarPagos();
			this.recuperarPlanPagos();
			this.obtenerSaldos();
		}
		this.msj = getAlertJS(statusResponse);
	}

	public void eliminarDebito(Pago pagoSel) {
		log.info("eliminar Pago " + pagoSel.getNroMov());		
		this.msj = "";
		this.debito = pagoSel;
		StatusResponse statusResponse = null;

			statusResponse = Servicios.eliminarDebitoReembolso(this.apertura, this.debito);

		if (statusResponse != null && statusResponse.getStatusCode().equals(SUCCESS)) {
			this.recuperarPagos();
			this.recuperarPlanPagos();
			this.obtenerSaldos();
		}
		this.msj = getAlertJS(statusResponse);
	}
	
	public void preAutorizarDebito(Pago pagoSel) {
		log.info("pre autorizar Pago " + pagoSel.getNroMov());
		this.msj = "";

		this.debito = pagoSel;
		StatusResponse statusResponse = null;

		this.debito.setCveEstadoPago("1");
		statusResponse = Servicios.modificarDebitoReembolso(this.apertura, this.debito);

		if (statusResponse != null && statusResponse.getStatusCode().equals(SUCCESS)) {
			this.recuperarPagos();
			this.recuperarPlanPagos();
			this.obtenerSaldos();
		}
		this.msj = getAlertJS(statusResponse);
	}

	private void recuperarPagos() {
		this.debitos = getSirAladiDao().getPagos(this.apertura.getNroMov());
		this.totalDebito = BigDecimal.ZERO;
		if (this.debitos != null && this.debitos.size() > 0) {
			for (Pago p : this.debitos)
				this.totalDebito = this.totalDebito.add(p.getHaberMo().subtract(p.getDebeMo()));
		}
	}

	public void seleccionarConcepto(ActionEvent event) {
		if (this.concepto.equals(CAPITAL))
			this.debito.setInstrumento(this.registro.getInstrumento());
		else if (this.concepto.equals(INTERES))
			this.debito.setInstrumento(this.mapInstrumentos.get(this.registro.getInstrumento().getCodInstrumento().trim() + "I"));
		else if (this.concepto.equals(COMISIONES_Y_GASTOS))
			this.debito.setInstrumento(mapInstrumentos.get(COMISIONES_Y_GASTOS));
	}

	public void filtrar(ActionEvent event) {
		if (StringUtils.isEmpty(this.filtro))
			this.aperturas = this.aperturasInicial;
		else {
			this.aperturas = new ArrayList<Apertura>();
			for (Apertura ap : this.aperturasInicial) {
				if (ap.getCodigoReembolso().indexOf(this.filtro.trim()) >= 0)
					this.aperturas.add(ap);
			}
		}
	}

	public void mostrarReporte(ActionEvent event) {
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("NRO_MOV", this.apertura.getNroMov());
		parametros.put("TITULO", (this.tipoApertura.equals(TIPO_APERTURA_IMPORTACION)) ? "DEBITOS" : "REEMBOLSOS");
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("pathTranslated", request.getPathTranslated());
		request.getSession().setAttribute("nombreReporte", "repPagosCobros.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}

	public void mostrarAdjunto(ActionEvent event) {
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("nroMov", this.apertura.getNroMov());
	}

	private void crearObjetosPorDefecto() {
		this.msj = "";
		this.esAnulacion = false;

		// Apertura
		this.apertura = new Apertura();
		this.apertura.setIdentificador(new Identificador());
		this.apertura.setInstitucion(new Institucion());
		this.apertura.setPais(new Pais());

		// Plan de Pagos
		this.planPagos = new ArrayList<PlanPago>();

		// Debitos (Pagos)
		this.debitos = new ArrayList<Pago>();

		// combos vacios
		this.itemsConcepto = new ArrayList<SelectItem>();

		this.estadoPagos = ESTADO_PENDIENTE;
	}

	private void obtenerDatosParametricos() {
		if (this.tipoApertura.equals(TIPO_APERTURA_EXPORTACION)) {
			String codInstrumento = this.registro.getInstrumento().getCodInstrumento().trim();
			this.itemsConcepto = new ArrayList<SelectItem>();
			this.itemsConcepto.add(new SelectItem(CAPITAL, "Capital"));
			if (codInstrumento.equals("CC") || codInstrumento.equals("CD") || codInstrumento.equals("OD") || codInstrumento.equals("LA"))
				this.itemsConcepto.add(new SelectItem(INTERES, "Interés"));
			this.itemsConcepto.add(new SelectItem(COMISIONES_Y_GASTOS, "Comisión y Gastos"));
		}

		// mapas de estados e instrumentos
		if (this.mapClavesEstadoPlan == null) {
			this.mapInstrumentos = armarMapInstrumentos(getSirAladiDao().getInstrumentos());
			this.mapClavesEstadoPlan = armarMapDescripcionClaves(getSirAladiDao().getClaves(CVE_ESTADO_PLAN_PAGO));
			this.mapClavesEstadoPago = armarMapDescripcionClaves(getSirAladiDao().getClaves(CVE_ESTADO_PAGO));
			this.mapClavesEstadoRegistro = armarMapDescripcionClaves(getSirAladiDao().getClaves(CVE_ESTADO_REGISTRO));
			this.mapClavesEstadoApertura = armarMapDescripcionClaves(getSirAladiDao().getClaves(CVE_ESTADO_APERTURA));
		}
	}

	public void setTipoApertura(String tipoApertura) {
		this.tipoApertura = tipoApertura;
	}

	public String getTipoApertura() {
		return tipoApertura;
	}

	public void setMapClavesEstadoApertura(Map<String, String> mapClavesEstadoApertura) {
		this.mapClavesEstadoApertura = mapClavesEstadoApertura;
	}

	public Map<String, String> getMapClavesEstadoApertura() {
		return mapClavesEstadoApertura;
	}

	public Pais getPaisConvenio() {
		return paisConvenio;
	}

	public void setPaisConvenio(Pais paisConvenio) {
		this.paisConvenio = paisConvenio;
	}

}
