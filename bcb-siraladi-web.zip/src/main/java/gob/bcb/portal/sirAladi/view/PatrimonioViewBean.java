package gob.bcb.portal.sirAladi.view;

import static gob.bcb.portal.sirAladi.commons.Constantes.CODIGO_PERSONA_BCB;
import gob.bcb.bpm.siraladi.jpa.DetPatrimonio;
import gob.bcb.bpm.siraladi.jpa.DetPatrimonioPK;
import gob.bcb.bpm.siraladi.jpa.Patrimonio;
import gob.bcb.bpm.siraladi.jpa.Persona;
import gob.bcb.bpm.siraladi.utils.UtilsPersist;
import gob.bcb.portal.sirAladi.comunes.controller.FacesContextUtil;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.event.ActionEvent;
import javax.persistence.EntityManagerFactory;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class PatrimonioViewBean extends BaseBeanController {
	private static Logger log = Logger.getLogger(PatrimonioViewBean.class);
	private static final String SELECT_PERSONAS = "FROM Persona p ORDER BY p.nomPersona";
	private Date fechaDesde;
	private Date fechaAl;
	private Patrimonio patrimonio;
	private List<Patrimonio> patrimonioList;
	private List<DetPatrimonio> detPatrimonioList;
	private List<DetPatrimonio> detPatrimonioListSel;
	private Map<String, String> personasIFAMap;
	private DetPatrimonio detPatrimonioSel;
	private BigDecimal totalPatBs;
	private BigDecimal totalPatSUS;
	private BigDecimal totalLimite;
	private BigDecimal totalSaldo;
	public PatrimonioViewBean() {
	}

	@PostConstruct
	public void init() {
		log.info("Iniciando el modulo de patrimonio.");
		recuperarVisit();
		inicializarDatos();
		
		if (getVisit().getParametro("SIRWEB_TMP_OBJECT") != null) {
			if (!(getVisit().getParametro("SIRWEB_TMP_OBJECT") instanceof PatrimonioViewBean)) {
			} else {
				PatrimonioViewBean objetoTMP = (PatrimonioViewBean) getVisit().getParametro("SIRWEB_TMP_OBJECT");
				patrimonioList = objetoTMP.getPatrimonioList();
				detPatrimonioList = objetoTMP.getDetPatrimonioList();
				patrimonio = objetoTMP.getPatrimonio();
				fechaDesde = objetoTMP.getFechaDesde();
				fechaAl = objetoTMP.getFechaAl();
			}
		}
		String action = (String) getVisit().getParametro("SIRWEB_TMP_ACTION");
		log.info("init SIRWEB_TMP_ACTION " + action);
		if (action != null) {
			if (action.equals("NEW")) {
				patrimonio = new Patrimonio();
			} else if (action.equals("SAVE")) {

			} else if (action.equals("SEARCH")) {

			} else {
				if (patrimonio != null && patrimonio.getNroOrden() != null && patrimonio.getNroOrden().compareTo(Integer.valueOf(0)) > 0) {
					patrimonio = getSirAladiDao().getPatrimonio(patrimonio.getNroOrden());
				}
			}
		} else {
			recuperaDatos(null);
		}
	}

	public void recuperaDatos(ActionEvent event) {
		patrimonioList = getSirAladiDao().getPatrimonios(fechaDesde, fechaAl);
		patrimonio = null;
		getVisit().setParametro("SIRWEB_TMP_OBJECT", this);
	}

	public String selecciona() {
		getVisit().setParametro("SIRWEB_TMP_OBJECT", this);
		patrimonioList = null;
		return null;
	}

	public void guardar(ActionEvent event) {
		// public String guardar() {
		Session session = getSirAladiDao().getHibernateTemplate().getSessionFactory().openSession();
		Transaction tx = session.getTransaction();

		String action = (String) getVisit().getParametro("SIRWEB_TMP_ACTION");

		Patrimonio maxPatrimonio = getSirAladiDao().getMaxPatrimonio();
		if (action != null) {
			if (action.equals("NEW")) {
				if (maxPatrimonio == null) {
					patrimonio.setNroOrden(Integer.valueOf(1));
				} else {
					patrimonio.setNroOrden(maxPatrimonio.getNroOrden() + 1);
				}
				patrimonio.setFechaActual(new Date());
			}
		}
		if (maxPatrimonio.getNroOrden().compareTo(patrimonio.getNroOrden()) == 0) {
			// es el ultimo patrimonio, se actualiza la fecha de actual
			patrimonio.setFechaActual(new Date());
		}
		log.info("Salvar cambios en patrimonio " + action + " nro orden " + patrimonio.getNroOrden());
		try {
			if (patrimonio.getFactorBs() == null || patrimonio.getFactorBs().compareTo(BigDecimal.ZERO) <= 0) {
				// patrimonio.setFactorBs(BigDecimal.ZERO);
				getFacesContext().addMessage(null, new FacesMessage("Factor de cambio invalido"));
				return;
			}
			if (patrimonio.getNivel() == null || patrimonio.getNivel().compareTo(BigDecimal.ZERO) <= 0) {
				// patrimonio.setNivel(BigDecimal.ZERO);
				getFacesContext().addMessage(null, new FacesMessage("Nivel de endeudamiento invalido"));
				return;
			}
			tx.begin();
			patrimonio.setFechaHora(new Date());
			patrimonio.setEstacion(getVisit().getUsuarioSirAladi().getLogin());
			patrimonio.setCodUsuario(getVisit().getUsuarioSirAladi().getLogin());
			session.saveOrUpdate(patrimonio);
			session.flush();
			// insertamos en det patrimonio las entidades vigentes menos el BCB
			if (action != null && action.equals("NEW")) {
				List<Persona> entidades = getSirAladiDao().getEntidades();
				for (Persona persona : entidades) {
					if (!persona.getCodPersona().trim().equals(CODIGO_PERSONA_BCB)) {
						DetPatrimonio detPatri = new DetPatrimonio();
						DetPatrimonioPK detPatrimonioPK = new DetPatrimonioPK();
						detPatrimonioPK.setCodPersona(persona.getCodPersona());
						detPatrimonioPK.setNroOrden(patrimonio.getNroOrden());
						detPatri.setId(detPatrimonioPK);
						detPatri.setPatBs(BigDecimal.ZERO);
						detPatri.setPatActual(BigDecimal.ZERO);
						detPatri.setLimiteMax(BigDecimal.ZERO);
						detPatri.setSaldoDeudor(getSirAladiDao().getSaldoContMo(persona.getCodPersona(), patrimonio.getFechaActual()));
						detPatri.setFechaHora(new Date());
						detPatri.setEstacion(getVisit().getUsuarioSirAladi().getLogin());
						detPatri.setCodUsuario(getVisit().getUsuarioSirAladi().getLogin());
						session.save(detPatri);
						session.flush();
					}
				}
			} else {
				// List<DetPatrimonio> detPatrimonios =
				// getSirAladiDao().getDetPatrimonios(patrimonio.getNroOrden());
				List<DetPatrimonio> detPatrimonios = detPatrimonioList;
				for (DetPatrimonio detPatri : detPatrimonios) {
					detPatri.setPatActual(BigDecimal.ZERO);
					if (patrimonio.getFactorBs() != null && patrimonio.getFactorBs().compareTo(BigDecimal.ZERO) > 0) {
						log.info("montoooooo " + patrimonio.getFactorBs());						
						BigDecimal monto = patrimonio.getFactorBs().setScale(7,BigDecimal.ROUND_HALF_UP);
						log.info("montoooooo " + monto);
						detPatri.setPatActual(detPatri.getPatBs().setScale(2, BigDecimal.ROUND_HALF_UP).divide(monto, BigDecimal.ROUND_HALF_UP));
						//detPatri.setPatActual((detPatri.getPatBs().setScale(2).divide(monto).setScale(2));
						//detPatri.setPatActual((detPatri.getPatBs().setScale(2).divide(patrimonio.getFactorBs().setScale(7), BigDecimal.ROUND_HALF_UP)).setScale(2));
					}
					detPatri.setLimiteMax(BigDecimal.ZERO);
					detPatri.setLimiteMax(detPatri.getPatActual().multiply(patrimonio.getNivel().divide((new BigDecimal(100.00)).setScale(2))));
					detPatri.setSaldoDeudor(getSirAladiDao().getSaldoContMo(detPatri.getId().getCodPersona(), patrimonio.getFechaActual()));
					detPatri.setFechaHora(new Date());
					detPatri.setEstacion(getVisit().getUsuarioSirAladi().getLogin());
					detPatri.setCodUsuario(getVisit().getUsuarioSirAladi().getLogin());
					session.saveOrUpdate(detPatri);
					session.flush();
				}

			}
			tx.commit();
			String msg = "Patrimonio con id " + patrimonio.getNroOrden() + " fue actualizado satisfactoriamente.";
			log.debug(msg);
			FacesContextUtil.addInfoMessage(msg);
		} catch (RuntimeException e) {
			tx.rollback();
			log.error("Error al guardar en BDD " + e.getMessage(), e);
			getFacesContext().addMessage(null, new FacesMessage(e.getMessage()));
			throw e;
		} finally {
			session.close();
		}
		detPatrimonioListSel = null;
		detPatrimonioList = null;
		getVisit().removeParametro("SIRWEB_TMP_OBJECT");
		getVisit().removeParametro("SIRWEB_TMP_ACTION");
		getVisit().setParametro("SIRWEB_TMP_ACTION", "EDIT");
		getVisit().setParametro("SIRWEB_TMP_OBJECT", this);
		// return null;
	}

	public String eliminar() {
		List<DetPatrimonio> detPatrimonios = getSirAladiDao().getDetPatrimonios(patrimonio.getNroOrden());
		if (detPatrimonios != null && detPatrimonios.size() > 0) {
			getFacesContext().addMessage(null,
					new FacesMessage("Existe elementos registrados en Detalle. Elimine primeramente los mismos para continuar"));
			return null;
		}
		Session session = getSirAladiDao().getHibernateTemplate().getSessionFactory().openSession();

		Transaction tx = session.getTransaction();
		try {
			tx.begin();
			session.delete(patrimonio);
			tx.commit();
		} catch (RuntimeException e) {
			tx.rollback();
			log.error("Error al guardar en BDD " + e.getMessage(), e);
			throw e;
		} finally {
			session.close();
		}
		return null;
	}

	public String nuevoRegistro() {
		getVisit().removeParametro("SIRWEB_TMP_OBJECT");
		patrimonioList = null;
		detPatrimonioListSel = null;
		detPatrimonioList = null;
		getVisit().setParametro("SIRWEB_TMP_ACTION", "NEW");
		patrimonio = new Patrimonio();
		getVisit().setParametro("SIRWEB_TMP_OBJECT", this);
		return null;
	}

	private void inicializarDatos() {
		patrimonioList = null;
		Calendar cal = GregorianCalendar.getInstance();
		fechaDesde = getSirAladiDao().getFechaActual();
		cal.setTime(fechaDesde);
		cal.add(Calendar.MONTH, -6);
		fechaDesde = cal.getTime();
		fechaAl = getSirAladiDao().getFechaActual();
		detPatrimonioListSel = new ArrayList<DetPatrimonio>();
	}

	public void actualizaIFAs(ActionEvent event) {
		if (patrimonio == null || patrimonio.getNroOrden() == null || patrimonio.getNroOrden().compareTo(Integer.valueOf(0)) <= 0) {
			getFacesContext().addMessage(null, new FacesMessage("No existe un lote de datos patrimonio seleccionado o el registro es nuevo"));
			return;
		}
		log.info("Actualizando IFAs en patrimonio " + patrimonio.getNroOrden());
		Session session = getSirAladiDao().getHibernateTemplate().getSessionFactory().openSession();
		Transaction tx = session.getTransaction();
		int cont= 0;
		try {
			tx.begin();
			List<Persona> entidades = getSirAladiDao().getEntidades();
			for (Persona persona : entidades) {
				if (!persona.getCodPersona().trim().equals(CODIGO_PERSONA_BCB)) {
					DetPatrimonioPK detPatrimonioPK = new DetPatrimonioPK();
					detPatrimonioPK.setCodPersona(persona.getCodPersona());
					detPatrimonioPK.setNroOrden(patrimonio.getNroOrden());
					DetPatrimonio detPat = (DetPatrimonio) getSirAladiDao().getHibernateTemplate().get(DetPatrimonio.class, detPatrimonioPK);
					if (detPat == null) {
						// el registro no existe en el lote
						DetPatrimonio detPatri = new DetPatrimonio();
						detPatrimonioPK = new DetPatrimonioPK();
						detPatrimonioPK.setCodPersona(persona.getCodPersona());
						detPatrimonioPK.setNroOrden(patrimonio.getNroOrden());
						detPatri.setId(detPatrimonioPK);
						detPatri.setPatBs(BigDecimal.ZERO);
						detPatri.setPatActual(BigDecimal.ZERO);
						detPatri.setLimiteMax(BigDecimal.ZERO);
						detPatri.setSaldoDeudor(getSirAladiDao().getSaldoContMo(persona.getCodPersona(), patrimonio.getFechaActual()));
						detPatri.setFechaHora(new Date());
						detPatri.setEstacion(getVisit().getUsuarioSirAladi().getLogin());
						detPatri.setCodUsuario(getVisit().getUsuarioSirAladi().getLogin());
						session.save(detPatri);
						cont++;
					}
				}
			}

			session.flush();
			tx.commit();
			String msg = "Patrimonio con id " + patrimonio.getNroOrden() + " actualiz� " + cont + " entidades.";
			log.info(msg);
			FacesContextUtil.addInfoMessage(msg);
		} catch (RuntimeException e) {
			tx.rollback();
			log.error("Error al guardar en BDD " + e.getMessage(), e);
			throw e;
		} finally {
			session.close();
		}
		detPatrimonioListSel = null;
		detPatrimonioList = null;
		getVisit().removeParametro("SIRWEB_TMP_OBJECT");
		getVisit().setParametro("SIRWEB_TMP_ACTION", "EDIT");
		getVisit().setParametro("SIRWEB_TMP_OBJECT", this);
	}

	public String irDetPatrimonio() {
		log.info("selecciona patrimonio irDetPatrimonio");
		patrimonioList = null;
		detPatrimonioListSel = null;
		detPatrimonioList = null;
		getVisit().setParametro("SIRWEB_TMP_OBJECT", this);
		return null;
	}

	public void setPatrimonio(Patrimonio patrimonio) {
		this.patrimonio = patrimonio;
	}

	public Patrimonio getPatrimonio() {
		return patrimonio;
	}

	public void setFechaDesde(Date fechaDesde) {
		this.fechaDesde = fechaDesde;
	}

	public Date getFechaDesde() {
		return fechaDesde;
	}

	public void setFechaAl(Date fechaAl) {
		this.fechaAl = fechaAl;
	}

	public Date getFechaAl() {
		return fechaAl;
	}

	public void setPatrimonioList(List<Patrimonio> patrimonioList) {
		this.patrimonioList = patrimonioList;
	}

	public List<Patrimonio> getPatrimonioList() {
		return patrimonioList;
	}

	public void setDetPatrimonioList(List<DetPatrimonio> detPatrimonioList) {
		this.detPatrimonioList = detPatrimonioList;
	}

	public List<DetPatrimonio> getDetPatrimonioList() {
		// detPatrimonioList = null;
		totalPatBs = BigDecimal.ZERO;
		totalPatSUS = BigDecimal.ZERO;
		totalLimite = BigDecimal.ZERO;
		totalSaldo = BigDecimal.ZERO;
		if (patrimonio != null && detPatrimonioList == null) {
			detPatrimonioList = getSirAladiDao().getDetPatrimonios(patrimonio.getNroOrden());
		}
		if (detPatrimonioList != null && detPatrimonioList.size() > 0) {
			for (DetPatrimonio detPatri : detPatrimonioList) {
				if (detPatri.getPatBs() != null)
					totalPatBs = totalPatBs.add(detPatri.getPatBs());
				if (detPatri.getPatActual() != null)
					totalPatSUS = totalPatSUS.add(detPatri.getPatActual());
				if (detPatri.getLimiteMax() != null)
					totalLimite = totalLimite.add(detPatri.getLimiteMax());
				if (detPatri.getSaldoDeudor() != null)
					totalSaldo = totalSaldo.add(detPatri.getSaldoDeudor());
			}
		}
		return detPatrimonioList;
	}

	public void setPersonasIFAMap(Map<String, String> personasIFAMap) {
		this.personasIFAMap = personasIFAMap;
	}

	public Map<String, String> getPersonasIFAMap() {
		if (patrimonio != null) {
			personasIFAMap = new HashMap<String, String>();
			List<Persona> entidades = (List<Persona>) getSirAladiDao().getHibernateTemplate().find(SELECT_PERSONAS);
			for (Persona persona : entidades) {
				if (!persona.getCodPersona().trim().equals(CODIGO_PERSONA_BCB)) {
					personasIFAMap.put(persona.getCodPersona(), persona.getNomPersona().trim());
				}
			}
		}
		return personasIFAMap;
	}

	public void setDetPatrimonioListSel(List<DetPatrimonio> detPatrimonioListSel) {
		this.detPatrimonioListSel = detPatrimonioListSel;
	}

	public List<DetPatrimonio> getDetPatrimonioListSel() {
		return detPatrimonioListSel;
	}

	public void setDetPatrimonioSel(DetPatrimonio detPatrimonioSel) {
		String msg = "Campos editados presione GUARDAR para hacer efectivo los cambios.";
		FacesContextUtil.addInfoMessage(msg);		
		getVisit().setParametro("SIRWEB_TMP_OBJECT", this);		
		this.detPatrimonioSel = detPatrimonioSel;
	}

	public DetPatrimonio getDetPatrimonioSel() {
		return detPatrimonioSel;
	}

	public void setTotalPatBs(BigDecimal totalPatBs) {
		this.totalPatBs = totalPatBs;
	}

	public BigDecimal getTotalPatBs() {
		return totalPatBs;
	}

	public void setTotalPatSUS(BigDecimal totalPatSUS) {
		this.totalPatSUS = totalPatSUS;
	}

	public BigDecimal getTotalPatSUS() {
		return totalPatSUS;
	}

	public void setTotalLimite(BigDecimal totalLimite) {
		this.totalLimite = totalLimite;
	}

	public BigDecimal getTotalLimite() {
		return totalLimite;
	}

	public void setTotalSaldo(BigDecimal totalSaldo) {
		this.totalSaldo = totalSaldo;
	}

	public BigDecimal getTotalSaldo() {
		return totalSaldo;
	}
	public EntityManagerFactory getEntityManagerFactory(String path, String idDBSource, String persistenceUnit) {
		EntityManagerFactory factory = UtilsPersist.createEntityManagerFactory2(path, idDBSource, persistenceUnit);
		return factory;
	}	
}
