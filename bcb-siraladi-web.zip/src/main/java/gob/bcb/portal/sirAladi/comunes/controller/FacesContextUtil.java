package gob.bcb.portal.sirAladi.comunes.controller;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * Clase utilitaria que permite obterner atributos del HttpServletRequest y HttpSession
 */
public class FacesContextUtil {
    /**
     * Establece un objeto en el HttpSession
     * @param fc FacesContext para obtener el contexto
     * @param key Llave para registrar el objeto
     * @param obj El objeto a ser almacenado
     */
    public static void setSessionAttribute(FacesContext fc, String key, Object obj) {
        HttpSession session = ((HttpSession) fc.getExternalContext().getSession(false));
        session.setAttribute(key, obj);
    }

    /**
     * Obtiene un objeto del HttpSession
     * @param fc FacesContext para obtener el contexto
     * @param key Llave del objeto buscado
     * @return El objeto almacenado en la sesion
     */
    public static Object getSessionAttribute(FacesContext fc, String key) {
        return ((HttpSession) fc.getExternalContext().getSession(false)).getAttribute(key);
    }

    /**
     * Retorna el objeto HttpSession relacionado con el FacesContext proporcionado
     * @param fc FacesContext para obtener el contexto
     * @return Objeto HttpSession
     */
    public static HttpSession getSession(FacesContext fc) {
        return (HttpSession) fc.getExternalContext().getSession(false);
    }

    /**
     * Obtiene un entero del HttpSession
     * @param fc FacesContext para obtener el contexto
     * @param key Llave del entero buscado
     * @return El entero almacenado en la sesion
     */
    public static Integer getIntSessionAttribute(FacesContext fc, String key) {
        return (Integer) ((HttpSession) fc.getExternalContext().getSession(false)).getAttribute(key);
    }

    /**
     * Obtiene una cadena del HttpSession
     * @param fc FacesContext para obtener el contexto
     * @param key Llave de la cadena buscada
     * @return La cadena almacenada en la sesion
     */
    public static String getStringSessionAttribute(FacesContext fc, String key) {
        return (String) ((HttpSession) fc.getExternalContext().getSession(false)).getAttribute(key);
    }

    /**
     * Obtiene un parametro del HttpServletRequest
     * @param fc FacesContext para obtener el contexto
     * @param paramName Llave del parametro buscado
     * @return La cadena con el valor del parametro
     */
    public static String getRequestParameter(FacesContext fc, String paramName) {
        return fc.getExternalContext().getRequestParameterMap().get(paramName);
    }

    /**
     * Establece un parametro en el HttpServletRequest
     * @param fc FacesContext para obtener el contexto
     * @param paramName El nombre del parametro
     * @param valor El valor del parametro
     */
    public static void setRequestAttribute(FacesContext fc, String paramName, Object valor) {
        HttpServletRequest request = (HttpServletRequest) fc.getExternalContext().getRequest();
        request.setAttribute(paramName, valor);
    }

    /**
     * Obtiene un parametro de tipo entero del HttpServletRequest
     * @param fc FacesContext para obtener el contexto
     * @param paramName Llave del parametro buscado
     * @return El entero con el valor del parametro
     */
    public static Integer getIntRequestParameter(FacesContext fc, String paramName) {
        String number = fc.getExternalContext().getRequestParameterMap().get(paramName);
        return (number != null && !number.trim().equals("")) ? Integer.parseInt(number) : null;
    }

    public static boolean isDevelopment(FacesContext fc){
        ExternalContext external = fc.getExternalContext();
        String param = external.getInitParameter("facelets.DEVELOPMENT");
        return "true".equals(param);
    }
	/**
	 * Add information message.
	 * 
	 * @param msg the information message
	 */
	public static void addInfoMessage(String msg) {
		addInfoMessage(null, msg);
	}
	
	/**
	 * Add information message to a sepcific client.
	 * 
	 * @param clientId the client id 
	 * @param msg the information message
	 */
	public static void addInfoMessage(String clientId, String msg) {
		FacesContext.getCurrentInstance().addMessage(clientId, new FacesMessage(FacesMessage.SEVERITY_INFO, msg, msg));
	}
	
	/**
	 * Add error message.
	 * 
	 * @param msg the error message
	 */
	public static void addErrorMessage(String msg) {
		addErrorMessage(null, msg);
	}
	
	/**
	 * Add error message to a sepcific client.
	 * 
	 * @param clientId the client id 
	 * @param msg the error message
	 */	
	public static void addErrorMessage(String clientId, String msg) {
		FacesContext.getCurrentInstance().addMessage(clientId, new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, msg));
	}    
}
