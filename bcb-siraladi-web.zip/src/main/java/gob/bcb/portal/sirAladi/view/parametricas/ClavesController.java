package gob.bcb.portal.sirAladi.view.parametricas;

import gob.bcb.bpm.siraladi.jpa.Clave;
import gob.bcb.bpm.siraladi.jpa.Claves;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;

import java.util.ArrayList;
import java.util.List;

import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;

public class ClavesController extends BaseBeanController {
	private Logger log = Logger.getLogger(ClavesController.class);
	
	private Clave socClaves = new Clave();
	private Claves socValorescla = new Claves();
	private List<Claves> socValoresclaLista = new ArrayList<Claves>();
	private List<SelectItem> monedas = new ArrayList<SelectItem>();
	private String mensaje = "";
	private List<Clave> socClavesLista = new ArrayList<Clave>();
	private String sIOCWEB_TIPOPERACION;

//	@PostConstruct
//	public void init() {
//		log.info("PostConstruct - " + getClass().getName());
//		try {
//			recuperarVisit();
//			String codEnt = getVisit().getUsuarioSirAladi().getPersona().getCodPersona();
//			String ip = getVisit().getAddress();
//
//			sIOCWEB_TIPOPERACION = (String) getVisit().getParametro("SIOCWEB_TIPOPERACION");
//			log.info("Par. sIOCWEB_TIPOPERACION= " + sIOCWEB_TIPOPERACION + " usuario: " + getVisit().getUsuarioSirAladi().getLogin()
//					+ " ==> codEnt: " + codEnt + " ip " + ip);
//
//			crearObjetosPorDefecto();
//
//			recuperarDatos();
//		} catch (Exception e) {
//			log.error("Error al obtener solicitud " + e.getMessage(), e);
//			FacesContext.getCurrentInstance().addMessage(null,
//					new FacesMessage(FacesMessage.SEVERITY_ERROR, "OcurriÃƒÆ’Ã‚Â³ un error: " + e.getMessage(), null));
//		}
//
//	}
//
//	private void crearObjetosPorDefecto() {
//		monedas.add(new SelectItem(34, "DOLARES ESTADOUNIDENSES"));
//		monedas.add(new SelectItem(69, "BOLIVIANOS"));
//	}
//
//	private void recuperarDatos() {
//
//		if (sIOCWEB_TIPOPERACION.equals("CLAVESPAR")) {
//			Param  socParametros = getServiceDao().getParamsLocal().findByCodigo("claves-list");
//			String listaclaves = socParametros.getValparam();
//			
//			socClavesLista = getServiceDao().getClavesLocal().getValoresByClave(listaclaves);
//		} else if (sIOCWEB_TIPOPERACION.equals("VER_DETCLAVE")) {
//			String SIOCWEB_CODBENEF = (String) getVisit().getParametro("SIOCWEB_CODCLAVE");
//			log.info("XXX: SIOCWEB_CODBENEF " + SIOCWEB_CODBENEF);
//			if (!StringUtils.isBlank(SIOCWEB_CODBENEF)) {
//				recuperarBenef(SIOCWEB_CODBENEF);
//			}
//		}
//
//	}
//
//	public void botonBuscar(ActionEvent actionEvent) {
//		buscar();
//	}
//
//	public void recuperarBenef(String benCodigo) {
//		socClaves = getServiceDao().getClavesLocal().claveByCodigo(benCodigo);
//
//		socValoresclaLista = getServiceDao().getClavesLocal().getValoresByClave(benCodigo);
//	}
//
//	public void buscar() {
//	}
//
//	public void adicionarNuevo(ActionEvent event) {
//		ClavesPK socValoresclaPK = new ClavesPK();
//		socValorescla = new Claves();
//		socValorescla.setId(socValoresclaPK);
//
//	}
//
//	public void editar(ActionEvent event) {
//		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
//		int fila = dataTable.getRowIndex();
//		log.info("editando fila: " + fila);
//		Claves cta0 = (Claves) SerializationUtils.clone(this.socValoresclaLista.get(fila));
//		socValorescla = getServiceDao().getClavesLocal().getValoresByCod(cta0.getId().getNomdato(), cta0.getId().getValdato());
//	}
//
//	public void adicionar(ActionEvent event) {
//		socClaves = new Clave();
//	}
//
//	public void guardarReg(ActionEvent event) {
//		try {
//			getServiceDao().getClavesLocal().saveOrUpdate(socClaves);
//			socClavesLista.clear();
//			DropDownBean dropDownBean = getVisit().getMainController();
//			log.info("XXX: dropDownBean.getPagina() " + dropDownBean.getPagina());
//			dropDownBean.setPagina("/Modulos/Transferencias/listaBenefsLocalDet.xhtml");
//			getVisit().setParametro("SIOCWEB_CLACODIGO", socClaves.getClaCodigo());
//			getVisit().setParametro("SIOCWEB_TIPOPERACION", "VER_DETCLAVE");
//
//			recuperarBenef(socClaves.getClaCodigo());
//
//		} catch (Exception e) {
//			log.error("Operacion con error: " + e.getMessage(), e);
//			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
//		}
//	}
//	public void guardarValorCla(Claves socValorescla) {
//		socValorescla.setEstacion(getVisit().getAddress());
//		socValorescla.setUsrCodigo(getVisit().getUsuarioSession().getLogin());
//		socValorescla.setFechaHora(new Date());
//		getServiceDao().getClavesLocal().saveOrUpdate(socValorescla);
//		
//	}
//	public void guardarValorClave(ActionEvent event) {
//		try {
//			socValorescla.getId().setClaCodigo(socClaves.getClaCodigo());
//			socValorescla.setClaVigente(Short.valueOf("1"));
//
//			guardarValorCla(socValorescla);
//
//			recuperarBenef(socClaves.getClaCodigo());
//		} catch (Exception e) {
//			log.error("Operacion con error: " + e.getMessage(), e);
//			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
//		}
//	}
//
//	public void guardarValorClaveM(ActionEvent event) {
//		try {
//			socValorescla.setClaVigente(Short.valueOf("1"));			
//			guardarValorCla(socValorescla);
//			recuperarBenef(socValorescla.getId().getClaCodigo());
//		} catch (Exception e) {
//			log.error("Operacion con error: " + e.getMessage(), e);
//			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
//		}
//	}
//
//	public void eliminar(ActionEvent event) {
//		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
//		int fila = dataTable.getRowIndex();
//
//		Claves cta0 = (Claves) SerializationUtils.clone(this.socValoresclaLista.get(fila));
//
//		try {
//			socValorescla = getServiceDao().getClavesLocal().getValoresByCod(cta0.getId().getClaCodigo(), cta0.getId().getValCodigo());
//			socValorescla.setClaVigente(Short.valueOf("0"));
//			guardarValorCla(socValorescla);			
//			getServiceDao().getClavesLocal().saveOrUpdate(socValorescla);
//			log.info("Se dio de baja el registro.");
//
//			recuperarBenef(socClaves.getClaCodigo());
//		} catch (Exception e) {
//			log.error("Operacion con error: " + e.getMessage(), e);
//			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
//		}
//	}
//
//	public void eventoGenerarBtn(ActionEvent action) {
//		getServiceDao().getClavesLocal().saveOrUpdate(socClaves);		
//	}
//
//	public List<SelectItem> getMonedas() {
//		return monedas;
//	}
//
//	public void setMonedas(List<SelectItem> monedas) {
//		this.monedas = monedas;
//	}
//
//	public void setMensaje(String mensaje) {
//		this.mensaje = mensaje;
//	}
//
//	public String getMensaje() {
//		return mensaje;
//	}
//
//	public Clave getClave() {
//		return socClaves;
//	}
//
//	public void setClave(Clave socClaves) {
//		this.socClaves = socClaves;
//	}
//
//	public Claves getClaves() {
//		return socValorescla;
//	}
//
//	public void setClaves(Claves socValorescla) {
//		this.socValorescla = socValorescla;
//	}
//
//	public List<Claves> getClavesLista() {
//		return socValoresclaLista;
//	}
//
//	public void setClavesLista(List<Claves> socValoresclaLista) {
//		this.socValoresclaLista = socValoresclaLista;
//	}
//
//	public List<Clave> getClaveLista() {
//		return socClavesLista;
//	}
//
//	public void setClaveLista(List<Clave> socClavesLista) {
//		this.socClavesLista = socClavesLista;
//	}
//
//

}
