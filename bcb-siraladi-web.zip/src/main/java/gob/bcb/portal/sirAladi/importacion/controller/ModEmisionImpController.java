/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-sirAladi
 * gob.bcb.portal.sirAladi.importacion.controller.ModEmisionImpController
 * 15/07/2011 - 15:30:12
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.importacion.controller;

import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarSelectItemsInstituciones;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarSelectItemsPaises;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.getAlertJS;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.getCierreModalPanelJS;
import static gob.bcb.portal.sirAladi.commons.Constantes.CODIGO_MONEDA_DOLARES;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTADO_PENDIENTE;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTADO_VIGENTE;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTILO_INVISIBLE;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTILO_VISIBLE;
import static gob.bcb.portal.sirAladi.commons.Constantes.SUCCESS;
import static gob.bcb.portal.sirAladi.commons.Constantes.TIPO_APERTURA_IMPORTACION;
import static gob.bcb.portal.sirAladi.commons.Constantes.TIPO_EMISION_EMISION;
import static gob.bcb.portal.sirAladi.commons.Constantes.TIPO_MOVIMIENTO_APERTURA;
import gob.bcb.bpm.siraladi.jpa.Adjunto;
import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.Identificador;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Instrumento;
import gob.bcb.bpm.siraladi.jpa.Pais;
import gob.bcb.bpm.siraladi.jpa.Registro;
import gob.bcb.bpm.siraladi.pojo.StatusResponse;
import gob.bcb.portal.sirAladi.commons.Archivo;
import gob.bcb.portal.sirAladi.commons.Servicios;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.richfaces.event.UploadEvent;
import org.richfaces.model.UploadItem;

/**
 * Backing Bean de la vista de modificaci�n de emisi�n de importaci�n.
 * 
 * @author wherrera
 * 
 */
public class ModEmisionImpController extends BaseBeanController {
	private String filtro;
	private String msj;
	private boolean mostrarModal;

	private Apertura apertura;
	private Registro registro;
	private Adjunto adjunto;
	private Archivo archivo;

	private List<Apertura> emisionesPendientes;
	private List<Apertura> emisionesInicial;
	private List<SelectItem> itemsPaisesExterior;
	private List<SelectItem> itemsInstitucionesExterior;

	private static Logger log = Logger.getLogger(ModEmisionImpController.class);

	public ModEmisionImpController() {
	}

	@PostConstruct
	public void init() {
		log.info("Iniciando el modulo de modificaciones de emisiones para Importacion.");
		recuperarVisit();
		this.crearObjetosPorDefecto();
		this.consultarPendientes();
		if (this.emisionesPendientes == null || this.emisionesPendientes.size() == 0)
			mostrarModal = false;

	}

	public Apertura getApertura() {
		return apertura;
	}

	public void setApertura(Apertura apertura) {
		this.apertura = apertura;
	}

	public Registro getRegistro() {
		return registro;
	}

	public void setRegistro(Registro registro) {
		this.registro = registro;
	}

	public List<Apertura> getEmisionesPendientes() {
		return emisionesPendientes;
	}

	public void setEmisionesPendientes(List<Apertura> emisionesPendientes) {
		this.emisionesPendientes = emisionesPendientes;
	}

	public String getMsj() {
		return msj;
	}

	public void setMsj(String msj) {
		this.msj = msj;
	}

	public boolean isMostrarModal() {
		return mostrarModal;
	}

	public String getFiltro() {
		return filtro;
	}

	public void setFiltro(String filtro) {
		this.filtro = filtro;
	}

	public List<SelectItem> getItemsPaisesExterior() {
		return itemsPaisesExterior;
	}

	public void setItemsPaisesExterior(List<SelectItem> itemsPaisesExterior) {
		this.itemsPaisesExterior = itemsPaisesExterior;
	}

	public List<SelectItem> getItemsInstitucionesExterior() {
		return itemsInstitucionesExterior;
	}

	public void setItemsInstitucionesExterior(List<SelectItem> itemsInstitucionesExterior) {
		this.itemsInstitucionesExterior = itemsInstitucionesExterior;
	}

	public String getEstiloPaginacionPendientes() {
		return (this.emisionesPendientes != null && this.emisionesPendientes.size() > 10) ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	public String getEstiloGrillaPendientes() {
		return (this.emisionesPendientes != null && this.emisionesPendientes.size() > 0) ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	public String getEstiloMsjSinPendientes() {
		return (this.emisionesPendientes != null && this.emisionesPendientes.size() > 0) ? ESTILO_INVISIBLE : ESTILO_VISIBLE;
	}

	public String getEstiloMostrarEmision() {
		return (this.apertura != null && this.apertura.getNroMov() != null && this.apertura.getNroMov() > 0) ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	public void seleccionarPais(ActionEvent event) {
		String codPais = this.apertura.getPais().getCodPais();
		this.cargarBancosPaisExterior(codPais);
	}

	public void cargarBancosPaisExterior(String codPais) {
		if (!StringUtils.isEmpty(codPais))
			this.itemsInstitucionesExterior = armarSelectItemsInstituciones(getSirAladiDao().getInstitucionesPorPais(codPais));
		else
			this.itemsInstitucionesExterior.clear();
	}

	public void registrarApertura(ActionEvent event) {
		this.msj = "";
		StatusResponse statusResponse = null;
		try {
			Integer.valueOf(this.apertura.getAnio());
			Integer.valueOf(this.apertura.getSecuencia());
			this.completarDatos();
			statusResponse = Servicios.guardarEmision(this.apertura, this.registro);
			if (SUCCESS.equalsIgnoreCase(statusResponse.getStatusCode()))
				this.recuperarApertura(this.apertura.getNroMov(), true);
			log.info(statusResponse.getDescrip());
		} catch (Exception e) {
			statusResponse = new StatusResponse("Error al guardar la emisi�n.");
			e.printStackTrace();
		}
		this.msj = getAlertJS(statusResponse);
	}

	private void completarDatos() {
		Date fecha = getSirAladiDao().getFechaActual();

		// Apertura
		this.apertura.setCveTipoApe(TIPO_APERTURA_IMPORTACION);
		this.apertura.setCodMoneda(CODIGO_MONEDA_DOLARES);
		this.apertura.setFechaCalc(fecha);

		// Registro
		this.registro.setCveEstadoReg(ESTADO_PENDIENTE);
		this.registro.setCveTipoEmis(TIPO_EMISION_EMISION);
		this.registro.setHaberMo(BigDecimal.ZERO);
		this.registro.setFechaTrans(fecha);
		this.registro.setEstacion(getVisit().getAddress());
		this.registro.setCodUsuario(getVisit().getUsuarioSirAladi().getLogin());
	}

	public void consultarPendientes(ActionEvent event) {
		this.consultarPendientes();
	}

	private void consultarPendientes() {
		this.msj = "";
		this.emisionesPendientes = getSirAladiDao().getAperturas(TIPO_APERTURA_IMPORTACION, ESTADO_VIGENTE, "R", ESTADO_PENDIENTE,
				getVisit().getUsuarioSirAladi().getPersona(), null, null, null);
		this.emisionesInicial = this.emisionesPendientes;
	}

	public void seleccionarEmisionPendiente(Apertura aperturaSel) {
		log.info("Aertura select "  + aperturaSel.getNroMov());
		this.msj = "";
		this.mostrarModal = false;
		this.apertura = aperturaSel;
		this.recuperarApertura(this.apertura.getNroMov(), false);
		if (this.itemsPaisesExterior == null || this.itemsPaisesExterior.size() == 0) {
			List<Pais> listaPaisesExterior = getSirAladiDao().getPaisesExterior();
			this.itemsPaisesExterior = armarSelectItemsPaises(listaPaisesExterior);
		}
		this.emisionesInicial.clear();
		this.emisionesPendientes.clear();
		this.msj = getCierreModalPanelJS("modalPanelPendientes");
	}

	private void recuperarApertura(Integer nroMovApertura, boolean consultarApertura) {
		if (consultarApertura)
			this.apertura = getSirAladiDao().getApertura(nroMovApertura);
		this.registro = getSirAladiDao().getRegistroEmision(nroMovApertura);
		this.cargarBancosPaisExterior(this.apertura.getPais().getCodPais());
		adjunto = getSirAladiDao().getAdjunto(nroMovApertura);
	}

	public void filtrar(ActionEvent event) {
		if (StringUtils.isEmpty(this.filtro))
			this.emisionesPendientes = this.emisionesInicial;
		else {
			this.emisionesPendientes = new ArrayList<Apertura>();
			for (Apertura ap : this.emisionesInicial) {
				if (ap.getCodigoReembolso().indexOf(this.filtro.trim()) >= 0)
					this.emisionesPendientes.add(ap);
			}
		}
	}

	public void mostrarReporte(ActionEvent event) {
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("NRO_MOV", this.apertura.getNroMov());
		parametros.put("TITULO", "EMISION DE INSTRUMENTO");
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("pathTranslated", request.getPathTranslated());
		request.getSession().setAttribute("nombreReporte", "repApertura.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}
	
	public void adjuntar(UploadEvent event) {
		this.msj = "";
		UploadItem item = event.getUploadItem();
		StatusResponse statusResponse = new StatusResponse("");
		try {
			this.archivo = new Archivo();
			this.archivo.setLength(item.getData().length);
			this.archivo.setNombreMimeExtension(item.getFileName(), this.apertura.getCodigoReembolsoCorrido());
			this.archivo.setData(item.getData());
			if (this.apertura != null && this.apertura.getNroMov() != null && this.apertura.getNroMov() > 0) {

				this.archivo.guardarAdjunto(this.apertura.getNroMov(), TIPO_MOVIMIENTO_APERTURA);
				this.archivo = null;
				adjunto = getSirAladiDao().getAdjunto(apertura.getNroMov());
				//statusResponse = new StatusResponse("Archivo adjunto actualizado exit�samente");
			} else {
				//statusResponse = new StatusResponse("No existe instrumento seleccionado");
			}
		} catch (Exception e) {
			statusResponse = new StatusResponse("Hubo un error al modificar el archivo adjunto " + e.getMessage());
			log.error("Hubo un error al modificar el archivo adjunto " + e.getMessage(), e);
		}
		this.msj = getAlertJS(statusResponse);
	}

	public void mostrarAdjunto(ActionEvent event) {
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("nroMov", this.apertura.getNroMov());
	}

	private void crearObjetosPorDefecto() {
		this.msj = "";
		this.mostrarModal = true;

		// Pendientes
		this.emisionesPendientes = new ArrayList<Apertura>();

		// Apertura
		this.apertura = new Apertura();
		this.apertura.setIdentificador(new Identificador());
		this.apertura.setInstitucion(new Institucion());
		this.apertura.setPais(new Pais());

		// Registro
		this.registro = new Registro();
		this.registro.setInstrumento(new Instrumento());
		this.registro.setInstitucion(new Institucion());

		// Combos
		this.itemsPaisesExterior = new ArrayList<SelectItem>();
		this.itemsInstitucionesExterior = new ArrayList<SelectItem>();

	}

	public void setAdjunto(Adjunto adjunto) {
		this.adjunto = adjunto;
	}

	public Adjunto getAdjunto() {
		return adjunto;
	}

	public void setArchivo(Archivo archivo) {
		this.archivo = archivo;
	}

	public Archivo getArchivo() {
		return archivo;
	}

}
