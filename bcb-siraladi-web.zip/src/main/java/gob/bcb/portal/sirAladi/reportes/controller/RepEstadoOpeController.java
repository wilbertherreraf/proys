/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-web-sirAladi
 * gob.bcb.portal.sirAladi.reportes.controller.RepEstadoOpeController
 * 04/10/2011 - 10:56:28
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.reportes.controller;

import static gob.bcb.portal.sirAladi.commons.AladiUtils.dateToString;
import static gob.bcb.portal.sirAladi.commons.Constantes.CODIGO_PERSONA_BCB;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTILO_INVISIBLE;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTILO_VISIBLE;
import static gob.bcb.portal.sirAladi.commons.Constantes.FORMATO_FECHA_JAVA;
import static gob.bcb.portal.sirAladi.commons.Constantes.TIPO_APERTURA_IMPORTACION;
import gob.bcb.bpm.siraladi.jpa.Persona;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

/**
 * Backing bean de la vista de consulta de estado de operaciones de importacion
 * 
 * @author wherrera
 * 
 */
public class RepEstadoOpeController extends BaseBeanController {
	private Date fecha;
	private String codPersonaUsuario;
	private String tipoOperacion;
	private String descTipoOperacion;
	private String queryDetalle;
	private String queryResumen;
	private String msj;
	private boolean desabilitado;
	private boolean esUsuarioBCB;
	private boolean esExportacion;

	private Persona persona;

	// private SirAladiDao sirAladiDao;
	private List<List<Object>> listaOperaciones;
	private List<BigDecimal> total;
	private List<SelectItem> itemsPersonas;

	private static Logger log = Logger.getLogger(RepEstadoOpeController.class);

	public RepEstadoOpeController() {
	}

	@PostConstruct
	public void init() {
		log.info("PostConstruct: Iniciando el modulo de consulta de estado de operaciones.");
		this.msj = "";
		this.desabilitado = true;
		this.listaOperaciones = null;
		this.persona = new Persona();
		
		recuperarVisit();
		this.fecha = getSirAladiDao().getFechaActual();		
		if (getVisit().getParametro("SIRWEB_TMP_OBJECT") != null){
			if (!(getVisit().getParametro("SIRWEB_TMP_OBJECT") instanceof RepEstadoOpeController)){
				getVisit().removeParametro("SIRWEB_TMP_OBJECT");
			} else {
				RepEstadoOpeController repEstadoOpeController = ((RepEstadoOpeController) getVisit().getParametro("SIRWEB_TMP_OBJECT"));
				this.persona = repEstadoOpeController.getPersona();
				this.fecha = repEstadoOpeController.getFecha();
				this.listaOperaciones = repEstadoOpeController.getListaOperaciones();
			}
		}

		this.tipoOperacion = getVisit().getMainAladiController().getTipoOperacion();
		this.esExportacion = !this.tipoOperacion.equals(TIPO_APERTURA_IMPORTACION);
		this.descTipoOperacion = this.esExportacion ? "Exportaci�n" : "Importaci�n";
		this.codPersonaUsuario = getVisit().getUsuarioSirAladi().getPersona().getCodPersona();
		this.esUsuarioBCB = this.codPersonaUsuario.trim().equals(CODIGO_PERSONA_BCB);
		this.itemsPersonas = new ArrayList<SelectItem>();
		if (this.esUsuarioBCB) {
			List<Persona> entidades = getSirAladiDao().getEntidades();
			for (Persona p : entidades)
				this.itemsPersonas.add(new SelectItem(p.getCodPersona(), p.getNomPersona().trim()));
		}
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public Persona getPersona() {
		return persona;
	}

	public void setPersona(Persona persona) {
		this.persona = persona;
	}

	public List<List<Object>> getListaOperaciones() {
		if (listaOperaciones != null) {
			this.total = Arrays.asList(new BigDecimal[] { BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO });
			for (List<Object> reg : this.listaOperaciones) {
				this.total.set(0, this.total.get(0).add((BigDecimal) reg.get(6)));
				this.total.set(1, this.total.get(1).add((BigDecimal) reg.get(7)));
				this.total.set(2, this.total.get(2).add((BigDecimal) reg.get(8)));
			}
		}
		return listaOperaciones;
	}

	public void setListaOperaciones(List<List<Object>> listaOperaciones) {
		this.listaOperaciones = listaOperaciones;
	}

	public List<SelectItem> getItemsPersonas() {
		
		return itemsPersonas;
	}

	public void setItemsPersonas(List<SelectItem> itemsPersonas) {
		this.itemsPersonas = itemsPersonas;
	}

	public boolean isDesabilitado() {
		return desabilitado;
	}

	public void setDesabilitado(boolean desabilitado) {
		this.desabilitado = desabilitado;
	}

	public boolean isHabilitado() {
		return !desabilitado;
	}

	public String getMsj() {
		return msj;
	}

	public void setMsj(String msj) {
		this.msj = msj;
	}

	public List<BigDecimal> getTotal() {
		return total;
	}

	public String getDescTipoOperacion() {
		return descTipoOperacion;
	}

	public void setDescTipoOperacion(String descTipoOperacion) {
		this.descTipoOperacion = descTipoOperacion;
	}

	public String getEstiloPaginacionOperaciones() {
		return (this.listaOperaciones != null && this.listaOperaciones.size() > 15) ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	public String getEstiloBuscar() {
		return this.desabilitado ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	public String getEstiloLimpiar() {
		return this.desabilitado ? ESTILO_INVISIBLE : ESTILO_VISIBLE;
	}

	public String getEstiloUsuarioBCB() {
		return this.esUsuarioBCB ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	public boolean isEsUsuarioBCB() {
		return this.esUsuarioBCB;
	}

	public void recuperarOperaciones(ActionEvent event) {
		this.msj = "";
		this.listaOperaciones = null;
		armarConsulta();
		this.listaOperaciones = getSirAladiDao().ejecutarQueryListas(this.queryDetalle);
		//getVisit().setParametro("OBJ_TMP_REGS", listaOperaciones);
		//getVisit().setParametro("OBJ_TMP_PERSONA", this.persona);
		//getVisit().setParametro("OBJ_TMP_FECHA", this.fecha);
		this.desabilitado = false;
		getVisit().setParametro("SIRWEB_TMP_OBJECT", this);		
	}

	public void armarConsulta() {
		String codPersona = null;
		if (this.esUsuarioBCB)
			codPersona = (StringUtils.isEmpty(this.persona.getCodPersona())) ? "%" : this.persona.getCodPersona();
		else
			codPersona = this.codPersonaUsuario;
		Calendar fechaAl = GregorianCalendar.getInstance();
		fechaAl.setTime(fecha);
		String strFecha = " mdy(" + (fechaAl.get(Calendar.MONTH) + 1) + "," + fechaAl.get(Calendar.DAY_OF_MONTH) + "," + fechaAl.get(Calendar.YEAR)
				+ ") ";

		StringBuffer from = new StringBuffer();
		from.append("FROM (SELECT TRIM(inst.nom_inst) nom_inst , TRIM(inst.nom_plaza) plaza, ");
		from.append("TRIM(a.cod_inst)||'-'||TRIM(a.cod_id)||'-'|| ");
		from.append("TRIM(a.anio)||'-'|| TRIM(a.secuencia)||'-'||a.dav cod_reembolso, ");
		from.append("TRIM(pais.nom_pais) convenio, ");
		from.append("a.fecha_emis, a.fecha_vto_pag, ");
		from.append("NVL((SELECT SUM(r.debe_mo - r.haber_mo) FROM registro r WHERE r.nro_mov_ape = a.nro_mov ");
		from.append("AND r.cve_estado_reg = 'C' AND r.fecha_trans <= " + strFecha + " ), 0) importe, ");
		from.append("NVL((SELECT SUM(p.haber_mo - p.debe_mo) FROM pago p     WHERE p.nro_mov_ape = a.nro_mov ");
		from.append("AND p.cve_estado_pago = 'C' AND p.cod_instrumento <> 'CG' ");
		from.append("AND p.fecha_cargo <= " + strFecha + " ), 0) monto_pagado, saldo_a_fecha(a.nro_mov, " + strFecha + ") saldo_a ");
		from.append("FROM apertura a, ");
		if (this.esExportacion)
			from.append("registro re, institucion ic, ");
		from.append("institucion inst, ");
		from.append("persona_inst pei, ");
		from.append("pais ");
		from.append("WHERE a.fecha_emis <= " + strFecha + " ");
		from.append("AND a.cve_tipo_ape = '" + this.tipoOperacion + "' ");
		if (this.esExportacion) {
			from.append("AND a.nro_mov = re.nro_mov_ape ");
			from.append("AND re.cve_tipo_emis = 'E' ");
			from.append("AND a.cod_inst = ic.cod_inst ");
			from.append("AND ic.cod_pais = pais.cod_pais ");
			from.append("AND re.cod_inst_recep = inst.cod_inst ");
		} else {
			from.append("AND a.cod_pais = pais.cod_pais ");
			from.append("AND a.cod_inst = inst.cod_inst ");
		}
		from.append("AND inst.cod_inst = pei.cod_inst ");
		from.append("AND pei.cod_persona LIKE '" + codPersona + "' ) t ");

		String where = "WHERE (saldo_a) <> 0 ";
		//String where = "WHERE (t.importe - t.monto_pagado) > 0 ";

		StringBuffer detalle = new StringBuffer();
		detalle.append("SELECT nom_inst, plaza, ");
		detalle.append("cod_reembolso, convenio, fecha_emis, fecha_vto_pag, ");
		detalle.append("importe, monto_pagado, saldo_a saldo ");
		detalle.append(from).append(where);
		detalle.append("ORDER BY 1, 2, 4, 3 ");
		this.queryDetalle = detalle.toString();

		StringBuffer resumen = new StringBuffer();
		resumen.append("SELECT nom_inst, plaza, SUM(importe) importe, ");
		resumen.append("SUM(monto_pagado) monto_pagado, saldo_a saldo ");
		resumen.append(from).append(where);
		resumen.append("GROUP BY nom_inst, plaza,saldo_a ");
		//resumen.append("HAVING saldo_a <> 0 ");
		resumen.append("ORDER BY 1, 2");
		this.queryResumen = resumen.toString();

		//log.info(queryDetalle);
		//log.info(queryResumen);

	}

	public void mostrarReporte(ActionEvent event) {
		armarConsulta();
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("QUERY_DETALLE", this.queryDetalle);
		parametros.put("QUERY_RESUMEN", this.queryResumen);
		parametros.put("TITULO",
				"ESTADO DE OPERACIONES DE " + this.descTipoOperacion.toUpperCase() + " AL " + dateToString(this.fecha, FORMATO_FECHA_JAVA));
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("pathTranslated", request.getPathTranslated());
		request.getSession().setAttribute("nombreReporte", "repEstadoOpe.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}

	public void limpiar(ActionEvent event) {
		getVisit().removeParametro("SIRWEB_TMP_OBJECT");
	}


	public static void main(String[] args) {
		Calendar fechaAl = GregorianCalendar.getInstance();
		String strFecha = " mdy(" + (fechaAl.get(Calendar.MONTH) + 1) + "," + fechaAl.get(Calendar.DAY_OF_MONTH) + "," + fechaAl.get(Calendar.YEAR)
				+ ") ";
		System.out.println(strFecha);
	}
}
