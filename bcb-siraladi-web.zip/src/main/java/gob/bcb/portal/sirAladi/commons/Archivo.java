/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * cb-web-sirAladi
 * gob.bcb.portal.sirAladi.commons.Archivo
 * 28/10/2011 - 13:36:19
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.commons;

import static gob.bcb.portal.sirAladi.commons.Constantes.DIRECTORIO_ADJUNTOS;
import gob.bcb.core.utils.ArchivoUtil;
import gob.bcb.portal.sirAladi.dao.DaoFactory;

import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.log4j.Logger;

/**
 * Clase java que contiene los datos de un archivo.
 * 
 * @author wherrera
 * 
 */
public class Archivo {
	private static Logger log = Logger.getLogger(Archivo.class);
	private String nombre;
	private String path;
	private String mime;
	private String extension;
	private int length;
	private byte[] data;

	public String getNombre() {
		return nombre;
	}

	public String setNombre(String nombre) {
		return this.nombre = nombre;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getMime() {
		return mime;
	}

	public void setMime(String mime) {
		this.mime = mime;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		this.data = data;
	}

	/**
	 * M�todo que asigna el path, nombre, extensi�n y mime al archivo.
	 * 
	 * @param nombre
	 * @param codReembolso
	 */
	public void setNombreMimeExtension(String archUpload, String codReembolso) {
		// this.path = DIRECTORIO_ADJUNTOS + codReembolso + "-" + nombre.trim();
		this.nombre = getNombreArchivo(archUpload);
		int extDot = nombre.lastIndexOf('.');
		if (extDot > 0) {
			this.extension = nombre.substring(extDot + 1).toLowerCase();
			try {
				this.mime = ArchivoUtil.obtenerMime(nombre);
			} catch (NullPointerException e) {
				this.mime = null;
			}
		} else {
			mime = "application/x-binary";
		}
	}

	/**
	 * M�todo que obtiene el nombre del archivo, excluyendo el path.
	 * 
	 * @return
	 */
	public String getNombreArchivo(String nombre) {
		int pos = nombre.lastIndexOf("\\");
		if (pos == -1)
			pos = nombre.lastIndexOf("/");
		return nombre.substring(1 + pos).replace(' ', '_');
	}

	/**
	 * M�todo que guarda un archivo en directorio y su path en Base de Datos,
	 * asociado a un movimiento.
	 * 
	 * @param nroMov
	 * @param tipoMov
	 */
	public void guardarAdjunto(int nroMov, String tipoMov) {
		String nroMovLit = String.format("%08d", nroMov);
		this.path = DIRECTORIO_ADJUNTOS + tipoMov + nroMovLit + "-" + nombre;
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(this.path);
			fos.write(this.data);
			fos.flush();
			fos.close();
			String sqlQuery = "DELETE FROM adjunto WHERE nro_mov = " + nroMov;
			DaoFactory.getInstance().getSirAladiDao().ejecutarDml(sqlQuery);
			log.info("Insertando adjunto en guardarAdjunto " + sqlQuery);
			String insert = "INSERT INTO adjunto(nro_mov,cve_tipo_mov,ruta_archivo,cve_tipo_mime) " + "VALUES('" + nroMov + "','" + tipoMov + "','"
					+ this.path + "','" + this.extension + "')";
			DaoFactory.getInstance().getSirAladiDao().ejecutarDml(insert);
			this.data = null;
		} catch (IOException e) {
			log.error("No se pudo guardar el archivo " + this.path, e);
			throw new RuntimeException(e);
		} catch (Exception e) {
			log.error("Error al guardar el archivo " + this.path, e);
			e.printStackTrace();
			throw new RuntimeException(e);
		} finally {
			if (fos != null) {
				try {
					fos.close();
				} catch (IOException e) {
				}
			}
		}
	}
}
