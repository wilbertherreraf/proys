package gob.bcb.portal.sirAladi.reportes.controller;

import static gob.bcb.portal.sirAladi.commons.AladiUtils.dateToString;
import static gob.bcb.portal.sirAladi.commons.Constantes.FORMATO_FECHA_JAVA;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.portal.sirAladi.commons.AladiUtils;
import gob.bcb.portal.sirAladi.commons.Constantes;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

public class ReportesGenericos extends BaseBeanController {
	private static Logger log = Logger.getLogger(ReportesGenericos.class);
	public static final int MAX_DIAS_REPORTE_EXTRACTO = 365;	
	private Date fechaDesde;
	private Date fechaAl;

	private Date fecha1;
	private Date fecha2;
	private Date fecha3;
	private Date fecha4;
	private Date fecha5;

	@PostConstruct
	public void init() {
		log.info("Iniciando el modulo de consulta de reportes genericos.");
		recuperarVisit();
		crearObjetosPorDefecto();
		if (getVisit().getParametro("SIRWEB_TMP_OBJECT") != null) {
			if (!(getVisit().getParametro("SIRWEB_TMP_OBJECT") instanceof ReportesGenericos)) {
			} else {
				ReportesGenericos objeto = (ReportesGenericos) getVisit().getParametro("SIRWEB_TMP_OBJECT");
				fechaDesde = objeto.getFechaDesde();
				fechaAl = objeto.getFechaAl();
				if (objeto.getFecha1() != null)
					fecha1 = objeto.getFecha1();
				if (objeto.getFecha2() != null)
					fecha2 = objeto.getFecha2();
				if (objeto.getFecha3() != null)
					fecha3 = objeto.getFecha3();
				if (objeto.getFecha4() != null)
					fecha4 = objeto.getFecha4();
				if (objeto.getFecha5() != null)
					fecha5 = objeto.getFecha5();
			}
		}
	}

	public void clasifProds(String tipo) {
		String strFechaDesde = dateToString(this.fechaDesde, FORMATO_FECHA_JAVA);
		this.fechaAl = getFechaFin(this.fechaAl);
		String strFechaAl = dateToString(this.fechaAl, FORMATO_FECHA_JAVA);
		log.info("REPORTE POR CLASIFICACION DE PRODUCTOS INSTRUMENTOS EMITIDOS ENTRE " + strFechaDesde + " AL " + strFechaAl);
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("FECHA_DESDE", this.fechaDesde);
		parametros.put("FECHA_HASTA", this.fechaAl);
		parametros.put("CUADRO", "C01");		
		parametros.put("TITULO", "INSTRUMENTOS EMITIDOS\nENTRE " + strFechaDesde + " AL " + strFechaAl + "\nCLASIFICADOS POR PRODUCTO");
		parametros.put(Constantes.PARAM_TIPO_REPORTE, tipo);		

		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("nombreReporte", "repClasificacionProds.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}

	public void saldosMultilaterales(ActionEvent event) {
		String strFechaDesde = dateToString(this.fechaDesde, FORMATO_FECHA_JAVA);
		String strFechaAl = dateToString(this.fechaAl, FORMATO_FECHA_JAVA);
		log.info("REPORTE ENTRE " + strFechaDesde + " AL " + strFechaAl);
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("fechaDesde", this.fechaDesde);
		parametros.put("fechaHasta", this.fechaAl);
		parametros.put("TITULO",
				"Posición Global de operaciones de comercio y compensaci򬟦inal de Bolivia con el resto de los paises miembros de ALADI ENTRE "
						+ strFechaDesde + " AL " + strFechaAl);

		if ((getVisit().getParametro().containsKey("SIRWEB_TMP_TIPOREP")))
			parametros.put(Constantes.PARAM_TIPO_REPORTE, getVisit().getParametro("SIRWEB_TMP_TIPOREP"));

		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("nombreReporte", "REPSALDOMULTILATERAL");
		request.getSession().setAttribute("parametros", parametros);
	}

	public void emisionesPorMes(String tipo) {
		String strFechaDesde = dateToString(this.fechaDesde, FORMATO_FECHA_JAVA);
		this.fechaAl = getFechaFin(this.fechaAl);
		String strFechaAl = dateToString(this.fechaAl, FORMATO_FECHA_JAVA);
		log.info("REPORTE ENTRE " + strFechaDesde + " AL " + strFechaAl);
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("FECHA_DESDE", this.fechaDesde);
		parametros.put("FECHA_HASTA", this.fechaAl);
		parametros.put("CUADRO", "C02");		
		parametros.put("TITULO", "EMISIONES DE INSTRUMENTOS\nDEL " + strFechaDesde + " AL " + strFechaAl + "\nCLASIFICADOS POR INSTITUCION AUTORIZADA");
		parametros.put(Constantes.PARAM_TIPO_REPORTE, tipo);

		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("parametros", parametros);
		request.getSession().setAttribute("nombreReporte", "repEmisMes.jasper");
	}

	public void emisionesPorMesPorConvenio(String tipo) {
		String strFechaDesde = dateToString(this.fechaDesde, FORMATO_FECHA_JAVA);
		this.fechaAl = getFechaFin(this.fechaAl);
		String strFechaAl = dateToString(this.fechaAl, FORMATO_FECHA_JAVA);
		log.info("REPORTE ENTRE " + strFechaDesde + " AL " + strFechaAl);
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("FECHA_DESDE", this.fechaDesde);
		parametros.put("FECHA_HASTA", this.fechaAl);
		parametros.put("CUADRO", "C03");		
		parametros.put("TITULO", "EMISIONES DE INSTRUMENTOS\nDEL " + strFechaDesde + " AL " + strFechaAl + "\nCLASIFICADOS POR CONVENIO");
		parametros.put(Constantes.PARAM_TIPO_REPORTE, tipo);

		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("nombreReporte", "repEmisMesConvenio.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}

	public void nroEmisPorMesPorIFA(String tipo) {
		log.info("======================================REPORTE ENTRE " + this.fechaAl);		
		String strFechaDesde = dateToString(this.fechaDesde, FORMATO_FECHA_JAVA);
		this.fechaAl = getFechaFin(this.fechaAl);
		String strFechaAl = dateToString(this.fechaAl, FORMATO_FECHA_JAVA);
		log.info("REPORTE ENTRE " + strFechaDesde + " AL " + strFechaAl);
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("FECHA_DESDE", this.fechaDesde);
		parametros.put("FECHA_HASTA", this.fechaAl);
		parametros.put("CUADRO", "C04");		
		parametros.put("TITULO", "NUMERO DE EMISIONES DE INSTRUMENTOS\nDEL " + strFechaDesde + " AL " + strFechaAl + "\nCLASIFICADOS POR INSTITUCION");
		parametros.put(Constantes.PARAM_TIPO_REPORTE, tipo);

		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("nombreReporte", "repNroEmisMes.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}

	public void nroEmisPorMesPorConv(String tipo) {
		String strFechaDesde = dateToString(this.fechaDesde, FORMATO_FECHA_JAVA);
		this.fechaAl = getFechaFin(this.fechaAl);
		String strFechaAl = dateToString(this.fechaAl, FORMATO_FECHA_JAVA);
		log.info("REPORTE ENTRE " + strFechaDesde + " AL " + strFechaAl);
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("FECHA_DESDE", this.fechaDesde);
		parametros.put("FECHA_HASTA", this.fechaAl);
		parametros.put("CUADRO", "C05");		
		parametros.put("TITULO", "NUMERO DE EMISIONES DE INSTRUMENTOS\nDEL " + strFechaDesde + " AL " + strFechaAl + "\nCLASIFICADOS POR CONVENIO");
		parametros.put(Constantes.PARAM_TIPO_REPORTE, tipo);

		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("nombreReporte", "repNroEmisMesConvenio.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}

	public void pagosPorMesPorIFA(String tipo) {
		String strFechaDesde = dateToString(this.fechaDesde, FORMATO_FECHA_JAVA);
		String strFechaAl = dateToString(this.fechaAl, FORMATO_FECHA_JAVA);
		log.info("REPORTE ENTRE " + strFechaDesde + " AL " + strFechaAl);
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("FECHA_DESDE", this.fechaDesde);
		parametros.put("FECHA_HASTA", this.fechaAl);
		parametros.put("CUADRO", "C06");		
		parametros.put("TITULO", "OPERACIONES ALADI\nDEL " + strFechaDesde + " AL " + strFechaAl + "\nCLASIFICADOS POR INSTITUCION");
		parametros.put(Constantes.PARAM_TIPO_REPORTE, tipo);

		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("nombreReporte", "repPagosMes.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}

	public void pagosPorMesPorConv(String tipo) {
		String strFechaDesde = dateToString(this.fechaDesde, FORMATO_FECHA_JAVA);
		this.fechaAl = getFechaFin(this.fechaAl);
		String strFechaAl = dateToString(this.fechaAl, FORMATO_FECHA_JAVA);
		log.info("REPORTE ENTRE " + strFechaDesde + " AL " + strFechaAl);
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("FECHA_DESDE", this.fechaDesde);
		parametros.put("FECHA_HASTA", this.fechaAl);
		parametros.put("CUADRO", "C07");		
		parametros.put("TITULO", "OPERACIONES ALADI\nDEL " + strFechaDesde + " AL " + strFechaAl + "\nCLASIFICADOS POR CONVENIO");
		parametros.put(Constantes.PARAM_TIPO_REPORTE, tipo);
		
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("nombreReporte", "repPagosMesConvenio.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}

	public void pagosAnticipadosEfectuadosPorConv(String tipo) {
		String strFechaDesde = dateToString(this.fechaDesde, FORMATO_FECHA_JAVA);
		this.fechaAl = getFechaFin(this.fechaAl);
		String strFechaAl = dateToString(this.fechaAl, FORMATO_FECHA_JAVA);
		log.info("REPORTE ENTRE " + strFechaDesde + " AL " + strFechaAl);
		Map<String, Object> parametros = new HashMap<String, Object>();
		
		parametros.put("FECHA_DESDE", this.fechaDesde);
		parametros.put("FECHA_HASTA", this.fechaAl);
		parametros.put("CUADRO", "C08");		
		parametros.put("TITULO", "PAGOS ANTICIPADOS EFECTUADOS POR CONVENIO\nDEL " + strFechaDesde + " AL " + strFechaAl);
		parametros.put(Constantes.PARAM_TIPO_REPORTE, tipo);
		
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("nombreReporte", "repPagosAnticipados.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}	
	public void operacionesCPCRAladi(String tipo) {
		log.info("##############################");
		
		String strFechaDesde = dateToString(this.fechaDesde, FORMATO_FECHA_JAVA);
		this.fechaAl = getFechaFin(this.fechaAl);
		String strFechaAl = dateToString(this.fechaAl, FORMATO_FECHA_JAVA);
		log.info("REPORTE ENTRE " + strFechaDesde + " AL " + strFechaAl);
		Map<String, Object> parametros = new HashMap<String, Object>();
		
		parametros.put("FECHA_DESDE", this.fechaDesde);
		parametros.put("FECHA_HASTA", this.fechaAl);
		parametros.put("CUADRO", "C09");		
		parametros.put("TITULO", "CPCR - ALADI");
		parametros.put("TITOPERACIONES", "PERIODO DEL " + strFechaDesde + " AL " + strFechaAl);
		parametros.put(Constantes.PARAM_TIPO_REPORTE, tipo);
		
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("nombreReporte", "repCPCR.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}	
	public void gastosPorMesPorIFA(String tipo) {
		String strFechaDesde = dateToString(this.fechaDesde, FORMATO_FECHA_JAVA);
		this.fechaAl = getFechaFin(this.fechaAl);
		String strFechaAl = dateToString(this.fechaAl, FORMATO_FECHA_JAVA);
		log.info("REPORTE ENTRE " + strFechaDesde + " AL " + strFechaAl);
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("FECHA_DESDE", this.fechaDesde);
		parametros.put("FECHA_HASTA", this.fechaAl);
		parametros.put("TITULO", "Periodo " + strFechaDesde + " AL " + strFechaAl);
		parametros.put(Constantes.PARAM_TIPO_REPORTE, tipo);

		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("nombreReporte", "repGastosMes.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}

	public void gastosPorMesPorConv(String tipo) {
		String strFechaDesde = dateToString(this.fechaDesde, FORMATO_FECHA_JAVA);
		this.fechaAl = getFechaFin(this.fechaAl);
		String strFechaAl = dateToString(this.fechaAl, FORMATO_FECHA_JAVA);
		log.info("REPORTE ENTRE " + strFechaDesde + " AL " + strFechaAl);
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("FECHA_DESDE", this.fechaDesde);
		parametros.put("FECHA_HASTA", this.fechaAl);
		parametros.put("TITULO", "Periodo " + strFechaDesde + " AL " + strFechaAl);
		parametros.put(Constantes.PARAM_TIPO_REPORTE, tipo);

		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("nombreReporte", "repGastosMesConvenio.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}

	public void pagosAEfectPorIFA(String tipo) {
		String strFechaDesde = dateToString(this.fechaDesde, FORMATO_FECHA_JAVA);
		this.fechaAl = getFechaFin(this.fechaAl);
		String strFechaAl = dateToString(this.fechaAl, FORMATO_FECHA_JAVA);
		log.info("REPORTE ENTRE " + strFechaDesde + " AL " + strFechaAl);
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("FECHA_DESDE", this.fechaDesde);
		parametros.put("FECHA_HASTA", this.fechaAl);
		parametros.put("CUADRO", "C08");		
		parametros.put("TITULO", "OPERACIONES ALADI\nDEL " + strFechaDesde + " AL " + strFechaAl + "\nCLASIFICADOS POR CONVENIO");
		parametros.put(Constantes.PARAM_TIPO_REPORTE, tipo);

		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("nombreReporte", "repPagosEfect.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}

	public void pagosAEfectPorConv(String tipo) {
		String strFechaDesde = dateToString(this.fechaDesde, FORMATO_FECHA_JAVA);
		this.fechaAl = getFechaFin(this.fechaAl);
		String strFechaAl = dateToString(this.fechaAl, FORMATO_FECHA_JAVA);
		log.info("REPORTE ENTRE " + strFechaDesde + " AL " + strFechaAl);
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("FECHA_DESDE", this.fechaDesde);
		parametros.put("FECHA_HASTA", this.fechaAl);
		parametros.put("TITULO", "Periodo " + strFechaDesde + " AL " + strFechaAl);
		parametros.put(Constantes.PARAM_TIPO_REPORTE, tipo);

		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("nombreReporte", "repPagosEfectMesconvenio.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}

	public void endeudamientoPorConvenio(String tipo) {
		String strFechaDesde = dateToString(this.fechaDesde, FORMATO_FECHA_JAVA);
		String strFechaAl = dateToString(this.fechaAl, FORMATO_FECHA_JAVA);
		log.info("REPORTE ENTRE " + strFechaDesde + " AL " + strFechaAl);
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put(Constantes.PARAM_TIPO_REPORTE, tipo);

		if (fecha1 != null)
			parametros.put("FECHA1", this.fecha1);
		if (fecha2 != null)
			parametros.put("FECHA2", this.fecha2);
		if (fecha3 != null)
			parametros.put("FECHA3", this.fecha3);
		if (fecha4 != null)
			parametros.put("FECHA4", this.fecha4);
		if (fecha5 != null)
			parametros.put("FECHA5", this.fecha5);

		parametros.put("TITULO", "ENDEUDAMIENTO CON LOS PAISES ALADI");

		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("nombreReporte", "repEndeudaporConv.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}

	public void evolucionOpersBol(String tipo) {
		String strFechaDesde = dateToString(this.fechaDesde, FORMATO_FECHA_JAVA);
		this.fechaAl = getFechaFin(this.fechaAl);
		String strFechaAl = dateToString(this.fechaAl, FORMATO_FECHA_JAVA);
		log.info("REPORTE ENTRE " + strFechaDesde + " AL " + strFechaAl);
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("FECHA_DESDE", this.fechaDesde);
		parametros.put("FECHA_HASTA", this.fechaAl);
		parametros.put("TITULO", "Evolución de las operaciones de Bolivia \nentre " + strFechaDesde + " AL " + strFechaAl);
		parametros.put(Constantes.PARAM_TIPO_REPORTE, tipo);

		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("nombreReporte", "repEvolucionBol.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}	
	public void operacionesRealizadas(String tipo) {
		String strFechaDesde = dateToString(this.fechaDesde, FORMATO_FECHA_JAVA);
		this.fechaAl = getFechaFin(this.fechaAl);
		String strFechaAl = dateToString(this.fechaAl, FORMATO_FECHA_JAVA);
		log.info("REPORTE ENTRE " + strFechaDesde + " AL " + strFechaAl);
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("FECHA_DESDE", this.fechaDesde);
		parametros.put("FECHA_HASTA", this.fechaAl);
		parametros.put("TITULO", "OPERACIONES REALIZADAS \nentre " + strFechaDesde + " AL " + strFechaAl);
		parametros.put(Constantes.PARAM_TIPO_REPORTE, tipo);

		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("nombreReporte", "repBaseImpExpXls.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}	
	private void crearObjetosPorDefecto() {
		Date fecha = getSirAladiDao().getFechaActual();
		fechaDesde = AladiUtils.getInicioCuatrimestre(fecha);
		fechaAl = fecha;
		fecha1 = fechaDesde;

	}

	private Date getFechaFin(Date fechaHasta){
		Date d1 = UtilsDate.addTime(fechaHasta,(MAX_DIAS_REPORTE_EXTRACTO-1) * (-1), 5);
		
		int compara = UtilsDate.compara(d1, fechaDesde);
		if (compara > 0){
			// intervalo entre fechas mayor al permitido
			fechaHasta = UtilsDate.addTime(fechaDesde,(MAX_DIAS_REPORTE_EXTRACTO-1), 5);
		}
		return fechaHasta;
	}
	public void setFechaDesde(Date fechaDesde) {
		this.fechaDesde = fechaDesde;
	}

	public Date getFechaDesde() {
		return fechaDesde;
	}

	public void setFechaAl(Date fechaAl) {
		this.fechaAl = fechaAl;
	}

	public Date getFechaAl() {
		return fechaAl;
	}

	public void setFecha1(Date fecha1) {
		this.fecha1 = fecha1;
	}

	public Date getFecha1() {
		return fecha1;
	}

	public void setFecha2(Date fecha2) {
		this.fecha2 = fecha2;
	}

	public Date getFecha2() {
		return fecha2;
	}

	public void setFecha3(Date fecha3) {
		this.fecha3 = fecha3;
	}

	public Date getFecha3() {
		return fecha3;
	}

	public void setFecha4(Date fecha4) {
		this.fecha4 = fecha4;
	}

	public Date getFecha4() {
		return fecha4;
	}

	public void setFecha5(Date fecha5) {
		this.fecha5 = fecha5;
	}

	public Date getFecha5() {
		return fecha5;
	}

}
