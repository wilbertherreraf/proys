package gob.bcb.portal.sirAladi.view;

import gob.bcb.bpm.siraladi.jpa.Patrimonio;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;

public class DetPatrimonioViewBean extends BaseBeanController {
	private static Logger log = Logger.getLogger(DetPatrimonioViewBean.class);
	private Patrimonio patrimonio; 
	public DetPatrimonioViewBean() {
	}
	@PostConstruct
	public void init() {
		log.info("Iniciando el modulo de Detalla patrimonio.");
		recuperarVisit();
		if (getVisit().getParametro("SIRWEB_TMP_APERTURAS") != null) {
			if (!(getVisit().getParametro("SIRWEB_TMP_OBJECT") instanceof DetPatrimonioViewBean)) {
			} else {
				DetPatrimonioViewBean objetoTMP = (DetPatrimonioViewBean) getVisit().getParametro("SIRWEB_TMP_OBJECT");
				patrimonio = objetoTMP.getPatrimonio();
			}
		}
	}
	public void recuperaDatos(){
		
	}
	public void setPatrimonio(Patrimonio patrimonio) {
		this.patrimonio = patrimonio;
	}
	public Patrimonio getPatrimonio() {
		return patrimonio;
	}
}
