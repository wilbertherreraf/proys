/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-sirAladi
 * gob.bcb.portal.sirAladi.operacionesBCB.controller.PagosAladiController
 * 17/08/2011 - 10:24:07
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.operacionesBCB.controller;

import static gob.bcb.portal.sirAladi.commons.AladiUtils.getAlertJS;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTILO_INVISIBLE;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTILO_VISIBLE;
import static gob.bcb.portal.sirAladi.commons.Constantes.SUCCESS;
import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.Identificador;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Pago;
import gob.bcb.bpm.siraladi.jpa.Pais;
import gob.bcb.bpm.siraladi.jpa.Registro;
import gob.bcb.bpm.siraladi.jpa.TPagoImp;
import gob.bcb.bpm.siraladi.pojo.StatusResponse;
import gob.bcb.portal.sirAladi.commons.Servicios;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;
import gob.bcb.portal.sirAladi.dao.DaoFactory;
import gob.bcb.portal.sirAladi.dao.SirAladiDao;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.event.ActionEvent;

import org.apache.log4j.Logger;

/**
 * Backin Bean de la vista de autorizaci�n de pagos aladi.
 * 
 * @author wherrera
 * 
 */

public class PagosAladiController extends BaseBeanController {
	private Date fechaDesde;
	private Date fechaHasta;
	private String msj;
	private boolean chkSelectAll;
	private boolean desabilitado;

	private Apertura apertura;

	private SirAladiDao sirAladiDao;
	private List<TPagoImp> pagosAladi;
	private List<Pago> pagos;
	private List<Registro> registros;
	private List<Pago> debitos;

	private static Logger log = Logger.getLogger(PagosAladiController.class);

	public PagosAladiController() {
	}

	@PostConstruct
	public void init() {
		log.info("Iniciando el modulo de autorizacion de pagos - importaciones.");
		recuperarVisit();
		this.sirAladiDao = DaoFactory.getInstance().getSirAladiDao();
		this.crearObjetosPorDefecto();

	}

	public Date getFechaDesde() {
		return fechaDesde;
	}

	public void setFechaDesde(Date fechaDesde) {
		this.fechaDesde = fechaDesde;
	}

	public Date getFechaHasta() {
		return fechaHasta;
	}

	public void setFechaHasta(Date fechaHasta) {
		this.fechaHasta = fechaHasta;
	}

	public List<TPagoImp> getPagosAladi() {
		return pagosAladi;
	}

	public void setPagosAladi(List<TPagoImp> pagosAladi) {
		this.pagosAladi = pagosAladi;
	}

	public List<Pago> getPagos() {
		return pagos;
	}

	public void setPagos(List<Pago> pagos) {
		this.pagos = pagos;
	}

	public Apertura getApertura() {
		return apertura;
	}

	public void setApertura(Apertura apertura) {
		this.apertura = apertura;
	}

	public List<Registro> getRegistros() {
		return registros;
	}

	public void setRegistros(List<Registro> registros) {
		this.registros = registros;
	}

	public List<Pago> getDebitos() {
		return debitos;
	}

	public void setDebitos(List<Pago> debitos) {
		this.debitos = debitos;
	}

	public boolean getChkSelectAll() {
		return chkSelectAll;
	}

	public void setChkSelectAll(boolean chkSelectAll) {
		this.chkSelectAll = chkSelectAll;
	}

	public boolean isHabilitado() {
		return !desabilitado;
	}

	public String getMsj() {
		return msj;
	}

	public void setMsj(String msj) {
		this.msj = msj;
	}

	public String getEstiloBuscar() {
		return this.desabilitado ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	public String getEstiloLimpiar() {
		return this.desabilitado ? ESTILO_INVISIBLE : ESTILO_VISIBLE;
	}

	public String getEstiloVerPagos() {
		return (this.pagos != null && this.pagos.size() > 0) ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	public String getEstiloPaginacionPagosAladi() {
		return (this.pagosAladi != null && this.pagosAladi.size() > 10) ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	public String getEstiloPaginacionPagos() {
		return (this.pagos != null && this.pagos.size() > 10) ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	@SuppressWarnings("unchecked")
	public void recuperarPagos(ActionEvent event) {
		this.msj = "";
		if (!this.fechaHasta.before(this.fechaDesde)) {
			StatusResponse statusResponse = Servicios.getPagosAladi(this.fechaDesde, this.fechaHasta);
			if (SUCCESS.equals(statusResponse.getStatusCode())) {
				this.pagosAladi = (List<TPagoImp>) statusResponse.getContenido().get("pagosAladi");
				this.desabilitado = false;
			} else
				this.msj = getAlertJS(statusResponse);
		} else
			this.msj = getAlertJS("La fecha 'Hasta' no puede ser inferior que la fecha 'Desde'.");
	}

	public void selectAll(ActionEvent event) {
		this.msj = "";
		for (TPagoImp pago : this.pagosAladi)
			pago.setSeleccionado(this.chkSelectAll);
	}

	public void clickCheck(ActionEvent event) {
		this.msj = "";
		this.chkSelectAll = true;
		for (TPagoImp pago : this.pagosAladi) {
			if (!pago.isSeleccionado()) {
				this.chkSelectAll = false;
				break;
			}
		}
	}

	@SuppressWarnings("unchecked")
	public void aceptarPagos(ActionEvent event) {
		this.msj = "";
		this.pagos = null;
		int nroPagosAladiSeleccionados = 0;
		for (TPagoImp pago : this.pagosAladi)
			if (pago.isSeleccionado())
				nroPagosAladiSeleccionados++;
		if (nroPagosAladiSeleccionados == 0)
			this.msj = getAlertJS("Debe seleccionar al menos un pago.");
		else {
			StatusResponse statusResponse = Servicios.guardarPagosAladi(this.pagosAladi);
			if (SUCCESS.equals(statusResponse.getStatusCode())) {
				this.pagos = (List<Pago>) statusResponse.getContenido().get("pagos");
				List<String> codigosInstituciones = new ArrayList<String>();
				for (Pago itemPago : this.pagos)
					codigosInstituciones.add(itemPago.getInstitucion().getCodInst());
				if (codigosInstituciones.size() > 0) {
					List<Institucion> listaInstituciones = this.sirAladiDao.getInstituciones(codigosInstituciones);
					Map<String, Institucion> mapInstituciones = new HashMap<String, Institucion>();
					for (Institucion i : listaInstituciones)
						mapInstituciones.put(i.getCodInst(), i);
					for (Pago itemPago : this.pagos)
						itemPago.setInstitucion(mapInstituciones.get(itemPago.getInstitucion().getCodInst()));
				}
			}
			this.msj = getAlertJS(statusResponse);
		}
	}

	public void limpiar(ActionEvent event) {
		this.msj = "";
		this.fechaDesde = null;
		this.fechaHasta = null;
		this.crearObjetosPorDefecto();
	}

	private void crearObjetosPorDefecto() {
		this.desabilitado = true;
		this.pagosAladi = null;
		this.pagos = null;
		this.msj = null;

		// Apertura
		this.apertura = new Apertura();
		this.apertura.setIdentificador(new Identificador());
		this.apertura.setInstitucion(new Institucion());
		this.apertura.setPais(new Pais());

		// Registros
		this.registros = new ArrayList<Registro>();

		// Debitos
		this.debitos = new ArrayList<Pago>();
	}

}
