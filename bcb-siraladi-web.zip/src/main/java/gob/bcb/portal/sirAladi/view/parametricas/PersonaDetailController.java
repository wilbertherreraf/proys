package gob.bcb.portal.sirAladi.view.parametricas;

import gob.bcb.bpm.siraladi.jpa.Persona;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class PersonaDetailController  extends BaseBeanController {
	private static final Log log = LogFactory.getLog(PersonaDetailController.class);
	private Persona personaSelected = new Persona();
	
}
