package gob.bcb.portal.sirAladi.commons;

import gob.bcb.portal.sirAladi.controller.BaseBeanController;

import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;

/**
 * Managed Bean utilizado para liberar los objetos almacenados en la HttpSession
 */

public class Liberar extends BaseBeanController{

	private static Logger log = Logger.getLogger(Liberar.class);

    private FacesContext fc = FacesContext.getCurrentInstance();
    /** Constructor */
    public Liberar() {
    }

    /**
     * ActionListener que elimina los objetos temporales de la session.
     */
    public void limpiarSession(){
        SessionUtil.removerTemporales(fc);
/*        for (Iterator<?> i = getVisit().getParametro().keySet().iterator(); i.hasNext();) {
			String key = (String) i.next();
			if (key.startsWith("SIRWEB_TMP")) {
				getVisit().removeParametro(key);
			}
        }*/
    }

} 
