/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-sirAladi
 * gob.bcb.portal.sirAladi.operacionesBCB.controller.PagosAnticipadosExpController
 * 27/09/2011 - 10:54:47
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.operacionesBCB.controller;

import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarMapDescripcionClaves;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarSelectItemsInstrumentos;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarSelectItemsPaises;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.getAlertJS;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.getCierreModalPanelJS;
import static gob.bcb.portal.sirAladi.commons.Constantes.CODIGO_ID_PAGO_ANTICIPADO;
import static gob.bcb.portal.sirAladi.commons.Constantes.CODIGO_INSTITUCION_BCB;
import static gob.bcb.portal.sirAladi.commons.Constantes.CODIGO_INSTRUMENTO_PAGO_ANTICIPADO;
import static gob.bcb.portal.sirAladi.commons.Constantes.CODIGO_MONEDA_DOLARES;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_ESTADO_PAGO_ANT;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTADO_CONTABILIZADO;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTADO_PENDIENTE;
import static gob.bcb.portal.sirAladi.commons.Constantes.SUCCESS;
import static gob.bcb.portal.sirAladi.commons.Constantes.TIPO_APERTURA_EXPORTACION;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Instrumento;
import gob.bcb.bpm.siraladi.jpa.Pais;
import gob.bcb.bpm.siraladi.jpa.RegAnticipado;
import gob.bcb.bpm.siraladi.pojo.StatusResponse;
import gob.bcb.bpm.siraladi.utils.NumeroDAV;
import gob.bcb.portal.sirAladi.commons.Servicios;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;
import gob.bcb.portal.sirAladi.dao.DaoFactory;
import gob.bcb.portal.sirAladi.dao.SirAladiDao;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

/**
 * Backin Bean de la vista de pagos anticipados.
 * 
 * @author wherrera
 * 
 */

public class PagosAnticipadosExpController extends BaseBeanController {
	private String msj;
	private String codPais;
	private String filtroCodReembolso;
	private boolean mostrarModal;

	private RegAnticipado pagoAnticipado;
	private SirAladiDao sirAladiDao;
	private List<RegAnticipado> pagosAnticipados;
	private List<SelectItem> itemsInstrumentos;
	private List<SelectItem> itemsPaises;
	private Map<String, String> mapPaisesBancos;
	private Map<String, String> mapEstado;

	private static Logger log = Logger.getLogger(PagosAnticipadosExpController.class);

	public PagosAnticipadosExpController() {
	}

	@PostConstruct
	public void init() {
		log.info("Iniciando el modulo de pagos anticipados - exportaciones.");
		recuperarVisit();
		this.sirAladiDao = DaoFactory.getInstance().getSirAladiDao();
		this.crearObjetosPorDefecto();
		this.pagosAnticipados = this.sirAladiDao.getPagosAnticipados(TIPO_APERTURA_EXPORTACION, ESTADO_PENDIENTE);
		this.mostrarModal = (this.pagosAnticipados != null && this.pagosAnticipados.size() > 0);

	}

	public String getMsj() {
		return msj;
	}

	public void setMsj(String msj) {
		this.msj = msj;
	}

	public boolean isMostrarModal() {
		return mostrarModal;
	}

	public String getCodPais() {
		return codPais;
	}

	public void setCodPais(String codPais) {
		this.codPais = codPais;
	}

	public String getFiltroCodReembolso() {
		return filtroCodReembolso;
	}

	public void setFiltroCodReembolso(String filtroCodReembolso) {
		this.filtroCodReembolso = filtroCodReembolso;
	}

	public RegAnticipado getPagoAnticipado() {
		return pagoAnticipado;
	}

	public void setPagoAnticipado(RegAnticipado pagoAnticipado) {
		this.pagoAnticipado = pagoAnticipado;
	}

	public List<RegAnticipado> getPagosAnticipados() {
		return pagosAnticipados;
	}

	public void setPagosAnticipados(List<RegAnticipado> pagosAnticipados) {
		this.pagosAnticipados = pagosAnticipados;
	}

	public List<SelectItem> getItemsInstrumentos() {
		return itemsInstrumentos;
	}

	public void setItemsInstrumentos(List<SelectItem> itemsInstrumentos) {
		this.itemsInstrumentos = itemsInstrumentos;
	}

	public List<SelectItem> getItemsPaises() {
		return itemsPaises;
	}

	public void setItemsPaises(List<SelectItem> itemsPaises) {
		this.itemsPaises = itemsPaises;
	}

	public Map<String, String> getMapPaisesBancos() {
		return mapPaisesBancos;
	}

	public void setMapPaisesBancos(Map<String, String> mapPaisesBancos) {
		this.mapPaisesBancos = mapPaisesBancos;
	}

	public Map<String, String> getMapEstado() {
		return mapEstado;
	}

	public void setMapEstado(Map<String, String> mapEstado) {
		this.mapEstado = mapEstado;
	}

	public void seleccionarPais(ActionEvent event) {
		Institucion institucion = this.sirAladiDao.getBancoCentralPorPais(this.codPais);
		this.pagoAnticipado.setCodInst(institucion.getCodInst());
	}

	public void procesarPagoAnticipado(ActionEvent event) {
		this.msj = "";
		String idBtn = event.getComponent().getId();
		if (idBtn.equals("btnGuardar") || idBtn.equals("btnModificar"))
			this.guardarPagoAnticipado();
		else if (idBtn.equals("btnAutorizar"))
			this.autorizarPagoAnticipado();
		else if (idBtn.equals("btnEliminar"))
			this.eliminarPagoAnticipado();
	}

	private void guardarPagoAnticipado() {
		StatusResponse statusResponse = null;
		if (!this.pagoAnticipado.getCodInstrumento().equals(CODIGO_INSTRUMENTO_PAGO_ANTICIPADO)) {
			this.pagoAnticipado.setDebeMo(new BigDecimal(this.pagoAnticipado.getHaberMo().toString()));
			this.pagoAnticipado.setHaberMo(BigDecimal.ZERO);
		}

		if (this.pagoAnticipado.getNroMov() != null && this.pagoAnticipado.getNroMov() > 0)
			statusResponse = Servicios.modificarPagoAnticipado(this.pagoAnticipado);
		else
			statusResponse = Servicios.registrarPagoAnticipado(this.pagoAnticipado);

		this.pagoAnticipado = this.sirAladiDao.getPagoAnticipado(this.pagoAnticipado);
		this.pagoAnticipado.setCodInstrumento(this.pagoAnticipado.getCodInstrumento().substring(0, 3));
		if (!this.pagoAnticipado.getCodInstrumento().trim().equals(CODIGO_INSTRUMENTO_PAGO_ANTICIPADO)) {
			this.pagoAnticipado.setHaberMo(new BigDecimal(this.pagoAnticipado.getDebeMo().toString()));
			this.pagoAnticipado.setDebeMo(BigDecimal.ZERO);
		}
		this.msj = getAlertJS(statusResponse);
	}

	private void autorizarPagoAnticipado() {
		this.pagoAnticipado.setCveEstadoAnt(ESTADO_CONTABILIZADO);
		StatusResponse statusResponse = Servicios.modificarPagoAnticipado(this.pagoAnticipado);
		if (!statusResponse.getStatusCode().equals(SUCCESS))
			this.pagoAnticipado.setCveEstadoAnt(ESTADO_PENDIENTE);
		this.msj = getAlertJS(statusResponse);
	}

	private void eliminarPagoAnticipado() {
		StatusResponse statusResponse = Servicios.eliminarPagoAnticipado(this.pagoAnticipado);
		if (statusResponse.getStatusCode().equals(SUCCESS))
			this.crearObjetosPorDefecto();
		this.msj = getAlertJS(statusResponse);
	}

	public void generarDAV(ActionEvent event) {
		this.msj = "";
		if (StringUtils.isEmpty(this.pagoAnticipado.getCodInst()) || StringUtils.isEmpty(this.pagoAnticipado.getCodId())
				|| StringUtils.isEmpty(this.pagoAnticipado.getAnio()) || StringUtils.isEmpty(this.pagoAnticipado.getSecuencia())) {
			if (!StringUtils.isEmpty(this.pagoAnticipado.getSecuencia()))
				this.pagoAnticipado.setSecuencia(StringUtils.leftPad(this.pagoAnticipado.getSecuencia(), 6, '0'));
			this.msj = getAlertJS("No se puede generar el DAV, ingrese los campos correctamente.");
		} else {
			this.pagoAnticipado.setSecuencia(StringUtils.leftPad(this.pagoAnticipado.getSecuencia(), 6, '0'));
			this.pagoAnticipado.setDav(NumeroDAV.generaDAV(this.pagoAnticipado.getCodInst(), this.pagoAnticipado.getCodId(), this.pagoAnticipado.getAnio(),
					this.pagoAnticipado.getSecuencia()));
		}
	}

	public void consultarPagosAnticipados(ActionEvent event) {
		this.pagosAnticipados = this.sirAladiDao.getPagosAnticipados(TIPO_APERTURA_EXPORTACION, ESTADO_PENDIENTE);
	}

	public void seleccionarPagoAnticipado(RegAnticipado regAnticipadoSel) {
		this.msj = "";
		this.pagoAnticipado = regAnticipadoSel;
		this.pagoAnticipado.setCodInstrumento(this.pagoAnticipado.getCodInstrumento().trim());
		if (!this.pagoAnticipado.getCodInstrumento().trim().equals(CODIGO_INSTRUMENTO_PAGO_ANTICIPADO)) {
			this.pagoAnticipado.setHaberMo(new BigDecimal(this.pagoAnticipado.getDebeMo().toString()));
			this.pagoAnticipado.setDebeMo(BigDecimal.ZERO);
		}
		this.codPais = this.sirAladiDao.getInstitucion(this.pagoAnticipado.getCodInst()).getPais().getCodPais();
		this.pagosAnticipados.clear();
		this.mostrarModal = false;
		this.msj = getCierreModalPanelJS("modalPanelBuscador");
	}

	public void mostrarReporte(ActionEvent event) {
		if (this.pagoAnticipado.getNroMov() != null && this.pagoAnticipado.getNroMov() > 0) {
			Map<String, Object> parametros = new HashMap<String, Object>();
			parametros.put("NRO_MOV", this.pagoAnticipado.getNroMov());
			parametros.put("TITULO", "PAGO ANTICIPADO POR EXPORTACI�N");
			HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
			request.getSession().setAttribute("pathTranslated", request.getPathTranslated());
			request.getSession().setAttribute("nombreReporte", "repPagoAnticipadoExp.jasper");
			request.getSession().setAttribute("parametros", parametros);
		}
	}

	private void crearObjetosPorDefecto() {
		this.msj = "";
		this.codPais = null;
		this.mostrarModal = false;

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(this.sirAladiDao.getFechaActual());

		this.pagoAnticipado = new RegAnticipado();
		this.pagoAnticipado.setCodId(CODIGO_ID_PAGO_ANTICIPADO);
		this.pagoAnticipado.setCodInstRecep(CODIGO_INSTITUCION_BCB);
		this.pagoAnticipado.setAnio(String.valueOf(calendar.get(Calendar.YEAR)));
		this.pagoAnticipado.setCodMoneda(CODIGO_MONEDA_DOLARES);
		this.pagoAnticipado.setCveTipoApe(TIPO_APERTURA_EXPORTACION);
		this.pagoAnticipado.setCveEstadoAnt(ESTADO_PENDIENTE);
		this.pagoAnticipado.setDebeMo(BigDecimal.ZERO);

		if (this.mapEstado == null) {
			String[] codigosInstrumentos = { "LEX", "ALE" };
			List<Instrumento> listaInstrumentos = this.sirAladiDao.getInstrumentos(Arrays.asList(codigosInstrumentos));
			List<Pais> listaPaisesExterior = this.sirAladiDao.getPaisesExterior();

			this.itemsInstrumentos = armarSelectItemsInstrumentos(listaInstrumentos);
			this.itemsPaises = armarSelectItemsPaises(listaPaisesExterior);

			List<Institucion> listaBancosCentrales = this.sirAladiDao.getBancosCentralesExterior();
			this.mapPaisesBancos = new HashMap<String, String>();
			for (Institucion bc : listaBancosCentrales)
				this.mapPaisesBancos.put(bc.getCodInst(), bc.getPais().getNomPais().trim());

			this.mapEstado = armarMapDescripcionClaves(this.sirAladiDao.getClaves(CVE_ESTADO_PAGO_ANT));
		}

	}

}
