/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-web-sirAladi
 * gob.bcb.portal.sirAladi.reportes.controller.RepRelPatrimonioController
 * 04/10/2011 - 10:56:28
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.reportes.controller;

import static gob.bcb.portal.sirAladi.commons.Constantes.FORMATO_FECHA_JAVA;
import gob.bcb.bpm.siraladi.jpa.Patrimonio;
import gob.bcb.bpm.siraladi.jpa.Persona;
import gob.bcb.portal.sirAladi.commons.AladiUtils;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;
import gob.bcb.portal.sirAladi.dao.DaoFactory;
import gob.bcb.portal.sirAladi.dao.SirAladiDao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

/**
 * Backing bean de la vista de consulta de relacion patrimonio y endeudamiento.
 * 
 * @author wherrera
 * 
 */
public class RepRelPatrimonioController extends BaseBeanController {
	private String codPersona;
	private String nroOrden;
	private String query;
	private Date fechaAl;

	private SirAladiDao sirAladiDao;
	private List<List<Object>> listaRelacion;
	private List<SelectItem> itemsOrden;
	private List<SelectItem> itemsPersonas;
	private List<BigDecimal> totales;

	private static Logger log = Logger.getLogger(RepRelPatrimonioController.class);

	public RepRelPatrimonioController() {
	}

	@PostConstruct
	public void init() {
		log.info("Iniciando el modulo de consulta de relacion patrimonio endeudamiento.");
		recuperarVisit();
		this.sirAladiDao = DaoFactory.getInstance().getSirAladiDao();
		this.crearObjetosPorDefecto();

	}

	public String getCodPersona() {
		return codPersona;
	}

	public void setCodPersona(String codPersona) {
		this.codPersona = codPersona;
	}

	public String getNroOrden() {
		return nroOrden;
	}

	public void setNroOrden(String nroOrden) {
		this.nroOrden = nroOrden;
	}

	public Date getFechaAl() {
		return fechaAl;
	}

	public void setFechaAl(Date fechaAl) {
		this.fechaAl = fechaAl;
	}

	public String getTxtFechaAl() {
		return AladiUtils.dateToString(this.fechaAl, FORMATO_FECHA_JAVA);
	}

	public String getTxtFechaPatrimonioAl() {
		String fecha = null;
		if (this.listaRelacion != null && this.listaRelacion.size() > 0)
			fecha = AladiUtils.dateToString((Date) this.listaRelacion.get(0).get(5), FORMATO_FECHA_JAVA);
		return fecha;
	}

	public String getTxtLimiteEndeudamiento() {
		String limite = null;
		if (this.listaRelacion != null && this.listaRelacion.size() > 0)
			limite = ((BigDecimal) this.listaRelacion.get(0).get(6)).toString();
		return limite;
	}

	public List<List<Object>> getListaRelacion() {
		return listaRelacion;
	}

	public List<SelectItem> getItemsPersonas() {
		return itemsPersonas;
	}

	public List<SelectItem> getItemsOrden() {
		return itemsOrden;
	}

	public List<BigDecimal> getTotales() {
		return totales;
	}

	public void consultarRelacionPatrimonio(ActionEvent event) {
		String codigoPersona = StringUtils.isEmpty(this.codPersona) ? "%" : this.codPersona;
		String fecha = AladiUtils.dateToString(this.fechaAl, FORMATO_FECHA_JAVA);
		StringBuffer sb = new StringBuffer("SELECT b.cod_persona, TRIM(c.nom_persona) institucion, ");
		sb.append("b.pat_actual, b.limite_max, ");
		sb.append("saldo_cont_mo(b.cod_persona, TO_DATE('" + fecha + "','%d/%m/%Y'), 'I') saldo_deudor, ");
		sb.append("a.fecha_anterior, a.nivel ");
		sb.append("FROM patrimonio a, det_patrimonio b, persona  c ");
		sb.append("WHERE a.nro_orden = b.nro_orden ");
		sb.append("AND b.cod_persona = c.cod_persona ");
		sb.append("AND c.cod_persona LIKE '" + codigoPersona + "' ");
		sb.append("AND a.nro_orden = '" + this.nroOrden + "' ");
		this.query = sb.toString();
		this.listaRelacion = this.sirAladiDao.ejecutarQueryListas(this.query);

		// calculo de totales
		this.totales = Arrays.asList(new BigDecimal[] { BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO });
		for (List<Object> reg : this.listaRelacion) {
			this.totales.set(0, this.totales.get(0).add((BigDecimal) reg.get(2)));
			this.totales.set(1, this.totales.get(1).add((BigDecimal) reg.get(3)));
			this.totales.set(2, this.totales.get(2).add((BigDecimal) reg.get(4)));
			this.totales.set(3, this.totales.get(3).add(((BigDecimal) reg.get(3)).subtract((BigDecimal) reg.get(4))));
		}
	}

	public void mostrarReporte(ActionEvent event) {
		String fecha = AladiUtils.dateToString(this.fechaAl, FORMATO_FECHA_JAVA);
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("TITULO", "RELACI�N PATRIMONIO Y ENDEUDAMIENTO POR OPERACIONES DE IMPORTACI�N");
		parametros.put("QUERY", query);
		parametros.put("FECHA_AL", fecha);
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("pathTranslated", request.getPathTranslated());
		request.getSession().setAttribute("nombreReporte", "repRelPatrimonio.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}

	public void limpiar(ActionEvent event) {
		this.crearObjetosPorDefecto();
	}

	private void crearObjetosPorDefecto() {
		this.codPersona = null;
		this.fechaAl = this.sirAladiDao.getFechaActual();
		this.listaRelacion = new ArrayList<List<Object>>();

		// combos
		if (this.itemsPersonas == null) {
			this.itemsPersonas = new ArrayList<SelectItem>();
			List<Persona> personas = this.sirAladiDao.getEntidades();
			for (Persona persona : personas)
				this.itemsPersonas.add(new SelectItem(persona.getCodPersona(), persona.getNomPersona().trim()));
			this.itemsOrden = new ArrayList<SelectItem>();
			List<Patrimonio> patrimonios = this.sirAladiDao.getPatrimonios(null, null);
			for (Patrimonio patrimonio : patrimonios)
				this.itemsOrden.add(new SelectItem(Integer.toString(patrimonio.getNroOrden()), Integer.toString(patrimonio.getNroOrden())));
		}
	}

}
