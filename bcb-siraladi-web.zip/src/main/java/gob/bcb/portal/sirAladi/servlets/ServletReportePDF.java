/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-web-sirAladi
 * gob.bcb.portal.sirAladi.servlets.ServletReportePDF
 * 30/09/2011 - 11:25:57
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.servlets;

import gob.bcb.bpm.siraladi.pojo.SaldoConvenio;
import gob.bcb.core.utils.ArchivoUtil;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.portal.sirAladi.commons.Constantes;
import gob.bcb.portal.sirAladi.controller.Visit;
import gob.bcb.portal.sirAladi.dao.DaoFactory;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JRParameter;
import net.sf.jasperreports.engine.JRRuntimeException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperRunManager;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRXlsExporter;
import net.sf.jasperreports.engine.export.JRXlsExporterParameter;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimpleXlsxReportConfiguration;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.log4j.Logger;

/**
 * Servlet que despliega el contenido de un archivo PDF generado en array de
 * bytes y bajado de sesion.
 * 
 * @author wherrera
 * 
 */
public class ServletReportePDF extends HttpServlet {
	private static Logger log = Logger.getLogger(ServletReportePDF.class);
	public static final String REPORTE_FORMATO = "reportFormato";
	public static final String BEAN_SALDOS_X_CONV = "beanSaldosPorConvenio";	
	
	/**
	 * M�todo que despliega un reporte en formato pdf.
	 * 
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	// @SuppressWarnings("unchecked")
	// private void desplegarReporte(final HttpServletRequest request, final
	// HttpServletResponse response) {
	public void service(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		HttpSession session = null;
		String nombreReporte = null;
		List<?> beanDataSource = null;
		// Map<String, Object> parametros = null;
		Map parametros = new HashMap();
	
        SimpleDateFormat sdfLong = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
       
		try {
			// recuperacion de variables guardadas en sesion.
			session = request.getSession();
			int cont = 0;
			do {
				// si el reporte no recibe parametros en los 10 seg 
				nombreReporte = (String) session.getAttribute("nombreReporte");
				Thread.sleep(500);
				cont++;
				
			} while (nombreReporte == null && cont <= 20);

			Visit visit = (Visit) session.getAttribute(Constantes.SESSION_KEY_USER);
			log.info("reporte jasper:=> {" + nombreReporte + "} iniciado " + visit.getUsuarioSirAladi().getLogin());			
			ServletContext context = getServletConfig().getServletContext();
			String reportFileName = context.getRealPath("/Modulos/Reportes/ReportesJasper/" + nombreReporte);
			File reportFile = new File(reportFileName);
			if (!reportFile.exists())
				throw new JRRuntimeException("Archivo " + nombreReporte
						+ " no encontrado. El reporte no puede ser visualizado, comunique al administrador del sistema.");

			InputStream reportStream = context.getResourceAsStream("/Modulos/Reportes/ReportesJasper/" + nombreReporte);
				
			log.info("directorio reportFile.getParentFile() " + reportFile.getParentFile());
			parametros = (Map) session.getAttribute("parametros");
			
			// recuperacion de beanDataSource si corresponde de acuerdo al tipo
			// de reporte
			if (nombreReporte.equals("repSaldosPorConvenio.jasper") || nombreReporte.equals("repNumeralesIntereses.jasper")) {
				beanDataSource = (List<SaldoConvenio>) session.getAttribute("beanDataSource");
				parametros.put(BEAN_SALDOS_X_CONV, beanDataSource);
			}
			
			parametros.put("USUARIO", visit.getUsuarioSirAladi().getLogin());
			parametros.put("FECHA_HORA", new Date());
			parametros.put("SERVIDOR", visit.getAddress());
			parametros.put("host", request.getRemoteAddr());
			parametros.put("fechaImpresion", sdfLong.format(new Date()));
			parametros.put(JRParameter.REPORT_LOCALE, Locale.US);
			parametros.put("BaseDir", reportFile.getParentFile());
			String formatoReporte = (String) parametros.get(Constantes.PARAM_TIPO_REPORTE); 
			
			if (formatoReporte == null || formatoReporte.trim().isEmpty()) {
				formatoReporte = "PDF";
			}
			parametros.put(REPORTE_FORMATO, formatoReporte);
			log.info("parametros " +  ArrayUtils.toString(parametros));
			
			/* ##### GENERANDO REPOrTITO ############## */
			// whf 201610 se agrega opcion de imprimir en xls
			byte[] reportePDF = obtenerReporte(reportFileName, parametros);
			
			String nFileJasper = nombreReporte.substring(0, (nombreReporte.indexOf(".") < 0 ? nombreReporte.length():nombreReporte.indexOf(".")));
			//connection = DaoFactory.getInstance().getSirAladiDao().getConnection();
			String nameFileOut = (nFileJasper.concat(UtilsDate.stringFromDate(new Date(), "yyyyMMddHHss"))).concat(".").concat(formatoReporte.toLowerCase());
			response.setHeader("Cache-Control", "no-cache");
			response.setHeader("Pragma", "no-cache");
			response.setDateHeader("Expires", 0);
			
			ServletOutputStream ouputStream = response.getOutputStream();
			response.setContentType(ArchivoUtil.getMimeFromExt(ArchivoUtil.obtenerExtension(nameFileOut)));
			response.setContentLength(reportePDF.length);
			response.setHeader("content-disposition", "inline; filename=\"" + nameFileOut + "\"");

			ouputStream.write(reportePDF, 0, reportePDF.length);			
			ouputStream.flush();
			ouputStream.close();
			try {
				reportStream.close();
				parametros.clear();
				reportStream = null;
			} catch (Exception e) {
				log.error("Error al cerrar stream " + e.getMessage(), e);
			}			
		} catch (Exception e) {
			log.error("Error al generar reporte " + e.getMessage(), e);
			try {
				StringWriter stringWriter = new StringWriter();
				PrintWriter out = new PrintWriter(stringWriter);				
				out.println("<html>");
				out.println("<head>");
				out.println("<title>Error al generar reporte</title>");
				out.println("<link rel=\"stylesheet\" type=\"text/css\" href=\"/resources/css/theme.css\" title=\"Style\">");
				out.println("</head>");
				out.println("<body bgcolor=\"white\">");
				out.println("<span>Ocurri un error al generar el reporte :</span>");
				out.println("<pre>");
				e.printStackTrace(out);
				out.println("</pre>");
				out.println("</body>");
				out.println("</html>");
				response.setContentType("text/html");
			    response.getOutputStream().print(stringWriter.toString()); 				
				out.flush();
				out.close();
			} catch (Exception e1) {
				log.error("Error al generar pagina de error de reporte " + e1.getMessage(), e1);
			}
		} finally {

			if (session != null) {
				session.removeAttribute("nombreReporte");
				session.removeAttribute("beanDataSource");
				session.removeAttribute("parametros");
			}
		}
	}

	private static byte[] obtenerReporte(String pathReporteJasper, Map<String, Object> parametros) throws Exception {
		Connection connection = null;
		byte[] reportePdf = null;

		// FileOutputStream fos = null;
		final ByteArrayOutputStream out = new ByteArrayOutputStream();
		try {
			long startTime = System.currentTimeMillis();

			String formatReport = (String) parametros.get(REPORTE_FORMATO);
			connection = DaoFactory.getInstance().getSirAladiDao().getConnection();
			connection.setTransactionIsolation(Connection.TRANSACTION_READ_UNCOMMITTED);
			JasperPrint jrprintFile = JasperFillManager.fillReport(pathReporteJasper, parametros, connection);
			log.info("connection.getTransactionIsolation(): " + connection.getTransactionIsolation());

			if (formatReport.trim().equalsIgnoreCase("xlsx") || formatReport.trim().equalsIgnoreCase("xls")) {
				// exportReporte(response, reportStream, reportFileName,
				// parametros);
				JRXlsxExporter exporter = new JRXlsxExporter();
				exporter.setExporterInput(new SimpleExporterInput(jrprintFile));
				exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(out));

				SimpleXlsxReportConfiguration configuration = new SimpleXlsxReportConfiguration();
				configuration.setOnePagePerSheet(false);
				configuration.setIgnorePageMargins(true);
				configuration.setWhitePageBackground(true);
//				configuration.setRemoveEmptySpaceBetweenRows(true);
				configuration.setDetectCellType(true);// Set configuration as
//														// you
//														// like it!!
				exporter.setConfiguration(configuration);
				exporter.exportReport();
			} else {
				if (parametros.containsKey(BEAN_SALDOS_X_CONV)){
					List<SaldoConvenio> saldos = (List<SaldoConvenio>) parametros.get(BEAN_SALDOS_X_CONV);
					JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(saldos);
					log.info("Rreport con BEAN " + saldos.size());
					reportePdf = JasperRunManager.runReportToPdf(pathReporteJasper, parametros, dataSource);
				} else {
					reportePdf = JasperRunManager.runReportToPdf(pathReporteJasper, parametros, connection);
				}
				out.write(reportePdf);
			}

			long endTime = System.currentTimeMillis();
			long time = (endTime - startTime) / 1;

			log.info("success with " + time + " (s) yeah!!");
			return out.toByteArray();
		} catch (Exception e) {
			log.error("Error al exportar a XCEL " + e.getMessage(), e);
			throw new Exception(e);
		} finally {
			try {
				if (connection != null)
					connection.close();
			} catch (Exception e1) {
				throw new Exception(e1);
			}
		}
		// return reportePdf;
	}
	
	
	public void destroy() {

	}

}
