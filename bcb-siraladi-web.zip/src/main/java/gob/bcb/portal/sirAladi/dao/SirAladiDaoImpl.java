/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-web-sirAladi
 * gob.bcb.portal.sirAladi.dao.SirAladiDaoImpl
 * 15/11/2011 - 14:31:11
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.dao;

import static gob.bcb.portal.sirAladi.commons.Constantes.CODIGO_PERSONA_BCB;
import static gob.bcb.portal.sirAladi.commons.Constantes.TIPO_APERTURA_EXPORTACION;
import static gob.bcb.portal.sirAladi.commons.Constantes.TIPO_APERTURA_IMPORTACION;
import static gob.bcb.portal.sirAladi.commons.Constantes.TIPO_EMISION_EMISION;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.support.DataAccessUtils;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.SessionFactoryUtils;

import gob.bcb.bpm.siraladi.jpa.Adjunto;
import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.ClasifProductos;
import gob.bcb.bpm.siraladi.jpa.Claves;
import gob.bcb.bpm.siraladi.jpa.DetPatrimonio;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Instrumento;
import gob.bcb.bpm.siraladi.jpa.Pago;
import gob.bcb.bpm.siraladi.jpa.Pais;
import gob.bcb.bpm.siraladi.jpa.Patrimonio;
import gob.bcb.bpm.siraladi.jpa.Persona;
import gob.bcb.bpm.siraladi.jpa.PlanPago;
import gob.bcb.bpm.siraladi.jpa.RegAnticipado;
import gob.bcb.bpm.siraladi.jpa.Registro;
import gob.bcb.bpm.siraladi.jpa.TPagoImp;
import gob.bcb.bpm.siraladi.pojo.UsuarioSirAladi;
import gob.bcb.bpm.siraladi.service.ServiceDao;

/**
 * Clase que implemente la interface SirAladiDao.
 * 
 * @author wherrera
 * 
 */

public class SirAladiDaoImpl implements SirAladiDao {
	private static Logger log = Logger.getLogger(SirAladiDaoImpl.class);
	private HibernateTemplate hibernateTemplate;
	private boolean insWhere;
	@Autowired
	private ServiceDao serviceDao;

	public String selectAperturas(String tipoApertura, String estadoApertura, String codPersona, String tipoReg,
			String estadoRegistro, String codConvenio) {
		StringBuffer query = new StringBuffer("SELECT a FROM Apertura a ");
		codPersona = codPersona.trim();
		insWhere = true;
		if (tipoApertura != null && !tipoApertura.trim().isEmpty()) {
			insWhere = false;
			query.append("WHERE a.cveTipoApe = '").append(tipoApertura).append("' ");

			if (estadoApertura != null && !estadoApertura.trim().isEmpty())
				query.append("AND a.cveEstadoApe in ('").append(estadoApertura).append("') ");

			if (tipoApertura.equals("I")) {
				if (!codPersona.equals(CODIGO_PERSONA_BCB)) {
					query.append(
							"AND exists (select 1 from PersonaInst pi WHERE pi.id.codInst = a.institucion.codInst ");
					query.append("AND pi.id.codPersona = '").append(codPersona).append("') "); // select
																								// 1
				}
				if (codConvenio != null && !codConvenio.trim().isEmpty()) {
					// selecciona el pais convenio
					query.append("AND a.pais.codPais = '").append(codConvenio).append("' ");
				}
			} else if (tipoApertura.equals("E")) {
				if (!codPersona.equals(CODIGO_PERSONA_BCB)) {
					query.append("AND exists (select 1 from PersonaInst pi, Registro r ");
					query.append("WHERE pi.id.codInst = r.institucion.codInst ");
					query.append("AND r.nroMovApe = a.nroMov AND r.cveTipoEmis = 'E' ");
					query.append("AND pi.id.codPersona = '").append(codPersona).append("') "); // select
																								// 1
				}
				if (codConvenio != null && !codConvenio.trim().isEmpty()) {
					// selecciona el pais convenio
					query.append("AND exists (select 1 from Institucion i "); // select1
																				// pais
					query.append("where i.codInst = a.institucion.codInst ");
					query.append("and i.pais.codPais = '").append(codConvenio).append("') ");
				}
			}
		} else {
			if (estadoApertura != null && !estadoApertura.trim().isEmpty()) {
				query.append("WHERE a.cveEstadoApe in ('").append(estadoApertura).append("') ");
				insWhere = false;
			}
			if (!codPersona.equals(CODIGO_PERSONA_BCB)) {
				if (insWhere)
					query.append("WHERE ");
				else
					query.append("AND ");

				query.append("(" + // init
						"(a.cveTipoApe = 'I' AND exists (select 1 from PersonaInst pi WHERE pi.id.codInst = a.institucion.codInst ");
				query.append("AND pi.id.codPersona = '").append(codPersona).append("')) "); // select
																							// 1
				query.append("OR ");
				query.append("(a.cveTipoApe = 'E' AND exists (select 1 from PersonaInst pi, Registro r ");
				query.append("WHERE pi.id.codInst = r.institucion.codInst ");
				query.append("AND r.nroMovApe = a.nroMov AND r.cveTipoEmis = 'E' ");
				query.append("AND pi.id.codPersona = '").append(codPersona).append("')) "); // select
																							// 1
				query.append(") "); // fin init
				insWhere = false;
			}
			if (codConvenio != null && !codConvenio.trim().isEmpty()) {
				if (insWhere)
					query.append("WHERE ");
				else
					query.append("AND ");
				// selecciona el pais convenio
				query.append("("); // init
				query.append("(a.cveTipoApe = 'E' AND exists (select 1 from Institucion i "); // select1
																								// pais
				query.append("where i.codInst = a.institucion.codInst ");
				query.append("and i.pais.codPais = '").append(codConvenio).append("')) "); // finselect1pais
				query.append("OR ");
				query.append("(a.cveTipoApe = 'I' AND a.pais.codPais = '").append(codConvenio).append("')");
				query.append(") "); // fin init
				insWhere = false;
			}
		}
		if (tipoReg != null && estadoRegistro != null && !estadoRegistro.trim().isEmpty()) {
			if (insWhere)
				query.append("WHERE ");
			else
				query.append("AND ");

			insWhere = false;

			if (tipoReg.equals("R")) {
				// si es tabla registro, aperturas que tengan un registro en
				// estado = estadoRegistro
				query.append("exists (select 1 from Registro r1 ");
				query.append("WHERE r1.nroMovApe = a.nroMov ");
				query.append("AND r1.cveEstadoReg = '").append(estadoRegistro).append("') "); // select
																								// 1
			} else if (tipoReg.equals("P")) {
				query.append("exists (select 1 from Pago p1 ");
				query.append("WHERE p1.nroMovApe = a.nroMov ");
				query.append("AND p1.cveEstadoPago = '").append(estadoRegistro).append("') "); // select
																								// 1
			} else if (tipoReg.equals("PP")) {
				// si es tabla plan de pagos aperturas que tengan un registro en
				// estado = estadoRegistro
				query.append("exists (select 1 from Pago p1 ");
				query.append("WHERE p1.nroMovApe = a.nroMov ");
				query.append("AND p1.cveEstadoPago = '").append(estadoRegistro).append("') "); // select
																								// 1
			}
		}
		return query.toString();
	}

	public List<Claves> getClaves(String nomDato) {
		String query = "FROM Claves c WHERE c.id.nomdato = ? ORDER BY c.interp";
		return hibernateTemplate.find(query, nomDato);
	}

	public String getDescripcionClave(String nomDato, String valDato) {
		DetachedCriteria criteria = DetachedCriteria.forClass(Claves.class);
		criteria.add(Restrictions.eq("id.nomdato", nomDato));
		criteria.add(Restrictions.eq("id.valdato", valDato));
		Claves claves = (Claves) DataAccessUtils.uniqueResult(hibernateTemplate.findByCriteria(criteria));
		return claves.getInterp().trim();
	}

	public List<Persona> getEntidades() {
		String query = "FROM Persona p WHERE p.cveVigente = 'V' AND p.institucions.size > 0 ORDER BY p.nomPersona";
		return hibernateTemplate.find(query);
	}

	public List<Persona> getEntidadesBCB() {
		String query = "FROM Persona p WHERE p.cveVigente = 'V' AND p.institucions.size = 0 ORDER BY p.nomPersona";
		return hibernateTemplate.find(query);
	}

	public BigDecimal getSaldoContMo(String codPersona, Date fecha) {
		List<List<Object>> listaRelacion = new ArrayList<List<Object>>();

		Calendar fechaAl = GregorianCalendar.getInstance();
		fechaAl.setTime(fecha);
		String strFecha = " mdy(" + (fechaAl.get(Calendar.MONTH) + 1) + "," + fechaAl.get(Calendar.DAY_OF_MONTH) + ","
				+ fechaAl.get(Calendar.YEAR) + ") ";
		String query = "SELECT saldo_cont_mo(b.cod_persona, " + strFecha
				+ ", 'I') saldo FROM Persona b WHERE b.cod_persona = '" + codPersona + "' ";
		listaRelacion = ejecutarQueryListas(query);
		BigDecimal valor = BigDecimal.ZERO;
		for (List<Object> reg : listaRelacion) {
			valor = (BigDecimal) reg.get(0);
		}
		// return (BigDecimal.valueOf((valor == null ? Double.valueOf(0) :
		// valor)));
		// BigDecimal montoTotal = (BigDecimal) hibernateTemplate.find(query,
		// codPersona).get(0);
		return (valor == null) ? BigDecimal.ZERO : valor;
	}

	public Persona getEntidadPorUsuario(String codPersona) {
		String consulta = "FROM Persona p WHERE TRIM(p.codPersona) = ?";
		Persona persona = (Persona) this.hibernateTemplate.find(consulta, codPersona.trim()).get(0);
		String query = "FROM Institucion i WHERE i.codInst IN "
				+ "(SELECT pi.id.codInst FROM PersonaInst pi WHERE pi.id.codPersona = ?) "
				+ "AND i.cveEstado = '0' ORDER BY i.nomPlaza";
		persona.setInstitucions(hibernateTemplate.find(query, persona.getCodPersona()));
		return persona;
	}

	public List<Pais> getPaises() {
		String query = "FROM Pais p WHERE p.cveEstConvenio = 'V' ORDER BY p.nomPais";
		return hibernateTemplate.find(query);
	}

	public Pais getPaisConvenio(Apertura apertura) {
		String query = null;

		if (apertura.getCveTipoApe().trim().equals("E")) {
			query = "Select p FROM Pais p,Institucion i where i.pais.codPais = p.codPais and i.codInst = ? ";
			return (Pais) hibernateTemplate.find(query, apertura.getInstitucion().getCodInst().trim()).get(0);
		}
		query = "Select p FROM Pais p where p.codPais = ? ";
		return (Pais) hibernateTemplate.find(query, apertura.getPais().getCodPais().trim()).get(0);
	}

	public List<Pais> getPaisesExterior() {
		String query = "FROM Pais p WHERE p.codPais <> '02' AND p.cveEstConvenio = 'V' ORDER BY p.nomPais";
		return hibernateTemplate.find(query);
	}

	public List<Instrumento> getInstrumentos() {
		String query = "FROM Instrumento i ORDER BY i.nomInstrumento";
		return hibernateTemplate.find(query);
	}

	public List<Instrumento> getInstrumentos(List<String> codigosInstrumentos) {
		String query = "FROM Instrumento i WHERE i.codInstrumento IN (:codigosInstrumentos) ORDER BY i.nomInstrumento";
		return hibernateTemplate.findByNamedParam(query, "codigosInstrumentos", codigosInstrumentos);
	}

	public Institucion getInstitucion(String codInstitucion) {
		return (Institucion) hibernateTemplate.get(Institucion.class, codInstitucion);
	}

	public List<Institucion> getInstituciones(List<String> codigosInstituciones) {
		String query = "FROM Institucion i WHERE i.codInst IN (:codigosInstituciones) ORDER BY i.nomInst, i.nomPlaza";
		return hibernateTemplate.findByNamedParam(query, "codigosInstituciones", codigosInstituciones);
	}

	public List<Institucion> getInstitucionesPorPais(String codPais) {
		String query = "FROM Institucion i WHERE i.pais.codPais = ? AND i.cveEstado = '0' ORDER BY i.nomInst, i.nomPlaza";
		return hibernateTemplate.find(query, codPais);
	}

	public List<Institucion> getBancosCentralesExterior() {
		String query = "FROM Institucion i WHERE i.cveTipoInst = 'S' AND i.cveEstado = '0' AND i.pais.codPais != '02'";
		return hibernateTemplate.find(query);
	}

	public List<Institucion> getInstitucionesReporte(String codPais) {
		List<Institucion> listaInstituciones;
		if (codPais != null) {
			String query = "FROM Institucion i WHERE i.pais.codPais = ? ORDER BY i.nomInst, i.nomPlaza";
			listaInstituciones = hibernateTemplate.find(query, codPais);
		} else {
			String query = "FROM Institucion i ORDER BY i.pais.codPais, i.nomInst, i.nomPlaza";
			listaInstituciones = hibernateTemplate.find(query);
		}
		return listaInstituciones;
	}

	public Institucion getBancoCentralPorPais(String codPais) {
		DetachedCriteria criteria = DetachedCriteria.forClass(Institucion.class);
		criteria.add(Restrictions.eq("pais.codPais", codPais));
		criteria.add(Restrictions.eq("cveTipoInst", "S"));
		criteria.add(Restrictions.eq("cveEstado", "0"));
		return (Institucion) DataAccessUtils.uniqueResult(hibernateTemplate.findByCriteria(criteria));
	}

	public List<ClasifProductos> getClasificacionProductos() {
		String query = "FROM ClasifProductos cp WHERE cp.codClasifprod <> 0 ORDER BY cp.descrip";
		return hibernateTemplate.find(query);
	}

	public ClasifProductos getClasifProductos(Integer codClasifprod) {
		return (ClasifProductos) hibernateTemplate.get(ClasifProductos.class, codClasifprod);
	}

	public Persona getPersona(String codPersona) {
		return (Persona) hibernateTemplate.get(Persona.class, codPersona);
	}

	public Adjunto getAdjunto(Integer nroMov) {
		return (Adjunto) hibernateTemplate.get(Adjunto.class, nroMov);
	}

	public Apertura getApertura(Apertura apertura) {
		DetachedCriteria criteria = DetachedCriteria.forClass(Apertura.class);
		if (apertura.getInstitucion() != null && apertura.getInstitucion().getCodInst() != null
				&& !apertura.getInstitucion().getCodInst().trim().isEmpty())
			criteria.add(Restrictions.eq("institucion.codInst", apertura.getInstitucion().getCodInst()));

		if (apertura.getIdentificador() != null && apertura.getIdentificador().getCodId() != null
				&& !apertura.getIdentificador().getCodId().trim().isEmpty())
			criteria.add(Restrictions.eq("identificador.codId", apertura.getIdentificador().getCodId()));

		if (apertura.getAnio() != null && !apertura.getAnio().trim().isEmpty())
			criteria.add(Restrictions.eq("anio", apertura.getAnio()));

		if (apertura.getSecuencia() != null && !apertura.getSecuencia().trim().isEmpty())
			criteria.add(Restrictions.eq("secuencia", apertura.getSecuencia()));

		// criteria.add(Restrictions.eq("dav", apertura.getDav()));
		return (Apertura) DataAccessUtils.uniqueResult(hibernateTemplate.findByCriteria(criteria));
	}

	public List<Apertura> getAperturas(Apertura apertura, UsuarioSirAladi usuario) {
		List<Apertura> aperturas = null;
		List<Apertura> aperturasRet = new ArrayList<Apertura>();
		DetachedCriteria criteria = DetachedCriteria.forClass(Apertura.class);
		if (apertura.getInstitucion() != null && apertura.getInstitucion().getCodInst() != null
				&& !apertura.getInstitucion().getCodInst().trim().isEmpty())
			criteria.add(Restrictions.eq("institucion.codInst", apertura.getInstitucion().getCodInst()));

		if (apertura.getIdentificador() != null && apertura.getIdentificador().getCodId() != null
				&& !apertura.getIdentificador().getCodId().trim().isEmpty())
			criteria.add(Restrictions.eq("identificador.codId", apertura.getIdentificador().getCodId()));

		if (apertura.getAnio() != null && !apertura.getAnio().trim().isEmpty())
			criteria.add(Restrictions.eq("anio", apertura.getAnio()));

		if (apertura.getSecuencia() != null && !apertura.getSecuencia().trim().isEmpty())
			criteria.add(Restrictions.eq("secuencia", apertura.getSecuencia()));

		// criteria.add(Restrictions.eq("dav", apertura.getDav()));
		aperturas = hibernateTemplate.findByCriteria(criteria);

		if (usuario.getPersona().getCodPersona().trim().equals(CODIGO_PERSONA_BCB)) {
			return aperturas;
		}

		for (Apertura apertura2 : aperturas) {
			if (usuarioPuedeVerApertura(usuario, apertura2, apertura2.getCveTipoApe())) {
				aperturasRet.add(apertura2);
			}
		}

		return aperturasRet;
	}

	public Apertura getApertura(Integer nroMov) {
		Apertura apertura = serviceDao.getAperturaLocal().findByNroMovCveEstado(nroMov, null);
		if (apertura != null) {
			Persona persona = serviceDao.getPersonaLocal().findByCodigo(apertura.getCodPersona());
			apertura.setPersona(persona);
		}
		return apertura;
		// return (Apertura) hibernateTemplate.get(Apertura.class, nroMov);
	}

	public Registro getRegistroEmision(Integer nroMovApertura) {
		List<Registro> registroList = serviceDao.getRegistroLocal().getRegistroByTipoEmis(nroMovApertura,
				TIPO_EMISION_EMISION);
		// DetachedCriteria criteria =
		// DetachedCriteria.forClass(Registro.class);
		// criteria.add(Restrictions.eq("nroMovApe", nroMovApertura));
		// criteria.add(Restrictions.eq("cveTipoEmis", TIPO_EMISION_EMISION));
		// return (Registro)
		// DataAccessUtils.uniqueResult(hibernateTemplate.findByCriteria(criteria));
		if (registroList.size() > 1)
			throw new RuntimeException("Existe mas de un registro de emision " + nroMovApertura);
		if (registroList.size() == 1)
			return registroList.get(0);
		return null;
	}

	public List<Registro> getRegistros(Integer nroMovApertura) {
		String query = "FROM Registro r WHERE r.nroMovApe = ? ORDER BY r.nroMov";
		return hibernateTemplate.find(query, nroMovApertura);
	}

	public List<Pago> getPagos(Integer nroMovApertura) {
		String query = "FROM Pago p WHERE p.nroMovApe = ? ORDER BY p.nroMov";
		return hibernateTemplate.find(query, nroMovApertura);
	}

	public List<PlanPago> getPlanPagos(Integer nroMovApertura) {
		String query = "FROM PlanPago pp WHERE pp.id.nroMov = ? AND pp.cveEstadoPlan <> 'S' ORDER BY pp.id.nroPlan";
		return hibernateTemplate.find(query, nroMovApertura);
	}

	public RegAnticipado getPagoAnticipado(RegAnticipado pagoAnticipado) {
		DetachedCriteria criteria = DetachedCriteria.forClass(RegAnticipado.class);
		criteria.add(Restrictions.eq("codInst", pagoAnticipado.getCodInst()));
		criteria.add(Restrictions.eq("codId", pagoAnticipado.getCodId()));
		criteria.add(Restrictions.eq("anio", pagoAnticipado.getAnio()));
		criteria.add(Restrictions.eq("secuencia", pagoAnticipado.getSecuencia()));
		criteria.add(Restrictions.eq("dav", pagoAnticipado.getDav()));
		return (RegAnticipado) DataAccessUtils.uniqueResult(hibernateTemplate.findByCriteria(criteria));
	}

	public List<RegAnticipado> getPagosAnticipados(String tipoApertura, String estado) {
		StringBuffer query = new StringBuffer("FROM RegAnticipado r ");
		if (tipoApertura != null || estado != null) {
			query.append("WHERE ");
			if (tipoApertura != null)
				query.append("r.cveTipoApe = '").append(tipoApertura).append("' ");
			if (tipoApertura != null && estado != null)
				query.append("AND ");
			if (estado != null)
				query.append("r.cveEstadoAnt = '").append(estado).append("' ");
		}
		query.append("ORDER BY r.nroMov DESC");
		return hibernateTemplate.find(query.toString());
	}

	public List<RegAnticipado> getPagosAnticipados(Date fechaDesde, Date fechaHasta) {
		String query = "FROM RegAnticipado p WHERE p.fechaCargo BETWEEN ? AND ? ORDER BY p.nroMov DESC";
		return hibernateTemplate.find(query, new Date[] { fechaDesde, fechaHasta });
	}

	public boolean usuarioPuedeVerApertura(UsuarioSirAladi usuario, Apertura apertura, String tipoApertura) {
		boolean autorizado = true;
		if (!usuario.getPersona().getCodPersona().trim().equals(CODIGO_PERSONA_BCB)) {
			if (tipoApertura == null)
				tipoApertura = apertura.getCveTipoApe();
			if (tipoApertura.equals(TIPO_APERTURA_IMPORTACION)
					&& apertura.getCveTipoApe().equals(TIPO_APERTURA_IMPORTACION))
				autorizado = usuario.getMapInstituciones().containsKey(apertura.getInstitucion().getCodInst());
			else if (tipoApertura.equals(TIPO_APERTURA_EXPORTACION)
					&& apertura.getCveTipoApe().equals(TIPO_APERTURA_EXPORTACION)) {
				Registro registro = getRegistroEmision(apertura.getNroMov());
				autorizado = usuario.getMapInstituciones().containsKey(registro.getInstitucion().getCodInst());
			} else
				autorizado = false;
		}
		return autorizado;
	}

	public BigDecimal getMontoInstrumento(Integer nroMovApertura) {
		String query = "SELECT SUM(r.debeMo - r.haberMo) FROM Registro r WHERE r.nroMovApe = ? AND r.cveEstadoReg = 'C'";
		BigDecimal montoTotal = (BigDecimal) hibernateTemplate.find(query, nroMovApertura).get(0);
		return (montoTotal == null) ? BigDecimal.ZERO : montoTotal;
	}

	public BigDecimal getMontoPagadoInstrumento(Integer nroMovApertura) {
		String query = "SELECT SUM(p.haberMo - p.debeMo) FROM Pago p WHERE p.nroMovApe = ? AND "
				+ "p.cveEstadoPago = 'C' AND p.instrumento.codInstrumento <> 'CG'";
		BigDecimal totalPagado = (BigDecimal) hibernateTemplate.find(query, nroMovApertura).get(0);
		return (totalPagado == null) ? BigDecimal.ZERO : totalPagado;
	}

	public BigDecimal getSumaPlanPagos(Integer nroMovApertura) {
		String query = "SELECT sum(nvl(pp.interes, 0) + nvl(pp.capital, 0)) FROM PlanPago pp "
				+ "WHERE pp.id.nroMov = ? AND pp.cveEstadoPlan in ('N','P') ";

		Double valor = (Double) hibernateTemplate.find(query, nroMovApertura).get(0);
		return (BigDecimal.valueOf((valor == null ? Double.valueOf(0) : valor)));
	}

	public int getNroPagosPendientesImportacion(Persona entidad) {
		List<Pago> pagos = null;
		List<Apertura> aperturas = null;
		StringBuffer query = new StringBuffer("SELECT p FROM Apertura a, Pago p ");
		// StringBuffer query = new StringBuffer();
		// query.append(selectAperturas("I", null, entidad.getCodPersona(), "P",
		// "P", null));
		if (entidad.getCodPersona().trim().equals(CODIGO_PERSONA_BCB)) {
			query.append("WHERE a.nroMov = p.nroMovApe AND a.cveTipoApe = 'I' AND p.cveEstadoPago in ('P','1') ");
			pagos = hibernateTemplate.find(query.toString());
		} else {
			query.append("WHERE a.nroMov = p.nroMovApe AND a.cveTipoApe = 'I' AND p.cveEstadoPago = 'P' ");
			query.append("AND a.institucion IN (:instituciones) ");
			pagos = hibernateTemplate.findByNamedParam(query.toString(), "instituciones", entidad.getInstitucions());
		}
		return (pagos == null) ? 0 : pagos.size();
	}

	public List<Apertura> getAperturasConPagosPendientesImportacion(Persona entidad, String estadoPago) {
		List<Apertura> aperturas = null;
		StringBuffer query = new StringBuffer("SELECT DISTINCT a FROM Apertura a, Pago p ");
		query.append(
				"WHERE a.nroMov = p.nroMovApe AND a.cveEstadoApe = 'V' AND p.cveEstadoPago = '" + estadoPago + "' ");

		if (entidad.getCodPersona().trim().equals(CODIGO_PERSONA_BCB)) {
			query.append("ORDER BY a.nroMov DESC");
			aperturas = hibernateTemplate.find(query.toString());
		} else {
			query.append("AND a.institucion IN (:instituciones) ");
			query.append("ORDER BY a.nroMov DESC");
			aperturas = hibernateTemplate.findByNamedParam(query.toString(), "instituciones",
					entidad.getInstitucions());
		}
		return aperturas;
	}

	public List<Apertura> getAperturas(String tipoApertura, String estadoApertura, String tipoReg,
			String estadoRegistro, Persona entidad, Date fechaDesde, Date fechaHasta, String codConvenio) {
		List<Apertura> aperturas = null;
		StringBuffer query = new StringBuffer();
		query.append(selectAperturas(tipoApertura, estadoApertura, entidad.getCodPersona(), tipoReg, estadoRegistro,
				codConvenio));

		if (fechaDesde != null && fechaHasta != null) {
			if (insWhere)
				query.append("WHERE ");
			else
				query.append("AND ");
			query.append("a.fechaEmis BETWEEN ? AND ? ");
			query.append("ORDER BY a.nroMov DESC");
			log.info(query.toString());
			aperturas = hibernateTemplate.find(query.toString(), new Date[] { fechaDesde, fechaHasta });
		} else {
			query.append("ORDER BY a.nroMov DESC");
			log.info(query.toString());
			aperturas = hibernateTemplate.find(query.toString());
		}
		return aperturas;
	}

	public Patrimonio getMaxPatrimonio() {
		StringBuffer query = new StringBuffer();
		query.append("Select p FROM Patrimonio p WHERE p.nroOrden = (select max(p1.nroOrden) from Patrimonio p1)");

		List results = hibernateTemplate.find(query.toString());
		if (results.size() > 0) {
			return (Patrimonio) results.get(0);
		}
		return null; // TODO - Should I throw an exception instead?

	}

	public Patrimonio getPatrimonio(Integer nroOrden) {
		return (Patrimonio) hibernateTemplate.get(Patrimonio.class, nroOrden);
	}

	public List<Patrimonio> getPatrimonios(Date fechaDesde, Date fechaHasta) {
		StringBuffer query = new StringBuffer();
		query.append("Select p FROM Patrimonio p ");
		if (fechaDesde != null && fechaHasta != null) {
			query.append("where p.fechaAnterior BETWEEN ? AND ? ");
			query.append("ORDER BY p.nroOrden DESC");
			log.info("Query getPatrimonios " + query.toString());
			return hibernateTemplate.find(query.toString(), new Date[] { fechaDesde, fechaHasta });
		}
		query.append("ORDER BY p.nroOrden DESC");
		log.info("Query getPatrimonios " + query.toString());
		return hibernateTemplate.find(query.toString());
	}

	public List<DetPatrimonio> getDetPatrimonios(Integer nroOrden) {
		StringBuffer query = new StringBuffer();
		query.append("FROM DetPatrimonio p ");
		query.append("WHERE p.id.nroOrden = ? ");
		query.append("order by p.id.codPersona ");
		return hibernateTemplate.find(query.toString(), nroOrden);
	}

	public List<TPagoImp> getOpeNoRegistradas() {
		String query = "FROM TPagoImp p ORDER BY p.fecha1 DESC";
		return hibernateTemplate.find(query);
	}

	public Connection getConnection() {
		Connection connection = null;
		try {
			connection = SessionFactoryUtils.getDataSource(hibernateTemplate.getSessionFactory()).getConnection();
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
		}
		return connection;
	}

	public List<Map<String, Object>> ejecutarQueryMapas(String query) {
		log.info("Ejecutando Query: " + query);
		List<Map<String, Object>> mapDatos = null;
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			// no se usa el createSQLQuery de una Session porque el metodo list
			// de SQLQuery
			// convierte los campos tipo char de informix a objetos Character
			// java,
			// retornando s�lo el primer caracter de una campo tipo char, lo
			// cual es incorrecto.
			connection = SessionFactoryUtils.getDataSource(hibernateTemplate.getSessionFactory()).getConnection();

			statement = connection.createStatement();
			resultSet = statement.executeQuery(query);
			mapDatos = new ArrayList<Map<String, Object>>();
			int nroColumnas = resultSet.getMetaData().getColumnCount();
			ResultSetMetaData metaData = resultSet.getMetaData();
			while (resultSet.next()) {
				Map<String, Object> fila = new LinkedHashMap<String, Object>();
				for (int i = 1; i <= nroColumnas; i++)
					fila.put(metaData.getColumnLabel(i), resultSet.getObject(i));
				mapDatos.add(fila);
			}
			log.info("Query ejecutado satisfactoriamente.");
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (connection != null)
					connection.close();
			} catch (Exception e) {
				log.error("Error: " + e.getMessage(), e);
			}
		}
		return mapDatos;
	}

	public List<List<Object>> ejecutarQueryListas(String query) {
		List<Map<String, Object>> resultado = ejecutarQueryMapas(query);
		List<List<Object>> datos = new ArrayList<List<Object>>();
		for (Map<String, Object> fila : resultado) {
			List<Object> registro = new ArrayList<Object>();
			Set<Entry<String, Object>> entries = fila.entrySet();
			for (Entry<String, Object> entry : entries)
				registro.add(entry.getValue());
			datos.add(registro);
		}
		return datos;
	}

	public boolean ejecutarDml(String sentenciaDml) {
		log.info("Ejecutando sentencia: " + sentenciaDml);
		boolean ejecucionCorrecta = false;
		try {
			Session session = hibernateTemplate.getSessionFactory().openSession();
			session.createSQLQuery(sentenciaDml).executeUpdate();
			session.close();
			ejecucionCorrecta = true;
			log.info("Sentencia ejecutada satisfactoriamente.");
		} catch (Exception e) {
			log.error("ocurrio un error al ejecutar la sentencia." + e);
			log.error("Error: " + e.getMessage(), e);
		}
		return ejecucionCorrecta;
	}

	public Date getFechaActual() {
		return new Date();
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	public ServiceDao getServiceDao() {
		return serviceDao;
	}

	public void setServiceDao(ServiceDao serviceDao) {
		this.serviceDao = serviceDao;
	}
}
