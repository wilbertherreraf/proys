/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-portletBase
 * gob.bcb.portal.sirAladi.parametros.logica.MaestroDetalle
 * 08/07/2011 - 10:56:58
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.parametros.logica;

/**
 * Clase que tiene la configuracion de una tabla maestro detalle
 *
 *
 * @author wherrera
 *
 */
public class MaestroDetalle
{
	private String tablaPadre;
	private String tablaHijo;
	private String joinColumnaPadre;
	private String joinColumnaHijo;
	
	public MaestroDetalle(Object tablaPadre, Object tablaHijo,
			Object joinColumnaPadre, Object joinColumnaHijo)
	{
		super();
		this.tablaPadre = ((String) tablaPadre).trim();
		this.tablaHijo = ((String) tablaHijo).trim();
		this.joinColumnaPadre = ((String) joinColumnaPadre).trim();
		this.joinColumnaHijo = ((String) joinColumnaHijo).trim();
	}
	public String getTablaPadre()
	{
		return tablaPadre;
	}
	public void setTablaPadre(String tablaPadre)
	{
		this.tablaPadre = tablaPadre;
	}
	public String getTablaHijo()
	{
		return tablaHijo;
	}
	public void setTablaHijo(String tablaHijo)
	{
		this.tablaHijo = tablaHijo;
	}
	public String getJoinColumnaPadre()
	{
		return joinColumnaPadre;
	}
	public void setJoinColumnaPadre(String joinColumnaPadre)
	{
		this.joinColumnaPadre = joinColumnaPadre;
	}
	public String getJoinColumnaHijo()
	{
		return joinColumnaHijo;
	}
	public void setJoinColumnaHijo(String joinColumnaHijo)
	{
		this.joinColumnaHijo = joinColumnaHijo;
	}
}
