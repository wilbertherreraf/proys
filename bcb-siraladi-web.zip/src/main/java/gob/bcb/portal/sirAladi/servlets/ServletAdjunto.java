/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-web-sirAladi
 * gob.bcb.portal.sirAladi.servlets.ServletReportePDF
 * 30/09/2011 - 11:25:57
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.servlets;

import gob.bcb.bpm.siraladi.jpa.Adjunto;
import gob.bcb.portal.sirAladi.commons.Archivo;
import gob.bcb.portal.sirAladi.dao.DaoFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;

import javax.faces.context.FacesContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

/**
 * Servlet que despliega un archivo.
 * 
 * @author wherrera
 * 
 */
public class ServletAdjunto extends HttpServlet {
	private static Logger log = Logger.getLogger(ServletAdjunto.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest
	 * , javax.servlet.http.HttpServletResponse)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.desplegarReporte(request, response);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest
	 * , javax.servlet.http.HttpServletResponse)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.desplegarReporte(request, response);
	}

	/**
	 * M�todo que despliega un documento.
	 * 
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	private void desplegarReporte(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = null;
		PrintWriter out = null;
		String msjError = null;

		try {
			// recuperacion de variables guardadas en sesion.
			Integer nroMov = null;
			Archivo archivo = null;
			do {
				session = request.getSession();
				nroMov = (Integer) session.getAttribute("nroMov");
				archivo = (Archivo) session.getAttribute("adjunto");
			} while (nroMov == null && archivo == null);
			
			if (session.getAttribute("nroMov") != null) {
				nroMov = (Integer) session.getAttribute("nroMov");
				archivo = obtenerAdjunto(nroMov);
				int read = 0;
				byte[] bytes = new byte[1024];
				response.setContentType(archivo.getMime());
				response.setHeader("Content-Disposition", "inline; filename=\"" + archivo.getNombre() + "\"");
				FileInputStream fis = null;
				OutputStream os = null;
			
				// Agregamos la ruta principal y la concatenamos
				fis = new FileInputStream(new File(archivo.getPath()));
				os = response.getOutputStream();
				while ((read = fis.read(bytes)) != -1) {
					os.write(bytes, 0, read);
				}
				os.flush();
				os.close();
				
			} else{
				archivo = (Archivo) session.getAttribute("adjunto");
				ServletOutputStream ouputStream = response.getOutputStream();
				response.setContentType(archivo.getMime());
				response.setContentLength(archivo.getLength());
				response.setHeader("Content-Disposition","inline; filename=\"" + archivo.getNombre()+"\"");
				ouputStream.write(archivo.getData(), 0, archivo.getLength());
				ouputStream.flush();
				ouputStream.close();				
			}


			// This option isn't quite necessary, It worked for me with or
			// without it
			try {
				FacesContext.getCurrentInstance().responseComplete();
			} catch (Exception e) {
			}
		} catch (FileNotFoundException e) {
			msjError = "No se encontr� ning�n archivo adjunto para este instrumento.";
			log.error(msjError, e);
		} catch (Exception e) {
			msjError = "Ocurri� un error al desplegar el archivo adjunto.";
			log.error(msjError, e);
		} finally {
			if (session != null) {
				session.removeAttribute("nroMov");
				session.removeAttribute("adjunto");
			}
			if (msjError != null) {
				try {
					response.setContentType("text/html; charset=iso-8859-1");
					out = response.getWriter();
					out.println("<html><body><center><br/><br/><h4>");
					out.println(msjError);
					out.println("</h4></center></body></html>");
					out.flush();
					out.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
	private void desplegarReporte0(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = null;
		PrintWriter out = null;
		String msjError = null;

		try {
			// recuperacion de variables guardadas en sesion.
			Integer nroMov = null;
			Archivo archivo = null;
			do {
				session = request.getSession();
				nroMov = (Integer) session.getAttribute("nroMov");
				archivo = (Archivo) session.getAttribute("adjunto");
			} while (nroMov == null && archivo == null);
			
			if (session.getAttribute("nroMov") != null) {
				nroMov = (Integer) session.getAttribute("nroMov");
				archivo = new Archivo();
				
				//archivo.recuperarAdjunto(nroMov);
					
				ServletOutputStream ouputStream = response.getOutputStream();
				response.setContentType(archivo.getMime());
				response.setHeader("Content-Disposition", "inline; filename=\"" + archivo.getNombre() + "\"");
				ouputStream.write(archivo.getData(),0,archivo.getData().length);
				ouputStream.flush();
				ouputStream.close();
				
			} else{
				archivo = (Archivo) session.getAttribute("adjunto");
				ServletOutputStream ouputStream = response.getOutputStream();
				response.setContentType(archivo.getMime());
				response.setContentLength(archivo.getLength());
				response.setHeader("Content-Disposition","inline; filename=\"" + archivo.getNombre()+"\"");
				ouputStream.write(archivo.getData(), 0, archivo.getLength());
				ouputStream.flush();
				ouputStream.close();				
			}


			// This option isn't quite necessary, It worked for me with or
			// without it
			try {
				FacesContext.getCurrentInstance().responseComplete();
			} catch (Exception e) {
			}
		} catch (FileNotFoundException e) {
			msjError = "No se encontro ningun archivo adjunto para este instrumento.";
			log.error(msjError, e);
		} catch (Exception e) {
			msjError = "Ocurrio un error al desplegar el archivo adjunto.";
			log.error(msjError, e);
		} finally {
			if (session != null) {
				session.removeAttribute("nroMov");
				session.removeAttribute("adjunto");
			}
			if (msjError != null) {
				try {
					response.setContentType("text/html; charset=iso-8859-1");
					out = response.getWriter();
					out.println("<html><body><center><br/><br/><h4>");
					out.println(msjError);
					out.println("</h4></center></body></html>");
					out.flush();
					out.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
	private Archivo obtenerAdjunto(int nroMov) throws Exception {
		Archivo archivo = null;
		try {
			Adjunto adjunto = DaoFactory.getInstance().getSirAladiDao().getAdjunto(nroMov);
			if (adjunto == null)
				throw new FileNotFoundException("No se encontro ningon archivo adjunto para este instrumento.");
			archivo = new Archivo();
			archivo.setPath(adjunto.getRutaArchivo().trim());
			archivo.setNombreMimeExtension(adjunto.getRutaArchivo().trim(), "");
		} catch (FileNotFoundException e) {
			throw new FileNotFoundException("No existe ningun documento adjunto." + nroMov);
		} catch (Exception e) {
			throw new Exception(e);
		}
		return archivo;
	}

}
