/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-web-sirAladi
 * gob.bcb.portal.sirAladi.operacionesBCB.controller.MonitorOpeNoRegController
 * 04/10/2011 - 10:56:28
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.operacionesBCB.controller;

import static gob.bcb.portal.sirAladi.commons.Constantes.SUCCESS;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Instrumento;
import gob.bcb.bpm.siraladi.jpa.Pais;
import gob.bcb.bpm.siraladi.jpa.TPagoImp;
import gob.bcb.bpm.siraladi.pojo.StatusResponse;
import gob.bcb.portal.sirAladi.commons.AladiUtils;
import gob.bcb.portal.sirAladi.commons.Servicios;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;
import gob.bcb.portal.sirAladi.dao.DaoFactory;
import gob.bcb.portal.sirAladi.dao.SirAladiDao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;

/**
 * Backing bean de la vista de monitoreo de operaciones no registradas.
 * 
 * @author wherrera
 * 
 */
public class MonitorOpeNoRegController extends BaseBeanController {
	private String msj;

	private SirAladiDao sirAladiDao;
	private List<TPagoImp> listaTPagosImp = new ArrayList<TPagoImp>();
	private Map<String, String> mapInstituciones = new HashMap<String, String>();
	private Map<String, String> mapPaises = new HashMap<String, String>();
	private Map<String, String> mapInstrumentos = new HashMap<String, String>();

	private static Logger log = Logger.getLogger(MonitorOpeNoRegController.class);

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public MonitorOpeNoRegController() {

	}

	@PostConstruct
	public void init() {
		log.info("Iniciando el modulo de monitoreo de operaciones no registradas.");
		recuperarVisit();
		this.sirAladiDao = DaoFactory.getInstance().getSirAladiDao();
		this.listaTPagosImp = this.sirAladiDao.getOpeNoRegistradas();

		if (this.listaTPagosImp != null && this.listaTPagosImp.size() > 0) {
			// map con descripcion de instituciones
			Set<String> setCodigossInst = new HashSet<String>();
			for (TPagoImp pagoImp : this.listaTPagosImp) {
				if (!setCodigossInst.contains(pagoImp.getCodInst()))
					setCodigossInst.add(pagoImp.getCodInst());
				if (!setCodigossInst.contains(pagoImp.getCodInstRecep()))
					setCodigossInst.add(pagoImp.getCodInstRecep());
			}
			List<Institucion> instituciones = this.sirAladiDao.getInstituciones(new ArrayList(setCodigossInst));
			for (Institucion institucion : instituciones)
				this.mapInstituciones.put(institucion.getCodInst(), institucion.getNomInst().trim());

			// map con descripcion de paises
			List<Pais> paises = this.sirAladiDao.getPaises();
			for (Pais pais : paises)
				this.mapPaises.put(pais.getCodPais(), pais.getNomPais().trim());

			// map con descripcion de instrumentos
			List<Instrumento> instrumentos = this.sirAladiDao.getInstrumentos();
			for (Instrumento instrumento : instrumentos)
				this.mapInstrumentos.put(instrumento.getCodInstrumento(), instrumento.getNomInstrumento().trim());
		}

	}

	public String getMsj() {
		return msj;
	}

	public List<TPagoImp> getListaTPagosImp() {
		return listaTPagosImp;
	}

	public Map<String, String> getMapInstituciones() {
		return mapInstituciones;
	}

	public Map<String, String> getMapPaises() {
		return mapPaises;
	}

	public Map<String, String> getMapInstrumentos() {
		return mapInstrumentos;
	}

	public void autorizarTPagoImp(TPagoImp tPagoImpSel) {
		this.msj = "";
		TPagoImp tPagoImp = tPagoImpSel;
		StatusResponse statusResponse = Servicios.guardarOperacionNoRegistrada(tPagoImp, true);
		if (statusResponse.getStatusCode().equals(SUCCESS)) {
				StatusResponse statusResponse1 = Servicios.guardarOperacionNoRegistrada(tPagoImp, false);
				if (!statusResponse1.getStatusCode().equals(SUCCESS))
					statusResponse = statusResponse1;
			this.listaTPagosImp = this.sirAladiDao.getOpeNoRegistradas();
		}
		this.msj = AladiUtils.getAlertJS(statusResponse);
	}
	
	public void eliminarTPagoImp(TPagoImp tPagoImpSel) {
		this.msj = "";
		TPagoImp tPagoImp = tPagoImpSel;
		StatusResponse statusResponse = Servicios.guardarOperacionNoRegistrada(tPagoImp, false);
		if (statusResponse.getStatusCode().equals(SUCCESS)) {
			this.listaTPagosImp = this.sirAladiDao.getOpeNoRegistradas();
		}
		this.msj = AladiUtils.getAlertJS(statusResponse);
	}

}
