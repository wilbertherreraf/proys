/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-web-sirAladi
 * gob.bcb.portal.sirAladi.reportes.controller.RepOperacionesController
 * 04/10/2011 - 10:56:28
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.reportes.controller;

import static gob.bcb.portal.sirAladi.commons.AladiUtils.dateToString;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.getAlertJS;
import static gob.bcb.portal.sirAladi.commons.Constantes.CODIGO_PERSONA_BCB;
import static gob.bcb.portal.sirAladi.commons.Constantes.FORMATO_FECHA_JAVA;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

/**
 * Backing bean de la vista de consulta de operaciones.
 * 
 * @author wherrera
 * 
 */
public class RepOperacionesController extends BaseBeanController {
	private static Logger log = Logger.getLogger(RepOperacionesController.class);
	
	private Date fechaDesde;
	private Date fechaAl;
	private String queryRegistro;
	private String queryPago;
	private String queryPlanPagos;

	private List<List<Object>> listaRegistro;
	private List<List<Object>> listaPago;
	private List<List<Object>> listaPlanPago;

	public RepOperacionesController() {
	}

	@PostConstruct
	public void init() {
		log.info("Iniciando el modulo de consulta de operaciones realizadas.");
		recuperarVisit();
		this.crearObjetosPorDefecto();

		try {
			this.cargarCombos();
		} catch (Exception e) {
			log.error("Ocurrio un error: " + e.getMessage(), e);
		}
		if (getVisit().getParametro("SIRWEB_TMP_OBJECT") != null) {
			if (!(getVisit().getParametro("SIRWEB_TMP_OBJECT") instanceof RepOperacionesController)) {
				//getVisit().removeParametro("SIRWEB_TMP_OBJECT");
			} else {
				RepOperacionesController repOperacionesController = (RepOperacionesController) getVisit().getParametro("SIRWEB_TMP_OBJECT");
				this.fechaDesde = repOperacionesController.getFechaDesde();
				this.fechaAl = repOperacionesController.getFechaAl();
				this.listaRegistro = repOperacionesController.getListaRegistro();
				this.listaPago = repOperacionesController.getListaPago();
				this.listaPlanPago = repOperacionesController.getListaPlanPago();
			}
		}
	}

	public Date getFechaDesde() {
		return fechaDesde;
	}

	public void setFechaDesde(Date fechaDesde) {
		this.fechaDesde = fechaDesde;
	}

	public Date getFechaAl() {
		return fechaAl;
	}

	public void setFechaAl(Date fechaAl) {
		this.fechaAl = fechaAl;
	}

	public List<List<Object>> getListaRegistro() {
		return listaRegistro;
	}

	public List<List<Object>> getListaPago() {
		return listaPago;
	}

	public void armarConsulta() {
		String codPersona = getVisit().getUsuarioSirAladi().getPersona().getCodPersona().trim();
		Calendar fechaAl = GregorianCalendar.getInstance();
		fechaAl.setTime(this.fechaDesde);
		String strFechaDesde = " mdy(" + (fechaAl.get(Calendar.MONTH) + 1) + "," + fechaAl.get(Calendar.DAY_OF_MONTH) + ","
				+ fechaAl.get(Calendar.YEAR) + ") ";
		fechaAl.setTime(this.fechaAl);
		String strFechaAl = " mdy(" + (fechaAl.get(Calendar.MONTH) + 1) + "," + fechaAl.get(Calendar.DAY_OF_MONTH) + "," + fechaAl.get(Calendar.YEAR)
				+ ") ";

		StringBuffer qryRegistro = new StringBuffer();
		qryRegistro.append("SELECT ");
		qryRegistro.append("    TRIM(a.cod_inst)||'-'||TRIM(a.cod_id)||'-'||TRIM(a.anio)||'-'||TRIM(a.secuencia)||'-'||dav cod_reembolso, ");
		qryRegistro
				.append("    (select trim(cla.interp) from claves cla where cla.nomdato = 'cve_tipo_ape' and cla.valdato = a.cve_tipo_ape) tipo_ape, ");
		qryRegistro.append("    (case when a.cve_tipo_ape = 'I' then ");
		qryRegistro.append("            (select TRIM(nom_pais) from pais where cod_pais = a.cod_pais) ");
		qryRegistro.append("        else ");
		qryRegistro
				.append("            (select TRIM(pa.nom_pais) from pais pa, institucion i where pa.cod_pais = i.cod_pais and i.cod_inst = a.cod_inst) ");
		qryRegistro.append("    end) pais, ");
		qryRegistro.append("    (select TRIM(i.nom_inst) from institucion i where i.cod_inst = a.cod_inst) ifa_emisora, ");
		qryRegistro.append("    (select TRIM(i.nom_inst) from institucion i where i.cod_inst = r.cod_inst_recep) ifa_recep, ");
		qryRegistro
				.append("    (select trim(cla.interp) from claves cla where cla.nomdato = 'cve_tipo_emis' and cla.valdato = r.cve_tipo_emis) operacion, ");
		qryRegistro.append("    DECODE(r.cve_tipo_emis, 'D', r.haber_mo - r.debe_mo, r.debe_mo - r.haber_mo) monto, ");
		qryRegistro
				.append("    (select trim(cla.interp) from claves cla where cla.nomdato = 'cve_estado_reg' and cla.valdato = r.cve_estado_reg) estado, ");
		qryRegistro.append("    r.fecha_trans fecha ");
		qryRegistro.append("FROM    registro r,    apertura a ");
		qryRegistro.append("WHERE  r.nro_mov_ape = a.nro_mov ");
		qryRegistro.append("and r.fecha_trans BETWEEN " + strFechaDesde + " AND " + strFechaAl + " ");

		if (!codPersona.equals(CODIGO_PERSONA_BCB)) {
			qryRegistro.append("AND ((a.cve_Tipo_Ape = 'I' AND exists (select 1  ");
			qryRegistro.append("    from Persona_Inst pi WHERE pi.cod_Inst = a.cod_Inst AND pi.cod_Persona = '" + codPersona + "'))   ");
			qryRegistro.append("    OR (a.cve_Tipo_Ape = 'E' AND exists (select 1  ");
			qryRegistro.append("                                from Persona_Inst pi ");
			qryRegistro.append("				WHERE pi.cod_Inst = r.cod_Inst_recep ");
			qryRegistro.append("				AND pi.cod_Persona = '" + codPersona + "')) ");
			qryRegistro.append(") ");
		}
		qryRegistro.append("ORDER BY 9, 1,2,4 ");
		this.queryRegistro = qryRegistro.toString();
		
		StringBuffer qPago = new StringBuffer();
		qPago.append("SELECT ");
		qPago.append("    TRIM(a.cod_inst)||'-'||TRIM(a.cod_id)||'-'||TRIM(a.anio)||'-'||TRIM(a.secuencia)||'-'||dav cod_reembolso, ");
		qPago
				.append("    (select trim(cla.interp) from claves cla where cla.nomdato = 'cve_tipo_ape' and cla.valdato = a.cve_tipo_ape) tipo_ape, ");
		qPago.append("    (case when a.cve_tipo_ape = 'I' then ");
		qPago.append("            (select TRIM(nom_pais) from pais where cod_pais = a.cod_pais) ");
		qPago.append("        else ");
		qPago
				.append("            (select TRIM(pa.nom_pais) from pais pa, institucion i where pa.cod_pais = i.cod_pais and i.cod_inst = a.cod_inst) ");
		qPago.append("    end) pais, ");
		qPago.append("    (select TRIM(i.nom_inst) from institucion i where i.cod_inst = a.cod_inst) ifa_emisora, ");
		qPago.append("    (select TRIM(i.nom_inst) from institucion i where i.cod_inst = r.cod_inst_recep) ifa_recep, ");
		qPago.append("    TRIM(r.cod_instrumento) instrumento, ");
		qPago.append("    (r.haber_mo - r.debe_mo) monto, ");
		qPago
				.append("    (select trim(cla.interp) from claves cla where cla.nomdato = 'cve_estado_pago' and cla.valdato = r.cve_estado_pago) estado, ");
		qPago.append("    r.fecha_cargo fecha ");
		qPago.append("FROM    apertura a, pago r ");
		qPago.append("WHERE  a.nro_mov = r.nro_mov_ape ");
		qPago.append("and r.fecha_cargo BETWEEN " + strFechaDesde + " AND " + strFechaAl + " ");

		if (!codPersona.equals(CODIGO_PERSONA_BCB)) {
			qPago.append("AND ((a.cve_Tipo_Ape = 'I' AND exists (select 1  ");
			qPago.append("    from Persona_Inst pi WHERE pi.cod_Inst = a.cod_Inst AND pi.cod_Persona = '" + codPersona + "'))   ");
			qPago.append("    OR (a.cve_Tipo_Ape = 'E' AND exists (select 1  ");
			qPago.append("                                from Persona_Inst pi ");
			qPago.append("				WHERE pi.cod_Inst = r.cod_Inst_recep ");
			qPago.append("				AND pi.cod_Persona = '" + codPersona + "'))   ");
			qPago.append(") ");
		}
		qPago.append("ORDER BY   9, 1,2,4 ");
		this.queryPago = qPago.toString();

		StringBuffer qryPlanPagos = new StringBuffer();
		qryPlanPagos.append("select ");
		qryPlanPagos.append("TRIM(a.cod_inst)||'-'||TRIM(a.cod_id)||'-'||TRIM(a.anio)||'-'||TRIM(a.secuencia)||'-'||dav cod_reembolso, ");
		qryPlanPagos
				.append("(select trim(cla.interp) from claves cla where cla.nomdato = 'cve_tipo_ape' and cla.valdato = a.cve_tipo_ape) tipo_ape, ");
		qryPlanPagos.append("(case when a.cve_tipo_ape = 'I' then ");
		qryPlanPagos.append("            (select TRIM(nom_pais) from pais where cod_pais = a.cod_pais) ");
		qryPlanPagos.append("        else ");
		qryPlanPagos
				.append("            (select TRIM(pa.nom_pais) from pais pa, institucion i where pa.cod_pais = i.cod_pais and i.cod_inst = a.cod_inst) ");
		qryPlanPagos.append("    end) pais, ");
		qryPlanPagos.append("    (select TRIM(i.nom_inst) from institucion i where i.cod_inst = a.cod_inst) ifa_emisora, ");
		qryPlanPagos.append("    pp.fecha_neg fecha_neg, ");
		qryPlanPagos.append("    pp.fecha_val fecha_val, ");
		qryPlanPagos.append("    pp.capital capital, ");
		qryPlanPagos.append("    pp.interes interes, ");
		qryPlanPagos
				.append("    (select trim(cla.interp) from claves cla where cla.nomdato = 'cve_estado_plan' and cla.valdato = pp.cve_estado_plan) estado, ");
		qryPlanPagos.append("    date(pp.fecha_hora) fecha ");		
		qryPlanPagos.append("from apertura a, plan_pago pp ");
		qryPlanPagos.append("where a.nro_mov = pp.nro_mov ");
		qryPlanPagos.append("and date(pp.fecha_hora) between " + strFechaDesde + " AND " + strFechaAl + " ");

		if (!codPersona.equals(CODIGO_PERSONA_BCB)) {
			qryPlanPagos.append("and ((a.cve_Tipo_Ape = 'I' AND exists (select 1 from Persona_Inst pi WHERE pi.cod_Inst = a.cod_Inst ");
			qryPlanPagos.append("                                            AND pi.cod_Persona = '" + codPersona + "')) ");
			qryPlanPagos.append("OR (a.cve_Tipo_Ape = 'E' AND exists (select 1 from Persona_Inst pi, Registro r ");
			qryPlanPagos.append("				WHERE pi.cod_Inst = r.cod_Inst_recep ");
			qryPlanPagos.append("				AND r.nro_Mov_ape = a.nro_Mov AND r.cve_Tipo_Emis = 'E' ");
			qryPlanPagos.append("				AND pi.cod_Persona = '" + codPersona + "')) ");
			qryPlanPagos.append(") ");
		}
		qryPlanPagos.append("order by pp.fecha_hora, 1 ");

		this.queryPlanPagos = qryPlanPagos.toString();

		StringBuffer qryPagoAnt = new StringBuffer();
		if (codPersona.equals(CODIGO_PERSONA_BCB)) {

			qryPagoAnt.append("select TRIM(a.cod_inst)||'-'||TRIM(a.cod_id)||'-'||TRIM(a.anio)||'-'||TRIM(a.secuencia)||'-'||dav cod_reembolso, ");
			qryPagoAnt
					.append("(select trim(cla.interp) from claves cla where cla.nomdato = 'cve_tipo_ape' and cla.valdato = a.cve_tipo_ape) tipo_ape,  ");
			qryPagoAnt.append("(case when a.cve_tipo_ape = 'I' then  ");
			qryPagoAnt
					.append("    (select TRIM(pa.nom_pais) from pais pa, institucion i where pa.cod_pais = i.cod_pais and i.cod_inst = a.cod_inst_recep)  ");
			qryPagoAnt.append("else  ");
			qryPagoAnt
					.append("    (select TRIM(pa.nom_pais) from pais pa, institucion i where pa.cod_pais = i.cod_pais and i.cod_inst = a.cod_inst)  ");
			qryPagoAnt.append("end) pais, ");
			qryPagoAnt.append("(case when a.cve_tipo_ape = 'I' then  ");
			qryPagoAnt.append("    (select TRIM(i.nom_inst) from institucion i where i.cod_inst = a.cod_inst_recep)  ");
			qryPagoAnt.append("else  ");
			qryPagoAnt.append("    (select TRIM(i.nom_inst) from institucion i where i.cod_inst = a.cod_inst_recep) ");
			qryPagoAnt.append("end) ifa_emisora, ");
			qryPagoAnt
					.append("(select trim(cla.interp) from claves cla where cla.nomdato = 'cve_estado_ant' and cla.valdato = a.cve_estado_ant) estado, ");
			qryPagoAnt.append("(debe_mo + haber_mo) monto, ");
			qryPagoAnt.append("fecha_cargo fecha ");
			qryPagoAnt.append("from reg_anticipado a ");
			qryPagoAnt.append("where fecha_cargo between " + strFechaDesde + " AND " + strFechaAl + " ");
			qryPagoAnt.append("order by 7,1,2 ");
		}
	}

	public void recuperarOperaciones(ActionEvent event) {
		armarConsulta();
		this.listaRegistro = getSirAladiDao().ejecutarQueryListas(queryRegistro.toString());
		this.listaPago = getSirAladiDao().ejecutarQueryListas(queryPago.toString());
		this.listaPlanPago = getSirAladiDao().ejecutarQueryListas(queryPlanPagos.toString());
		
		if (!((this.listaRegistro != null && this.listaRegistro.size() > 0) || (this.listaPago != null && this.listaPago.size() > 0)|| (this.listaPlanPago != null && this.listaPlanPago.size() > 0)))
			getAlertJS("No hay operaciones realizadas entre el " + dateToString(this.fechaDesde, FORMATO_FECHA_JAVA) + " y el "
					+ dateToString(this.fechaAl, FORMATO_FECHA_JAVA) + ".");
		getVisit().setParametro("SIRWEB_TMP_OBJECT", this);
	}

	public void mostrarReporte(ActionEvent event) {
		StringBuffer query = new StringBuffer();
		String codPersona = getVisit().getUsuarioSirAladi().getPersona().getCodPersona().trim();
		if (codPersona.equals(CODIGO_PERSONA_BCB)) {
			query.append("SELECT cod_persona, nom_persona from persona where cve_vigente = 'V' order by nom_persona");			
		}else{
			query.append("SELECT cod_persona, nom_persona from persona where cod_Persona = '" + codPersona + "' order by nom_persona");
		}
		
		armarConsulta();
		String strFechaDesde = dateToString(this.fechaDesde, FORMATO_FECHA_JAVA);
		String strFechaAl = dateToString(this.fechaAl, FORMATO_FECHA_JAVA);
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("FECHA_DESDE", this.fechaDesde);
		parametros.put("FECHA_HASTA", this.fechaAl);		
		parametros.put("QUERY_PERSONA", query.toString());
		parametros.put("TITULO", "OPERACIONES REALIZADAS DEL " + strFechaDesde + " AL " + strFechaAl);
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("pathTranslated", request.getPathTranslated());
		request.getSession().setAttribute("nombreReporte", "repOperacionesIFA.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}
	public void mostrarReporteDiff(ActionEvent event) {
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("TITULO", "DIFERENCIAS EN REGISTROS");
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("pathTranslated", request.getPathTranslated());
		request.getSession().setAttribute("nombreReporte", "repDiferenciasPlanPag.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}

	public void limpiar(ActionEvent event) {
		this.crearObjetosPorDefecto();
		getVisit().removeParametro("SIRWEB_TMP_OBJECT");
	}

	private void crearObjetosPorDefecto() {
		this.listaRegistro = null;
		this.listaPago = null;
		this.listaPlanPago = null;
		Date fecha = getSirAladiDao().getFechaActual();
		this.fechaDesde = fecha;
		this.fechaAl = fecha;
	}

	private void cargarCombos() {
	}

	public void setQueryPlanPagos(String queryPlanPagos) {
		this.queryPlanPagos = queryPlanPagos;
	}

	public String getQueryPlanPagos() {
		return queryPlanPagos;
	}

	public void setListaPlanPago(List<List<Object>> listaPlanPago) {
		this.listaPlanPago = listaPlanPago;
	}

	public List<List<Object>> getListaPlanPago() {
		return listaPlanPago;
	}
}
