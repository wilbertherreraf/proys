/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-sirAladi
 * gob.bcb.portal.sirAladi.operacionesBCB.controller.PagosAnticipadosImpController
 * 27/09/2011 - 10:54:47
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.operacionesBCB.controller;

import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarMapDescripcionClaves;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.dateToString;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.getAlertJS;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.getInicioCuatrimestre;
import static gob.bcb.portal.sirAladi.commons.Constantes.CODIGO_ID_PAGO_ANTICIPADO;
import static gob.bcb.portal.sirAladi.commons.Constantes.CODIGO_INSTITUCION_BCB;
import static gob.bcb.portal.sirAladi.commons.Constantes.CODIGO_INSTRUMENTO_PAGO_ANTICIPADO;
import static gob.bcb.portal.sirAladi.commons.Constantes.CODIGO_MONEDA_DOLARES;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_ESTADO_PAGO_ANT;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTADO_CONTABILIZADO;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTADO_PENDIENTE;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTILO_INVISIBLE;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTILO_VISIBLE;
import static gob.bcb.portal.sirAladi.commons.Constantes.FORMATO_FECHA_JAVA;
import static gob.bcb.portal.sirAladi.commons.Constantes.SUCCESS;
import static gob.bcb.portal.sirAladi.commons.Constantes.TIPO_APERTURA_IMPORTACION;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.RegAnticipado;
import gob.bcb.bpm.siraladi.jpa.SwfMensaje;
import gob.bcb.bpm.siraladi.pojo.SaldoConvenio;
import gob.bcb.bpm.siraladi.pojo.StatusResponse;
import gob.bcb.portal.sirAladi.commons.AladiUtils;
import gob.bcb.portal.sirAladi.commons.Constantes;
import gob.bcb.portal.sirAladi.commons.Servicios;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

/**
 * Backin Bean de la vista de pagos anticipados.
 * 
 * @author wherrera
 * 
 */

public class PagosAnticipadosImpController extends BaseBeanController {
	private static Logger log = Logger.getLogger(PagosAnticipadosImpController.class);
	private String msj;
	private String codPais;
	private Date fechaDesde;
	private Date fechaHasta;
	private Date fechaAl;
	private String cuentaAoB;

	private SaldoConvenio saldo;
	private SaldoConvenio totalSaldo;
	private RegAnticipado pagoAnticipado;

	private List<SaldoConvenio> saldos;
	private List<RegAnticipado> pagosAnticipados;
	private List<List<Object>> listaDetalleSaldo;
	private List<BigDecimal> listaTotalDetalleSaldo;
	private Map<String, String> mapPaisesBancos;
	private Map<String, String> mapEstado;

	@PostConstruct
	public void init() {
		log.info("Iniciando el modulo de pagos anticipados - importaciones.");
		recuperarVisit();
		if (getVisit().getParametro("SIRWEB_TMP_OBJECT") != null) {
			if (!(getVisit().getParametro("SIRWEB_TMP_OBJECT") instanceof PagosAnticipadosImpController)) {
				// getVisit().removeParametro("SIRWEB_TMP_OBJECT");
			} else {
				PagosAnticipadosImpController pagosAnticipadosImpController = ((PagosAnticipadosImpController) getVisit().getParametro(
						"SIRWEB_TMP_OBJECT"));
				this.saldos = pagosAnticipadosImpController.getSaldos();
				this.fechaAl = pagosAnticipadosImpController.getFechaAl();
				this.fechaDesde = pagosAnticipadosImpController.getFechaDesde();
				this.fechaHasta = pagosAnticipadosImpController.getFechaHasta();
				this.codPais = pagosAnticipadosImpController.getCodPais();
				this.cuentaAoB = pagosAnticipadosImpController.getCuentaAoB();
			}
		}
		crearObjetosPorDefecto();
		recuperarDatos();
	}

	private void recuperarDatos() {
		pagosAnticipados = getSirAladiDao().getPagosAnticipados(TIPO_APERTURA_IMPORTACION, ESTADO_PENDIENTE);
	}

	public List<SaldoConvenio> getSaldos() {
		return saldos;
	}

	public void setSaldos(List<SaldoConvenio> saldos) {
		this.saldos = saldos;
	}

	public SaldoConvenio getSaldo() {
		return saldo;
	}

	public void setSaldo(SaldoConvenio saldo) {
		this.saldo = saldo;
	}

	public SaldoConvenio getTotalSaldo() {
		return totalSaldo;
	}

	public void setTotalSaldo(SaldoConvenio totalSaldo) {
		this.totalSaldo = totalSaldo;
	}

	public List<RegAnticipado> getPagosAnticipados() {
		return pagosAnticipados;
	}

	public void setPagosAnticipados(List<RegAnticipado> pagosAnticipados) {
		this.pagosAnticipados = pagosAnticipados;
	}

	public List<List<Object>> getListaDetalleSaldo() {

		String strFechaAl = AladiUtils.dateToString(this.fechaAl, FORMATO_FECHA_JAVA);
		String queryDetalle = "SELECT DISTINCT TRIM(e.nom_pais) pais, " + "TRIM(a.nom_persona) institucion, "
				+ "c.cod_inst||'-'||c.cod_id||'-'||TRIM(c.anio)||'-'||TRIM(c.secuencia)||'-'||c.dav num_reembolso, " + "d.fecha_val fecha_pago, "
				+ "d.capital  capital, " + "d.interes interes, " + "d.monto  total "
				+ "FROM persona a, persona_inst b, apertura c, plan_pago d, pais e " + "WHERE a.cod_persona = b.cod_persona "
				+ "AND b.cod_inst = c.cod_inst " + "AND c.nro_mov = d.nro_mov " + "AND d.cve_estado_plan NOT IN ('C','S') "
				+ "AND c.cod_pais = e.cod_pais " + "AND c.cve_estado_ape = 'V' " + "AND e.cod_pais LIKE '" + this.codPais + "' "
				+ "AND d.fecha_val <= to_date('" + strFechaAl + "', '%d/%m/%Y') " + "AND c.cve_tipo_ape = 'I' " + "ORDER BY 1, 2, 3 DESC";
		this.listaDetalleSaldo = getSirAladiDao().ejecutarQueryListas(queryDetalle);

		this.listaTotalDetalleSaldo = Arrays.asList(new BigDecimal[] { BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO });
		for (List<Object> item : this.listaDetalleSaldo) {
			this.listaTotalDetalleSaldo.set(0, this.listaTotalDetalleSaldo.get(0).add((BigDecimal) item.get(4)));
			this.listaTotalDetalleSaldo.set(1, this.listaTotalDetalleSaldo.get(1).add((BigDecimal) item.get(5)));
			this.listaTotalDetalleSaldo.set(2, this.listaTotalDetalleSaldo.get(2).add((BigDecimal) item.get(6)));
		}
		return listaDetalleSaldo;
	}

	public void setListaDetalleSaldo(List<List<Object>> listaDetalleSaldo) {
		this.listaDetalleSaldo = listaDetalleSaldo;
	}

	public List<BigDecimal> getListaTotalDetalleSaldo() {
		return listaTotalDetalleSaldo;
	}

	public Map<String, String> getMapEstado() {
		return mapEstado;
	}

	public Map<String, String> getMapPaisesBancos() {
		return mapPaisesBancos;
	}

	public void setMapPaisesBancos(Map<String, String> mapPaisesBancos) {
		this.mapPaisesBancos = mapPaisesBancos;
	}

	public void setMapEstado(Map<String, String> mapEstado) {
		this.mapEstado = mapEstado;
	}

	public RegAnticipado getPagoAnticipado() {
		return pagoAnticipado;
	}

	public void setPagoAnticipado(RegAnticipado pagoAnticipado) {
		this.pagoAnticipado = pagoAnticipado;
	}

	public String getMsj() {
		return msj;
	}

	public void setMsj(String msj) {
		this.msj = msj;
	}

	public Date getFechaDesde() {
		return fechaDesde;
	}

	public void setFechaDesde(Date fechaDesde) {
		this.fechaDesde = fechaDesde;
	}

	public Date getFechaHasta() {
		return fechaHasta;
	}

	public void setFechaHasta(Date fechaHasta) {
		this.fechaHasta = fechaHasta;
	}

	public Date getFechaAl() {
		return fechaAl;
	}

	public void setFechaAl(Date fechaAl) {
		this.fechaAl = fechaAl;
	}

	public String getEstiloConsultaSaldos() {
		return (this.saldos != null && this.saldos.size() > 0) ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

//	public void consultarNumeralesIntereses(ActionEvent event) {
//		log.info("ejecutando consultarSaldos");
//		this.msj = "";
//		if (this.listaTotalDetalleSaldo != null)
//			this.listaTotalDetalleSaldo = null;
//		log.info("cuentaAoB " + cuentaAoB);
//		StatusResponse statusResponse = Servicios.getNumeralesIntereses(this.fechaDesde, this.fechaHasta, cuentaAoB);
//
//		this.saldos = (List<SaldoConvenio>) statusResponse.getContenido().get("saldosConvenio");
//		if (this.saldos != null && this.saldos.size() > 0) {
//			this.totalSaldo = new SaldoConvenio();
//			this.totalSaldo.setDebitoA(BigDecimal.ZERO);
//			this.totalSaldo.setDebitoB(BigDecimal.ZERO);
//			this.totalSaldo.setSaldoAladi(BigDecimal.ZERO);
//			this.totalSaldo.setSaldoDiaCtaA(BigDecimal.ZERO);
//			this.totalSaldo.setSaldoDiaCtaB(BigDecimal.ZERO);
//			this.totalSaldo.setPagosPendientes(BigDecimal.ZERO);
//			this.totalSaldo.setCobrosPendientes(BigDecimal.ZERO);
//			this.totalSaldo.setTotal(BigDecimal.ZERO);
//			this.totalSaldo.setMontoCuentaA(BigDecimal.ZERO);
//
//			for (SaldoConvenio s : this.saldos) {
//				this.totalSaldo.setDebitoA(this.totalSaldo.getDebitoA().add(s.getDebitoA()));
//				this.totalSaldo.setDebitoB(this.totalSaldo.getDebitoB().add(s.getDebitoB()));
//				this.totalSaldo.setSaldoAladi(this.totalSaldo.getSaldoAladi().add(s.getSaldoAladi()));
//				this.totalSaldo.setSaldoDiaCtaA(this.totalSaldo.getSaldoDiaCtaA().add(s.getSaldoDiaCtaA()));
//				this.totalSaldo.setSaldoDiaCtaB(this.totalSaldo.getSaldoDiaCtaB().add(s.getSaldoDiaCtaB()));
//				this.totalSaldo.setPagosPendientes(this.totalSaldo.getPagosPendientes().add(s.getPagosPendientes()));
//				this.totalSaldo.setCobrosPendientes(this.totalSaldo.getCobrosPendientes().add(s.getCobrosPendientes()));
//				this.totalSaldo.setMontoCuentaA(this.totalSaldo.getMontoCuentaA().add(s.getMontoCuentaA()));
//				this.totalSaldo.setTotal(this.totalSaldo.getTotal().add(s.getTotal()));
//			}
//		}
//
//		if (!statusResponse.getStatusCode().equals(SUCCESS))
//			this.msj = getAlertJS(statusResponse);
//		getVisit().setParametro("SIRWEB_TMP_OBJECT", this);
//	}
//
	public void consultarSaldos(ActionEvent event) {
		this.consultarSaldos();
	}

	private void consultarSaldos() {
		log.info("ejecutando consultarSaldos");
		this.msj = "";
		if (this.listaTotalDetalleSaldo != null)
			this.listaTotalDetalleSaldo = null;

		StatusResponse statusResponse = Servicios.getSaldosConvenioImportacion(this.fechaDesde, this.fechaHasta, this.fechaAl);
		this.saldos = (List<SaldoConvenio>) statusResponse.getContenido().get("saldosConvenio");
		// ///////////////////////////////////////
//		BigDecimal n = new BigDecimal(10);
//		SaldoConvenio sc = new SaldoConvenio("05", "OOO", n, n, n, n, n, n, n, n, false);
//		SaldoConvenio sc1 = new SaldoConvenio("01", "ARG", n, n, n, n, n, n, n, n, false);
//		SaldoConvenio sc3 = new SaldoConvenio("04", "bol", n, n, n, n, n, n, n, n, false);
//		SaldoConvenio sc5 = new SaldoConvenio("06", "ECU", n, n, n, n, n, n, n, n, false);
//		SaldoConvenio sc6 = new SaldoConvenio("09", "PER", n, n, n, n, n, n, n, n, false);
//		this.saldos = new ArrayList<SaldoConvenio>();
//		this.saldos.add(sc);
//		this.saldos.add(sc1);
//		this.saldos.add(sc3);
//		this.saldos.add(sc5);
//		this.saldos.add(sc6);
//		StatusResponse statusResponse = new StatusResponse("BIEN saldos del convenio.");
//		statusResponse.setStatusCode(SUCCESS);
//		log.info("XXX: BORRAR!!! BORRAR!!! BORRAR!!! BORRAR!!! BORRAR!!! BORRAR!!! BORRAR!!! BORRAR!!! BORRAR!!! BORRAR!!! BORRAR!!! ");
		// ///////////////////
		if (this.saldos != null && this.saldos.size() > 0) {
			this.totalSaldo = new SaldoConvenio();
			this.totalSaldo.setDebitoA(BigDecimal.ZERO);
			this.totalSaldo.setDebitoB(BigDecimal.ZERO);
			this.totalSaldo.setSaldoAladi(BigDecimal.ZERO);
			this.totalSaldo.setSaldoDiaCtaA(BigDecimal.ZERO);
			this.totalSaldo.setSaldoDiaCtaB(BigDecimal.ZERO);
			this.totalSaldo.setPagosPendientes(BigDecimal.ZERO);
			this.totalSaldo.setCobrosPendientes(BigDecimal.ZERO);
			for (SaldoConvenio s : this.saldos) {
				this.totalSaldo.setDebitoA(this.totalSaldo.getDebitoA().add(s.getDebitoA()));
				this.totalSaldo.setDebitoB(this.totalSaldo.getDebitoB().add(s.getDebitoB()));
				this.totalSaldo.setSaldoAladi(this.totalSaldo.getSaldoAladi().add(s.getSaldoAladi()));
				this.totalSaldo.setSaldoDiaCtaA(this.totalSaldo.getSaldoDiaCtaA().add(s.getSaldoDiaCtaA()));
				this.totalSaldo.setSaldoDiaCtaB(this.totalSaldo.getSaldoDiaCtaB().add(s.getSaldoDiaCtaB()));
				this.totalSaldo.setPagosPendientes(this.totalSaldo.getPagosPendientes().add(s.getPagosPendientes()));
				this.totalSaldo.setCobrosPendientes(this.totalSaldo.getCobrosPendientes().add(s.getCobrosPendientes()));
				if (pagosAnticipados != null && pagosAnticipados.size() > 0) {
					for (RegAnticipado r : pagosAnticipados) {
						String descPais = null;
						if (r.getCveTipoApe().equals(TIPO_APERTURA_IMPORTACION))
							descPais = this.mapPaisesBancos.get(r.getCodInstRecep());
						else
							descPais = this.mapPaisesBancos.get(r.getCodInst());
						if (s.getNomPais().trim().equalsIgnoreCase(descPais)) {
							s.setSeleccionado(true);
							break;
						}
					}
				}
			}
		}
		if (!statusResponse.getStatusCode().equals(SUCCESS))
			this.msj = getAlertJS(statusResponse);
		getVisit().setParametro("SIRWEB_TMP_OBJECT", this);
	}

	public void verFormDatoAdicional(SaldoConvenio saldoConvenioSel) {
		log.info("En verFormDatoAdicional " + saldoConvenioSel.getCodPais());
		this.msj = "";
		pagoAnticipado = new RegAnticipado();		
		Institucion institucionBancoCentral = getSirAladiDao().getBancoCentralPorPais(saldoConvenioSel.getCodPais());
		saldoConvenioSel.setSeleccionado(false);

		log.info(">> institucionBancoCentral CodInst " + institucionBancoCentral.getCodInst());		
		Date fechaActual = getSirAladiDao().getFechaActual();
		
		List<RegAnticipado> lista = getServiceDao().getRegAnticipadoLocal().registrosAntBy(TIPO_APERTURA_IMPORTACION, institucionBancoCentral.getCodInst(), fechaActual, null, CODIGO_INSTRUMENTO_PAGO_ANTICIPADO);
		log.info("listalistalista " + lista.size());
		for (RegAnticipado regAnticipado : lista) {
			if (!regAnticipado.getCveEstadoAnt().trim().equals("R") ){
				// solo y solo si es diferente a rechazado
				addMessageError("Error", "ya existe un registro de pago anticipado para el convenio " + institucionBancoCentral.getNomInst() + "");
				return;
			}
		}
		
		this.saldo = saldoConvenioSel;
		this.cargarDatosPagoAnticipado();
	}

	private void cargarDatosPagoAnticipado() {
		Date fechaActual = getSirAladiDao().getFechaActual();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(fechaActual);
		String codConvenio = this.saldo.getCodPais();
		Institucion institucionBancoCentral = getSirAladiDao().getBancoCentralPorPais(codConvenio);
		pagoAnticipado = new RegAnticipado();
		pagoAnticipado.setNroMov(0);
		pagoAnticipado.setCveTipoApe(TIPO_APERTURA_IMPORTACION);
		pagoAnticipado.setCodInst(CODIGO_INSTITUCION_BCB);
		pagoAnticipado.setCodId(CODIGO_ID_PAGO_ANTICIPADO);
		pagoAnticipado.setAnio(Integer.toString(calendar.get(Calendar.YEAR)));
		pagoAnticipado.setCodInstrumento(CODIGO_INSTRUMENTO_PAGO_ANTICIPADO);
		pagoAnticipado.setCveEstadoAnt(ESTADO_PENDIENTE);
		pagoAnticipado.setCodMoneda(CODIGO_MONEDA_DOLARES);
		pagoAnticipado.setCodInstRecep(institucionBancoCentral.getCodInst());
		pagoAnticipado.setDebeMo(this.saldo.getSaldoAladi().abs());
		pagoAnticipado.setHaberMo(BigDecimal.ZERO);
		pagoAnticipado.setFechaCargo(fechaActual);
		pagoAnticipado.setFechaVal(fechaActual);
	}

	public void aceptarDatoAdicional() {
		log.info("Creando nuevo PA");
		this.msj = "";
		try {
			pagoAnticipado.setEstacion(getVisit().getAddress());
			pagoAnticipado.setCodUsuario(getVisit().getUsuarioSirAladi().getLogin());

			RegAnticipado regAnticipado = getServiceDao().getRegAnticipadoServiceLocal().crearPAnticipadoSwift(pagoAnticipado);
			pagosAnticipados = getSirAladiDao().getPagosAnticipados(TIPO_APERTURA_IMPORTACION, ESTADO_PENDIENTE);
			this.saldo = null;
			pagoAnticipado = null;
			addMessageInfo("Aviso", "Pago Anticipado generado con numero de reembolso temporal " + regAnticipado.getNroReembLiteral());
		} catch (Exception e) {
			log.error("error en nuevo Pago anticipado " + e.getMessage(), e);
			addMessageError("Error", "error al guardar Pago anticipado " + e.getMessage());
		}
	}

	public void editarListaPagosAnticipados(RegAnticipado regAnticipadoSel) {
		this.msj = "";
		pagoAnticipado = regAnticipadoSel;
	}

	public void eliminarListaPagosAnticipados(RegAnticipado regAnticipadoSel) {
		log.info("En eliminarListaPagosAnticipados " + regAnticipadoSel.getCodigoReembolso());
		msj = "";
		try {
			pagoAnticipado = regAnticipadoSel;

			pagoAnticipado.setEstacion(getVisit().getAddress());
			pagoAnticipado.setCodUsuario(getVisit().getUsuarioSirAladi().getLogin());
			getServiceDao().getRegAnticipadoServiceLocal().eliminar(pagoAnticipado);

			saldo = null;
			pagoAnticipado = null;
			addMessageInfo("Aviso", "Pago Anticipado rechazado " + regAnticipadoSel.getNroMov());
		} catch (Exception e) {
			log.error("error al guardar Pago anticipado " + e.getMessage(), e);
			addMessageError("Error", "Mensaje: " + e.getMessage());
		}
		recuperarDatos();

	}

	public void modificarPagoAnticipado() {
		log.info("modificarPagoAnticipado PAnticip " + pagoAnticipado.getNroMov());
		msj = "";
		try {
			pagoAnticipado.setEstacion(getVisit().getAddress());
			pagoAnticipado.setCodUsuario(getVisit().getUsuarioSirAladi().getLogin());
			RegAnticipado regAnticipado = getServiceDao().getRegAnticipadoServiceLocal().modificarPAnticipadoSwift(pagoAnticipado);
			saldo = null;
			pagoAnticipado = null;
			addMessageInfo("Aviso", "Pago Anticipado modificado con numero de reembolso " + regAnticipado.getNroReembLiteral());
		} catch (Exception e) {
			log.error("error al guardar Pago anticipado " + e.getMessage(), e);
			addMessageError("Error", "Mensaje: " + e.getMessage());
		}
		recuperarDatos();
	}

	public void autorizarPagoAnticipado(RegAnticipado regAnticipadoSel) {
		log.info("autorizarPagoAnticipado " + regAnticipadoSel.getNroMov());
		this.msj = "";
		pagoAnticipado = regAnticipadoSel;
		pagoAnticipado.setCveEstadoAnt(ESTADO_CONTABILIZADO);
		StatusResponse statusResponse = Servicios.modificarPagoAnticipado(pagoAnticipado);
		if (statusResponse.getStatusCode().endsWith(SUCCESS) && this.saldos != null && this.saldos.size() > 0) {
			this.consultarSaldos();
			pagosAnticipados = getSirAladiDao().getPagosAnticipados(TIPO_APERTURA_IMPORTACION, ESTADO_PENDIENTE);
		}
		this.msj = getAlertJS(statusResponse);
	}

	private void eliminarPagoAnticipado() {
		StatusResponse statusResponse = Servicios.eliminarPagoAnticipado(pagoAnticipado);

		pagosAnticipados = getSirAladiDao().getPagosAnticipados(TIPO_APERTURA_IMPORTACION, ESTADO_PENDIENTE);
		if (pagosAnticipados == null)
			this.crearObjetosPorDefecto();
		this.msj = getAlertJS(statusResponse);
	}

	public void verDetalleSaldoPais(SaldoConvenio saldoConvenioSel) {
		try {
			this.codPais = saldoConvenioSel.getCodPais();
		} catch (ClassCastException e) {
			this.codPais = "%";
		}

		getVisit().setParametro("SIRWEB_TMP_OBJECT", this);
		log.info("this codpais ver det saldo " + this.codPais);
	}

	public void verDetalleSaldoTodo() {
		try {
			this.codPais = "%";
		} catch (ClassCastException e) {
			this.codPais = "%";
		}

		getVisit().setParametro("SIRWEB_TMP_OBJECT", this);
		log.info("this codpais ver det saldo " + this.codPais);
	}

	public void verReporteDetalleSaldo(ActionEvent event) {
		// parametros para reporte de detalle de saldo por convenio
		String strFechaAl = AladiUtils.dateToString(this.fechaAl, FORMATO_FECHA_JAVA);
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("TITULO", "DETALLE DE PAGOS VENCIDOS POR IMPORTACIONES DEL " + dateToString(this.fechaDesde, FORMATO_FECHA_JAVA) + " AL "
				+ dateToString(this.fechaHasta, FORMATO_FECHA_JAVA));
		parametros.put("FECHA_AL", strFechaAl);
		parametros.put("COD_PAIS", this.codPais);

		if ((getVisit().getParametro().containsKey("SIRWEB_TMP_TIPOREP")))
			parametros.put(Constantes.PARAM_TIPO_REPORTE, getVisit().getParametro("SIRWEB_TMP_TIPOREP"));

		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("nombreReporte", "repDetalleSaldoPorConvenio.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}

	public void verReporteSaldos(ActionEvent event) {
		// parametros para reporte de saldos por convenio
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put(
				"TITULO",
				"SALDOS POR CONVENIO DEL " + dateToString(this.fechaDesde, FORMATO_FECHA_JAVA) + " AL "
						+ dateToString(this.fechaHasta, FORMATO_FECHA_JAVA));
		parametros.put("FECHA_AL", dateToString(this.fechaAl, FORMATO_FECHA_JAVA));
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("nombreReporte", "repSaldosPorConvenio.jasper");
		request.getSession().setAttribute("parametros", parametros);
		request.getSession().setAttribute("beanDataSource", this.saldos);
	}

	public void verNumeralesIntereses(ActionEvent event) {
		// parametros para reporte de saldos por convenio
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("TITULO", "CONSULTA DE NUMERALES E INTERESES DEL " + dateToString(this.fechaDesde, FORMATO_FECHA_JAVA) + " AL "
				+ dateToString(this.fechaHasta, FORMATO_FECHA_JAVA));
		parametros.put("CUENTA", "");
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("nombreReporte", "repNumeralesIntereses.jasper");
		request.getSession().setAttribute("parametros", parametros);
		request.getSession().setAttribute("beanDataSource", this.saldos);
	}

	private void crearObjetosPorDefecto() {
		this.msj = "";
		this.saldos = null;
		this.saldo = null;
		pagosAnticipados = null;

		// pone fechas por defecto
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(getSirAladiDao().getFechaActual());
		this.fechaAl = calendar.getTime();
		calendar.add(Calendar.DAY_OF_YEAR, -1);
		this.fechaHasta = calendar.getTime();
		this.fechaDesde = getInicioCuatrimestre(this.fechaHasta);

		if (this.mapEstado == null) {
			List<Institucion> listaBancosCentrales = getSirAladiDao().getBancosCentralesExterior();
			this.mapPaisesBancos = new HashMap<String, String>();
			for (Institucion bc : listaBancosCentrales)
				this.mapPaisesBancos.put(bc.getCodInst(), bc.getPais().getNomPais().trim());
			this.mapEstado = armarMapDescripcionClaves(getSirAladiDao().getClaves(CVE_ESTADO_PAGO_ANT));
		}
	}

	public void irDetalleSwift(RegAnticipado regAnticipadoSel) {
		log.info("irDetalleSwift " + regAnticipadoSel.getNroMov());
		String codope = (regAnticipadoSel.getNroMov() != null ? regAnticipadoSel.getNroMov().toString() : "0");

		SwfMensaje swfMensaje = getServiceDao().getSwfMensajeLocal().findByCodoperacion(codope, null);

		if (swfMensaje != null) {
			getVisit().setParametro("SIRWEB_CODMENSAJE", swfMensaje.getMenCodmen());
			irAPagina("/view/Pagosant/swiftDetail.xhtml");
		} else {
			// this.msj = getAlertJS("Error mensaje swift inexistente");
			addMessageError("Error ", "mensaje swift inexistente");
		}
	}

	public void setCodPais(String codPais) {
		this.codPais = codPais;
	}

	public String getCodPais() {
		return codPais;
	}

	public void setCuentaAoB(String cuentaAoB) {
		this.cuentaAoB = cuentaAoB;
	}

	public String getCuentaAoB() {
		return cuentaAoB;
	}

}
