package gob.bcb.portal.sirAladi.view;

import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarMapDescripcionClaves;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarSelectDescripcionClaves;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.getAlertConCierreModalJS;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.getAlertJS;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_ESTADO_APERTURA;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_ESTADO_REGISTRO;
import static gob.bcb.portal.sirAladi.commons.Constantes.SUCCESS;
import gob.bcb.bpm.siraladi.jpa.Adjunto;
import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.ClasifProductos;
import gob.bcb.bpm.siraladi.jpa.Pais;
import gob.bcb.bpm.siraladi.jpa.Registro;
import gob.bcb.bpm.siraladi.pojo.StatusResponse;
import gob.bcb.portal.sirAladi.commons.Servicios;
import gob.bcb.portal.sirAladi.comunes.controller.FacesContextUtil;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

public class AperturaViewBean extends BaseBeanController {
	private static Logger log = Logger.getLogger(AperturaViewBean.class);
	private String msj;
	private Apertura apertura;
	private Adjunto adjunto;
	private ClasifProductos clasifProductos;
	private BigDecimal totalEmisionInstrumento;
	private BigDecimal totalSaldoInstrumento;
	private BigDecimal totalSumaPlanPagos;
	private Integer codClasifprod = null;
	private Pais paisConvenio;
	private Map<String, String> mapClavesEstadoApertura;
	private Registro registro;
	private Map<String, String> mapClavesEstadoRegistro;
	private List clasificacionProductosItems = null;
	private List<SelectItem> estadoAperturaItems = null;

	public AperturaViewBean() {
	}

	@PostConstruct
	public void init() {
		log.info("Iniciando el modulo Apertura Bean View.");
		clasifProductos = new ClasifProductos();
		clasifProductos.setCodClasifprod(0);
		recuperarVisit();
		apertura = null;

		if (getVisit().getCurrentApertura() != null) {
			String action = FacesContextUtil.getRequestParameter(getFacesContext(), "SIRWEB_TMP_ACTION");
			if (action != null) {
				if (action.equals("SAVE_APERTURA")) {
					apertura = getVisit().getCurrentApertura();
				}
			}
			if (apertura == null) {
				apertura = getSirAladiDao().getApertura(getVisit().getCurrentApertura().getNroMov());
			}
			recuperarDatos();
		}
	}

	private void recuperarDatos() {
		BigDecimal totalPagado = getSirAladiDao().getMontoPagadoInstrumento(this.apertura.getNroMov());
		totalEmisionInstrumento = getSirAladiDao().getMontoInstrumento(this.apertura.getNroMov());
		totalSaldoInstrumento = totalEmisionInstrumento.subtract(totalPagado);
		totalSumaPlanPagos = getSirAladiDao().getSumaPlanPagos(this.apertura.getNroMov());
		paisConvenio = getSirAladiDao().getPaisConvenio(apertura);
		registro = getSirAladiDao().getRegistroEmision(apertura.getNroMov());
		adjunto = getSirAladiDao().getAdjunto(apertura.getNroMov());

		if (apertura.getClasifProductos() != null) {
			clasifProductos = getSirAladiDao().getClasifProductos(apertura.getClasifProductos().getCodClasifprod());
			codClasifprod = apertura.getClasifProductos().getCodClasifprod();
		}

		this.mapClavesEstadoApertura = armarMapDescripcionClaves(getSirAladiDao().getClaves(CVE_ESTADO_APERTURA));
		this.mapClavesEstadoRegistro = armarMapDescripcionClaves(getSirAladiDao().getClaves(CVE_ESTADO_REGISTRO));
	}

	public void guardarApertura(ActionEvent event) {
		this.msj = "";
		StatusResponse statusResponse = Servicios.modificarApertura(this.apertura);
		if (SUCCESS.equals(statusResponse.getStatusCode())) {
			this.apertura = getSirAladiDao().getApertura(this.apertura.getNroMov());
			this.msj = getAlertConCierreModalJS("panelApertura", statusResponse);
		} else {
			// this.apertura = (Apertura)
			// SerializationUtils.clone(this.aperturaInicial);
			log.error("Error al  actualizar Apertura: " + statusResponse.getDescrip());
			this.msj = getAlertJS(statusResponse);
		}
		getVisit().setCurrentApertura(apertura);
	}

	public void modificarAperturaSinValidacion(ActionEvent event) {
		this.msj = "";
		apertura.setClasifProductos(getClasifProductosSelected());
		StatusResponse statusResponse = Servicios.modificarAperturaSinValidacion(apertura);
		if (SUCCESS.equals(statusResponse.getStatusCode())) {
			this.apertura = getSirAladiDao().getApertura(this.apertura.getNroMov());
			this.msj = getAlertConCierreModalJS("panelApertura", statusResponse);
		} else {
			// this.apertura = (Apertura)
			// SerializationUtils.clone(this.aperturaInicial);
			log.error("Error al  actualizar Apertura: " + statusResponse.getDescrip());
			this.msj = getAlertJS(statusResponse);
		}
		getVisit().setCurrentApertura(apertura);
	}

	// public void cancelarCambios(ActionEvent event) {
	public String cancelarCambios() {
		apertura = getSirAladiDao().getApertura(getVisit().getCurrentApertura().getNroMov());
		getVisit().setCurrentApertura(apertura);
		return null;
	}

	public List getClasificacionProductosItems() {
		if (clasificacionProductosItems == null) {
			clasificacionProductosItems = new LinkedList();
			List<ClasifProductos> listaClasifProductos = getSirAladiDao().getClasificacionProductos();
			for (ClasifProductos i : listaClasifProductos)
				clasificacionProductosItems.add(new SelectItem(i.getCodClasifprod(), i.getDescrip().trim()));
		}
		return clasificacionProductosItems;
	}

	public List<SelectItem> getEstadoAperturaItems() {
		if (estadoAperturaItems == null) {
			estadoAperturaItems = armarSelectDescripcionClaves(getSirAladiDao().getClaves(CVE_ESTADO_APERTURA));
		}
		return estadoAperturaItems;
	}

	public void clasifProductosSelected(ActionEvent event) {
		apertura.setClasifProductos(getClasifProductosSelected());
		getVisit().setCurrentApertura(apertura);
	}

	public ClasifProductos getClasifProductosSelected() {
		return codClasifprod != null ? getSirAladiDao().getClasifProductos(codClasifprod) : clasifProductos;
	}

	public void mostrarAdjunto(ActionEvent event) {
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("nroMov", this.apertura.getNroMov());
	}

	public void mostrarReporte(ActionEvent event) {
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("NRO_MOV", this.apertura.getNroMov());
		parametros.put("TITULO", "DETALLE DE INSTRUMENTO");
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("pathTranslated", request.getPathTranslated());
		request.getSession().setAttribute("nombreReporte", "repHistorico.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}
	public void clasifProds(ActionEvent event) {
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("tfile", "xls");		
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("pathTranslated", request.getPathTranslated());
		request.getSession().setAttribute("nombreReporte", "repClasificacionProds.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}
	
	public boolean isModificable() {
		String codrecprotegido = (String) getVisit().getParametro("codrecprotegido");
		codrecprotegido = codrecprotegido == null ? "" : codrecprotegido;
		if (apertura.getCveTipoApe().trim().equals("I")) {
			// es modificable si la apertura esta vigente y la emision fue
			// autorizada
			return (isAuthorized("ALA0104") && apertura.getCveEstadoApe().trim().equals("V") && registro.getCveEstadoReg().trim().equals("C") && codrecprotegido
					.equals("ALA0104"));
		}
		return (isAuthorized("ALA0204") && apertura.getCveEstadoApe().trim().equals("V") && registro.getCveEstadoReg().trim().equals("C") && codrecprotegido
				.equals("ALA0204"));
	}

	public void setApertura(Apertura apertura) {
		this.apertura = apertura;
	}

	public Apertura getApertura() {
		return apertura;
	}

	public void setTotalEmisionInstrumento(BigDecimal totalEmisionInstrumento) {
		this.totalEmisionInstrumento = totalEmisionInstrumento;
	}

	public BigDecimal getTotalEmisionInstrumento() {
		return totalEmisionInstrumento;
	}

	public void setTotalSaldoInstrumento(BigDecimal totalSaldoInstrumento) {
		this.totalSaldoInstrumento = totalSaldoInstrumento;
	}

	public BigDecimal getTotalSaldoInstrumento() {
		return totalSaldoInstrumento;
	}

	public void setTotalSumaPlanPagos(BigDecimal totalSumaPlanPagos) {
		this.totalSumaPlanPagos = totalSumaPlanPagos;
	}

	public BigDecimal getTotalSumaPlanPagos() {
		return totalSumaPlanPagos;
	}

	public void setMapClavesEstadoApertura(Map<String, String> mapClavesEstadoApertura) {
		this.mapClavesEstadoApertura = mapClavesEstadoApertura;
	}

	public Map<String, String> getMapClavesEstadoApertura() {
		return mapClavesEstadoApertura;
	}

	public void setPaisConvenio(Pais paisConvenio) {
		this.paisConvenio = paisConvenio;
	}

	public Pais getPaisConvenio() {
		return paisConvenio;
	}

	public void setRegistro(Registro registro) {
		this.registro = registro;
	}

	public Registro getRegistro() {
		return registro;
	}

	public void setMapClavesEstadoRegistro(Map<String, String> mapClavesEstadoRegistro) {
		this.mapClavesEstadoRegistro = mapClavesEstadoRegistro;
	}

	public Map<String, String> getMapClavesEstadoRegistro() {
		return mapClavesEstadoRegistro;
	}

	public String getMsj() {
		return msj;
	}

	public void setMsj(String msj) {
		this.msj = msj;
	}

	public void setAdjunto(Adjunto adjunto) {
		this.adjunto = adjunto;
	}

	public Adjunto getAdjunto() {
		return adjunto;
	}

	public void setClasifProductos(ClasifProductos clasifProductos) {
		this.clasifProductos = clasifProductos;
	}

	public ClasifProductos getClasifProductos() {
		return clasifProductos;
	}

	public void setCodClasifprod(Integer codClasifprod) {
		this.codClasifprod = codClasifprod;
	}

	public Integer getCodClasifprod() {
		return codClasifprod;
	}
}
