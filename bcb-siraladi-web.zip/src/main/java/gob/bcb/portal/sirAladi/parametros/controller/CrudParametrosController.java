/**
 * La Paz - Bolivia
 * bcb-portal-portletBase
 * gob.bcb.portal.sirAladi.parametros.controller.CrudParametrosController
 * 08/06/2011 - 12:16:28
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.parametros.controller;

import gob.bcb.portal.sirAladi.parametros.logica.Columna;
import gob.bcb.portal.sirAladi.parametros.logica.MaestroDetalle;
import gob.bcb.portal.sirAladi.parametros.logica.OperacionesParametros;
import gob.bcb.portal.sirAladi.parametros.logica.Tabla;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.application.Application;
import javax.faces.component.UIComponent;
import javax.faces.component.html.HtmlGraphicImage;
import javax.faces.component.html.HtmlOutputText;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.event.ActionEvent;

import org.ajax4jsf.component.html.HtmlAjaxCommandButton;
import org.ajax4jsf.component.html.HtmlAjaxCommandLink;
import org.ajax4jsf.component.html.HtmlAjaxSupport;
import org.apache.commons.lang.SerializationUtils;
import org.apache.log4j.Logger;
import org.richfaces.component.html.HtmlColumn;
import org.richfaces.component.html.HtmlComponentControl;
import org.richfaces.component.html.HtmlDataTable;
import org.richfaces.component.html.HtmlPanel;
import org.richfaces.component.html.HtmlToolTip;

/**
 * Backing bean de la pagina crudParametros.xhtml. Controla las operaciones de
 * altas bajas y modificaciones para tablas parametricas.
 * 
 * @author wherrera
 * 
 */
public class CrudParametrosController {
	private List<Tabla> tablas;
	private List<Tabla> tablasVisibles;
	private List<Columna> registro;
	private List<List<String>> datos;
	private List<List<String>> datosHijo;
	private HtmlPanel richPanelGrillaTabla;
	private HtmlPanel richPanelGrillaTablaHijo;
	private HtmlPanel richPanelDetalleRegistro;
	private HtmlOutputText msjError;
	private OperacionesParametros operaciones;
	private String txtFilterPadre;
	private String txtFilterHijo;
	private int filaTabla;
	private int filaRegistroPadre;

	public static final String ESTILO_VISIBLE = "display:block;";
	public static final String ESTILO_INVISIBLE = "display:none;";

	private static Logger log = Logger.getLogger(CrudParametrosController.class);

	/**
	 * Constructor del Backing Bean
	 */
	public CrudParametrosController() {
		try {
			Application application = FacesContext.getCurrentInstance().getApplication();

			this.richPanelGrillaTabla = (HtmlPanel) application.createComponent(HtmlPanel.COMPONENT_TYPE);
			this.richPanelGrillaTabla.setId("panelDetalleTabla");
			this.richPanelGrillaTabla.setStyle(ESTILO_INVISIBLE);

			this.richPanelGrillaTablaHijo = (HtmlPanel) application.createComponent(HtmlPanel.COMPONENT_TYPE);
			this.richPanelGrillaTablaHijo.setId("panelDetalleTablaHijo");
			this.richPanelGrillaTablaHijo.setStyle(ESTILO_INVISIBLE);

			this.richPanelDetalleRegistro = (HtmlPanel) application.createComponent(HtmlPanel.COMPONENT_TYPE);
			this.richPanelDetalleRegistro.setId("richPanelDetalleRegistro");
			// //this.richPanelDetalleRegistro.setStyle("height:432px; overflow:auto;");
			/**/this.richPanelDetalleRegistro.setStyle("min-height:432px;");

			this.msjError = (HtmlOutputText) application.createComponent(HtmlOutputText.COMPONENT_TYPE);
			this.msjError.setId("msjError");
			this.msjError.setEscape(false);

			this.iniciar();
		} catch (Exception e) {
			mostrarMsjError("Error al iniciar el modulo de ABMs a Parametricas ");
		}
	}

	public HtmlPanel getRichPanelGrillaTabla() {
		return richPanelGrillaTabla;
	}

	public void setRichPanelGrillaTabla(HtmlPanel richPanelGrillaTabla) {
		this.richPanelGrillaTabla = richPanelGrillaTabla;
	}

	public HtmlPanel getRichPanelGrillaTablaHijo() {
		return richPanelGrillaTablaHijo;
	}

	public void setRichPanelGrillaTablaHijo(HtmlPanel richPanelGrillaTablaHijo) {
		this.richPanelGrillaTablaHijo = richPanelGrillaTablaHijo;
	}

	public HtmlPanel getRichPanelDetalleRegistro() {
		return richPanelDetalleRegistro;
	}

	public void setRichPanelDetalleRegistro(HtmlPanel richPanelDetalleRegistro) {
		this.richPanelDetalleRegistro = richPanelDetalleRegistro;
	}

	public HtmlOutputText getMsjError() {
		return msjError;
	}

	public void setMsjError(HtmlOutputText msjError) {
		this.msjError = msjError;
	}

	public List<Tabla> getTablas() {
		return tablas;
	}

	public List<Tabla> getTablasVisibles() {
		return tablasVisibles;
	}

	public List<Columna> getRegistro() {
		return registro;
	}

	public List<List<String>> getDatos() {
		return datos;
	}

	public List<List<String>> getDatosHijo() {
		return datosHijo;
	}

	public int getFilaTabla() {
		return filaTabla;
	}

	public int getFilaRegistroPadre() {
		return filaRegistroPadre;
	}

	public String getTxtFilterPadre() {
		return txtFilterPadre;
	}

	public void setTxtFilterPadre(String txtFilterPadre) {
		this.txtFilterPadre = txtFilterPadre;
	}

	public String getTxtFilterHijo() {
		return txtFilterHijo;
	}

	public void setTxtFilterHijo(String txtFilterHijo) {
		this.txtFilterHijo = txtFilterHijo;
	}

	/**
	 * Metodo que reinicia el modulo y obtiene todos los datos nuevamente.
	 * 
	 * @param event
	 */
	public void reiniciar(ActionEvent event) {
		try {
			this.iniciar();
		} catch (Exception e) {
			mostrarMsjError("Error al actualizar el modulo.");
		}
	}

	/**
	 * Metodo que responde al evento de realizar click en una tabla del listado
	 * de tablas parametricas.
	 * 
	 * @param event
	 */
	public void seleccionarTabla(ActionEvent event) {
		this.msjError.setValue("");
		try {
			this.registro = null;
			this.filaRegistroPadre = -1;
			HtmlDataTable richDataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
			this.filaTabla = richDataTable.getRowIndex();
			this.dibujarTablaPadre();
			this.richPanelGrillaTabla.setStyle(ESTILO_VISIBLE);
			this.richPanelGrillaTablaHijo.setStyle(ESTILO_INVISIBLE);
		} catch (Exception e) {
			mostrarMsjError("Error al obtener los datos de la tabla seleccionada.");
			e.printStackTrace();
		}
	}

	/**
	 * Metodo que responde al evento de hacer click en un registro de una tabla
	 * padre, muestra el hijo del registro seleccionado. (Maestro - Detalle)
	 * 
	 * @param event
	 */
	public void verTablaHijo(ActionEvent event) {
		this.msjError.setValue("");
		try {
			HtmlDataTable richDataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
			MaestroDetalle maestroDetalle = this.tablasVisibles.get(this.filaTabla).getMaestroDetalle();
			this.filaRegistroPadre = richDataTable.getRowIndex();
			String rowIdRegistro = this.datos.get(this.filaRegistroPadre).get(0);
			this.dibujarTablaHijo(maestroDetalle, rowIdRegistro);
			this.richPanelGrillaTablaHijo.setStyle(ESTILO_VISIBLE);
		} catch (Exception e) {
			mostrarMsjError("Error al obtener el detalle del registro seleccionado.");
		}
	}

	/**
	 * Metodo que filtra el resultado de la grilla de datos de una tabla padre,
	 * segun un texto introducido en el campo para filtrado de registros.
	 * 
	 * @param event
	 */
	public void filtrarDatosPadre(ActionEvent event) {
		this.richPanelGrillaTablaHijo.getChildren().clear();
		this.richPanelGrillaTablaHijo.setHeader("");
		this.richPanelDetalleRegistro.getChildren().clear();
		this.msjError.setValue("");
		this.dibujarTablaPadre();
	}

	/**
	 * Metodo que filtra el resultado de la grilla de datos de una tabla hijo,
	 * segun un texto introducido en el campo para filtrado de registros.
	 * 
	 * @param event
	 */
	public void filtrarDatosHijo(ActionEvent event) {
		MaestroDetalle maestroDetalle = this.tablasVisibles.get(this.filaTabla).getMaestroDetalle();
		String rowIdRegistro = this.datos.get(this.filaRegistroPadre).get(0);
		this.dibujarTablaHijo(maestroDetalle, rowIdRegistro);
	}

	/**
	 * Metodo que responde al evento de hacer click en el icono realizar la
	 * operacion CRUD correspondiente.
	 * 
	 * @param event
	 * @param esHijo
	 *            boolean que indica si se realizo la operacion sobre una tabla
	 *            hijo o no.
	 */
	private void verFormularioCrud(ActionEvent event, boolean esHijo) {
		try {
			this.msjError.setValue("");
			String operacion = event.getComponent().getId().replaceAll("2", "");
			if (operacion.equals(operaciones.INSERT))
				this.getRegistroTabla(-1, esHijo);
			else {
				HtmlDataTable richDataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
				this.getRegistroTabla(richDataTable.getRowIndex(), esHijo);
			}
			this.dibujarDetalleRegistro(operacion, esHijo);
		} catch (Exception e) {
			String mensajeError = "Error en la operacion realizada. ";
			mostrarMsjError(mensajeError);
			log.error(mensajeError + e.toString());
			e.printStackTrace();
		}
	}

	/**
	 * Metodo que responde al evento de hacer click en el icono realizar la
	 * operacion CRUD correspondiente en una tabla padre.
	 * 
	 * @param event
	 */
	public void verFormularioCrudPadre(ActionEvent event) {
		this.verFormularioCrud(event, false);
	}

	/**
	 * Metodo que responde al evento de hacer click en el icono realizar la
	 * operacion CRUD correspondiente en una tabla hijo.
	 * 
	 * @param event
	 */
	public void verFormularioCrudHijo(ActionEvent event) {
		this.verFormularioCrud(event, true);
	}

	/**
	 * Metodo que realiza la ejecuacion de una operacion DML asociada un
	 * registro de una tabla padre.
	 * 
	 * @param event
	 */
	public void ejecutarOperacionDmlPadre(ActionEvent event) {
		this.ejecutarOperacionDml(event, false);
	}

	/**
	 * Metodo que realiza la ejecuacion de una operacion DML asociada un
	 * registro de una tabla hijo.
	 * 
	 * @param event
	 */
	public void ejecutarOperacionDmlHijo(ActionEvent event) {
		this.ejecutarOperacionDml(event, true);
	}

	/**
	 * Metodo que realiza la ejecuacion de una operacion DML asociada un
	 * registro de una tabla.
	 * 
	 * 
	 * @param event
	 * @param esHijo
	 *            booleano que indica si la operacion realizada es sobre una
	 *            tabla hijo o no.
	 */
	private void ejecutarOperacionDml(ActionEvent event, boolean esHijo) {
		this.msjError.setValue("");
		try {
			this.txtFilterPadre = null;
			this.txtFilterHijo = null;
			Tabla tabla = this.tablasVisibles.get(this.filaTabla);
			String operacion = event.getComponent().getId();
			String sentenciaDml = null;
			String nombreTabla = esHijo ? tabla.getMaestroDetalle().getTablaHijo() : tabla.getNombreTabla();
			sentenciaDml = operaciones.getSentenciaDml(operacion, nombreTabla, this.registro, this.getLogs());
			if (sentenciaDml != null) {
				this.operaciones.ejecutarSentenciaDML(sentenciaDml);
				if (esHijo)
					this.dibujarTablaHijo(tabla.getMaestroDetalle(), this.datos.get(this.filaRegistroPadre).get(0));
				else
					this.dibujarTablaPadre();
			}
		} catch (Exception e) {
			mostrarMsjError("No se pudo realizar la operacion solicitada.");
			e.printStackTrace();
		}
	}

	/**
	 * Metodo que arma dinamicamente la grilla de datos de una tabla parametrica
	 * padre.
	 * 
	 */
	private void dibujarTablaPadre() {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		Tabla tablaSeleccionada = this.tablasVisibles.get(this.filaTabla);
		int nroOperaciones = tablaSeleccionada.getNroPermisosABM() + 1;
		int nroColumnas = tablaSeleccionada.getNroColumnasVisibles();
		boolean update = true;
		this.datos = this.operaciones.getDatosTablaPadre(tablaSeleccionada, this.txtFilterPadre);

		// <h:dataTable value="#{crudParametros.datos}" var="fila">
		HtmlDataTable tablaDinamica = new HtmlDataTable();
		tablaDinamica.setValueExpression("value", operaciones.crearValueExpression(facesContext, "#{crudParametros.datos}", List.class));
		tablaDinamica.setVar("fila");
		tablaDinamica.setId("grillaPadre");
		tablaDinamica.setOnRowMouseOver("this.style.backgroundColor='#F1F1F1'");
		tablaDinamica.setOnRowMouseOut("this.style.backgroundColor='#FFFFFF'");

		HtmlAjaxSupport ajaxSupportVerDetalle = null;
		if (tablaSeleccionada.esMaestroDetalle()) {
			ajaxSupportVerDetalle = new HtmlAjaxSupport();
			ajaxSupportVerDetalle.setEvent("onclick");
			ajaxSupportVerDetalle.setReRender("panelDetalleTablaHijo, msjError");
			ajaxSupportVerDetalle.addActionListener(operaciones.crearActionListener(facesContext, "#{crudParametros.verTablaHijo}"));
			tablaDinamica.setRows(5);
		} else
			tablaDinamica.setRows(10);

		for (int i = 1; i <= nroColumnas + nroOperaciones; i++) {
			if (i > nroColumnas || (i <= nroColumnas && tablaSeleccionada.getColumnas().get(i - 1).isVisible())) {
				// <h:column>
				HtmlColumn column = new HtmlColumn();
				if (this.datos.size() > 0 || i <= nroColumnas)
					tablaDinamica.getChildren().add(column);

				if (i <= nroColumnas) {
					// <h:outputText value="nombreColumna[i]"> -> <f:facet
					// name="header">
					HtmlOutputText header = new HtmlOutputText();
					header.setValue(tablaSeleccionada.getColumnas().get(i - 1).getDescripcionColumna());
					column.setHeader(header);
				}

				if (this.datos.size() > 0) {
					if (i <= nroColumnas) {
						// <h:outputText value="#{fila[" + i + "]}">
						HtmlOutputText output = new HtmlOutputText();
						output.setValueExpression("value", operaciones.crearValueExpression(facesContext, "#{fila[" + i + "]}", String.class));
						Converter converter = operaciones.getFormatoConverter(tablaSeleccionada.getColumnas().get(i - 1).getTipoDato());
						if (converter != null)
							output.setConverter(converter);
						column.getChildren().add(output);
						if (tablaSeleccionada.esMaestroDetalle())
							column.getChildren().add(ajaxSupportVerDetalle);
						column.setStyleClass(operaciones.getAlineacionColumna(tablaSeleccionada.getColumnas().get(i - 1).getTipoDato()));
					} else {
						String nombreIcono = null;
						column.setStyleClass("centrado");
						HtmlToolTip toolTipOperacion = new HtmlToolTip();

						HtmlComponentControl richComponetControl = new HtmlComponentControl();
						richComponetControl.setFor("modalPanelDetalleRegistro");
						richComponetControl.setOperation("show");
						richComponetControl.setEvent("onclick");

						HtmlGraphicImage iconoOperacion = new HtmlGraphicImage();
						iconoOperacion.getChildren().add(richComponetControl);

						HtmlAjaxSupport ajaxSupport = new HtmlAjaxSupport();
						ajaxSupport.setEvent("onclick");
						ajaxSupport.setReRender("richPanelDetalleRegistro, msjError");
						ajaxSupport.addActionListener(operaciones.crearActionListener(facesContext, "#{crudParametros.verFormularioCrudPadre}"));
						ajaxSupport.setImmediate(true);
						ajaxSupport.setAjaxSingle(true);

						if (i == nroColumnas + 1) {
							// icono ver Detalle de registro
							nombreIcono = "iconoVerDetalle";
							iconoOperacion.setUrl("/resources/images/show-icon.png");
							toolTipOperacion.setValue("Ver Registro");
							ajaxSupport.setId(operaciones.SELECT);
						} else {
							if (update) {
								if (tablaSeleccionada.isUpdate()) {
									// icono editar registro
									nombreIcono = "iconoModificar";
									iconoOperacion.setUrl("/resources/images/edit-icon.png");
									toolTipOperacion.setValue("Modificar");
									ajaxSupport.setId(operaciones.UPDATE);
								} else {
									update = false;
								}
							}
							if (!update && tablaSeleccionada.isDelete()) {
								// icono eliminar registro
								nombreIcono = "iconoEliminar";
								iconoOperacion.setUrl("/resources/images/delete-icon.png");
								toolTipOperacion.setValue("Eliminar");
								ajaxSupport.setId(operaciones.DELETE);
							}
							update = false;
						}

						richComponetControl.setAttachTo(nombreIcono);
						iconoOperacion.setId(nombreIcono);
						toolTipOperacion.setFor(nombreIcono);

						column.getChildren().add(iconoOperacion);
						column.getChildren().add(toolTipOperacion);
						column.getChildren().add(ajaxSupport);
					}
				}
			} else
				nroColumnas++;
		}

		this.richPanelGrillaTabla.getChildren().clear();
		this.richPanelGrillaTabla.setHeader(tablaSeleccionada.getDescripcionTabla());

		HtmlAjaxSupport ajaxSupportFiltrar = new HtmlAjaxSupport();
		ajaxSupportFiltrar.setEvent("onclick");
		ajaxSupportFiltrar.setReRender("panelDetalleTabla, panelDetalleTablaHijo, msjError");
		ajaxSupportFiltrar.addActionListener(operaciones.crearActionListener(facesContext, "#{crudParametros.filtrarDatosPadre}"));

		HtmlGraphicImage iconoSearch = new HtmlGraphicImage();
		iconoSearch.setUrl("/resources/images/find-icon.png");
		iconoSearch.setId("iconoSearch");
		iconoSearch.getChildren().add(ajaxSupportFiltrar);

		HtmlToolTip toolTipSearch = new HtmlToolTip();
		toolTipSearch.setValue("Buscar");
		toolTipSearch.setFor("iconoSearch");

		this.richPanelGrillaTabla.getChildren().add(operaciones.html("<div align='right'>"));
		this.richPanelGrillaTabla.getChildren().add(operaciones.getInplaceInput(facesContext, "#{crudParametros.txtFilterPadre}"));
		this.richPanelGrillaTabla.getChildren().add(operaciones.html("&nbsp;&nbsp;"));
		this.richPanelGrillaTabla.getChildren().add(iconoSearch);
		this.richPanelGrillaTabla.getChildren().add(toolTipSearch);
		this.richPanelGrillaTabla.getChildren().add(operaciones.html("</div>"));
		this.richPanelGrillaTabla.getChildren().add(tablaDinamica);
		this.richPanelGrillaTabla.getChildren().add(operaciones.html("<center>"));
		this.richPanelGrillaTabla.getChildren().add(operaciones.getPaginador("grillaPadre"));
		this.richPanelGrillaTabla.getChildren().add(operaciones.html("</center>"));

		this.richPanelGrillaTablaHijo.getChildren().clear();
		this.richPanelGrillaTablaHijo.setHeader(null);
		this.txtFilterPadre = null;

		if (tablaSeleccionada.isInsert()) {
			// icono adicionar nuevo registro
			HtmlComponentControl richComponetControl = new HtmlComponentControl();
			richComponetControl.setFor("modalPanelDetalleRegistro");
			richComponetControl.setAttachTo(operaciones.INSERT);
			richComponetControl.setOperation("show");
			richComponetControl.setEvent("onclick");

			HtmlGraphicImage iconoAdicionar = new HtmlGraphicImage();
			iconoAdicionar.setUrl("/resources/images/add-icon.png");
			iconoAdicionar.setId("iconoInsertar");

			HtmlAjaxCommandLink linkAdicionar = new HtmlAjaxCommandLink();
			linkAdicionar.setId(operaciones.INSERT);
			linkAdicionar.setReRender("richPanelDetalleRegistro");
			linkAdicionar.addActionListener(operaciones.crearActionListener(facesContext, "#{crudParametros.verFormularioCrudPadre}"));
			linkAdicionar.setImmediate(true);
			linkAdicionar.setAjaxSingle(true);
			linkAdicionar.getChildren().add(iconoAdicionar);
			linkAdicionar.getChildren().add(operaciones.html("&nbsp;&nbsp;<b>Adicionar</b>"));
			linkAdicionar.getChildren().add(richComponetControl);

			HtmlToolTip toolTipAdicionar = new HtmlToolTip();
			toolTipAdicionar.setFor(operaciones.INSERT);
			toolTipAdicionar.setValue("Insertar un nuevo registro para " + tablaSeleccionada.getDescripcionTabla());

			this.richPanelGrillaTabla.getChildren().add(operaciones.html("<div align='right'>"));
			this.richPanelGrillaTabla.getChildren().add(linkAdicionar);
			this.richPanelGrillaTabla.getChildren().add(operaciones.html("</div>"));
			this.richPanelGrillaTabla.getChildren().add(toolTipAdicionar);
		}
	}

	/**
	 * Metodo que arma dinamicamente la grilla de datos de una tabla parametrica
	 * hija.
	 * 
	 */
	private void dibujarTablaHijo(MaestroDetalle maestroDetalle, String rowIdRegistro) {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		Tabla tablaSeleccionada = new Tabla();
		for (Tabla tab : this.tablas) {
			if (tab.getNombreTabla().equals(maestroDetalle.getTablaHijo())) {
				tablaSeleccionada = null;
				tablaSeleccionada = tab;
				break;
			}
		}
		int nroOperaciones = tablaSeleccionada.getNroPermisosABM() + 1;
		int nroColumnas = tablaSeleccionada.getNroColumnasVisibles();
		boolean update = true;
		this.datosHijo = this.operaciones.getDatosTablaHijo(tablaSeleccionada, maestroDetalle, rowIdRegistro, this.txtFilterHijo);

		// <h:dataTable value="#{crudParametros.datos}" var="fila">
		HtmlDataTable tablaDinamica = new HtmlDataTable();
		tablaDinamica.setValueExpression("value", operaciones.crearValueExpression(facesContext, "#{crudParametros.datosHijo}", List.class));
		tablaDinamica.setVar("filaHijo");
		tablaDinamica.setId("grillaHijo");
		tablaDinamica.setRows(10);
		tablaDinamica.setOnRowMouseOver("this.style.backgroundColor='#F1F1F1'");
		tablaDinamica.setOnRowMouseOut("this.style.backgroundColor='#FFFFFF'");

		for (int i = 1; i <= nroColumnas + nroOperaciones; i++) {
			if (i > nroColumnas || (i <= nroColumnas && tablaSeleccionada.getColumnas().get(i - 1).isVisible())) {
				// <h:column>
				HtmlColumn column = new HtmlColumn();
				if (this.datosHijo.size() > 0 || i <= nroColumnas)
					tablaDinamica.getChildren().add(column);

				if (i <= nroColumnas) {
					// <h:outputText value="nombreColumna[i]"> -> <f:facet
					// name="header">
					HtmlOutputText header = new HtmlOutputText();
					header.setValue(tablaSeleccionada.getColumnas().get(i - 1).getDescripcionColumna());
					column.setHeader(header);
				}

				if (this.datosHijo.size() > 0) {
					if (i <= nroColumnas) {
						// <h:outputText value="#{fila[" + i + "]}">
						HtmlOutputText output = new HtmlOutputText();
						output.setValueExpression("value", operaciones.crearValueExpression(facesContext, "#{filaHijo[" + i + "]}", String.class));
						Converter converter = operaciones.getFormatoConverter(tablaSeleccionada.getColumnas().get(i - 1).getTipoDato());
						if (converter != null)
							output.setConverter(converter);
						column.getChildren().add(output);
						column.setStyleClass(operaciones.getAlineacionColumna(tablaSeleccionada.getColumnas().get(i - 1).getTipoDato()));
					} else {
						String nombreIcono = null;
						column.setStyleClass("centrado");
						HtmlToolTip toolTipOperacion = new HtmlToolTip();

						HtmlComponentControl richComponetControl = new HtmlComponentControl();
						richComponetControl.setFor("modalPanelDetalleRegistro");
						richComponetControl.setOperation("show");
						richComponetControl.setEvent("onclick");

						HtmlGraphicImage iconoOperacion = new HtmlGraphicImage();
						iconoOperacion.getChildren().add(richComponetControl);

						HtmlAjaxSupport ajaxSupport = new HtmlAjaxSupport();
						ajaxSupport.setEvent("onclick");
						ajaxSupport.setReRender("richPanelDetalleRegistro, msjError");
						ajaxSupport.addActionListener(operaciones.crearActionListener(facesContext, "#{crudParametros.verFormularioCrudHijo}"));
						ajaxSupport.setImmediate(true);
						ajaxSupport.setAjaxSingle(true);

						if (i == nroColumnas + 1) {
							// icono ver Detalle de registro
							nombreIcono = "iconoVerDetalle";
							iconoOperacion.setUrl("/resources/images/show-icon.png");
							toolTipOperacion.setValue("Ver Registro");
							ajaxSupport.setId(operaciones.SELECT + "2");
						} else {
							if (update) {
								if (tablaSeleccionada.isUpdate()) {
									// icono editar registro
									nombreIcono = "iconoModificar";
									iconoOperacion.setUrl("/resources/images/edit-icon.png");
									toolTipOperacion.setValue("Modificar");
									ajaxSupport.setId(operaciones.UPDATE + "2");
								} else {
									update = false;
								}
							}
							if (!update && tablaSeleccionada.isDelete()) {
								// icono eliminar registro
								nombreIcono = "iconoEliminar";
								iconoOperacion.setUrl("/resources/images/delete-icon.png");
								toolTipOperacion.setValue("Eliminar");
								ajaxSupport.setId(operaciones.DELETE + "2");
							}
							update = false;
						}
						nombreIcono = nombreIcono + "2";
						richComponetControl.setAttachTo(nombreIcono);
						iconoOperacion.setId(nombreIcono);
						toolTipOperacion.setFor(nombreIcono);

						column.getChildren().add(iconoOperacion);
						column.getChildren().add(toolTipOperacion);
						column.getChildren().add(ajaxSupport);
					}
				}
			} else
				nroColumnas++;
		}

		this.richPanelGrillaTablaHijo.getChildren().clear();
		this.richPanelGrillaTablaHijo.setHeader(tablaSeleccionada.getDescripcionTabla());
		this.txtFilterHijo = null;

		HtmlAjaxSupport ajaxSupportFiltrar = new HtmlAjaxSupport();
		ajaxSupportFiltrar.setEvent("onclick");
		ajaxSupportFiltrar.setReRender("panelDetalleTablaHijo, msjError");
		ajaxSupportFiltrar.addActionListener(operaciones.crearActionListener(facesContext, "#{crudParametros.filtrarDatosHijo}"));

		HtmlGraphicImage iconoSearch = new HtmlGraphicImage();
		iconoSearch.setUrl("/resources/images/find-icon.png");
		iconoSearch.setId("iconoSearchHijo");
		iconoSearch.getChildren().add(ajaxSupportFiltrar);

		HtmlToolTip toolTipSearch = new HtmlToolTip();
		toolTipSearch.setValue("Buscar");
		toolTipSearch.setFor("iconoSearchHijo");

		this.richPanelGrillaTablaHijo.getChildren().add(operaciones.html("<div align='right'>"));
		this.richPanelGrillaTablaHijo.getChildren().add(operaciones.getInplaceInput(facesContext, "#{crudParametros.txtFilterHijo}"));
		this.richPanelGrillaTablaHijo.getChildren().add(operaciones.html("&nbsp;&nbsp;"));
		this.richPanelGrillaTablaHijo.getChildren().add(iconoSearch);
		this.richPanelGrillaTablaHijo.getChildren().add(toolTipSearch);
		this.richPanelGrillaTablaHijo.getChildren().add(operaciones.html("</div>"));
		this.richPanelGrillaTablaHijo.getChildren().add(tablaDinamica);
		this.richPanelGrillaTablaHijo.getChildren().add(operaciones.html("<center>"));
		this.richPanelGrillaTablaHijo.getChildren().add(operaciones.getPaginador("grillaHijo"));
		this.richPanelGrillaTablaHijo.getChildren().add(operaciones.html("</center>"));

		if (tablaSeleccionada.isInsert()) {
			// icono adicionar nuevo registro
			HtmlComponentControl richComponetControl = new HtmlComponentControl();
			richComponetControl.setFor("modalPanelDetalleRegistro");
			richComponetControl.setAttachTo(operaciones.INSERT + "2");
			richComponetControl.setOperation("show");
			richComponetControl.setEvent("onclick");

			HtmlGraphicImage iconoAdicionar = new HtmlGraphicImage();
			iconoAdicionar.setUrl("/resources/images/add-icon.png");
			iconoAdicionar.setId("iconoInsertar" + "2");

			HtmlAjaxCommandLink linkAdicionar = new HtmlAjaxCommandLink();
			linkAdicionar.setId(operaciones.INSERT + "2");
			linkAdicionar.setReRender("richPanelDetalleRegistro");
			linkAdicionar.addActionListener(operaciones.crearActionListener(facesContext, "#{crudParametros.verFormularioCrudHijo}"));
			linkAdicionar.setImmediate(true);
			linkAdicionar.setAjaxSingle(true);
			linkAdicionar.getChildren().add(iconoAdicionar);
			linkAdicionar.getChildren().add(operaciones.html("&nbsp;&nbsp;<b>Adicionar</b>"));
			linkAdicionar.getChildren().add(richComponetControl);

			HtmlToolTip toolTipAdicionar = new HtmlToolTip();
			toolTipAdicionar.setFor(operaciones.INSERT);
			toolTipAdicionar.setValue("Insertar un nuevo registro para " + tablaSeleccionada.getDescripcionTabla());

			this.richPanelGrillaTablaHijo.getChildren().add(operaciones.html("<div align='right'>"));
			this.richPanelGrillaTablaHijo.getChildren().add(linkAdicionar);
			this.richPanelGrillaTablaHijo.getChildren().add(operaciones.html("</div>"));
			this.richPanelGrillaTablaHijo.getChildren().add(toolTipAdicionar);
		}
	}

	/**
	 * Metodo que arma dinammicamente el detalle de un registro de una tabla
	 * parametrica.
	 * 
	 * @param operacion
	 * @param esHijo
	 *            Boolean que indica si la operacion realizada es sobre una
	 *            tabla hijo o no.
	 */
	private void dibujarDetalleRegistro(String operacion, boolean esHijo) throws Exception {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		this.richPanelDetalleRegistro.getChildren().clear();
		if (operacion.equals(operaciones.DELETE)) {
			this.richPanelDetalleRegistro.getChildren().add(
					operaciones.html("<br/><br/><center>�Est� seguro de eliminar el registro?</center><br/><br/>"));
		} else {
			this.richPanelDetalleRegistro.getChildren().add(operaciones.html("<table border='0' cellpadding='5' valign='middle'>"));
			for (int i = 1; i < this.registro.size(); i++) {
				Columna columna = this.registro.get(i);
				if (columna.isVisible()) {
					this.richPanelDetalleRegistro.getChildren().add(
							operaciones.html("<tr><th align='right'>" + columna.getDescripcionColumna() + "</th><td>"));
					if (columna.getJoinTabla() != null
							&& (operacion.equals(operaciones.INSERT) || (operacion.equals(operaciones.UPDATE) && columna.isEditable())))
						columna.setListaValores(this.operaciones.getListaValoresColumna(columna));
					UIComponent valorColumna = operaciones.getComponente(facesContext, operacion, columna, i);
					this.richPanelDetalleRegistro.getChildren().add(valorColumna);
					this.richPanelDetalleRegistro.getChildren().add(operaciones.html("</td></tr>"));
				}
			}
			this.richPanelDetalleRegistro.getChildren().add(operaciones.html("</table><br/>"));
		}

		HtmlComponentControl richComponetControl = new HtmlComponentControl();
		richComponetControl.setFor("modalPanelDetalleRegistro");
		richComponetControl.setAttachTo(operacion);
		richComponetControl.setOperation("hide");
		richComponetControl.setEvent("onclick");

		HtmlAjaxCommandButton botonAceptar = new HtmlAjaxCommandButton();
		botonAceptar.setId("botonAceptar");
		String labelBoton = null;
		if (operacion.equals(operaciones.SELECT))
			labelBoton = "Cerrar";
		else {
			if (esHijo)
				botonAceptar.addActionListener(operaciones.crearActionListener(facesContext, "#{crudParametros.ejecutarOperacionDmlHijo}"));
			else
				botonAceptar.addActionListener(operaciones.crearActionListener(facesContext, "#{crudParametros.ejecutarOperacionDmlPadre}"));
			if (operacion.equals(operaciones.INSERT))
				labelBoton = "Registrar";
			else if (operacion.equals(operaciones.UPDATE))
				labelBoton = "Actualizar";
			else if (operacion.equals(operaciones.DELETE))
				labelBoton = "Eliminar";
		}
		botonAceptar.setValue(labelBoton);
		botonAceptar.setId(operacion);
		if (esHijo)
			botonAceptar.setReRender("panelDetalleTablaHijo, msjError");
		else
			botonAceptar.setReRender("panelDetalleTabla, msjError");
		botonAceptar.getChildren().add(richComponetControl);
		this.richPanelDetalleRegistro.getChildren().add(operaciones.html("<div align='center'>"));
		this.richPanelDetalleRegistro.getChildren().add(botonAceptar);
		this.richPanelDetalleRegistro.getChildren().add(operaciones.html("</div>"));
	}

	/**
	 * Metodo que obtiene el registro de una tabla a partir de una fila.
	 * 
	 * @param filaRegistro
	 * @param esHijo
	 *            Boolean que indica si la operacion sera sobre una tabla hijo o
	 *            no.
	 */
	private void getRegistroTabla(int filaRegistro, boolean esHijo) {
		try {
			Tabla tabla = new Tabla();
			if (esHijo) {
				String tablaHijo = this.tablasVisibles.get(this.filaTabla).getMaestroDetalle().getTablaHijo();
				for (Tabla tab : this.tablas) {
					if (tab.getNombreTabla().equals(tablaHijo)) {
						tabla = null;
						tabla = tab;
						break;
					}
				}
			} else
				tabla = this.tablasVisibles.get(this.filaTabla);
			this.registro = null;
			this.registro = tabla.clonarColumnas();
			if (filaRegistro >= 0) {
				List<String> datosRegistro = null;
				if (esHijo)
					datosRegistro = this.datosHijo.get(filaRegistro);
				else
					datosRegistro = this.datos.get(filaRegistro);
				for (int i = 0; i < datosRegistro.size(); i++) {
					if (i == 0)
						this.registro.set(0, new Columna(datosRegistro.get(0)));
					else {
						if (this.registro.get(i).getTipoDato().startsWith(operaciones.FECHA)) {
							SimpleDateFormat sdf = new SimpleDateFormat();
							if (this.registro.get(i).getTipoDato().equals(operaciones.FECHA))
								sdf.applyPattern(operaciones.FORMATO_FECHA_JAVA);
							else if (this.registro.get(i).getTipoDato().equals(operaciones.FECHA_HORA))
								sdf.applyPattern(operaciones.FORMATO_FECHA_HORA_JAVA);
							Date date = sdf.parse(datosRegistro.get(i));
							this.registro.get(i).setValor(date);
							this.registro.get(i).setValorOriginal(SerializationUtils.clone(date));
						} else {
							this.registro.get(i).setValor(datosRegistro.get(i));
							this.registro.get(i).setValorOriginal(SerializationUtils.clone(datosRegistro.get(i)));
						}
					}
				}
			} else if (filaRegistro == -1 && esHijo) {
				List<String> registroPadre = this.datos.get(this.filaRegistroPadre);
				String campoHijo = this.tablasVisibles.get(this.filaTabla).getMaestroDetalle().getJoinColumnaHijo();
				for (int i = 1; i < this.registro.size(); i++) {
					if (this.registro.get(i).getNombreColumna().equals(campoHijo)) {
						this.registro.get(i).setValor(registroPadre.get(i));
						this.registro.get(i).setEditable(false);
						break;
					}
				}
			}
		} catch (Exception e) {
			String mensajeError = "Error en la obtencion de datos del registro seleccionado. ";
			mostrarMsjError(mensajeError);
			log.error(mensajeError + e.toString());
		}
	}

	/**
	 * M�todo que inicia la recuperacion y el armado de la interface de
	 * configuracion de tablas parametricas
	 * 
	 */
	private void iniciar() throws Exception {
		this.tablasVisibles = null;
		this.registro = null;
		this.datos = null;
		this.datosHijo = null;
		this.filaTabla = -1;
		this.filaRegistroPadre = -1;
		this.txtFilterPadre = null;
		this.txtFilterHijo = null;

		this.richPanelGrillaTabla.getChildren().clear();
		this.richPanelGrillaTabla.setHeader("");
		this.richPanelGrillaTablaHijo.getChildren().clear();
		this.richPanelGrillaTablaHijo.setHeader("");
		this.richPanelDetalleRegistro.getChildren().clear();
		this.msjError.setValue("");

		log.info("Iniciando el modulo administracion de tablas parametricas.");
		this.operaciones = new OperacionesParametros();
		this.tablas = this.operaciones.getTablasParametricas();
		this.filtarTablasVisibles();
	}

	/**
	 * Metodo que filtra las tablas que pueden ser visibles
	 * 
	 */
	private void filtarTablasVisibles() {
		if (this.tablas.size() > 0) {
			this.tablasVisibles = new ArrayList<Tabla>();
			for (Tabla tabla : this.tablas) {
				if (tabla.isVisible())
					this.tablasVisibles.add(tabla);
			}
		}
	}

	/**
	 * Metodo que adiciona dinamicamente un mensaje de error informativo
	 * 
	 * @param msjError
	 */
	private void mostrarMsjError(String mensajeError) {
		if (mensajeError != null && mensajeError.length() > 0) {
			StringBuilder sb = new StringBuilder();
			sb.append("<script language='javascript'>");
			sb.append("alert(\"").append(mensajeError).append("\");");
			sb.append("</script>");
			this.msjError.setValue(sb.toString());
		}
	}

	/**
	 * [PENDIENTE] Este metodo debe obtener los campos de logs para registrar
	 * logs de auditoria.
	 * 
	 * @return
	 */
	private Map<String, String> getLogs() {
		final String LOG_USUARIO = "cod_usuario";
		final String LOG_FECHA_HORA = "fecha_hora";
		final String LOG_ESTACION = "estacion";
		Map<String, String> logs = new HashMap<String, String>();
		logs.put(LOG_USUARIO, "'ADM'");
		logs.put(LOG_FECHA_HORA, "current");
		logs.put(LOG_ESTACION, "''ADM''");
		return logs;
	}

}
