/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-web-sirAladi
 * gob.bcb.portal.sirAladi.commons.Constantes
 * 11/11/2011 - 17:14:42
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.commons;

/**
 * Clase que contiene las constantes de la aplicacion web
 * 
 * @author wherrera
 * 
 */
public class Constantes {

	// Constantes de para la aplicaci�n.
	public static String URL_QUEUE_SERVICIO = null;
	public static String NOMBRE_QUEUE_SERVICIO = null;
	public static String QUEUE_SERVICIO_ADJUNTOS = null;
	public static String DIRECTORIO_ADJUNTOS = null;
	public static String SERVIDOR = null;

	// Constantes de formatos de fechas.
	public static final String FORMATO_FECHA_JAVA = "dd/MM/yyyy";
	public static final String FORMATO_FECHA_HORA_JAVA = "dd/MM/yyyy HH:mm:ss";

	// Constantes de estilos css para componentes html.
	public static final String ESTILO_VISIBLE = "display:block;";
	public static final String ESTILO_INVISIBLE = "display:none;";
	public static final String PARAM_TIPO_REPORTE = "formatoReporte";

	// Constantes de nombres de dato de la tabla claves.
	public static final String CVE_ESTADO = "cve_estado";
	public static final String CVE_ESTADO_PLAN_PAGO = "cve_estado_plan";
	public static final String CVE_TIPO_EMISION = "cve_tipo_emis";
	public static final String CVE_ESTADO_REGISTRO = "cve_estado_reg";
	public static final String CVE_ESTADO_PAGO = "cve_estado_pago";
	public static final String CVE_TIPO_MIME = "cve_tipo_mime";
	public static final String CVE_ESTADO_APERTURA = "cve_estado_ape";
	public static final String CVE_TIPO_APERTURA = "cve_tipo_ape";
	public static final String CVE_ESTADO_PAGO_ANT = "cve_estado_ant";
	public static final String CVE_TIPO_INST = "cve_tipo_inst";
	public static final String CVE_TIPOCTAINST = "pec_tipoctainst";
	public static final String CVE_ESTSWIFT = "men_cveestswift";

	// Constantes de codigos de operaciones para el servicio del Sir Aladi.
	public static final String REGISTRAR_EMISION = "AL0101";
	public static final String MODIFICAR_EMISION = "AL0102";
	public static final String ELIMINAR_EMISION = "AL0105";
	public static final String ANULAR_EMISION = "AL0106";
	public static final String MODIFICAR_APERTURA = "AL0107";

	public static final String REGISTRAR_REGISTRO = "AL0201";
	public static final String MODIFICAR_REGISTRO = "AL0202";
	public static final String ELIMINAR_REGISTRO = "AL0205";

	public static final String REGISTRAR_DEBITO_REEMBOLSO = "AL0301";
	public static final String MODIFICAR_DEBITO_REEMBOLSO = "AL0302";
	public static final String ELIMINAR_DEBITO_REEMBOLSO = "AL0309";
	public static final String CONSULTAR_PAGOS_ALADI = "AL0305";
	public static final String REGISTRAR_PAGOS_ALADI = "AL0307";

	public static final String GUARDAR_OPERACION_NO_REGISTRADA = "AL0306";
	public static final String ELIMINAR_OPERACION_NO_REGISTRADA = "AL0310";

	public static final String REGISTRAR_PAGOS_ANTICIPADOS = "AL0401";
	public static final String MODIFICAR_PAGO_ANTICIPADO = "AL0404";
	public static final String CONSULTAR_SALDOS_CONVENIO = "AL0403";
	public static final String ELIMIAR_PAGO_ANTICIPADO = "AL0405";

	public static final String MODIFICAR_CUOTA_PLAN_PAGO = "AL0504";
	public static final String ENVIAR_PLAN_PAGOS_A_ALADI = "AL0502";

	public static final String CONSULTAR_INSTITUCIONES_AUTORIZADAS = "AL0601";
	public static final String GUARDAR_INSTITUCIONES_AUTORIZADAS = "AL0602";

	// Constantes propias de la logica del sir aladi.
	public static final String TIPO_APERTURA_IMPORTACION = "I";
	public static final String TIPO_APERTURA_EXPORTACION = "E";

	public static final String ESTADO_EMISION = "E";
	public static final String ESTADO_NEGOCIACION = "N";
	public static final String ESTADO_PENDIENTE = "P";
	public static final String ESTADO_PREAUTORIZADO = "1";
	public static final String ESTADO_CONTABILIZADO = "C";
	public static final String ESTADO_SUSPENDIDO = "S";
	public static final String ESTADO_VIGENTE = "V";
	public static final String ESTADO_LIQUIDADO = "L";

	public static final String TIPO_EMISION_EMISION = "E";
	public static final String TIPO_EMISION_INCREMENTO = "I";
	public static final String TIPO_EMISION_DECREMENTO = "D";
	public static final String TIPO_MOVIMIENTO_APERTURA = "A";

	public static final String CODIGO_PAIS_BOLIVIA = "02";
	public static final String CODIGO_PERSONA_BCB = "900";
	public static final String CODIGO_INSTITUCION_BCB = "0660";
	public static final String CODIGO_MONEDA_DOLARES = "34";
	public static final String CODIGO_ID_PAGO_ANTICIPADO = "9";
	public static final String CODIGO_INSTRUMENTO_PAGO_ANTICIPADO = "LEX";

	public static final String ADMINSITRADOR_BCB = "adminCentr";
	public static final String AUTORIZADOR_BCB = "adminBCB";
	public static final String OPERADOR_BCB = "opeBCB";

	public static final String AUTORIZADOR_EXTERNO = "admin";
	public static final String OPERADOR_EXTERNO = "ope";

	public static final String SUCCESS = "Success";
	public static final String SESSION_KEY_USER = "sessionScope.visit";

	// asignacion de valores a las constantes (spring).
	private String urlQueueServicio;
	private String nombreQueueServicio;
	private String queueServicioAdjuntos;
	private String directorioAdjuntos;
	private String servidor;

	public void setUrlQueueServicio(String urlQueueServicio) {
		this.urlQueueServicio = urlQueueServicio;
		if (URL_QUEUE_SERVICIO == null)
			URL_QUEUE_SERVICIO = this.urlQueueServicio;
	}

	public void setNombreQueueServicio(String nombreQueueServicio) {
		this.nombreQueueServicio = nombreQueueServicio;
		if (NOMBRE_QUEUE_SERVICIO == null)
			NOMBRE_QUEUE_SERVICIO = this.nombreQueueServicio;
	}

	public void setQueueServicioAdjuntos(String queueServicioAdjuntos) {
		this.queueServicioAdjuntos = queueServicioAdjuntos;
		if (QUEUE_SERVICIO_ADJUNTOS == null)
			QUEUE_SERVICIO_ADJUNTOS = this.queueServicioAdjuntos;
	}

	public void setDirectorioAdjuntos(String directorioAdjuntos) {
		this.directorioAdjuntos = directorioAdjuntos;
		if (DIRECTORIO_ADJUNTOS == null)
			DIRECTORIO_ADJUNTOS = this.directorioAdjuntos;
	}

	public void setServidor(String servidor) {
		this.servidor = servidor;
		if (SERVIDOR == null)
			SERVIDOR = this.servidor;
	}

}
