/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-sirAladi
 * gob.bcb.portal.sirAladi.reportes.controller.RepHistoricoController
 * 26/07/2011 - 14:49:03
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.reportes.controller;

import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarMapDescripcionClaves;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarSelectDescripcionClaves;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarSelectItemsPaises;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_ESTADO_APERTURA;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_ESTADO_PAGO;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_ESTADO_PLAN_PAGO;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_ESTADO_REGISTRO;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_TIPO_APERTURA;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_TIPO_EMISION;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTILO_INVISIBLE;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTILO_VISIBLE;
import static gob.bcb.portal.sirAladi.commons.Constantes.TIPO_APERTURA_IMPORTACION;
import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.Pago;
import gob.bcb.bpm.siraladi.jpa.PlanPago;
import gob.bcb.bpm.siraladi.jpa.Registro;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;
import gob.bcb.portal.sirAladi.controller.MainAladiController;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

/**
 * Backing Bean para la vista de Reportes Historicos.
 * 
 * @author wherrera
 * 
 */
public class RepHistoricoController extends BaseBeanController {
	private String filtro;
	private String descPagos;
	private BigDecimal totalEmisionInstrumento;
	private BigDecimal totalSaldoInstrumento;
	private boolean desabilitado;
	private Apertura apertura;
	private PlanPago totalPlanPago;

	private List<Registro> registros;
	private List<PlanPago> planPagos;
	private List<Pago> debitos;
	private BigDecimal totalReg;
	private BigDecimal totalPag;
	private Map<String, String> mapClavesTipoEmision;
	private Map<String, String> mapClavesEstadoRegistro;
	private Map<String, String> mapClavesEstadoPlan;
	private Map<String, String> mapClavesEstadoPago;
	private Map<String, String> mapClavesTipoApertura;
	private Map<String, String> mapClavesEstadoApertura;
	private List<SelectItem> itemsPaisesExterior;
	private List<SelectItem> itemsTipoOperacion;
	private List<SelectItem> itemsEstadoApertura;

	private static Logger log = Logger.getLogger(RepHistoricoController.class);

	public RepHistoricoController() {
	}

	@PostConstruct
	public void init() {
		log.info("Iniciando el modulo de Reportes y Consulta de Historicos.");
		recuperarVisit();
		this.crearObjetosPorDefecto();
		try {
			this.cargarCombos();
		} catch (Exception e) {
			log.error("Ocurrio un error: " + e.getMessage(), e);
		}

		if (getVisit().getParametro("SIRWEB_TMP_OBJECT") != null) {
			if (!(getVisit().getParametro("SIRWEB_TMP_OBJECT") instanceof RepHistoricoController)) {
				//getVisit().removeParametro("SIRWEB_TMP_OBJECT");
			} else {
			}
		}

		if (getVisit().getCurrentApertura() != null){
			this.apertura = getSirAladiDao().getApertura(getVisit().getCurrentApertura().getNroMov());
			this.obtenerHistorial(this.apertura.getNroMov());			
		} 
	}
	
	public TimeZone getTimeZone() {
		return TimeZone.getDefault();
	}

	public boolean isHabilitado() {
		return !desabilitado;
	}

	public String getFiltro() {
		return filtro;
	}

	public void setFiltro(String filtro) {
		this.filtro = filtro;
	}

	public Map<String, String> getMapClavesTipoEmision() {
		return mapClavesTipoEmision;
	}

	public void setMapClavesTipoEmision(Map<String, String> mapClavesTipoEmision) {
		this.mapClavesTipoEmision = mapClavesTipoEmision;
	}

	public Map<String, String> getMapClavesEstadoRegistro() {
		return mapClavesEstadoRegistro;
	}

	public void setMapClavesEstadoRegistro(Map<String, String> mapClavesEstadoRegistro) {
		this.mapClavesEstadoRegistro = mapClavesEstadoRegistro;
	}

	public Map<String, String> getMapClavesEstadoPlan() {
		return mapClavesEstadoPlan;
	}

	public void setMapClavesEstadoPlan(Map<String, String> mapClavesEstadoPlan) {
		this.mapClavesEstadoPlan = mapClavesEstadoPlan;
	}

	public Map<String, String> getMapClavesEstadoPago() {
		return mapClavesEstadoPago;
	}

	public void setMapClavesEstadoPago(Map<String, String> mapClavesEstadoPago) {
		this.mapClavesEstadoPago = mapClavesEstadoPago;
	}

	public Map<String, String> getMapClavesTipoApertura() {
		return mapClavesTipoApertura;
	}

	public void setMapClavesTipoApertura(Map<String, String> mapClavesTipoApertura) {
		this.mapClavesTipoApertura = mapClavesTipoApertura;
	}

	public Map<String, String> getMapClavesEstadoApertura() {
		return mapClavesEstadoApertura;
	}

	public void setMapClavesEstadoApertura(Map<String, String> mapClavesEstadoApertura) {
		this.mapClavesEstadoApertura = mapClavesEstadoApertura;
	}

	public Apertura getApertura() {
		return apertura;
	}

	public void setApertura(Apertura apertura) {
		this.apertura = apertura;
	}

	public List<Registro> getRegistros() {
		return registros;
	}

	public List<PlanPago> getPlanPagos() {
		return planPagos;
	}

	public PlanPago getTotalPlanPago() {
		return totalPlanPago;
	}

	public List<Pago> getDebitos() {
		return debitos;
	}

	public BigDecimal getTotalReg() {
		return totalReg;
	}

	public BigDecimal getTotalPag() {
		return totalPag;
	}

	public String getDescPagos() {
		return descPagos;
	}

	public BigDecimal getTotalEmisionInstrumento() {
		return totalEmisionInstrumento;
	}

	public BigDecimal getTotalSaldoInstrumento() {
		return totalSaldoInstrumento;
	}

	public String getEstiloBuscar() {
		return !this.desabilitado ? ESTILO_INVISIBLE : ESTILO_VISIBLE;
	}

	public String getEstiloLimpiar() {
		return this.desabilitado ? ESTILO_INVISIBLE : ESTILO_VISIBLE;
	}

	private void obtenerHistorial(Integer nroMovApertura) {
		this.descPagos = (TIPO_APERTURA_IMPORTACION.equals(this.apertura.getCveTipoApe())) ? "D�bitos" : "Cobros";
		this.desabilitado = false;

		// saldos
		this.totalEmisionInstrumento = getSirAladiDao().getMontoInstrumento(nroMovApertura);
		BigDecimal totalPagado = getSirAladiDao().getMontoPagadoInstrumento(nroMovApertura);
		this.totalSaldoInstrumento = this.totalEmisionInstrumento.subtract(totalPagado);
		// registros
		this.registros = getSirAladiDao().getRegistros(nroMovApertura);
		this.totalReg = BigDecimal.ZERO;
		if (this.registros != null && this.registros.size() > 0) {
			for (Registro r : this.registros)
				this.totalReg = this.totalReg.add(r.getDebeMo().subtract(r.getHaberMo()));
		}
		// plan de pagos
		this.planPagos = getSirAladiDao().getPlanPagos(nroMovApertura);
		this.calcularTotalPlanPago();
		// pagos
		this.debitos = getSirAladiDao().getPagos(nroMovApertura);
		this.totalPag = BigDecimal.ZERO;
		if (this.debitos != null && this.debitos.size() > 0) {
			for (Pago p : this.debitos)
				this.totalPag = this.totalPag.add(p.getHaberMo().subtract(p.getDebeMo()));
		}
	}

	private void calcularTotalPlanPago() {
		this.totalPlanPago = new PlanPago();
		this.totalPlanPago.setCapital(BigDecimal.ZERO);
		this.totalPlanPago.setInteres(BigDecimal.ZERO);
		this.totalPlanPago.setMonto(BigDecimal.ZERO);
		if (this.planPagos.size() > 0) {
			for (PlanPago cuota : this.planPagos) {
				if (cuota.getCveEstadoPlan() != null && (cuota.getCveEstadoPlan().trim().equals("N") || cuota.getCveEstadoPlan().trim().equals("P"))) {
					// solo se suma los pendientes
					this.totalPlanPago.setCapital(this.totalPlanPago.getCapital().add(cuota.getCapital()));
					this.totalPlanPago.setInteres(this.totalPlanPago.getInteres().add(cuota.getInteres()));
					this.totalPlanPago.setMonto(this.totalPlanPago.getMonto().add(cuota.getMonto()));
				}
			}
		}
	}

	public void irEnmiendas(ActionEvent event) {
		MainAladiController.irA("/Modulos/Comunes/enmiendas.xhtml", this.apertura.getCveTipoApe(), this.apertura.getNroMov());
	}

	public void irPlanPagos(ActionEvent event) {
		MainAladiController.irA("/Modulos/Comunes/negociaciones.xhtml", this.apertura.getCveTipoApe(), this.apertura.getNroMov());
	}

	public void irPagos(ActionEvent event) {
		MainAladiController.irA("/Modulos/Comunes/pagosCobros.xhtml", this.apertura.getCveTipoApe(), this.apertura.getNroMov());
	}

	public void limpiar(ActionEvent event) {
		this.crearObjetosPorDefecto();
		getVisit().removeParametro("SIRWEB_TMP_OBJECT");
	}

	public void mostrarReporte(ActionEvent event) {
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("NRO_MOV", this.apertura.getNroMov());
		parametros.put("TITULO", "HISTORICO DE OPERACIONES DE INSTRUMENTO");
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("pathTranslated", request.getPathTranslated());
		request.getSession().setAttribute("nombreReporte", "repHistorico.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}

	public void mostrarAdjunto(ActionEvent event) {
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("nroMov", this.apertura.getNroMov());
	}

	private void crearObjetosPorDefecto() {
		this.desabilitado = true;

		// Historico
		this.registros = new ArrayList<Registro>();
		this.planPagos = new ArrayList<PlanPago>();
		this.debitos = new ArrayList<Pago>();

		// mapas de descripciones de codigos y estados
		this.mapClavesEstadoPlan = armarMapDescripcionClaves(getSirAladiDao().getClaves(CVE_ESTADO_PLAN_PAGO));
		this.mapClavesTipoEmision = armarMapDescripcionClaves(getSirAladiDao().getClaves(CVE_TIPO_EMISION));
		this.mapClavesEstadoRegistro = armarMapDescripcionClaves(getSirAladiDao().getClaves(CVE_ESTADO_REGISTRO));
		this.mapClavesEstadoPago = armarMapDescripcionClaves(getSirAladiDao().getClaves(CVE_ESTADO_PAGO));
		this.mapClavesTipoApertura = armarMapDescripcionClaves(getSirAladiDao().getClaves(CVE_TIPO_APERTURA));
		this.mapClavesEstadoApertura = armarMapDescripcionClaves(getSirAladiDao().getClaves(CVE_ESTADO_APERTURA));
	}

	private void cargarCombos() {
		this.itemsPaisesExterior = armarSelectItemsPaises(getSirAladiDao().getPaisesExterior());
		this.itemsTipoOperacion = armarSelectDescripcionClaves(getSirAladiDao().getClaves(CVE_TIPO_APERTURA));
		this.itemsEstadoApertura = armarSelectDescripcionClaves(getSirAladiDao().getClaves(CVE_ESTADO_APERTURA));
	}

	public void setItemsPaisesExterior(List<SelectItem> itemsPaisesExterior) {
		this.itemsPaisesExterior = itemsPaisesExterior;
	}

	public List<SelectItem> getItemsPaisesExterior() {
		return itemsPaisesExterior;
	}

	public void setItemsTipoOperacion(List<SelectItem> itemsTipoOperacion) {
		this.itemsTipoOperacion = itemsTipoOperacion;
	}

	public List<SelectItem> getItemsTipoOperacion() {
		return itemsTipoOperacion;
	}

	public void setItemsEstadoApertura(List<SelectItem> itemsEstadoApertura) {
		this.itemsEstadoApertura = itemsEstadoApertura;
	}

	public List<SelectItem> getItemsEstadoApertura() {
		return itemsEstadoApertura;
	}
}
