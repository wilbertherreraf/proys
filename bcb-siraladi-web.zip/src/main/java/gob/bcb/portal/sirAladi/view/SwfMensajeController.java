package gob.bcb.portal.sirAladi.view;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import gob.bcb.bpm.siraladi.jpa.Claves;
import gob.bcb.bpm.siraladi.jpa.Param;
import gob.bcb.bpm.siraladi.jpa.SwfDetmensaje;
import gob.bcb.bpm.siraladi.jpa.SwfMensaje;
import gob.bcb.bpm.siraladi.service.ClienteOtp;
import gob.bcb.bpm.siraladi.utils.Constants;
import gob.bcb.core.utils.ArchivoSinple;
import gob.bcb.core.utils.ArchivoUtil;
import gob.bcb.lavado.client.HandlerGeneratorLauCli;
import gob.bcb.portal.sirAladi.commons.Archivo;
import gob.bcb.portal.sirAladi.commons.Constantes;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;
import gob.bcb.swift.exception.SwiftAdminException;
import gob.bcb.swift.pojos.SwiftDatos;
import gob.bcb.swift.service.ReporteSwift;

public class SwfMensajeController extends BaseBeanController {
	private static Logger log = Logger.getLogger(SwfMensajeController.class);
	private SwfMensaje swfMensajeSelected = new SwfMensaje();
	private SwfDetmensaje swfDetmensajeSelected = new SwfDetmensaje();
	private List<SwfDetmensaje> swfDetmensajeLista = new ArrayList<SwfDetmensaje>();
	private List<SelectItem> cveestswiftItems;
	private Map<String, String> cveestswiftMap;

	private ReporteSwift reporteSwift = new ReporteSwift();
	public static String FILE_REPORT_SWIFT = "reposwiftsend.docx";

	@PostConstruct
	public void init() {
		log.info("Iniciando el modulo de adm swift");
		recuperarVisit();
		
		Param param = null;
		
		try {
			param = getServiceDao().getParamsLocal().findByCodigo(Constants.PARAM_PATHSWIFT);
		
			String pathSwift = param.getValparam();
			File d0 = new File(pathSwift);
			HandlerGeneratorLauCli.initCurrentInstance(d0.getParent(), Constants.NOMBRE_APP);
		} catch (Exception e) {
			log.error("Error al inicializar cliente LAU: " + e.getMessage(), e);
			throw new RuntimeException("Error al inicializar cliente LAU " + e.getMessage(), e);
		}
		
		getCveestswiftItems();
		Integer codigomensaje = (Integer) getVisit().getParametro("SIRWEB_CODMENSAJE");
		recuperarDatos(codigomensaje);

		// inicialiar reporte swift
		InputStream in = SwfMensajeController.class.getClassLoader().getResourceAsStream(FILE_REPORT_SWIFT);

		reporteSwift.initArchivoTemplate(in, FILE_REPORT_SWIFT);
		reporteSwift.inicializar();
	}

	private void recuperarDatos(Integer codigomensaje) {
		log.info("Recuperando mensaje " + codigomensaje);
		swfMensajeSelected = getServiceDao().getSwfMensajeLocal().findByCodigo(codigomensaje);
		swfDetmensajeLista = getServiceDao().getSwfDetmensajeLocal().findByCodMen(codigomensaje);
	}

	public void verReporte() {
		log.info("XXX: reporte " + swfMensajeSelected.getMenCodmen());
		try {
			SwfMensaje swfMensaje = getServiceDao().getSwfMensajeLocal().findByCodigo(swfMensajeSelected.getMenCodmen());

			SwiftDatos swiftDatos = getServiceDao().getSwfMensajeLocal().swiftDatosFromSwfMensaje(swfMensaje);

			ArchivoSinple archivoSinplePDF = generarReporte(swfMensaje.getMenPlano(), swiftDatos);

			Archivo archivo = new Archivo();
			archivo.setLength(archivoSinplePDF.getData().length);
			archivo.setMime(archivoSinplePDF.getContentType());
			archivo.setNombre(archivoSinplePDF.getNameOriginal());
			archivo.setExtension("pdf");
			// this.apertura.getCodigoReembolsoCorrido());
			archivo.setData(archivoSinplePDF.getData());
			HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
			request.getSession().setAttribute("adjunto", archivo);
			// downloadFile(archivoSinple);
		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error :" + e.getMessage(), e.getMessage());
			FacesContext.getCurrentInstance().addMessage(null, msg);
		}
	}
	public void generarNroSwift() {
		log.info("XXX: generarNroSwift " + swfMensajeSelected.getMenCodmen());
		try {
			swfMensajeSelected.setMenAuditusr(getVisit().getUsuarioSirAladi().getLogin());
			swfMensajeSelected.setMenAuditwst(getVisit().getAddress());
			
			swfMensajeSelected = getServiceDao().getSwiftMessageServiceLocal().actualizarCorrelativo(swfMensajeSelected);
			
			recuperarDatos(swfMensajeSelected.getMenCodmen());
			
			log.info("Actualizaion de nro swift hecho: " + swfMensajeSelected.getMenCodmen() + " " + swfMensajeSelected.getMenNrocorr());			
			addMessageInfo("Aviso", "Correlativo Swift generado para " + swfMensajeSelected.getMenCodmen() + " con numero correlativo " + swfMensajeSelected.getMenNrocorr());			
		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}
	
	public void autorizarSwift() {
		log.info("autorizarSwift " + swfMensajeSelected.getMenCodmen());
		try {
			Param param = getServiceDao().getParamsLocal().findByCodigo(Constants.PARAM_OTP_RESOURCE);			
			String urlotp = param.getValparam();
			
			param = getServiceDao().getParamsLocal().findByCodigo("verifica-otp");
			String verificaotp = param.getValparam();
			
			if (verificaotp.equalsIgnoreCase("S")){
				log.info("Verifica con OTP ::> " + getCodeOtp() + ", urlotp: " + urlotp);
				ClienteOtp clienteOtp = new ClienteOtp(urlotp);
				clienteOtp.verificarCodigo(getVisit().getUsuarioSirAladi().getLogin().trim(), getCodeOtp());			
				setCodeOtp(null);				
			} else {
				log.info("NO Verifica con OTP");
			}
			
			swfMensajeSelected.setMenAuditusr(getVisit().getUsuarioSirAladi().getLogin());
			swfMensajeSelected.setMenAuditwst(getVisit().getAddress());
			
			swfMensajeSelected = getServiceDao().getSwiftMessageServiceLocal().autorizarMensaje(swfMensajeSelected);
			
			recuperarDatos(swfMensajeSelected.getMenCodmen());
			
			log.info("autorizar Mensaje swift hecho: " + swfMensajeSelected.getMenCodmen() + " " + swfMensajeSelected.getMenNrocorr());
			addMessageInfo("Aviso", "Mensaje autorizado para " + swfMensajeSelected.getMenCodmen() + " con numero correlativo " + swfMensajeSelected.getMenNrocorr());
		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}
	public void actualizarSwift() {
		log.info("actualizar Swift " + swfMensajeSelected.getMenCodmen());
		try {
			swfMensajeSelected.setMenAuditusr(getVisit().getUsuarioSirAladi().getLogin());
			swfMensajeSelected.setMenAuditwst(getVisit().getAddress());
			
			swfMensajeSelected = getServiceDao().getSwiftMessageServiceLocal().actualizarMensaje(swfMensajeSelected);
			
			recuperarDatos(swfMensajeSelected.getMenCodmen());
			
			log.info("autorizar Mensaje swift hecho: " + swfMensajeSelected.getMenCodmen() + " " + swfMensajeSelected.getMenNrocorr());
			addMessageInfo("Aviso", "Mensaje actualizado para " + swfMensajeSelected.getMenCodmen() + " con numero correlativo " + swfMensajeSelected.getMenNrocorr());
		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}	
	public void rechazarSwift() {
		log.info("rechazar Swift " + swfMensajeSelected.getMenCodmen());
		try {
			getServiceDao().getSwfMensajeLocal().rechazarSwift(swfMensajeSelected.getMenCodmen(), getVisit().getUsuarioSirAladi().getLogin(), getVisit().getAddress());
			
			recuperarDatos(swfMensajeSelected.getMenCodmen());
			
			log.info("autorizar Mensaje swift hecho: " + swfMensajeSelected.getMenCodmen() + " " + swfMensajeSelected.getMenNrocorr());
			addMessageInfo("Aviso", "Mensaje rechazado para " + swfMensajeSelected.getMenCodmen());
		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}	
	private ArchivoSinple generarReporte(String swiftPlano, SwiftDatos mensajesDatos) {

		try {
			mensajesDatos.setAuditusr(getVisit().getUsuarioSirAladi().getLogin());
			mensajesDatos.setAuditwst(getVisit().getAddress());			
			Param param = getServiceDao().getParamsLocal().findByCodigo("pathswift");
			reporteSwift.populateReport(swiftPlano, mensajesDatos);

			reporteSwift.render();
			String nameFile = "reportSwf_" + mensajesDatos.getSwfMensaje().getMenCodmt() + "_" + mensajesDatos.getSwfMensaje().getMenCodmen()
					+ ".pdf";
			ArchivoSinple archivoSinplePDF = reporteSwift.convertToPDF(reporteSwift.getArchivoSinple(), nameFile);
			
			archivoSinplePDF.setDirectory(param.getValparam());
			archivoSinplePDF.setName(archivoSinplePDF.getHash() + "." + ArchivoUtil.obtenerExtension(archivoSinplePDF.getNameOriginal()));
			archivoSinplePDF.putPathFile();			
			log.info("reporte PDF generado " + archivoSinplePDF.getNameOriginal());
			return archivoSinplePDF;
		} catch (Exception e) {
			log.error("Error al renderizar reporte swift!!!!!! " + e.getMessage(), e);
			throw new SwiftAdminException(e.getMessage(), e);
		} catch (Throwable e) {
			log.error("Throwable: Error al renderizar reporte swift!!!!!! " + e.getMessage(), e);
			throw new SwiftAdminException(e.getMessage(), e);
		}

	}

	public SwfMensaje getSwfMensajeSelected() {
		return swfMensajeSelected;
	}

	public void setSwfMensajeSelected(SwfMensaje swfMensajeSelected) {
		this.swfMensajeSelected = swfMensajeSelected;
	}

	public SwfDetmensaje getSwfDetmensajeSelected() {
		return swfDetmensajeSelected;
	}

	public void setSwfDetmensajeSelected(SwfDetmensaje swfDetmensajeSelected) {
		this.swfDetmensajeSelected = swfDetmensajeSelected;
	}

	public List<SwfDetmensaje> getSwfDetmensajeLista() {
		return swfDetmensajeLista;
	}

	public void setSwfDetmensajeLista(List<SwfDetmensaje> swfDetmensajeLista) {
		this.swfDetmensajeLista = swfDetmensajeLista;
	}

	public List<SelectItem> getCveestswiftItems() {
		if (cveestswiftItems == null) {
			cveestswiftItems = new ArrayList<SelectItem>();
			cveestswiftMap = new HashMap<String, String>();
			List<Claves> ClavesList = getServiceDao().getClavesLocal().getValoresByClave(Constantes.CVE_ESTSWIFT);
			for (Claves claves : ClavesList) {
				cveestswiftItems.add(new SelectItem(claves.getId().getValdato().trim(), claves.getInterp().trim()));
				cveestswiftMap.put(claves.getId().getValdato().trim(), claves.getInterp().trim());
			}
		}
		return cveestswiftItems;
	}

	public void setCveestswiftItems(List<SelectItem> cveestswiftItems) {
		this.cveestswiftItems = cveestswiftItems;
	}

	public Map<String, String> getCveestswiftMap() {
		return cveestswiftMap;
	}

	public void setCveestswiftMap(Map<String, String> cveestswiftMap) {
		this.cveestswiftMap = cveestswiftMap;
	}
	public static void main(String[] args) {
		File d0 = new File("/opt/aplicaciones/configuraciones/web/siraladi/swift");
		System.out.println(d0.getParent());
	}
}
