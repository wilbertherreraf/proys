package gob.bcb.portal.sirAladi.view.parametricas;

import gob.bcb.bpm.siraladi.jpa.Param;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ParametrosSistController extends BaseBeanController {
	private static final Log log = LogFactory.getLog(ParametrosSistController.class);
	private List<Param> socParametrosLista = new ArrayList<Param>();
	private Param socParametrosSelected = new Param();
	private String mensaje = "";	
	
	@PostConstruct
	public void init() {
		log.info("PostConstruct - " + getClass().getName());
		try {
			recuperarVisit();

			recuperarDatos();
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Ocurrió un error: " + e.getMessage(), null));
		}
		
	}
	private void recuperarDatos() {
		socParametrosSelected = new Param();		
		
		socParametrosLista = getServiceDao().getParamsLocal().findAll();
	}
	public void adicionar() {
		socParametrosSelected = new Param();
	}
	public void editar(Param cta0) {
		socParametrosSelected = getServiceDao().getParamsLocal().findByCodigo(cta0.getNomparam());
	}
	
	public void guardarReg(Param socBanco) {
		socBanco.setEstacion(getVisit().getAddress());
		socBanco.setCodUsuario(getVisit().getUsuarioSirAladi().getLogin());
		socBanco.setFechaHora(new Date());
		getServiceDao().getParamsLocal().saveorupdate(socBanco);
		
	}
	public void guardar() {
		try {
			guardarReg(socParametrosSelected);
			addMessageInfo("Aviso", "La operación se realizó exitósamente.");			
			recuperarDatos();
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
		}
	}
	
	public String getMensaje() {
		return mensaje;
	}
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
	public List<Param> getSocParametrosLista() {
		return socParametrosLista;
	}
	public void setSocParametrosLista(List<Param> socParametrosLista) {
		this.socParametrosLista = socParametrosLista;
	}
	public Param getSocParametrosSelected() {
		return socParametrosSelected;
	}
	public void setSocParametrosSelected(Param socParametrosSelected) {
		this.socParametrosSelected = socParametrosSelected;
	}
}
