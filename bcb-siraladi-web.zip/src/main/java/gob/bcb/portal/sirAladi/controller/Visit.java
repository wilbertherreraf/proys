package gob.bcb.portal.sirAladi.controller;

import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.pojo.UsuarioSirAladi;

import java.util.HashMap;
import java.util.Map;

public class Visit {
	private UsuarioSirAladi usuarioSirAladi;
	private Apertura currentApertura;
	private MainAladiController mainAladiController;
	private Map<String, Object> parametro = new HashMap<String, Object>();
	private String address;
	public Visit() {
	}

	public void setUsuarioSirAladi(UsuarioSirAladi usuarioSirAladi) {
		this.usuarioSirAladi = usuarioSirAladi;
	}

	public UsuarioSirAladi getUsuarioSirAladi() {
		return usuarioSirAladi;
	}

	public void setCurrentApertura(Apertura currentApertura) {
		this.currentApertura = currentApertura;
	}

	public Apertura getCurrentApertura() {
		return currentApertura;
	}

	public void setMainAladiController(MainAladiController mainAladiController) {
		this.mainAladiController = mainAladiController;
	}

	public MainAladiController getMainAladiController() {
		return mainAladiController;
	}

	public void setParametro(String key, Object valor) {
		if (this.parametro == null){
			parametro = new HashMap<String, Object>();
		}
		if (valor == null){
			if (parametro.containsKey(key))
				parametro.remove(key);
		} else {
			if (key != null){
				parametro.put(key, valor);				
			}
		}
	}

	public Object getParametro(String key) {
		return parametro.get(key);
	}
	public void removeParametro(String key) {
		try{
			parametro.remove(key);
		}catch (Exception e) {
		}
	}
	public void limpiarParametros() {
		parametro.clear();
	}

	public void setParametro(Map<String, Object> parametro) {
		this.parametro = parametro;
	}

	public Map<String, Object> getParametro() {
		return parametro;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

}
