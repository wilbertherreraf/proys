/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-web-sirAladi
 * gob.bcb.portal.sirAladi.consultas.controller.RepInstitucionesController
 * 04/10/2011 - 10:56:28
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.reportes.controller;

import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarMapDescripcionClaves;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarSelectDescripcionClaves;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarSelectItemsPaises;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_ESTADO;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTILO_INVISIBLE;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTILO_VISIBLE;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Pais;
import gob.bcb.bpm.siraladi.jpa.SwfPersonacta;
import gob.bcb.portal.sirAladi.commons.Constantes;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;
import gob.bcb.portal.sirAladi.controller.MainAladiController;
import gob.bcb.portal.sirAladi.dao.DaoFactory;
import gob.bcb.portal.sirAladi.dao.SirAladiDao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

/**
 * Backing bean de la vista de consulta de instituciones Autorizadas
 * 
 * @author wherrera
 * 
 */
public class RepInstitucionesController extends BaseBeanController {
	private static Logger log = Logger.getLogger(RepInstitucionesController.class);

	private boolean desabilitado;

	private Pais pais;

	private SirAladiDao sirAladiDao;
	private Map<String, String> mapClavesEstado;
	private List<Institucion> listaInstituciones = new ArrayList<Institucion>();
	private Institucion institucionSearch = new Institucion();
	private Institucion institucionSelected = new Institucion();

	private List<SwfPersonacta> swfPersonactaLista = new ArrayList<SwfPersonacta>();

	private List<SelectItem> itemsPaises = new ArrayList<SelectItem>();
	private List<SelectItem> itemsTipoInst = new ArrayList<SelectItem>();
	
	@PostConstruct
	public void init() {
		log.info("Iniciando el modulo de consulta de instituciones.");
		recuperarVisit();
		this.sirAladiDao = DaoFactory.getInstance().getSirAladiDao();
		this.crearObjetosPorDefecto();

	}

	public void irDetalleInstitucion(Institucion institucion) {
		log.info("VEr detalle persona " + institucion.getCodInst());
		getVisit().setParametro("SIRWEB_CODINST", institucion.getCodInst());
		MainAladiController mainAladiController = getVisit().getMainAladiController();
		mainAladiController.removerSesiones();
		mainAladiController.setPagina("/view/Parametros/institucionDetail.xhtml");
	}

	public Pais getPais() {
		return pais;
	}

	public void setPais(Pais pais) {
		this.pais = pais;
	}

	public List<SelectItem> getItemsPaises() {
		return itemsPaises;
	}

	public void setItemsPaises(List<SelectItem> itemsPaises) {
		this.itemsPaises = itemsPaises;
	}

	public List<Institucion> getListaInstituciones() {
		return listaInstituciones;
	}

	public void setListaInstituciones(List<Institucion> listaInstituciones) {
		this.listaInstituciones = listaInstituciones;
	}

	public boolean isDesabilitado() {
		return desabilitado;
	}

	public void setDesabilitado(boolean desabilitado) {
		this.desabilitado = desabilitado;
	}

	public boolean isHabilitado() {
		return !desabilitado;
	}

	public Map<String, String> getMapClavesEstado() {
		return mapClavesEstado;
	}

	public void setMapClavesEstado(Map<String, String> mapClavesEstado) {
		this.mapClavesEstado = mapClavesEstado;
	}

	public String getEstiloPaginacionInstituciones() {
		return (this.listaInstituciones != null && this.listaInstituciones.size() > 15) ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	public String getEstiloBuscar() {
		return this.desabilitado ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	public String getEstiloLimpiar() {
		return this.desabilitado ? ESTILO_INVISIBLE : ESTILO_VISIBLE;
	}

	public boolean isPaisTodos() {
		return StringUtils.isEmpty(this.pais.getCodPais());
	}

	public void recuperarInstituciones(ActionEvent event) {
		String codPais = (StringUtils.isEmpty(this.pais.getCodPais())) ? null : this.pais.getCodPais();
		this.listaInstituciones = this.sirAladiDao.getInstitucionesReporte(codPais);
		this.desabilitado = false;
	}

	public void mostrarReporte(ActionEvent event) {
		String codPais = (StringUtils.isEmpty(institucionSearch.getPais().getCodPais())) ? "%" : institucionSearch.getPais().getCodPais();
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("TITULO", "INSTITUCIONES");
		parametros.put("COD_PAIS", codPais);
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("pathTranslated", request.getPathTranslated());
		request.getSession().setAttribute("nombreReporte", "repInstituciones.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}

	public void limpiar(ActionEvent event) {
		this.crearObjetosPorDefecto();
	}

	private void crearObjetosPorDefecto() {
		desabilitado = true;
		listaInstituciones = new ArrayList<Institucion>();
		pais = new Pais();
		itemsTipoInst = armarSelectDescripcionClaves(getSirAladiDao().getClaves(Constantes.CVE_TIPO_INST));
		// descripcion de los estados
		if (this.mapClavesEstado == null) {
			this.itemsPaises = armarSelectItemsPaises(this.sirAladiDao.getPaises());
			this.mapClavesEstado = armarMapDescripcionClaves(this.sirAladiDao.getClaves(CVE_ESTADO));
		}
		institucionSearch = new Institucion();
		institucionSearch.setPais(new Pais());
	}

//	public void tipoinstChanged(ValueChangeEvent event) {
	public void tipoinstChanged(ActionEvent event) {	
		log.info("XXX: siiiiiiiiiiiiiiiii" + institucionSearch.getCveTipoInst());
		
		listaInstituciones = getServiceDao().getInstitucionLocal().findInstituciones(institucionSearch);
		desabilitado = false;
		log.info("Recuperados " + listaInstituciones.size());
	}

	public void paisChanged(ActionEvent event) {	
		log.info("XXX: siiiiiiiiiiiiiiiii" + institucionSearch.getPais().getCodPais());
		listaInstituciones = getServiceDao().getInstitucionLocal().findInstituciones(institucionSearch);
		desabilitado = false;
		log.info("Recuperados " + listaInstituciones.size());
	}
	
	public Institucion getInstitucionSelected() {
		return institucionSelected;
	}

	public void setInstitucionSelected(Institucion institucionesSelected) {
		this.institucionSelected = institucionesSelected;
	}

	public List<SwfPersonacta> getSwfPersonactaLista() {
		return swfPersonactaLista;
	}

	public void setSwfPersonactaLista(List<SwfPersonacta> swfPersonactaLista) {
		this.swfPersonactaLista = swfPersonactaLista;
	}

	public Institucion getInstitucionSearch() {
		return institucionSearch;
	}

	public void setInstitucionSearch(Institucion institucionSearch) {
		this.institucionSearch = institucionSearch;
	}

	public List<SelectItem> getItemsTipoInst() {
		return itemsTipoInst;
	}

	public void setItemsTipoInst(List<SelectItem> itemsTipoInst) {
		this.itemsTipoInst = itemsTipoInst;
	}

}
