package gob.bcb.portal.sirAladi.view.parametricas;

import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarMapDescripcionClaves;

import static gob.bcb.portal.sirAladi.commons.AladiUtils.getAlertJS;
import gob.bcb.bpm.siraladi.jpa.Claves;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Pais;
import gob.bcb.bpm.siraladi.jpa.SwfMttransfer;
import gob.bcb.bpm.siraladi.jpa.SwfPersonacta;
import gob.bcb.bpm.siraladi.jpa.SwfPersonactaPK;
import gob.bcb.portal.sirAladi.commons.Constantes;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

public class InstitucionController extends BaseBeanController {
	private static Logger log = Logger.getLogger(InstitucionController.class);
	private List<Institucion> institucionLista = new ArrayList<Institucion>();
	private Institucion institucionSelected = new Institucion();
	private Institucion institucionEdit = new Institucion();
	private List<SwfPersonacta> swfPersonactaLista = new ArrayList<SwfPersonacta>();
	private SwfPersonacta swfPersonactaSelected = new SwfPersonacta();
	private SwfPersonacta swfPersonactaEdit = new SwfPersonacta();
	private Map<String, String> mapClavesTipoinst;

	private List<SelectItem> institucionTipoLista = null;
	private List<SelectItem> institucionInterLista = null;
	private List<SelectItem> cuentasInterLista = new ArrayList<SelectItem>();
	private List<SelectItem> tipoctainstItems;
	private List<SelectItem> tiposMensajeSwiftItems = null;
	
	@PostConstruct
	public void init() {
		recuperarVisit();
		String codInst = (String) getVisit().getParametro("SIRWEB_CODINST");
		log.info("==SIRWEB_CODINST " + codInst);
		mapClavesTipoinst = armarMapDescripcionClaves(getSirAladiDao().getClaves(Constantes.CVE_TIPO_INST));
		recuperarDatosPersona(codInst);

		recuperarCuentasInter();
		log.info("Inicializado controlador " + this.getClass().getName());
	}

	private void recuperarDatosPersona(String codPersona) {
		log.info("recupeando datos " + codPersona);
		institucionSelected = getServiceDao().getInstitucionLocal().findByCodInst(codPersona);
		swfPersonactaLista = getServiceDao().getSwfPersonactaLocal().buscarCtasPersona(codPersona, null, null, null, null, null, null);

		SwfPersonactaPK swfPersonactaPK = new SwfPersonactaPK();
		swfPersonactaSelected = new SwfPersonacta();
		swfPersonactaSelected.setId(swfPersonactaPK);
	}

	public void nuevaCuenta() {
		log.info("Inicio nueva cuenta " + institucionSelected.getCodInst());

		SwfPersonactaPK swfPersonactaPK = new SwfPersonactaPK();
		swfPersonactaPK.setPecCodpersona(institucionSelected.getCodInst());

		swfPersonactaSelected = new SwfPersonacta();
		swfPersonactaSelected.setId(swfPersonactaPK);
		swfPersonactaSelected.setPecCodmoncta("34");
		// cuenta destino sin intermediario
		swfPersonactaSelected.setPecTipoctainst("D");

	}

	public void nuevaCuentaInter() {
		log.info("Inicio nueva cuentaInter " + swfPersonactaSelected.getId().getPecCodinst());
		swfPersonactaSelected.setPecNroctainter(null);

		SwfPersonactaPK swfPersonactaPK = new SwfPersonactaPK();
		swfPersonactaEdit = new SwfPersonacta();

		if (swfPersonactaSelected.getPecTipoctainst().equals("I")) {

			swfPersonactaPK.setPecCodpersona(swfPersonactaSelected.getId().getPecCodinst());
			swfPersonactaPK.setPecCodinst(swfPersonactaSelected.getPecCodinstinter());

			swfPersonactaEdit.setPecCodmoncta("34");
			// cuenta destino sin intermediario
			swfPersonactaEdit.setPecTipoctainst("D");
		}
		swfPersonactaEdit.setId(swfPersonactaPK);
	}

	public void nuevoBancoExterno() {

		institucionEdit = new Institucion();
		Pais pais = new Pais();
		institucionEdit.setPais(pais);
	}

	public void guardarNuevoBancoExterno() {
		try {

			log.info("Guardando inst " + institucionEdit.getBic());
			institucionEdit.setCveTipoInst("E");
			getServiceDao().getInstitucionLocal().guardarInstitucion(institucionEdit);
			institucionTipoLista = null;

		} catch (Exception e) {
			log.error("error al guardar " + e.getMessage(), e);
			getAlertJS("error al guardar " + e.getMessage());
		}
	}

	public void guardarInstitucion() {
		log.info("Modificando inst " + institucionSelected.getCodInst());
		try {
			institucionSelected = getServiceDao().getInstitucionLocal().guardarInstitucion(institucionSelected);
			institucionTipoLista = null;
			recuperarDatosPersona(institucionSelected.getCodInst());
		} catch (Exception e) {
			log.error("error al guardar " + e.getMessage(), e);
			getAlertJS("error al guardar " + e.getMessage());
		}
	}

	public void guardarCuenta() {
		try {
			log.info("Guardando Cuenta " + swfPersonactaSelected.getId().getPecNrocta() + " " + swfPersonactaSelected.getId().getPecCodinst() + " "
					+ swfPersonactaSelected.getId().getPecCodpersona() + " " + swfPersonactaSelected.getPecDescripcta());

			getServiceDao().getSwfPersonactaLocal().guardarCuentaPersona(swfPersonactaSelected, swfPersonactaEdit);
			
			recuperarDatosPersona(institucionSelected.getCodInst());
		} catch (Exception e) {
			log.error("error al guardar " + e.getMessage(), e);
			getAlertJS("error al guardar " + e.getMessage());
		}

	}
	public void editarCuenta(SwfPersonacta swfPersonactaSel){
		log.info("editarCuenta " + swfPersonactaSel.getId().getPecNrocta());
		swfPersonactaSelected = getServiceDao().getSwfPersonactaLocal().findByCodigo(swfPersonactaSel.getId().getPecCodpersona(), swfPersonactaSel.getId().getPecCodinst(), swfPersonactaSel.getId().getPecNrocta());
		log.info("XXX: tipo " + swfPersonactaSelected.getPecTipoctainst());
		swfPersonactaEdit = getServiceDao().getSwfPersonactaLocal().findByCodigo(swfPersonactaSelected.getId().getPecCodinst(), swfPersonactaSelected.getPecCodinstinter(), swfPersonactaSelected.getPecNroctainter());
		
		if (swfPersonactaEdit == null){
			SwfPersonactaPK swfPersonactaPK = new SwfPersonactaPK();
			swfPersonactaEdit = new SwfPersonacta();
			swfPersonactaEdit.setId(swfPersonactaPK);
		}
	}
	public void asignarCuenta(SwfPersonacta swfPersonactaSel){
		log.info("asignarCuenta " + swfPersonactaSel.getId().getPecNrocta());
		swfPersonactaSelected = getServiceDao().getSwfPersonactaLocal().findByCodigo(swfPersonactaSel.getId().getPecCodpersona(), swfPersonactaSel.getId().getPecCodinst(), swfPersonactaSel.getId().getPecNrocta());		
		try {
			institucionSelected = getServiceDao().getInstitucionLocal().findByCodInst(swfPersonactaSelected.getId().getPecCodpersona());
			if (institucionSelected.getCveTipoInst().equals("S")){
				institucionSelected.setCtaCodinst(swfPersonactaSelected.getId().getPecCodinst());
				institucionSelected.setCtaNumero(swfPersonactaSelected.getId().getPecNrocta());
				institucionSelected = getServiceDao().getInstitucionLocal().guardarInstitucion(institucionSelected);				
			}
			institucionTipoLista = null;
			recuperarDatosPersona(institucionSelected.getCodInst());
		} catch (Exception e) {
			log.error("error al guardar " + e.getMessage(), e);
			getAlertJS("error al guardar " + e.getMessage());
		}
		
		swfPersonactaSelected = getServiceDao().getSwfPersonactaLocal().findByCodigo(swfPersonactaSel.getId().getPecCodpersona(), swfPersonactaSel.getId().getPecCodinst(), swfPersonactaSel.getId().getPecNrocta());
		log.info("XXX: tipo " + swfPersonactaSelected.getPecTipoctainst());
		swfPersonactaEdit = getServiceDao().getSwfPersonactaLocal().findByCodigo(swfPersonactaSelected.getId().getPecCodinst(), swfPersonactaSelected.getPecCodinstinter(), swfPersonactaSelected.getPecNroctainter());
		
		if (swfPersonactaEdit == null){
			SwfPersonactaPK swfPersonactaPK = new SwfPersonactaPK();
			swfPersonactaEdit = new SwfPersonacta();
			swfPersonactaEdit.setId(swfPersonactaPK);
		}
	}
	
	public void codinstChanged(ActionEvent event) {
		log.info("En codinstChanged " + swfPersonactaSelected.getId().getPecCodinst());

		swfPersonactaSelected.setPecTipoctainst("D");

		swfPersonactaSelected.setPecCodinstinter(null);
		swfPersonactaSelected.setPecNroctainter(null);

		recuperarCuentasInter();
	}

	public void tipoctainstChanged(ActionEvent event) {
		// cuando cambia el tipo de cuenta se determina si es con o sin
		// intermediario
		log.info("En tipoctainstChanged " + swfPersonactaSelected.getPecTipoctainst() + " " + swfPersonactaSelected.getId().getPecCodinst() + " "
				+ swfPersonactaSelected.getId().getPecNrocta());

		swfPersonactaSelected.setPecCodinstinter(null);
		swfPersonactaSelected.setPecNroctainter(null);

		recuperarCuentasInter();
	}

	public void codinstinterChanged(ActionEvent event) {
		// cuando cambia el bco intermediario se filtra las ctas registradas
		log.info("En codinstinterChanged " + swfPersonactaSelected.getPecCodinstinter());

		if (!StringUtils.isBlank(swfPersonactaSelected.getPecTipoctainst())) {
			if (swfPersonactaSelected.getPecTipoctainst().equals("I")) {
				if (!StringUtils.isBlank(swfPersonactaSelected.getPecCodinstinter())) {
					recuperarCuentasInter();
				}
			}
		}
	}

	public void selectItem(Institucion institucion) {
		institucionSelected = institucion;
	}

	public List<Institucion> getInstitucionLista() {
		return institucionLista;
	}

	public void setInstitucionLista(List<Institucion> institucionLista) {
		this.institucionLista = institucionLista;
	}

	public Institucion getInstitucionSelected() {
		return institucionSelected;
	}

	public void setInstitucionSelected(Institucion institucionSelected) {
		this.institucionSelected = institucionSelected;
	}

	public List<SwfPersonacta> getSwfPersonactaLista() {
		return swfPersonactaLista;
	}

	public void setSwfPersonactaLista(List<SwfPersonacta> swfPersonactaLista) {
		this.swfPersonactaLista = swfPersonactaLista;
	}

	public SwfPersonacta getSwfPersonactaSelected() {
		return swfPersonactaSelected;
	}

	public void setSwfPersonactaSelected(SwfPersonacta swfPersonactaSelected) {
		this.swfPersonactaSelected = swfPersonactaSelected;
	}

	public Map<String, String> getMapClavesTipoinst() {
		return mapClavesTipoinst;
	}

	public void setMapClavesTipoinst(Map<String, String> mapClavesTipoinst) {
		this.mapClavesTipoinst = mapClavesTipoinst;
	}

	public Institucion getInstitucionEdit() {
		return institucionEdit;
	}

	public void setInstitucionEdit(Institucion institucionEdit) {
		this.institucionEdit = institucionEdit;
	}

	public List<SelectItem> getInstitucionTipoLista() {
		// filtra entidades definidas como externas
		if (institucionTipoLista == null) {
			log.info("recuperando items instituciones externas");
			institucionTipoLista = new ArrayList<SelectItem>();

			Institucion institucionSearch = new Institucion();
			institucionSearch.setPais(new Pais());
			institucionSearch.setCveTipoInst("E");
			List<Institucion> institucionTLista = getServiceDao().getInstitucionLocal().findInstituciones(institucionSearch);
			for (Institucion institucion : institucionTLista) {
				institucionTipoLista.add(new SelectItem(institucion.getCodInst(), institucion.getNomInst() + " - " + institucion.getNomPlaza()));
			}
		}
		return institucionTipoLista;
	}

	public void setInstitucionTipoLista(List<SelectItem> institucionTipoLista) {
		this.institucionTipoLista = institucionTipoLista;
	}

	public List<SelectItem> getTipoctainstItems() {
		if (tipoctainstItems == null) {
			tipoctainstItems = new ArrayList<SelectItem>();
			List<Claves> ClavesList = getServiceDao().getClavesLocal().getValoresByClave(Constantes.CVE_TIPOCTAINST);
			for (Claves claves : ClavesList) {
				tipoctainstItems.add(new SelectItem(claves.getId().getValdato().trim(), claves.getInterp().trim()));
			}
		}
		return tipoctainstItems;
	}

	public void setTipoctainstItems(List<SelectItem> tipoctainstItems) {
		this.tipoctainstItems = tipoctainstItems;
	}

	public List<SelectItem> getInstitucionInterLista() {
		if (institucionInterLista == null) {
			log.info("recuperando items instituciones inter externas");
			institucionInterLista = new ArrayList<SelectItem>();

			Institucion institucionSearch = new Institucion();
			institucionSearch.setPais(new Pais());
			institucionSearch.setCveTipoInst("E");
			List<Institucion> institucionTLista = getServiceDao().getInstitucionLocal().findInstituciones(institucionSearch);
			for (Institucion institucion : institucionTLista) {
				institucionInterLista.add(new SelectItem(institucion.getCodInst(), institucion.getNomInst() + " - " + institucion.getNomPlaza()));
			}
		}

		return institucionInterLista;
	}

	public void setInstitucionInterLista(List<SelectItem> institucionInterLista) {
		this.institucionInterLista = institucionInterLista;
	}

	public List<SelectItem> getCuentasInterLista() {
		return cuentasInterLista;
	}

	private void recuperarCuentasInter() {
		SwfPersonactaPK swfPersonactaPK = new SwfPersonactaPK();
		swfPersonactaEdit = new SwfPersonacta();
		swfPersonactaEdit.setId(swfPersonactaPK);

		cuentasInterLista = new ArrayList<SelectItem>();

		log.info("En recuperarCuentasInter " + swfPersonactaSelected.getId().getPecCodinst() + " " + swfPersonactaSelected.getPecCodinstinter());

		if (!StringUtils.isBlank(swfPersonactaSelected.getPecTipoctainst())) {
			if (swfPersonactaSelected.getPecTipoctainst().equals("D")) {

			} else if (swfPersonactaSelected.getPecTipoctainst().equals("I")) {
				log.info("con intermediario");
				if (!StringUtils.isBlank(swfPersonactaSelected.getId().getPecCodinst())
						&& !StringUtils.isBlank(swfPersonactaSelected.getPecCodinstinter())) {

					List<SwfPersonacta> swfPersonactaList = getServiceDao().getSwfPersonactaLocal().buscarCtasPersona(
							swfPersonactaSelected.getId().getPecCodinst(), swfPersonactaSelected.getPecCodinstinter(), null, null, null, null, null);

					for (SwfPersonacta swfPersonacta : swfPersonactaList) {
						cuentasInterLista.add(new SelectItem(swfPersonacta.getId().getPecNrocta(), swfPersonacta.getId().getPecNrocta() + " : "
								+ swfPersonacta.getPecDescripcta()));
					}
				}

			}
		}

		log.info("XXX: recuperados " + cuentasInterLista.size());
	}

	public void setCuentasInterLista(List<SelectItem> cuentasInterLista) {
		this.cuentasInterLista = cuentasInterLista;
	}

	public SwfPersonacta getSwfPersonactaEdit() {
		return swfPersonactaEdit;
	}

	public void setSwfPersonactaEdit(SwfPersonacta swfPersonactaEdit) {
		this.swfPersonactaEdit = swfPersonactaEdit;
	}

	public List<SelectItem> getTiposMensajeSwiftItems() {
		if (tiposMensajeSwiftItems == null) {
			tiposMensajeSwiftItems = new ArrayList<SelectItem>();
			List<SwfMttransfer> swfMttransferLista = getServiceDao().getSwfMttransferLocal().getMTs();
			for (SwfMttransfer swfMttransfer : swfMttransferLista) {
				tiposMensajeSwiftItems.add(new SelectItem(swfMttransfer.getMttCodttransfer(), swfMttransfer.getMttCodttransfer() +": "+swfMttransfer.getMttDescrip() + " : " + swfMttransfer.getMttCodmt()));
			}
		}

		return tiposMensajeSwiftItems;
	}

	public void setTiposMensajeSwiftItems(List<SelectItem> tiposMensajeSwiftItems) {
		this.tiposMensajeSwiftItems = tiposMensajeSwiftItems;
	}

}
