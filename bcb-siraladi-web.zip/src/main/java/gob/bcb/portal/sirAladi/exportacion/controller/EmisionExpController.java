/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-sirAladi
 * gob.bcb.portal.sirAladi.exportacion.controller.EmisionExpController
 * 15/07/2011 - 15:30:12
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.exportacion.controller;

import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarMapInstrumentos;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarSelectItemsInstituciones;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarSelectItemsInstrumentos;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarSelectItemsPaises;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarSelectItemsPlazasInstituciones;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.getAlertJS;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarItemsPersonaBCB;
import static gob.bcb.portal.sirAladi.commons.Constantes.CODIGO_MONEDA_DOLARES;
import static gob.bcb.portal.sirAladi.commons.Constantes.CODIGO_PAIS_BOLIVIA;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTADO_PENDIENTE;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTILO_INVISIBLE;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTILO_VISIBLE;
import static gob.bcb.portal.sirAladi.commons.Constantes.SUCCESS;
import static gob.bcb.portal.sirAladi.commons.Constantes.TIPO_APERTURA_EXPORTACION;
import static gob.bcb.portal.sirAladi.commons.Constantes.TIPO_EMISION_EMISION;
import static gob.bcb.portal.sirAladi.commons.Constantes.TIPO_MOVIMIENTO_APERTURA;
import gob.bcb.bpm.siraladi.jpa.Adjunto;
import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.Identificador;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Instrumento;
import gob.bcb.bpm.siraladi.jpa.Pais;
import gob.bcb.bpm.siraladi.jpa.Persona;
import gob.bcb.bpm.siraladi.jpa.Registro;
import gob.bcb.bpm.siraladi.pojo.StatusResponse;
import gob.bcb.bpm.siraladi.utils.NumeroDAV;
import gob.bcb.portal.sirAladi.commons.Archivo;
import gob.bcb.portal.sirAladi.commons.Servicios;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.richfaces.event.UploadEvent;
import org.richfaces.model.UploadItem;

/**
 * Backing Bean de la vista de emisin de exportacin.
 * 
 * @author wherrera
 * 
 */
public class EmisionExpController extends BaseBeanController {
	private static Logger log = Logger.getLogger(EmisionExpController.class);
	private String msj;

	private Apertura apertura;
	private Registro registro;
	private Pais paisConvenio;
	private Persona persona;	
	private Adjunto adjunto;
	private Archivo archivo;

	private Map<String, Instrumento> mapInstrumentos;
	private List<SelectItem> itemsInstitucionesLocales;
	private List<SelectItem> itemsPaisesExterior;
	private List<SelectItem> itemsInstitucionesExterior;
	private List<SelectItem> itemsInstrumentos;

	private List<SelectItem> itemsPersonasBCB;	
	public EmisionExpController() {
	}

	@PostConstruct
	public void init() {
		log.info("Iniciando el modulo de emisiones para Exportacion.");
		recuperarVisit();
		this.crearObjetosPorDefecto();
		try {
			this.cargarCombos();
		} catch (Exception e) {
			this.msj = getAlertJS("Ocurrio un error al iniciar el modulo.");
			log.error("Ocurrio un error: " + e.getMessage(), e);
		}
	}

	public void registrarApertura(ActionEvent event) {
		this.msj = "";
		StatusResponse statusResponse = null;
		if (this.archivo == null)
			statusResponse = new StatusResponse("Debe adjuntar mensaje swift.");
		else {
			try {
				Integer.valueOf(this.apertura.getAnio());
				Integer.valueOf(this.apertura.getSecuencia());
				this.completarDatos();
				statusResponse = Servicios.guardarEmision(this.apertura, this.registro);
				if (SUCCESS.equalsIgnoreCase(statusResponse.getStatusCode())) {

					//apertura = getServiceDao().getAperturaLocal().findByNroMovCveEstado(this.apertura.getNroMov(), null); //findById(this.apertura.getNroMov(), false);
					this.apertura = getServiceDao().getAperturaLocal().findByCodReembolso(this.apertura.getInstitucion().getCodInst(),
							this.apertura.getIdentificador().getCodId(), this.apertura.getAnio(), this.apertura.getSecuencia(),
							this.apertura.getDav(),false);
					
					//apertura = getSirAladiDao().getApertura(apertura);
					registro = getSirAladiDao().getRegistroEmision(apertura.getNroMov());
					this.paisConvenio = this.apertura.getInstitucion().getPais();
					adjunto = getSirAladiDao().getAdjunto(apertura.getNroMov());
					this.cargarBancosPaisExterior(this.paisConvenio.getCodPais());
					try {
						this.archivo.guardarAdjunto(this.apertura.getNroMov(), TIPO_MOVIMIENTO_APERTURA);
						this.archivo = null;
						log.info(statusResponse.getDescrip());
					} catch (Exception e) {
						statusResponse = new StatusResponse("ADVERTENCIA: " + statusResponse.getDescrip()
								+ " PERO hubo un error al guardar el archivo adjunto " + e.getMessage());
						log.error(statusResponse.getDescrip(), e);
					}

				} else {
					log.info(statusResponse.getDescrip());
				}
			} catch (NumberFormatException e) {
				statusResponse = new StatusResponse("Todos los campos del c digo de reembolso deben ser num ricos.");
				log.error(statusResponse.getDescrip(), e);
			} catch (Exception e) {
				statusResponse = new StatusResponse("Error al guardar la emisi n." + e.getMessage());
				log.error(statusResponse.getDescrip(), e);
			}
		}
		this.msj = getAlertJS(statusResponse);
	}

	public void mostrarReporte(ActionEvent event) {
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("NRO_MOV", this.apertura.getNroMov());
		parametros.put("TITULO", "EMISION DE INSTRUMENTO");
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("pathTranslated", request.getPathTranslated());
		request.getSession().setAttribute("nombreReporte", "repApertura.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}

	public void adjuntar(UploadEvent event) throws IOException {
		this.msj = "";
		UploadItem item = event.getUploadItem();
		StatusResponse statusResponse = new StatusResponse("");
		this.archivo = new Archivo();
		this.archivo.setLength(item.getData().length);
		this.archivo.setNombreMimeExtension(item.getFileName(), this.apertura.getCodigoReembolsoCorrido());
		this.archivo.setData(item.getData());
		if (this.apertura != null && this.apertura.getNroMov() != null && this.apertura.getNroMov() > 0) {
			try {
				this.archivo.guardarAdjunto(this.apertura.getNroMov(), TIPO_MOVIMIENTO_APERTURA);
				this.archivo = null;
				adjunto = getSirAladiDao().getAdjunto(apertura.getNroMov());
				//statusResponse = new StatusResponse("Archivo adjunto actualizado exit samente");
			} catch (Exception e) {
				statusResponse = new StatusResponse("Hubo un error al modificar el archivo adjunto " + e.getMessage());
				log.error(statusResponse.getDescrip(), e);
			}
			this.msj = getAlertJS(statusResponse);
		}
	}

	public void mostrarAdjunto(ActionEvent event) {
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("nroMov", this.apertura.getNroMov());
		request.getSession().setAttribute("adjunto", this.archivo);
	}

	public List<SelectItem> getItemsInstitucionesLocales() {
		return itemsInstitucionesLocales;
	}

	public void setItemsInstitucionesLocales(List<SelectItem> itemsInstitucionesLocales) {
		this.itemsInstitucionesLocales = itemsInstitucionesLocales;
	}

	public List<SelectItem> getItemsPaisesExterior() {
		return itemsPaisesExterior;
	}

	public void setItemsPaisesExterior(List<SelectItem> itemsPaisesExterior) {
		this.itemsPaisesExterior = itemsPaisesExterior;
	}

	public List<SelectItem> getItemsInstitucionesExterior() {
		return itemsInstitucionesExterior;
	}

	public void setItemsInstitucionesExterior(List<SelectItem> itemsInstitucionesExterior) {
		this.itemsInstitucionesExterior = itemsInstitucionesExterior;
	}

	public List<SelectItem> getItemsInstrumentos() {
		return itemsInstrumentos;
	}

	public void setItemsInstrumentos(List<SelectItem> itemsInstrumentos) {
		this.itemsInstrumentos = itemsInstrumentos;
	}

	public Pais getPaisConvenio() {
		return paisConvenio;
	}

	public void setPaisConvenio(Pais paisConvenio) {
		this.paisConvenio = paisConvenio;
	}

	public boolean isRegistradoEnBD() {
		return (this.apertura != null && this.apertura.getNroMov() != null && this.apertura.getNroMov() > 0);
	}

	public String getEstiloImprimible() {
		return isRegistradoEnBD() ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	public String getEstiloSinAdjunto() {
		return (this.archivo == null) ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	public String getEstiloConAdjunto() {
		return (this.archivo != null) ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	public void seleccionarPais(ActionEvent event) {
		this.msj = "";
		String codPais = this.paisConvenio.getCodPais();
		this.cargarBancosPaisExterior(codPais);
	}

	private void cargarBancosPaisExterior(String codPais) {
		if (!StringUtils.isEmpty(codPais))
			this.itemsInstitucionesExterior = armarSelectItemsInstituciones(getSirAladiDao().getInstitucionesPorPais(codPais));
		else
			this.itemsInstitucionesExterior.clear();
	}

	public void generarDAV(ActionEvent event) {
		this.msj = "";
		if (StringUtils.isEmpty(this.apertura.getInstitucion().getCodInst()) || StringUtils.isEmpty(this.apertura.getIdentificador().getCodId())
				|| StringUtils.isEmpty(this.apertura.getAnio()) || StringUtils.isEmpty(this.apertura.getSecuencia())) {
			if (!StringUtils.isEmpty(this.apertura.getSecuencia()))
				this.apertura.setSecuencia(StringUtils.leftPad(this.apertura.getSecuencia(), 6, '0'));
			this.msj = getAlertJS("No se puede generar el DAV, ingrese los campos correctamente.");
		} else {
			this.calcularDAV();
		}
	}

	private void calcularDAV() {
		this.apertura.setSecuencia(StringUtils.leftPad(this.apertura.getSecuencia(), 6, '0'));
		this.apertura.setDav(NumeroDAV.generaDAV(this.apertura.getInstitucion().getCodInst(), this.apertura.getIdentificador().getCodId(),
				this.apertura.getAnio(), this.apertura.getSecuencia()));
	}

	public void seleccionarInstrumento(ActionEvent event) {
		this.msj = "";
		String codInstrumento = this.registro.getInstrumento().getCodInstrumento();
		if (!StringUtils.isEmpty(codInstrumento))
			this.apertura.getIdentificador().setCodId(this.mapInstrumentos.get(codInstrumento).getCodId());
	}

	private void completarDatos() {
		Date fecha = getSirAladiDao().getFechaActual();

		// Apertura
		this.apertura.setCveTipoApe(TIPO_APERTURA_EXPORTACION);
		this.apertura.setCodMoneda(CODIGO_MONEDA_DOLARES);
		this.apertura.setFechaCalc(fecha);
		this.calcularDAV();

		// Registro
		this.registro.setCveEstadoReg(ESTADO_PENDIENTE);  
		this.registro.setCveTipoEmis(TIPO_EMISION_EMISION);
		this.registro.setHaberMo(BigDecimal.ZERO);
		this.registro.setFechaTrans(fecha);
		this.registro.setEstacion(getVisit().getAddress());
		this.registro.setCodUsuario(getVisit().getUsuarioSirAladi().getLogin());
	}
	public void abrirPanelPersonaExp(ActionEvent event) {
		getVisit().setParametro("codPersonaExp", apertura.getCodPersona());
	}	
	public void seleccionarPersona(ActionEvent event) {
		this.msj = "";
		if (persona == null){
			apertura.setPersona(new Persona());
			return;
		}
		log.info("XXX: PersonaPersona noo nuulo " + persona.getCodPersona());		
		String codPersona = persona.getCodPersona();
		apertura.setCodPersona(codPersona);
		if (!StringUtils.isEmpty(codPersona))
			apertura.setPersona(persona);
		else
			apertura.setPersona(new Persona());
	
	}
	public void cancelarPersonaExp(ActionEvent event) {
		persona = (Persona) getVisit().getParametro("codPersonaExp");
		apertura.setPersona(persona);
		apertura.setCodPersona(persona.getCodPersona());
		getVisit().removeParametro("codPersonaExp");
	}	
	public void borrarAdjunto(ActionEvent event) {
		this.archivo = null;
	}

	private void crearObjetosPorDefecto() {
		this.msj = "";
		this.paisConvenio = new Pais();
		persona = new Persona();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(getSirAladiDao().getFechaActual());

		// Apertura
		this.apertura = new Apertura();
		this.apertura.setAnio(String.valueOf(calendar.get(Calendar.YEAR)));
		this.apertura.setFechaEmis(calendar.getTime());
		this.apertura.setIdentificador(new Identificador());
		this.apertura.setInstitucion(new Institucion());
		this.apertura.setPais(new Pais());
		this.apertura.getPais().setCodPais(CODIGO_PAIS_BOLIVIA);
		this.apertura.setPersona(new Persona());

		// Registro
		this.registro = new Registro();
		this.registro.setInstrumento(new Instrumento());
		this.registro.setInstitucion(new Institucion());
	}

	private void cargarCombos() {
		String[] codigosInstrumentos = { "CC", "CD", "LA", "OD", "OP", "PA" };
		List<Pais> listaPaisesExterior = getSirAladiDao().getPaisesExterior();
		List<Instrumento> listaInstrumentos = getSirAladiDao().getInstrumentos(Arrays.asList(codigosInstrumentos));
		List<Persona> listaPersona = getSirAladiDao().getEntidadesBCB();

		this.mapInstrumentos = armarMapInstrumentos(listaInstrumentos);
		this.itemsInstrumentos = armarSelectItemsInstrumentos(listaInstrumentos);
		this.itemsPaisesExterior = armarSelectItemsPaises(listaPaisesExterior);
		this.itemsInstitucionesLocales = armarSelectItemsPlazasInstituciones(getVisit().getUsuarioSirAladi().getPersona().getInstitucions());
		this.itemsInstitucionesExterior = new ArrayList<SelectItem>();
		this.itemsPersonasBCB = armarItemsPersonaBCB(listaPersona);
	}

	public Apertura getApertura() {
		return apertura;
	}

	public void setApertura(Apertura apertura) {
		this.apertura = apertura;
	}

	public Registro getRegistro() {
		return registro;
	}

	public void setRegistro(Registro registro) {
		this.registro = registro;
	}

	public String getMsj() {
		return msj;
	}

	public void setMsj(String msj) {
		this.msj = msj;
	}

	public void setArchivo(Archivo archivo) {
		this.archivo = archivo;
	}

	public Archivo getArchivo() {
		return archivo;
	}

	public void setAdjunto(Adjunto adjunto) {
		this.adjunto = adjunto;
	}

	public Adjunto getAdjunto() {
		return adjunto;
	}

	public void setItemsPersonasBCB(List<SelectItem> itemsPersonasBCB) {
		this.itemsPersonasBCB = itemsPersonasBCB;
	}

	public List<SelectItem> getItemsPersonasBCB() {
		return itemsPersonasBCB;
	}

	public void setPersona(Persona persona) {
		this.persona = persona;
	}

	public Persona getPersona() {
		return persona;
	}

}
