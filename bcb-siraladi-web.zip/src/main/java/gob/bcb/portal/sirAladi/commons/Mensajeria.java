/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-web-sirAladi
 * gob.bcb.portal.sirAladi.commons.Mensajeria
 * 12/10/2011 - 09:20:16
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.commons;

import static gob.bcb.portal.sirAladi.commons.Constantes.SUCCESS;
import gob.bcb.bpm.siraladi.pojo.StatusResponse;
import gob.bcb.core.jms.BcbResponse;
import gob.bcb.core.jms.client.JMSConnectionHandler;
import gob.bcb.siraladi.xml.Msgbcbresp;
import gob.bcb.siraladi.xml.Msgsistemaresp;

import javax.jms.BytesMessage;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TemporaryQueue;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;

/**
 * Clase que contiene m�todos para enviar mensajes JMS.
 * 
 * @author wherrera
 */
public class Mensajeria implements MessageListener {
	private Session session;
	private MessageProducer producer;
	private Message messageResponse;
	private StatusResponse statusResponse;

	private static Logger log = Logger.getLogger(Mensajeria.class);

	/**
	 * Constructor de la clase mensajeria.
	 */
	public Mensajeria() {

	}

	public void enviarMensaje(String message) {
		long t0 = System.currentTimeMillis();
		log.info("Mensaje a enviar: \n" + message);
		MessageConsumer replyConsumer = null;
		MessageProducer producer = null;
		JMSConnectionHandler jMSConnectionHandler = new JMSConnectionHandler();
		Session session = null;
		try {
			session = jMSConnectionHandler.getSession();
			Destination destination = null;
			try {
				destination = session.createQueue(Constantes.NOMBRE_QUEUE_SERVICIO);
			} catch (JMSException e) {
				log.error("Ocurrio un error en el proceso de envio/recepcion del mensaje se intentara reconectar." + e.getMessage(), e);
				try {
					jMSConnectionHandler = new JMSConnectionHandler();
					JMSConnectionHandler.reConnect();
					session = jMSConnectionHandler.getSession();					
					destination = session.createQueue(Constantes.NOMBRE_QUEUE_SERVICIO);
				} catch (JMSException e1) {
					log.error("Error al reconectar " + e1.getMessage(), e1);
					jMSConnectionHandler.close();
					throw new JMSException(e1.getMessage());					
				}
			}
	    
			TemporaryQueue confirmQueue = session.createTemporaryQueue();

			// Wait to see if the loan request was accepted or declined

			TextMessage textMessage = session.createTextMessage();
			textMessage.setText(message);
			textMessage.setJMSReplyTo(confirmQueue);
			//replyConsumer = session.createConsumer(confirmQueue);
			replyConsumer = jMSConnectionHandler.getConsumer(confirmQueue);
			log.info("Mensaje enviado. Esperando respuesta del servicio...");
			jMSConnectionHandler.send(destination, textMessage);
			producer = jMSConnectionHandler.getProducer();
			TextMessage textMessageRec = (TextMessage) replyConsumer.receive(60000);
			if (textMessageRec == null) {
				throw new JMSException("respuesta de mensaje nulo, el servicio posiblemente no esta activo o no pudo responder");
			}

			String textMsg = textMessageRec.getText();
			BcbResponse response = BcbResponse.Factory.createFromStringXML(textMsg);
			Msgbcbresp msgbcbresp = response.getMsgBcbresp();
			Msgsistemaresp msgSistemaResponse = msgbcbresp.getMsgsistemaresp();
			this.statusResponse = new StatusResponse(msgSistemaResponse);
			log.info("Respuesta recibida satisfactoriamente. (" + (System.currentTimeMillis() - t0) + " ms.)");
			log.info("\n>>> Mensaje Recibido:\n" + textMsg + "\n\n");
		} catch (JMSException e) {
			this.statusResponse = new StatusResponse("Ocurrio un error en el proceso de envio/recepcion del mensaje." + e.getMessage());
			log.error(this.statusResponse.getDescrip(), e);
		} finally {
			try {
				if (producer != null)
					producer.close();
				jMSConnectionHandler.closeConsumers();
				//if (replyConsumer != null)
					//replyConsumer.close();
				if (session != null)
					session.close();
			} catch (Exception e) {
				log.error("error al cerrar coneccion a JMS ", e);
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.jms.MessageListener#onMessage(javax.jms.Message)
	 */
	
	public void onMessage(Message arg) {
		try {
			if (arg instanceof TextMessage) {
				String textMessage = ((TextMessage) arg).getText();
				BcbResponse response = BcbResponse.Factory.createFromStringXML(textMessage);
				Msgbcbresp msgbcbresp = response.getMsgBcbresp();
				Msgsistemaresp msgSistemaResponse = msgbcbresp.getMsgsistemaresp();
				this.statusResponse = new StatusResponse(msgSistemaResponse);
				log.info("\n>>> Mensaje Recibido:\n" + textMessage + "\n\n");
			} else if (arg instanceof BytesMessage) {
				BytesMessage bytesMessage = (BytesMessage) arg;
				byte data[] = new byte[(int) bytesMessage.getBodyLength()];
				bytesMessage.readBytes(data);
				statusResponse = new StatusResponse("SUPEEER");
				statusResponse.setStatusCode(SUCCESS);
				log.info("\n>>> Mensaje Recibido bytes:\n" + bytesMessage.getBodyLength() + "\n\n");
				statusResponse.getContenido().put("OBJETOBYTES", data);
			}
		} catch (Exception e) {
			log.error("error en la recepcion de respuesta de mensaje a servicio " + e.getMessage(), e);
		}
		this.messageResponse = arg;
	}

	/**
	 * M�todo que retorna el statusResponse del request
	 * 
	 * @return
	 */
	public StatusResponse getStatusResponse() {
		return statusResponse;
	}

}
