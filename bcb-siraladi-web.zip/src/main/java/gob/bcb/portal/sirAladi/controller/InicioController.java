/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-web-sirAladi
 * gob.bcb.portal.sirAladi.controller.InicioController
 * 09/09/2011 - 13:42:27
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.controller;

import static gob.bcb.portal.sirAladi.commons.Constantes.ESTILO_INVISIBLE;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTILO_VISIBLE;
import static gob.bcb.portal.sirAladi.commons.Constantes.TIPO_APERTURA_IMPORTACION;
import gob.bcb.bpm.siraladi.jpa.Persona;
import gob.bcb.portal.sirAladi.dao.DaoFactory;

import javax.faces.event.ActionEvent;

import org.apache.log4j.Logger;

/** 
 * BackBean de la pagina inicial del Sir Aladi.
 *
 * @author wherrera
 *
 */
public class InicioController
{
	private int nroPendientes;

	private static Logger log = Logger.getLogger(InicioController.class);
	

	public InicioController()
	{		
		log.info("Cargando Pagina Inicial Sir Aladi.");
		Persona entidad = MainAladiController.getDatosDelUsuario().getPersona();
	  this.nroPendientes = DaoFactory.getInstance().getSirAladiDao().getNroPagosPendientesImportacion(entidad);
	}
	
	
	public String getMensaje()
	{
		String mensaje = null;
		if (this.nroPendientes > 0)		
			mensaje = "Pagos por operaciones de importaci�n pendientes. (" + this.nroPendientes + ")";
		return mensaje;
	}
	
	 
	public String getEstiloMensaje()
	{
		return this.nroPendientes > 0 ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}
	
	
	public void irDetallePago(ActionEvent event)
	{		
		MainAladiController.irA("/Modulos/Comunes/pagosCobros.xhtml", TIPO_APERTURA_IMPORTACION, null);
	}
	

}
