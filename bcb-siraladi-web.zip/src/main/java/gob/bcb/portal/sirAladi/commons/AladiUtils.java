/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-sirAladi
 * gob.bcb.portal.sirAladi.commons.AladiUtils
 * 26/07/2011 - 17:04:13
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.commons;

import gob.bcb.bpm.siraladi.jpa.ClasifProductos;
import gob.bcb.bpm.siraladi.jpa.Claves;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Instrumento;
import gob.bcb.bpm.siraladi.jpa.Pais;
import gob.bcb.bpm.siraladi.jpa.Persona;
import gob.bcb.bpm.siraladi.pojo.StatusResponse;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.model.SelectItem;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.log4j.Logger;

/**
 * Clase que contiene mtodos utilitarios usados en la capa web del sir aladi.
 * 
 */
public class AladiUtils {
	private static Logger log = Logger.getLogger(AladiUtils.class);
	/**
	 * Mtodo que pone cdigo javascript en un bloque javascript.
	 * 
	 * @param contenido
	 *            cdigo javascript
	 * @return bloque javascript con contenido
	 */
	public static String getContenidoJS(String contenido) {
		if (contenido != null && !contenido.trim().isEmpty()){
			StringBuilder sb = new StringBuilder("<script language=\"javascript\">");
			sb.append(contenido);
			sb.append("</script>");
			return sb.toString();
		}
		return null;
	}

	/**
	 * Mtodo que arma un bloque javascript para desplegar alert(s) a partir de
	 * uno o varios objetos StatusResponse.
	 * 
	 * @param statusResponses
	 *            objeto StatusResponse
	 * @return bloque javascript con los alerts correspondientes
	 */
	public static String getAlertJS(StatusResponse... statusResponses) {
		return getContenidoJS(getMensajesConfirmacion(statusResponses));
	}

	/**
	 * Mtodo que arma un bloque javascript para desplegar un alert.
	 * 
	 * @param mensaje
	 *            texto, contenido del mensaje alert
	 * @return bloque javascript con alert correspondiente
	 */
	public static String getAlertJS(String mensaje) {
		StatusResponse response = new StatusResponse(mensaje);
		return getAlertJS(response);
	}

	/**
	 * Mtodo que arma un bloque javascript para desplegar un alert y cerrar una
	 * ventana modal.
	 * 
	 * @param idModalPanel
	 *            id de la ventana modal
	 * @param statusResponses
	 *            objeto StatusResponse
	 * @return bloque javascript con cdigo correspondiente
	 */
	public static String getAlertConCierreModalJS(String idModalPanel, StatusResponse... statusResponses) {
		return getContenidoJS(getMensajesConfirmacion(statusResponses) + getCerrarModalPanel(idModalPanel));
	}

	/**
	 * Mtodo que arma un bloque javascript para cerrar una ventana modal y
	 * desplegar un alert.
	 * 
	 * @param idModalPanel
	 *            id de la ventana modal
	 * @param statusResponses
	 *            objeto StatusResponse
	 * @return bloque javascript con cdigo correspondiente
	 */
	public static String getCierreModalConAlertJS(String idModalPanel, StatusResponse... statusResponses) {
		return getContenidoJS(getCerrarModalPanel(idModalPanel) + getMensajesConfirmacion(statusResponses));
	}

	/**
	 * Mtodo que retorna cdigo javascript para cerrar una ventana modal.
	 * 
	 * @param idModalPanel
	 *            id de la ventana modal
	 * @return bloque javascript con cdigo correspondiente
	 */
	private static String getCerrarModalPanel(String idModalPanel) {
		return "Richfaces.hideModalPanel('" + idModalPanel + "');";
	}

	/**
	 * Mtodo que arma un bloque javascript con cdigo para cerrar una ventana
	 * modal.
	 * 
	 * @param idModalPanel
	 *            id de la ventana modal
	 * @return bloque javascript con cdigo correspondiente
	 */
	public static String getCierreModalPanelJS(String idModalPanel) {
		return getContenidoJS(getCerrarModalPanel(idModalPanel));
	}

	/**
	 * Mtodo que arma una cadena que contiene mensajes de confirmacin, apartir
	 * de uno o ms objetos StatusResponse.
	 * 
	 * @param statusResponses
	 *            objeto StatusResponse
	 * @return cadena texto de mensaje de confirmacin.
	 */
	private static String getMensajesConfirmacion(StatusResponse... statusResponses) {
		if (statusResponses == null || statusResponses.length == 0){
			return null;
		}
		
		StringBuilder sb = new StringBuilder();
		for (StatusResponse statusResponse : statusResponses) {
			
			if (statusResponse == null || statusResponse.getDescrip()== null || statusResponse.getDescrip().trim().isEmpty()){
				continue;
			}
			String mensajePrincipal = statusResponse.getDescrip().replace((char) 10, ' ').replace((char) 13, ' ');
			Map<String, String> observaciones = statusResponse.getDescripTasksAdic();
			sb = new StringBuilder("alert(\"");
			if (observaciones != null && observaciones.size() > 0) {
				sb.append("1. " + mensajePrincipal);
				sb.append("\\n\\n2. Información Adicional:");
				Object[] keys = observaciones.keySet().toArray();
				for (Object key : keys)
					sb.append("\\n      - ").append(key).append(": ").append(observaciones.get(key));
			} else
				sb.append(mensajePrincipal);
			sb.append("\");");
		}
		log.info(sb.toString());
		return sb.toString();
	}

	/**
	 * Mtodo que obtiene la diferencia de dias entre dos fechas.
	 * 
	 * @param fechaInicio
	 *            fecha inicial
	 * @param fechaFin
	 *            fecha final
	 * @return Nmero de dias
	 */
	public static int getDiferenciasDias(Date fechaInicio, Date fechaFin) {
		final long MSEG_X_DIA = 1000 * 60 * 60 * 24;
		long diferencia = (fechaFin.getTime() - fechaInicio.getTime()) / MSEG_X_DIA;
		return (int) diferencia;
	}

	/**
	 * Mtodo que obtiene un String con formato fecha a partir de un objeto
	 * Date.
	 * 
	 * @param fecha
	 * @param formato
	 * @return
	 */
	public static String dateToString(Date fecha, String formato) {
		DateFormat df = new SimpleDateFormat(formato);
		return df.format(fecha);
	}

	/**
	 * Mtodo que obtiene un objeto Date a partir de un String con formato
	 * fecha.
	 * 
	 * @param strFecha
	 * @param formato
	 * @return
	 */
	public static Date stringToDate(String strFecha, String formato) {
		Date date = null;
		DateFormat df = new SimpleDateFormat(formato);
		try {
			date = df.parse(strFecha);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}

	/**
	 * Mtodo que obtiene un String con la fecha en literal apartir de un objeto
	 * Date.
	 * 
	 * @return String de hora.
	 */
	public static String dateToFechaLiteral(Date fecha) {
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.FULL, new Locale("ES", "BO"));
		String literal = dateFormat.format(fecha);
		String fechaLiteral = literal.substring(0, literal.indexOf(':', 0) - 3);
		return fechaLiteral;
	}

	/**
	 * Mtodo que convierte un tipo de dato Date a XMLGregorialCalendar
	 * 
	 * @param fecha
	 *            objeto Date
	 * @return objeto XMLGregorianCalendar
	 */
	public static XMLGregorianCalendar dateToXMLGregorianCalendar(Date fecha) {
		XMLGregorianCalendar xmlGregorianCalendar = null;
		try {
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(fecha);
			xmlGregorianCalendar = DatatypeFactory.newInstance().newXMLGregorianCalendar();
			xmlGregorianCalendar.setYear(calendar.get(Calendar.YEAR));
			xmlGregorianCalendar.setMonth(calendar.get(Calendar.MONTH) + 1);
			xmlGregorianCalendar.setDay(calendar.get(Calendar.DAY_OF_MONTH));
		} catch (DatatypeConfigurationException e) {
			log.error(e.getMessage(), e);
		}
		return xmlGregorianCalendar;
	}

	/**
	 * Mtodo que convierte un tipo de dato XMLGregorialCalendar a Date,
	 * 
	 * @param fecha
	 *            objeto XMLGregorianCalendar
	 * @return objeto Date
	 */
	public static Date xmlGregorianCalendarToDate(XMLGregorianCalendar fecha) {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.YEAR, fecha.getYear());
		calendar.set(Calendar.MONTH, fecha.getMonth() - 1);
		calendar.set(Calendar.DAY_OF_MONTH, fecha.getDay());
		return calendar.getTime();
	}

	/**
	 * Mtodo que retorna el primer dia del cuatrimestre dada una fecha.
	 * 
	 * @param fecha
	 *            fecha de referencia.
	 * @return fecha de inicio del cuatrimestre
	 */
	public static Date getInicioCuatrimestre(Date fecha) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(fecha);
		int mes = calendar.get(Calendar.MONTH);
		if (mes >= Calendar.JANUARY && mes <= Calendar.APRIL)
			mes = Calendar.JANUARY;
		else if (mes >= Calendar.MAY && mes <= Calendar.AUGUST)
			mes = Calendar.MAY;
		else if (mes >= Calendar.SEPTEMBER && mes <= Calendar.DECEMBER)
			mes = Calendar.SEPTEMBER;
		calendar.set(Calendar.DAY_OF_MONTH, 1);
		calendar.set(Calendar.MONTH, mes);
		return calendar.getTime();
	}

	public static Map<String, String> armarMapDescripcionClaves(List<Claves> listaClaves) {
		Map<String, String> map = new HashMap<String, String>();
		for (Claves clave : listaClaves)
			map.put(clave.getId().getValdato().trim(), clave.getInterp().trim());
		return map;
	}

	public static List<SelectItem> armarSelectDescripcionClaves(List<Claves> listaClaves) {
		List<SelectItem> list = new ArrayList<SelectItem>();
		for (Claves clave : listaClaves)
			list.add(new SelectItem(clave.getId().getValdato().trim(), clave.getInterp().trim()));
		return list;
	}

	public static List<SelectItem> armarSelectItemsPaises(List<Pais> listaPaises) {
		List<SelectItem> list = new ArrayList<SelectItem>();
		for (Pais pais : listaPaises)
			list.add(new SelectItem(pais.getCodPais().trim(), pais.getNomPais()));
		return list;
	}

	public static Map<String, Instrumento> armarMapInstrumentos(List<Instrumento> listaInstrumentos) {
		Map<String, Instrumento> map = new HashMap<String, Instrumento>();
		for (Instrumento instrumento : listaInstrumentos)
			map.put(instrumento.getCodInstrumento().trim(), instrumento);
		return map;
	}

	public static List<SelectItem> armarSelectItemsInstrumentos(List<Instrumento> listaInstrumentos) {
		List<SelectItem> list = new ArrayList<SelectItem>();
		for (Instrumento instrumento : listaInstrumentos)
			list.add(new SelectItem(instrumento.getCodInstrumento().trim(), instrumento.getNomInstrumento()));
		return list;
	}

	public static List<SelectItem> armarSelectItemsInstituciones(List<Institucion> listaInstituciones) {
		List<SelectItem> list = new ArrayList<SelectItem>();
		for (Institucion i : listaInstituciones)
			list.add(new SelectItem(i.getCodInst().trim(), i.getCodInst() + " - " + i.getNomInst().trim() + " - " + i.getNomPlaza().trim()));
		return list;
	}

	public static List<SelectItem> armarSelectItemsPlazasInstituciones(List<Institucion> listaInstituciones) {
		List<SelectItem> list = new ArrayList<SelectItem>();
		for (Institucion i : listaInstituciones)
			list.add(new SelectItem(i.getCodInst().trim(), i.getNomPlaza().trim()));
		return list;
	}

	public static List<SelectItem> armarItemsPlazasInstituciones(List<Institucion> listaInstituciones) {
		List<SelectItem> list = new ArrayList<SelectItem>();
		for (Institucion i : listaInstituciones)
			list.add(new SelectItem(i.getCodInst().trim(), i.getNomPlaza().trim()));
		return list;
	}
	public static List<SelectItem> armarItemsClasifProductos(List<ClasifProductos> listaObjetos) {
		List<SelectItem> list = new ArrayList<SelectItem>();
		for (ClasifProductos i : listaObjetos)
			list.add(new SelectItem(i.getCodClasifprod(), i.getDescrip().trim()));
		return list;
	}
	
	public static List<SelectItem> armarItemsPersonaBCB(List<Persona> lista) {
		List<SelectItem> list = new ArrayList<SelectItem>();
		for (Persona i : lista)
			list.add(new SelectItem(i.getCodPersona().trim(), i.getNomPersona().trim()));
		return list;
	}	
}
