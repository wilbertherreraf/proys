package gob.bcb.portal.sirAladi.controller;

import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Persona;
import gob.bcb.bpm.siraladi.jpa.Usuario;
import gob.bcb.bpm.siraladi.pojo.StatusResponse;
import gob.bcb.bpm.siraladi.pojo.UsuarioSirAladi;
import gob.bcb.bpm.siraladi.service.ServiceDao;
import gob.bcb.portal.sirAladi.commons.Constantes;
import gob.bcb.portal.sirAladi.dao.SirAladiDao;
import gob.bcb.portiaswift.service.ServiceSwiftDao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

public abstract class BaseBeanController {
	private static Logger log = Logger.getLogger(BaseBeanController.class);
	private Visit visit;
	private SirAladiDao sirAladiDao;
	private Map<String, Boolean> autorizado;
	private ServiceDao serviceDao;
	private ServiceSwiftDao serviceSwiftDao;
	private String codeOtp;
	
	public BaseBeanController() {
	}

	public FacesContext getFacesContext() {
		return FacesContext.getCurrentInstance();
	}

	public javax.faces.application.Application getApplication() {
		return getFacesContext().getApplication();
	}

	public Visit getVisit() {
		return visit;
	}

	public void setVisit(Visit visit) {
		this.sirAladiDao = visit.getMainAladiController().getSirAladiDao();
		this.visit = visit;
	}

	public void setSirAladiDao(SirAladiDao sirAladiDao) {
		this.sirAladiDao = sirAladiDao;
	}

	public SirAladiDao getSirAladiDao() {
		return sirAladiDao;
	}

	public boolean isAuthorized(String codRecurso) {
		return getVisit().getUsuarioSirAladi().getRecursos().contains(codRecurso);
	}

	public void recuperarVisit() {
		log.info("==== INGRESANDO A " + this.getClass().getName());
		HttpSession session = (HttpSession) getFacesContext().getExternalContext().getSession(false);
		Visit visit = (Visit) session.getAttribute(Constantes.SESSION_KEY_USER);
		setVisit(visit);

		if (visit != null && visit.getUsuarioSirAladi() != null) {
			autorizado = visit.getUsuarioSirAladi().getRecAutorizadosMapa();
		}
		Map<String, String> sesiones = getFacesContext().getExternalContext().getRequestParameterMap();
		visit.getParametro().putAll(sesiones);

		ServletContext servletContext = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		WebApplicationContext wac = WebApplicationContextUtils.getRequiredWebApplicationContext(servletContext);

		serviceDao = (ServiceDao) wac.getBean("serviceDao");
		serviceSwiftDao = (ServiceSwiftDao) wac.getBean("serviceSwiftDao");
		
		Persona persona = new Persona();
		
		persona.setCodPersona(visit.getUsuarioSirAladi().getPersona().getCodPersona());
		persona.setNomPersona(visit.getUsuarioSirAladi().getPersona().getNomPersona());
		persona.setEstacion(visit.getAddress());
		
		List<Institucion> institucionLista = new ArrayList<Institucion>();
		persona.setInstitucions(institucionLista);
		
		UsuarioSirAladi usuarioSirAladi = new UsuarioSirAladi(visit.getUsuarioSirAladi().getLogin());

		usuarioSirAladi.setRecursos(visit.getUsuarioSirAladi().getRecursos());
		usuarioSirAladi.setRoles(visit.getUsuarioSirAladi().getRoles());
		usuarioSirAladi.setPersona(persona);

		Usuario usuario = serviceDao.getUsuarioLocal().findByCodigo(visit.getUsuarioSirAladi().getLogin());
		
		if (usuario == null){
			usuario = new Usuario();
			usuario.setCodUsuario(visit.getUsuarioSirAladi().getLogin());
			usuario.setNomUsuario(visit.getUsuarioSirAladi().getLogin());
			if (visit.getUsuarioSirAladi().getRoles() != null)
				usuario.setPerfil(visit.getUsuarioSirAladi().getRoles().toString());
			usuario.setCveVigente("V");
			usuario.setCodUsuarioHa(visit.getUsuarioSirAladi().getLogin());
			usuario.setEstacion(visit.getAddress());
			usuario.setFechaHora(new Date());
			
			serviceDao.getUsuarioLocal().saveorupdate(usuario);
			
			log.info("Usuario aladi nuevo " + usuario.getCodUsuario());
		}
		serviceDao.setUsuarioAudit(usuarioSirAladi);
		log.info("Visit recuperado con " + visit.getUsuarioSirAladi().getLogin() + " IP " + visit.getAddress() + " Paersona: "
				+ visit.getUsuarioSirAladi().getPersona().getCodPersona() + " ");
	}

	public Map<String, Boolean> getAutorizado() {
		return autorizado;
	}

	public void setAutorizado(Map<String, Boolean> autorizado) {
		this.autorizado = autorizado;
	}

	public ServiceDao getServiceDao() {
		return serviceDao;
	}

	public ServiceSwiftDao getServiceSwiftDao() {
		return serviceSwiftDao;
	}

	public void irAPagina(String pagina) {
		log.info("Ir a pagina "  + pagina);
		MainAladiController mainAladiController = visit.getMainAladiController();
		mainAladiController.removerSesiones();
		mainAladiController.setPagina(pagina);
	}

	public void addMessageInfo(String summary, String detail) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, summary, detail);
		getFacesContext().addMessage(null, message);
	}

	public void addMessageError(String summary, String detail) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, summary, detail);
		getFacesContext().addMessage(null, message);
	}

	public String getMensajesConfirmacion(StatusResponse... statusResponses) {
		if (statusResponses == null || statusResponses.length == 0) {
			return null;
		}

		StringBuilder sb = new StringBuilder();
		for (StatusResponse statusResponse : statusResponses) {

			if (statusResponse == null || statusResponse.getDescrip() == null || statusResponse.getDescrip().trim().isEmpty()) {
				continue;
			}
			String mensajePrincipal = statusResponse.getDescrip().replace((char) 10, ' ').replace((char) 13, ' ');
			Map<String, String> observaciones = statusResponse.getDescripTasksAdic();
			// sb = new StringBuilder("alert(\"");
			if (observaciones != null && observaciones.size() > 0) {
				sb.append("1. " + mensajePrincipal);
				sb.append("\\n\\n2. Informacion Adicional:");
				Object[] keys = observaciones.keySet().toArray();
				for (Object key : keys)
					sb.append("\\n      - ").append(key).append(": ").append(observaciones.get(key));
			} else
				sb.append(mensajePrincipal);
			// sb.append("\");");
		}
		log.info(sb.toString());
		return sb.toString();
	}

	public void abrirModalOTP() {
		log.info("Llamando abrirModalOTP");
		codeOtp = "";
	}
	
	public String getCodeOtp() {
		return codeOtp;
	}

	public void setCodeOtp(String codeOtp) {
		this.codeOtp = codeOtp;
	}	
}
