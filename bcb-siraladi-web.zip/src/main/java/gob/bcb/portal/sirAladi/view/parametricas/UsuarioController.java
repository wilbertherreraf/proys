package gob.bcb.portal.sirAladi.view.parametricas;

import gob.bcb.bpm.siraladi.jpa.Usuario;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;

public class UsuarioController extends BaseBeanController {
	private static Logger log = Logger.getLogger(UsuarioController.class);
	private Usuario usuarioSelected = new Usuario();
	private List<Usuario> usuarioLista = new ArrayList<Usuario>();

	@PostConstruct
	public void init() {
		log.info("Iniciando el modulo de adm swift");
		recuperarVisit();

		recuperarDatos();
	}

	private void recuperarDatos() {
		usuarioLista = getServiceDao().getUsuarioLocal().findByEstado(null);
		usuarioSelected = new Usuario();
	}

	public void botonSelectItemNuevo() {
		log.info("botonSelectItemNuevo ");
		usuarioSelected = new Usuario();
		usuarioSelected.setCveVigente("V");
	}

	public void botonSelectItemEdit(Usuario usuarioSel) {
		log.info("botonSelectItemEdit " + usuarioSel.getCodUsuario());
		usuarioSelected = getServiceDao().getUsuarioLocal().findByCodigo(usuarioSel.getCodUsuario());
	}

	public void guardarRegistro() {
		try {
			log.info("Salvando registro " + usuarioSelected.getCodUsuario());
			usuarioSelected.setEstacion(getVisit().getAddress());
			usuarioSelected.setCodUsuarioHa(getVisit().getUsuarioSirAladi().getLogin());
			usuarioSelected = getServiceDao().getUsuarioLocal().saveorupdate(usuarioSelected);
			log.info("Registro actualizado " + usuarioSelected.getCodUsuario());
			addMessageInfo("Aviso", "Registro actualizado " + usuarioSelected.getCodUsuario());
		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
		recuperarDatos();
	}

	public Usuario getUsuarioSelected() {
		return usuarioSelected;
	}

	public void setUsuarioSelected(Usuario usuarioSelected) {
		this.usuarioSelected = usuarioSelected;
	}

	public List<Usuario> getUsuarioLista() {
		return usuarioLista;
	}

	public void setUsuarioLista(List<Usuario> usuarioLista) {
		this.usuarioLista = usuarioLista;
	}
}
