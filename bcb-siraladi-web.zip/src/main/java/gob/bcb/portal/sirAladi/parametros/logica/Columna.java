/**
 * Banco Central De Bolivia 
 * La Paz - Bolivia 
 * bcb-portal-portletBase
 * gob.bcb.portal.sirAladi.parametros.logica.Columna 
 * 08/06/2011 - 15:34:19 
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.parametros.logica;

import java.io.Serializable;
import java.util.List;

import javax.faces.component.UISelectItem;

/**
 * Clase que representa datos generales de una columna de una tabla parametrica.
 * 
 * @author wherrera
 * 
 */
public class Columna implements Serializable
{
	private String nombreColumna;
	private String descripcionColumna;
	private String tipoDato;
	private String maxLength;
	private boolean visible;
	private boolean editable;
	private boolean requerido;
	private boolean log;
	private String orderBy;
	private String joinTabla;
	private String joinCodigo;
	private String joinDescripcion;
	private Object valor;
	private Object valorOriginal;
	private List<UISelectItem> listaValores;
	
	public Columna(String rowId)
	{
		this.visible  = false;
		this.editable = false;
		this.valor = rowId;
	}

	public Columna(Object nombreColumna, Object descripcionColumna,
			Object tipoDato, Object maxLength, Object visible, Object editable,
			Object requerido, Object log, Object orderBy, Object joinTabla, 
			Object joinCodigo,Object joinDescripcion)
	{
		this.nombreColumna = ((String) nombreColumna).trim();
		this.descripcionColumna = ((String) descripcionColumna).trim();
		this.tipoDato = ((String) tipoDato).trim();
		this.maxLength = ((String) maxLength).trim();
		String strVisible = ((String) visible).trim();
		String strEditable = ((String) editable).trim();
		String strRequerido = ((String) requerido).trim();
		String strLog = ((String) log).trim();
		this.visible = strVisible.equalsIgnoreCase("SI");
		this.editable = strEditable.equalsIgnoreCase("SI");
		this.requerido = strRequerido.equalsIgnoreCase("SI");
		this.log = strLog.equalsIgnoreCase("SI");
		if (orderBy != null)
		{			
			this.orderBy = ((String) orderBy).trim();
			this.orderBy = this.orderBy.length() > 0 ? this.orderBy : null;
		}
		if (joinTabla != null)
		{			
			this.joinTabla = ((String) joinTabla).trim();
			this.joinTabla = this.joinTabla.length() > 0 ? this.joinTabla : null;
		}
		if (joinCodigo != null)
		{			
			this.joinCodigo = ((String) joinCodigo).trim();
			this.joinCodigo = this.joinCodigo.length() > 0 ? this.joinCodigo : null;
		}
		if (joinDescripcion != null)
		{			
			this.joinDescripcion = ((String) joinDescripcion).trim();
			this.joinDescripcion = this.joinDescripcion.length() > 0 ? this.joinDescripcion : null;
		}
	}

	public String getNombreColumna()
	{
		return nombreColumna;
	}
	public String getDescripcionColumna()
	{
		return descripcionColumna;
	}
	public String getMaxLength()
	{
		return maxLength;
	}
	public String getTipoDato()
	{
		return tipoDato;
	}
	public boolean isVisible()
	{
		return visible;
	}
	public boolean isEditable()
	{
		return editable;
	}
	public void setEditable(boolean editable)
	{
		this.editable = editable;
	}
	public boolean isRequerido()
	{
		return requerido;
	}
	public boolean isLog()
	{
		return log;
	}
	public String getOrderBy()
	{		
		return orderBy;
	}	
	public String getJoinTabla()
	{
		return joinTabla;
	}
	public String getJoinCodigo()
	{
		return joinCodigo;
	}
	public String getJoinDescripcion()
	{
		return joinDescripcion;
	}
	public Object getValor()
	{
		return valor;
	}	
	public void setValor(Object valor)
	{
		this.valor = valor;
	}
	public Object getValorOriginal()
	{
		return valorOriginal;
	}	
	public void setValorOriginal(Object valorOriginal)
	{
		this.valorOriginal = valorOriginal;
	}	
	public List<UISelectItem> getListaValores()
	{
		return listaValores;
	}	
	public void setListaValores(List<UISelectItem> listaValores)
	{
		this.listaValores = listaValores;
	}

	/**	  
	 * Metodo que verifica si el objeto tubo algun cambio, verifica los campos
	 * valor y valor original.
	 *
	 * @return
	 */
	public boolean tieneCambio() {
		boolean tieneCambio = false; 
		if(this.tipoDato.startsWith("FECHA"))
			tieneCambio = !this.valor.equals(this.valorOriginal);
		else
		{
			String strValorActual = "";
			String strValorOriginal = "";
			if(this.valor != null)
				strValorActual =this.valor.toString().trim();
			if(this.valorOriginal != null)
				strValorOriginal =this.valorOriginal.toString().trim();
			tieneCambio = !strValorActual.equals(strValorOriginal);
		}
		return tieneCambio;
	}

}
