/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-sirAladi
 * gob.bcb.portal.sirAladi.comunes.controller.EnmiendasController
 * 26/07/2011 - 14:49:03
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.comunes.controller;

import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarMapDescripcionClaves;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.armarSelectItemsInstituciones;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.getAlertConCierreModalJS;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.getAlertJS;
import static gob.bcb.portal.sirAladi.commons.AladiUtils.getCierreModalPanelJS;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_ESTADO_APERTURA;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_ESTADO_REGISTRO;
import static gob.bcb.portal.sirAladi.commons.Constantes.CVE_TIPO_EMISION;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTADO_CONTABILIZADO;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTADO_PENDIENTE;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTADO_VIGENTE;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTILO_INVISIBLE;
import static gob.bcb.portal.sirAladi.commons.Constantes.ESTILO_VISIBLE;
import static gob.bcb.portal.sirAladi.commons.Constantes.SUCCESS;
import static gob.bcb.portal.sirAladi.commons.Constantes.TIPO_APERTURA_IMPORTACION;
import static gob.bcb.portal.sirAladi.commons.Constantes.TIPO_EMISION_DECREMENTO;
import static gob.bcb.portal.sirAladi.commons.Constantes.TIPO_EMISION_INCREMENTO;
import gob.bcb.bpm.siraladi.jpa.Apertura;
import gob.bcb.bpm.siraladi.jpa.Identificador;
import gob.bcb.bpm.siraladi.jpa.Institucion;
import gob.bcb.bpm.siraladi.jpa.Pais;
import gob.bcb.bpm.siraladi.jpa.Registro;
import gob.bcb.bpm.siraladi.pojo.StatusResponse;
import gob.bcb.bpm.siraladi.pojo.UsuarioSirAladi;
import gob.bcb.portal.sirAladi.commons.Servicios;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;
import gob.bcb.portal.sirAladi.controller.MainAladiController;
import gob.bcb.portal.sirAladi.dao.DaoFactory;
import gob.bcb.portal.sirAladi.dao.SirAladiDao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

/**
 * Backing Bean para la vista de Enmiendas.
 * 
 * @author wherrera
 * 
 */
public class EnmiendasController extends BaseBeanController {
	private String msj;
	private String filtro;
	private String tipoApertura;
	private boolean desabilitado;
	private boolean mostrarModal;

	private Apertura apertura;
	private Apertura aperturaInicial;
	private Registro registro;
	private UsuarioSirAladi usuario;

	private SirAladiDao sirAladiDao;
	private List<Apertura> aperturas;
	private List<Apertura> aperturasInicial;
	private List<Registro> registros;
	private List<SelectItem> itemsInstituciones;
	private Map<String, String> mapClavesTipoEmision;
	private Map<String, String> mapClavesEstadoRegistro;
	private Map<String, String> mapClavesEstadoApertura;
	
	private static Logger log = Logger.getLogger(EnmiendasController.class);

	public EnmiendasController() {
	}

	@PostConstruct
	public void init() {
		log.info("Iniciando el modulo de enmiendas.");
		recuperarVisit();
		this.sirAladiDao = DaoFactory.getInstance().getSirAladiDao();
		this.usuario = MainAladiController.getDatosDelUsuario();
		this.tipoApertura = MainAladiController.getTipoOperacionPaginaActual();
		this.crearObjetosPorDefecto();
		Integer nroMov = MainAladiController.getParametroNroMov();
		if (nroMov == null || nroMov == 0)
			this.consultarAperturas();
		if ((nroMov != null && nroMov > 0) || this.aperturas == null || this.aperturas.size() == 0) {
			if (nroMov != null && nroMov > 0) {
				this.apertura = this.sirAladiDao.getApertura(nroMov);
				this.recuperarRegistros();
			}
			this.mostrarModal = false;
		}

	}

	public String getMsj() {
		return msj;
	}

	public void setMsj(String msj) {
		this.msj = msj;
	}

	public String getFiltro() {
		return filtro;
	}

	public void setFiltro(String filtro) {
		this.filtro = filtro;
	}

	public boolean isMostrarModal() {
		return mostrarModal;
	}

	public boolean isDesabilitado() {
		return desabilitado;
	}

	public void setDesabilitado(boolean desabilitado) {
		this.desabilitado = desabilitado;
	}

	public Apertura getApertura() {
		return apertura;
	}

	public void setApertura(Apertura apertura) {
		this.apertura = apertura;
	}

	public Registro getRegistro() {
		return registro;
	}

	public Map<String, String> getMapClavesTipoEmision() {
		return mapClavesTipoEmision;
	}

	public void setMapClavesTipoEmision(Map<String, String> mapClavesTipoEmision) {
		this.mapClavesTipoEmision = mapClavesTipoEmision;
	}

	public Map<String, String> getMapClavesEstadoRegistro() {
		return mapClavesEstadoRegistro;
	}

	public void setMapClavesEstadoRegistro(Map<String, String> mapClavesEstadoRegistro) {
		this.mapClavesEstadoRegistro = mapClavesEstadoRegistro;
	}

	public void setRegistro(Registro registro) {
		this.registro = registro;
	}

	public List<Apertura> getAperturas() {
		return aperturas;
	}

	public void setAperturas(List<Apertura> aperturas) {
		this.aperturas = aperturas;
	}

	public List<Registro> getRegistros() {
		return registros;
	}

	public void setRegistros(List<Registro> registros) {
		this.registros = registros;
	}

	public List<SelectItem> getItemsInstituciones() {
		return itemsInstituciones;
	}

	public void setItemsInstituciones(List<SelectItem> itemsInstituciones) {
		this.itemsInstituciones = itemsInstituciones;
	}

	public String getEstiloBuscar() {
		return this.desabilitado ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	public String getEstiloLimpiar() {
		return this.desabilitado ? ESTILO_INVISIBLE : ESTILO_VISIBLE;
	}

	public String getEstiloPaginacionAperturas() {
		return (this.aperturas != null && this.aperturas.size() > 10) ? ESTILO_VISIBLE : ESTILO_INVISIBLE;
	}

	public void buscarApertura(ActionEvent event) {
		this.msj = "";
		try {
			this.apertura = this.sirAladiDao.getApertura(this.apertura);
			if (this.apertura != null && this.sirAladiDao.usuarioPuedeVerApertura(this.usuario, this.apertura, this.tipoApertura))
				this.recuperarRegistros();
			else {
				this.crearObjetosPorDefecto();
				this.msj = getAlertJS("No se encontr� ning�n instrumento con el c�digo de reembolso ingresado.");
			}
		} catch (Exception e) {
			this.msj = getAlertJS("Debe ingresar todos los campos del c�digo de reembolso y estos deben ser num�ricos.");
			e.printStackTrace();
		}

	}

	private void recuperarRegistros() {
		this.desabilitado = false;
		this.aperturaInicial = (Apertura) SerializationUtils.clone(this.apertura);
		this.registros = this.sirAladiDao.getRegistros(this.apertura.getNroMov());
		this.obtenerDatosParametricos();
	}

	public void mostrarReporte(ActionEvent event) {
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("NRO_MOV", this.apertura.getNroMov());
		parametros.put("TITULO", "ENMIENDAS");
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("pathTranslated", request.getPathTranslated());
		request.getSession().setAttribute("nombreReporte", "repEnmiendas.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}

	public void mostrarAdjunto(ActionEvent event) {
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("nroMov", this.apertura.getNroMov());
	}

	public void verEdicionRegistro(Registro registroSel) {
		log.info("XXX: verEdicionRegistro " + registroSel.getNroMov());		
			this.registro = registroSel;
			if (this.registro.getHaberMo().compareTo(BigDecimal.ZERO) > 0) {
				this.registro.setDebeMo(this.registro.getHaberMo().multiply(new BigDecimal(-1)));
				this.registro.setHaberMo(BigDecimal.ZERO);
			}

	}
	public void nuevoRegistro() {
		log.info("XXX: nuevoRegistro ");
		this.registro = new Registro();
			this.registro.setInstitucion(this.registros.get(0).getInstitucion());
			this.registro.setInstrumento(this.registros.get(0).getInstrumento());
			this.registro.setNit(this.registros.get(0).getNit());
			this.registro.setCodUsuario(this.usuario.getLogin());
			this.registro.setEstacion(getVisit().getAddress());
	}	
	public void registrarRegistro(ActionEvent event) {
		this.msj = "";
		if (this.registro.getDebeMo().compareTo(BigDecimal.ZERO) >= 0) {
			if (this.registro.getCveTipoEmis() == null)
				this.registro.setCveTipoEmis(TIPO_EMISION_INCREMENTO);
			this.registro.setHaberMo(BigDecimal.ZERO);
		} else {
			this.registro.setCveTipoEmis(TIPO_EMISION_DECREMENTO);
			this.registro.setHaberMo(this.registro.getDebeMo().abs());
			this.registro.setDebeMo(BigDecimal.ZERO);
		}

		StatusResponse statusResponse = null;
		this.registro.setFechaTrans(this.sirAladiDao.getFechaActual());
		if (this.registro.getNroMov() != null && this.registro.getNroMov() > 0)
			statusResponse = Servicios.modificarRegistro(this.apertura, this.registro);
		else
			statusResponse = Servicios.registrarRegistro(this.apertura, this.registro);
		if (SUCCESS.equals(statusResponse.getStatusCode())) {
			this.registros = this.sirAladiDao.getRegistros(this.apertura.getNroMov());
			this.msj = getAlertConCierreModalJS("panelRegistro", statusResponse);
		} else
			this.msj = getAlertJS(statusResponse);
	}

	public void autorizarRegistro(Registro registroSel) {
		log.info("XXX: autorizarRegistro " + registroSel.getNroMov());
		this.realizarOperacionRegistro(registroSel, true);
	}

	public void eliminarRegistro(Registro registroSel) {
		log.info("XXX: eliminarRegistro " + registroSel.getNroMov());		
		this.realizarOperacionRegistro(registroSel, false);
	}

	private void realizarOperacionRegistro(Registro registroSel, boolean esAutorizacion) {
		this.msj = "";
		this.registro = registroSel;
		StatusResponse statusResponse = null;
		if (esAutorizacion) {
			this.registro.setCveEstadoReg(ESTADO_CONTABILIZADO);
			statusResponse = Servicios.modificarRegistro(this.apertura, this.registro);
		} else
			statusResponse = Servicios.eliminarRegistro(this.apertura, this.registro);
		if (SUCCESS.equals(statusResponse.getStatusCode()))
			this.registros = this.sirAladiDao.getRegistros(this.apertura.getNroMov());
		this.msj = getAlertJS(statusResponse);
	}
	public void guardarApertura(ActionEvent event) {
		this.msj = "";
		StatusResponse statusResponse = Servicios.modificarApertura(this.apertura);
		if (SUCCESS.equals(statusResponse.getStatusCode())) {
			this.apertura = this.sirAladiDao.getApertura(this.apertura.getNroMov());
			this.aperturaInicial = (Apertura) SerializationUtils.clone(this.apertura);
			this.msj = getAlertConCierreModalJS("panelApertura", statusResponse);
		} else {
			this.apertura = (Apertura) SerializationUtils.clone(this.aperturaInicial);
			this.msj = getAlertJS(statusResponse);
		}
	}

	public void consultarAperturasVigentes(ActionEvent event) {
		this.msj = "";
		this.filtro = "";
		this.aperturasInicial = this.sirAladiDao.getAperturas(this.tipoApertura, ESTADO_VIGENTE,
				"R", null,this.usuario.getPersona(), null, null, null);
		this.aperturas = this.aperturasInicial;
	}

	public void consultarAperturas(ActionEvent event) {
		this.consultarAperturas();
	}

	private void consultarAperturas() {
		this.msj = "";
		this.filtro = "";
		this.aperturasInicial = this.sirAladiDao.getAperturas(this.tipoApertura, ESTADO_VIGENTE,
				"R", ESTADO_PENDIENTE, this.usuario.getPersona(), null, null, null);
		this.aperturas = this.aperturasInicial;
	}

	public void seleccionarApertura(Apertura aperturaSel) {
		log.info("XXX: seleccionarApertura " + aperturaSel.getCodigoReembolsoCorrido());
		this.msj = "";
		this.mostrarModal = false;
		this.apertura = aperturaSel;
		this.recuperarRegistros();
		this.msj = getCierreModalPanelJS("modalPanelEmisiones");
	}

	public void filtrar(ActionEvent event) {
		if (StringUtils.isEmpty(this.filtro))
			this.aperturas = this.aperturasInicial;
		else {
			this.aperturas = new ArrayList<Apertura>();
			for (Apertura ap : this.aperturasInicial) {
				if (ap.getCodigoReembolso().indexOf(this.filtro.trim()) >= 0)
					this.aperturas.add(ap);
			}
		}
	}

	public void limpiar(ActionEvent event) {
		this.crearObjetosPorDefecto();
	}

	private void crearObjetosPorDefecto() {
		this.msj = "";
		this.desabilitado = true;
		this.mostrarModal = true;

		// Apertura
		this.apertura = new Apertura();
		this.apertura.setIdentificador(new Identificador());
		this.apertura.setInstitucion(new Institucion());
		this.apertura.setPais(new Pais());

		// Registros
		this.registros = new ArrayList<Registro>();

		// mapas y combos vacios
		this.itemsInstituciones = new ArrayList<SelectItem>();
	}

	private void obtenerDatosParametricos() {
		List<Institucion> listaInstituciones;
		if (this.apertura.getCveTipoApe().equals(TIPO_APERTURA_IMPORTACION))
			listaInstituciones = this.sirAladiDao.getInstitucionesPorPais(this.apertura.getPais().getCodPais());
		else
			listaInstituciones = this.usuario.getPersona().getInstitucions();

		this.itemsInstituciones = armarSelectItemsInstituciones(listaInstituciones);

		if (this.mapClavesTipoEmision == null) {
			this.mapClavesTipoEmision = armarMapDescripcionClaves(this.sirAladiDao.getClaves(CVE_TIPO_EMISION));
			this.mapClavesEstadoRegistro = armarMapDescripcionClaves(this.sirAladiDao.getClaves(CVE_ESTADO_REGISTRO));
			this.mapClavesEstadoApertura = armarMapDescripcionClaves(this.sirAladiDao.getClaves(CVE_ESTADO_APERTURA));			
		}
	}

	public void setTipoApertura(String tipoApertura) {
		this.tipoApertura = tipoApertura;
	}

	public String getTipoApertura() {
		return tipoApertura;
	}

	public void setMapClavesEstadoApertura(Map<String, String> mapClavesEstadoApertura) {
		this.mapClavesEstadoApertura = mapClavesEstadoApertura;
	}

	public Map<String, String> getMapClavesEstadoApertura() {
		return mapClavesEstadoApertura;
	}

}
