package gob.bcb.portal.sirAladi.view.parametricas;

import gob.bcb.bpm.siraladi.jpa.Cargo;
import gob.bcb.bpm.siraladi.jpa.Categoria;
import gob.bcb.bpm.siraladi.jpa.Persona;
import gob.bcb.bpm.siraladi.jpa.PersonaInst;
import gob.bcb.bpm.siraladi.jpa.PersonaInstPK;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class PersonaController extends BaseBeanController {
	private static final Log log = LogFactory.getLog(PersonaController.class);
	private List<Persona> personaLista = new ArrayList<Persona>();
	private Persona personaSelected = new Persona();
	private Categoria categoriaSelected = new Categoria();
	private PersonaInst personaInstSelected = new PersonaInst();
	private List<PersonaInst> personaInstLista = new ArrayList<PersonaInst>();	
	private List<Cargo> cargoLista = new ArrayList<Cargo>();	
	private Cargo cargoSelected = new Cargo();
	private String sIOCWEB_TIPOPERACION;
	
	@PostConstruct
	public void init() {
		log.info("PostConstruct - " + getClass().getName());
		try {
			recuperarVisit();

			String codEnt = getVisit().getUsuarioSirAladi().getPersona().getCodPersona();
			String ip = getVisit().getAddress();

			sIOCWEB_TIPOPERACION = (String) getVisit().getParametro("SIOCWEB_TIPOPERACION");
			log.info("Par. sIOCWEB_TIPOPERACION= " + sIOCWEB_TIPOPERACION + " usuario: " + getVisit().getUsuarioSirAladi().getLogin()
					+ " ==> codEnt: " + codEnt + " ip " + ip);

			recuperarDatos();
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Ocurrió un error: " + e.getMessage(), null));
		}
		
	}
	
	private void recuperarDatos() {
		personaSelected = new Persona();		
		personaLista = getServiceDao().getPersonaLocal().findAll();
	}

	public void adicionar() {
		personaSelected = new Persona();
	}
	public void editar(Persona cta0) {
		personaSelected = getServiceDao().getPersonaLocal().findByCodigo(cta0.getCodPersona());
	}
	
	public void editarCategoria(Persona cta0) {
		categoriaSelected = getServiceDao().getCategoriaLocal().getCalifVigByPersona(cta0.getCodPersona(), new Date());
		
		if (categoriaSelected == null){
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "No existe registro de calif para entidad: " + cta0.getCodPersona(), null));			
		}
		
	}	
	
	public void verPersonaInst(Persona cta0) {
		personaInstLista = getServiceDao().getPersonaInstLocal().findByCodPersona(cta0.getCodPersona());
	}	
	
	public void verCargosLista(Persona cta0) {
		cargoLista = getServiceDao().getCargoLocal().findByCodPersona(cta0.getCodPersona());
	}
	
	public void addPersonaInst(Persona cta0) {
		personaInstSelected = new PersonaInst();
		personaInstSelected.setId(new PersonaInstPK());
		personaInstSelected.getId().setCodPersona(cta0.getCodPersona());
	}	

	public void addCargo(Persona cta0) {
		cargoSelected = new Cargo();
		cargoSelected.setCodPersona(cta0.getCodPersona());
		cargoSelected.setCodMoneda("69");
	}	
	
	public void addPersona() {
		personaSelected = new Persona();
		personaSelected.setCveVigente("V");
	}
	
	private void guardarReg(Persona socBanco) {
		socBanco.setEstacion(getVisit().getAddress());
		socBanco.setCodUsuario(getVisit().getUsuarioSirAladi().getLogin());
		socBanco.setFechaHora(new Date());
		getServiceDao().getPersonaLocal().saveorupdate(socBanco);
		
	}
	private void guardarRegCategoria(Categoria socBanco) {
		socBanco.setEstacion(getVisit().getAddress());
		socBanco.setCodUsuario(getVisit().getUsuarioSirAladi().getLogin());
		socBanco.setFechaHora(new Date());
		getServiceDao().getCategoriaLocal().saveorupdate(socBanco);
		
	}
	
	public void guardar() {
		try {
			guardarReg(personaSelected);
			recuperarDatos();
			addMessageInfo("Aviso", "La operación se realizó exitósamente.");			
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
		}
	}

	public void guardarCategoria() {
		try {
			guardarRegCategoria(categoriaSelected);
			recuperarDatos();
			addMessageInfo("Aviso", "La operación se realizó exitósamente.");			
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
		}
	}
	
	private void guardarPersonaInst(PersonaInst socBanco) {
		getServiceDao().getPersonaInstLocal().saveorupdate(socBanco);
	}	
	public void guardarPersonaInst() {
		try {
			guardarPersonaInst(personaInstSelected);
			recuperarDatos();
			addMessageInfo("Aviso", "La operación se realizó exitósamente.");			
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
		}
	}	

	private void guardarCargo(Cargo socBanco) {
		getServiceDao().getCargoLocal().saveorupdate(socBanco);
	}
	
	public void guardarCargo() {
		try {
			guardarCargo(cargoSelected);
			recuperarDatos();
			addMessageInfo("Aviso", "La operación se realizó exitósamente.");			
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
		}
	}	
	
	public List<Persona> getPersonaLista() {
		return personaLista;
	}

	public void setPersonaLista(List<Persona> personaLista) {
		this.personaLista = personaLista;
	}

	public Persona getPersonaSelected() {
		return personaSelected;
	}

	public void setPersonaSelected(Persona personaSelected) {
		this.personaSelected = personaSelected;
	}

	public PersonaInst getPersonaInstSelected() {
		return personaInstSelected;
	}

	public void setPersonaInstSelected(PersonaInst personaInstSelected) {
		this.personaInstSelected = personaInstSelected;
	}

	public List<PersonaInst> getPersonaInstLista() {
		return personaInstLista;
	}

	public void setPersonaInstLista(List<PersonaInst> personaInstLista) {
		this.personaInstLista = personaInstLista;
	}

	public Categoria getCategoriaSelected() {
		return categoriaSelected;
	}

	public void setCategoriaSelected(Categoria categoriaSelected) {
		this.categoriaSelected = categoriaSelected;
	}

	public List<Cargo> getCargoLista() {
		return cargoLista;
	}

	public void setCargoLista(List<Cargo> cargoLista) {
		this.cargoLista = cargoLista;
	}

	public Cargo getCargoSelected() {
		return cargoSelected;
	}

	public void setCargoSelected(Cargo cargoSelected) {
		this.cargoSelected = cargoSelected;
	}

}
