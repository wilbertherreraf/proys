/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-web-sirAladi
 * gob.bcb.portal.sirAladi.dao.DaoFactory
 * 14/11/2011 - 14:48:14
 * Creado por wherrera
 */
package gob.bcb.portal.sirAladi.dao;

import gob.bcb.bpm.siraladi.service.ServiceDao;

import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

/**
 * Clase que implementa el patr�n Factory para generar el DAO correspondiente.
 * 
 * @author wherrera
 * 
 */
public class DaoFactory {
	private static Logger log = Logger.getLogger(DaoFactory.class);
	private static DaoFactory instance;
	private BeanFactory factory;

	/**
	 * Constructor que obtiene el BeanFactory de Spring.
	 */
	private DaoFactory() {
		ServletContext servletContext = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		WebApplicationContext wac = WebApplicationContextUtils.getRequiredWebApplicationContext(servletContext);
		this.factory = wac;
		
	}

	/**
	 * Crea una instancia de la clase DaoFactory.
	 * 
	 * @return
	 */
	private synchronized static DaoFactory newInstance() {
		return new DaoFactory();
	}

	/**
	 * M�todo que crea una instancia de DaoFactory si es que no existe una.
	 * 
	 * @return
	 */
	public static DaoFactory getInstance() {
		if (instance == null) {
			instance = newInstance();
			log.info("Instacia DaoFactory nueva creada!!");
		}
		return instance;
	}

	/**
	 * M�todo que obtiene el SirAladiDao configurado en Spring.
	 * 
	 * @return
	 */
	public SirAladiDao getSirAladiDao() {
		return (SirAladiDao) factory.getBean("sirAladiDao");
	}

	public ServiceDao getServiceDao() {
		return (ServiceDao) factory.getBean("serviceDao");
	}	
}
