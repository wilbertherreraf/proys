package gob.bcb.portal.sirAladi.view.parametricas;

import gob.bcb.bpm.siraladi.jpa.CalifRiesgo;
import gob.bcb.bpm.siraladi.jpa.ClasifProductos;
import gob.bcb.bpm.siraladi.jpa.Param;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ClasifProductosController extends BaseBeanController {
	private static final Log log = LogFactory.getLog(ClasifProductosController.class);
	private List<ClasifProductos> clasifProductosLista = new ArrayList<ClasifProductos>();
	private ClasifProductos clasifProductosSelected = new ClasifProductos();
	private String sIOCWEB_TIPOPERACION;	
	
	@PostConstruct
	public void init() {
		log.info("PostConstruct - " + getClass().getName());
		try {
			recuperarVisit();

			String codEnt = getVisit().getUsuarioSirAladi().getPersona().getCodPersona();
			String ip = getVisit().getAddress();

			sIOCWEB_TIPOPERACION = (String) getVisit().getParametro("SIOCWEB_TIPOPERACION");
			log.info("Par. sIOCWEB_TIPOPERACION= " + sIOCWEB_TIPOPERACION + " usuario: " + getVisit().getUsuarioSirAladi().getLogin()
					+ " ==> codEnt: " + codEnt + " ip " + ip);

			recuperarDatos();
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Ocurrió un error: " + e.getMessage(), null));
		}
		
	}
	
	private void recuperarDatos() {
		clasifProductosSelected = new ClasifProductos();		

		clasifProductosLista = getServiceDao().getClasifProductosLocal().findAll();
		log.info("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")		;
		log.info(clasifProductosLista.size())		;		
	}
	public void adicionar() {
		clasifProductosSelected = new ClasifProductos();
	}
	public void editar(ClasifProductos cta0) {
		clasifProductosSelected = getServiceDao().getClasifProductosLocal().findByCodigo(cta0.getCodClasifprod());
	}

	public void guardarReg(ClasifProductos socBanco) {
//		socBanco.setEstacion(getVisit().getAddress());
//		socBanco.setCodUsuario(getVisit().getUsuarioSirAladi().getLogin());
//		socBanco.setFechaHora(new Date());
		getServiceDao().getClasifProductosLocal().saveorupdate(socBanco);
		
	}
	public void guardar() {
		try {
			guardarReg(clasifProductosSelected);
			recuperarDatos();
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
		}
	}
	
	public List<ClasifProductos> getClasifProductosLista() {
		return clasifProductosLista;
	}

	public void setClasifProductosLista(List<ClasifProductos> clasifProductosLista) {
		this.clasifProductosLista = clasifProductosLista;
	}

	public ClasifProductos getClasifProductosSelected() {
		return clasifProductosSelected;
	}

	public void setClasifProductosSelected(ClasifProductos clasifProductosSelected) {
		this.clasifProductosSelected = clasifProductosSelected;
	}


}
