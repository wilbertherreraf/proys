package gob.bcb.portal.sirAladi.view.parametricas;

import gob.bcb.bpm.siraladi.jpa.CalifRiesgo;
import gob.bcb.portal.sirAladi.controller.BaseBeanController;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class CalifRiesgoController extends BaseBeanController {
	private static final Log log = LogFactory.getLog(ParametrosSistController.class);
	private List<CalifRiesgo> socParametrosLista = new ArrayList<CalifRiesgo>();
	private CalifRiesgo socParametrosSelected = new CalifRiesgo();
	private String sIOCWEB_TIPOPERACION;	
	
	@PostConstruct
	public void init() {
		log.info("PostConstruct - " + getClass().getName());
		try {
			recuperarVisit();

			String codEnt = getVisit().getUsuarioSirAladi().getPersona().getCodPersona();
			String ip = getVisit().getAddress();

			sIOCWEB_TIPOPERACION = (String) getVisit().getParametro("SIOCWEB_TIPOPERACION");
			log.info("Par. sIOCWEB_TIPOPERACION= " + sIOCWEB_TIPOPERACION + " usuario: " + getVisit().getUsuarioSirAladi().getLogin()
					+ " ==> codEnt: " + codEnt + " ip " + ip);

			recuperarDatos();
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Ocurrió un error: " + e.getMessage(), null));
		}
		
	}

	private void recuperarDatos() {
		socParametrosSelected = new CalifRiesgo();		
		socParametrosLista = getServiceDao().getCalifRiesgoLocal().findAll();
	}

	public void adicionar() {
		socParametrosSelected = new CalifRiesgo();
	}
	public void editar(CalifRiesgo cta0) {
		socParametrosSelected = getServiceDao().getCalifRiesgoLocal().findByCodigo(cta0.getCodCalif());
	}
	
	private void guardarReg(CalifRiesgo socBanco) {
		socBanco.setEstacion(getVisit().getAddress());
		socBanco.setCodUsuario(getVisit().getUsuarioSirAladi().getLogin());
		socBanco.setFechaHora(new Date());
		getServiceDao().getCalifRiesgoLocal().saveorupdate(socBanco);
		
	}
	public void guardar() {
		try {
			guardarReg(socParametrosSelected);
			recuperarDatos();
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
		}
	}
	
	public List<CalifRiesgo> getSocParametrosLista() {
		return socParametrosLista;
	}

	public void setSocParametrosLista(List<CalifRiesgo> socParametrosLista) {
		this.socParametrosLista = socParametrosLista;
	}

	public CalifRiesgo getSocParametrosSelected() {
		return socParametrosSelected;
	}

	public void setSocParametrosSelected(CalifRiesgo socParametrosSelected) {
		this.socParametrosSelected = socParametrosSelected;
	}

}
