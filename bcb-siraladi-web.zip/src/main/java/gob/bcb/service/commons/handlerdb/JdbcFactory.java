package gob.bcb.service.commons.handlerdb;

 
import gob.bcb.bpm.siraladi.utils.Utils;
import gob.bcb.core.utils.Constants;

import java.beans.PropertyVetoException;
import java.io.File;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.XMLConfiguration;
import org.apache.log4j.Logger;

import com.mchange.v2.c3p0.ComboPooledDataSource;

/**
 * Session factory which uses plain old jdbc connections.
 * 
 * The following properties must be set in the configuration:
 * <ul>
 * <li>oiosaml-sp.sessionhandler.factory=dk.itst.oiosaml.sp.service.session.jdbc.JndiFactory</li>
 * <li>oiosaml-sp.sessionhandler.jdbc.url: JDBC url to use for the connetion</li>
 * <li>oiosaml-sp.sessionhandler.jdbc.driver: Driver class name to use</li>
 * <li>oiosaml-sp.sessionhandler.jdbc.username</li>
 * <li>oiosaml-sp.sessionhandler.jdbc.password</li>
 * </ul>
 * 
 * @author Joakim Recht
 * 
 */
public class JdbcFactory implements DBSourceHandlerFactory {
	private static Logger log = Logger.getLogger(JdbcFactory.class);
	private XMLConfiguration config = null;
	static {
		System.setProperty("com.mchange.v2.log.MLog", "com.mchange.v2.log.FallbackMLog");	
		System.setProperty("com.mchange.v2.log.FallbackMLog.DEFAULT_CUTOFF_LEVEL", "WARNING");		
	}

	// cambiar mensajes oio
	private JdbcDBSourceHandler jdbcDBSourceHandlerInstance;
	
	public void close() {

	}

	
	public void configure(String idDBSource) {
		String url = (String) Utils.getValueFromXML(config,Constants.PROP_DB_JDBC_URL.replaceFirst("ID-DATABASE", idDBSource), "string");
		String username = (String) Utils.getValueFromXML(config,Constants.PROP_DB_JDBC_USER.replaceFirst("ID-DATABASE", idDBSource),
				"string");
		String password = (String) Utils.getValueFromXML(config,Constants.PROP_DB_JDBC_PASSWORD.replaceFirst("ID-DATABASE", idDBSource),
				"string");
		String driver = (String) Utils.getValueFromXML(config,Constants.PROP_DB_JDBC_DRIVER.replaceFirst("ID-DATABASE", idDBSource),
				"string");
		
		configure(url, username, password, driver);
	}
	
	public void configure(String path, String idDBSource) {
		try {
			config = new XMLConfiguration(new File(path));
		} catch (ConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		configure(idDBSource) ;
		
	}

	
	public void configure() {
	}

	public void configure(String url, String username, String password, String driver) {
		Map<String, String> options = new HashMap<String, String>();
		options.put("url", url);
		options.put("username", username);
		options.put("password", password);		
		options.put("driver", driver);

		jdbcDBSourceHandlerInstance = new JdbcDBSourceHandler(buildApplicationManagedConnection(options));
	}

	
	public DBSourceHandler getHandler() {
		if (jdbcDBSourceHandlerInstance == null)
			throw new IllegalStateException(
			"Instancia del Datasource a conexion a Base de datos es nulo, Por favor invoque configure antes de llamar a getHandler");			
		return jdbcDBSourceHandlerInstance;
	}

	protected DataSource buildApplicationManagedConnection(Map<String, String> options) {
		ComboPooledDataSource datasource = new ComboPooledDataSource();
		ClassLoader classLoader = this.getClass().getClassLoader();
		try {
			classLoader.loadClass(options.get("driver"));
		} catch (ClassNotFoundException e) {
			log.error("Unable to create relational database connector, JDBC driver can not be found on the classpath");
			throw new RuntimeException("Unable to create relational database connector, JDBC driver can not be found on the classpath");
		}

		try {
			datasource.setDriverClass(options.get("driver"));
			datasource.setJdbcUrl(options.get("url"));
			datasource.setUser(options.get("username"));
			datasource.setPassword(options.get("password"));

			log.debug("datos de conexion " + options.get("url") + ":" + options.get("username"));
			if (options.containsKey("poolAcquireIncrement")) {
				datasource.setAcquireIncrement(Integer.parseInt(options.get("poolAcquireIncrement")));
			} else {
				datasource.setAcquireIncrement(1);
			}

			if (options.containsKey("poolAcquireRetryAttempts")) {
				datasource.setAcquireRetryAttempts(Integer.parseInt(options.get("poolAcquireRetryAttempts")));
			} else {
				datasource.setAcquireRetryAttempts(0);
			}

			if (options.containsKey("poolAcquireRetryDelay")) {
				datasource.setAcquireRetryDelay(Integer.parseInt(options.get("poolAcquireRetryDelay")));
			} else {
				datasource.setAcquireRetryDelay(5000);
			}

			if (options.containsKey("poolBreakAfterAcquireFailure")) {
				datasource.setBreakAfterAcquireFailure(Boolean.parseBoolean(options.get("poolBreakAfterAcquireFailure")));
			} else {
				datasource.setBreakAfterAcquireFailure(false);
			}

			if (options.containsKey("poolMinSize")) {
				datasource.setMinPoolSize(Integer.parseInt(options.get("poolMinSize")));
			} else {
				datasource.setMinPoolSize(3);
			}

			if (options.containsKey("poolMaxSize")) {
				datasource.setMaxPoolSize(Integer.parseInt(options.get("poolMaxSize")));
			} else {
				datasource.setMaxPoolSize(20);
			}
			
			if (options.containsKey("poolMaxIdleTime")) {
				datasource.setMaxIdleTime(Integer.parseInt(options.get("poolMaxIdleTime")));
			} else {
				datasource.setMaxIdleTime(601);
			}

			if (options.containsKey("poolIdleTestPeriod")) {
				datasource.setIdleConnectionTestPeriod(Integer.parseInt(options.get("poolIdleTestPeriod")));
			} else {
				datasource.setIdleConnectionTestPeriod(180);
			}
			datasource.setInitialPoolSize(1);
			log.info("Created application managed data source for data connector");
			return datasource;
		} catch (PropertyVetoException e) {
			log.error("Unable to create data source for data connector with JDBC driver class " + options.get("driver"), e);
			return null;
		}
	}
	
	private abstract class DS implements DataSource {
		private String url;
		private String username;
		private String password;
		private String driver;
		
		
		public Connection getConnection() throws SQLException {
			return DriverManager.getConnection(url, username, password);
		}

		
		public Connection getConnection(String username, String password) throws SQLException {
			throw new UnsupportedOperationException();
		}

		
		public PrintWriter getLogWriter() throws SQLException {
			throw new UnsupportedOperationException();
		}

		
		public int getLoginTimeout() throws SQLException {
			throw new UnsupportedOperationException();
		}

		
		public void setLogWriter(PrintWriter out) throws SQLException {
			throw new UnsupportedOperationException();
		}

		
		public void setLoginTimeout(int seconds) throws SQLException {
			throw new UnsupportedOperationException();
		}

		
		public boolean isWrapperFor(Class<?> iface) throws SQLException {
			throw new UnsupportedOperationException();
		}

		
		public <T> T unwrap(Class<T> iface) throws SQLException {
			throw new UnsupportedOperationException();
		}

	}
}
