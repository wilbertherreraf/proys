package gob.bcb.service.commons.handlerdb;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

/**
 * Factory for creating new session handlers. Normally, only one instance of a factory is created
 * (using {@link Factory}), so implementations must be thread safe.
 */
/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public interface DBSourceHandlerFactory {

	/**
	 * Obtiene un nuevo DB Source handler .
	 */ 
	public DBSourceHandler getHandler();

	/**
	 * Close the factory. No calls to {@link #getHandler()} will be made after this call. Be aware
	 * that this method might be called several times, and should not fail if this happens.
	 */
	public void close();

	/**
	 * Configure the factory. This will be called before any calls are made to {@link #getHandler()}
	 * .
	 */
	public void configure();

	public void configure(String idDBSource);
	public void configure(String path,String idDBSource);
	
	public static class Factory {
		private static final Logger log = Logger.getLogger(DBSourceHandlerFactory.class);

		private static Map<String, DBSourceHandlerFactory> instance = new HashMap<String, DBSourceHandlerFactory>();

		public static synchronized DBSourceHandlerFactory newInstance(String idDBSource) {
			if (instance.containsKey(idDBSource))
				return instance.get(idDBSource);
		
			log.info("Creando nuevo handler factory: " + idDBSource);
			
			DBSourceHandlerFactory factory = (DBSourceHandlerFactory) new JdbcFactory();
			factory.configure(idDBSource);
			instance.put(idDBSource, factory);
			log.info("Nueva conexion nativa creada id: " + idDBSource);
			return factory;
		}
		public static synchronized DBSourceHandlerFactory newInstance(String path, String idDBSource) {
			if (instance.containsKey(idDBSource))
				return instance.get(idDBSource);
		
			log.info("Creando nuevo handler factory: " + idDBSource);
			
			DBSourceHandlerFactory factory = (DBSourceHandlerFactory) new JdbcFactory();
			factory.configure(path, idDBSource);
			instance.put(idDBSource, factory);
			log.info("Nueva conexi�n nativa creada id: " + idDBSource);
			return factory;
		}

		public static void close() {
			log.info("Cerrando instancias de conexiones nativas");
			if (instance == null) {
				return;
			}
			
			try {
				instance.clear();
				instance = null;
			} catch (Exception e) {
				log.error("Error al cerrar instancias de conexion nativas", e);
			}
			log.info("Instancias de conexiones nativas cerradas ... hecho");
		}
	}

}
