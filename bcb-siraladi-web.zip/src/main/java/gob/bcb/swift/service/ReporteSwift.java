package gob.bcb.swift.service;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.log4j.Logger;
import org.apache.poi.xwpf.converter.pdf.PdfConverter;
import org.apache.poi.xwpf.converter.pdf.PdfOptions;
import org.apache.poi.xwpf.usermodel.XWPFDocument;

import fr.opensagres.xdocreport.core.XDocReportException;
import fr.opensagres.xdocreport.document.IXDocReport;
import fr.opensagres.xdocreport.document.registry.XDocReportRegistry;
import fr.opensagres.xdocreport.template.IContext;
import fr.opensagres.xdocreport.template.TemplateEngineKind;
import fr.opensagres.xdocreport.template.formatter.FieldsMetadata;
import gob.bcb.core.utils.ArchivoSinple;
import gob.bcb.core.utils.ArchivoUtil;
import gob.bcb.core.utils.UtilsFile;
import gob.bcb.swift.exception.SwiftAdminException;
import gob.bcb.swift.pojos.Block4;
import gob.bcb.swift.pojos.SwiftDatos;

public class ReporteSwift extends ReporteSwiftAbstract {

	private static final Logger log = Logger.getLogger(ReporteSwift.class);

	private IXDocReport report;
	private IContext context;
	private static final int OUTPUT_BYTE_ARRAY_INITIAL_SIZE = 4096;

	public ReporteSwift() {

	}

	public void inicializar() {
		try {
			log.info("inicializando report xdocreport " + (TemplateEngineKind.Freemarker == null));
			report = XDocReportRegistry.getRegistry().loadReport(getArchivoTemplateReport().getArchivoSinple().getStream(), TemplateEngineKind.Freemarker);
			// FieldsMetadata metadata0 = new FieldsMetadata(
			// TemplateEngineKind.Velocity );
			FieldsMetadata metadata = report.createFieldsMetadata();
			// metadata.setTemplateEngineKind(TemplateEngineKind.Freemarker.name());
			metadata.load("block4", Block4.class, true);

			context = report.createContext();
			log.info("Contexto Freemaker inicializado ...");
		} catch (IOException e) {
			log.error("IOException: Error al generar Documento " + e.getMessage(), e);
			throw new SwiftAdminException("IOException: Error al generar Documento " + e.getMessage(), e);
		} catch (XDocReportException e) {
			log.error("XDocReportException: Error al generar Documento " + e.getMessage(), e);
			throw new SwiftAdminException("XDocReportException: Error al generar Documento " + e.getMessage(), e);
		} catch (Exception e) {
			log.error("Exception: Error al generar Documento " + e.getMessage(), e);
			throw new SwiftAdminException("Exception: Error al generar Documento " + e.getMessage(), e);
		}
	}

	public void populateReport(String swiftPlano, SwiftDatos mensajesDatos) throws IOException {
		populateFieldsReport(swiftPlano, mensajesDatos);

		context.put("header", getHeaderMsg());
		context.put("block4", getBlock4Lista());
	}

	public void render() {
		log.info("##### En renderReport...##########");
		ByteArrayOutputStream out = null;
		long start = System.currentTimeMillis();
		try {
			log.info("Antes de renderReport ");

			out = new ByteArrayOutputStream(OUTPUT_BYTE_ARRAY_INITIAL_SIZE);
			report.process(context, out);

			newFromOutputStream(out, getArchivoTemplateReport().getArchivoSinple().getNameOriginal());
			out.close();
			log.info("##### FIN renderReport...########## [" + (System.currentTimeMillis() - start) + " ms]");
		} catch (IOException e) {
			log.error("IOException: Error al generar Documento " + e.getMessage(), e);
			throw new SwiftAdminException("IOException: Error al generar Documento " + e.getMessage(), e);
		} catch (XDocReportException e) {
			log.error("XDocReportException: Error al generar Documento " + e.getMessage(), e);
			throw new SwiftAdminException("XDocReportException: Error al generar Documento " + e.getMessage(), e);
		} catch (Exception e) {
			log.error("Exception: Error al generar Documento " + e.getMessage(), e);
			throw new SwiftAdminException("Exception: Error al generar Documento " + e.getMessage(), e);
		} finally {
			if (out != null) {
				try {
					out.close();
				} catch (IOException e) {
					log.error("Error al cerrar Documento " + e.getMessage(), e);
				}
			}
		}
	}

	public ArchivoSinple convertToPDF(ArchivoSinple archivoSinple, String nameFile) {
		log.info("eN convertToPDF archivoSinple " + archivoSinple.getHash());
		long startTime = System.currentTimeMillis();
		ByteArrayOutputStream out = null;
		ArchivoSinpleServiceImpl archivoSinpleServiceImpl = null;
		try {
			// String file = "CL01FM";
			InputStream in = archivoSinple.getStream();
			// 1) Load docx with POI XWPFDocument
			XWPFDocument document = new XWPFDocument(in);

			// 2) Convert POI XWPFDocument 2 PDF with iText
			out = new ByteArrayOutputStream(OUTPUT_BYTE_ARRAY_INITIAL_SIZE);
			PdfOptions options = null;

			PdfConverter.getInstance().convert(document, out, options);

			archivoSinpleServiceImpl = new ArchivoSinpleServiceImpl();
			archivoSinpleServiceImpl.newFromOutputStream(out, nameFile);
			archivoSinpleServiceImpl.getArchivoSinple().setNameOriginal(nameFile);

			out.close();
			log.info("Generate PDF " + archivoSinpleServiceImpl.getArchivoSinple().getName() + "["
					+ archivoSinpleServiceImpl.getArchivoSinple().getNameOriginal() + "] with " + (System.currentTimeMillis() - startTime) + " ms.");
			return archivoSinpleServiceImpl.getArchivoSinple();
		} catch (IOException e) {
			log.error("IOException: Error al generar Documento " + e.getMessage(), e);
			throw new SwiftAdminException("IOException: Error al generar Documento " + e.getMessage(), e);
		} catch (Exception e) {
			log.error("Exception: Error al generar Documento " + e.getMessage(), e);
			throw new SwiftAdminException("Exception: Error al generar Documento " + e.getMessage(), e);
		} catch (Throwable e) {
			log.error("Throwable: Error al generar Documento " + e.getMessage(), e);
			throw new SwiftAdminException("Throwable: Error al generar Documento " + e.getMessage(), e);
		} finally {
			if (out != null) {
				try {
					out.close();
				} catch (IOException e) {
					log.error("Error al cerrar Documento " + e.getMessage(), e);
				}
			}
		}
	}

	public IContext getContext() {
		return context;
	}

	public void setContext(IContext context) {
		this.context = context;
	}

	public static void main(String[] args) {
		toPDFTest();
		ReporteSwift reporteSwift = new ReporteSwift();
		//
		// String swiftPlano = "";
		// try {
		// swiftPlano =
		// UtilsFile.readFileAsString("e:/opt/swfadmintest/06.txt");
		// } catch (IOException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		//
		// FileInputStream fis = null;
		//
		// String pathFileDocx = "";
		// InputStream in = null;
		// File file = null;
		// try {
		// // fis = new FileInputStream(file);
		// file = ResourceUtils.getFile("classpath:reposwift.docx");
		// in = new FileInputStream(file);
		// pathFileDocx = file.getAbsolutePath();
		// } catch (FileNotFoundException e) {
		// log.error("Error al abrir archivo reporte swift!!!!!! ");
		// throw new SwiftAdminException(e.getMessage(), e);
		// }
		//
		ArchivoSinpleServiceImpl archivoSinpleServiceImpl = new ArchivoSinpleServiceImpl();
		// archivoSinpleServiceImpl.fileUpload(in, "reposwift.docx");
		archivoSinpleServiceImpl.fromPathfile("e:/opt/aplicaciones/swiftadmin/reposwift.docx", "reposwift.docx");
		ArchivoSinple archivoSinplePDF = reporteSwift.convertToPDF(archivoSinpleServiceImpl.getArchivoSinple(), "reposwift.pdf");
		archivoSinplePDF.setDirectory("e:/tmp");
		archivoSinplePDF.setName(archivoSinplePDF.getHash() + "." + ArchivoUtil.obtenerExtension(archivoSinplePDF.getNameOriginal()));
		archivoSinplePDF.putPathFile();
		String p = UtilsFile.grabaEnArchivo(archivoSinplePDF.getStream(), archivoSinplePDF.getPathFile());
		//
		// reporteSwift.setTemplateService(archivoSinpleServiceImpl);
		// reporteSwift.inicializar();
		//
		// try {
		// reporteSwift.populateFieldsReport(swiftPlano);
		// } catch (IOException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		//
		// reporteSwift.render();
		// reporteSwift.getArchivoSinple().setDirectory("e:/tmp");
		// reporteSwift.getArchivoSinple().setName(
		// reporteSwift.getArchivoSinple().getHash() + "." +
		// ArchivoUtil.obtenerExtension(reporteSwift.getArchivoSinple().getNameOriginal()));
		// reporteSwift.putPathFile();
		//
		// String p =
		// UtilsFile.grabaEnArchivo(reporteSwift.getArchivoSinple().getStream(),
		// reporteSwift.getArchivoSinple().getPathFile());
		log.info("archivo salvado " + p);

	}

	public static void toPDFTest() {
		long startTime = System.currentTimeMillis();

		try {
			String file = "CL01FM";
			InputStream in = new FileInputStream("E:\\tmp\\" + file + ".docx");
			// 1) Load docx with POI XWPFDocument
			XWPFDocument document = new XWPFDocument(in);

			// 2) Convert POI XWPFDocument 2 PDF with iText
			File outFile = new File("E:\\tmp\\" + file + ".pdf");
			outFile.getParentFile().mkdirs();

			OutputStream out = new FileOutputStream(outFile);
			PdfOptions options = null; // PdfOptions.create().fontEncoding(
										// "windows-1250" );
			PdfConverter.getInstance().convert(document, out, options);
			System.out.println("Generate DocxBig.pdf with " + (System.currentTimeMillis() - startTime) + " ms.");
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}

}
