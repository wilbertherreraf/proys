package gob.bcb.swift.test;

import gob.bcb.bpm.siraladi.jpa.Param;
import gob.bcb.bpm.siraladi.jpa.SwfMensaje;
import gob.bcb.bpm.siraladi.service.ServiceDao;
import gob.bcb.portiaswift.entities.Loader;
import gob.bcb.portiaswift.service.ServiceSwiftDao;

import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.context.support.FileSystemXmlApplicationContext;


public class SwiftMessageServicePTest {
	private static Logger log = Logger.getLogger(SwiftMessageServicePTest.class);
	private FileSystemXmlApplicationContext factory;
	private ServiceSwiftDao serviceSwiftDao;
	private ServiceDao serviceDao ;	

	public void initContext() {
		factory = new FileSystemXmlApplicationContext("WebContent/WEB-INF/applicationContext.xml");
		serviceSwiftDao = (ServiceSwiftDao) factory.getBean("serviceSwiftDao");
		serviceDao = (ServiceDao) factory.getBean("serviceDao");		
	}

	public void actualizarSwift(Integer mencod) {
		SwfMensaje swfMensaje = serviceDao.getSwfMensajeLocal().findByCodigo(mencod);
		swfMensaje = serviceDao.getSwiftMessageServiceLocal().actualizarCorrelativo(swfMensaje);
		
		log.info("FIN UPD correlativo portia " + swfMensaje.getMenCodmen());		
	}
	public void nuevonroSwift() {
		Loader loader = serviceSwiftDao.getLoaderQLBeanLocal().nuevoCodSwift("SIRALADI", "auditWst", "auditUsr");
		log.info("Nro swift Portia asignado " + loader.getNumeroSwift() + " id " + loader.getIdLoader());		
		loader = serviceSwiftDao.getLoaderQLBeanLocal().maxLoader();
		log.info("loader.getIdLoader() " + loader.getIdLoader());		
	}	
	
	public void updateSwfMensaje() {
		SwfMensaje swfMensaje = serviceDao.getSwfMensajeLocal().findByCodigo(1);
		log.info("loader.getIdLoader() " + swfMensaje.getMenAuditfho());
		
		swfMensaje.setMenAuditfho(new Date());
		
		serviceDao.getSwfMensajeLocal().saveorupdate(swfMensaje);
		swfMensaje = serviceDao.getSwfMensajeLocal().findByCodigo(1);
		log.info("loader.getIdLoader() " + swfMensaje.getMenAuditfho());
		
	}	
	
	public void updateLoader() {
		Loader loader = serviceSwiftDao.getLoaderQLBeanLocal().findByCodigo(1);
		log.info("loader.getIdLoader() " + loader.getFechaHora());
		
		loader.setFechaHora(new Date());
		loader.setIdPortia((int) (new Date()).getTime());
		
		loader = serviceSwiftDao.getLoaderQLBeanLocal().saveorupdate(loader);
		
		loader = serviceSwiftDao.getLoaderQLBeanLocal().findByCodigo(1);
		log.info("loader.getIdLoader() " + loader.getIdPortia());		
		log.info("loader.getIdLoader() " + loader.toString());
		
	}	
	public void autorizarMensaje(Integer mencod) {
		SwfMensaje swfMensaje = serviceDao.getSwfMensajeLocal().findByCodigo(mencod);
		swfMensaje = serviceDao.getSwiftMessageServiceLocal().autorizarMensaje(swfMensaje);

	}
	
	public static void main(String args[]) {
		SwiftMessageServicePTest swiftMessageServiceTest = new SwiftMessageServicePTest();
		try {
			log.error("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX: ");
			swiftMessageServiceTest.initContext();
			//swiftMessageServiceTest.actualizarSwift(17);
			//swiftMessageServiceTest.nuevonroSwift();
			//swiftMessageServiceTest.updateSwfMensaje();
			//swiftMessageServiceTest.updateLoader();
			swiftMessageServiceTest.autorizarMensaje(17);
			
		}catch (Exception e) {
			log.error("XXX: " + e.getMessage(), e);
		}
	}
}
