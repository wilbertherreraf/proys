package gob.bcb.swift.test;

import gob.bcb.bpm.siraladi.exceptions.AladiException;
import gob.bcb.bpm.siraladi.jpa.SwfMensaje;
import gob.bcb.bpm.siraladi.service.ServiceDao;
import gob.bcb.portiaswift.entities.Loader;
import gob.bcb.portiaswift.service.ServiceSwiftDao;
import gob.bcb.swift.pojos.SwiftDatos;

import org.apache.log4j.Logger;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class SwiftMessageServiceTest {
	private static Logger log = Logger.getLogger(SwiftMessageServiceTest.class);
	private FileSystemXmlApplicationContext factory;
	private ServiceSwiftDao serviceSwiftDao;
	private ServiceDao serviceDao ;	

	public void initContext() {
		factory = new FileSystemXmlApplicationContext("WebContent/WEB-INF/applicationContext.xml");
		serviceSwiftDao = (ServiceSwiftDao) factory.getBean("serviceSwiftDao");
		serviceDao = (ServiceDao) factory.getBean("serviceDao");		
	}

	public void actualizarSwift(Integer mencod) {
		SwfMensaje swfMensaje = serviceDao.getSwfMensajeLocal().findByCodigo(mencod);
		//serviceDao.getSwiftMessageServiceLocal().actualizarCorrelativo(swfMensaje);
		
		log.info("Inicio UPD correlativo portia " + swfMensaje.getMenCodmen());
		SwiftDatos swiftDatos = serviceDao.getSwfMensajeLocal().swiftDatosFromSwfMensaje(swfMensaje);
		Loader loader = serviceSwiftDao.getLoaderQLBeanLocal().nuevoCodSwift("SIRALADI", "auditWst", "auditUsr");
		
		log.info("Nro swift Portia asignado " + loader.getNumeroSwift() + " id " + loader.getIdLoader() + " a mensaje==> " + swfMensaje.getMenCodmen());
		
		swfMensaje.setMenNrocorr(loader.getNumeroSwift());

		loader = serviceSwiftDao.getLoaderQLBeanLocal().maxLoader();
		//loader = loaderQLBeanLocal.maxLoader();
		log.info("loader.getIdLoader() " + loader.getIdLoader() + " " + swfMensaje.getMenNrocorr());
		if (loader.getNumeroSwift().compareTo(swfMensaje.getMenNrocorr()) != 0){
			throw new AladiException("ERROR_DE_VALIDACION", new Object[] { "Error al actualizar nro swift mensaje "
					+ swfMensaje.getMenCodmen() + " nro asignado no coincide " + swfMensaje.getMenNrocorr()});			
		}
		
		SwfMensaje swfMensajeNew = serviceDao.getSwfMensajeLocal().saveorupdate(swfMensaje);
		swiftDatos.setSwfMensaje(swfMensajeNew);
		
//		//generarCorrelativoSwiftPortia(swiftDatos);
//		serviceDao.getSwiftMessageServiceLocal().actualizarCampo(swiftDatos, "20", 4, null);
//		log.info("FIN UPD correlativo portia " + swfMensaje.getMenCodmen());		
	}
	public void nuevonroSwift() {
		Loader loader = serviceSwiftDao.getLoaderQLBeanLocal().nuevoCodSwift("SIRALADI", "auditWst", "auditUsr");
		log.info("Nro swift Portia asignado " + loader.getNumeroSwift() + " id " + loader.getIdLoader());		
		loader = serviceSwiftDao.getLoaderQLBeanLocal().maxLoader();
		log.info("loader.getIdLoader() " + loader.getIdLoader());		
	}	
	public static void main(String args[]) {
		SwiftMessageServiceTest swiftMessageServiceTest = new SwiftMessageServiceTest();
		try {
			swiftMessageServiceTest.initContext();
			//swiftMessageServiceTest.actualizarSwift(17);
			swiftMessageServiceTest.nuevonroSwift();
			
		}catch (Exception e) {
			log.error("XXX: " + e.getMessage(), e);
		}
	}
}
