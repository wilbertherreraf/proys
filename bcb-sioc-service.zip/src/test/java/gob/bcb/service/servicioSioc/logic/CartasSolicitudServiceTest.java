package gob.bcb.service.servicioSioc.logic;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Assert;
import org.junit.Test;

import gob.bcb.bpm.pruebaCU.Beneficiario;
import gob.bcb.bpm.pruebaCU.CarCartascr;
import gob.bcb.bpm.pruebaCU.CarCartascrDao;
import gob.bcb.bpm.pruebaCU.CarCartascrdet;
import gob.bcb.bpm.pruebaCU.CarCartascrdetDao;
import gob.bcb.bpm.pruebaCU.QueryProcessor;
import gob.bcb.bpm.pruebaCU.SocBenefsDao;
import gob.bcb.bpm.pruebaCU.SocCuentassol;
import gob.bcb.bpm.pruebaCU.SocCuentassolDao;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocDetallessolDao;
import gob.bcb.bpm.pruebaCU.SocOpecomiDao;
import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.bpm.pruebaCU.SocSolicitudctas;
import gob.bcb.bpm.pruebaCU.SocSolicitudctasDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudctasPK;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.SocSolicitudesDao;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.core.utils.UtilsXML;
import gob.bcb.service.config.BaseData;
import gob.bcb.service.servicioPortiaSwift.PortiaService;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.ws.MensajeSiocTO;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;
 
public class CartasSolicitudServiceTest extends BaseData {
	private static final Log log = LogFactory.getLog(CartasSolicitudServiceTest.class);
	private CartasCredService cartasCredService;
	private SocSolicitudesDao socSolicitudesDao;
	private SocDetallessolDao socDetallessolDao;
	private SocSolicitudctasDao socSolicitudctasDao;
	private CarCartascrDao carCartascrDao;
	private CarCartascrdetDao carCartascrdetDao;
	private SocBenefsDao socBenefsDao;
	private ProcesosSolicitud procesosSolicitud = new ProcesosSolicitud();
	private SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
	private RegistrarSolicitud registrarSolicitud = new RegistrarSolicitud();
	private SocOpecomiDao socOpecomiDao;
	private ActualizarAFecha actualizarAFecha = new ActualizarAFecha();
	
	@Test
	public void cargarCartaFromSigepTest() throws Exception {
		log.info("========== nuevaCartascrTest =============");
		String filexml = "src/test/resources/mensmefp/v10_273.xml";
		iniciarDaos();		
		SocSolicitudes socSolicitudes = cargarXMLFromSigepTest(filexml);
		log.info("hechoooooooooooooooooooooooooooooo");
	}
	
	//@Test
	public void recuperarYProcesarEmisionTest() throws Exception {
		log.info("========== procesarSolicitudProvisionCartaTest =============");
		iniciarDaos();
		Solicitud solicitudTO = cartasCredService.inicilizaORecuperaEmisionCarta("006616");
		
		CarCartascr carCartascr = solicitudTO.getCarCartascr();
		CarCartascrdet carCartascrdet = solicitudTO.getCarCartascrdet();
		carCartascrdet.setCcdGlosa("Emison de carta");
		
		carCartascr.setCcrFechaemis(new Date());
		carCartascr.setCcrFechavtopag(UtilsDate.addTime(carCartascr.getCcrFechaemis(), 335, 5));
		
		carCartascr.setCcrNomexportador("getCcrNomexportador");
		carCartascr.setCcrNomimportador("getCcrNomimportador()");
		carCartascr.setCcrNomproducto("solicitud.getCarCartascr().getCcrNomproducto()");
		carCartascr.setCcrBencodigo("000663");
		carCartascr.setCcrBcocodigo("000286");
		SocSolicitudctas socSolicitudctasAcreditivo = new SocSolicitudctas();
		socSolicitudctasAcreditivo.setCtaAfectable("013308");
		
		solicitudTO.setSocSolicitudctasLista(Arrays.asList(socSolicitudctasAcreditivo));
		solicitudTO.getSolicitud().setFechaCont(new Date());		
		procesar(solicitudTO, "REG_SOLICITUD_CC");
		
		solicitudTO.getSolicitud().setFechaCont(new Date());

		solicitudTO = procesar(solicitudTO, "ACT_A_FECHA");

		procesar(solicitudTO, "ctrlcompros");
		
		//procesar(solicitudTO, "PREAUT");
		//Thread.sleep(5000);
		log.info("hechoooooooooooooooooooooooooooooo");		
	}

	//@Test
	public void preautorizarSolicitudTest() throws Exception {
		log.info("========== preautorizarSolicitudTest =============");
		iniciarDaos();
		Solicitud solicitudTO = cartasCredService.inicilizaORecuperaEmisionCarta("006424");
		
		CarCartascr carCartascr = solicitudTO.getCarCartascr();
		CarCartascrdet carCartascrdet = solicitudTO.getCarCartascrdet();
		
		carCartascr.setCcrFechaemis(new Date());
		carCartascr.setCcrFechavtopag(UtilsDate.addTime(carCartascr.getCcrFechaemis(), 335, 5));
		
		carCartascr.setCcrNomexportador("getCcrNomexportador");
		carCartascr.setCcrNomimportador("getCcrNomimportador()");
		carCartascr.setCcrNomproducto("solicitud.getCarCartascr().getCcrNomproducto()");
		carCartascr.setCcrBencodigo("000663");
		carCartascr.setCcrBcocodigo("000286");
		SocSolicitudctas socSolicitudctasAcreditivo = new SocSolicitudctas();
		socSolicitudctasAcreditivo.setCtaAfectable("013308");
		
		solicitudTO.setSocSolicitudctasLista(Arrays.asList(socSolicitudctasAcreditivo));
		solicitudTO.getSolicitud().setFechaCont(new Date());		
		procesar(solicitudTO, "PREAUT");
		log.info("hechoooooooooooooooooooooooooooooo");		
	}

	//@Test
	public void autorizarSolicitudTest() throws Exception {
		log.info("========== autorizarSolicitudTest =============");
		iniciarDaos();
		Solicitud solicitudTO = cartasCredService.inicilizaORecuperaEmisionCarta("006509");
		
		//solicitudTO.getSolicitud().setFechaCont(new Date());		
		procesar(solicitudTO, "AUTSWFT");
		procesar(solicitudTO, "AUTSOL");
		procesar(solicitudTO, "NOTIFMEFP");
		log.info("hechoooooooooooooooooooooooooooooo");		
	}
	
	//@Test
	public void crearPagoTest() throws Exception {
		log.info("========== crearPagoTest =============");
		iniciarDaos();
		Solicitud solicitudTO = cartasCredService.inicilizaORecuperaPago("000072", Constants.CLAVE_CCRED_TIPOEMISION_PAGO);
		
		CarCartascr carCartascr = solicitudTO.getCarCartascr();
		CarCartascrdet carCartascrdet = solicitudTO.getCarCartascrdet();		
		carCartascrdet.setCcdMonto(BigDecimal.valueOf(55000));
		carCartascrdet.setCcdGlosa("pagoo55555555555");		
		carCartascrdet.setCcdCodbcoreceptor("000199");		
		
		SocDetallessol socDetallessol = solicitudTO.getSocDetallessolLista().get(0);
		
		socDetallessol.setCodBanco("000011");// bofa 000011,000506		
		socDetallessol.setDetInfo("/BNF/PAYMENT NRO 2 ////BNK BK REF:00333-11-0104901 ////LC REF:I-2018-013"); // CAMPO 72
		socDetallessol.setDetCodttransfer("202E"); // nordeasocDetallessol.getDetCodttransfer()

		SocSolicitudctasPK socSolicitudctasPK = new SocSolicitudctasPK();
		socSolicitudctasPK.setTipoCuenta(Constants.COD_CLAVE_BENEFMT);
		
		SocSolicitudctas socSolicitudctasBenefMT = new SocSolicitudctas();
		socSolicitudctasBenefMT.setId(socSolicitudctasPK);
		socSolicitudctasBenefMT.setCtaAfectable("012949"); // 
		
		solicitudTO.setSocSolicitudctasLista(Arrays.asList(socSolicitudctasBenefMT));
		solicitudTO.getSolicitud().setFechaCont(new Date());		
		solicitudTO = procesar(solicitudTO, "REG_CC_PAGOENMI");
		log.info("soliccc " + solicitudTO.getSolicitud().getSocCodigo());
		solicitudTO.getSolicitud().setFechaCont(new Date());		
		solicitudTO = procesar(solicitudTO, "ACT_A_FECHA");

		//procesar(solicitudTO, "PREAUT");
		//procesar(solicitudTO, "AUTSOL");
		log.info("hechoooooooooooooooooooooooooooooo");		
	}
	
	//@Test
	public void preaoutoPagoTest() throws Exception {
		log.info("========== crearPagoTest =============");
		iniciarDaos();
		Solicitud solicitudTO = cartasCredService.recuperarDatosCartaParaCodcartacr("000061", 2);
		
		procesar(solicitudTO, "PREAUT");
		procesar(solicitudTO, "AUTSOL");
		log.info("hechoooooooooooooooooooooooooooooo");		
	}
	//@Test
	public void autoPagoTest() throws Exception {
		log.info("========== autoPagoTest =============");
		iniciarDaos();
		Solicitud solicitudTO = cartasCredService.recuperarDatosCartaParaCodcartacr("000072", 5);
		//procesar(solicitudTO, "AUTSOL");
		procesar(solicitudTO, "NOTIFMEFP");		
	}
	//@Test
	public void crearEnmiendaFechaAmpliacionTest() throws Exception {
		log.info("========== crearEnmiendaFechaAmpliacionTest =============");
		iniciarDaos();
		Solicitud solicitudTO = cartasCredService.inicilizaORecuperaEnmiendaFecha("000072", Constants.CLAVE_CCRED_TIPOEMISION_INCREMENTO);
		
		CarCartascr carCartascr = solicitudTO.getCarCartascr();
		//carCartascr.setCcrFechavtopag(UtilsDate.addTime(carCartascr.getCcrFechavtopag(), 30, 5));
		
		CarCartascrdet carCartascrdet = solicitudTO.getCarCartascrdet();		
		carCartascrdet.setCcdFechacargo(UtilsDate.addTime(carCartascr.getCcrFechavtopag(), 55, 5));
		carCartascrdet.setCcdGlosa("prueba enmienda fecha");
		carCartascrdet.setCcdMonto(BigDecimal.valueOf(55500));		
		solicitudTO.getSolicitud().setFechaCont(new Date());
		solicitudTO = procesar(solicitudTO, "REG_CC_PAGOENMI");
		log.info("soliccc " + solicitudTO.getSolicitud().getSocCodigo());
		solicitudTO.getSolicitud().setFechaCont(new Date());
		
		solicitudTO = procesar(solicitudTO, "ACT_A_FECHA");

		procesar(solicitudTO, "PREAUT");
		procesar(solicitudTO, "AUTSOL");
		log.info("hechoooooooooooooooooooooooooooooo");		
	}	
	
	//@Test
	public void crearEnmiendaMontoTest() throws Exception {
		log.info("========== crearEnmiendaMontoTest =============");
		iniciarDaos();
		Solicitud solicitudTO = cartasCredService.inicilizaORecuperaEnmiendaFecha("000061", Constants.CLAVE_CCRED_TIPOEMISION_INCREMENTO);
		
		CarCartascr carCartascr = solicitudTO.getCarCartascr();
		CarCartascrdet carCartascrdet = solicitudTO.getCarCartascrdet();		
		carCartascrdet.setCcdMonto(BigDecimal.valueOf(88000));
		carCartascrdet.setCcdGlosa("prueba enmienda inccremento monto");
		
		solicitudTO = procesar(solicitudTO, "REG_CC_PAGOENMI");
		log.info("soliccc " + solicitudTO.getSolicitud().getSocCodigo());
		solicitudTO.getSolicitud().setFechaCont(new Date());
		
		solicitudTO = procesar(solicitudTO, "ACT_A_FECHA");

		procesar(solicitudTO, "PREAUT");
		procesar(solicitudTO, "AUTSOL");
		log.info("hechoooooooooooooooooooooooooooooo");		
	}
	
	//@Test
	public void crearEnmiendaMontoYFechaTest() throws Exception {
		log.info("========== crearEnmiendaMontoYFechaTest =============");
		iniciarDaos();
		Solicitud solicitudTO = cartasCredService.inicilizaORecuperaEnmiendaFecha("000061", Constants.CLAVE_CCRED_TIPOEMISION_INCREMENTO);
		
		CarCartascr carCartascr = solicitudTO.getCarCartascr();
		CarCartascrdet carCartascrdet = solicitudTO.getCarCartascrdet();		
		carCartascrdet.setCcdMonto(BigDecimal.valueOf(88000));
		carCartascrdet.setCcdFechacargo(UtilsDate.addTime(carCartascr.getCcrFechavtopag(), 30, 5));
		carCartascrdet.setCcdGlosa("prueba enmienda inccremento monto y fecha");
		
		solicitudTO = procesar(solicitudTO, "REG_CC_PAGOENMI");
		log.info("soliccc " + solicitudTO.getSolicitud().getSocCodigo());
		solicitudTO.getSolicitud().setFechaCont(new Date());
		
		solicitudTO = procesar(solicitudTO, "ACT_A_FECHA");

		procesar(solicitudTO, "PREAUT");
		procesar(solicitudTO, "AUTSOL");
		log.info("hechoooooooooooooooooooooooooooooo");		
	}	
	//@Test
	public void preAutoEnmiendaTest() throws Exception {
		log.info("========== preAutoEnmiendaTest =============");
		iniciarDaos();
		Solicitud solicitudTO = cartasCredService.recuperarDatosCartaParaCodcartacr("000059", 5);
		
		solicitudTO = procesar(solicitudTO, "REG_CC_PAGOENMI");
		log.info("soliccc " + solicitudTO.getSolicitud().getSocCodigo());
		solicitudTO.getSolicitud().setFechaCont(new Date());
		solicitudTO = procesar(solicitudTO, "ACT_A_FECHA");

		procesar(solicitudTO, "PREAUT");
		procesar(solicitudTO, "AUTSOL");
		log.info("hechoooooooooooooooooooooooooooooo");		
	}
	
	//@Test
	public void procesarSolicitudProvisionCartaTest() throws Exception {
		log.info("========== procesarSolicitudProvisionCartaTest =============");
		String filexml = "src/test/resources/mensmefp/v10_1482.xml";
		
		iniciarDaos();
		SocSolicitudes socSolicitudes = cargarXMLFromSigepTest(filexml);
		finalizarDaos();
	}
	
	//@Test
	public void inicializarEmisionCartaTest() throws Exception {
		log.info("========== inicializarEmisionCartaTest =============");
		iniciarDaos();
		Solicitud solicitud = cartasCredService.inicilizaORecuperaEmisionCarta("006419");
		
		SocSolicitudes socSolicitudes = solicitud.getSolicitud();
		
		solicitud.setCodUsuarioAudit("199");
		solicitud.setCodPersonaAudit(Constants.COD_BCB);
		solicitud.setCodEstacionAudit("123");
		solicitud.setCodUsuarioCont("190");

		List<SocDetallessol> socDetallessolLista = solicitud.getSocDetallessolLista();
		SocSolicitante socSolicitante = solicitud.getSocSolicitante();
		SocDetallessol socDetallessolSelected = new SocDetallessol();
		
		if (socDetallessolLista.size() > 0)
			socDetallessolSelected = socDetallessolLista.get(0);
		
		CarCartascr carCartascrSelected = solicitud.getCarCartascr();
		List<CarCartascrdet> carCartascrdetLista = solicitud.getCarCartascrdetLista();
		CarCartascrdet carCartascrdetSelected = solicitud.getCarCartascrdet();		
		
		// seteamos valores de carta emision
		carCartascrSelected.setCcrFechaemis(new Date());
		carCartascrSelected.setCcrFechavtopag(UtilsDate.addTime(carCartascrSelected.getCcrFechaemis(), 338, 5));
		carCartascrSelected.setCcrNomexportador("ccrNomexportador");
		carCartascrSelected.setCcrNomimportador("Nomimportador");
		carCartascrSelected.setCcrNomproducto("Nomproducto");
		
		carCartascrdetSelected.setCcdGlosa("registro de emision de carta");
		
		socDetallessolSelected.setBenCodigo(null);
		
		List<Beneficiario> beneficiarios = socBenefsDao.recuperarBeneficiariosSolicitante(socSolicitudes, socDetallessolSelected.getBenCodigo(),
				socSolicitudes.getCodMonedat(), null, false);		
		for (Beneficiario beneficiario : beneficiarios) {
			log.info(beneficiario.getBenNombre());
		}
		List<SocCuentassol> socCuentassolLista = socCuentassolDao.listaByClaveCuenta(Constants.CLAVE_CTA_GARANT_ACREDIT, carCartascrSelected.getCcrCodmontrans());
		for (SocCuentassol socCuentassol : socCuentassolLista) {
			log.info(socCuentassol.getCtaNommovimiento());
		}
		
		socDetallessolSelected.setBenCodigo("001145"); // camc
		socDetallessolSelected.setCodBanco("000434"); // BANK OF CHINA (BEIJING BRANCH)
		
		SocSolicitudctas socSolicitudctasNew = new SocSolicitudctas();
		socSolicitudctasNew.setId(new SocSolicitudctasPK());
		socSolicitudctasNew.getId().setTipoCuenta(Constants.CLAVE_CTA_GARANT_ACREDIT);
		socSolicitudctasNew.setCveTipocomis(Constants.CLAVE_TIPOCOMIS_SOLIC);
		
		socSolicitudctasNew.setCtaAfectable(socCuentassolLista.get(0).getCtaAfectable());
		
		solicitud.setCarCartascr(carCartascrSelected);
		solicitud.setCarCartascrdet(carCartascrdetSelected);
		
		socDetallessolLista = new ArrayList<SocDetallessol>();
		socDetallessolLista.add(socDetallessolSelected);
		solicitud.setSocDetallessolLista(socDetallessolLista);
		
		List<SocSolicitudctas> socSolicitudctasLista = new ArrayList<SocSolicitudctas>();
		socSolicitudctasLista.add(socSolicitudctasNew);
		solicitud.setSocSolicitudctasLista(socSolicitudctasLista);
		
		solicitud = registrarSolicitud.registrarSolicitudCarta(solicitud);
		
		//socDetallessolDao.getHibernateTemplate().evict(socDetallessolSelected);
		//log.info(socDetallessolSelected.getBenCodigo());
		finalizarDaos();		
	}
	
	//@Test
	public void preAutorizarEmisionSolicitudCartaTest() {
		log.info("========== preAutorizarEmisionSolicitudCartaTest =============");
		
		preAutorizarSolicitudCartaTest("006419");
	}

	//@Test
	public void rechazarEmisionSolicitudCartaTest() {
		log.info("========== rechazarEmisionSolicitudCartaTest =============");
		
		rechazarSolicitudCartaTest("006419");
	}

	//@Test
	public void consultasConfirmacionTest() throws Exception {
		log.info("========== consultasConfirmacionTest =============");
//		19217822577424
//		14715430474355
//		16712483369144
//		23621875550727
//		27691929429457
//		27703050988661
//		27733139516540
//		23482942923698
		String filexml = "src/test/resources/mensmefp/c06_2411071383202.xml";
		filexml = "src/test/resources/mensmefp/V01_VARIOS.XML";
		//String newstr = readAndChangeCodsolic(filexml, "6725545754077");

		for(int i=0; i<2; i++) {
			String cod = System.nanoTime() + "";
			String newstr = readAndChangeCodsolic(filexml, cod);			
			enviarXMLSigep(newstr, false);
			if (i%2 == 0) {
				log.info("PPPPPPPPPPPPPPPPPPPPPP");
				filexml = "src/test/resources/mensmefp/V01_VARIOS2.XML";
			} else {
				log.info("IIIIIIIIIIIIIIIIIIIIIIIIII");				
				filexml = "src/test/resources/mensmefp/V01_VARIOS.XML";
			}
		}
		log.info("zzzzzzzzzzzzzzzzzzzzzzzzzzZZZZZZZZZZZZZZZz");
		Thread.sleep(60000);
		//procesarXML(newstr);		
		log.info("hechoooooooooooooooooooooooooooooo");
	}
	
	//@Test
	public void reiniciarTest() throws Exception {
		log.info("========== preAutoEnmiendaTest =============");
		iniciarDaos();
		Solicitud solicitudTO = new Solicitud();
		
		solicitudTO = procesar(solicitudTO, "reiniciarprocesos");
		log.info("hechoooooooooooooooooooooooooooooo");		
	}
	
	public void preAutorizarSolicitudCartaTest(String socCodigo) {
		iniciarDaos();
		Solicitud solicitud = procesosSolicitud.recuperarSolicitudSimple(socCodigo);

		solicitud.setCodUsuarioAudit("199");
		solicitud.setCodPersonaAudit(Constants.COD_BCB);
		solicitud.setCodEstacionAudit("123");
		solicitud.setCodUsuarioCont("190");

		solicitud.getSolicitud().setFechaCont(new Date());
		procesosSolicitud.preAutorizar(solicitud);

		finalizarDaos();		
	}
	
	public void rechazarSolicitudCartaTest(String socCodigo) {
		log.info("========== preAutorizarSolicitudCartaTest =============");
		iniciarDaos();
		Solicitud solicitud = procesosSolicitud.recuperarSolicitudSimple(socCodigo);

		solicitud.setCodUsuarioAudit("199");
		solicitud.setCodPersonaAudit(Constants.COD_BCB);
		solicitud.setCodEstacionAudit("123");
		solicitud.setCodUsuarioCont("190");

		solicitud.getSolicitud().setFechaCont(new Date());
		procesosSolicitud.rechazar(solicitud);

		finalizarDaos();		
	}	
	
	public SocSolicitudes cargarXMLFromSigepTest(String filexml){
		log.info("========== cargarXMLFromSigepTest =============");
		String cod = System.nanoTime() + "";
		String newstr = readAndChangeCodsolic(filexml, cod);
		procesarXML(newstr);
		log.info("hechoooooooooooooooooooooooooooooo");
	
		//iniciarDaos();
		SocSolicitudes socSolicitudes = socSolicitudesDao.getByCodSolicitudorig(cod);
		Assert.assertNotNull("Solicitud inexistente", socSolicitudes);
		log.info("Codigo solicitud " + socSolicitudes.getSocCodigo());
		return socSolicitudes;
	}
	
	public void xMLFromSigepTest(String filexml){
		log.info("========== xMLFromSigepTest =============");
		String cod = System.nanoTime() + "";
		String newstr = readAndChangeCodsolic(filexml, cod);
		procesarXML(newstr);
		log.info("hechoooooooooooooooooooooooooooooo");
	}	
	
	public void iniciarDaos() {
		socDetallessolDao = (SocDetallessolDao) applicationContext.getBean("socDetallessolDao");
		carCartascrDao = (CarCartascrDao) applicationContext.getBean("carCartascrDao");
		carCartascrdetDao = (CarCartascrdetDao) applicationContext.getBean("carCartascrdetDao");
		socSolicitudctasDao = (SocSolicitudctasDao) applicationContext.getBean("socSolicitudctasDao");
		socSolicitudesDao = (SocSolicitudesDao) applicationContext.getBean("socSolicitudesDao");
		socCuentassolDao = (SocCuentassolDao) applicationContext.getBean("socCuentassolDao");
		socOpecomiDao = (SocOpecomiDao) applicationContext.getBean("socOpecomiDao");
		socBenefsDao = (SocBenefsDao) applicationContext.getBean("socBenefsDao");
		procesosSolicitud.setSessionFactory(sessionFactorySioc);
		actualizarAFecha.setSessionFactory(sessionFactorySioc);
		registrarSolicitud.setSessionFactory(sessionFactorySioc);

		cartasCredService = new CartasCredService(sessionFactorySioc, sessionFactoryCoin);

	}
	
	public void iniciarDaosTrans() {
		QueryProcessor.setSessionFactory(sessionFactorySioc);
		SiocCoinService.setSessionFactory(sessionFactoryCoin);
		PortiaService.setSessionFactory(sessionFactoryPortia);

		QueryProcessor.begin();
		SiocCoinService.begin();
	}
	
	public void finalizarDaos() {
		PortiaService.commit();
		SiocCoinService.commit();
		QueryProcessor.commit();
	}
	
}
