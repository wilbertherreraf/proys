package gob.bcb.service.servicioSioc;

import gob.bcb.core.utils.UtilsFile;
import gob.bcb.service.config.BaseClientColas;

import java.io.IOException;

import javax.jms.JMSException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ClientColas extends BaseClientColas {
	private static final Log log = LogFactory.getLog(ClientColas.class);

	public void enviarArchFirmado(String archFirmado) throws JMSException, IOException {
		String mensajeXML = UtilsFile.readFileAsString2(archFirmado);
		String cod = System.nanoTime() + "";
		log.info("Codigo " + cod);
		String newstr = mensajeXML.replaceAll("(<cod_solicitud_origen>)[^&]*(</cod_solicitud_origen>)", "$1" + cod +"$2");
		newstr = mensajeXML.replaceAll("(<cod_solicitud_origen>)[^&]*(</cod_solicitud_origen>)", "$1" + cod +"$2");
		parametrosMsg.put("opcion", "REG_SOLWS");
		parametrosMsg.put(gob.bcb.service.servicioSioc.common.Constants.COD_IFA_REQUEST, gob.bcb.service.servicioSioc.common.Constants.COD_IFA_MEFP);
		parametrosMsg.put("mensajeXML", newstr);

		enviar();
	}

	public static void main(String[] args) {
//		//String str = "212&firstString=4507&endString=asdfff";
//		String str = "adw4345<cod_solicitud_origen>4507</cod_solicitud_origen>asdfg";
//		String newstr = str.replaceAll("(<cod_solicitud_origen>)[^&]*(</cod_solicitud_origen>)", "$1AAAAAA$2");
//		//String newstr = str.replaceAll("(&firstString=)[^&]*(&endString=)", "$1foo$2");
//		System.out.println(str);
//		System.out.println(newstr);		
		
		ClientColas clientColas = new ClientColas();
		clientColas.init();
		try {
			log.info("===============oo000OOinicioOOO000oo===============");			
			//clientColas.enviarArchFirmado("e:/V01_1509012015180756_I.xml");
			//clientColas.enviarArchFirmado("e:/tmp/v01_grande2.xml");
//			clientColas.enviarArchFirmado("e:/tmp/V01_varios.xml");
//			try {
//				Thread.sleep(1700);
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			clientColas.enviarArchFirmado("e:/tmp/V01_01.xml");			
//			clientColas.enviarArchFirmado("e:/tmp/V01_02.xml");
			clientColas.enviarArchFirmado("e:/tmp/V01_03.xml");
			clientColas.enviarArchFirmado("e:/tmp/V01_05.xml");
			clientColas.enviarArchFirmado("e:/tmp/V01_03.xml");
			clientColas.enviarArchFirmado("e:/tmp/V01_05.xml");			
			clientColas.enviarArchFirmado("e:/tmp/V01_05.xml");			
//			clientColas.enviarArchFirmado("e:/tmp/V05_01.xml");
//			clientColas.enviarArchFirmado("e:/tmp/V08_01.xml");
//			clientColas.enviarArchFirmado("e:/tmp/V10_01.xml");
			//clientColas.enviarArchFirmado("e:/tmp/V08ordenpag.xml");
//			clientColas.enviarArchFirmado("e:/tmp/V08ordenpag.xml");			
//			clientColas.enviarArchFirmado("e:/tmp/V01_18_1_E16092015154702_I.xml");			
//			clientColas.enviarArchFirmado("e:/tmp/V02_167_1_E17032015122206_I0.xml");
//			clientColas.enviarArchFirmado("e:/tmp/V08ordenpag.xml");			
//			clientColas.enviarArchFirmado("e:/tmp/V01_18_1_E16092015154702_I0.xml");
//			clientColas.enviarArchFirmado("e:/tmp/V02_167_1_E17032015122206_I1.xml");			
//			clientColas.enviarArchFirmado("e:/tmp/V01_18_1_E16092015154702_I1.xml");			
			//clientColas.enviarArchFirmado("e:/opt/testsiocmsgsigep/V02002.xml");			
			//clientColas.enviarArchFirmado("e:/opt/testsiocmsgsigep/V03001.xml");			
			//clientColas.enviarArchFirmado("e:/opt/testsiocmsgsigep/V04001.xml");			
			//clientColas.enviarArchFirmado("e:/opt/testsiocmsgsigep/V05001.xml");			
			//clientColas.enviarArchFirmado("e:/opt/testsiocmsgsigep/V06001.xml");			
			//clientColas.enviarArchFirmado("e:/opt/testsiocmsgsigep/V08001.xml");			
			//clientColas.enviarArchFirmado("e:/opt/testsiocmsgsigep/T01001.xml");
			//clientColas.enviarArchFirmado("e:/opt/testsiocmsgsigep/T02001.xml");
			log.info("===============oo000OFIIIIIIIIIINOOO000oo===============");			
		} catch (JMSException e) {
			log.error("Error " + e.getMessage());
		} catch (IOException e) {
			log.error("Error 2 " + e.getMessage());
		}
		System.exit(0);
	}
}
