package gob.bcb.service.servicioSioc;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;

import gob.bcb.bpm.pruebaCU.UtilsSioc;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.service.config.BaseDaoTest;
import gob.bcb.service.servicioTres.model.FactorConvMnDao;

public class CoinDaoTest extends BaseDaoTest {
	public void tipoCambio(Date fecha, String codMoneda) {
		FactorConvMnDao factorConvMnDao = (FactorConvMnDao) factoryDaoCoin.getDao("FactorConvMnDao");
		log.info("factorConvMnDao " + (factorConvMnDao == null));
		BigDecimal factor = factorConvMnDao.getTC(Integer.valueOf(codMoneda), fecha);
		log.info("factor " + factor);

	}

	public void conversion(BigDecimal monto, Integer monOrigen, Integer monDestino, Date fechaTc, String debitoAbono) {
		Map<String, Object> montoConvertido = UtilsSioc.conversion(monto, monOrigen, monDestino, fechaTc, debitoAbono);
		log.info("factor " + ArrayUtils.toString(montoConvertido));
	}

	public static void main(String[] args) {
		log.info("inicio testing");
		CoinDaoTest socSolicitudesDaoTest = new CoinDaoTest();
		try {
			socSolicitudesDaoTest.initContext();
			// socSolicitudesDaoTest.SocSolicitudesDaoQuery("1438717567702");
			// socSolicitudesDaoTest.tipoCambio(UtilsDate.dateFromString("2015/08/07",
			// "yyyy/MM/dd"), "53");
			socSolicitudesDaoTest.conversion(BigDecimal.valueOf(1000.00), 69, 34, UtilsDate.dateFromString("2016/01/07", "yyyy/MM/dd"), "C");
			socSolicitudesDaoTest.conversion(BigDecimal.valueOf(888.00), 69, 34, UtilsDate.dateFromString("2016/01/07", "yyyy/MM/dd"), "V");
			log.info("cerrandoaaaaaaaaa");
			socSolicitudesDaoTest.applicationContext.stop();

			log.info("cerrando");
		} catch (Exception e) {
			log.error("XXX: " + e.getMessage(), e);
		} finally {
			log.info("cerrando");
			socSolicitudesDaoTest.applicationContext.close();

		}
	}

}
