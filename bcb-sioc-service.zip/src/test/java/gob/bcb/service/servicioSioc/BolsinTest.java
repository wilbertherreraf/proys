package gob.bcb.service.servicioSioc;

import gob.bcb.bpm.pruebaCU.QueryProcessor;
import gob.bcb.bpm.pruebaCU.SocBolsin;
import gob.bcb.bpm.pruebaCU.SocBolsinDao;
import gob.bcb.core.jms.BcbRequestImpl;
import gob.bcb.core.jms.StatusResponse;
import gob.bcb.core.jms.client.MessageObjectBean;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.service.config.BaseEnviarMsgTest;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BolsinTest extends BaseEnviarMsgTest {
	public SocBolsin nuevo(String solCodigo, Integer cuentaD, BigDecimal montoSol, String benef) {
		SocBolsin solicitudB = new SocBolsin();
		solicitudB.setSolCodigo(solCodigo);
		solicitudB.setFecha(new Date());
		solicitudB.setCorr(solCodigo);
		solicitudB.setSeq(1);
		solicitudB.setCuentaD(12);
		solicitudB.setCotiz(BigDecimal.valueOf(6.96));
		solicitudB.setMontoSol(BigDecimal.valueOf(100000));
		solicitudB.setMontoAdj(BigDecimal.valueOf(0.00));
		solicitudB.setMontoMN(solicitudB.getMontoSol().multiply(solicitudB.getCotiz()).setScale(2, BigDecimal.ROUND_HALF_UP));
		solicitudB.setClaEstado('9');
		solicitudB.setBenef(benef);
		solicitudB.setClaTipsolic("E");
		solicitudB.setBolCtamn(null);
		solicitudB.setBolCtame(null);
		solicitudB.setUsrCodigo("YOP");
		solicitudB.setFechaHora(new Date());
		solicitudB.setEstacion("ricochango");

		return solicitudB;
	}

	public SocBolsin nuevo(String socCodigo) {
		SocBolsin solicitudB = new SocBolsin();
		solicitudB.setSocCodigo(socCodigo);
		return solicitudB;

	}

	public BcbRequestImpl autBolsinTest(String socCodigo) {
		Map<String, Object> mapaRespuesta = new HashMap<String, Object>();

		SocBolsin solicitudB2 = nuevo(socCodigo);
		
		Map<String, Object> parametrosMsg = new HashMap<String, Object>();		
		parametrosMsg.put("opcion", "autBolsin");
		parametrosMsg.put("solicitud", solicitudB2);
		BcbRequestImpl bcbRequestImpl = crearObjetoMensaje((String) parametrosMsg.get("opcion"), parametrosMsg);
		bcbRequestImpl.setDisableReplyTo(true);
		//StatusResponse statusResponse = bcbRequestImpl.sendMessage();
		//
		// if (statusResponse != null && statusResponse.getResponse() instanceof
		// MessageObjectBean) {
		// MessageObjectBean messageObjectBean1 = (MessageObjectBean)
		// statusResponse.getResponse();
		// mapaRespuesta = (Map<String, Object>)
		// messageObjectBean1.getTransformedMessage();
		// String codSol = (String) mapaRespuesta.get("estado");
		// System.out.println("estado =  " + codSol);
		// } else {
		// System.out.println(statusResponse.getDescrip());
		// }
		return bcbRequestImpl;
	}

	public void nuevoBolsinTest() {
		Map<String, Object> mapaRespuesta = new HashMap<String, Object>();

		SocBolsin solicitudB = nuevo("903", 12, BigDecimal.valueOf(100000), "903-000106");
		getParametrosMsg().put("opcion", "nuevaBolsin");
		getParametrosMsg().put("solicitud", solicitudB);
		BcbRequestImpl bcbRequestImpl = crearObjetoMensaje((String) getParametrosMsg().get("opcion"), getParametrosMsg());
		bcbRequestImpl.setDisableReplyTo(true);
		StatusResponse statusResponse = bcbRequestImpl.sendMessage();

//		String codSol = "";
//		if (statusResponse != null && statusResponse.getResponse() instanceof MessageObjectBean) {
//			MessageObjectBean messageObjectBean1 = (MessageObjectBean) statusResponse.getResponse();
//			mapaRespuesta = (Map<String, Object>) messageObjectBean1.getTransformedMessage();
//			codSol = (String) mapaRespuesta.get("codSolicitud");
//			System.out.println("codSol =  " + codSol);
//		} else {
//			System.out.println(statusResponse.getDescrip());
//		}
	}
	public void consultaBolsinTest(){
		SocBolsinDao socBolsinDao = new SocBolsinDao();
		socBolsinDao.setSessionFactory(QueryProcessor.getSessionFactory());
		List<SocBolsin> socBolsinLista = socBolsinDao.getByEstadoFecha(UtilsDate.dateFromString("21/04/2015", "dd/MM/yyyy"), "5", "'ED','E'");
		for (SocBolsin socBolsin : socBolsinLista) {
			System.out.println(socBolsin.getSocCodigo());
		}
	}
	public BcbRequestImpl subastaBolsinTest(){
		SocBolsinDao socBolsinDao = new SocBolsinDao();
		socBolsinDao.setSessionFactory(QueryProcessor.getSessionFactory());
		List<SocBolsin> socBolsinLista = socBolsinDao.getByEstadoFecha(UtilsDate.dateFromString("22/04/2015", "dd/MM/yyyy"), "5", "'ED','E'");
		
		Map<String, Object> parametrosMsg = new HashMap<String, Object>();		
		parametrosMsg.put("opcion", "subasta");
		parametrosMsg.put("solicitudes", socBolsinLista);
		parametrosMsg.put("base", BigDecimal.valueOf(6.86));		
		BcbRequestImpl bcbRequestImpl = crearObjetoMensaje((String) parametrosMsg.get("opcion"), parametrosMsg);
		bcbRequestImpl.setDisableReplyTo(true);
		bcbRequestImpl.sendMessage();
		
		return bcbRequestImpl;
	}
	public BcbRequestImpl sinsubastaBolsinTest(){
		SocBolsinDao socBolsinDao = new SocBolsinDao();
		socBolsinDao.setSessionFactory(QueryProcessor.getSessionFactory());
		List<SocBolsin> socBolsinLista = socBolsinDao.getByEstadoFecha(UtilsDate.dateFromString("22/04/2015", "dd/MM/yyyy"), "5", "'ED','E'");
		
		Map<String, Object> parametrosMsg = new HashMap<String, Object>();		
		parametrosMsg.put("opcion", "sinSubasta");
		parametrosMsg.put("solicitudes", socBolsinLista);
		parametrosMsg.put("base", BigDecimal.valueOf(6.86));		
		BcbRequestImpl bcbRequestImpl = crearObjetoMensaje((String) parametrosMsg.get("opcion"), parametrosMsg);
		bcbRequestImpl.setDisableReplyTo(true);
		bcbRequestImpl.sendMessage();
		
		return bcbRequestImpl;
	}
	
	public static void main(String[] args) {
		BolsinTest bolsinTest = new BolsinTest();
		bolsinTest.initContext();
		bolsinTest.nuevoBolsinTest();
//		BcbRequestImpl bcbRequestImpl00 = bolsinTest.autBolsinTest("1429676246438");
//		bcbRequestImpl00.sendMessage();
//		BcbRequestImpl bcbRequestImpl0 = bolsinTest.autBolsinTest("1429590023916");
//		BcbRequestImpl bcbRequestImpl1 = bolsinTest.autBolsinTest("1429590455066");
//		bolsinTest.nuevoBolsinTest();
//		BcbRequestImpl bcbRequestImpl2 = bolsinTest.autBolsinTest("1429590455187");
//		BcbRequestImpl bcbRequestImpl3 = bolsinTest.autBolsinTest("1429591638733");
//		bolsinTest.nuevoBolsinTest();
//		bcbRequestImpl2.sendMessage();
//		bolsinTest.nuevoBolsinTest();
//		bcbRequestImpl1.sendMessage();
//		bcbRequestImpl0.sendMessage();
//		bolsinTest.nuevoBolsinTest();
//		bcbRequestImpl3.sendMessage();
//		bolsinTest.consultaBolsinTest();
		bolsinTest.subastaBolsinTest();
		//bolsinTest.sinsubastaBolsinTest();
		System.out.println("==========================FIN MENSAJE RECIBIDO==========================");
		System.exit(0);
	}
}
