package gob.bcb.service.servicioSioc;

import java.util.List;

import gob.bcb.bpm.pruebaCU.Beneficiario;
import gob.bcb.bpm.pruebaCU.SocBenefsDao;
import gob.bcb.bpm.pruebaCU.SocCuentassol;
import gob.bcb.bpm.pruebaCU.SocCuentassolDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.SocSolicitudesDao;
import gob.bcb.service.config.BaseDaoTest;

public class SocCuentassolDaoTest extends BaseDaoTest {
	public void ctasSolicitante(String codSoli) {
		SocCuentassolDao socCuentassolDaoLocal = (SocCuentassolDao) factoryDao.getDao("socCuentassolDao");
		List<SocCuentassol> SocCuentassolLista = socCuentassolDaoLocal.ctasSolicitante(codSoli, null, null, 69, null, null, null);
		for (SocCuentassol socCuentassol : SocCuentassolLista) {
			log.info("solicitud " + socCuentassol.toString());
		}

	}
	
	public void registrarcuentas(String codSolicitud) {
		SocSolicitudesDao socSolicitudesDao = (SocSolicitudesDao) factoryDao.getDao("socSolicitudesDao");
		SocSolicitudes socSolicitudes = socSolicitudesDao.getSolicitud(codSolicitud);
		
		
	}
	public void recuperarBeneficiariosSolicitante(String codSolicitud) {
		SocSolicitudes socSolicitudes = new SocSolicitudes();
		socSolicitudes.setSocCodigo("000063");
		socSolicitudes.setCveSubtipooper("TE");
		socSolicitudes.setSolCodigo("500	");
		
		SocBenefsDao socBenefsDao = (SocBenefsDao) factoryDao.getDao("socBenefsDao");
		List<Beneficiario> beneficiarios = socBenefsDao.recuperarBeneficiariosSolicitante(socSolicitudes, "", null, null, false);
		log.info("beneficiarios " + beneficiarios.size());
		
	}
	public static void main(String[] args) {
		SocCuentassolDaoTest socSolicitudesDaoTest = new SocCuentassolDaoTest();
		try {
			socSolicitudesDaoTest.initContext();
			//socSolicitudesDaoTest.ctasSolicitante("913");
			socSolicitudesDaoTest.recuperarBeneficiariosSolicitante("913");
			socSolicitudesDaoTest.applicationContext.stop();
			
		} catch (Exception e) {
			log.error("XXX: " + e.getMessage(), e);
		} finally {
			log.info("cerrando");
			socSolicitudesDaoTest.applicationContext.close();
		}
	}
}
