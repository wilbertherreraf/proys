package gob.bcb.service.config;

import gob.bcb.bpm.pruebaCU.FactoryDao;
import gob.bcb.core.jms.BcbRequestImpl;
import gob.bcb.core.jms.client.JMSConnectionHandler;
import gob.bcb.core.jms.client.MessageObjectBean;
import gob.bcb.core.utils.UtilsProperties;
import gob.bcb.service.commons.ConfigurationServ;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.jms.Connection;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.SessionFactory;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class BaseDaoTest {
	protected static final Log log = LogFactory.getLog(BaseDaoTest.class);
	protected FileSystemXmlApplicationContext applicationContext;
	protected FactoryDao factoryDao;
	protected FactoryDao factoryDaoCoin;
	protected SessionFactory sessionFactorySioc;
	protected SessionFactory sessionFactoryPortia;	
	protected SessionFactory sessionFactoryBeanSiocCoin;
	protected SessionFactory sessionFactory;
	
	private String brokerUrl = "tcp://10.2.11.91:61616";
	// private String brokerUrl = "tcp://localhost:61616";
	private String requestQueue = "BCB.SUSTANTIVO.BPM.SIOC.QUEUE";

	private Connection connection;
	private Map<String, Object> parametrosMsg = new HashMap<String, Object>();
	private MessageObjectBean messageObjectBean = new MessageObjectBean();
	private Map<String, Object> parametros = new HashMap<String, Object>();
	
	public void initContext() {
		Properties properties = UtilsProperties.loadFilePropertiesFromClass("service.properties");
		String pathHome = properties.getProperty("path.home");
		if (!pathHome.startsWith("e:")) {
			pathHome = "e:".concat(pathHome);
		}
		ConfigurationServ.setServiceName(properties.getProperty("service.name"));

		ConfigurationServ.setHomeProperty(pathHome);
		ConfigurationServ.init(pathHome);

		brokerUrl = ConfigurationServ.getConfigProperty("jms.broker.url");
		gob.bcb.core.jms.Constants.setUrlBroker(brokerUrl);
		
		String[] appContextList = { "classpath:applicationcontextSioc.xml", 
				"classpath:applicationcontextSiocCoin.xml","classpath:applicationcontextPortia.xml"};

		applicationContext= new FileSystemXmlApplicationContext(appContextList);
		factoryDao = (FactoryDao) applicationContext.getBean("factoryDao");
		factoryDaoCoin= (FactoryDao) applicationContext.getBean("factoryDaoSiocCoin");
		sessionFactorySioc = (SessionFactory) applicationContext.getBean("sessionFactoryBean");
		sessionFactoryPortia = (SessionFactory) applicationContext.getBean("sessionFactoryBeanPortia");
		sessionFactoryBeanSiocCoin = (SessionFactory) applicationContext.getBean("sessionFactoryBeanSiocCoin");
		sessionFactory = factoryDao.getSessionFactory();
	}

	public BcbRequestImpl crearObjetoMensaje(String opcion, Map<String, Object> parametrosMs) {
		MessageObjectBean messageObjectBea = new MessageObjectBean();
		messageObjectBea.setTransformedMessage(parametrosMs);
		String usuarioTask = "wherrera";//Servicios.getParam("usuarioTask");
		usuarioTask = "1653";//Servicios.getParam("usuarioTask");
		BcbRequestImpl bcbRequestImpl = null;
		JMSConnectionHandler jMSConnectionHandler = new JMSConnectionHandler(brokerUrl);
		parametros.put("BCBAddress", "visit.getAddress()" + (Math.random()+100));
		parametros.put("BCBIdemisor", "SIOCWS");
		parametros.put("BCBIddestinatario", requestQueue);
		parametros.put("BCBIdusuario", usuarioTask);
		parametros.put("BCBPasswmd5", ">>>1234<<<");
		parametros.put("BCBIdsistema", "SIOCWS");
		parametros.put("BCBIdoperacion", opcion);
		bcbRequestImpl = (BcbRequestImpl) BcbRequestImpl.newInstance((String) parametros.get("BCBAddress"), (String) parametros.get("BCBIdemisor"),
				(String) parametros.get("BCBIddestinatario"), (String) parametros.get("BCBIdsistema"), (String) parametros.get("BCBIdoperacion"),
				null, (String) parametros.get("BCBIdusuario"), (String) parametros.get("BCBPasswmd5"), null, null);
		bcbRequestImpl.setNameQueueTopic((String) parametros.get("BCBIddestinatario"));
		bcbRequestImpl.setBody(messageObjectBea);
		bcbRequestImpl.setJMSConnectionHandler(jMSConnectionHandler);
		bcbRequestImpl.setDisableReplyTo(true);

		return bcbRequestImpl;
	}

	public Map<String, Object> getParametrosMsg() {
		return parametrosMsg;
	}

	public void setParametrosMsg(Map<String, Object> parametrosMsg) {
		this.parametrosMsg = parametrosMsg;
	}
	
}
