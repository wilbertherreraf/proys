package gob.bcb.service.config;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.jms.JMSException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import gob.bcb.bpm.pruebaCU.Servicios;
import gob.bcb.core.jms.BcbRequestImpl;
import gob.bcb.core.jms.BcbResponseImpl;
import gob.bcb.core.jms.ResponseContext;
import gob.bcb.core.jms.StatusResponse;
import gob.bcb.core.jms.client.JMSConnectionHandler;
import gob.bcb.core.jms.client.MessageObjectBean;
import gob.bcb.core.utils.UtilsProperties;
import gob.bcb.service.commons.ConfigurationServ;
import gob.bcb.service.servicioSioc.SeverMainSioc;

public class BaseServerColas {
	private static final Log log = LogFactory.getLog(BaseServerColas.class);	
	Map<String, Object> parametros = new HashMap<String, Object>();
	MessageObjectBean messageObjectBean = new MessageObjectBean();
	BaseDaoTest baseDaoTest = new BaseDaoTest();
	protected String brokerUrl = "tcp://10.2.11.91:61616";
	// private String brokerUrl = "tcp://localhost:61616";
	protected String requestQueue = "BCB.SUSTANTIVO.BPM.SIOC.QUEUE";
	
	public BcbRequestImpl crearBcbRequestImpl(String opcion, Map<String, Object> parametrosMs) {
		MessageObjectBean messageObjectBea = new MessageObjectBean();
		messageObjectBea.setTransformedMessage(parametrosMs);
		String usuarioTask = "wherrera";//Servicios.getParam("usuarioTask");
		usuarioTask = "1653";//Servicios.getParam("usuarioTask");
		brokerUrl = gob.bcb.core.jms.Constants.getUrlBroker();
		log.info("brokerUrl " + brokerUrl);
		BcbRequestImpl bcbRequestImpl = null;
		
		ConfigurationServ.initConnectionFactory(null);		
		JMSConnectionHandler jMSConnectionHandler = new JMSConnectionHandler(ConfigurationServ.getConnectionFactory());
		
		parametros.put("BCBAddress", "visit.getAddress()" + (Math.random()+100));
		parametros.put("BCBIdemisor", "SIOCWS");
		parametros.put("BCBIddestinatario", requestQueue);
		parametros.put("BCBIdusuario", usuarioTask);
		parametros.put("BCBPasswmd5", ">>>1234<<<");
		parametros.put("BCBIdsistema", "SIOCWS");
		parametros.put("BCBIdoperacion", opcion);
		bcbRequestImpl = (BcbRequestImpl) BcbRequestImpl.newInstance((String) parametros.get("BCBAddress"), (String) parametros.get("BCBIdemisor"),
				(String) parametros.get("BCBIddestinatario"), (String) parametros.get("BCBIdsistema"), (String) parametros.get("BCBIdoperacion"),
				null, (String) parametros.get("BCBIdusuario"), (String) parametros.get("BCBPasswmd5"), null, null);
		bcbRequestImpl.setNameQueueTopic((String) parametros.get("BCBIddestinatario"));
		bcbRequestImpl.setBody(messageObjectBea);
		bcbRequestImpl.setJMSConnectionHandler(jMSConnectionHandler);
		bcbRequestImpl.setDisableReplyTo(true);

		return bcbRequestImpl;
	}
	
	public static void main(String[] args) {
		SeverMainSioc.initConfig();
		BaseServerColas baseServerColas = new BaseServerColas();
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("opcion","obtenerTC");
		BcbRequestImpl bcbRequestImpl = baseServerColas.crearBcbRequestImpl("obtenerTC", parametros);
		bcbRequestImpl.setDisableReplyTo(false);
		
		SeverMainSioc.main(null);
		boolean state = SeverMainSioc.getInstance().getServerService().isStarted();
		log.info("estado " + state);
		bcbRequestImpl.sendPingRequest();		
		log.info("pooooooooooost ping 11111111111111");
		bcbRequestImpl = baseServerColas.crearBcbRequestImpl("obtenerTC", parametros);
		bcbRequestImpl.setDisableReplyTo(false);		
		StatusResponse statusResponse = bcbRequestImpl.sendMessage();
		
		state = SeverMainSioc.getInstance().getServerService().isStarted();
		log.info("estado " + state);		
		SeverMainSioc.getInstance().getServerService().stop();
		log.info("===========================saliendo======================");

		bcbRequestImpl = baseServerColas.crearBcbRequestImpl("obtenerTC", parametros);
		bcbRequestImpl.setDisableReplyTo(false);
		bcbRequestImpl.sendPingRequest();
		statusResponse = bcbRequestImpl.sendMessage();
		log.info("despues 2do ping");		
		SeverMainSioc.getInstance().getServerService().stop();
	}
}
