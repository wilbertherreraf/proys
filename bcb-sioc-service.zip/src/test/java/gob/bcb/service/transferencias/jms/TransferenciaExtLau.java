package gob.bcb.service.transferencias.jms;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Assert;
import org.junit.Test;

import gob.bcb.bpm.pruebaCU.QueryProcessor;
import gob.bcb.bpm.pruebaCU.SocBenefsDao;
import gob.bcb.bpm.pruebaCU.SocCuentassolDao;
import gob.bcb.bpm.pruebaCU.SocDetallessolDao;
import gob.bcb.bpm.pruebaCU.SocOpecomi;
import gob.bcb.bpm.pruebaCU.SocOpecomiDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudctas;
import gob.bcb.bpm.pruebaCU.SocSolicitudctasDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.SocSolicitudesDao;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.service.config.BaseData;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioPortiaSwift.PortiaService;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.logic.ActualizarAFecha;
import gob.bcb.service.servicioSioc.logic.ProcesosSolicitud;
import gob.bcb.service.servicioSioc.logic.RegistrarSolicitud;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;

public class TransferenciaExtLau extends BaseData {
	private static final Log log = LogFactory.getLog(TransferenciaExtLau.class);
	private SocSolicitudesDao socSolicitudesDao;
	private SocDetallessolDao socDetallessolDao;
	private SocSolicitudctasDao socSolicitudctasDao;
	private SocBenefsDao socBenefsDao;
	private ProcesosSolicitud procesosSolicitud = new ProcesosSolicitud();
	private SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
	private RegistrarSolicitud registrarSolicitud = new RegistrarSolicitud();
	private SocOpecomiDao socOpecomiDao;
	private ActualizarAFecha actualizarAFecha = new ActualizarAFecha();
	
	//@Test
	public void cargarXMLFromSigepTest(){
		log.info("========== cargarXMLFromSigepTest =============");
		String filexml = "src/test/resources/mensmefp/t01_512.xml";
		iniciarDaos();
		SocSolicitudes socSolicitudes = cargarXMLFromSigepTest(filexml);
	}	

	@Test
	public void actualizarAfechaSolicitudTest() {
		log.info("========== actualizarAfechaSolicitudTest =============");
		iniciarDaos();		
		actualizarAFechaTest("006608");
		//rechazarTest("006491");
	}
	
	//@Test
	public void preautorizarSolicitudTest() {
		log.info("========== preautorizarSolicitudTest =============");
		iniciarDaos();		
		preautorizarTest("012992");
		//rechazarTest("006491");
	}
	
	//@Test
	public void autorizarSolicitudTest() {
		log.info("========== autorizarSolicitudTest =============");
		iniciarDaos();		
		autorizarTest("012992");
	}
	
	public void actualizarAFechaTest(String socCodigo) {
		log.info("========== actualizarAFechaTest =============");
		Date fecha = new Date();		
		Solicitud solicitudTO = populateSolicitudTO(socCodigo);
		solicitudTO.getSolicitud().setFechaCont(fecha);		
		solicitudTO = procesar(solicitudTO, "ACT_A_FECHA");
		if (StringUtils.isBlank(solicitudTO.getSolicitud().getSocCodigo())) {
			throw new BusinessException("El servicio no retorna el codigo de la solicitud");
		}

		log.info("Fin preautorizarSolicitudTest " + solicitudTO.getSolicitud().getSocCodigo());
	}	
	public void preautorizarTest(String socCodigo) {
		log.info("========== preautorizarTest =============");
		Solicitud solicitudTO = populateSolicitudTO(socCodigo);
		solicitudTO = procesar(solicitudTO, "REG_SOLICITUD");
		if (StringUtils.isBlank(solicitudTO.getSolicitud().getSocCodigo())) {
			throw new BusinessException("El servicio no retorna el codigo de la solicitud");
		}
		Date fecha = new Date();
		solicitudTO.getSolicitud().setFechaCont(fecha);
		solicitudTO = procesar(solicitudTO, "PREAUT");
		log.info("Fin preautorizarSolicitudTest " + solicitudTO.getSolicitud().getSocCodigo());
	}

	public void autorizarTest(String socCodigo) {
		log.info("========== autorizarTest =============");
		Solicitud solicitudTO = populateSolicitudTO(socCodigo);
		if (solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)) {
			procesar(solicitudTO, "AUTSWFT");
		}
		procesar(solicitudTO, "AUTSOL");

		log.info("Fin autorizarTest " + solicitudTO.getSolicitud().getSocCodigo());
	}
	
	public void rechazarTest(String socCodigo) {
		log.info("========== rechazarTest =============");
		Solicitud solicitudTO = populateSolicitudTO(socCodigo);
		procesar(solicitudTO, "RECHAZARSOL");

		log.info("Fin rechazarTest " + solicitudTO.getSolicitud().getSocCodigo());
	}
	
	private Solicitud populateSolicitudTO(String socCodigo) {
		Solicitud solicitudTO = procesosSolicitud.recuperarSolicitudSimple(socCodigo);
		SocSolicitudes socSolicitudes = solicitudTO.getSolicitud();
		
		solicitudTO.setsIOCWEB_TIPOPERACION("preauto");

		List<SocSolicitudctas> socSolicitudctasLista = socSolicitudctasDao.getCuentas(socCodigo);
		
		solicitudTO.setSocSolicitudctasLista(socSolicitudctasLista);
		List<SocOpecomi> socOpecomiLista = socOpecomiDao.getByCveTipocomis(socSolicitudes.getSocCodigo(), 0,
				null, "F");
		solicitudTO.setSocOpecomiLista(socOpecomiLista);

		return solicitudTO;
	}
	
	public SocSolicitudes cargarXMLFromSigepTest(String filexml){
		log.info("========== cargarXMLFromSigepTest =============");
		String cod = System.nanoTime() + "";
		String newstr = readAndChangeCodsolic(filexml, cod);
		procesarXML(newstr);
		log.info("hechoooooooooooooooooooooooooooooo");
	
		//iniciarDaos();
		SocSolicitudes socSolicitudes = socSolicitudesDao.getByCodSolicitudorig(cod);
		Assert.assertNotNull("Solicitud inexistente", socSolicitudes);
		log.info("Codigo solicitud " + socSolicitudes.getSocCodigo());
		return socSolicitudes;
	}	
	
	public void iniciarDaos() {
		socDetallessolDao = (SocDetallessolDao) applicationContext.getBean("socDetallessolDao");
		socSolicitudctasDao = (SocSolicitudctasDao) applicationContext.getBean("socSolicitudctasDao");
		socSolicitudesDao = (SocSolicitudesDao) applicationContext.getBean("socSolicitudesDao");
		socCuentassolDao = (SocCuentassolDao) applicationContext.getBean("socCuentassolDao");
		socOpecomiDao = (SocOpecomiDao) applicationContext.getBean("socOpecomiDao");
		socBenefsDao = (SocBenefsDao) applicationContext.getBean("socBenefsDao");
		procesosSolicitud.setSessionFactory(sessionFactorySioc);
		actualizarAFecha.setSessionFactory(sessionFactorySioc);
		registrarSolicitud.setSessionFactory(sessionFactorySioc);
	}
	
	public void iniciarDaosTrans() {
		QueryProcessor.setSessionFactory(sessionFactorySioc);
		SiocCoinService.setSessionFactory(sessionFactoryCoin);
		PortiaService.setSessionFactory(sessionFactoryPortia);

		QueryProcessor.begin();
		SiocCoinService.begin();
	}
	
	public void finalizarDaos() {
		PortiaService.commit();
		SiocCoinService.commit();
		QueryProcessor.commit();
	}
}
