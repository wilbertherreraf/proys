package gob.bcb.swift;

import java.util.Date;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.prowidesoftware.swift.io.ConversionService;
import com.prowidesoftware.swift.io.IConversionService;
import com.prowidesoftware.swift.model.SwiftBlock1;
import com.prowidesoftware.swift.model.SwiftBlock2Output;
import com.prowidesoftware.swift.model.SwiftBlock3;
import com.prowidesoftware.swift.model.SwiftBlock4;
import com.prowidesoftware.swift.model.SwiftMessage;
import com.prowidesoftware.swift.model.Tag;
import com.prowidesoftware.swift.model.field.Field32A;
import com.prowidesoftware.swift.model.field.Field58D;
import com.prowidesoftware.swift.model.field.Field72;
import com.prowidesoftware.swift.model.field.SwiftParseUtils;
import com.prowidesoftware.swift.model.mt.mt2xx.MT202;

import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocDetallessolDao;
import gob.bcb.bpm.pruebaCU.SocMensajesDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.SocSolicitudesDao;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.service.config.BaseDaoTest;
import gob.bcb.service.servicioSioc.logic.ProcesosSolicitud;
import gob.bcb.service.servicioSioc.logic.SwiftSiocService;

public class SwiftPru extends BaseDaoTest {
	public static void crear01() {
		IConversionService srv = new ConversionService();
		SwiftMessage msg = new SwiftMessage();

		SwiftBlock4 b4 = new SwiftBlock4();
		MT202 mT202 = new MT202();
		Field32A f = new Field32A("090801USD1234,56");
		Field58D f53B = new Field58D();
		f53B.setComponent1("28020663657");
		f53B.setNameAndAddressLine1("BARCLAYS\nBANK PLC");
		// f53B.setComponent2("BARCLAYS BANK PLC");
		// f53B.setComponent3("MIAMI,FL");
		// Field72 f72 = new
		// Field72("/ACC/AG:3357-X EMPRESARIAL ABC SUL //SAO BERNARDO DO CAMPO //SAO PAULO BR");
		Field72 f72 = new Field72();
		f72.setComponent1(" EMPRESARIAL ABC SUL  EMPRESARIAL ABC  EMPRESARIAL ABC  EMPRESARIAL ABC  EMPRESARIAL ABC ");
		System.out.println("f72.getValue() " + f72.getValue());
		String ln = System.getProperty("line.separator");
		int j = "asdfade".lastIndexOf(ln);
		System.out.println(j);

		SwiftBlock1 b1 = new SwiftBlock1();

		b1.setApplicationId("F");
		b1.setServiceId("01");
		b1.setLogicalTerminal("BICFOOYYAXXX");
		b1.setSessionNumber("1234");
		b1.setSequenceNumber("123456");

		msg.setBlock1(b1);
		msg.setBlock2(new SwiftBlock2Output("O1030831051017BICFUUYYAXXX10194697810510170831N"));
		msg.setBlock3(new SwiftBlock3());
		msg.getBlock3().addTag(new Tag("113:NOMT"));
		msg.getBlock3().addTag(new Tag("108", "P22ABCD43C6J3XYZ"));
		msg.setBlock4(b4);
		msg.getBlock4().add(f);
		msg.getBlock4().add(f53B);
		msg.getBlock4().add(f72);
		mT202.setSwiftMessage(msg);
		String fin = srv.getFIN(msg);
		System.out.println(fin);

		java.util.List<String> lines = SwiftParseUtils.getLines("/485000121UNITED NATIONS ECONOMIC COMISSIONFOR LATIN AMERICA AND THE CARIBBEAN");
		System.out.println("lines " + lines.size());
		for (String string : lines) {
			System.out.println(string);
		}
	}

	public void genmensaje() {
		SocMensajesDao socMensajesDao = (SocMensajesDao) factoryDao.getDao("socMensajesDao");
		
		SocSolicitudesDao socSolicitudesDao = (SocSolicitudesDao) factoryDao.getDao("socSolicitudesDao");
		SocSolicitudes socSolicitudes = socSolicitudesDao.getSolicitud("000056");
		
		SocDetallessolDao socDetallessolDao = (SocDetallessolDao) factoryDao.getDao("socDetallessolDao");
		SocDetallessol socDetallessol = socDetallessolDao.getDetalle(socSolicitudes.getSocCodigo(), 1);
		
		ProcesosSolicitud procesosSolicitud = new ProcesosSolicitud();
		procesosSolicitud.setSessionFactory(sessionFactorySioc);
		Solicitud solicitud = procesosSolicitud.recuperarSolicitudSimple(socSolicitudes.getSocCodigo());
		solicitud.getSolicitud().setFechaCont(new Date());
		
		SwiftSiocService swiftSiocService = new SwiftSiocService();
		swiftSiocService.setSessionFactory(sessionFactorySioc);
		swiftSiocService.generarMensSwift(solicitud);

	}

	public static void pat() {
		// String to be scanned to find the pattern.
		String line = "This order was placed for QT3000! OK?";
		String PARSER_PATTERN = "[[/c][/S]$]S[$S]0-3";
		PARSER_PATTERN = "(\\S+)/$";
		PARSER_PATTERN = "([\\S+]{1,5}\\s[\\S+]{0,})";
		PARSER_PATTERN = "([a-zA-Z]{1,5}\\s+)([a-zA-Z]{0,5}\\s+)";
		PARSER_PATTERN = "^(([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,2}){1,1})*$";
		line = "yyyyy@c022.a.asdfed.ttt.u.tyyydd.ettt.wwww.as.fa";
		// Create a Pattern object
		Pattern r = Pattern.compile(PARSER_PATTERN);
		// Now create matcher object.
		Matcher m = r.matcher(line);
		if (m.matches()) {
			System.out.println("Found value: " + m.group(0));
			System.out.println("Found value1: " + m.group(1));
			System.out.println("Found value2: " + m.group(2));
			System.out.println("Found value3: " + m.group(3));
		} else {
			System.out.println("NO MATCH");
		}
	}
	public static void main(String[] args) {
		log.info("inicio testing");
		SwiftPru swiftPruTest = new SwiftPru();
		try {
			swiftPruTest.initContext();
			swiftPruTest.genmensaje();
			log.info("cerrandoaaaaaaaaa");
			swiftPruTest.applicationContext.stop();

			log.info("cerrando");
		} catch (Exception e) {
			log.error("XXX: " + e.getMessage(), e);
		} finally {
			log.info("cerrando");
			swiftPruTest.applicationContext.close();

		}
	}
}
