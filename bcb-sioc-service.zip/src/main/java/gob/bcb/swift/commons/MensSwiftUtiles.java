package gob.bcb.swift.commons;

import gob.bcb.core.utils.StringFormat;
import gob.bcb.core.utils.UtilsGeneric;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.UnhandledException;

import com.prowidesoftware.swift.model.field.SwiftParseUtils;

public class MensSwiftUtiles {
	public static int MAX_LINE_CHARS = 35;
	public static String EOF = "@EOF@";
	
	 public static int validarConcepto(String concepto) {
		int valid = 0;
        int i = 0;

        do {
               char c = concepto.charAt(i);

               if (Character.isDigit(c))
                      valid++;
           else if (Character.isUpperCase(c)) {
                      if (c != 'Á' && c != 'É' && c != 'Í' && c != 'Ó' && c != 'Ú' && c != 'Ñ')
                             valid++;
                      else
                             valid = -1;
               } else if (Character.isLowerCase(c)) {
                      if (c != 'á' && c != 'é' && c != 'í' && c != 'ó' && c != 'ú' && c != 'ñ')
                             valid++;
                      else
                             valid = -1;
               } else if (c == '/' || c == '(' || c == ')' || c == '?' || c == '+' || c == '-' || c == '.' || c == ',' || c == ':' || c == '\''
                             || c == ' ')
                      valid++;
               else
                      valid = -1;
               i++;
        } while (valid > 0 && i < concepto.length());

        return valid;

       }

	public static String formatoLinea(String textoOri, int numLinea, String cadenaInicio, boolean conCadInicio) {
		int cantCarateres = 34;

		textoOri = (!StringUtils.isBlank(textoOri) ? textoOri.trim() : "");
		textoOri = (textoOri.startsWith("//") ? textoOri.replaceFirst("//", "") : textoOri);
		textoOri = (textoOri.startsWith("-") ? textoOri.replaceFirst("-", "") : textoOri);

		String cadInicio = "";
		if (numLinea > 1 && conCadInicio) {
			cadInicio = cadenaInicio;
		}
		if (textoOri.trim().length() == 0) {
			return "";
		}

		if (cantCarateres >= textoOri.length()) {
			return (cadInicio + textoOri + '\r' + '\n');

		}
		numLinea++;
		String linea35 = textoOri.substring(0, cantCarateres);

		// verificamos que haya una caracter vacio para tomar desde ahi la
		// nueval linea
		int posVacio = linea35.lastIndexOf(' ');
		String nuevaLinea35 = "";
		if (posVacio <= 0) {
			// no hya caracter vacio se corta a 34 caracteres
			nuevaLinea35 = textoOri.substring(0, cantCarateres);
		} else {
			nuevaLinea35 = textoOri.substring(0, posVacio);
		}

		// resto de la cadena
		textoOri = textoOri.substring(nuevaLinea35.length());

		nuevaLinea35 = nuevaLinea35 + '\r' + '\n';

		return cadInicio + nuevaLinea35 + formatoLinea(textoOri, numLinea, cadenaInicio, conCadInicio);
	}

	public static String cortarTexto(String textoOri, String cadenaInicio, boolean conCadInicio) {
		if (StringUtils.isBlank(textoOri)) {
			return textoOri;
		}

		try {
			// String lines1[] = null;
			List<String> cadEspliteado = new ArrayList<String>();
			String lines[] = textoOri.split("\\r\\n");

			for (int i = 0; i < lines.length; i++) {
				String linesSub[] = lines[i].split("//");
				for (int j = 0; j < linesSub.length; j++) {
					if (!StringUtils.isBlank(linesSub[j]))
						cadEspliteado.add(linesSub[j]);
				}
			}

			String cadenaNew = "";
			int tam = 1;
			for (String cadenalinea : cadEspliteado) {
				if (!StringUtils.isBlank(cadenalinea)) {
					String nCadena = formatoLinea(cadenalinea, tam, cadenaInicio, conCadInicio);
					tam++;
					cadenaNew = cadenaNew + (nCadena);
				}
			}
			return cadenaNew.trim();
		} catch (NullPointerException e) {
			throw new RuntimeException("Error al cortar texto " + e.getMessage(), e);
		} catch (Exception e) {
			throw new RuntimeException("Error al cortar texto " + e.getMessage(), e);
		}
	}

	/**
	 * divide una cadena en lineas menores a 35 caracteres 
	 * @param valor
	 * @param linesMax lineas maximo del resultado
	 * @param suffix cadena de separacion por linea
	 * @param cadenaInicio 
	 * @param startLine
	 * @return
	 */
	public static List<String> splitInLines(String valor, int linesMax, String suffix, String cadenaInicio, int startLine) {
		String frase = "";
		List<String> result = new ArrayList<String>();
		cadenaInicio = StringUtils.trimToEmpty(cadenaInicio);
		int line = 0;
		String prefijo = "";
		
		valor = StringUtils.trimToEmpty(valor);
		valor = MensSwiftUtiles.reemplazarCaracteresInvalidos(valor);
		valor = StringUtils.replaceChars(valor, "\r\n", "  ");		
		valor = StringUtils.replace(valor, "//", " ");
		do {
			valor = StringUtils.trimToEmpty(valor);			
			if (line >= startLine && StringUtils.isNotBlank(valor)) {
				prefijo = cadenaInicio;
			} else {
				prefijo = "";
			}
			valor = prefijo.concat(valor);
			//System.out.println("frase " + frase + " %% " + frase.length() + " valor: "  + valor);
			frase = UtilsGeneric.truncate(valor, MAX_LINE_CHARS, EOF, true);
			frase = StringUtils.trimToEmpty(frase);
			
			if (StringUtils.isNotBlank(frase)) {
				int lastSpace = frase.lastIndexOf(EOF);
				//System.out.println(lastSpace + ">> " +frase + " :: " + frase.length() + " ??[" + valor + "] $$ " + valor.length());

				frase = frase.substring(0,lastSpace);
				valor = valor.substring(frase.length());
				
				frase = (frase.startsWith("-") ? frase.replaceFirst("-", "") : frase);
				//System.out.println(frase + " <::> " + valor );
				//System.out.println(frase + " :: " + frase.length() + " ?? " + valor );
				frase = StringUtils.trimToEmpty(frase);
				result.add(frase);				
				line++;
				//System.out.println(prefijo.concat(frase) + " :: " + prefijo.concat(frase).length());
			}
		} while (valor.length() > 0 && result.size() < linesMax);
		
		return result;
	}

	public static String newStringFromBytes(byte[] bytes, String charsetName) {
		try {
			return new String(bytes, charsetName);
		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException("Impossible failure: Charset.forName(\"" + charsetName + "\") returns invalid name.");

		}
	}
	
	public static String charsInvalids = "Ã�Ã‰Ã�Ã“ÃšÃ‘Ã¡Ã©Ã­Ã³ÃºÃ±?\"";
	public static String charsValids =   "AEIOUNaeioun  ";

	public static Integer isValidoConcepto(String value, int numcharsline) {
		if (StringUtils.isBlank(value)) {
			return 0;
		}
		String valor = StringUtils.trimToEmpty(value);
		final List<String> result = new ArrayList<String>();
		if (value != null) {
			final BufferedReader br = new BufferedReader(new StringReader(valor));
			try {
				String l = br.readLine();
				while (l!=null) {
					result.add(l);
					l = br.readLine();
				}
			} catch (final IOException e) {
				throw new UnhandledException(e);
			}
		}
		int pos = 1;
		for (String string : result) {
			if (string.length() > numcharsline) {
				return pos;
			}
			pos++;
		}
		return 0;
	}

	public static String reemplazarCaracteresInvalidos(String valor) {
		valor = StringUtils.trimToEmpty(valor);
		if (StringUtils.isBlank(valor)) {
			return valor;
		}
		String nuevovalor = StringUtils.replaceChars(valor, charsInvalids, charsValids);
		return nuevovalor;
	}

	public static final Charset UTF8_CHARSET = Charset.forName("UTF-8");

	public static void main(String[] args) throws IOException {
		final String cad = "/ACC/FFC:983622168 BG \"cUBAA,BOLIVIA\r\nARMAS////CORPORATION Ã�Ã‰Ã�Ã†Ã“ÃšÃ‘Ã¡Ã©Ã­Ã³ÃºÃ± Ã�Ã¡Acï¿½ hola mundo cruel niÃ±o m'\'a(aÃ�Ã‘(Ã€Ã‡ Â�ÃƒÂ±";

		String valor = "RETRIBUCIONALTITULAR REPOSICIONREPOSICION AS DE, LA00 1 ENERGIA PAGADA Y NO, RETIRADA PERIODO ,SEPTIEMBRE  14A A ABRIL 2015.1 3";
		List<String> sb = MensSwiftUtiles.splitInLines(valor, 18, " ", "//", 1);
		System.out.println("==================f" + valor);
		for (String string : sb) {
			System.out.println(string.length() + ": " +  string);
		}
		SwiftParseUtils.splitComponents(valor, "", "");
		valor = "/benf/RETRIBUC\r\nIONALTITULAR //REPOSICIONR\rEPOSICION AS DE, //LA ENERGIA PAGADA Y NO, /RETIRADA PERIODO ,SEPTIEMBRE 14A A ABRIL 2015.";

		String delimitadores = "[ .,;?!Â¡Â¿\'\"\\[\\]]+";
		delimitadores = "[//[\\]]+";

		// String[] palabrasSeparadas = valor.split(delimitadores);
		String[] palabrasSeparadas = StringUtils.split(valor, "\r\n//");
		for (String string : palabrasSeparadas) {
			// System.out.println(string);
		}
		valor = "/benf/RETRIBUCIONALTITULAR \r\n//REPOSICIONREPOSICION AS DE, \r\n//LA ENERGIA PAGADA Y NO, RETIRADA PERIODO ,SEPTIEMBRE 14A A ABRIL 2015.123";
		// valor = MensSwiftUtiles.controlCadena(valor, 35, " ", null, 1);
		//System.out.println("=valor= " + valor);
		// List<String> result = SwiftParseUtils.getLines(valor);
		// //result = SwiftParseUtils.splitComponents(valor, "", "");
		// final StringBuffer result00 = new StringBuffer();
		// for (String string : result) {
		// System.out.println("==>> " + string);
		// String[] palabrasSeparadas0 =
		// StringUtils.splitByWholeSeparator(string, "//");
		// if (palabrasSeparadas0.length > 1){
		// for (String string2 : palabrasSeparadas0) {
		// if (result00.length() > 0) {
		// result00.append(" ");
		// }
		// result00.append(string2);
		// }
		// } else {
		// result00.append(string);
		// }
		// System.out.println("== " + string);
		// }
		// System.out.println(result00.toString());
		//
		// String result0 = MensSwiftUtiles.controlCadena(valor);
		// System.out.println(result0);
		// List<String> result1 = SwiftParseUtils.getLines(result0);
		// for (String string : result1) {
		// System.out.println(string );
		// }

		// boolean c = MensSwiftUtiles.isValidoConcepto(cad,
		// "ARMAS,CUBA,AA,as asf,,");
		// System.out.println(c);
		// c = MensSwiftUtiles.isValidoConcepto(cad, "");
		// System.out.println(c);
		//
		 //System.out.println(cad + " :: " + MensSwiftUtiles.reemplazarCaracteresInvalidos(cad));
		// System.out.println(MensSwiftUtiles.newStringFromString(cad));
		// String cc = new String(cad.getBytes(), "ISO-8859-1");
		// System.out.println(cc);
		// cc = new String(cc.getBytes(), "UTF-8");
		// System.out.println(cc);
	}
}
