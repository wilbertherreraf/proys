package gob.bcb.swift.commons;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.namespace.QName;

/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public interface ConstantsSwift {
	static final String CVE_ESTADOCTA  = "pec_estadocta";
	static final String CODIGO_MONEDA_DOLARES = "34";
	static final String CODIGO_MONEDA_DOLARES_SWF = "USD";
	static final String EST_MEN_SWFT = "P";

	static final String PEC_CODBCOFEEDWARE  = "000003";
	
	static final String PAR_ESTADOCTAACTIVA  = "A";
	static final String PAR_ESTADOCTANOAACTIVA  = "N";
	static final String PAR_ESTSWIFT_AUTO  = "A";	
	static final String PAR_ESTSWIFT_PEND  = "P";	
	static final String PAR_ESTSWIFT_RECH  = "R";	
	static final String PAR_ESTSWIFT_PREAUT  = "1";	
	
	static final String PARAM_PATHSWIFT  = "pathswift";
		
	static final String FORMAT_DATE_TIME = "yyyy-MM-dd HH:mm:ss:SSS";
	
	static final String AUDIT_USER_ESTACION = "estacion";
	static final String AUDIT_USER_SESSION_ID = "userID";
	static final String AUDIT_USER_DATABASE_ID = "userDatabase";
	
	static final String CODCAMPO_IDAPP = "IDAPP";
	static final String CODCAMPO_SERVID = "SERVID";
	static final String CODCAMPO_LTERMINAL = "LTID";
	static final String CODCAMPO_SESSNUM = "SESSNUM";
	static final String CODCAMPO_SEQNUM = "SEQNUM";
	static final String CODCAMPO_PRIORITY = "PRIOR";
	static final String CODCAMPO_RECEIVER = "RECEIVER";	

}
