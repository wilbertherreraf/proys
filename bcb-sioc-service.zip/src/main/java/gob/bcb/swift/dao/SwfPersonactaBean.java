package gob.bcb.swift.dao;

import gob.bcb.bpm.pruebaCU.SocBancosDao;

import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.pojos.BancoPlaza;
import gob.bcb.swift.commons.ConstantsSwift;
import gob.bcb.swift.exception.SwiftAdminException;
import gob.bcb.swift.model.SwfPersonacta;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

public class SwfPersonactaBean extends HibernateDaoSupport implements SwfPersonactaLocal {
	private static Logger log = Logger.getLogger(SwfPersonactaBean.class);

	public SwfPersonacta findByCodigo(String pecCodpersona, String pecCodinst, String pecNrocta) {
		String jpql = "SELECT t FROM SwfPersonacta t ";
		jpql = jpql.concat("WHERE t.id.pecCodpersona = :pecCodpersona ");
		jpql = jpql.concat("and t.id.pecCodinst = :pecCodinst ");
		jpql = jpql.concat("and t.id.pecNrocta = :pecNrocta ");

		Query query = getSession().createQuery(jpql);
		query.setParameter("pecCodpersona", pecCodpersona);
		query.setParameter("pecCodinst", pecCodinst); 
		query.setParameter("pecNrocta", pecNrocta);

		List lista = query.list();
		if (lista.size() > 0) {
			return (SwfPersonacta) lista.get(0);
		}

		return null;
	}

	public SwfPersonacta recuperarCuentaActiva(String pecCodpersona, String pecCodinst, String pecEstadocta) {

		String jpql = "SELECT t FROM SwfPersonacta t ";
		jpql = jpql.concat("WHERE t.id.pecCodpersona = :pecCodpersona ");

		if (!StringUtils.isBlank(pecCodinst)) {
			jpql = jpql.concat("and t.id.pecCodinst = :pecCodinst ");
		}

		jpql = jpql.concat("and t.pecEstadocta = :pecEstadocta ");
		log.info("Buscando cuenta activa " + pecCodpersona + " " + pecCodinst + " " + pecEstadocta + " => " + jpql);
		Query query = getSession().createQuery(jpql);
		query.setParameter("pecCodpersona", pecCodpersona);

		if (!StringUtils.isBlank(pecCodinst)) {
			query.setParameter("pecCodinst", pecCodinst);
		}
		query.setParameter("pecEstadocta", pecEstadocta);

		List lista = query.list();
		if (lista.size() == 0) {
			throw new SwiftAdminException("Cuenta activa inexistentes " + pecCodpersona + " verifique en cuentas instituciones");
		}
		if (lista.size() > 1) {
			throw new SwiftAdminException("Existen mas de Una Cuenta activa " + pecCodpersona + " verifique en cuentas instituciones");
		}

		return (SwfPersonacta) lista.get(0);
	}

	public List<SwfPersonacta> buscarCtasPersona(String pecCodpersona, String pecCodinst, String pecNrocta, String pecTipoctainst,
			String pecCodinstinter, String pecNroctainter, String pecEstadocta) {
		String jpql = "SELECT t FROM SwfPersonacta t ";
		jpql = jpql.concat("WHERE exists (select 1 from SocBancos b where b.bcoCodigo = t.id.pecCodpersona) ");
		
		if (!StringUtils.isBlank(pecCodpersona)) {
			jpql = jpql.concat("and t.id.pecCodpersona = :pecCodpersona ");			
		} 
		
		if (!StringUtils.isBlank(pecCodinst)) {
			jpql = jpql.concat("and t.id.pecCodinst = :pecCodinst ");
		}
		
		if (!StringUtils.isBlank(pecNrocta)) {
			jpql = jpql.concat("and t.id.pecNrocta = :pecNrocta ");
		}
		if (!StringUtils.isBlank(pecTipoctainst)) {
			jpql = jpql.concat("and t.pecTipoctainst = :pecTipoctainst ");
		}
		if (!StringUtils.isBlank(pecCodinstinter)) {
			jpql = jpql.concat("and t.pecCodinstinter = :pecCodinstinter ");
		}
		if (!StringUtils.isBlank(pecNroctainter)) {
			jpql = jpql.concat("and t.pecNroctainter = :pecNroctainter ");
		}

		if (!StringUtils.isBlank(pecEstadocta)) {
			jpql = jpql.concat("and t.pecEstadocta = :pecEstadocta ");
		}

		log.info("Query buscarCtasPersona " + jpql);
		Query query = getSession().createQuery(jpql);
		
		if (!StringUtils.isBlank(pecCodpersona)) {
			query.setParameter("pecCodpersona", pecCodpersona);			
		} 

		if (!StringUtils.isBlank(pecCodinst)) {
			query.setParameter("pecCodinst", pecCodinst);
		}

		if (!StringUtils.isBlank(pecNrocta)) {
			query.setParameter("pecNrocta", pecNrocta);
		}
		if (!StringUtils.isBlank(pecTipoctainst)) {
			query.setParameter("pecTipoctainst", pecTipoctainst);
		}
		if (!StringUtils.isBlank(pecCodinstinter)) {
			query.setParameter("pecCodinstinter", pecCodinstinter);
		}
		if (!StringUtils.isBlank(pecNroctainter)) {
			query.setParameter("pecNroctainter", pecNroctainter);
		}
		if (!StringUtils.isBlank(pecEstadocta)) {
			query.setParameter("pecEstadocta", pecEstadocta);
		}
		List lista = query.list();

		return lista;
	}

	public void guardarCuenta(SwfPersonacta swfPersonacta) {
		// agregar cuenta intermediario
		// validar camposº
		SwfPersonacta swfPersonactaOld = findByCodigo(swfPersonacta.getId().getPecCodpersona(), swfPersonacta.getId().getPecCodinst(), swfPersonacta
				.getId().getPecNrocta());

		if (StringUtils.isBlank(swfPersonacta.getId().getPecNrocta())) {
			throw new BusinessException("Nro cuenta o codigo Feedware de Banco invalido");
		}
		if (StringUtils.isBlank(swfPersonacta.getId().getPecCodinst())) {
			throw new BusinessException("Codigo de institucion intermediario invalido");
		}
		if (swfPersonactaOld == null) {
			log.info("Muevo cuenta ");
			// cambiarEstados(swfPersonacta.getId().getPecCodpersona(),
			// swfPersonacta.getId().getPecCodinst(),
			// null,Constants.PAR_ESTADOCTANOAACTIVA);

			swfPersonacta.setPecEstadocta(ConstantsSwift.PAR_ESTADOCTAACTIVA);
			this.getHibernateTemplate().merge(swfPersonacta);

			log.info("Nuevo cuenta salvado " + swfPersonacta.getId().getPecNrocta());
		} else {
			log.info("modidfica cuenta " + swfPersonacta.getId().getPecNrocta());
			this.getHibernateTemplate().merge(swfPersonacta);
			log.info("modidfica cuenta salvado " + swfPersonacta.getId().getPecNrocta());
		}
	}

	public List<BancoPlaza> findBancosByFWNroCta(String pecCodpersona, String pecCodinst, String pecNrocta, String pecTipoctainst, String pecEstadocta) {
		List<SwfPersonacta> swfPersonactaLista = buscarCtasPersona(pecCodpersona, pecCodinst, pecNrocta, pecTipoctainst, null, null, pecEstadocta);

		SocBancosDao socBancosDao = new SocBancosDao();
		socBancosDao.setSessionFactory(getSessionFactory());

		List<BancoPlaza> plazasLista = new ArrayList<BancoPlaza>();
		for (SwfPersonacta swfPersonacta : swfPersonactaLista) {
			BancoPlaza bancoPlaza = socBancosDao.bancoPlazaByCod(swfPersonacta.getId().getPecCodpersona());

			bancoPlaza.setPlaNrocuenta(swfPersonacta.getId().getPecNrocta());
			bancoPlaza.setPecEstadocta(swfPersonacta.getPecEstadocta());
			bancoPlaza.setSwfPersonacta(swfPersonacta);

			//BancoPlaza bancoPlazaInter = socBancosDao.bancoPlazaByCod(swfPersonacta.getId().getPecCodinst());

			plazasLista.add(bancoPlaza);

		}
		return plazasLista;
	}
	
	public BancoPlaza findBancoByFWNroCta(String pecCodpersona, String pecCodinst, String pecNrocta, String pecTipoctainst, String pecEstadocta) {
		List<BancoPlaza> plazasLista = findBancosByFWNroCta(pecCodpersona, pecCodinst, pecNrocta, pecTipoctainst, pecEstadocta);
		if (plazasLista.size() > 0) {
			return plazasLista.get(0);
		}
		return null;
	}
	
	public List<SwfPersonacta> buscarCtasPersona(String pecCodpersona, String pecCodinst, String pecNrocta, String pecTipoctainst,
			String pecEstadocta) {
		String jpql = "SELECT t FROM SwfPersonacta t, SocBancos b, SocPlazas p  ";
		jpql = jpql.concat("where b.bcoCodigo = p.id.bcoCodigo ");
		jpql = jpql.concat("and p.id.bcoCodigo = t.id.pecCodpersona ");		
		
		if (!StringUtils.isBlank(pecCodpersona)) {
			jpql = jpql.concat("and t.id.pecCodpersona = :pecCodpersona ");			
		} 
		
		if (!StringUtils.isBlank(pecCodinst)) {
			jpql = jpql.concat("and t.id.pecCodinst = :pecCodinst ");
		}
		
		if (!StringUtils.isBlank(pecNrocta)) {
			jpql = jpql.concat("and t.id.pecNrocta like :pecNrocta ");
		}
		if (!StringUtils.isBlank(pecTipoctainst)) {
			jpql = jpql.concat("and t.pecTipoctainst = :pecTipoctainst ");
		}

		if (!StringUtils.isBlank(pecEstadocta)) {
			jpql = jpql.concat("and t.pecEstadocta = :pecEstadocta ");
		}

		log.info("Query buscarCtasPersona " + jpql);
		Query query = getSession().createQuery(jpql);
		
		if (!StringUtils.isBlank(pecCodpersona)) {
			query.setParameter("pecCodpersona", pecCodpersona);			
		} 

		if (!StringUtils.isBlank(pecCodinst)) {
			query.setParameter("pecCodinst", pecCodinst);
		}

		if (!StringUtils.isBlank(pecNrocta)) {
			query.setParameter("pecNrocta", pecNrocta.trim().toUpperCase() + "%");
		}
		if (!StringUtils.isBlank(pecTipoctainst)) {
			query.setParameter("pecTipoctainst", pecTipoctainst);
		}
		if (!StringUtils.isBlank(pecEstadocta)) {
			query.setParameter("pecEstadocta", pecEstadocta);
		}
		List lista = query.list();

		return lista;
	}
	public List<BancoPlaza> buscarBancosByFWNroCta(String pecCodpersona, String pecCodinst, String pecNrocta, String pecTipoctainst, String pecEstadocta) {
		SocBancosDao socBancosDao = new SocBancosDao();
		socBancosDao.setSessionFactory(getSessionFactory());

		List<SwfPersonacta> swfPersonactaLista = buscarCtasPersona(pecCodpersona, pecCodinst, pecNrocta, pecTipoctainst, pecEstadocta);

		List<BancoPlaza> plazasLista = new ArrayList<BancoPlaza>();
		for (SwfPersonacta swfPersonacta : swfPersonactaLista) {
			BancoPlaza bancoPlaza = socBancosDao.bancoPlazaByCod(swfPersonacta.getId().getPecCodpersona());

			bancoPlaza.setPlaNrocuenta(swfPersonacta.getId().getPecNrocta());
			bancoPlaza.setPecEstadocta(swfPersonacta.getPecEstadocta());
			
			bancoPlaza.setSwfPersonacta(swfPersonacta);
			plazasLista.add(bancoPlaza);

		}
		return plazasLista;
	}
}
