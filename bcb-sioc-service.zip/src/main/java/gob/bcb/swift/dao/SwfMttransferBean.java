package gob.bcb.swift.dao;

import gob.bcb.swift.model.SwfMttransfer;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("swfMttransferLocal")
@Transactional
public class SwfMttransferBean extends HibernateDaoSupport implements SwfMttransferLocal {
	private static Logger log = Logger.getLogger(SwfMttransferBean.class);

	public SwfMttransfer findByCodigo(String mttCodttransfer) {
		
		String jpql = "SELECT t FROM SwfMttransfer t WHERE t.mttCodttransfer = :mttCodttransfer ";
		log.debug("En findByCodigo " + mttCodttransfer + " " + jpql);
		Query query = getSession().createQuery(jpql);
		query.setParameter("mttCodttransfer", mttCodttransfer);
		List lista = query.list();
		if (lista.size() > 0) {
			return (SwfMttransfer) lista.get(0);
		}
		return null;
	}
	public List<SwfMttransfer> getMTs() {
		
		String jpql = "SELECT t FROM SwfMttransfer t ";

		Query query = getSession().createQuery(jpql);

		List lista = query.list();
		return lista;
	}
}
