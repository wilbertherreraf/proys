package gob.bcb.swift.dao;

import gob.bcb.swift.model.SwfPersonacta;
import gob.bcb.swift.model.SwfPersonactaPK;

import java.util.List;

import org.hibernate.SessionFactory;

public interface SwfPersonactaLocal {

	SwfPersonacta findByCodigo(String pecCodpersona, String pecCodinst, String pecNrocta);

	void guardarCuenta(SwfPersonacta swfPersonacta);

	List<SwfPersonacta> buscarCtasPersona(String pecCodpersona, String pecCodinst, String pecNrocta, String pecTipoctainst, String pecCodinstinter,
			String pecNroctainter, String pecEstadocta);

	SwfPersonacta recuperarCuentaActiva(String pecCodpersona, String pecCodinst, String pecEstadocta);
	void setSessionFactory(SessionFactory sessionFactory);
}
