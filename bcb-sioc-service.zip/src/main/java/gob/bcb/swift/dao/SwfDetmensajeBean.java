package gob.bcb.swift.dao;

import gob.bcb.swift.model.SwfDetmensaje;
import gob.bcb.swift.model.SwfDetmensajePK;
import gob.bcb.swift.model.SwfMensaje;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("swfDetmensajeLocal")
@Transactional
public class SwfDetmensajeBean extends HibernateDaoSupport implements SwfDetmensajeLocal {
	private static Logger log = Logger.getLogger(SwfDetmensajeBean.class);
	public SwfDetmensaje findByCodigo(Integer demCodmen, Integer demNrocorr) {
		String jpql = "SELECT t FROM SwfDetmensaje t ";
		jpql = jpql.concat("WHERE t.id.demCodmen = :demCodmen ");
		jpql = jpql.concat("and t.id.demNrocorr = :demNrocorr ");

		Query query = getSession().createQuery(jpql);
		query.setParameter("demCodmen", demCodmen);
		query.setParameter("demNrocorr", demNrocorr);

		List lista = query.list();
		if (lista.size() > 0) {
			return (SwfDetmensaje) lista.get(0);
		}

		return null;
	}
	public SwfDetmensaje findByCampo(Integer demCodmen, String demCodcampo, Integer demBloque) {
		String jpql = "SELECT t FROM SwfDetmensaje t ";
		jpql = jpql.concat("WHERE t.id.demCodmen = :demCodmen ");
		jpql = jpql.concat("and t.demCodcampo = :demCodcampo ");

		Query query = getSession().createQuery(jpql);
		query.setParameter("demCodmen", demCodmen);
		query.setParameter("demCodcampo", demCodcampo);

		List lista = query.list();
		if (lista.size() > 0) {
			return (SwfDetmensaje) lista.get(0);
		}

		return null;
	}
	public List<SwfDetmensaje> findByCodMen(Integer demCodmen) {
		String jpql = "SELECT t FROM SwfDetmensaje t ";
		jpql = jpql.concat("WHERE t.id.demCodmen = :demCodmen ");
		
		Query query = getSession().createQuery(jpql);
		
		query.setParameter("demCodmen", demCodmen);
		
		List lista = query.list();
		return lista;
	}
	
	public SwfDetmensaje saveorupdate(SwfMensaje swfMensaje, SwfDetmensaje swfDetmensaje){
		log.info("en saveorupdate " + swfMensaje.getMenCodmen() + " :: " + swfDetmensaje.getId().getDemCodmen() + " " + swfDetmensaje.getId().getDemNrocorr());
		SwfDetmensaje swfDetmensajeOld = findByCodigo(swfDetmensaje.getId().getDemCodmen(), swfDetmensaje.getId().getDemNrocorr());
		
		if (swfDetmensajeOld == null){
			swfDetmensaje.getId().setDemCodmen(swfMensaje.getMenCodmen());
			swfDetmensaje.setDemAuditusr(swfMensaje.getMenAuditusr());
			swfDetmensaje.setDemAuditwst(swfMensaje.getMenAuditwst());
			swfDetmensaje.setDemAuditfho(new Date());
			
			Integer codigo = getCodigo(swfDetmensaje.getId().getDemCodmen());
			swfDetmensaje.getId().setDemNrocorr(codigo);
			
			this.getHibernateTemplate().merge(swfDetmensaje);
		} else {
			swfDetmensaje.setDemAuditusr(swfMensaje.getMenAuditusr());
			swfDetmensaje.setDemAuditwst(swfMensaje.getMenAuditwst());
			swfDetmensaje.setDemAuditfho(new Date());
			
			this.getHibernateTemplate().merge(swfDetmensaje);
		}
		log.info("salvado Detmensaje: " + swfDetmensaje.toString());		
		return findByCodigo(swfDetmensaje.getId().getDemCodmen(), swfDetmensaje.getId().getDemNrocorr());
	}

	public SwfDetmensaje actualizarCampo(Integer demCodmen, String demCodcampo, Integer demBloque, String demValor, String auditUsr, String auditWst) {
		log.info("actualizarCampo:: "+ demCodmen + " demCodcampo: " + demCodcampo + " demBloque: " + demBloque + " demValor: " + demValor);
		
		SwfDetmensaje swfDetmensaje = findByCampo(demCodmen, demCodcampo, demBloque);

		if (swfDetmensaje == null) {
			swfDetmensaje = new SwfDetmensaje();
			SwfDetmensajePK swfDetmensajePK = new SwfDetmensajePK();
			swfDetmensajePK.setDemCodmen(demCodmen);
			swfDetmensajePK.setDemNrocorr(0);

			swfDetmensaje.setId(swfDetmensajePK);
			swfDetmensaje.setDemValor(demValor);
			swfDetmensaje.setDemCodcampo(demCodcampo);
			swfDetmensaje.setDemAuditusr(auditUsr);
			swfDetmensaje.setDemAuditwst(auditWst);
			swfDetmensaje.setDemAuditfho(new Date());

			Integer codigo = getCodigo(swfDetmensaje.getId().getDemCodmen());
			swfDetmensaje.getId().setDemNrocorr(codigo);
			
			this.getHibernateTemplate().merge(swfDetmensaje);
		} else {
			swfDetmensaje.setDemValor(demValor);
			swfDetmensaje.setDemAuditusr(auditUsr);
			swfDetmensaje.setDemAuditwst(auditWst);
			swfDetmensaje.setDemAuditfho(new Date());
			
			swfDetmensaje = updateDetmensaje(swfDetmensaje);
		}

		return swfDetmensaje;
	}

	public SwfDetmensaje nuevoDetmensaje(SwfDetmensaje swfDetmensaje) {
		log.info("en nuevoDetmensaje " + swfDetmensaje.toString());		
		Integer codigo = getCodigo(swfDetmensaje.getId().getDemCodmen());
		swfDetmensaje.getId().setDemNrocorr(codigo);
		this.getHibernateTemplate().merge(swfDetmensaje);
		
		return findByCodigo(swfDetmensaje.getId().getDemCodmen(), codigo);
	}

	public SwfDetmensaje updateDetmensaje(SwfDetmensaje swfDetmensaje) {
		log.info("en updateDetmensaje " + swfDetmensaje.toString());		
		this.getHibernateTemplate().merge(swfDetmensaje);
		
		return findByCodigo(swfDetmensaje.getId().getDemCodmen(), swfDetmensaje.getId().getDemNrocorr());
	}
	
	public List<SwfDetmensaje> actualizarDetalles(SwfMensaje swfMensaje, List<SwfDetmensaje> swfDetmensajeList){
		log.info("en actualizarDetalles " + swfMensaje.getMenCodmen());
		borrarDetalles(swfMensaje.getMenCodmen());
		
		for (SwfDetmensaje swfDetmensaje : swfDetmensajeList) {
			saveorupdate(swfMensaje, swfDetmensaje);
		}
		return findByCodMen(swfMensaje.getMenCodmen()) ;
	}

	private void borrarDetalles(Integer demCodmen) {
		//log.info("En borrarDetalles: para demCodmen " + demCodmen);

		String jsql = "DELETE from SwfDetmensaje c ";
		jsql = jsql.concat("WHERE c.id.demCodmen = :demCodmen ");

		Query query = getSession().createQuery(jsql);
		query.setParameter("demCodmen", demCodmen);

		int result = query.executeUpdate();
		//log.info("Modificados: " + result + " para " + demCodmen);

	}
	
	private Integer getCodigo(Integer demCodmen) {
		Integer codigo = null;
		String jpql = "select max(m.id.demNrocorr) ";
		jpql = jpql.concat("from SwfDetmensaje m ");
		jpql = jpql.concat("where m.id.demCodmen = :demCodmen ");

		Query query = getSession().createQuery(jpql);
		query.setParameter("demCodmen", demCodmen);

		List result = query.list();

		if (result.size() > 0)
			codigo = (Integer) result.get(0);

		if (codigo == null) {
			codigo = 0;
		}
		codigo++;
		log.debug("Nuevo codigo : " + codigo);
		return codigo;

	}
}
