package gob.bcb.swift.dao;

import gob.bcb.swift.model.SwfDetmensaje;
import gob.bcb.swift.model.SwfDetmensajePK;
import gob.bcb.swift.model.SwfMensaje;

import java.util.List;

import org.hibernate.SessionFactory;

public interface SwfDetmensajeLocal {

	SwfDetmensaje findByCodigo(Integer demCodmen, Integer demNrocorr);

	List<SwfDetmensaje> findByCodMen(Integer demCodmen);

	SwfDetmensaje nuevoDetmensaje(SwfDetmensaje swfDetmensaje);

	SwfDetmensaje updateDetmensaje(SwfDetmensaje swfDetmensaje);

	List<SwfDetmensaje> actualizarDetalles(SwfMensaje swfMensaje, List<SwfDetmensaje> swfDetmensajeList);

	SwfDetmensaje saveorupdate(SwfMensaje swfMensaje, SwfDetmensaje swfDetmensaje);

	SwfDetmensaje findByCampo(Integer demCodmen, String demCodcampo, Integer demBloque);

	SwfDetmensaje actualizarCampo(Integer demCodmen, String demCodcampo, Integer demBloque, String demValor, String auditUsr, String auditWst);
	void setSessionFactory(SessionFactory sessionFactory);
}
