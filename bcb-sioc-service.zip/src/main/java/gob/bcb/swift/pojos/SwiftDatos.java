package gob.bcb.swift.pojos;

import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.swift.model.SwfBics;
import gob.bcb.swift.model.SwfMensaje;
import gob.bcb.swift.model.SwfMttransfer;
import gob.bcb.swift.model.SwfPersonacta;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class SwiftDatos implements Serializable{
	private SwfMensaje swfMensaje;
	private SwfBics swfBicsSender;
	private SwfBics swfBicsReceiver;	
	private SwfMttransfer swfMttransfer;
	private String auditwst;
	private String auditusr;
	private Solicitud solicitudTO;
	private SocDetallessol socDetallessol;	
	private Map<String, Object> parametro = new HashMap<String, Object>();
	
//	public SwfPersonacta getSender() {
//		return sender;
//	}
//
//	public void setSender(SwfPersonacta sender) {
//		this.sender = sender;
//	}
//
//	public SwfPersonacta getReceiver() {
//		return receiver;
//	}
//
//	public void setReceiver(SwfPersonacta receiver) {
//		this.receiver = receiver;
//	}

//	public SwfPersonacta getBeneficiario() {
//		return beneficiario;
//	}
//
//	public void setBeneficiario(SwfPersonacta beneficiario) {
//		this.beneficiario = beneficiario;
//	}

//	public SwfPersonacta getBeneficiarioBco() {
//		return beneficiarioBco;
//	}
//
//	public void setBeneficiarioBco(SwfPersonacta beneficiarioBco) {
//		this.beneficiarioBco = beneficiarioBco;
//	}
//
//	public SwfPersonacta getIntermediario() {
//		return intermediario;
//	}
//
//	public void setIntermediario(SwfPersonacta intermediario) {
//		this.intermediario = intermediario;
//	}

	public void setParametro(String key, Object valor) {
		if (this.parametro == null){
			parametro = new HashMap<String, Object>();
		}
		if (valor == null){
			if (parametro.containsKey(key))
				parametro.remove(key);
		} else {
			if (key != null){
				parametro.put(key, valor);				
			}
		}
	}

	public Object getParametro(String key) {
		return parametro.get(key);
	}
	public void removeParametro(String key) {
		try{
			parametro.remove(key);
		}catch (Exception e) {
		}
	}
	public void limpiarParametros() {
		parametro.clear();
	}

	public void setParametro(Map<String, Object> parametro) {
		this.parametro = parametro;
	}

	public Map<String, Object> getParametro() {
		return parametro;
	}

	public SwfMensaje getSwfMensaje() {
		return swfMensaje;
	}

	public void setSwfMensaje(SwfMensaje swfMensaje) {
		this.swfMensaje = swfMensaje;
	}

	public SwfMttransfer getSwfMttransfer() {
		return swfMttransfer;
	}

	public void setSwfMttransfer(SwfMttransfer swfMttransfer) {
		this.swfMttransfer = swfMttransfer;
	}

	public String getAuditwst() {
		return auditwst;
	}

	public void setAuditwst(String auditwst) {
		this.auditwst = auditwst;
	}

	public String getAuditusr() {
		return auditusr;
	}

	public void setAuditusr(String auditusr) {
		this.auditusr = auditusr;
	}

	public SwfBics getSwfBicsSender() {
		return swfBicsSender;
	}

	public void setSwfBicsSender(SwfBics swfBicsSender) {
		this.swfBicsSender = swfBicsSender;
	}

	public SwfBics getSwfBicsReceiver() {
		return swfBicsReceiver;
	}

	public void setSwfBicsReceiver(SwfBics swfBicsReceiver) {
		this.swfBicsReceiver = swfBicsReceiver;
	}

	public SwfBics newSwfBicsSender(String bicCodbic, String bicCodbranch, String bicDescrip, String bicDirecc1, String bicCiudad, String bicPais){
		swfBicsSender = new SwfBics(bicCodbic, bicCodbranch, bicDescrip, bicDirecc1, bicCiudad, bicPais);
		return swfBicsSender; 
	}
	public SwfBics newSwfBicsReceiver(String bicCodbic, String bicCodbranch, String bicDescrip, String bicDirecc1, String bicCiudad, String bicPais){
		swfBicsReceiver = new SwfBics(bicCodbic, bicCodbranch, bicDescrip, bicDirecc1, bicCiudad, bicPais);
		return swfBicsReceiver; 
	}

	public Solicitud getSolicitudTO() {
		return solicitudTO;
	}

	public void setSolicitudTO(Solicitud solicitudTO) {
		this.solicitudTO = solicitudTO;
	}

	public SocDetallessol getSocDetallessol() {
		return socDetallessol;
	}

	public void setSocDetallessol(SocDetallessol socDetallessol) {
		this.socDetallessol = socDetallessol;
	}	
}
