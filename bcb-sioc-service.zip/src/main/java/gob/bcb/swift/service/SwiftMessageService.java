package gob.bcb.swift.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.prowidesoftware.swift.model.LogicalTerminalAddress;
import com.prowidesoftware.swift.model.SwiftBlock4;
import com.prowidesoftware.swift.model.Tag;
import com.prowidesoftware.swift.model.field.Field;

import gob.bcb.bpm.pruebaCU.Beneficiario;
import gob.bcb.bpm.pruebaCU.GenMoneda;
import gob.bcb.bpm.pruebaCU.GenMonedaDao;
import gob.bcb.bpm.pruebaCU.SocBancosDao;
import gob.bcb.bpm.pruebaCU.SocBenefs;
import gob.bcb.bpm.pruebaCU.SocBenefsDao;
import gob.bcb.bpm.pruebaCU.SocCuentas;
import gob.bcb.bpm.pruebaCU.SocCuentassolDao;
import gob.bcb.bpm.pruebaCU.SocOpecomi;
import gob.bcb.bpm.pruebaCU.SocOpecomiDao;
import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.bpm.pruebaCU.SocSolicitanteDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudctas;
import gob.bcb.bpm.pruebaCU.SocSolicitudctasDao;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.lavado.client.pojos.SearchResponse;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioPortiaSwift.PortiaService;
import gob.bcb.service.servicioPortiaSwift.model.Loader;
import gob.bcb.service.servicioPortiaSwift.model.LoaderDao;
import gob.bcb.service.servicioSioc.ClienteLvdSioc;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.logic.CartasCredService;
import gob.bcb.service.servicioSioc.pojos.BancoPlaza;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;
import gob.bcb.swift.commons.ConstantsSwift;
import gob.bcb.swift.dao.SwfDetmensajeBean;
import gob.bcb.swift.dao.SwfDetmensajeLocal;
import gob.bcb.swift.dao.SwfMensajeBean;
import gob.bcb.swift.dao.SwfMensajeLocal;
import gob.bcb.swift.dao.SwfMttransferBean;
import gob.bcb.swift.dao.SwfMttransferLocal;
import gob.bcb.swift.dao.SwfMttransferdetBean;
import gob.bcb.swift.dao.SwfMttransferdetLocal;
import gob.bcb.swift.dao.SwfPersonactaBean;
import gob.bcb.swift.dao.SwfPersonactaLocal;
import gob.bcb.swift.exception.SwiftAdminException;
import gob.bcb.swift.model.SwfDetmensaje;
import gob.bcb.swift.model.SwfMensaje;
import gob.bcb.swift.model.SwfMttransfer;
import gob.bcb.swift.model.SwfMttransferdet;
import gob.bcb.swift.pojos.SwiftDatos;
import gob.bcb.swift.pojos.SwiftMessageBcb;

@Service("swiftMessageServiceLocal")
@Transactional
public class SwiftMessageService implements SwiftMessageServiceLocal {
	private static final Logger log = Logger.getLogger(SwiftMessageService.class);

	@Autowired
	private SocBancosDao socBancosDao = new SocBancosDao();
	@Autowired
	private SocBenefsDao socBenefsDao = new SocBenefsDao();
	@Autowired
	private SwfMttransferdetLocal swfMttransferdetLocal = new SwfMttransferdetBean();
	@Autowired
	private SwfMensajeLocal swfMensajeLocal = new SwfMensajeBean();
	@Autowired
	private SwfMttransferLocal swfMttransferLocal = new SwfMttransferBean();
	@Autowired
	private SwfPersonactaLocal swfPersonactaLocal = new SwfPersonactaBean();
	@Autowired
	private SwfDetmensajeLocal swfDetmensajeLocal = new SwfDetmensajeBean();

	private SessionFactory sessionFactory;

	public SwiftMessageService() {
	}

	public SwiftMessageService(EntityManager entityManager) {

	}

	public SwfMensaje generarMensaje(SwiftDatos swiftDatos) {
		log.info("En generarMensaje swiftDatos inicio de generar Swift " + swiftDatos.getSwfMensaje().getMenCodmt() + " " + swiftDatos.getSwfMensaje().getMenCodoperacion() + " "
				+ swiftDatos.getSwfMensaje().getMenCodusrswf());

		SwiftMessageBcb swiftMessageBcb = new SwiftMessageBcb();
		log.info("·······" + swiftDatos.getSwfMensaje().getMenBic() + "·····");

		llenarBlock12(swiftMessageBcb, swiftDatos.getSwfMensaje().getMenCodmt(), swiftDatos.getSwfMensaje().getMenBic());
		llenarBlock3(swiftMessageBcb, swiftDatos.getSwfMensaje().getMenCodmt());

		obtenerCamposBlk4(swiftDatos, swiftMessageBcb);

		//log.info("SMIFT::\n" + swiftMessageBcb.FIN());

		SwfMensaje swfMensaje = guardarSwiftObject(swiftDatos, swiftMessageBcb);
		return swfMensaje;

	}

	public void obtenerCamposBlk4(SwiftDatos swiftDatos, SwiftMessageBcb swiftMessageBcb) {
		log.info("En obtenerCamposBlk4 " + swiftDatos.getSwfMensaje().getMenCodmt());
		List<SwfMttransferdet> SwfMttransferdetLista = swfMttransferdetLocal.findByCodTTransfer(swiftDatos.getSwfMensaje().getMenCodmt(), 4);

		for (SwfMttransferdet swfMttransferdet : SwfMttransferdetLista) {
			Field field = obtenerValor(swiftDatos, swiftDatos.getSwfMensaje(), swiftMessageBcb, swfMttransferdet);

			if (field != null) {
				swiftMessageBcb.addField(field);
			}

		}
	}

	/**
	 * recupera valor del campo propio del bloque 4
	 * 
	 * @param swfMttransferdet
	 * @return
	 */
	private Field obtenerValor(SwiftDatos swiftDatos, SwfMensaje swfMensaje, SwiftMessageBcb swiftMessageBcb, SwfMttransferdet swfMttransferdet) {

		if (swiftMessageBcb == null) {
			swiftMessageBcb = new SwiftMessageBcb();
		}
		SocSolicitudctasDao socSolicitudctasDao = new SocSolicitudctasDao();
		socSolicitudctasDao.setSessionFactory(getSessionFactory());

		String campo = swfMttransferdet.getId().getDttCodcampo().trim();
		String valorKtte = "";
		if (!StringUtils.isBlank(swfMttransferdet.getDttTipocampo())) {
			if (swfMttransferdet.getDttTipocampo().equals("K")) {
				// campo constante
				if (!StringUtils.isBlank(swfMttransferdet.getDttValcampo())) {
					valorKtte = swfMttransferdet.getDttTipocampo();
				}
			}
		}

		//log.info("Obtener Valor " + swfMttransferdet.getId().getDttCodttransfer() + " campo:" + campo + " Bloque:" + swfMttransferdet.getId().getDttBloque());
		Field field = null;
		boolean requerido = true;
		if (campo.equals("20")) {
			// ref transaccion
			field = swiftMessageBcb.setField20(swfMensaje.getMenNrocorr(), new Date(), swfMensaje.getMenCodusrswf());
		} else if (campo.equals("21")) {
			// referencia original
			field = swiftMessageBcb.setField21(swfMttransferdet.getDttValcampo());
		} else if (campo.equals("23B")) {
			// Codigo sta operacion bancaria
			// ktte CRED
			field = swiftMessageBcb.setField23B(swfMttransferdet.getDttValcampo());
		} else if (campo.equals("32A")) {
			// FECHA MONEDA IMPORTE
			field = swiftMessageBcb.setField32A(swfMensaje.getMenFecvalor(), swfMensaje.getMenCodmonswift(), swfMensaje.getMenMonto());
		} else if (campo.equals("33B")) {
			// monto ordenado
			requerido = false;
			if (swiftDatos.getSolicitudTO().getSolicitud().getTipoRetencion().equals(Constants.CLAVE_TIPORETENCION_CONDESC)) {
				SocOpecomiDao socOpecomiDao = new SocOpecomiDao();
				socOpecomiDao.setSessionFactory(getSessionFactory());

				SocOpecomi socOpecomi = socOpecomiDao.getOpeComisByDetCodClaCom(swiftDatos.getSolicitudTO().getSolicitud().getSocCodigo(), 0, "MONTOORD");
				if (socOpecomi == null || socOpecomi.getMontoMo().compareTo(BigDecimal.valueOf(0)) <= 0) {
					throw new BusinessException("No se puede hallar MONTOORD para Solicitud con descuento " + swiftDatos.getSolicitudTO().getSolicitud().getSocCodigo());
				}

				GenMonedaDao genMonedaDao = new GenMonedaDao();
				genMonedaDao.setSessionFactory(getSessionFactory());

				GenMoneda genMoneda = genMonedaDao.findByCodMoneda(socOpecomi.getCodMoneda());
				BigDecimal montoOrd = socOpecomi.getMontoMo();

				BigDecimal monto = montoOrd.setScale(2, RoundingMode.HALF_UP);

				field = swiftMessageBcb.setField33B(genMoneda.getMonSigla(), monto);
			}
		} else if (campo.equals("50A")) {
			field = swiftMessageBcb.setField50A(swfMttransferdet.getDttValcampo());

		} else if (campo.equals("50K")) {

			String cta = "";
			// 50k es la cuenta del cliente originante de la solicitud
			SocSolicitudctas socSolicitudctas = socSolicitudctasDao.getCuenta(swiftDatos.getSolicitudTO().getSolicitud().getSocCodigo(), Constants.COD_CLAVE_MOVPROVISION, null,
					null, null, null);
			// 3987
			SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
			socSolicitanteDao.setSessionFactory(getSessionFactory());

			SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCodigo(socSolicitudctas.getSolCodigo());
			if (socSolicitante != null) {
				if (!StringUtils.isBlank(socSolicitante.getSolCodigo()) && socSolicitante.getSolCodigo().trim().equals(Constants.COD_BCB)) {
					// cta del bcb
					cta = socSolicitudctas.getNroCuenta();
				} else {
					if (!StringUtils.isBlank(socSolicitante.getClaEntidad())) {
						if (socSolicitante.getClaEntidad().equals(Constants.CLAVE_CLAENTIDAD_SISTFINANCIERO)) {
							// la cta de provision pertenece a entidad es un bco
							// externo
							cta = socSolicitudctas.getNroLibreta();
						} else if (socSolicitante.getClaEntidad().equals(Constants.CLAVE_CLAENTIDAD_SISTPUBLICO)) {
							// es en el bcb
							cta = socSolicitudctas.getNroCuenta();
						}
					} else {
						throw new BusinessException("Error de parametrizacion, solicitante " + socSolicitudctas.getSolCodigo() + " sin tipo de entidad");
					}
				}
			} else {
				log.error("solicitante inexistente en socsolicitante " + socSolicitudctas.getSolCodigo());
				cta = socSolicitudctas.getNroCuenta();
			}

			if (StringUtils.isBlank(cta)) {
				throw new BusinessException(
						"Nro Cuenta de provision de solicitante " + swiftDatos.getSolicitudTO().getSolicitud().getSolCodigo() + " nulo, revise la cuenta MOVPROVISION");
			}
			String nameAndLocation = StringUtils.trimToEmpty(swiftDatos.getSolicitudTO().getSocSolicitante().getSolPersona()) + " ";
			nameAndLocation = nameAndLocation + StringUtils.trimToEmpty(swiftDatos.getSolicitudTO().getSocSolicitante().getSolDireccion()) + " ";
			nameAndLocation = nameAndLocation + StringUtils.trimToEmpty(swiftDatos.getSolicitudTO().getSocSolicitante().getSolPlaza());
			nameAndLocation = StringUtils.trimToEmpty(nameAndLocation);

			field = swiftMessageBcb.setField50K(cta, nameAndLocation);

		} else if (campo.equals("52A")) {
			field = swiftMessageBcb.setField52A(null, swiftDatos.getSolicitudTO().getSocSolicitante().getSolBic());
		} else if (campo.equals("52D")) {
			// field = swiftMessageBcb.setField20(swfMensaje.getMenNrocorr(),
			// swfMensaje.getMenFecvalor(), swfMensaje.getMenCodusrswf());
		} else if (campo.equals("53A")) {
			// field = swiftMessageBcb.setField53A(swfMensaje.getMenNrocorr(),
			// swfMensaje.getMenFecvalor(), swfMensaje.getMenCodusrswf());
		} else if (campo.equals("53B")) {
			// CORRESPONSAL DEL REMITENTE LUGAR
			// CTA BCB EN EL ESTANDAR
			// NOMBRE CTA
			SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
			socCuentassolDao.setSessionFactory(getSessionFactory());

			SocCuentas socCuentas = socCuentassolDao.getSocCuentaBanqueroExt(swiftDatos.getSolicitudTO().getSolicitud(), swfMensaje.getMenCodmon(), null);

			if (socCuentas != null) {
				BancoPlaza bancoPlazaSender = socBancosDao.bancoPlazaByCod(Constants.COD_BCB_SWIFT);

				field = swiftMessageBcb.setField53B(socCuentas.getCtaNrocuenta(), bancoPlazaSender.getBcoNombre());
			}
		} else if (campo.equals("53D")) {
			// field = swiftMessageBcb.setField20(swfMensaje.getMenNrocorr(),
			// swfMensaje.getMenFecvalor(), swfMensaje.getMenCodusrswf());
		} else if (campo.equals("54B")) {
			// field = swiftMessageBcb.setField20(swfMensaje.getMenNrocorr(),
			// swfMensaje.getMenFecvalor(), swfMensaje.getMenCodusrswf());
		} else if (campo.equals("54D")) {
			// field = swiftMessageBcb.setField20(swfMensaje.getMenNrocorr(),
			// swfMensaje.getMenFecvalor(), swfMensaje.getMenCodusrswf());
		} else if (campo.equals("56A")) {
			// BIC INTERMEDIARIO
			// NOMBRE BCO INTERMEDIARO
			// intemediario
			// 56A
			BancoPlaza bancoPlaza = socBancosDao.bancoPlazaByCod(swiftDatos.getSocDetallessol().getCodBancointer());
			field = swiftMessageBcb.setField56A(null, bancoPlaza.getPlaBic());

		} else if (campo.equals("56D")) {
			// field = swiftMessageBcb.setField20(swfMensaje.getMenNrocorr(),
			// swfMensaje.getMenFecvalor(), swfMensaje.getMenCodusrswf());
		} else if (campo.equals("57A")) {
			// BIC ENT. DEPOSITARIA DE LA CTA - FI BIC
			BancoPlaza bancoPlaza = socBancosDao.bancoPlazaByCod(swiftDatos.getSocDetallessol().getCodBanco());
			if (bancoPlaza == null) {
				throw new SwiftAdminException("Beneficiario " + swiftDatos.getSocDetallessol().getBenCodigo() + " con banco " + swiftDatos.getSocDetallessol().getCodBanco()
						+ " sin registro en bancos");
			}
			if (StringUtils.isBlank(bancoPlaza.getPlaBic())) {
				throw new SwiftAdminException("Beneficiario " + swiftDatos.getSocDetallessol().getBenCodigo() + " con Banco " + swiftDatos.getSocDetallessol().getCodBanco()
						+ " sin BIC requerido para Campo " + campo + " MT " + swfMttransferdet.getId().getDttCodttransfer());
			}
			field = swiftMessageBcb.setField57A(null, bancoPlaza.getPlaBic());

		} else if (campo.equals("57D")) {
			BancoPlaza bancoPlaza = socBancosDao.bancoPlazaByCod(swiftDatos.getSocDetallessol().getCodBanco());

			if (bancoPlaza == null) {
				throw new SwiftAdminException("Beneficiario " + swiftDatos.getSocDetallessol().getBenCodigo() + " con banco " + swiftDatos.getSocDetallessol().getCodBanco()
						+ " sin registro en bancos");
			}
			if (StringUtils.isBlank(swiftDatos.getSocDetallessol().getNroCuentabcointer())) {
				throw new SwiftAdminException("Beneficiario " + swiftDatos.getSocDetallessol().getBenCodigo() + " con Banco " + swiftDatos.getSocDetallessol().getCodBanco()
						+ " sin Nro de cta o FW registrado, requerido para Campo " + campo + " MT " + swfMttransferdet.getId().getDttCodttransfer());
			}

			String nameAndLocation = StringUtils.trimToEmpty(bancoPlaza.getBcoNombre()) + " ";
			nameAndLocation = nameAndLocation + StringUtils.trimToEmpty(bancoPlaza.getPlaNombre());
			nameAndLocation = StringUtils.trimToEmpty(nameAndLocation);

			field = swiftMessageBcb.setField57D(swiftDatos.getSocDetallessol().getNroCuentabcointer(), nameAndLocation);

		} else if (campo.equals("57B")) {
			// field = swiftMessageBcb.setField20(swfMensaje.getMenNrocorr(),
			// swfMensaje.getMenFecvalor(), swfMensaje.getMenCodusrswf());
		} else if (campo.equals("58A")) {
			// ENT BENEFICIARIA CON BIC
			// el beneficiario es un banco
			boolean esCartas = swiftDatos.getSolicitudTO().getSolicitud().getClaTipo().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS) 
					|| swiftDatos.getSolicitudTO().getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS);
			
			BancoPlaza bancoPlaza = null;
			String nroCtaBco = "";
			if (esCartas) {
				CartasCredService cartasCredService = new CartasCredService(getSessionFactory(), SiocCoinService.getSessionFactory());
				Solicitud solicitud = cartasCredService.recuperarCartaYDetalleParaSolicitud(swiftDatos.getSolicitudTO().getSolicitud().getSocCodigo());
				bancoPlaza = socBancosDao.bancoPlazaByCod(solicitud.getCarCartascrdet().getCcdCodbcoreceptor());
				
				if (bancoPlaza == null) {
					throw new SwiftAdminException("Entidad beneficiaria " + solicitud.getCarCartascrdet().getCcdCodbcoreceptor() + " sin registro en socbancos");
				}
				nroCtaBco = swiftDatos.getSocDetallessol().getNroCuentabco();
			} else {
				bancoPlaza = socBancosDao.bancoPlazaByCod(swiftDatos.getSocDetallessol().getNroCuentabco());				
			
				if (bancoPlaza == null) {
					throw new SwiftAdminException("Entidad beneficiaria " + swiftDatos.getSocDetallessol().getNroCuentabco()
							+ " sin registro en socbancos");
				}
			}	
			
			if (StringUtils.isBlank(bancoPlaza.getPlaBic())) {
				throw new SwiftAdminException("Entidad beneficiaria " + bancoPlaza.getSocBancos().getBcoCodigo()
						+ " sin BIC, requerido para Campo " + campo + " MT " + swfMttransferdet.getId().getDttCodttransfer());
			}
			
			field = swiftMessageBcb.setField58A(nroCtaBco, bancoPlaza.getPlaBic());
		} else if (campo.equals("58D")) {
			// ENT BENEFICIARIA NOMBRE DIRECCION
			SocBenefsDao socBenefsDao = new SocBenefsDao();
			socBenefsDao.setSessionFactory(getSessionFactory());
			SocBenefs socBenefs = socBenefsDao.getBenefsByBenCodigo(swiftDatos.getSocDetallessol().getBenCodigo());

			field = swiftMessageBcb.setField58D(swiftDatos.getSocDetallessol().getNroCuentabco(), socBenefs.getBenNombre());

		} else if (campo.equals("59")) {
			SocBenefsDao socBenefsDao = new SocBenefsDao();
			socBenefsDao.setSessionFactory(getSessionFactory());

			List<Beneficiario> beneficiarios = socBenefsDao.beneficiariosExternosSolicitante(swiftDatos.getSolicitudTO().getSolicitud().getSolCodigo(),
					swiftDatos.getSocDetallessol().getBenCodigo(), swfMensaje.getMenCodmon(), null, false);

			if (beneficiarios.size() > 0) {

				if (StringUtils.isBlank(beneficiarios.get(0).getBenDireccion()) || StringUtils.isBlank(beneficiarios.get(0).getBenPlaza())) {
					throw new SwiftAdminException(
							"Beneficiario " + swiftDatos.getSocDetallessol().getBenCodigo() + " - " + beneficiarios.get(0).getBenNombre() + " sin registro de direccion o plaza");
				}

				String nameAndLocation = StringUtils.trimToEmpty(beneficiarios.get(0).getBenDireccion()) + ", ";
				nameAndLocation = nameAndLocation + StringUtils.trimToEmpty(beneficiarios.get(0).getBenPlaza());

				nameAndLocation = StringUtils.trimToEmpty(nameAndLocation);

				field = swiftMessageBcb.setField59(swiftDatos.getSocDetallessol().getNroCuentabco(), beneficiarios.get(0).getBenNombre(), nameAndLocation);
			} else {
				throw new SwiftAdminException(swiftDatos.getSocDetallessol().getId().getDetCodigo() + ":: Campo " + campo + " MT " + swfMttransferdet.getId().getDttCodttransfer()
						+ " beneficiario " + swiftDatos.getSocDetallessol().getBenCodigo() + " sin registro para ");
			}

		} else if (campo.equals("70")) {
			requerido = false;
			if (!StringUtils.isBlank(swiftDatos.getSocDetallessol().getDetConcepto())) {
				String valor = swiftDatos.getSocDetallessol().getTipoConcepto();
				if (!StringUtils.isBlank(valor) && valor.equals("INV")) {
					valor = "/" + swiftDatos.getSocDetallessol().getTipoConcepto() + "/";
					valor = valor.concat(swiftDatos.getSocDetallessol().getDetConcepto().trim());
				} else {
					valor = swiftDatos.getSocDetallessol().getDetConcepto().trim();
				}
				field = swiftMessageBcb.setField70(valor);
			}
		} else if (campo.equals("71A")) {
			field = swiftMessageBcb.setField71A(swfMttransferdet.getDttValcampo());
			if (swiftDatos.getSolicitudTO().getSolicitud().getTipoRetencion().equals(Constants.CLAVE_TIPORETENCION_CONDESC)) {
				if (swiftDatos.getSolicitudTO().getSolicitud().getCodMonedat().compareTo(Constants.COD_MONEDA_USD) != 0) {
					field = swiftMessageBcb.setField71A("BEN");
				}
			}

		} else if (campo.equals("71F")) {
			requerido = false;
			// whf: solo en moneda de la union europea exigen el campo 71F
			if (swiftDatos.getSolicitudTO().getSolicitud().getTipoRetencion().equals(Constants.CLAVE_TIPORETENCION_CONDESC)) {
				if (swiftDatos.getSolicitudTO().getSolicitud().getCodMonedat().compareTo(Constants.COD_MONEDA_USD) != 0) {

					SocOpecomiDao socOpecomiDao = new SocOpecomiDao();
					socOpecomiDao.setSessionFactory(getSessionFactory());

					SocOpecomi socOpecomi = socOpecomiDao.getOpeComisByDetCodClaCom(swiftDatos.getSolicitudTO().getSolicitud().getSocCodigo(), 0, "MONTOORDCOMIS");
					if (socOpecomi == null || socOpecomi.getMontoMo().compareTo(BigDecimal.valueOf(0)) <= 0) {
						throw new BusinessException("No se puede hallar MONTOORDCOMIS para Solicitud con descuento " + swiftDatos.getSolicitudTO().getSolicitud().getSocCodigo());
					}

					GenMonedaDao genMonedaDao = new GenMonedaDao();
					genMonedaDao.setSessionFactory(getSessionFactory());

					GenMoneda genMoneda = genMonedaDao.findByCodMoneda(socOpecomi.getCodMoneda());
					BigDecimal montoOrd = socOpecomi.getMontoMo();

					BigDecimal monto = montoOrd.setScale(2, RoundingMode.HALF_UP);

					field = swiftMessageBcb.setField71F(genMoneda.getMonSigla(), monto);
				}
			}
		} else if (campo.equals("72")) {
			boolean esCartas = swiftDatos.getSolicitudTO().getSolicitud().getClaTipo().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS) 
					|| swiftDatos.getSolicitudTO().getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS);
			if (!esCartas) {
				field = swiftMessageBcb.setField72(swiftDatos.getSocDetallessol().getDetInfo());				
			} else {
				field = swiftMessageBcb.setField72SinModificar(swiftDatos.getSocDetallessol().getDetInfo());
			}

			requerido = false;
		} else {
			throw new SwiftAdminException("Campo " + campo + " Cod MT " + swfMttransferdet.getId().getDttCodttransfer() + " no definido avise a sistemas ");
		}

		if (requerido && (field == null || field.isEmpty())) {
			throw new SwiftAdminException("Campo " + campo + " Cod MT " + swfMttransferdet.getId().getDttCodttransfer() + " sin definicion de valor, avise a sistemas");
		}

		if (field != null) {
			log.info(
					"Valor obtenido: " + swfMttransferdet.getId().getDttCodttransfer() + ":" + campo + ":" + swfMttransferdet.getId().getDttBloque() + " => " + field.getValue());
		}

		if (field == null || field.isEmpty()) {
			return null;
		}

		if (field.isEmpty()) {
			return null;
		}

		return field;
	}

	private void llenarBlock12(SwiftMessageBcb swiftMessageBcb, String mttCodttransfer, String bicReceiver) {
		log.debug("Inicio llenar Block12 " + mttCodttransfer + " bicReceiver : " + bicReceiver);
		SwfMttransfer swfMttransfer = swfMttransferLocal.findByCodigo(mttCodttransfer);

		String mt = swfMttransfer.getMttCodmt();

		SwfMttransferdet swfMttransferdet = swfMttransferdetLocal.findByCodigo(mttCodttransfer, ConstantsSwift.CODCAMPO_IDAPP, 1);
//		log.info("XXX: swfMttransferdet " + swfMttransferdet.getDttValcampo());
		String applicationId = swfMttransferdet.getDttValcampo().trim();

		swfMttransferdet = swfMttransferdetLocal.findByCodigo(mttCodttransfer, ConstantsSwift.CODCAMPO_SERVID, 1);
		String serviceId = swfMttransferdet.getDttValcampo().trim();

		String logicalTerminal = getLogicalTerminal(mttCodttransfer);

		swfMttransferdet = swfMttransferdetLocal.findByCodigo(mttCodttransfer, ConstantsSwift.CODCAMPO_SESSNUM, 1);
		String sessionNumber = swfMttransferdet.getDttValcampo().trim();

		swfMttransferdet = swfMttransferdetLocal.findByCodigo(mttCodttransfer, ConstantsSwift.CODCAMPO_SEQNUM, 1);
		String sequenceNumber = swfMttransferdet.getDttValcampo().trim();

		log.info("Preparando mensaje mt " + applicationId + "-" + serviceId + "-" + logicalTerminal + "-" + sessionNumber + "-" + sequenceNumber);
		swiftMessageBcb.createBlock1(applicationId, serviceId, logicalTerminal, sessionNumber, sequenceNumber);

		swfMttransferdet = swfMttransferdetLocal.findByCodigo(mttCodttransfer, ConstantsSwift.CODCAMPO_PRIORITY, 2);
		String messagePriority = swfMttransferdet.getDttValcampo().trim();

		String deliveryMonitoring = null;
		String obsolescencePeriod = null;

		swiftMessageBcb.createBlock2(mt, bicReceiver, messagePriority, deliveryMonitoring, obsolescencePeriod);
	}

	private void llenarBlock3(SwiftMessageBcb swiftMessageBcb, String mt) {
		log.debug("Inicio llenar Block3 " + mt);
		List<SwfMttransferdet> SwfMttransferdetLista = swfMttransferdetLocal.findByCodTTransfer(mt, 3);
		for (SwfMttransferdet swfMttransferdet : SwfMttransferdetLista) {
			swiftMessageBcb.createBlock3(swfMttransferdet.getId().getDttCodcampo(), swfMttransferdet.getDttValcampo());
		}
	}

	private String getLogicalTerminal(String dttCodttransfer) {
		log.debug("Obteniendo LogicalTerminal dttCodttransfer: " + dttCodttransfer);

		SwfMttransferdet swfMttransferdet = swfMttransferdetLocal.findByCodigo(dttCodttransfer, ConstantsSwift.CODCAMPO_LTERMINAL, 1);

		BancoPlaza bancoPlazaSender = socBancosDao.bancoPlazaByCod(Constants.COD_BCB_SWIFT);

		LogicalTerminalAddress logicalTerminalAddress = new LogicalTerminalAddress(bancoPlazaSender.getPlaBic());
		logicalTerminalAddress.setLTIdentifier(swfMttransferdet.getDttValcampo().trim().charAt(0));

//		log.info("swfMttransferdet.getDttValcampo().trim().charAt(0) " + swfMttransferdet.getDttValcampo().trim().charAt(0) + " ::::::: "
//				+ logicalTerminalAddress.getSenderLogicalTerminalAddress());

		return logicalTerminalAddress.getSenderLogicalTerminalAddress();
	}

	private SwfMensaje guardarSwiftObject(SwiftDatos swiftDatos, SwiftMessageBcb swiftMessageBcbIn) {
		log.info("Guardando mensaje y detalles swift:: " + swiftDatos.getSwfMensaje().getMenCodoperacion() + " " + swiftDatos.getSwfMensaje().getMenCodmen());
		try {

			String menPlano = swiftMessageBcbIn.FIN();
			log.info("Guardando swift:: menPlano:: " + menPlano.toUpperCase());

			swiftDatos.getSwfMensaje().setMenPlano(menPlano);

			SwfMensaje swfMensajeNew = swfMensajeLocal.saveorupdate(swiftDatos.getSwfMensaje());

			List<SwfDetmensaje> swfDetmensajeLista = new ArrayList<SwfDetmensaje>();

			// se elimina todos los detalles
			swfDetmensajeLocal.actualizarDetalles(swfMensajeNew, swfDetmensajeLista);

			final SwiftBlock4 b4 = swiftMessageBcbIn.getBlock4();

			if (b4 != null && !b4.isEmpty()) {
				for (Tag t : b4.getTags()) {
					// barremos todos los campos del BLOCK4
					final Field field = t.getField();

					SwfDetmensaje swfDetmensaje = swfDetmensajeLocal.actualizarCampo(swfMensajeNew.getMenCodmen(), field.getName(), 4, field.getValue(),
							swfMensajeNew.getMenAuditusr(), swfMensajeNew.getMenAuditwst());

					swfDetmensajeLista.add(swfDetmensaje);
				}
			}

			swfMensajeNew = swfMensajeLocal.findByCodigo(swfMensajeNew.getMenCodmen());
			swiftDatos.setSwfMensaje(swfMensajeNew);

			log.info("SWIFT Salvado hecho ... " + swfMensajeNew.getMenCodmen() + " " + swfMensajeNew.getMenCodoperacion());
			return swfMensajeNew;
		} catch (Exception e) {
			log.error("Error al actualizar swift " + e.getMessage(), e);
			throw new SwiftAdminException("Error al actualizar swift " + e.getMessage());
		}
	}

	public SwfMensaje actualizarCampo(SwiftDatos swiftDatos, String codCampo, Integer demBloque, String valorCampo) {
		// el objeto es mantener el principio que el mensaje debe ser
		// actualizado a partir de las fuentes
		log.info("actualizarCampo:: " + swiftDatos.getSwfMensaje().getMenCodmen() + " codCampo: " + codCampo + " demBloque:" + demBloque);
		SwiftMessageBcb swiftMessageBcb = new SwiftMessageBcb();

		try {
			swiftMessageBcb.fromString(swiftDatos.getSwfMensaje().getMenPlano());
//			log.info("SMIFT::\n" + swiftMessageBcb.FIN());

			SwfMttransferdet swfMttransferdet = swfMttransferdetLocal.findByCodigo(swiftDatos.getSwfMensaje().getMenCodmt(), codCampo, demBloque);

			Field field = obtenerValor(swiftDatos, swiftDatos.getSwfMensaje(), swiftMessageBcb, swfMttransferdet);
			if (field == null) {
				throw new SwiftAdminException("Error al actualizar swift en " + swiftDatos.getSwfMensaje().getMenCodmen() + " codCampo: " + codCampo + " demBloque:" + demBloque);
			}

			swiftMessageBcb.addField(field);

			String menPlano = swiftMessageBcb.FIN();
			log.info("Guardando swift:: menPlano:: " + menPlano);

			swiftDatos.getSwfMensaje().setMenPlano(menPlano.toUpperCase());

			SwfMensaje swfMensajeNew = swfMensajeLocal.saveorupdate(swiftDatos.getSwfMensaje());

			SwfDetmensaje swfDetmensaje = swfDetmensajeLocal.actualizarCampo(swiftDatos.getSwfMensaje().getMenCodmen(), codCampo, demBloque, field.getValue(),
					swfMensajeNew.getMenAuditusr(), swfMensajeNew.getMenAuditwst());

			swiftDatos.setSwfMensaje(swfMensajeNew);

			log.debug("Detalle mensaje acutliazado ::" + swfDetmensaje.toString());

			return swfMensajeNew;

		} catch (Exception e) {
			log.error("Error al actualizar campo swift " + e.getMessage(), e);
			throw new SwiftAdminException("Error al actualizar campo swift " + e.getMessage(), e);
		}
	}

	private SwfMensaje generarCorrelativoSwiftPortia(SwiftDatos swiftDatos) {
		log.info("Inicio actualizar nro swift " + swiftDatos.getSwfMensaje().getMenCodmen());
		SwfMensaje swfMensaje = swiftDatos.getSwfMensaje();
		// // POOOOOOORTIA
		Map<String, Object> mapaParametros2 = new HashMap<String, Object>();
		mapaParametros2.put("consulta", "crear");
		mapaParametros2.put("usuarioaudit", swfMensaje.getMenAuditusr());
		mapaParametros2.put("estacionaudit", swfMensaje.getMenAuditwst());

		log.debug("Llamando al servicio de portiaswift: obtener numero swift");

		PortiaService portiaService = new PortiaService();
		Map<String, Object> mapaResultado2 = portiaService.executeTask(mapaParametros2);

		Integer codSwift = (Integer) mapaResultado2.get("swift");
		Loader loader = (Loader) mapaResultado2.get("loader");

//		log.info("Inicio portia solicitud de nuevo nro swift");
		log.info("Nro swift Portia asignado " + codSwift + " a mensaje==> " + swfMensaje.getMenCodmen());

		swfMensaje.setMenNrocorr(codSwift);
		SwfMensaje swfMensajeNew = swfMensajeLocal.saveorupdate(swfMensaje);

		swiftDatos.setSwfMensaje(swfMensajeNew);

		LoaderDao loaderDao = new LoaderDao();
		loaderDao.setSessionFactory(PortiaService.getSessionFactory());

		Loader loaderNew = loaderDao.findByCodigo(loader.getIdLoader());

		log.info("loader.getIdLoader() " + loader.getIdLoader() + " " + swfMensajeNew.getMenNrocorr());

		if (loaderNew == null || loaderNew.getNumeroSwift().compareTo(swfMensajeNew.getMenNrocorr()) != 0) {
			throw new SwiftAdminException("Error al actualizar nro swift mensaje " + swfMensaje.getMenCodmen() + " nro asignado no coincide " + swfMensaje.getMenNrocorr());
		}
		log.debug("Fin generara correltativo a mensaje==> " + swfMensajeNew.getMenCodmen());
		return swfMensajeNew;
	}

	private SwfMensaje generarCorrelativoSwiftLavado(SwiftDatos swiftDatos, ClienteLvdSioc clienteLvdSioc) {
		log.info("Inicio actualizar LVD nro swift " + swiftDatos.getSwfMensaje().getMenCodmen());
		SwfMensaje swfMensaje = swiftDatos.getSwfMensaje();
		// // LAVDO
		String codigoOperacion = String.valueOf(swfMensaje.getMenCodoperacion() + "" + swfMensaje.getMenDetcodigo());
		
		SearchResponse searchResponse = clienteLvdSioc.solicitarCorrelativo(codigoOperacion, swfMensaje.getMenAuditusr());
		
		swfMensaje.setMenNrocorr(searchResponse.getNrocorr());
		swfMensaje.setMenNrolavado(Integer.valueOf(searchResponse.getCodoperacion()));

		SwfMensaje swfMensajeNew = swfMensajeLocal.saveorupdate(swfMensaje);

		swiftDatos.setSwfMensaje(swfMensajeNew);
		log.info("Mensaje con correlativo LAVADO: " + swfMensajeNew.getMenCodmen() + " con nro lavado : " + swfMensajeNew.getMenNrolavado() + " y nro correlativo swift : "
				+ swfMensajeNew.getMenNrocorr());
		return swfMensajeNew;
	}

	public SwfMensaje actualizarCorrelativo(SwfMensaje swfMensajePar, String pathSwift, ClienteLvdSioc clienteLvdSioc) {
		log.info("Inicio actualizar correlativo portia " + swfMensajePar.getMenCodmen());

		SwiftDatos swiftDatos = swfMensajeLocal.swiftDatosFromSwfMensaje(swfMensajePar);
		swiftDatos.getSwfMensaje().setMenAuditusr(swfMensajePar.getMenAuditusr());
		swiftDatos.getSwfMensaje().setMenAuditwst(swfMensajePar.getMenAuditwst());

		swiftDatos.setAuditusr(swfMensajePar.getMenAuditusr());
		swiftDatos.setAuditwst(swfMensajePar.getMenAuditwst());

		boolean requiereCorr = requiereCorrelativo(swiftDatos.getSwfMensaje());
		// **** PORTIA ****//
		if (requiereCorr) {
			if (clienteLvdSioc.getClienteLvd() == null && (swiftDatos.getSwfMensaje().getMenNrolavado() == null || swiftDatos.getSwfMensaje().getMenNrolavado().compareTo(0) == 0)){
				// se genera por portia
				generarCorrelativoSwiftPortia(swiftDatos);
			} else {
				generarCorrelativoSwiftLavado(swiftDatos, clienteLvdSioc);
			}
		}

		SwfMensaje swfMensaje = actualizarCampo(swiftDatos, "20", 4, null);
		if (clienteLvdSioc.getClienteLvd() != null) {
			// se realiza el scaneo
			clienteLvdSioc.scanMensaje(swfMensaje);
		}

		swfMensaje = swfMensajeLocal.preAutorizarSwift(swfMensaje, pathSwift);

		log.info("Correlativo SWIFT Actualizado... " + swfMensajePar.getMenCodmen());
		return swfMensaje;
	}

	private boolean requiereCorrelativo(SwfMensaje swfMensaje) {
		if (StringUtils.isBlank(swfMensaje.getMenCveestswift()) || swfMensaje.getMenCveestswift().trim().equals(ConstantsSwift.PAR_ESTSWIFT_AUTO)
				|| swfMensaje.getMenCveestswift().trim().equals(ConstantsSwift.PAR_ESTSWIFT_RECH)) {
			log.error("Error al actualizar nro swift mensaje " + swfMensaje.getMenCodmen() + " con estado " + swfMensaje.getMenCveestswift() + " invalido");
			throw new SwiftAdminException("Error al actualizar nro swift mensaje " + swfMensaje.getMenCodmen() + " con estado " + swfMensaje.getMenCveestswift() + " invalido");
		}

		if (StringUtils.isBlank(swfMensaje.getMenCodusrswf())) {
			log.error("Error al actualizar nro swift mensaje " + swfMensaje.getMenCodmen() + " sin codigo de usuario");
			throw new SwiftAdminException("Error al actualizar nro swift mensaje " + swfMensaje.getMenCodmen() + " sin codigo de usuario");
		}

		if (swfMensaje.getMenNrocorr() != null && swfMensaje.getMenNrocorr().compareTo(0) > 0) {
			// obtenemos el correlativo portia
			LoaderDao loaderDao = new LoaderDao();
			loaderDao.setSessionFactory(PortiaService.getSessionFactory());

			Loader loaderOld = loaderDao.findByNroSwift(swfMensaje.getMenNrocorr());

			log.info("loader.getIdLoaderOld() " + loaderOld.getIdLoader() + " " + swfMensaje.getMenNrocorr());
			if (loaderOld != null) {
				if (loaderOld.getDescrip() != null && loaderOld.getDescrip().trim().equals(Constants.CODAPP_SIOC)) {
					log.info("Correltativo a reutilizar mensaje==> " + swfMensaje.getMenCodmen());
					return false;
				}
			}
		}
		return true;
	}

	public SwfMensaje autorizarMensaje(SwfMensaje swfMensajePar, String pathSwift) {
		SwfMensaje swfMensaje = swfMensajeLocal.autorizarSwift(swfMensajePar, pathSwift);

		return swfMensaje;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
		inicializar();
	}

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void inicializar() {
		swfMttransferLocal.setSessionFactory(getSessionFactory());
		swfMttransferdetLocal.setSessionFactory(getSessionFactory());
		swfPersonactaLocal.setSessionFactory(getSessionFactory());
		swfMensajeLocal.setSessionFactory(getSessionFactory());
		swfDetmensajeLocal.setSessionFactory(getSessionFactory());
		socBancosDao.setSessionFactory(getSessionFactory());
		socBenefsDao.setSessionFactory(getSessionFactory());
	}
}
