package gob.bcb.swift.service;

import gob.bcb.core.utils.ArchivoSinple;
import gob.bcb.core.utils.ArchivoUtil;
import gob.bcb.swift.exception.SwiftAdminException;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;

@Service(value = "archivoSinpleService")
public class ArchivoSinpleServiceImpl implements Serializable {
	private static final Logger log = Logger.getLogger(ArchivoSinpleServiceImpl.class);
	private ArchivoSinple archivoSinple;
	private String extensionFile = "docx";
	private String prefixNameFile = "";

	public ArchivoSinpleServiceImpl() {
		log.debug("ArchivoSinpleService creado...");
	}

	/**
	 * Archivo descargado desde el servidor
	 * 
	 * @param pathFile
	 * @return
	 */
	public ArchivoSinple fromPathfile(String pathFile, String nameFileOriginal) {
		log.info("Cargando archivo de ruta: " + pathFile + " nameFileOriginal " + nameFileOriginal);
		archivoSinple = new ArchivoSinple();
		archivoSinple.setNameOriginal(nameFileOriginal);

		File f = checkFile(pathFile);

		archivoSinple.setDirectory(f.getParent());
		archivoSinple.setName(f.getName());

		putPathFile();

		try {
			byte[] data = FileCopyUtils.copyToByteArray(f);
			writeData(data);

			return archivoSinple;
		} catch (IOException e) {
			throw new SwiftAdminException("Error al copiar data " + e.getMessage(), e);
		} catch (Exception e) {
			throw new SwiftAdminException(e.getMessage(), e);
		}
	}

	public ArchivoSinple fileUpload(InputStream stream, String nameFileOriginal) {
		archivoSinple = new ArchivoSinple();
		archivoSinple.setNameOriginal(nameFileOriginal);
		// ArchivoUtil.obtenerExtension(nameFile);

		try {
			byte[] data = FileCopyUtils.copyToByteArray(stream);
			writeData(data);

			archivoSinple.setName(archivoSinple.getHash() + "." + ArchivoUtil.obtenerExtension(nameFileOriginal));

			return archivoSinple;
		} catch (IOException e) {
			throw new SwiftAdminException("Error al copiar data " + e.getMessage(), e);
		} catch (Exception e) {
			throw new SwiftAdminException(e.getMessage(), e);
		}
	}

	public ArchivoSinple newFromOutputStream(ByteArrayOutputStream baos, String nameFile) {
		archivoSinple = new ArchivoSinple();
		archivoSinple.setNameOriginal(nameFile);
		archivoSinple.setContentType(ArchivoUtil.obtenerMime(nameFile));
		
		byte[] data = baos.toByteArray();
		writeData(data);
		
		String ext = ArchivoUtil.obtenerExtension(nameFile);
		if (ext == null || ext.length() == 0) {
			ext = "";
		} else {
			ext = "." + ext;
		}
		archivoSinple.setName(archivoSinple.getHash() + ext);		
		
		return archivoSinple;
	}

	private void writeData(byte[] data) {
		archivoSinple.setSize(data.length);
		archivoSinple.setData(data);

		try {
			String hash = ArchivoUtil.checkSumFile(archivoSinple.getStream());
			archivoSinple.setHash(hash);
			log.info("Datos archivo completados " + archivoSinple.getSize());
		} catch (Exception e) {
			throw new SwiftAdminException(e.getMessage(), e);
		}
	}

	/**
	 * Setea el nombre del archivo y directorio
	 * 
	 * @param directory
	 * @param nameFile
	 * @param nameFileOriginal
	 *            nombre de archivo que se diferencia con name ya que name
	 *            contiene hash y nameOriginal es uno leible
	 */
	public void settingPathFile(String directory, String nameFile, String nameFileOriginal) {
		archivoSinple.setDirectory(directory);
		archivoSinple.setNameOriginal(nameFileOriginal);
		String ext = ArchivoUtil.obtenerExtension(nameFileOriginal);
		if (ext == null || ext.length() == 0) {
			ext = "";
		} else {
			ext = "." + ext;
		}
		archivoSinple.setName(nameFile + ext);
		putPathFile();
	}

	public ArchivoSinple getArchivoSinple() {
		return archivoSinple;
	}

	public void setArchivoSinple(ArchivoSinple archivoSinple) {
		archivoSinple.setVerified(false);
		this.archivoSinple = archivoSinple;
	}

	public void putPathFile() {
		File h = new File(archivoSinple.getDirectory(), archivoSinple.getName());
		archivoSinple.setPathFile(h.getAbsolutePath());
		archivoSinple.setContentType(ArchivoUtil.obtenerMime(h.getAbsolutePath()));
	}

	/**
	 * Valida el hash del archivo cargado contra el parametro
	 * 
	 * @param hashIn
	 * @return
	 */
	public boolean hashValid(String hashIn) {
		// seteamos que el archivo paso por proceso de verificado
		archivoSinple.setVerified(true);

		if (StringUtils.isBlank(hashIn) || StringUtils.isBlank(archivoSinple.getHash())) {
			archivoSinple.setAccept(false);
		} else {
			archivoSinple.setAccept(archivoSinple.getHash().equals(hashIn));
		}

		return archivoSinple.isAccept();
	}

	private File checkFile(String pathFile) {
		if (StringUtils.isBlank(pathFile)) {
			log.error("Ruta archivo nulo");
			// return;
			throw new SwiftAdminException("Ruta archivo nulo");
		}

		File h = new File(pathFile);
		if (!h.exists() || h.isDirectory()) {
			log.error("Archivo inexistente " + pathFile);
			throw new SwiftAdminException("Archivo inexistente " + pathFile);
		}
		return h;
	}

	public String getPrefixNameFile() {
		return prefixNameFile;
	}

	public void setPrefixNameFile(String prefixNameFile) {
		// archivoSinple.setName(prefixNameFile.concat(archivoSinple.getName()));
		// putPathFile();
		this.prefixNameFile = prefixNameFile;
	}

	public String getExtensionFile() {
		return extensionFile;
	}

	public void setExtensionFile(String extensionFile) {
		this.extensionFile = extensionFile;
	}

	public static void main(String[] args) {
		File h = new File("/tmp/CL01.pdf");
		System.out.println("wsdlURL : " + h.getPath());
		System.out.println("wsdlURL : " + h.getName());
		System.out.println("wsdlURL : " + h.getParent());
		System.out.println("wsdlURL : " + h.getAbsolutePath());
		h = new File(h.getAbsolutePath());
		System.out.println("wsdlURL : " + h.getParent());
		try {
			System.out.println("wsdlURL : " + h.getCanonicalPath());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
