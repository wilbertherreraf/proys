package gob.bcb.swift.service;

import gob.bcb.bpm.pruebaCU.SocBancosDao;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.service.servicioSioc.pojos.BancoPlaza;
import gob.bcb.swift.pojos.Block4;
import gob.bcb.swift.pojos.HeaderMsg;
import gob.bcb.swift.pojos.SwiftDatos;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.prowidesoftware.swift.io.parser.SwiftParser;
import com.prowidesoftware.swift.model.MtSwiftMessage;
import com.prowidesoftware.swift.model.SwiftBlock1;
import com.prowidesoftware.swift.model.SwiftBlock2;
import com.prowidesoftware.swift.model.SwiftBlock2Input;
import com.prowidesoftware.swift.model.SwiftBlock2Output;
import com.prowidesoftware.swift.model.SwiftBlock4;
import com.prowidesoftware.swift.model.SwiftBlock5;
import com.prowidesoftware.swift.model.SwiftMessage;
import com.prowidesoftware.swift.model.Tag;
import com.prowidesoftware.swift.model.field.Field;
import com.prowidesoftware.swift.model.field.Field20;

public abstract class ReporteSwiftAbstract extends ArchivoSinpleServiceImpl {

	private static final Logger log = Logger.getLogger(ReporteSwiftAbstract.class);

	private ArchivoSinpleServiceImpl archivoTemplateReport = new ArchivoSinpleServiceImpl();
	private HeaderMsg headerMsg;
	private List<Block4> block4Lista;
	private SocBancosDao socBancosDao;
	public void populateFieldsReport(String swiftPlano, SwiftDatos mensajesDatos ) throws IOException {

		log.info("En populateFieldsReport: \n" + swiftPlano);

		SwiftParser swiftParser = new SwiftParser(swiftPlano);
		SwiftMessage swiftMessage = swiftParser.message();

		SwiftBlock1 block1 = swiftMessage.getBlock1();

		SwiftBlock2 block2 = swiftMessage.getBlock2();

		final SwiftBlock4 b4 = swiftMessage.getBlock4();

		block4Lista = new ArrayList<Block4>();
		headerMsg = new HeaderMsg();
		headerMsg.setMencodmen(String.valueOf(mensajesDatos.getSwfMensaje().getMenCodmen()));

		headerMsg.setNrocorr("");
		if (mensajesDatos.getSwfMensaje().getMenNrocorr() != null)
			headerMsg.setNrocorr(String.valueOf(mensajesDatos.getSwfMensaje().getMenNrocorr()));

		headerMsg.setOperator((mensajesDatos.getSwfMensaje().getMenCodusrswf() == null ? "" : mensajesDatos.getSwfMensaje().getMenCodusrswf()));

		headerMsg.setCodusuario((mensajesDatos.getAuditusr() == null ? "" : mensajesDatos.getAuditusr()) + " "
				+ (mensajesDatos.getAuditwst() == null ? "" : mensajesDatos.getAuditwst()));

		headerMsg.setPriority(block2.getMessagePriority());

		headerMsg.setNroreference("I");// (swiftBlock2Output.getReceiverOutputTime());

		Field20 field20 = new Field20();
		field20 = (Field20) b4.getFieldByName("20");

		headerMsg.setReference("");
		if (field20 != null)
			headerMsg.setReference((mensajesDatos.getSwfMensaje().getMenFecauto() != null ? UtilsDate.stringFromDate(mensajesDatos.getSwfMensaje()
					.getMenFecauto(), "hhmm yyMMdd") : "")
					+ " " + field20.getValue());

		// headerMsg.setInreference(UtilsDate.stringFromDate(mensajesDatos.getSwfMensaje().getMenFecreg(),
		// "hhmm") + " " + mtSwiftMessage.getMir());
		headerMsg.setMur(swiftMessage.getMUR());

		headerMsg.setMt(swiftMessage.getType());
		headerMsg.setMtdescrip(mensajesDatos.getSwfMttransfer().getMttDescrip());
		headerMsg.setSender(block1.getLogicalTerminal());

		String senderdescrip = (mensajesDatos.getSwfBicsSender().getBicDescrip() == null ? "" : mensajesDatos.getSwfBicsSender().getBicDescrip()
				.trim())
				+ "\n"
				+ (mensajesDatos.getSwfBicsSender().getBicCiudad() == null ? "" : mensajesDatos.getSwfBicsSender().getBicCiudad().trim())
				+ ", " + (mensajesDatos.getSwfBicsSender().getBicPais() == null ? "" : mensajesDatos.getSwfBicsSender().getBicPais().trim());
		headerMsg.setSenderdescrip(senderdescrip);

		headerMsg.setReceiver(swiftMessage.getReceiver());
		headerMsg.setReceiverdescrip((mensajesDatos.getSwfBicsReceiver().getBicDescrip() == null ? "" : mensajesDatos.getSwfBicsReceiver()
				.getBicDescrip().trim()
				+ "\n")
				+ (mensajesDatos.getSwfBicsReceiver().getBicCiudad() == null ? "" : mensajesDatos.getSwfBicsReceiver().getBicCiudad().trim()));

		SwiftBlock5 block5 = swiftMessage.getBlock5();

		if (block5 == null) {
			block5 = new SwiftBlock5();
			headerMsg.setFooter(UtilsDate.stringFromDate(mensajesDatos.getSwfMensaje().getMenAuditfho(), "dd/MM/yyyy hh:mm:ss"));
		} else {
			headerMsg.setFooter(block5.toJson());
		}

		headerMsg.setFechora(UtilsDate.stringFromDate(new Date(), "dd/MM/yyyy hh:mm:ss"));
		
		removeNulsFromHeaderMsg(headerMsg);
		
		if (b4 != null && !b4.isEmpty()) {
			for (Tag t : b4.getTags()) {
				final Field field = t.getField();

				Block4 block = new Block4();
				
				String nomCampo = field.getName();
				String nomBanco = ""; 
				block.setName(field.getName());
				log.info("XXX: nomCampo:: " + nomCampo + " field.getName(): " + field.getName() + " field.getValue():" + field.getValue());
				if (nomCampo.equals("57A") || nomCampo.equals("52A") || nomCampo.equals("56A")){
					
					BancoPlaza  bancoPlaza  = getSocBancosDao().bancoPlazaByBic(field.getValue());
					if (bancoPlaza != null){
						log.info("XXX: bancoPlaza " + bancoPlaza.getBcoNombre());
						nomBanco = bancoPlaza.getBcoNombre();
						nomBanco = nomBanco + "\r\n" + StringUtils.trimToEmpty(bancoPlaza.getPlaNombre());
					}
				}
				//String label = StringEscapeUtils.unescapeHtml(field.getLabel(new Locale("es_ES")));
				String label = StringEscapeUtils.unescapeHtml(field.getLabel(field.getName(), null, null, new Locale("es")));
				log.info(field.getLabel() + " => " + label + " : " + field.getValue());
				
				block.setReference(label);

				String valorfcomponents = "";
				String valorCampo = field.getValue();

				if (valorCampo != null && !StringUtils.isBlank(valorCampo)) {
					String[] valorCampoArra = valorCampo.split("\r\n");
					// longitud hasta el primer salto

					String[] valorCampoArra2 = valorCampoArra[0].split("//");
					int tama = valorCampoArra2[0].length();

					final List<String> components = field.getComponents();
					int tamacompo = 0;
					for (int i = 0; i < components.size(); i++) {
						final String component = components.get(i);

						if (!StringUtils.isBlank(component)) {
							tamacompo = tamacompo + component.length();
							if (tamacompo <= tama) {
								valorfcomponents = valorfcomponents + component + " \t ";
							} else {
								valorfcomponents = valorfcomponents + "\r\n" + component;
							}
						}
					}
				}
				if (!StringUtils.isBlank(nomBanco)){
					valorfcomponents = valorfcomponents + "\r\n" + nomBanco;
				}
				block.setValue(valorfcomponents);

				// campos especiales: algunos campos como p.e. el 57A PROWIDE solo almacena el BIC para el reporte se requiere el nombre de la entidadmas
				
				
				block4Lista.add(block);
			}
		}
	}

	public void populateFieldsReportIn(String swiftPlano, SwiftDatos mensajesDatos) throws IOException {

		log.info(swiftPlano);

		SwiftParser swiftParser = new SwiftParser(swiftPlano);
		SwiftMessage swiftMessage = swiftParser.message();

		MtSwiftMessage mtSwiftMessage = new MtSwiftMessage(swiftMessage);

		log.info("Sender " + swiftMessage.getSender() + " - " + mtSwiftMessage.getSender());

		SwiftBlock1 block1 = swiftMessage.getBlock1();
		// log.info(block1.toJson());

		SwiftBlock2 block2 = swiftMessage.getBlock2();

		SwiftBlock2Output swiftBlock2Output = (SwiftBlock2Output) block2;
		// SwiftBlock2Input swiftBlock2Input = (SwiftBlock2Input) block2;
		// log.info(block2.toJson());

		block4Lista = new ArrayList<Block4>();
		headerMsg = new HeaderMsg();
		headerMsg.setMencodmen(String.valueOf(mensajesDatos.getSwfMensaje().getMenCodmen()));
		headerMsg.setNrocorr("");
		if (mensajesDatos.getSwfMensaje().getMenNrocorr() != null)
			headerMsg.setNrocorr(String.valueOf(mensajesDatos.getSwfMensaje().getMenNrocorr()));

		headerMsg.setCodusuario("");
		if (!StringUtils.isBlank(mensajesDatos.getAuditusr()))
			headerMsg.setCodusuario(mensajesDatos.getAuditusr());

		headerMsg.setPriority(block2.getMessagePriority());

		headerMsg.setNroreference(swiftBlock2Output.getReceiverOutputTime());
		headerMsg.setReference(block1.getApplicationId() + " " + block1.getBlockValue());
		headerMsg.setReference(swiftBlock2Output.getReceiverOutputDate() + block1.getLogicalTerminal() + block1.getSessionNumber()
				+ block1.getSequenceNumber());

		headerMsg.setNroinreference(swiftBlock2Output.getSenderInputTime());
		headerMsg.setInreference(mtSwiftMessage.getMir());
		headerMsg.setInreference(swiftBlock2Output.getMIR());

		headerMsg.setMt(swiftMessage.getType());
		headerMsg.setMtdescrip(mensajesDatos.getSwfMttransfer().getMttDescrip());
		headerMsg.setSender(mensajesDatos.getSwfMensaje().getMenBic());

		String senderdescrip = mensajesDatos.getSwfBicsSender().getBicDescrip() + "\n" + mensajesDatos.getSwfBicsSender().getBicDirecc1() + ", "
				+ mensajesDatos.getSwfBicsSender().getBicCiudad() + ", " + mensajesDatos.getSwfBicsSender().getBicPais();
		headerMsg.setSenderdescrip(senderdescrip);
		headerMsg.setReceiver(mtSwiftMessage.getReceiver());
		headerMsg.setReceiverdescrip(mensajesDatos.getSwfBicsReceiver().getBicDescrip() + "\n" + mensajesDatos.getSwfBicsReceiver().getBicPais());

		SwiftBlock5 block5 = swiftMessage.getBlock5();

		headerMsg.setFooter(block5.toJson());
		headerMsg.setFechora(UtilsDate.stringFromDate(new Date(), "dd/MM/yyyy hh:mm:ss"));

		headerMsg.setMur(mtSwiftMessage.getMur());
		
		removeNulsFromHeaderMsg(headerMsg);
		
		final SwiftBlock4 b4 = swiftMessage.getBlock4();
		if (b4 != null && !b4.isEmpty()) {
			for (Tag t : b4.getTags()) {
				final Field field = t.getField();

				log.info(field.getLabel() + " => " + field.getName() + " : " + field.getValue());

				Block4 block = new Block4();

				block.setName(field.getName());
				String label = StringEscapeUtils.unescapeHtml(field.getLabel(new Locale("es_ES")));
				block.setReference(label);

				String valorf = "";
				String valorfcomponents = "";
				String valorCampo = field.getValue();

				if (valorCampo != null) {
					String[] valorCampoArra = valorCampo.split("\r\n");
					// longitud hasta el primer salto
					int tama = valorCampoArra[0].length();
					String[] valorCampoArra2 = valorCampoArra[0].split("//");
					tama = valorCampoArra2[0].length();
					for (String linea : valorCampoArra) {
						valorf = valorf + "  ::  " + linea;
					}

					final List<String> components = field.getComponents();
					int tamacompo = 0;
					for (int i = 0; i < components.size(); i++) {
						final String component = components.get(i);

						if (!StringUtils.isBlank(component)) {
							tamacompo = tamacompo + component.length();
							if (tamacompo <= tama) {
								valorfcomponents = valorfcomponents + component + " \t ";
							} else {
								valorfcomponents = valorfcomponents + "\r\n" + component;
							}
						}
					}
				}
				block.setValue(valorfcomponents);

				block4Lista.add(block);
			}
		}
	}

	public ArchivoSinpleServiceImpl getArchivoTemplateReport() {
		return archivoTemplateReport;
	}

	public void setArchivoTemplateReport(ArchivoSinpleServiceImpl archivoTemplateReport) {
		this.archivoTemplateReport = archivoTemplateReport;
	}

	public void initArchivoTemplate(InputStream in, String nameReport) {
		archivoTemplateReport = new ArchivoSinpleServiceImpl();
		archivoTemplateReport.fileUpload(in, nameReport);
		archivoTemplateReport.getArchivoSinple().setDirectory("");
	}

	private void removeNulsFromHeaderMsg(HeaderMsg headerMsg) {
		headerMsg.setMencodmen((headerMsg.getMencodmen() == null ? "" : headerMsg.getMencodmen().trim()));
		headerMsg.setOperator((headerMsg.getOperator() == null ? "" : headerMsg.getOperator().trim()));
		headerMsg.setPriority((headerMsg.getPriority() == null ? "" : headerMsg.getPriority().trim()));
		headerMsg.setNroreference((headerMsg.getNroreference() == null ? "" : headerMsg.getNroreference().trim()));
		headerMsg.setReference((headerMsg.getReference() == null ? "" : headerMsg.getReference().trim()));
		headerMsg.setNroinreference((headerMsg.getNroinreference() == null ? "" : headerMsg.getNroinreference().trim()));
		headerMsg.setInreference((headerMsg.getInreference() == null ? "" : headerMsg.getInreference().trim()));
		headerMsg.setMt((headerMsg.getMt() == null ? "" : headerMsg.getMt().trim()));
		headerMsg.setMtdescrip((headerMsg.getMtdescrip() == null ? "" : headerMsg.getMtdescrip().trim()));
		headerMsg.setSender((headerMsg.getSender() == null ? "" : headerMsg.getSender().trim()));
		headerMsg.setSenderdescrip((headerMsg.getSenderdescrip() == null ? "" : headerMsg.getSenderdescrip().trim()));
		headerMsg.setReceiver((headerMsg.getReceiver() == null ? "" : headerMsg.getReceiver().trim()));
		headerMsg.setReceiverdescrip((headerMsg.getReceiverdescrip() == null ? "" : headerMsg.getReceiverdescrip().trim()));
		headerMsg.setMur((headerMsg.getMur() == null ? "" : headerMsg.getMur().trim()));
		headerMsg.setNrocorr((headerMsg.getNrocorr() == null ? "" : headerMsg.getNrocorr().trim()));
		headerMsg.setFooter((headerMsg.getFooter() == null ? "" : headerMsg.getFooter().trim()));
		headerMsg.setFechora((headerMsg.getFechora() == null ? "" : headerMsg.getFechora().trim()));
		headerMsg.setCodusuario((headerMsg.getCodusuario() == null ? "" : headerMsg.getCodusuario().trim()));
	}

	public HeaderMsg getHeaderMsg() {
		return headerMsg;
	}

	public void setHeaderMsg(HeaderMsg headerMsg) {
		this.headerMsg = headerMsg;
	}

	public List<Block4> getBlock4Lista() {
		return block4Lista;
	}

	public void setBlock4Lista(List<Block4> block4Lista) {
		this.block4Lista = block4Lista;
	}

	public SocBancosDao getSocBancosDao() {
		return socBancosDao;
	}

	public void setSocBancosDao(SocBancosDao socBancosDao) {
		this.socBancosDao = socBancosDao;
	}

}
