package gob.bcb.swift.service;

import org.hibernate.SessionFactory;

import gob.bcb.service.servicioSioc.ClienteLvdSioc;
import gob.bcb.swift.model.SwfMensaje;
import gob.bcb.swift.pojos.SwiftDatos;

public interface SwiftMessageServiceLocal {

	SwfMensaje actualizarCampo(SwiftDatos swiftDatos, String codCampo, Integer demBloque, String valorCampo);

	void setSessionFactory(SessionFactory sessionFactory);

	SwfMensaje actualizarCorrelativo(SwfMensaje swfMensajePar, String pathSwift, ClienteLvdSioc clienteLvdSioc);

	SwfMensaje autorizarMensaje(SwfMensaje swfMensajePar, String pathSwift);


}
