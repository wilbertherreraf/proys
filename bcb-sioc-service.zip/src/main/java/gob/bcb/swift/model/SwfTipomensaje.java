package gob.bcb.swift.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the swf_tipomensaje database table.
 * 
 */
@Entity
@Table(name="swf_tipomensaje")
public class SwfTipomensaje implements Serializable, DomainObject {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="tim_codmt")
	private String timCodmt;

	@Column(name="tim_descrip")
	private String timDescrip;

	@Column(name="tim_info")
	private String timInfo;

	@Column(name="tim_tabtipmensa")
	private Integer timTabtipmensa;

	@Column(name="tim_tipmensa")
	private Integer timTipmensa;

	public SwfTipomensaje() {
	}

	public String getTimCodmt() {
		return this.timCodmt;
	}

	public void setTimCodmt(String timCodmt) {
		this.timCodmt = timCodmt;
	}

	public String getTimDescrip() {
		return this.timDescrip;
	}

	public void setTimDescrip(String timDescrip) {
		this.timDescrip = timDescrip;
	}

	public String getTimInfo() {
		return this.timInfo;
	}

	public void setTimInfo(String timInfo) {
		this.timInfo = timInfo;
	}

	public Integer getTimTabtipmensa() {
		return this.timTabtipmensa;
	}

	public void setTimTabtipmensa(Integer timTabtipmensa) {
		this.timTabtipmensa = timTabtipmensa;
	}

	public Integer getTimTipmensa() {
		return this.timTipmensa;
	}

	public void setTimTipmensa(Integer timTipmensa) {
		this.timTipmensa = timTipmensa;
	}

}