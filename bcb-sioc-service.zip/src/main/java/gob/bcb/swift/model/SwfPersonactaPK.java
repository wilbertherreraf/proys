package gob.bcb.swift.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class SwfPersonactaPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name = "pec_codpersona")
	private String pecCodpersona;
	@Column(name = "pec_codinst")
	private String pecCodinst;
	@Column(name = "pec_nrocta")
	private String pecNrocta;
	
	public String getPecCodpersona() {
		return pecCodpersona;
	}
	public void setPecCodpersona(String pecCodpersona) {
		this.pecCodpersona = pecCodpersona;
	}
	public String getPecCodinst() {
		return pecCodinst;
	}
	public void setPecCodinst(String pecCodinst) {
		this.pecCodinst = pecCodinst;
	}
	public String getPecNrocta() {
		return pecNrocta;
	}
	public void setPecNrocta(String pecNrocta) {
		this.pecNrocta = pecNrocta;
	}
	
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((pecCodinst == null) ? 0 : pecCodinst.hashCode());
		result = prime * result + ((pecCodpersona == null) ? 0 : pecCodpersona.hashCode());
		result = prime * result + ((pecNrocta == null) ? 0 : pecNrocta.hashCode());
		return result;
	}
	
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SwfPersonactaPK other = (SwfPersonactaPK) obj;
		if (pecCodinst == null) {
			if (other.pecCodinst != null)
				return false;
		} else if (!pecCodinst.equals(other.pecCodinst))
			return false;
		if (pecCodpersona == null) {
			if (other.pecCodpersona != null)
				return false;
		} else if (!pecCodpersona.equals(other.pecCodpersona))
			return false;
		if (pecNrocta == null) {
			if (other.pecNrocta != null)
				return false;
		} else if (!pecNrocta.equals(other.pecNrocta))
			return false;
		return true;
	}

}
