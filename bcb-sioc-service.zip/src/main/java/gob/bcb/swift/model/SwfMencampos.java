package gob.bcb.swift.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the swf_mencampos database table.
 * 
 */
@Entity
@Table(name="swf_mencampos")
public class SwfMencampos implements Serializable, DomainObject {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SwfMencamposPK id;

	@Column(name="mtf_descrip")
	private String mtfDescrip;

	@Column(name="mtf_reglavalid")
	private String mtfReglavalid;

	@Column(name="mtf_status")
	private String mtfStatus;

	//uni-directional many-to-one association to SwfTipomensaje
//	@ManyToOne
//	@JoinColumn(name="mtf_codmt", insertable = false, updatable=false)
//	private SwfTipomensaje swfTipomensaje;

	public SwfMencampos() {
	}

	public SwfMencamposPK getId() {
		return this.id;
	}

	public void setId(SwfMencamposPK id) {
		this.id = id;
	}

	public String getMtfDescrip() {
		return this.mtfDescrip;
	}

	public void setMtfDescrip(String mtfDescrip) {
		this.mtfDescrip = mtfDescrip;
	}

	public String getMtfReglavalid() {
		return this.mtfReglavalid;
	}

	public void setMtfReglavalid(String mtfReglavalid) {
		this.mtfReglavalid = mtfReglavalid;
	}

	public String getMtfStatus() {
		return this.mtfStatus;
	}

	public void setMtfStatus(String mtfStatus) {
		this.mtfStatus = mtfStatus;
	}

//	public SwfTipomensaje getSwfTipomensaje() {
//		return this.swfTipomensaje;
//	}
//
//	public void setSwfTipomensaje(SwfTipomensaje swfTipomensaje) {
//		this.swfTipomensaje = swfTipomensaje;
//	}

}