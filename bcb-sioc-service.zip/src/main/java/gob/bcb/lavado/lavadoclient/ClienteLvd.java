package gob.bcb.lavado.lavadoclient;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CharsetEncoder;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import gob.bcb.lavado.client.HandlerGeneratorLauCli;
import gob.bcb.lavado.client.pojos.SearchResponse;

public class ClienteLvd {
	private final Logger log = LoggerFactory.getLogger(ClienteLvd.class);
	public static final String PATH_RESOURCE_API_SEARCH = "/api/_search";	
	public final static String SCAN_SWIFT_GET_INISESSION = PATH_RESOURCE_API_SEARCH
			+ "/lvd-inisesion?codapp={codapp}&coduser={coduser}&tenc={tenc}&ctrlcode={ctrlcode}&ctrldata={ctrldata}";
	public final static String SCAN_SWIFT_GET_SESSION = PATH_RESOURCE_API_SEARCH
			+ "/lvd-inicia?codapp={codapp}&coduser={coduser}";	
	public final static String SCAN_SWIFT_SOLICITARCORR_RESOURCE = PATH_RESOURCE_API_SEARCH
			+ "/scan-correlativo?codapp={codapp}&idop={idop}&coduser={coduser}&idsession={idsession}";
	
	public final static String SCAN_SWIFT_SCANREGISTROLAU_RESOURCE = PATH_RESOURCE_API_SEARCH
			+ "/scan-registro?codapp={codapp}&coduser={coduser}&codlvd={codlvd}&nroswf={nroswf}&idop={idop}&idsession={idsession}&swfp={swfp}&clau={clau}";	
	public final static String SCAN_SWIFT_SCANREGISTRO_RESOURCE = PATH_RESOURCE_API_SEARCH
			+ "/scan-registro?codapp={codapp}&coduser={coduser}&codlvd={codlvd}&nroswf={nroswf}&idop={idop}&idsession={idsession}&swfp={swfp}";
	
	public final static String SCAN_SWIFT_PREAUTLAU_RESOURCE = PATH_RESOURCE_API_SEARCH
			+ "/scan-preaut?codapp={codapp}&coduser={coduser}&codlvd={codlvd}&nroswf={nroswf}&idop={idop}&idsession={idsession}&swfp={swfp}&clau={clau}";	
	public final static String SCAN_SWIFT_PREAUT_RESOURCE = PATH_RESOURCE_API_SEARCH
			+ "/scan-preaut?codapp={codapp}&coduser={coduser}&codlvd={codlvd}&nroswf={nroswf}&idop={idop}&idsession={idsession}&swfp={swfp}";
	
	public final static String SCAN_SWIFT_END_SESSION = PATH_RESOURCE_API_SEARCH + "/lvd-fin?codapp={codapp}&coduser={coduser}&idsession={idsession}";

	public final static String SCAN_SWIFT_SINGLE_RESOURCE = PATH_RESOURCE_API_SEARCH + "/scan-single?query={query}";
	public final static String SCAN_SWIFT_BY_CODSTRATEGY = PATH_RESOURCE_API_SEARCH + "/scan-field?query={query}&field={field}";

	private String urlBase;
	private String protocol;
	private String host;
	private String nameContextSite;
	private int port;
	protected static ObjectMapper mapper = new ObjectMapper();

	private RestTemplate template;

	public ClienteLvd(String url, String pathBase, String idGenerator) {

		this.urlBase = url;
		try {
			HandlerGeneratorLauCli.initCurrentInstance(pathBase, idGenerator);

			URI uri = new URI(url);
			this.protocol = uri.getScheme();
			this.host = uri.getHost();
			this.port = uri.getPort();
			this.nameContextSite = uri.getPath();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			template = new RestTemplate();
		} catch (Exception e) {
			log.error("Error al desparcear URL " + e.getMessage(), e);
		}
	}

	/**
	 * Solicita sesión en el servidor de lavado, envia el lau de codapp y
	 * coduser
	 * 
	 * @param codapp
	 * @param coduser
	 * @return
	 * @throws Exception
	 */
	public SearchResponse getIniSessionLavado(String codapp, String coduser) throws Exception {
		log.info("======@ getIniSessionLavado @====== ");

		String url = getUrlResouce(SCAN_SWIFT_GET_INISESSION);
		log.info("Consultando... " + url);

		Map<String, String> params = new HashMap<String, String>();
		params.put("codapp", codapp);
		params.put("coduser", coduser);

		HandlerGeneratorLauCli.getCurrentInstanceHGenCli().generateToken(params);

		String searchResponses = template.getForEntity(url, String.class, params).getBody();
		SearchResponse searchResponse = deserialize(searchResponses);
		//log.info("idresponse: {} {} {} {}", searchResponse.getCodResp(), searchResponse.getDescripResp(), searchResponse.getCodResplau(), searchResponse.getDescripResp());

		boolean requireSend = HandlerGeneratorLauCli.getCurrentInstanceHGenCli().processResponse(searchResponse);

		if (requireSend) {
			log.info("Reenviando mensaje por razon de respuesta lau");
			params = new HashMap<String, String>();
			params.put("codapp", codapp);
			params.put("coduser", coduser);

			HandlerGeneratorLauCli.getCurrentInstanceHGenCli().generateToken(params);

			searchResponses = template.getForEntity(url, String.class, params).getBody();
			searchResponse = deserialize(searchResponses);
//			log.info("respuesta de reenvio: {} {} {} {}", searchResponse.getCodResp(), searchResponse.getDescripResp(), searchResponse.getCodResplau(),
//					searchResponse.getDescripResp());
		}

		return searchResponse;
	}

	public SearchResponse getSessionLavado(String codapp, String coduser) throws Exception {
		log.info("======@ getSessionLavado @====== ");

		String url = getUrlResouce(SCAN_SWIFT_GET_SESSION);
		log.info("Consultando... " + url);

		Map<String, String> params = new HashMap<String, String>();
		params.put("codapp", codapp);
		params.put("coduser", coduser);

		String searchResponses = template.getForEntity(url, String.class, params).getBody();
		SearchResponse searchResponse = deserialize(searchResponses);
//		log.info("idresponse: {} {} {} {}", searchResponse.getCodResp(), searchResponse.getDescripResp(), searchResponse.getCodResplau(), searchResponse.getDescripResp());
		return searchResponse;
	}
	
	public SearchResponse solicitarCorrelativo(String codapp, String codoperacion, String coduser, String idsession) throws Exception {
		log.info("======@ solicitarCorrelativo @======");
		String url = getUrlResouce(SCAN_SWIFT_SOLICITARCORR_RESOURCE);
		log.info("Consultando... " + url);

		Map<String, String> params = new HashMap<String, String>();
		params.put("codapp", codapp);
		params.put("idop", codoperacion);
		params.put("coduser", coduser);
		params.put("idsession", idsession);

		HandlerGeneratorLauCli.getCurrentInstanceHGenCli().generateToken(params);

		String searchResponses = template.getForEntity(url, String.class, params).getBody();
		SearchResponse searchResponse = deserialize(searchResponses);

		return searchResponse;
	}

	public SearchResponse scanSwiftRegistro(String codapp, String coduser, Integer codlvd, Integer nroswf, String idoperacion, String idsession, String menPlano)
			throws Exception {
		log.info("======@ scanSwiftRegistro @======");
		Map<String, String> params = new HashMap<String, String>();
		String url = getUrlResouce(SCAN_SWIFT_SCANREGISTRO_RESOURCE);

		menPlano = convertToUtf8(menPlano, "ISO-8859-1");
		
		String codelau = HandlerGeneratorLauCli.getCurrentInstanceHGenCli().generateTokenForMsg(menPlano);
		if (!StringUtils.isBlank(codelau)){
			log.info("->Envio de mensaje con LAU {}", codelau);
			url = getUrlResouce(SCAN_SWIFT_SCANREGISTROLAU_RESOURCE);
			params.put("clau", codelau);
		}
		
		menPlano = URLEncoder.encode(menPlano, "UTF-8").replace("+", "%20");
		log.info("-----( salida ) -----");
		log.info(menPlano);
		params.put("codapp", codapp);
		params.put("coduser", coduser);
		params.put("codlvd", String.valueOf(codlvd));
		params.put("nroswf", String.valueOf(nroswf));
		params.put("idop", idoperacion);
		params.put("idsession", idsession);
		params.put("swfp", menPlano);

		log.info("Consultando scanSwiftRegistro ... " + url);
		String searchResponses = template.getForEntity(url, String.class, params).getBody();
		SearchResponse searchResponse = deserialize(searchResponses);

		return searchResponse;
	}

	public SearchResponse preautorizarSwift(String codapp, String coduser, Integer codlvd, Integer nroswf, String idoperacion, String idsession, String menPlano)
			throws Exception {
		Map<String, String> params = new HashMap<String, String>();		
		log.info("======@ preautorizarSwift @======");
		String url = getUrlResouce(SCAN_SWIFT_PREAUT_RESOURCE);
		
		menPlano = convertToUtf8(menPlano, "ISO-8859-1");
		log.info(menPlano);
		
		String codelau = HandlerGeneratorLauCli.getCurrentInstanceHGenCli().generateTokenForMsg(menPlano);
		if (!StringUtils.isBlank(codelau)){
			log.info("->Envio de mensaje con LAU {}", codelau);
			url = getUrlResouce(SCAN_SWIFT_PREAUTLAU_RESOURCE);
			params.put("clau", codelau);
		}
		
		menPlano = URLEncoder.encode(menPlano, "UTF-8").replace("+", "%20");

		log.info("Consultando... " + url);
		log.info("******************************************************************************");
		log.info(menPlano);
		log.info("******************************************************************************");		
		params.put("codapp", codapp);
		params.put("coduser", coduser);
		params.put("codlvd", String.valueOf(codlvd));
		params.put("nroswf", String.valueOf(nroswf));
		params.put("idop", idoperacion);
		params.put("idsession", idsession);
		params.put("swfp", menPlano);
		String urlParm = "http://10.3.11.170:8080/lavado/api/_search/scan-preaut?codapp="+codapp+"&coduser="+coduser+"&codlvd=" +codlvd+"&nroswf=" +nroswf+"&idop=" +idoperacion+"&idsession=" +idsession+"&swfp=" +menPlano+"&clau="+codelau;
		log.info("......................................................");
		log.info(urlParm);
		log.info("......................................................");		
		String searchResponses = template.getForEntity(url, String.class,params).getBody();
		SearchResponse searchResponse = deserialize(searchResponses);

		return searchResponse;
	}

	public SearchResponse postSessionLavado(String codapp, String coduser, String idsession) throws Exception {
		log.info("======@ postSessionLavado @====== ");

		String url = getUrlResouce(SCAN_SWIFT_END_SESSION);
		log.info("Consultando... " + url);

		Map<String, String> params = new HashMap<String, String>();
		params.put("codapp", codapp);
		params.put("coduser", coduser);
		params.put("idsession", idsession);

		HandlerGeneratorLauCli.getCurrentInstanceHGenCli().generateToken(params);

		String searchResponses = template.getForEntity(url, String.class, params).getBody();
		SearchResponse searchResponse = deserialize(searchResponses);

		return searchResponse;
	}

	/**
	 * Consulta rest para un mensaje plano retornando cadena url:
	 * /api/_search/scan-single?query={query}
	 * 
	 * @param menPlano
	 *            mensaje swift en formato plano
	 * @return
	 * @throws Exception
	 */
	public SearchResponse scanMsgPlanoSingleFromString(String menPlano) throws Exception {
		log.info("======@ Scan Single Msg Plano @======");
		log.info(menPlano);
		menPlano = URLEncoder.encode(menPlano, "UTF-8").replace("+", "%20");
		String url = getUrlResouce(SCAN_SWIFT_SINGLE_RESOURCE);
		log.info("Consultando... " + url);

		Map<String, String> params = new HashMap<String, String>();
		params.put("query", menPlano);
		template = new RestTemplate();
		String searchResponses = template.getForEntity(url, String.class, params).getBody();
		SearchResponse searchResponse = deserialize(searchResponses);
		log.info("respuesta servidor rest " + searchResponse.getCodResp() + " - " + searchResponse.getDescripResp());
		return searchResponse;
	}

	/**
	 * Consulta rest para una consulta y
	 * /api/_search/scan-field?query={query}&field={field}
	 * 
	 * @param query
	 *            texto a buscar
	 * @param field
	 *            id de la estrategia
	 * @return
	 * @throws Exception
	 */
	public SearchResponse searchQueryByFieldFromString(String query, String field) throws Exception {
		log.info("======@ Scan Field @======");
		log.info("Field: " + field + " " + query);
		String url = getUrlResouce(SCAN_SWIFT_BY_CODSTRATEGY);
		log.info("Consultando... " + url);

		template = new RestTemplate();

		Map<String, String> params = new HashMap<String, String>();
		params.put("query", query);
		params.put("field", field);

		String searchResponses = template.getForEntity(url, String.class, params).getBody();
		SearchResponse searchResponse = deserialize(searchResponses);

		return searchResponse;
	}

	public static String convertToUtf8(String input, String encoding) {
		CharsetDecoder decoder = Charset.forName("UTF-8").newDecoder();
		CharsetEncoder encoder = Charset.forName(encoding).newEncoder();
		ByteBuffer tmp;
		try {
			tmp = encoder.encode(CharBuffer.wrap(input));
		} catch (CharacterCodingException e) {
			return input;
		}

		try {
			return decoder.decode(tmp).toString();
		} catch (CharacterCodingException e) {
			return input;
		}

	}

	public String getUrlResouce(String endpoint) throws MalformedURLException {
		log.debug("endpoint " + endpoint);
		String nContextSite = "";
		if (nameContextSite.startsWith("/")) {
			nContextSite = nameContextSite;
		} else {
			nContextSite = "/" + nameContextSite;
		}

		URL base = new URL(protocol, host, port, nContextSite);
		String url = fullUrl(base.toString(), endpoint);

		return url;
	}

	private String fullUrl(String baseUrl, String end) {
		String base = !baseUrl.endsWith("/") ? baseUrl + "/" : baseUrl;
		String newEnd = end.startsWith("/") ? end.substring(1) : end;
		return base + newEnd;
	}

	public static SearchResponse deserialize(String object) {
		try {
			return mapper.readValue(object, SearchResponse.class);
		} catch (IOException e) {
			throw new IllegalArgumentException("Unserializable " + object.getClass().getName() + " -> " + object.toString());
		}
	}

	public static void main(String[] args) throws UnsupportedEncodingException {
		String menPlano = URLEncoder.encode("asdf asdf as *asdf* ", "UTF-8");
		System.out.println(menPlano);
	}
}
