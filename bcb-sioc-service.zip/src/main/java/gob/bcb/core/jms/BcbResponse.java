package gob.bcb.core.jms;

import gob.bcb.core.jms.model.Msgbcbresp;

import java.util.Date;
import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public interface BcbResponse {

	/**
	 * Obtiene el id de esta respuesta. En algunos casos podr a ser el mismo Id
	 * del request.
	 * 
	 * @return El id de esta respuesta
	 */
	String getResponseId();

	String getStatusCode();

	String getStatusDescription();
	Date getReceivedDate();
	void updateMsgsistemaresp(String statusCode, String statusDescription, Object tipoJAXBEleASubtituir);
	String toString(Object value) throws JAXBException, ParserConfigurationException, TransformerException;

	Msgbcbresp getMsgBcbresp();
}
