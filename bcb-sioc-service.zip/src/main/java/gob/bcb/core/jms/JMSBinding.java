package gob.bcb.core.jms;

import java.io.File;

import java.io.InputStream;
import java.io.Reader;
import java.io.Serializable;
import java.nio.ByteBuffer;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import javax.jms.BytesMessage;
import javax.jms.DeliveryMode;
import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.MessageFormatException;
import javax.jms.ObjectMessage;
import javax.jms.Session;
import javax.jms.StreamMessage;
import javax.jms.TextMessage;

import static gob.bcb.core.jms.JmsMessageType.Blob;
import static gob.bcb.core.jms.JmsMessageType.Bytes;
import static gob.bcb.core.jms.JmsMessageType.Map;
import static gob.bcb.core.jms.JmsMessageType.Object;
import static gob.bcb.core.jms.JmsMessageType.Stream;
import static gob.bcb.core.jms.JmsMessageType.Text;
import org.apache.log4j.Logger;
import org.w3c.dom.Node;

public class JMSBinding {
	private static Logger LOG = Logger.getLogger(BcbRequestImpl.class);
	private Set<String> outFilter;
	private final static String regex = "(BCB)[a-z|A-Z]";
	private Pattern pattern = Pattern.compile(regex);

	public JMSBinding() {
		initialize();
	}

	public void setOutFilter(Set<String> outFilter) {
		this.outFilter = outFilter;
	}

	public Set<String> getOutFilter() {
		if (outFilter == null) {
			outFilter = new HashSet<String>();
		}

		return outFilter;
	}

	public Object extractBodyFromJms(Message message) {
		try {
			if (message instanceof ObjectMessage) {
				if (LOG.isTraceEnabled()) {
					LOG.trace("Extracting body as a ObjectMessage from JMS message: " + message);
				}
				ObjectMessage objectMessage = (ObjectMessage) message;
				Object payload = objectMessage.getObject();

				return payload;

			} else if (message instanceof TextMessage) {
				if (LOG.isTraceEnabled()) {
					LOG.trace("Extracting body as a TextMessage from JMS message: " + message);
				}
				TextMessage textMessage = (TextMessage) message;
				return textMessage.getText();
			} else if (message instanceof MapMessage) {
				if (LOG.isTraceEnabled()) {
					LOG.trace("Extracting body as a MapMessage from JMS message: " + message);
				}
				return createMapFromMapMessage((MapMessage) message);
			} else if (message instanceof BytesMessage) {
				if (LOG.isTraceEnabled()) {
					LOG.trace("Extracting body as a BytesMessage from JMS message: " + message);
				}
				return createByteArrayFromBytesMessage((BytesMessage) message);
			} else if (message instanceof StreamMessage) {
				if (LOG.isTraceEnabled()) {
					LOG.trace("Extracting body as a StreamMessage from JMS message: " + message);
				}
				return message;
			} else {
				return null;
			}
		} catch (JMSException e) {
			throw new RuntimeException("Failed to extract body due to: " + e + ". Message: " + message, e);
		}
	}

	public Map<String, Object> extractHeadersFromJms(Message jmsMessage) {
		Map<String, Object> map = new HashMap<String, Object>();
		if (jmsMessage != null) {
			// lets populate the standard JMS message headers
			try {
				map.put("JMSCorrelationID", jmsMessage.getJMSCorrelationID());
				map.put("JMSDeliveryMode", jmsMessage.getJMSDeliveryMode());
				map.put("JMSDestination", jmsMessage.getJMSDestination());
				map.put("JMSExpiration", jmsMessage.getJMSExpiration());
				map.put("JMSMessageID", jmsMessage.getJMSMessageID());
				map.put("JMSPriority", jmsMessage.getJMSPriority());
				map.put("JMSRedelivered", jmsMessage.getJMSRedelivered());
				map.put("JMSTimestamp", jmsMessage.getJMSTimestamp());

				// to work around OracleAQ not supporting the JMSReplyTo header
				// (CAMEL-2909)
				try {
					map.put("JMSReplyTo", jmsMessage.getJMSReplyTo());
				} catch (JMSException e) {
					LOG.trace("Cannot read JMSReplyTo header. Will ignore this exception.", e);
				}
				// to work around OracleAQ not supporting the JMSType header
				// (CAMEL-2909)
				try {
					map.put("JMSType", jmsMessage.getJMSType());
				} catch (JMSException e) {
					LOG.trace("Cannot read JMSType header. Will ignore this exception.", e);
				}

				// this works around a bug in the ActiveMQ property handling
				map.put("JMSXGroupID", jmsMessage.getStringProperty("JMSXGroupID"));
			} catch (JMSException e) {
				throw new RuntimeException(e);
			}

			Enumeration names;
			try {
				names = jmsMessage.getPropertyNames();
			} catch (JMSException e) {
				throw new RuntimeException(e);
			}
			while (names.hasMoreElements()) {
				String name = names.nextElement().toString();
				try {
					Object value = jmsMessage.getObjectProperty(name);
					String key = name;

					if (map.containsKey(key) || !getOutFilter().contains(key))
						continue;

					map.put(key, value);
				} catch (JMSException e) {
					throw new RuntimeException(name, e);
				}
			}
		}

		return map;
	}

	public Object getObjectProperty(Message jmsMessage, String name) throws JMSException {
		// try a direct lookup first
		Object answer = jmsMessage.getObjectProperty(name);
		if (answer == null) {
			// then encode the key and do another lookup
			String key = name;
			answer = jmsMessage.getObjectProperty(key);
		}
		return answer;
	}

	protected byte[] createByteArrayFromBytesMessage(BytesMessage message) throws JMSException {
		message.reset();
		if (message.getBodyLength() > Integer.MAX_VALUE) {
			LOG.warn("Length of BytesMessage is too long: " + message.getBodyLength());
			return null;
		}
		byte[] result = new byte[(int) message.getBodyLength()];
		message.readBytes(result);
		return result;
	}

	protected Message createJmsMessage(Exception cause, Session session) throws JMSException {
		if (LOG.isTraceEnabled()) {
			LOG.trace("Using JmsMessageType: " + Object);
		}
		return session.createObjectMessage(cause);
	}

	protected Message createJmsMessage(Object body, Map<String, Object> headers, Session session) throws JMSException {
		JmsMessageType type = null;

		type = getJMSMessageTypeForBody(body, headers, session);

		// create the JmsMessage based on the type
		if (type != null) {
			Message answer = createJmsMessageForType(body, headers, session, type);
			// ensure default delivery mode is used by default
			//answer.setJMSDeliveryMode(Message.DEFAULT_DELIVERY_MODE);
			answer.setJMSDeliveryMode(DeliveryMode.NON_PERSISTENT);
			return answer;
		} else if (body instanceof Message) {
			Message answer = (Message) body;
			if (headers != null && !headers.isEmpty())
				setPropertiesFromMap(answer, headers);
			//answer.setJMSDeliveryMode(Message.DEFAULT_DELIVERY_MODE);
			answer.setJMSDeliveryMode(DeliveryMode.NON_PERSISTENT);
			return answer;
		}

		// warn if the body could not be mapped
		if (body != null && LOG.isDebugEnabled()) {
			LOG.warn("Cannot determine specific JmsMessage type to use from body class." + " Will use generic JmsMessage." + " Body class: "
					+ ". If you want to send a POJO then your class might need to implement java.io.Serializable"
					+ ", or you can force a specific type by setting the jmsMessageType option on the JMS endpoint.");
		}

		// return a default message
		Message answer = session.createMessage();
		// ensure default delivery mode is used by default
		//answer.setJMSDeliveryMode(Message.DEFAULT_DELIVERY_MODE);
		answer.setJMSDeliveryMode(DeliveryMode.NON_PERSISTENT);
		return answer;
	}

	protected JmsMessageType getJMSMessageTypeForBody(Object body, Map<String, Object> headers, Session session) {
		JmsMessageType type = null;
		// let body determine the type
		if (body instanceof Node || body instanceof String) {
			type = Text;
		} else if (body instanceof byte[] || body instanceof File || body instanceof Reader || body instanceof InputStream
				|| body instanceof ByteBuffer) {
			type = Bytes;
		} else if (body instanceof Map) {
			type = Map;
		} else if (body instanceof Serializable) {
			type = Object;
		}
		return type;
	}

	/**
	 * 
	 * Create the {@link Message}
	 * 
	 * @return jmsMessage or null if the mapping was not successfully
	 */
	protected Message createJmsMessageForType(Object body, Map<String, Object> headers, Session session, JmsMessageType type) throws JMSException {
		switch (type) {
		case Text: {
			TextMessage message = session.createTextMessage();
			String payload = (String) body;
			message.setText(payload);
			return message;
		}
		case Bytes: {
			BytesMessage message = session.createBytesMessage();
			byte[] payload = (byte[]) body;
			message.writeBytes(payload);
			if (headers != null && !headers.isEmpty())
				setPropertiesFromMap(message, headers);
			return message;
		}
		case Map: {
			MapMessage message = session.createMapMessage();
			Map payload = (Map) body;
			populateMapMessage(message, payload);
			if (headers != null && !headers.isEmpty())
				setPropertiesFromMap(message, headers);
			return message;
		}
		case Object:
			Serializable payload;
			try {
				payload = (Serializable) body;
			} catch (Exception e) {
				// cannot convert to serializable then thrown an exception to
				// avoid sending a null message
				JMSException cause = new MessageFormatException(e.getMessage());
				cause.initCause(e);
				throw cause;
			}
			ObjectMessage objectMessage = session.createObjectMessage();
			objectMessage.setObject(payload);
			if (headers != null && !headers.isEmpty())
				setPropertiesFromMap(objectMessage, headers);			
			//return session.createObjectMessage(payload);
			return objectMessage;
		default:
			break;
		}
		return null;
	}

	protected void populateMapMessage(MapMessage message, Map<?, ?> map) throws JMSException {
		for (Object key : map.keySet()) {
			String keyString = (String) key;
			if (keyString != null) {
				message.setObject(keyString, map.get(key));
			}
		}
	}

	public Map<String, Object> createMapFromMapMessage(MapMessage message) throws JMSException {
		Map<String, Object> answer = new HashMap<String, Object>();
		Enumeration names = message.getMapNames();

		while (names.hasMoreElements()) {
			String name = names.nextElement().toString();
			Object value = message.getObject(name);
			answer.put(name, value);
		}
		return answer;
	}

	public Map<String, Object> getParamsFromMessage(Message message, Map<String, Object> prop) throws JMSException {
		Map<String, Object> map = new HashMap<String, Object>();
		Enumeration names;
		try {
			names = message.getPropertyNames();
		} catch (JMSException e) {
			throw new RuntimeException(e);
		}
		while (names.hasMoreElements()) {
			String headerName = names.nextElement().toString();
			if (getOutFilter().contains(headerName) || prop.containsKey(headerName))
				// si es un parametro que inicia con BCB no se considera ya que
				// es de propiedades
				continue;

			Object value = message.getObjectProperty(headerName);
			map.put(headerName, value);
		}
		return map;
	}

	protected void initialize() {
		getOutFilter().add("BCBAddress");
		getOutFilter().add("BCBIdemisor");
		getOutFilter().add("BCBIddestinatario");
		getOutFilter().add("BCBIdusuario");
		getOutFilter().add("BCBPasswmd5");
		getOutFilter().add("BCBIdsistema");
		getOutFilter().add("BCBNrooperacion");
		getOutFilter().add("BCBIdoperacion");
		getOutFilter().add("BCBDescripcion");
		getOutFilter().add("BCBCodestadoresp");
	}

	public void setPropertiesFromMap(Message jmsMessage, Map<String, Object> map) throws JMSException {
		for (Map.Entry<?, ?> entry : map.entrySet()) {
			LOG.debug("setting properties : " + (String) entry.getKey() + " - " + entry.getValue());
			setProperty(jmsMessage, (String) entry.getKey(), entry.getValue());
		}
	}

	public void setProperty(Message jmsMessage, String name, Object value) throws JMSException {
		if (value == null) {
			return;
		}
		if (value instanceof Byte) {
			jmsMessage.setByteProperty(name, (Byte) value);
		} else if (value instanceof Boolean) {
			jmsMessage.setBooleanProperty(name, (Boolean) value);
		} else if (value instanceof Double) {
			jmsMessage.setDoubleProperty(name, (Double) value);
		} else if (value instanceof Float) {
			jmsMessage.setFloatProperty(name, (Float) value);
		} else if (value instanceof Integer) {
			jmsMessage.setIntProperty(name, (Integer) value);
		} else if (value instanceof Long) {
			jmsMessage.setLongProperty(name, (Long) value);
		} else if (value instanceof Short) {
			jmsMessage.setShortProperty(name, (Short) value);
		} else if (value instanceof String) {
			jmsMessage.setStringProperty(name, (String) value);
		} else {
			// fallback to Object
			jmsMessage.setObjectProperty(name, value);
		}
	}
/**
 * Extrae propiedades que se insertan en el header del mensaje
 * @param map
 * @return
 */
	public Map<String, Object> extractParamsFilter(Map<String, Object> map) {
		Map<String, Object> result = new HashMap<String, Object>();
		for (Map.Entry<?, ?> entry : map.entrySet()) {
			if (getOutFilter().contains(entry.getKey())) {
				result.put((String) entry.getKey(), entry.getValue());
			}
		}
		return result;
	}

	public static void main(String[] args) {
		int i = 0;

		while (i < 10) {

			if (i == 5) {
				i++;
				continue;
			}
			i++;
			System.out.println(i);
		}
	}
}
