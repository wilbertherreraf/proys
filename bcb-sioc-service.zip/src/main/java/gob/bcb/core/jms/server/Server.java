package gob.bcb.core.jms.server;

import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Server {
	private static final Log log = LogFactory.getLog(Server.class);
	private static final AtomicBoolean started = new AtomicBoolean(false);
	private static AbstractApplicationContext appContext;
	
	public boolean start() throws Exception {
		if (started.compareAndSet(false, true)) {
			// lets just ignore redundant start() calls
			// as its way too easy to not be completely sure if start() has been
			// called or not with the gazillion of different configuration
			// mechanisms
			// throw new IllegalStateException("Allready started.");
			log.info("@@@@@@@@@@@ INICIADO @@@@@@@@@@@@@@");
			return true;
		}
		log.info("@@@@@@@@@@@ SESSION YA FUE CREADA @@@@@@@@@@@@@@");
		return false;
	}

	public void stop() {
		log.info("Stopping aplication context!!!");
		if (!started.get()) {
			return;
		}
//		DefaultMessageListenerContainer pooledConnectionFactory = (DefaultMessageListenerContainer) appContext
//				.getBean("ServiceListenerContainer");		
//		log.info("==>appContext isRunning? " + appContext.isRunning() + " " + pooledConnectionFactory.getActiveConsumerCount() + " " + pooledConnectionFactory.isActive());
//		pooledConnectionFactory.destroy();
//		AmqJNDIPooledConnectionFactory  pooledConnectionFactory = (AmqJNDIPooledConnectionFactory ) ConfigurationServ.getConnectionFactory();
//		pooledConnectionFactory.stop();
		log.info("appContext isRunning?AAAAAAAAAAAAAA " + appContext.isRunning());
		//appContext.stop();
		appContext.close();
		log.info("appContext isRunning post? " + appContext.isActive());
		//appContext.destroy();
		started.set(false);
		appContext = null;
	}

	public boolean isStarted() {
		return started.get();
	}

	public ApplicationContext runServer(String[] pathFileSpring) throws Exception {
		if (start()) {
			log.info("Iniciando SERVER ...");
			appContext = new ClassPathXmlApplicationContext(pathFileSpring);
			appContext.registerShutdownHook();
//			pooledConnectionFactory = (PooledConnectionFactory) appContext
//					.getBean("pooledConnectionFactory");			
			return appContext;
		}
		log.info("Servicio ya creado...");
		// FileSystemXmlApplicationContext appContext = new
		// FileSystemXmlApplicationContext(pathFileSpring);
		return appContext;
	}
}
