package gob.bcb.core.jms;

import java.util.HashMap;
import java.util.Map;

import javax.jms.Message;
import javax.jms.Session;
import org.apache.log4j.Logger;

public class ResponseContext {
	private static Logger log = Logger.getLogger(ResponseContext.class);
	private BcbResponse bcbResponse;
	private Map<String, DescripcionParametro> descripcionParametroList = new HashMap<String, DescripcionParametro>();
	private final BcbRequest bcbRequest;

	public ResponseContext(BcbRequest bcbRequest) {
		this.bcbRequest = bcbRequest;
		init();
	}

	public final void init() {

			if (bcbRequest == null) {
				log.error("Mensaje recibido nulo o no fue inicializado BCBRequest");
				throw new RuntimeException("REQUEST_NULO");
			}

			if (getCodTipoOperacion() == null || getCodTipoOperacion().isEmpty()) {
				log.error("Codigo de tipo operacion nulo");
				throw new RuntimeException("TIPO_OPERACION_NO_INICIALIZADO");
			}

			try {
				BcbResponseImpl bcbResponseImpl = new BcbResponseImpl();
				bcbResponseImpl.createFromBcbRequest((BcbRequestImpl) bcbRequest);
				bcbResponse = bcbResponseImpl;
				log.info("BcbResponse inicializado..." + bcbRequest.getIdTipoOperacion());
			} catch (Exception e) {
				log.error("Error creando objeto de respuesta " + e.getMessage(),e);				
				throw new RuntimeException("ERROR_CREANDO_OBJETO_RESPONSE " + e.getMessage() );
			}
	}

	/**
	 * A ade en un mapa de objetos el objeto para ser devuelto en la respuesta,
	 * si el objeto a devolver en la respuesta es diferente a al objeto
	 * contenido en el parametro objeto se debe realizar la conversion
	 * respectiva
	 * 
	 * @param codTipoOperacion
	 * @param paramName
	 * @param tipoParam
	 * @param objeto
	 */
	public void addDescripcionParametro(String codTipoOperacion, String paramName, String tipoParam, Object objeto) {
		BcbResponseImpl bcbResponseImpl = (BcbResponseImpl) bcbResponse;
		bcbResponseImpl.addDescripcionParametro(paramName, objeto);			
	}

	/**
	 * Arma los parametros de respuesta que se debe retornar en el objeto
	 * msgsistemaresp.contenido seg n el requerimiento de la operacion, para
	 * ello se discrimina por tipo de operacion valor contenido en
	 * descripcionParValor.getFormato
	 * 
	 * @param statusCode
	 * @param consent
	 */
	public void updateReponse(String statusCode, String consent) {
		log.debug("Actualizando response con statusCode: " + statusCode + " y descripci n: " + consent);
		BcbResponseImpl bcbResponseImpl = (BcbResponseImpl) bcbResponse;
		try {
			bcbResponseImpl.sendResponseBcbMsg(statusCode, consent);
		} catch (Exception e) {
			throw new RuntimeException("ERROR_AL_ACTUALIZAR_RESPUESTA " + descripcionParametroList.keySet().toString());
		}
	}

	public void addTaskDescripAdicional(Map<String, Object> taskAdic) {
		BcbResponseImpl bcbResponseImpl = (BcbResponseImpl) bcbResponse;
		bcbResponseImpl.addTaskDescripAdicional(taskAdic);
	}

	public static BcbResponse errorRequest(Message message, Session session, String statusCode, String consent, String idOperacion) {
		log.error("!!!ERROR NO CONTROLADO: Generacion de mensaje de error " + statusCode + " - " + consent);

		// whf eliminar las contantes aladi
		BcbResponseImpl bcbResponseImpl = new BcbResponseImpl(message, session);
		try {
			bcbResponseImpl.sendResponseBcbMsg(statusCode, consent);
		} catch (Exception e) {
			log.error("no se pudo enviar mensaje de respuesta " + e.getMessage(), e);
			throw new RuntimeException(e);
		}
		return bcbResponseImpl;
	}

	/**
	 * @return the codTipoOperacion
	 */
	public String getCodTipoOperacion() {
		return bcbRequest.getIdTipoOperacion();
	}
	/**
	 * @return the bcbResponse
	 */
	public BcbResponse getBcbResponse() {
		return bcbResponse;
	}

	public static void main(String[] args) {
	}
}
