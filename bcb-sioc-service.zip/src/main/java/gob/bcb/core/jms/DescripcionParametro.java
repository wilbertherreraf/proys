package gob.bcb.core.jms;

import java.io.Serializable;

/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public class DescripcionParametro implements Serializable{
	  private String perteneceAMetodo;
	  private final String nombre;
	  private final String tipo;
	  private final Object value;
	  private final String formato;

	  /**
	   * @param perteneceAMetodo
	   * @param nombre
	   * @param tipo
	   * @param value
	   * @param formato
	   */
	  public DescripcionParametro(String perteneceAMetodo, String nombre,
	      String tipo, Object value, String formato)
	  {
	    super();
	    this.perteneceAMetodo = perteneceAMetodo;
	    this.nombre = nombre;
	    this.tipo = tipo;
	    this.value = value;
	    this.formato = formato;
	  }

	  /**
	   * @param nombre
	   * @param tipo
	   * @param value
	   * @param formato
	   */
	  public DescripcionParametro(String nombre,
	      String tipo, Object value, String formato)
	  {
	    super();
	    this.nombre = nombre;
	    this.tipo = tipo;
	    this.value = value;
	    this.formato = formato;
	  }

	  // ---------------------------------------------------------------------------
	  /**
	   * @return the nombre
	   */
	  public String getNombre()
	  {
	    return nombre;
	  }

	  /**
	   * @return the tipo
	   */
	  public String getTipo()
	  {
	    return tipo;
	  }

	  /**
	   * @return the value
	   */
	  public Object getValue()
	  {
	    return value;
	  }

	  /**
	   * @return the formato
	   */
	  public String getFormato()
	  {
	    return formato;
	  }

	  /**
	   * @return the perteneceAMetodo
	   */
	  public final String getPerteneceAMetodo()
	  {
	    return perteneceAMetodo;
	  }

	  /*
	   * (non-Javadoc)
	   * @see java.lang.Object#toString()
	   */
	  
	  public String toString()
	  {
	    StringBuilder builder = new StringBuilder();
	    builder.append("DescripcionParametro [perteneceAMetodo=");
	    builder.append(perteneceAMetodo);
	    builder.append(", nombre=");
	    builder.append(nombre);
	    builder.append(", tipo=");
	    builder.append(tipo);
	    builder.append(", value=");
	    builder.append(value);
	    builder.append(", formato=");
	    builder.append(formato);
	    builder.append("]");
	    return builder.toString();
	  }

	  // ---------------------------------------------------------------------------
}
