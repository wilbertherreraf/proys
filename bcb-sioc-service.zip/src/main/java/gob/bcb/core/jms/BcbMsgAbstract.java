package gob.bcb.core.jms;

import gob.bcb.core.jms.client.JMSConnectionHandler;
import gob.bcb.core.utils.JAXBHelper;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.core.utils.UtilsNet;
import gob.bcb.core.utils.UtilsXmlBind;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.IllegalStateException;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TemporaryQueue;
import javax.jms.TextMessage;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;

public abstract class BcbMsgAbstract {
	private static Logger log = Logger.getLogger(BcbMsgAbstract.class);
	/**
	 * nombre del feature dentro del servicio de negocio o BPM
	 */
	private String nameQueueTopic;
	private Map<String, Object> parameters = new HashMap<String, Object>();
	private Map<String, Object> propiedades = new HashMap<String, Object>();
	private Object mensajeBCBJAXB;
	private Object body;
	private Message jmsMessage;
	private Session jmsSession;
	private JMSBinding binding;
	private MessageConsumer replyConsumer = null;
	private boolean typeDestinationQueue = true;
	private boolean disableReplyTo;
	private boolean printed = true;
	private Destination destination;
	private long startTime;
	private JMSConnectionHandler jMSConnectionHandler;

	private final static JAXBContext jAXBContext;
	static {
		try {
			jAXBContext = JAXBContext.newInstance("gob.bcb.core.jms.model");
			log.debug("Contexto objetos JAXB iniciado");
		} catch (JAXBException e) {
			log.error("Error al inicializar contexto JAXB " + e.getMessage(), e);
			throw new RuntimeException(e);
		}
	}
	private final static Map<Class<?>, JAXBContext> contexts = new HashMap<Class<?>, JAXBContext>();
	private static DocumentBuilderFactory documentBuilderFactory;

	public BcbMsgAbstract() {
		startTime = System.currentTimeMillis();
		try {
			getPropiedades().put("BCBAddress", UtilsNet.getAddressHost());
			getPropiedades().put("BCBIdemisor", UtilsNet.getNameHost());
		} catch (Exception e) {
		}
		getPropiedades().put("BCBIddestinatario", "default");
		getPropiedades().put("BCBIdusuario", "localhost");
		getPropiedades().put("BCBPasswmd5", "");
		getPropiedades().put("BCBIdsistema", "system");
		getPropiedades().put("BCBNrooperacion", UtilsDate.stringFromDate(new Date(), "yyyyMMdd") + UtilsGeneric.generateUUID());
		getPropiedades().put("BCBIdoperacion", "default");
	}

	public BcbMsgAbstract(Message jmsMessage) {
		setJmsMessage(jmsMessage);
	}

	public BcbMsgAbstract(Message jmsMessage, Session session) {
		setJmsMessage(jmsMessage);
		setJmsSession(session);
	}

	public abstract void setPropiedadesFromMsgBcb();

	public abstract void setMsgBcbFromPropiedades();

	public abstract void updateMsgsistemaresp(String statusCode, String statusDescription, Object tipoJAXBEleASubtituir);

	/**
	 * implementar si el body es nulo que tipo de mensaje se lleva
	 */
	protected void setBodyMsgBcb() {

		if (getBody() == null) {
			// por defecto es XML
			try {
				setBody(toString(getMensajeBCBJAXB()));
				getRequestElements().clear();
			} catch (Exception e) {
				log.error(e.getMessage(), e);
				throw new RuntimeException(e);
			}
		}
	}


	public void sendResponseBcbMsg(String statusCode, String consent) throws JAXBException, ParserConfigurationException, TransformerException {
		updateMsgsistemaresp(statusCode, consent, null);
		if (isDisableReplyTo() || getDestination() == null) {
			log.warn("Mensaje sin destino de respuesta");
			return;
		}

		try {
			Message response = createMessage();
			setJmsMessage(response);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new RuntimeException(e);
		}
		sendResponse();
	}

	private static final int deliveryMode = DeliveryMode.NON_PERSISTENT;
	private static final int priority = 5;
	public void sendResponse() {
		MessageProducer producer = null;
		try {
			log.info(">>>Mensaje<<<<<<<<<<<<< ");			
			producer = jmsSession.createProducer(getDestination());
			jmsMessage.setJMSType(body.getClass().getName());
			producer.setDeliveryMode(deliveryMode);
			producer.send(jmsMessage);
			long endTime = System.currentTimeMillis();
			log.info(">>>Mensaje de respuesta enviada [duracion: " + TimeUnit.MILLISECONDS.convert(endTime - startTime, TimeUnit.MILLISECONDS)
					+ "(ms)]:\n" + producer.toString());
		} catch (Exception e) {
			log.error("ESTO ES HORRRIBLE ERROR FATAL!!!!!: no se pudo enviar mensaje de respuesta " + e.getMessage(), e);
			throw new RuntimeException(e);
		} finally {
			if (producer != null) {
				try {
					producer.close();
					log.warn("Sender de response JMS cerrado...");
				} catch (JMSException e) {
					log.error("Error al cerrar session JMS " + e.getMessage(), e);
				}
			}
		}
	}
	public void sendPing() {
		MessageProducer producer = null;
		if (isDisableReplyTo() || getDestination() == null) {
			log.info("Ping no send!!!");
			return;
		}
		
		try {
			log.info("En send ping...");
			producer = getJmsSession().createProducer(getDestination());
			TextMessage msg = getJmsSession().createTextMessage("PING");
			producer.send(msg);
			
		} catch (Exception e) {
			log.error("ESTO ES HORRRIBLE ERROR FATAL!!!!!: no se pudo enviar pingcito " + e.getMessage(), e);
			throw new RuntimeException(e);
		} finally {
			if (producer != null) {
				try {
					producer.close();
					log.info("Sender de response JMS cerrado...");
				} catch (JMSException e) {
					log.error("Error al cerrar session JMS " + e.getMessage(), e);
				}
			}
		}
	}
	public void sendPingRequest() {
		Message messageIn = null;
		MessageConsumer replyConsumer = null;
		try {
			log.info("En sendPingRequest ping...");
			Session jmsSession = getJMSConnectionHandler().getSession();
			Destination destination = jmsSession.createQueue(nameQueueTopic);
			TextMessage msg = jmsSession.createTextMessage("PING");			
			TemporaryQueue confirmQueue = jmsSession.createTemporaryQueue();
			msg.setJMSReplyTo(confirmQueue);
			replyConsumer = getJMSConnectionHandler().getConsumer(confirmQueue);

			getJMSConnectionHandler().send(destination, msg);			

			messageIn = replyConsumer.receive(5000);// (50000);
			
			if (messageIn == null){
				log.error("Sin Respuesta de Servicio");
				throw new RuntimeException("Sin Respuesta de Servicio");				
			}
			replyConsumer.close();
			log.info("En FIN sendPingRequest ping...");
		} catch (Exception e) {
			log.error("ESTO ES HORRRIBLE ERROR FATAL!!!!!: no se pudo enviar pingcito " + e.getMessage(), e);
			throw new RuntimeException(e);
		} finally {
			if (replyConsumer != null) {
				try {
					replyConsumer.close();
					log.info("Sender de response JMS cerrado...");
				} catch (JMSException e) {
					log.error("Error al cerrar session JMS " + e.getMessage(), e);
				}
			}
		}
	}

	public StatusResponse sendMessage() {

		StatusResponse statusResponse = null;
		startTime = System.currentTimeMillis();
		try {
			send();

			if (!isDisableReplyTo()) {
				statusResponse = procesarResponseMsgIn();
				long endTime = System.currentTimeMillis();
				log.info("Respuesta recibida satisfactoriamente. (" + (endTime - startTime) + " ms.)");
				getJMSConnectionHandler().closeConsumer(getJmsMessage().getJMSReplyTo());				
			}
		} catch (NullPointerException e) {
			log.error("error al procesarResponse JMS " + e.getMessage(), e);
			statusResponse = new StatusResponse();
			statusResponse.setStatusCode("NullPointerException");
			statusResponse.setDescrip(e.getMessage());

		} catch (Exception e) {
			log.error("error al cerrar consumers JMS " + e.getMessage(), e);
			statusResponse = new StatusResponse();
			statusResponse.setStatusCode("Exception");
			statusResponse.setDescrip(e.getMessage());
		} finally {
			try {
				log.info("en finally de sendMessage");
				getJMSConnectionHandler().getProducer().close();
			} catch (JMSException e) {
				log.error("errror al cerrar producer " + e.getMessage(), e);
			}
		}


		return statusResponse;
	}

	public void send() {
		try {
			if (getJmsMessage() == null) {
				Message msgOut = createMessage();
				setJmsMessage(msgOut);
			}

			try {
				if (isTypeDestinationQueue()) {
					destination = getJmsSession().createQueue(nameQueueTopic);
				} else {
					destination = getJmsSession().createTopic(nameQueueTopic);
				}
			} catch (JMSException e) {
				log.error("Ocurrio un error en el proceso de envio/recepcion del mensaje se intentara reconectar." + e.getMessage(), e);
				try {
					getJMSConnectionHandler().reConnect();
					setJmsSession(getJMSConnectionHandler().getSession());
					if (isTypeDestinationQueue()) {
						destination = getJmsSession().createQueue(nameQueueTopic);
					} else {
						destination = getJmsSession().createTopic(nameQueueTopic);
					}
				} catch (JMSException e1) {
					log.error("Error al reconectar " + e1.getMessage(), e1);
					getJMSConnectionHandler().close();
					throw new JMSException(e1.getMessage());
				}
			}

			if (!isDisableReplyTo()) {
				TemporaryQueue confirmQueue = getJmsSession().createTemporaryQueue();
				getJmsMessage().setJMSReplyTo(confirmQueue);
				// getJmsMessage().setJMSExpiration(2000);
				replyConsumer = getJMSConnectionHandler().getConsumer(confirmQueue);

			}
			getJMSConnectionHandler().send(destination, getJmsMessage(), false, 5, 45000);
			//getJMSConnectionHandler().send(destination, getJmsMessage());
			if (isPrinted())
				log.info("Mensaje request enviado: \n" + printMessage());
		} catch (Exception e) {
			log.error("error al enviar mensaje: " + e.getMessage(), e);
			throw new RuntimeException(e);
		}
	}

	public Object extractBodyAndParams(Message message) {
		Object bodyMsgIn = null;
		try {
			if (message == null) {
				log.error("Mensaje NULO");
				throw new Exception("Mensaje NULO");
			}

			setPropiedades(getBinding().extractHeadersFromJms(message));

			bodyMsgIn = getBinding().extractBodyFromJms(message);

			if (bodyMsgIn == null) {
				log.error("No se pudo recuperar contenido del mensaje");
				throw new Exception("No se pudo recuperar contenido del mensaje");
			}

			if (bodyMsgIn instanceof String) {
				Object mensajeJAXB = null;
				try {
					String mens =  (String) bodyMsgIn;
					if (mens.equals("PING")){
						log.info("Es pingggggggggggggggggggg" + mens);
						return mens;
					}
					mensajeJAXB = JAXBHelper.convertXMLToMsgBcb(mens, jAXBContext);
					mensajeBCBJAXB = mensajeJAXB;
					// TransformSirAladi transformSirAladi = new
					// TransformSirAladi();
					// Map<String, Object> params =
					// transformSirAladi.fromXMLToJPA(null, mensajeJAXB);
					// setRequestElements(params);
					// setPropiedadesFromMsgBcb();
				} catch (Exception e) {
					if (getPropiedades().containsKey("JMSType") && (getPropiedades().get("JMSType") != null)
							&& ((String) getPropiedades().get("JMSType")).equals(String.class.getName())) {
						// si tiene el parametro en el header se valida como
						// string
						log.warn("Se valida el contenido del mensaje como string " + e.getMessage(), e);
					} else {
						log.error(e.getMessage(), e);
						throw new RuntimeException(e);
					}
				}

			} else {
				Map<String, Object> params = getBinding().getParamsFromMessage(message, getPropiedades());
				setRequestElements(params);
				setMsgBcbFromPropiedades();
			}
			setBody(bodyMsgIn);
		} catch (Exception e) {
			log.error("Error en la recepcion del mensaje " + e.getMessage(), e);
			throw new RuntimeException(e);
		}
		return bodyMsgIn;
	}

	public Object procesarMsgIn() {
		Object bodyMsgIn = extractBodyAndParams(getJmsMessage());
		return bodyMsgIn;
	}

	protected Message createMessage() throws Exception {
		if (getJmsSession() == null) {
			setJmsSession(getJMSConnectionHandler().getSession());
		}
		setBodyMsgBcb();
		Message response = null;
		try {
			if (body instanceof byte[] || body instanceof Map) {
				setPropiedadesFromMsgBcb();
				getRequestElements().putAll(getBinding().extractParamsFilter(getPropiedades()));
				response = getBinding().createJmsMessage(body, getRequestElements(), getJmsSession());
			} else if (body instanceof String) {
				response = getBinding().createJmsMessage(body, getRequestElements(), getJmsSession());
			} else {
				setPropiedadesFromMsgBcb();
				getRequestElements().putAll(getBinding().extractParamsFilter(getPropiedades()));
				response = getBinding().createJmsMessage(getBody(), getRequestElements(), getJmsSession());
			}
			response.setJMSCorrelationID(determineCorrelationId(response));
		} catch (IllegalStateException e) {
			log.error("Error al crear mensaje reconectando: " + e.getMessage(), e);
			try {
				getJMSConnectionHandler().reConnect();
				setJmsSession(getJMSConnectionHandler().getSession());
				if (isTypeDestinationQueue()) {
					destination = getJmsSession().createQueue(nameQueueTopic);
				} else {
					destination = getJmsSession().createTopic(nameQueueTopic);
				}

			} catch (Exception e1) {
				getJMSConnectionHandler().close();
				throw new Exception("Error al crear mensaje, fallo en la reconecci�n " + e1.getMessage(), e1);
			}
			log.error("XXX: ULALAAAAAAA!!!! llamada recursiva : ");
			response = createMessage();
		} catch (Exception e) {
			log.error("Error al Generico crear mensaje: " + e.getMessage(), e);
			throw new Exception(e);
		}
		return response;
	}

	public abstract StatusResponse procesarResponseMsgIn();

	public void setJmsMessage(Message jmsMessage) {
		this.jmsMessage = jmsMessage;
	}

	public Message getJmsMessage() {
		return jmsMessage;
	}

	public JMSBinding getBinding() {
		if (binding == null) {
			binding = new JMSBinding();
		}
		return binding;
	}

	public void setBinding(JMSBinding binding) {
		this.binding = binding;
	}

	public String printMessage() {
		StringBuilder result = new StringBuilder();

		// result.append(getPropiedades().toString());
		// result.append(getRequestElements().toString());
		// Enumeration names;
		// try {
		// names = getJmsMessage().getPropertyNames();
		// } catch (JMSException e) {
		// throw new RuntimeException(e);
		// }
		// while (names.hasMoreElements()) {
		// String name = names.nextElement().toString();
		// try {
		// Object value = getJmsMessage().getObjectProperty(name);
		// result.append(name + " = " + value);
		// } catch (JMSException e) {
		// result.append(name + " = tipo valor desconocido");
		// }
		// result.append("\n");
		// }
		// result.append(" ===================body=======================\n");
		if (body == null) {
			result.append(getBinding().extractBodyFromJms(getJmsMessage()));
		} else {
			result.append(body);
		}
		// result.append("\n===================body=======================\n");
		return result.toString();
	}

	public String toString(Object value) throws JAXBException, ParserConfigurationException, TransformerException {
		if (value == null) {
			throw new IllegalArgumentException("Cannot convert from null value to JAXBSource");
		}
		// Document doc = JAXBHelper.toDocument(value, documentBuilderFactory,
		// getJaxbContext(value));
		Document doc = JAXBHelper.toDocument(value, documentBuilderFactory, getJaxbcontext());
		return UtilsXmlBind.getStringFromDom(doc);

	}

	protected String determineCorrelationId(Message message) throws JMSException {
		final String provisionalCorrelationId = (String) getPropiedades().get("JMSCorrelationID");

		if (provisionalCorrelationId != null) {
			return provisionalCorrelationId;
		}

		final String messageId = message.getJMSMessageID();
		final String correlationId = message.getJMSCorrelationID();
		if (correlationId == null || correlationId.trim().isEmpty()) {
			// correlation id is empty so fallback to message id
			return messageId;
		} else {
			return correlationId;
		}
	}

	private synchronized JAXBContext getJaxbContext(Object value) throws JAXBException {
		Class<?> type = value.getClass();
		JAXBContext context = contexts.get(type);
		if (context == null) {
			context = JAXBContext.newInstance(type);
			contexts.put(type, context);
		}
		return context;
	}

	public void addDescripcionParametro(String paramName, Object objeto) {
		parameters.put(paramName, objeto);
	}

	public String getIdTipoOperacion() {
		return (String) getPropiedades().get("BCBIdoperacion");
	}

	public Map<String, Object> getRequestElements() {
		return this.parameters;
	}

	public void setRequestElements(Map<String, Object> parameters) {
		this.parameters = parameters;
	}

	public void setJmsSession(Session jmsSession) {
		this.jmsSession = jmsSession;
	}

	public Session getJmsSession() {
		return jmsSession;
	}

	public void setNameQueueTopic(String nameQueueTopic) {
		this.nameQueueTopic = nameQueueTopic;
	}

	public String getNameQueueTopic() {
		return nameQueueTopic;
	}

	public void setBody(Object body) {
		this.body = body;
	}

	public Object getBody() {
		return body;
	}

	public void setPropiedades(Map<String, Object> propiedades) {
		this.propiedades = propiedades;
	}

	public Map<String, Object> getPropiedades() {
		return propiedades;
	}

	public void setMensajeBCBJAXB(Object mensajeBCBJAXB) {
		this.mensajeBCBJAXB = mensajeBCBJAXB;
	}

	public Object getMensajeBCBJAXB() {
		return this.mensajeBCBJAXB;
	}

	public static JAXBContext getJaxbcontext() {
		return jAXBContext;
	}

	public void setReplyConsumer(MessageConsumer replyConsumer) {
		this.replyConsumer = replyConsumer;
	}

	public MessageConsumer getReplyConsumer() {
		return replyConsumer;
	}

	public void setDisableReplyTo(boolean disableReplyTo) {
		this.disableReplyTo = disableReplyTo;
	}

	public boolean isDisableReplyTo() {
		return disableReplyTo;
	}

	public void setTypeDestinationQueue(boolean typeDestinationQueue) {
		this.typeDestinationQueue = typeDestinationQueue;
	}

	public boolean isTypeDestinationQueue() {
		return typeDestinationQueue;
	}

	public void setDestination(Destination destination) {
		this.destination = destination;
	}

	public Destination getDestination() {
		return destination;
	}

	public void setPrinted(boolean printed) {
		this.printed = printed;
	}

	public boolean isPrinted() {
		return printed;
	}

	public void setJMSConnectionHandler(JMSConnectionHandler jMSConnectionHandler) {
		this.jMSConnectionHandler = jMSConnectionHandler;
	}

	public JMSConnectionHandler getJMSConnectionHandler() {
		if (jMSConnectionHandler == null) {
			jMSConnectionHandler = new JMSConnectionHandler();
		}
		return jMSConnectionHandler;
	}

}

