package gob.bcb.core.jms.client;

public class SendMessage {
    private String jmsText;
    private boolean jmsPersistent;
    private int jmsPriority;
    private int jmsTimeToLive = -1;
    private String jmsCorrelationID;
    private String jmsReplyTo;
    private String jmsType;
    private int jmsMessageCount = 1;
    private String jmsMessageCountHeader = "JMSXMessageNumber";
    
    public SendMessage() {
    }
    
    public void send(){
    	
    }
}
