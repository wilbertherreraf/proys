package gob.bcb.core.jms;

public enum JmsMessageType {

    Bytes, 
    Map, 
    Object, 
    Stream, 
    Text,
    
    /**
     * BlobMessage which is not supported by all JMS implementations
     */
    Blob

}
