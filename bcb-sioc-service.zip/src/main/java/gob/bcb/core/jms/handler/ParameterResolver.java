package gob.bcb.core.jms.handler;

import gob.bcb.core.jms.Constants;
import gob.bcb.core.utils.UtilsDate;

import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

public class ParameterResolver {
	private static Logger log = Logger.getLogger(ParameterResolver.class);
	Map<String, String> params;

	public ParameterResolver() {
		params = new HashMap<String, String>();
	}
	
	public ParameterResolver(Map<String, String> map) {
		params = map;
	}

	public <T> T resolve(String resourceName, Class<T> resourceType) {
		String value = params.get(resourceName);
		return convertToType(value, resourceType);
	}

	public InputStream getAsStream(String name) {
		// returning these as a stream does not make much sense
		return null;
	}

	/**
	 * Convert the string representation of value to type T
	 */
	public <T> T convertToType(String value, Class<T> type) {

		/*
		 * char, byte, short, long, float, double, boolean
		 */
		T ret = null;
		try {
			if (String.class.equals(type)) {
				ret = type.cast(value);
			} else if (Integer.class.equals(type) || Integer.TYPE.equals(type)) {
				ret = type.cast(Integer.valueOf(value));
			} else if (Byte.class.equals(type) || Byte.TYPE.equals(type)) {
				ret = type.cast(Byte.valueOf(value));
			} else if (Short.class.equals(type) || Short.TYPE.equals(type)) {
				ret = type.cast(Short.valueOf(value));
			} else if (Long.class.equals(type) || Long.TYPE.equals(type)) {
				ret = type.cast(Long.valueOf(value));
			} else if (Float.class.equals(type) || Float.TYPE.equals(type)) {
				ret = type.cast(Float.valueOf(value));
			} else if (Double.class.equals(type) || Double.TYPE.equals(type)) {
				ret = type.cast(Double.valueOf(value));
			} else if (Boolean.class.equals(type) || Boolean.TYPE.equals(type)) {
				ret = type.cast(Boolean.valueOf(value));
			} else if (Date.class.equals(type)) {
				ret = type.cast(UtilsDate.dateFromString(value, Constants.FORMAT_DATE_DB));				
			} else if (Character.class.equals(type) || Character.TYPE.equals(type)) {
				ret = type.cast(value.charAt(0));
			} else {
				log.warn("No se pudo encontrar la clase para: " + value);
				ret = (T) String.class.cast(value);
			}
		} catch (NumberFormatException ex) {
			log.error("badly formed init param: " + value);
		}
		return ret;
	}
	public String convertToString(Object value) {

		/*
		 * char, byte, short, long, float, double, boolean
		 */
		String ret = null;

		try {
			if (String.class.equals(value.getClass())) {
				ret = (String) value;
			} else if (Integer.class.equals(value.getClass()) || Integer.TYPE.equals(value.getClass())) {
				ret = String.valueOf(value); 
			} else if (Byte.class.equals(value.getClass()) || Byte.TYPE.equals(value.getClass())) {
				ret = String.valueOf(value);
			} else if (Short.class.equals(value.getClass()) || Short.TYPE.equals(value.getClass())) {
				ret = String.valueOf(value);
			} else if (Long.class.equals(value.getClass()) || Long.TYPE.equals(value.getClass())) {
				ret = String.valueOf(value);
			} else if (Float.class.equals(value.getClass()) || Float.TYPE.equals(value.getClass())) {
				ret = String.valueOf(value);
			} else if (Double.class.equals(value.getClass()) || Double.TYPE.equals(value.getClass())) {
				ret = String.valueOf(value);
			} else if (Boolean.class.equals(value.getClass()) || Boolean.TYPE.equals(value.getClass())) {
				ret = String.valueOf(value);
			} else if (Date.class.equals(value.getClass())) {
				ret = UtilsDate.stringFromDate((Date) value, Constants.FORMAT_DATE_DB);				
			} else if (Character.class.equals(value.getClass()) || Character.TYPE.equals(value.getClass())) {
				ret = String.valueOf(value);
			} else {
				log.warn("No se pudo encontrar la clase para: " + value);
				ret = String.class.cast(value);
			}
		} catch (NumberFormatException ex) {
			log.error("badly formed init param: " + value);
		}
		return ret;
	}	
	
}
