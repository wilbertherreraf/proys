package gob.bcb.core.jms;

import gob.bcb.core.jms.model.Msgbcbresp;
import gob.bcb.core.jms.model.Msgcabeceraresp;
import gob.bcb.core.jms.model.Msgsistemaresp;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.core.utils.UtilsGeneric;

import java.io.StringReader;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;

/**
 * @author wilherrera Wilbert Herrera Flores Banco Central de Bolivia
 *         Departamento de Desarrollo
 */
public class BcbResponseImpl extends BcbMsgAbstract implements BcbResponse {
	private static Logger log = Logger.getLogger(BcbResponseImpl.class);
	private boolean received = false;

	public BcbResponseImpl() {
		Msgcabeceraresp msgcabeceraresp = new Msgcabeceraresp();

		Msgsistemaresp msgsistemaresp = new Msgsistemaresp();

		msgsistemaresp.setCodestadoresp("OPERACION_RECEIVED");
		msgsistemaresp
				.setDescripcion("Estado inicial del mensaje recepcionado en el servidor. Si recibe este mensaje favor comunicar al administrador");
		Msgbcbresp msgbcbresp = new Msgbcbresp();

		msgcabeceraresp.setFecharecepcion(UtilsDate.stringFromDate(new Date(), Constants.FORMAT_DATE_TIME));
		msgcabeceraresp.setFecharespuesta(UtilsDate.stringFromDate(new Date(), Constants.FORMAT_DATE_TIME));
		msgcabeceraresp.setIdrespuesta(UtilsDate.stringFromDate(new Date(), "yyyyMMdd") + UtilsGeneric.generateUUID());

		msgbcbresp.setMsgcabeceraresp(msgcabeceraresp);
		msgbcbresp.setMsgsistemaresp(msgsistemaresp);
		setMensajeBCBJAXB(msgbcbresp);
	}

	public BcbResponseImpl(Message message) {
		this();
		setJmsMessage(message);
	}

	public BcbResponseImpl(Message message, Session session) {
		this();
		setJmsMessage(message);
		setJmsSession(session);
	}

	public void createFromBcbRequest(BcbRequestImpl bcbRequestImpl) {
		setJmsMessage(bcbRequestImpl.getJmsMessage());
		setJmsSession(bcbRequestImpl.getJmsSession());

		getMsgBcbresp().getMsgcabeceraresp().setIddestinatario(bcbRequestImpl.getMsgbcb().getMsgcabecera().getIdemisor());
		getMsgBcbresp().getMsgcabeceraresp().setIdemisor(bcbRequestImpl.getMsgbcb().getMsgcabecera().getIddestinatario());
		getMsgBcbresp().getMsgcabeceraresp().setIdrespuesta(
				getMsgBcbresp().getMsgcabeceraresp().getIdemisor() + UtilsDate.stringFromDate(new Date(), "yyyyMMdd") + UtilsGeneric.generateUUID());
		getMsgBcbresp().getMsgcabeceraresp().setIdsistema(bcbRequestImpl.getMsgbcb().getMsgcabecera().getIdsistema());
		getMsgBcbresp().getMsgcabeceraresp().setNrooperacion(bcbRequestImpl.getMsgbcb().getMsgcabecera().getNrooperacion());
		// msgsistema
		getMsgBcbresp().getMsgsistemaresp().setIdoperacion(bcbRequestImpl.getMsgbcb().getMsgsistema().getIdoperacion());

		try {
			setDisableReplyTo(bcbRequestImpl.getJmsMessage().getJMSReplyTo() == null);
			if (!isDisableReplyTo())
				setDestination(bcbRequestImpl.getJmsMessage().getJMSReplyTo());
		} catch (Exception e) {
			log.warn("Mensaje sin respuesta");
			setDisableReplyTo(true);
		}
		received = true;
	}

	public void setMsgBcbFromPropiedades() {
		getMsgBcbresp().getMsgcabeceraresp().setIddestinatario((String) getPropiedades().get("BCBIddestinatario"));
		getMsgBcbresp().getMsgcabeceraresp().setIdemisor((String) getPropiedades().get("BCBIdemisor"));
		getMsgBcbresp().getMsgcabeceraresp().setIdrespuesta((String) getPropiedades().get("BCBIdrespuesta"));
		getMsgBcbresp().getMsgcabeceraresp().setIdsistema((String) getPropiedades().get("BCBIdsistema"));
		getMsgBcbresp().getMsgcabeceraresp().setNrooperacion((String) getPropiedades().get("BCBNrooperacion"));

		getMsgBcbresp().getMsgsistemaresp().setIdoperacion((String) getPropiedades().get("BCBIdoperacion"));
		getMsgBcbresp().getMsgsistemaresp().setCodestadoresp((String) getPropiedades().get("BCBCodestadoresp"));
		getMsgBcbresp().getMsgsistemaresp().setDescripcion((String) getPropiedades().get("BCBDescripcion"));
		getMsgBcbresp().getMsgsistemaresp().setMsgsadicionales((String) getPropiedades().get("BCBMsgsadicionales"));
	}

	public void setPropiedadesFromMsgBcb() {
		getPropiedades().put("BCBIddestinatario", getMsgBcbresp().getMsgcabeceraresp().getIddestinatario());
		getPropiedades().put("BCBIdemisor", getMsgBcbresp().getMsgcabeceraresp().getIdemisor());
		getPropiedades().put("BCBIdrespuesta", getMsgBcbresp().getMsgcabeceraresp().getIdrespuesta());
		getPropiedades().put("BCBIdsistema", getMsgBcbresp().getMsgcabeceraresp().getIdsistema());
		getPropiedades().put("BCBNrooperacion", getMsgBcbresp().getMsgcabeceraresp().getNrooperacion());

		getPropiedades().put("BCBIdoperacion", getMsgBcbresp().getMsgsistemaresp().getIdoperacion());
		getPropiedades().put("BCBCodestadoresp", getMsgBcbresp().getMsgsistemaresp().getCodestadoresp());
		getPropiedades().put("BCBDescripcion", getMsgBcbresp().getMsgsistemaresp().getDescripcion());
		getPropiedades().put("BCBMsgsadicionales", getMsgBcbresp().getMsgsistemaresp().getMsgsadicionales());
	}

	public void updateMsgsistemaresp(String statusCode, String consent, Object tipoJAXBEleASubtituir) {
		log.info("Actualizando response con statusCode: " + statusCode + " y descripci�n: " + consent);
		if (statusCode != null && !"OPERACION_SUCCESS".equalsIgnoreCase(statusCode)) {
			if (consent == null) {
				consent = "Estado de la respuesta es " + statusCode + " pero sin descripcion del mismo. Comunique a sistemas";
			}
			// eliminar el resto de las descripciones de parametros
			getRequestElements().clear();
		}

		if (statusCode != null) {
			getMsgBcbresp().getMsgsistemaresp().setCodestadoresp(statusCode);
			getPropiedades().put("BCBCodestadoresp", statusCode);
		}
		if (consent != null) {
			getMsgBcbresp().getMsgsistemaresp().setDescripcion(consent);
			getPropiedades().put("BCBDescripcion", consent);
		}
		getMsgBcbresp().getMsgcabeceraresp().setFecharespuesta(UtilsDate.stringFromDate(new Date(), "dd/MM/yyyy"));
	}

	public void addTaskDescripAdicional(Map<String, Object> taskAdic) {
		if (taskAdic.size() == 0) {
			return;
		}

		List<String> msgsAdic = new ArrayList<String>();
		for (Iterator<?> i = taskAdic.keySet().iterator(); i.hasNext();) {
			String key = (String) i.next();
			msgsAdic.add((String) taskAdic.get(key));
		}
		getMsgBcbresp().getMsgsistemaresp().setMsgsadicionales(msgsAdic.toString());
		getPropiedades().put("BCBMsgsadicionales", getMsgBcbresp().getMsgsistemaresp().getMsgsadicionales());		
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbResponse#getStatusCode()
	 */
	
	public String getStatusCode() {
		return getMsgBcbresp().getMsgsistemaresp().getCodestadoresp();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbResponse#getStatusDescription()
	 */
	
	public String getStatusDescription() {
		return getMsgBcbresp().getMsgsistemaresp().getDescripcion();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbResponse#getResponseId()
	 */
	
	public String getResponseId() {
		return getMsgBcbresp().getMsgcabeceraresp().getIdrespuesta();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.commons.BcbResponse#getReceivedDate()
	 */
	
	public Date getReceivedDate() {
		return UtilsDate.dateFromString(getMsgBcbresp().getMsgcabeceraresp().getFecharecepcion(), "yyyy-MM-dd HH:mm:ss:SSS");
	}

	public Msgbcbresp getMsgBcbresp() {
		return (Msgbcbresp) getMensajeBCBJAXB();
	}

	public StatusResponse procesarResponseMsgIn() {
		return null;
	}


}
