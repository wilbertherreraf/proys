package gob.bcb.core.jms.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Session;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.MessageAvailableConsumer;
//import org.apache.activemq.pool.AmqJNDIPooledConnectionFactory;
//import org.apache.activemq.pool.PooledConnectionFactory;
import org.apache.log4j.Logger;

public class JMSConnectionHandler {
	//private static final Log log = LogFactory.getLog(JMSConnectionHandler.class);
	private static Logger log = Logger.getLogger(JMSConnectionHandler.class);	

	private Session session;
	private MessageProducer producer;
	private Connection connection;
	private int deliveryMode = DeliveryMode.NON_PERSISTENT;
	private ConnectionFactory connectionFactory;
	// private Properties propiedades;
	private Map<Destination, MessageConsumer> consumers = new HashMap<Destination, MessageConsumer>();

	public JMSConnectionHandler() {
		ActiveMQConnectionFactory amqJNDIPooledConnectionFactory = new ActiveMQConnectionFactory();
		// propiedades = amqJNDIPooledConnectionFactory.getProperties();
		//connectionFactory = (PooledConnectionFactory) amqJNDIPooledConnectionFactory;
		connectionFactory = amqJNDIPooledConnectionFactory;
		getPropertiesToString();
	}

	public JMSConnectionHandler(String brokerURL) {
		ActiveMQConnectionFactory amqJNDIPooledConnectionFactory = new ActiveMQConnectionFactory(brokerURL);
		// propiedades = amqJNDIPooledConnectionFactory.getProperties();
		//connectionFactory = (PooledConnectionFactory) amqJNDIPooledConnectionFactory;
		connectionFactory = amqJNDIPooledConnectionFactory;
		getPropertiesToString();
	}

	public JMSConnectionHandler(ConnectionFactory cf) {
		log.debug("Creando objeto JMSConnectionHandler ");
		if (cf == null) {
			throw new IllegalStateException("ConnectionFactory nulo, inicialice el objeto de conexion JMS");
		}
		connectionFactory = cf;
		// propiedades = activeMQConnectionFactory.getProperties();
		getPropertiesToString();
	}

	public JMSConnectionHandler(Properties prop) {
		ActiveMQConnectionFactory amqJNDIPooledConnectionFactory = new ActiveMQConnectionFactory();
		amqJNDIPooledConnectionFactory.setProperties(prop);
		// propiedades = amqJNDIPooledConnectionFactory.getProperties();
		//connectionFactory = (PooledConnectionFactory) amqJNDIPooledConnectionFactory;
		connectionFactory = amqJNDIPooledConnectionFactory;
		getPropertiesToString();
	}

	public static synchronized ConnectionFactory initFromPropertiesContext(Properties prop) {
		ActiveMQConnectionFactory amqJNDIPooledConnectionFactory = null;
		try {
			amqJNDIPooledConnectionFactory = new ActiveMQConnectionFactory();
			amqJNDIPooledConnectionFactory.setProperties(prop);
			log.info("PooledConnectionFactory creado con propiedades " + amqJNDIPooledConnectionFactory.getProperties().toString());
		} catch (Exception e) {
			log.error("Error al iniciar ConnectionFactory " + e.getMessage(), e);
			throw new RuntimeException("Error al iniciar ConnectionFactory " + e.getMessage(), e);
		}

		//return (PooledConnectionFactory) amqJNDIPooledConnectionFactory;
		return amqJNDIPooledConnectionFactory;
	}

	public String getPropertiesToString() {
		log.info("$$$Pool creado con parametros$$$$$");
		return getPropiedades().toString();
	}

	public void reConnect() throws JMSException {
		log.info("Intento de reconexion JMS ");
		close();
//		PooledConnectionFactory pooledConnectionFactory = (PooledConnectionFactory) connectionFactory;
//		pooledConnectionFactory.stop();		
//		
		session = getSession();
	}

	public Connection getConnection() throws JMSException {
		if (connection == null) {
			connection = connectionFactory.createConnection();
			connection.start();
			
			log.info("Nueva conexion JMS creada " + connection.getClientID() + "\nMetadata: " + connection);
		}

		return connection;
	}
	public Connection getJmsConnection(){
		return connection;
	}
	
	protected Session createSession() throws JMSException {
		log.info("Solicitud de Nueva session JMS.");
		return getConnection().createSession(false, Session.AUTO_ACKNOWLEDGE);
	}

	public void send(Destination destination, Message message) throws JMSException {
		getProducer();
		producer.setTimeToLive(5000);
		producer.send(destination, message);
		
		if (log.isDebugEnabled()) {
			log.info("connection.getClientID() " + connection.getClientID() + "\nSent! to destination: " + destination + " message: " + message);
		}
	}

	public void send(Destination destination, Message message, boolean persistent, int priority, long timeToLive) throws JMSException {
		int deliveryMode = persistent ? DeliveryMode.PERSISTENT : DeliveryMode.NON_PERSISTENT;
		getProducer().send(destination, message, deliveryMode, priority, timeToLive);
		if (log.isDebugEnabled()) {
			log.debug("Sent! to destination: " + destination + " message: " + message);
		}
	}

	public Session getSession() throws JMSException {
		if (session == null) {
			session = createSession();
		}
		return session;
	}

	public MessageProducer getProducer() throws JMSException {
		if (producer == null) {
			producer = getSession().createProducer(null);
			producer.setDeliveryMode(deliveryMode);
			log.info("Producer message creado");
		}
		return producer;
	}
	public MessageProducer getJmsProducer() {
		return producer;
	}
	public void setProducer(MessageProducer producer) {
		this.producer = producer;
	}

	public MessageConsumer getConsumer(Destination destination) throws JMSException {
		return getConsumer(destination, true);
	}

	public MessageConsumer getConsumer(Destination destination, boolean create) throws JMSException {
		if (consumers == null) {
			consumers = new HashMap<Destination, MessageConsumer>();
		}

		MessageConsumer consumer = consumers.get(destination);
		if (create && consumer == null) {
			consumer = getSession().createConsumer(destination);
			consumers.put(destination, consumer);
			log.info("Consumer message creado: " + consumer);
		}
		return consumer;
	}

	public void closeConsumers() {
		if (consumers == null) {
			return;
		}
		try {
			log.info("Cerrando consumers ... " + connection.getClientID() + "\nMetadata: " + connection);
		} catch (JMSException e1) {
			log.warn("Exception al ", e1);
		}
		for (Iterator<MessageConsumer> it = consumers.values().iterator(); it.hasNext();) {

			MessageConsumer consumer = it.next();
			it.remove();

			try {
				consumer.setMessageListener(null);
				if (consumer instanceof MessageAvailableConsumer) {
					((MessageAvailableConsumer) consumer).setAvailableListener(null);
				}
				consumer.close();
				log.warn("Consumer cerrado...");
			} catch (JMSException e) {
				log.error("Exception al cerrar consumer ", e);
			}
		}
		if (producer != null){
			try {
				producer.close();
				log.warn("Producer JMS cerrado...");
			} catch (JMSException e) {
				log.error("Exception al cerrar producer ", e);
			}
		}
		if (session != null) {
			try {
				log.warn("Cerrando Session JMS...");
				session.close();
				log.warn("Session JMS cerrado...");				
			} catch (JMSException e) {
				log.error("Exception al cerrar session ", e);
			}
		}
//		try {
//			connection.close();
//			log.info("connection JMS cerrado");			
//		} catch (JMSException e) {
//			log.error("Error al cerrar connection JMS ", e);
//		}		

	}

	public void closeConsumer(Destination destination) throws JMSException {
		if (consumers == null) {
			return;
		}

		MessageConsumer consumer = consumers.get(destination);
		if (consumer != null) {
			consumers.remove(destination);

			consumer.setMessageListener(null);
			if (consumer instanceof MessageAvailableConsumer) {
				((MessageAvailableConsumer) consumer).setAvailableListener(null);
			}
			consumer.close();
			log.info("Consumer cerrado");
		}
//		try {
//			connection.close();
//			log.info("connection JMS cerrado");			
//		} catch (JMSException e) {
//			log.error("Error al cerrar connection JMS ", e);
//		}		
	}

	public void close() {
		try {
			if (consumers != null) {
				closeConsumers();
			}
			if (connection != null) {
				//connection.close();
			}
//			PooledConnectionFactory pooledConnectionFactory = (PooledConnectionFactory) connectionFactory;
//			pooledConnectionFactory.stop();
			log.info("connexion jms cerrado ");
		} catch (Exception e) {
			log.error("caught exception closing consumer", e);
		} finally {
			producer = null;
			session = null;
			//connection = null;
			if (consumers != null) {
				consumers.clear();
			}
			consumers = null;
		}
	}

	public boolean isClosed() {
		return consumers == null;
	}

	public List<MessageConsumer> getConsumers() {
		if (consumers == null) {
			consumers = new HashMap<Destination, MessageConsumer>();
		}
		return new ArrayList<MessageConsumer>(consumers.values());
	}

	public int getDeliveryMode() {
		return deliveryMode;
	}

	public void setDeliveryMode(int deliveryMode) {
		this.deliveryMode = deliveryMode;
	}

	public void setPropiedades0(Properties prop) {
//		PooledConnectionFactory pooledConnectionFactory = (PooledConnectionFactory) connectionFactory;
//		AmqJNDIPooledConnectionFactory amqJNDIPooledConnectionFactory = new AmqJNDIPooledConnectionFactory(
//				(ActiveMQConnectionFactory) pooledConnectionFactory.getConnectionFactory());
//		amqJNDIPooledConnectionFactory.setProperties(prop);
//		// this.propiedades = amqJNDIPooledConnectionFactory.getProperties();
//		connectionFactory = (PooledConnectionFactory) amqJNDIPooledConnectionFactory;
	}

	public Properties getPropiedades() {
		Properties prop = new Properties();

//		PooledConnectionFactory pooledConnectionFactory = (PooledConnectionFactory) connectionFactory;
//		AmqJNDIPooledConnectionFactory amqJNDIPooledConnectionFactory = new AmqJNDIPooledConnectionFactory(
//				(ActiveMQConnectionFactory) pooledConnectionFactory.getConnectionFactory());
		ActiveMQConnectionFactory amqJNDIPooledConnectionFactory = (ActiveMQConnectionFactory) connectionFactory;
		log.info("XXX:PROPER " + amqJNDIPooledConnectionFactory.getProperties().toString());
		amqJNDIPooledConnectionFactory.setProperties(prop);
		return prop;
	}

	public void setConnectionFactory(ConnectionFactory connectionFactory) {
		this.connectionFactory = connectionFactory;
	}

	public ConnectionFactory getConnectionFactory() {
		return connectionFactory;
	}

}
