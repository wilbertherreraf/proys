package gob.bcb.core.utils;

import java.io.File;
import java.io.FileInputStream;
import java.security.InvalidAlgorithmParameterException;
import java.security.KeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Provider;
import java.util.Collections;
import java.util.Iterator;

import javax.xml.crypto.MarshalException;
import javax.xml.crypto.XMLStructure;
import javax.xml.crypto.dom.DOMStructure;
import javax.xml.crypto.dsig.CanonicalizationMethod;
import javax.xml.crypto.dsig.DigestMethod;
import javax.xml.crypto.dsig.Reference;
import javax.xml.crypto.dsig.SignatureMethod;
import javax.xml.crypto.dsig.SignedInfo;
import javax.xml.crypto.dsig.Transform;
import javax.xml.crypto.dsig.XMLObject;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureException;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMSignContext;
import javax.xml.crypto.dsig.dom.DOMValidateContext;
import javax.xml.crypto.dsig.keyinfo.KeyInfo;
import javax.xml.crypto.dsig.keyinfo.KeyInfoFactory;
import javax.xml.crypto.dsig.keyinfo.KeyValue;
import javax.xml.crypto.dsig.spec.C14NMethodParameterSpec;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class XMLSignatureHelper {
	private XMLSignatureFactory signatureFactory;
	private KeyPair keyPair;
	private KeyInfo keyInfo;
	private Reference reference;
	private String uri;
	private DigestMethod digestMethod;
	private SignedInfo signedInfo;
	private XMLSignature signature;
	private Document documentToSign;

	public XMLSignatureHelper() throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		String providerName = System.getProperty("xmlSignFactoryProvider", "org.jcp.xml.dsig.internal.dom.XMLDSigRI");

		signatureFactory = XMLSignatureFactory.getInstance("DOM", (Provider) Class.forName(providerName).newInstance());
	}

	public XMLSignatureHelper(String type) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		String providerName = System.getProperty("xmlSignFactoryProvider", "org.jcp.xml.dsig.internal.dom.XMLDSigRI");

		signatureFactory = XMLSignatureFactory.getInstance(type, (Provider) Class.forName(providerName).newInstance());
	}

	private void createDigestMethod(String digestMethodName) throws NoSuchAlgorithmException, Exception {
		if (digestMethodName.equals("RIPEMD-160")) {
			this.digestMethod = signatureFactory.newDigestMethod(DigestMethod.RIPEMD160, null);
		} else if (digestMethodName.equals("SHA1")) {
			this.digestMethod = signatureFactory.newDigestMethod(DigestMethod.SHA1, null);
		} else if (digestMethodName.equals("SHA256")) {
			this.digestMethod = signatureFactory.newDigestMethod(DigestMethod.SHA256, null);
		} else if (digestMethodName.equals("SHA512")) {
			this.digestMethod = signatureFactory.newDigestMethod(DigestMethod.SHA512, null);
		} else {
			throw new Exception("createReference: invalid digest method [" + digestMethodName + "]");
		}
	}

	public void createReference(String uri, String digestMethodName) throws NoSuchAlgorithmException, InvalidAlgorithmParameterException, Exception {
		this.uri = uri;

		createDigestMethod(digestMethodName);
		reference = signatureFactory.newReference(this.uri, this.digestMethod);
	}

	public void createReferenceEnveloped(String uri, String digestMethodName) throws NoSuchAlgorithmException, InvalidAlgorithmParameterException,
			Exception {
		this.uri = uri;

		createDigestMethod(digestMethodName);
		reference = signatureFactory.newReference(this.uri, this.digestMethod,
				Collections.singletonList(signatureFactory.newTransform(Transform.ENVELOPED, (XMLStructure) null)), null, null);
	}

	public void createReferenceEnveloping(String digestMethodName) throws NoSuchAlgorithmException, InvalidAlgorithmParameterException, Exception {
		this.uri = null;

		createDigestMethod(digestMethodName);
		
		reference = signatureFactory.newReference("#object", this.digestMethod);
	}

	public void generateKeys(String keyMethod, int keySize, PrivateKey privateKey) throws NoSuchAlgorithmException, KeyException {
		KeyPairGenerator kpg = KeyPairGenerator.getInstance(keyMethod);
		kpg.initialize(keySize);
		keyPair = kpg.generateKeyPair();
		//keyPair = new KeyPair(null,privateKey); 
		KeyInfoFactory kif = signatureFactory.getKeyInfoFactory();
		KeyValue kv = kif.newKeyValue(keyPair.getPublic());

		keyInfo = kif.newKeyInfo(Collections.singletonList(kv));
	}

	public void createSignedInfo() throws NoSuchAlgorithmException, InvalidAlgorithmParameterException {
		signedInfo = signatureFactory.newSignedInfo(
				signatureFactory.newCanonicalizationMethod(CanonicalizationMethod.INCLUSIVE, (C14NMethodParameterSpec) null),
				signatureFactory.newSignatureMethod(SignatureMethod.RSA_SHA1, null), Collections.singletonList(reference));
	}

	public XMLSignature getSignature() {
		return (signatureFactory.newXMLSignature(signedInfo, keyInfo));
	}

	public void createSignature() {
		signature = signatureFactory.newXMLSignature(signedInfo, keyInfo);
	}

	public void signDocument(Document doc, XMLStructure content, PrivateKey privateKey) throws ParserConfigurationException, MarshalException, XMLSignatureException {
		XMLObject obj = signatureFactory.newXMLObject(Collections.singletonList(content), "object", null, null);

		DOMSignContext dsc = new DOMSignContext(privateKey, doc);
		dsc.setDefaultNamespacePrefix("ds");
		signature = signatureFactory.newXMLSignature(signedInfo, keyInfo, Collections.singletonList(obj), null, null);

		signature.sign(dsc);
	}

	public void signDocument(Document doc) throws ParserConfigurationException, MarshalException, XMLSignatureException {
		DOMSignContext dsc = new DOMSignContext(keyPair.getPrivate(), doc.getDocumentElement());

		signature = signatureFactory.newXMLSignature(signedInfo, keyInfo);

		signature.sign(dsc);
	}

	public Document getSignedDocument() throws ParserConfigurationException, MarshalException, XMLSignatureException {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		dbf.setNamespaceAware(true); // must be set
		Document doc = dbf.newDocumentBuilder().newDocument();

		DOMSignContext signContext = new DOMSignContext(keyPair.getPrivate(), doc);
		createSignature();
		signature.sign(signContext);

		return (doc);
	}

	public Document getSignedDocument(String uri, String digestMethodName, String keyType, int keySize) throws Exception {
		createReference(uri, digestMethodName);
		createSignedInfo();
		//generateKeys(keyType, keySize);

		return (getSignedDocument());
	}

	public boolean validateSignature(Document doc) throws MarshalException, XMLSignatureException, Exception {
		NodeList nl = doc.getElementsByTagNameNS(XMLSignature.XMLNS, "Signature");

		if (nl.getLength() == 0) {
			throw new Exception("'Signature' element must be present");
		}

		DOMValidateContext validateContext = new DOMValidateContext(new KeyValueSelector(), nl.item(0));

		XMLSignature signature = signatureFactory.unmarshalXMLSignature(validateContext);

		return (signature.validate(validateContext));
	}

	public void validateReferences(Document doc) throws MarshalException, XMLSignatureException, Exception {
		NodeList nl = doc.getElementsByTagNameNS(XMLSignature.XMLNS, "Signature");

		if (nl.getLength() == 0) {
			throw new Exception("'Signature' element must be present");
		}

		DOMValidateContext validateContext = new DOMValidateContext(new KeyValueSelector(), nl.item(0));

		XMLSignature signature = signatureFactory.unmarshalXMLSignature(validateContext);

		boolean sv = signature.getSignatureValue().validate(validateContext);
		System.out.println("signature validation status: " + sv);

		Iterator iter = signature.getSignedInfo().getReferences().iterator();

		while (iter.hasNext()) {
			Reference ref = (Reference) iter.next();
			System.out.println("ID = [" + ref.getId() + "] VALIDITY = [" + ref.validate(validateContext) + "]");
		}
	}

	public static void main(String[] args) {
		String keystoreType = "JKS";
		String keystoreFile = "e:/keystore";
		String keystorePass = "qazwsx";
		String privateKeyAlias = "oiosaml";
		String privateKeyPass = "qazwsx";
		String archDesalida = "e:/TGNyCorrespFIRMADO.xml";
		String archAFirmar = "d:/TGNyCorrespSinFIRMAR.xml";
		String codFirmador = "oiosaml";
        
		String xml = "<fo><valor>asd1</valor></fo>";
		File signatureFile = new File (archDesalida);
		//Manejo de Documentos XML
		/*
		 * Almacen de Claves
		 */
		
		try {
			KeyStore ks = KeyStore.getInstance (keystoreType);
			FileInputStream fis = new FileInputStream (keystoreFile);
			//Cargado de Almacen de Claves
			ks.load (fis, keystorePass.toCharArray ());
			//Extraccin de Clave Privada
			PrivateKey privateKey = (PrivateKey) ks.getKey (privateKeyAlias, privateKeyPass.toCharArray ());
			
			XMLSignatureHelper sigHelper = new XMLSignatureHelper();
			
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			dbf.setNamespaceAware(true);

			//Document doc = dbf.newDocumentBuilder().parse(args[0]);
			Document doc = UtilsXML.getDomFromString(xml);
//			NodeList nl = doc.getDocumentElement();
//
//			if (nl.getLength() == 0) {
//				System.out.println("Cannot find '" + args[1] + "' element");
//				System.exit(1);
//			}
//
			Node n = doc.getDocumentElement();
			XMLStructure content = new DOMStructure(n);

			sigHelper.createReferenceEnveloping("SHA1");
			sigHelper.createSignedInfo();
			sigHelper.generateKeys("RSA", 512,privateKey);
			sigHelper.signDocument(doc, content,privateKey);

			TransformerFactory tf = TransformerFactory.newInstance();
			Transformer trans = tf.newTransformer();
			trans.transform(new DOMSource(doc), new StreamResult(System.out));
			System.out.println();
			System.out.println("==========================");			
            if(!sigHelper.validateSignature(doc)) {
				System.out.println("Signature validated failed");
				sigHelper.validateReferences(doc);
			} else {
				System.out.println("Signature is valid!");
			}			
		} catch (Exception e) {
			System.out.println("EXCEPTION: " + e);
			e.printStackTrace();
			System.exit(1);
		}
	}
}
