/*
 * To change this template, choose Tools | Templates

 * and open the template in the editor.
 */
package gob.bcb.core.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

public class ArchivoUtil {
	private static final Logger log = Logger.getLogger(ArchivoUtil.class);
	/**
	 * Metodo que copia archivos en el sitema de archivos
	 * 
	 * @param origen
	 *            El archivo que se desea copiar
	 * @param destino
	 *            La ruta de la copia
	 * @throws FileNotFoundException
	 *             En caso de no existir el archivo origen
	 * @throws IOException
	 *             En caso de que no se pueda escribir en disco
	 */
	public static void copiarArchivos(File origen, File destino) throws FileNotFoundException, IOException {

		InputStream in = new FileInputStream(origen);
		// For Overwrite the file.
		OutputStream out = new FileOutputStream(destino);

		byte[] buf = new byte[1024];
		int len;
		while ((len = in.read(buf)) > 0) {
			out.write(buf, 0, len);
		}
		in.close();
		out.close();
	}

	/**
	 * Elimina la barra de separacion de rutas al final del nombre
	 * 
	 * @param nombre
	 *            El nombre del archivo
	 * @return El nombre del archivo sin la barra final de separador de rutas
	 */
	public static String formatearNombre(String nombre) {
		if (nombre.lastIndexOf('\\') > 0) {
			nombre = nombre.substring(nombre.lastIndexOf('\\') + 1);
		} else if (nombre.lastIndexOf('/') > 0) {
			nombre = nombre.substring(nombre.lastIndexOf('/') + 1);
		}
		return nombre;
	}
	public static String obtenerExtension(String nombre) {
		String extension ="" ;
		if (nombre == null){
			return extension;
		}
		int ultimoPunto = nombre.lastIndexOf('.');
		if (ultimoPunto > 0) {
			extension = nombre.substring(ultimoPunto + 1);
		} 
		return extension;
	}
	/**
	 * Metodo que retorna el tipo de mime de un archivo a partir de su extension
	 * 
	 * @param nombre
	 *            Nombre del archivo
	 * @return El tipo mime para el archivo
	 */
	public static String obtenerMime(String nombre) {
		String mime = null;
		String extension =obtenerExtension(nombre);
		if (extension != null && extension.trim().length() > 0) {
			mime = getMimeFromExt(extension);
		} else {
			mime = "application/x-binary";
		}
		return mime;
	}

	public static String getMimeFromExt(String extension) {
		String mime = null;
		if (mimes.containsKey(extension.toLowerCase())){
			return mimes.get(extension.toLowerCase()); 
		}
		
		if (extension.equalsIgnoreCase("avi")) {
			mime = "video/avi";
		} else if (extension.equalsIgnoreCase("bin")) {
			mime = "application/x-binary";
		} else if (extension.equalsIgnoreCase("bmp")) {
			mime = "image/bmp";
		} else if (extension.equalsIgnoreCase("exe")) {
			mime = "application/octet-stream";
		} else if (extension.equalsIgnoreCase("gif")) {
			mime = "image/gif";
		} else if (extension.equalsIgnoreCase("java")) {
			mime = "text/plain";
		} else if (extension.equalsIgnoreCase("jpeg")) {
			mime = "image/jpeg";
		} else if (extension.equalsIgnoreCase("jpg")) {
			mime = "image/jpeg";
		} else if (extension.equalsIgnoreCase("mid")) {
			mime = "audio/midi";
		} else if (extension.equalsIgnoreCase("midi")) {
			mime = "audio/midi";
		} else if (extension.equalsIgnoreCase("mov")) {
			mime = "video/quicktime";
		} else if (extension.equalsIgnoreCase("mp3")) {
			mime = "audio/mpeg3";
		} else if (extension.equalsIgnoreCase("mpeg")) {
			mime = "video/mpeg";
		} else if (extension.equalsIgnoreCase("mpg")) {
			mime = "video/mpeg";
		} else if (extension.equalsIgnoreCase("mpp")) {
			mime = "application/vnd.ms-project";
		} else if (extension.equalsIgnoreCase("pdf")) {
			mime = "application/pdf";
		} else if (extension.equalsIgnoreCase("pot")) {
			mime = "application/mspowerpoint";
		} else if (extension.equalsIgnoreCase("png")) {
			mime = "image/png";
		} else if (extension.equalsIgnoreCase("ps")) {
			mime = "application/postscript";
		} else if (extension.equalsIgnoreCase("tar")) {
			mime = "application/x-tar";
		} else if (extension.equalsIgnoreCase("text")) {
			mime = "text/plain";
		} else if (extension.equalsIgnoreCase("tgz")) {
			mime = "application/gnutar";
		} else if (extension.equalsIgnoreCase("txt")) {
			mime = "text/plain";
		} else if (extension.equalsIgnoreCase("xla")) {
			mime = "application/excel";
		} else if (extension.equalsIgnoreCase("zip")) {
			mime = "application/zip";
		} else if (extension.equalsIgnoreCase("odt")) {
			mime = "application/vnd.oasis.opendocument.text";
		} else if (extension.equalsIgnoreCase("ods")) {
			mime = "application/vnd.oasis.opendocument.spreadsheet";
		} else if (extension.equalsIgnoreCase("odp")) {
			mime = "application/vnd.oasis.opendocument.presentation";
		} else if (extension.equalsIgnoreCase("odg")) {
			mime = "application/vnd.oasis.opendocument.graphics";
		} else if (extension.equalsIgnoreCase("odc")) {
			mime = "application/vnd.oasis.opendocument.chart";
		} else if (extension.equalsIgnoreCase("odf")) {
			mime = "application/vnd.oasis.opendocument.formula";
		} else if (extension.equalsIgnoreCase("odb")) {
			mime = "application/vnd.oasis.opendocument.database[cita requerida]";
		} else if (extension.equalsIgnoreCase("odi")) {
			mime = "application/vnd.oasis.opendocument.image";
		} else if (extension.equalsIgnoreCase("odm")) {
			mime = "application/vnd.oasis.opendocument.text-master";
		} else {
			mime = "application/x-binary";
		}
		return mime;
	}

	public static String encriptarCodArchivo(Integer codArchivo) {
		return "" + ((codArchivo * 3) + 7);
	}

	public static Integer desencriptarCodArchivo(String codArchivo) {
		Integer codigo = Integer.parseInt(codArchivo);
		codigo = codigo - 7;
		codigo = codigo / 3;
		return codigo;
	}
	public static String checkSumFile(String pathFile) throws Exception {
		if (StringUtils.isBlank(pathFile)){
			return null;
		}
		FileInputStream fis = new FileInputStream(pathFile);
		
		return checkSumFile(fis) ;
	}
	public static String checkSumFile(InputStream fis) throws Exception {
		//FileInputStream fis = new FileInputStream(new File(pathFile));
		MessageDigest messageDigest = MessageDigest.getInstance("SHA1");		
		byte[] dataBytes = new byte[1024];
		int nread = 0;

		while ((nread = fis.read(dataBytes)) != -1) {
			messageDigest.update(dataBytes, 0, nread);
		}
		byte[] mdbytes = messageDigest.digest();
		
		StringBuffer sb = new StringBuffer("");
		for (int i = 0; i < mdbytes.length; i++) {
			sb.append(Integer.toString((mdbytes[i] & 0xff) + 0x100, 16).substring(1));
		}
		
		log.info("Hash " + sb.toString() );
		return sb.toString();
	}
	
	public static String getOriginalFilename(String pathFile) {
		// check for Unix-style path
		int pos = pathFile.lastIndexOf("/");
		if (pos == -1) {
			// check for Windows-style path
			pos = pathFile.lastIndexOf("\\");
		}
		if (pos != -1)  {
			// any sort of path separator found
			return pathFile.substring(pos + 1);
		}
		else {
			// plain name
			return pathFile;
		}
	}
	public static File checkFile(String pathFile) {
		if (StringUtils.isBlank(pathFile)) {
			log.error("Ruta archivo nulo");
			// return;
			throw new RuntimeException("Ruta archivo nulo");
		}

		File h = new File(pathFile);
		if (!h.exists() || h.isDirectory()) {
			log.error("Archivo inexistente " + pathFile);
			throw new RuntimeException("Archivo inexistente " + pathFile);
		}
		return h;
	}
	
	public static void main(String[] args) {
		
		String archivoOut = ArchivoUtil.getMimeFromExt(ArchivoUtil.obtenerExtension("xlsx"));
		System.out.println(archivoOut);
	}
	
	public static final Map<String, String> mimes = new HashMap<String,String>();
	
	static {
		mimes.put("doc","application/msword");
		mimes.put("dot","application/msword");
		mimes.put("docx","application/vnd.openxmlformats-officedocument.wordprocessingml.document");
		mimes.put("dotx","application/vnd.openxmlformats-officedocument.wordprocessingml.template");
		mimes.put("docm","application/vnd.ms-word.document.macroEnabled.12");
		mimes.put("dotm","application/vnd.ms-word.template.macroEnabled.12");
		mimes.put("xls","application/vnd.ms-excel");
		mimes.put("xlt","application/vnd.ms-excel");
		mimes.put("xla","application/vnd.ms-excel");
		mimes.put("xlsx","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		mimes.put("xltx","application/vnd.openxmlformats-officedocument.spreadsheetml.template");
		mimes.put("xlsm","application/vnd.ms-excel.sheet.macroEnabled.12");
		mimes.put("xltm","application/vnd.ms-excel.template.macroEnabled.12");
		mimes.put("xlam","application/vnd.ms-excel.addin.macroEnabled.12");
		mimes.put("xlsb","application/vnd.ms-excel.sheet.binary.macroEnabled.12");
		mimes.put("ppt","application/vnd.ms-powerpoint");
		mimes.put("pot","application/vnd.ms-powerpoint");
		mimes.put("pps","application/vnd.ms-powerpoint");
		mimes.put("ppa","application/vnd.ms-powerpoint");
		mimes.put("pptx","application/vnd.openxmlformats-officedocument.presentationml.presentation");
		mimes.put("potx","application/vnd.openxmlformats-officedocument.presentationml.template");
		mimes.put("ppsx","application/vnd.openxmlformats-officedocument.presentationml.slideshow");
		mimes.put("ppam","application/vnd.ms-powerpoint.addin.macroEnabled.12");
		mimes.put("pptm","application/vnd.ms-powerpoint.presentation.macroEnabled.12");
		mimes.put("potm","application/vnd.ms-powerpoint.template.macroEnabled.12");
		mimes.put("ppsm","application/vnd.ms-powerpoint.slideshow.macroEnabled.12");
		
	}
}
