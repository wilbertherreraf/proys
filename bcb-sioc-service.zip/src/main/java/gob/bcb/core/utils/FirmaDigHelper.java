package gob.bcb.core.utils;

import gob.bcb.core.exception.InternaException;
import gob.bcb.core.exception.MsgErr;
import gob.bcb.core.exception.VerificaException;
import gob.bcb.service.commons.ConfigurationServ;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.UTFDataFormatException;
import java.io.UnsupportedEncodingException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.cert.CertificateException;
import java.security.cert.CertificateExpiredException;
import java.security.cert.CertificateNotYetValidException;
import java.security.cert.X509Certificate;
import java.util.Calendar;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.xml.security.exceptions.XMLSecurityException;
import org.apache.xml.security.signature.ObjectContainer;
import org.apache.xml.security.signature.XMLSignature;
import org.apache.xml.security.signature.XMLSignatureException;
import org.apache.xml.security.transforms.TransformationException;
import org.apache.xml.security.transforms.Transforms;
import org.apache.xml.security.utils.Constants;
import org.apache.xml.security.utils.XMLUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.sun.org.apache.xpath.internal.CachedXPathAPI;

public class FirmaDigHelper {
	private static final Log log = LogFactory.getLog(FirmaDigHelper.class);

	static {
		// Llamado al metodo estatico de cargado de las libreras xml-security
		org.apache.xml.security.Init.init();
	}

	public FirmaDigHelper() {
	}

	public String sign(String mensajeXML) throws TransformationException, Exception {
		// Manejo de Documentos XML

		/*
		 * Almacen de Claves
		 */
		String keystoreType = "JKS";
		String keystoreFile = ConfigurationServ.getConfigProperty(gob.bcb.service.servicioSioc.common.Constants.PROP_BCB_KEY_STORE_FILE); // "/opt/certificados/sigmaSiodex/cecilia.jks";
		String keystorePass = ConfigurationServ.getConfigProperty(gob.bcb.service.servicioSioc.common.Constants.PROP_BCB_KEY_STORE_PASS); // "12345678";
		String privateKeyAlias = ConfigurationServ.getConfigProperty(gob.bcb.service.servicioSioc.common.Constants.PROP_BCB_PRIVATE_KEY_ALIAS);// "bcb";
		String privateKeyPass = ConfigurationServ.getConfigProperty(gob.bcb.service.servicioSioc.common.Constants.PROP_BCB_PRIVATE_KEY_PASS); // "12345678";
		
		KeyStore ks = KeyStore.getInstance(keystoreType);
		FileInputStream fis = new FileInputStream(keystoreFile);
		// Cargado de Almacen de Claves
		ks.load(fis, keystorePass.toCharArray());
		// Extraccin de Clave Privada
		PrivateKey privateKey = (PrivateKey) ks.getKey(privateKeyAlias, privateKeyPass.toCharArray());
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		// Inicializar Document Builder Factory
		dbf.setNamespaceAware(true);
		// Crear Manejador de Documentos
		DocumentBuilder db = dbf.newDocumentBuilder();
		org.w3c.dom.Document doc = db.newDocument();
		// Archivo de entrada a firmar
		Document datosDoc = UtilsXML.getDomFromString(mensajeXML);
		String BaseURI = "AAA"; //signatureFile.toURL().toString();
		XMLSignature sig = new XMLSignature(doc, BaseURI, XMLSignature.ALGO_ID_SIGNATURE_RSA);

		doc.appendChild(sig.getElement());
		ObjectContainer obj; // Actualizar //////////////////////////////////
		{
			obj = new ObjectContainer(doc);
			// Obtencion de los datos a firmar
			Element ele = datosDoc.getDocumentElement();
			Node nodo = doc.importNode(ele, true);
			obj.appendChild(nodo);
			String Id;
			{
				Calendar cal = Calendar.getInstance();
				log.debug("Date: " + cal.getTime().toString());
				Id = privateKeyAlias + " " + cal.getTime().toString();
			}

			obj.setId(Id);
			sig.appendObject(obj);

			Transforms transforms = new Transforms(doc);

			transforms.addTransform(Transforms.TRANSFORM_C14N_OMIT_COMMENTS);
			sig.addDocument("#" + Id, transforms, Constants.ALGO_ID_DIGEST_SHA1);
		}

		{
			log.debug("Iniciando proceso de firma... ");
			sig.sign(privateKey);
			log.debug("Finalizado proceso de firma...");
		}

		
		Element keyinfo = doc.createElementNS(sig.getBaseNamespace(), "ds:KeyInfo");
		Element keyname = doc.createElement("ds:KeyName");
		keyname.appendChild(doc.createTextNode(privateKeyAlias));
		keyinfo.appendChild(keyname);
		Element firma = doc.getDocumentElement();
		NodeList last = doc.getElementsByTagName("ds:Object");
		firma.insertBefore(keyinfo, last.item(0));
		
		String s = UtilsXmlBind.getStringFromDom(doc);
		
//		log.info("$$$$$$$$$$ Mensaje firmado $$$$$$$$$$ ");
//		log.info(firma);
//		log.info("$$$$$$$$$$ $$$$$$$$$$ $$$$$$$$$$ ");
		return s;
	}


	public void verify(String mensajeFirmado) throws 
			ParserConfigurationException, SAXException, IOException {
		// Cargar certificado
		X509Certificate cert = obtieneCertificado();
		Document doc = UtilsXML.getDomFromString(mensajeFirmado);
		verificaFirmaDeMensajeRecibido(cert, doc);
	}
	
	public X509Certificate obtieneCertificado()  {
		// inicializar datos
		X509Certificate cert = null;

		String keystoreType = "JKS";
		String keystoreFile = ConfigurationServ.getConfigProperty(gob.bcb.service.servicioSioc.common.Constants.PROP_BCB_KEY_STORE_FILE); // "/opt/certificados/sigmaSiodex/cecilia.jks";
		String keystorePass = ConfigurationServ.getConfigProperty(gob.bcb.service.servicioSioc.common.Constants.PROP_BCB_KEY_STORE_PASS); // "12345678";
		String codFirmador = ConfigurationServ.getConfigProperty(gob.bcb.service.servicioSioc.common.Constants.PROP_BCB_CERTIFICATE_ALIAS);// "bcb";

		// Obtener alias de certificado
		try {
			KeyStore ks = KeyStore.getInstance(keystoreType);
			FileInputStream fis = new FileInputStream(keystoreFile);
			// Cargado de Almacen de Claves
			ks.load(fis, keystorePass.toCharArray());

			cert = (X509Certificate) ks.getCertificate(codFirmador);

		} catch (UTFDataFormatException e) {
			// Lanzamiento de Excepcion
			log.error("UTFDataFormatException " + e.getMessage());			
			throw new InternaException(MsgErr.getMessage("X025") + e.getMessage(), e);
		} catch (IOException e) {
			// Lanzamiento de Excepcion
			log.error("IOException " + e.getMessage());			
			throw new InternaException(MsgErr.getMessage("I010") + e.getMessage(), e);
		} catch (KeyStoreException e) {
			log.error("KeyStoreException " + e.getMessage());			
			throw new InternaException(MsgErr.getMessage("F001") + e.getMessage(), e);
		} catch (NoSuchAlgorithmException e) {
			log.error("NoSuchAlgorithmException " + e.getMessage());			
			throw new InternaException(MsgErr.getMessage("F002") + e.getMessage(), e);
		} catch (CertificateException e) {
			log.error("CertificateException " + e.getMessage());			
			throw new InternaException(MsgErr.getMessage("F003") + e.getMessage(), e);
		}
		return cert;
	}

	/* Realiza la verificacin de firma digital */
	/**
	 * Metodo para verificar o validar la firma digital del documento XML
	 * recibido
	 * 
	 * @param cert
	 *            Variable que contiene el certificado del Participante en
	 *            formato X509
	 * @param mensajeFirmado
	 *            Cadena que representa el mensaje XML recibido
	 * @throws VerificaException
	 *             Excepcion de tipo VERIFICA
	 */
	public void verificaFirmaDeMensajeRecibido(X509Certificate cert, Document doc)  {
		// Inicializar variable
		boolean verifica = false;
		XMLSignature firma;
		try {
			String currentSystemId = "memory://";
			CachedXPathAPI xpathAPI = new CachedXPathAPI();
			Element contexto = XMLUtils.createDSctx(doc, "ds", Constants.SignatureSpecNS);
			Element dsElem = (Element) xpathAPI.selectSingleNode(doc, "//ds:Signature", contexto);
			firma = new XMLSignature(dsElem, currentSystemId);
		} catch (TransformerException e) {
			// Lanzamiento de Excepcion
			log.error("TransformerException " + e.getMessage());
			throw new VerificaException(MsgErr.getMessage("V007"), e);
		} catch (XMLSignatureException e) {
			// Lanzamiento de Excepcion*/
			log.error("XMLSignatureException " + e.getMessage());
			throw new VerificaException(MsgErr.getMessage("V008"), e);
		} catch (XMLSecurityException e) {
			// Lanzamiento de Excepcion
			log.error("XMLSecurityException " + e.getMessage());			
			throw new VerificaException(MsgErr.getMessage("V009"), e);
		} catch (Exception e) {
			// Lanzamiento de Excepcion
			log.error("Exception " + e.getMessage());			
			VerificaException verEx = new VerificaException(MsgErr.getMessage("I017"), e);
			throw verEx;
		}
		/*
		 * Verificacion de la firma
		 */
		try {
			cert.checkValidity();
			verifica = firma.checkSignatureValue(cert);
			log.info("Firmita " + verifica);
		} catch (CertificateExpiredException e) {
			// Lanzamiento de Excepcion
			log.error("CertificateExpiredException " + e.getMessage());			
			throw new VerificaException(MsgErr.getMessage("V010"), e);
		} catch (CertificateNotYetValidException e) {
			// Lanzamiento de Excepcion
			log.error("CertificateNotYetValidException " + e.getMessage());			
			throw new VerificaException(MsgErr.getMessage("V011"), e);
		} catch (XMLSignatureException e) {
			// Lanzamiento de Excepcion
			log.error("XMLSignatureException " + e.getMessage());			
			throw new VerificaException(MsgErr.getMessage("V008", e.toString()), e);
		}
		
		if (!verifica){
			log.error("Firma INVALIDA!!!! " + verifica + " " + MsgErr.getMessage("VS03"));
			throw new VerificaException(MsgErr.getMessage("VS03"));
		}
	}

	public static void main(String[] args) {
		Properties properties = UtilsProperties.loadFilePropertiesFromClass("service.properties");
		String pathHome = properties.getProperty("path.home");
		ConfigurationServ.setServiceName(properties.getProperty("service.name"));
		
		ConfigurationServ.setHomeProperty(pathHome);
		ConfigurationServ.init(pathHome);
		
		String archDesalida = "e:/TGNyCorrespFIRMADO2.xml";
		String archFirmado = "e://sinfirmado_orig.xml";
		archFirmado = "e://aaa.xml";
		
		FirmaDigHelper firmaDigHelper = new FirmaDigHelper();
		try {
			UtilsFile.copy(archFirmado, "e://firmado_origc.xml");
			String mensajeXML = UtilsFile.readFileAsString2(archFirmado);
			System.out.println(mensajeXML);
			mensajeXML = UtilsFile.readFileAsString2(archFirmado);
//			System.out.println(mensajeXML);			
			//String firmadito = firmaDigHelper.sign(mensajeXML);
//
			UtilsFile.grabaEnArchivo(mensajeXML, archDesalida);
			firmaDigHelper.verify(mensajeXML);			
			

//			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
//			// Inicializar Document Builder Factory
//			dbf.setNamespaceAware(true);
//			// Crear Manejador de Documentos
//			DocumentBuilder db = dbf.newDocumentBuilder();
//			// Archivo de entrada a firmar
//			Document datosDoc = db.parse(archDesalida);
//			X509Certificate cert = firmaDigHelper.obtieneCertificado();
//			firmaDigHelper.verificaFirmaDeMensajeRecibido(cert, datosDoc);
//		} catch (TransformationException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
	