package gob.bcb.core.utils;

import java.io.BufferedReader;
import java.io.FileReader;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.UUID;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.configuration.XMLConfiguration;
import org.w3c.dom.Document;

import com.thoughtworks.xstream.XStream;


/**
 * @author wilherrera
 * 
 */
public final class Utils {

	/**
	 * Making nice XML for output in browser, i.e. converting &lt; to &amp;lt;, &gt; to &amp;gt;
	 * etc.
	 */
	public static String makeXML(String param) {
		String xml = param;
		if (xml != null && !"".equals(xml)) {
			xml = xml.replaceAll("><", ">\n<");
			xml = xml.replaceAll("<", "&lt;");
			xml = xml.replaceAll(">", "&gt;");
			xml = xml.replaceAll("\n", "<br />");
		}
		return xml;
	}

	/**
	 * @return A beautified xml string
	 */
	public static String beautifyAndHtmlXML(String xml, String split) {
		return makeXML(beautifyXML(xml, split));
	}

	/**
	 * @return A beautified xml string
	 */
	public static String beautifyXML(String xml, String split) {
		String s = "";
		if (split != null)
			s = ".:split:.";

		if (xml == null || "".equals(xml))
			return xml;

		StringBuffer result = new StringBuffer();

		String[] results = xml.split("<");
		for (int i = 1; i < results.length; i++) {
			results[i] = "<" + results[i].trim();
			if (results[i].endsWith("/>")) {
				result.append(results[i]).append(s);
			} else if (results[i].startsWith("</")) {
				result.append(results[i]).append(s);
			} else if (results[i].endsWith(">")) {
				result.append(results[i]).append(s);
			} else {
				result.append(results[i]);
			}
		}
		// result = result.trim();

		if (split == null)
			return result.toString().trim();

		StringBuilder newResult = new StringBuilder();
		String ident = "";
		results = result.toString().split(s);
		for (int i = 0; i < results.length; i++) {
			if (results[i].startsWith("</"))
				ident = ident.substring(split.length());

			newResult.append(ident).append(results[i]).append("\n");

			if (!results[i].startsWith("<!") && !results[i].startsWith("<?") && results[i].indexOf("</") == -1
					&& results[i].indexOf("/>") == -1)
				ident += split;
		}
		return newResult.toString();
	}

	/**
	 * Generate a valid xs:ID string.
	 */
	public static String generateUUID() {
		return "_" + UUID.randomUUID().toString();
	}

	public static String objectToXML(Object object) {
		String xml = null;
		XStream xstream = new XStream();
		String packageObject[] = object.getClass().getPackage().toString().split(" ");
		if (packageObject.length == 1) {
			xstream.aliasPackage("", packageObject[0].trim());
		} else if (packageObject.length > 1) {
			xstream.aliasPackage("", packageObject[1].trim());
		}
		xml = xstream.toXML(object);
		return xml;
	}

	public static Object newInstance(String name) {
		try {
			Class<?> c = Class.forName(name);
			return c.newInstance();
		} catch (Exception e) {
			throw new RuntimeException("No se puede crear instancia de " + name, e);
		}
	}

	public static String readFileAsString(String filePath) throws java.io.IOException {
		String result = null;
		BufferedReader reader = null;
		try {
			StringBuffer fileData = new StringBuffer(1000);
			reader = new BufferedReader(new FileReader(filePath));
			char[] buf = new char[1024];
			int numRead = 0;
			while ((numRead = reader.read(buf)) != -1) {
				fileData.append(buf, 0, numRead);
			}
			reader.close();
			result = fileData.toString();
		} finally {
			try {
				reader.close();
			} catch (Exception e) {
				// no hacer nada
			}
		}
		return result;
	}
    public static String getAddressHost() throws Exception {
        String hostName = "";
        try {
            InetAddress addr = InetAddress.getLocalHost();
            hostName = addr.getHostAddress();
        } catch (UnknownHostException e) {
            hostName = "localhost";
        }
        return hostName;
    }
    public static String getNameHost() throws Exception {
        String hostName = "";
        try {
            InetAddress addr = InetAddress.getLocalHost();
            hostName = addr.getCanonicalHostName();
        } catch (UnknownHostException e) {
            hostName = "localhost";
        }
        return hostName;
    }
    
	/**
	 * Dado un objeto XMLConfiguration busca mediante una consulta xpath una valor en el mismo
	 * @param config Archivo XMLConfiguration contenedor de propiedades
	 * @param expXpath ruta de consulta escrita en formato xpath
	 * @param typeValRet tipo de dato del valor a retornar string, number, node o dom
	 * @return  los tipos de valores retornados pueden ser string, number, node o dom
	 */
	public static Object getValueFromXML(XMLConfiguration config, String expXpath, String typeValRet) {
		Object propResult = null;

		Document document = config.getDocument();
		try {
			XPathFactory xFactory = XPathFactory.newInstance();
			XPath xpath = xFactory.newXPath();
			XPathExpression exp = null;

			exp = xpath.compile(expXpath);

			if (typeValRet.equalsIgnoreCase("STRING")) {
				propResult = exp.evaluate(document, XPathConstants.STRING);
			} else if (typeValRet.equalsIgnoreCase("NUMBER")) {
				propResult = exp.evaluate(document, XPathConstants.NUMBER);
			} else if (typeValRet.equalsIgnoreCase("NODE")) {
				propResult = exp.evaluate(document, XPathConstants.NODE);
			} else if (typeValRet.equalsIgnoreCase("DOM")) {
				propResult = exp.evaluate(document);
			}

		} catch (XPathExpressionException e) {
			document = null;
			throw new RuntimeException(e);
		} catch (Exception e) {
			document = null;
			throw new RuntimeException(e);
		}
		document = null;
		return propResult;
	}    
}
