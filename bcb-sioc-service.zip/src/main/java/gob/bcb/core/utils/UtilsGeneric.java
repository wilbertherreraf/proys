package gob.bcb.core.utils;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;

public final class UtilsGeneric {
	private static final String IP_REGEX = ".+@.+\\.[a-z]+";

	/**
	 * Generate a valid xs:ID string.
	 */

	public static String generateUUID() {
		return UUID.randomUUID().toString();
	}

	public static Object newInstance(String name) {
		try {
			Class<?> c = Class.forName(name);
			return c.newInstance();
		} catch (Exception e) {
			throw new RuntimeException("No se puede crear instancia de " + name, e);
		}
	}

	public static void validarEmail(String emailAddress) {
		if (StringUtils.isBlank(emailAddress)) {
			return;
		}
		Pattern mask = null;

		mask = Pattern.compile(IP_REGEX);
		Matcher matcher = mask.matcher(emailAddress);

		if (!matcher.matches()) {
			throw new RuntimeException("Direccion de correo invalido");
		}

	}
	
	public static String truncate(String string0, int maxLength, String suffix, boolean defaultTruncateAtWord) {
		if (StringUtils.isBlank(string0)){
			return null;
		}
		String string = StringUtils.trimToEmpty(string0);
		if (string.length() <= maxLength) {
			return string + suffix;
		}
		System.out.println("VALOR:[" + string);		
		if (suffix == null || maxLength - suffix.length() <= 0) {
			// either no need or no room for suffix
			//System.out.println("AAAAA " + string.substring(0, maxLength));
			return StringUtils.trimToEmpty(string.substring(0, maxLength));
		}
		
		if (defaultTruncateAtWord) {
			// find the latest space within maxLength
			String sc = string.substring(0, maxLength+1);
			int lastSpace = sc.lastIndexOf(" ");			
			//int lastSpace = string.substring(0, maxLength - suffix.length() + 1).lastIndexOf(" ");
			//System.out.println(lastSpace + "] {" +sc+ "} ");			
			if (lastSpace > 0) {
				//return StringUtils.trimToEmpty(string.substring(0, lastSpace)) +suffix;
				//System.out.println(lastSpace + "] {" +sc+ "} " + StringUtils.trimToEmpty(string.substring(0, lastSpace)));
				return StringUtils.trimToEmpty(string.substring(0, lastSpace)) +suffix;
			}
		}
		// truncate to exact character and append suffix
		//System.out.println("CCC " + StringUtils.trimToEmpty(string.substring(0, maxLength - suffix.length())) + suffix);		
		return StringUtils.trimToEmpty(string.substring(0, maxLength)) + suffix;

	}

	public static String truncate(String string0, int maxLength, String suffix, String tok, boolean defaultTruncateAtWord) {
		// System.out.println("::::" + string0);
		if (StringUtils.isBlank(string0)) {
			return null;
		}
		String string = StringUtils.trimToEmpty(string0);
		if (string.length() <= maxLength) {
			return string;
		}

		if (suffix == null || maxLength - suffix.length() <= 0) {
			// either no need or no room for suffix
			return StringUtils.trimToEmpty(string.substring(0, maxLength));
		}
		if (defaultTruncateAtWord) {
			// find the latest space within maxLength
			String s = string.substring(0, maxLength);
			String s1 = string.substring(0, maxLength - suffix.length());
			System.out.println(s + "[" + s.length() + "]" + " && " + s1 + "[" + s1.length() + "]");

			int lastSpace = s.lastIndexOf(suffix);
			if (lastSpace >= 0) {
				// System.out.println(":=" + string.substring(0, maxLength -
				// suffix.length() + 1) + " " + lastSpace);
				// return StringUtils.trimToEmpty(string.substring(0,
				// lastSpace+1));
				return StringUtils.trimToEmpty(string.substring(0, lastSpace + 1));
			}
		}
		// truncate to exact character and append suffix
		// System.out.println("uuuu:" + string.substring(0, maxLength -
		// suffix.length()));
		return StringUtils.trimToEmpty(string.substring(0, maxLength));

	}

	/**
	 * divide una cadena en lineas de tamaño fijo o menor al prefijo
	 * 
	 * @param string0
	 *            cadena a dividir
	 * @param maxLength
	 *            maximo de una linea
	 * @param suffix
	 *            token a buscar
	 * @param tok
	 * @param defaultTruncateAtWord
	 *            true si se trunca antes del sufijo false si es de tamaño fijo
	 * @return
	 */
	public static List<String> splitInLines(String string0, int maxLength, String suffix, String tok, boolean defaultTruncateAtWord) {
		String frase = "";
		List<String> result = new ArrayList<String>();
		do {
			string0 = StringUtils.trimToEmpty(string0);
			string0 = string0.substring(frase.length());
			frase = UtilsGeneric.truncate(string0, maxLength, suffix, tok, defaultTruncateAtWord);
			frase = StringUtils.trimToEmpty(frase);
			if (StringUtils.isNotBlank(frase)) {
				result.add(frase);
				// System.out.println(frase);
			}
		} while (StringUtils.isNotBlank(frase));
		return result;
	}

	public static String cell(Object obj, int cellsize, String suffix) {
		if (obj == null || cellsize <= 0) {
			return null;
		}

		String value = String.valueOf(obj);
		if (value.length() == cellsize) {
			return value;
		} else if (value.length() > cellsize) {
			return truncate(value, cellsize, suffix, " ", true);
		} else {
			return value + space(cellsize - value.length());
		}
	}

	public static String space(int length) {
		if (length < 0) {
			return null;
		}

		StringBuilder space = new StringBuilder();
		for (int i = 0; i < length; i++) {
			space.append(' ');
		}
		return space.toString();
	}

	public static String newStringFromBytes(byte[] bytes, String charsetName) {
		try {
			return new String(bytes, charsetName);
		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException("Impossible failure: Charset.forName(\"" + charsetName + "\") returns invalid name.");

		}
	}

	public static final Charset ISO_CHARSET = Charset.forName("UTF-8");

	public static String newStringFromString(String cadena) {
		if (cadena == null)
			return null;
		return newStringFromBytes(cadena.getBytes(), ISO_CHARSET.name());
	}

	public static Map<String, String> paramsLista(String text) {
		// byte[] valueDecoded= Base64.decode(bytesEncoded);
		Map<String, String> map = new LinkedHashMap<String, String>();
		if (text == null || text.trim().length() == 0) {
			return map;
		}
		String params = new String(text);

		for (String keyValue : params.split(" *& *")) {
			String[] pairs = keyValue.split(" *= *", 2);
			map.put(pairs[0], pairs.length == 1 ? "" : pairs[1]);
		}
		return map;
	}

	public static BigDecimal bigDecimalFromString(String valor) {
		if (StringUtils.isBlank(valor)) {
			return null;
		}
		DecimalFormatSymbols symbols = new DecimalFormatSymbols();
		symbols.setGroupingSeparator(',');
		symbols.setDecimalSeparator('.');
		String pattern = "#,##0.0#";
		DecimalFormat decimalFormat = new DecimalFormat(pattern, symbols);
		decimalFormat.setParseBigDecimal(true);

		// parse the string
		BigDecimal bigDecimal;
		try {
			bigDecimal = (BigDecimal) decimalFormat.parse(valor);
		} catch (ParseException e) {
			throw new RuntimeException("Error al convertir '" + valor + "' a BigDecimal" + e.getMessage());
		}
		return bigDecimal;
	}

	public static String formatearMonto(BigDecimal monto) {
		return formatearMonto(monto, true);
	}

	public static String formatearMonto(BigDecimal monto, boolean conSeparacion) {
		String montoLiteral0 = String.format("%.2f", monto);
		String pd = ".";
		String psm = ",";
		if (montoLiteral0.indexOf(",") > 0) {
			pd = ",";
			psm = ".";
		}
		String montoLiteral = "";
		if (conSeparacion) {
			montoLiteral = String.format("%,.2f", monto);
		} else {
			montoLiteral = String.format("%.2f", monto);
		}

		String mm = montoLiteral.replace(pd.charAt(0), '$');
		String mm0 = mm.replace(psm.charAt(0), '#');

		mm = mm0.replace('$', ',');
		mm0 = mm.replace('#', '.');

		String montoT = mm0;

		return montoT;

	}

	static public String cortarConcepto(String concepto) {
		String concCortado = "";
		Boolean cortado = false;
		int i = 34;
		int j;
		String texto = "";
		String ln = "\r\n";

		System.out.println("longitud cadena  = " + concepto.length());
		if (concepto.length() > 35) {
			texto = concepto;
			do {
				System.out.println("posicion i  : " + i);
				System.out.println("charAt(i) : " + concepto.charAt(i));
				if (concepto.charAt(i) == ' ' || concepto.charAt(i) == '.' || concepto.charAt(i) == ',') {
					texto = concepto.substring(0, i) + ln + concepto.substring(i + 1);
					cortado = true;
				}
				i--;
			} while (!cortado);

			concCortado = texto;
			j = texto.indexOf(ln);
			texto = concCortado.substring(j + ln.length());

			if (texto.length() > 35) {
				cortado = false;
				i = 34;
				do {
					if (texto.charAt(i) == ' ' || texto.charAt(i) == '.' || texto.charAt(i) == ',') {
						texto = texto.substring(0, i) + ln + texto.substring(i + 1);
						cortado = true;
					}
					i--;
				} while (!cortado);
				concCortado = concCortado.substring(0, j + ln.length()) + texto;

				j = texto.indexOf(ln);
				texto = texto.substring(j + ln.length());

				if (texto.length() > 35) {
					cortado = false;
					i = 34;
					do {
						if (texto.charAt(i) == ' ' || texto.charAt(i) == '.' || texto.charAt(i) == ',') {
							texto = texto.substring(0, i) + ln + texto.substring(i + 1);
							cortado = true;
						}
						i--;
					} while (!cortado);
					i = concCortado.indexOf(ln);
					j = concCortado.indexOf(ln, i + 1);
					concCortado = concCortado.substring(0, j + ln.length()) + texto;

					j = texto.indexOf(ln);
					texto = texto.substring(j + ln.length());

					if (texto.length() > 35) {
						concCortado = "-1";
					}
				}
			}
		} else {
			concCortado = concepto;
		}

		return concCortado;
	}

	public static Map<String, String> valoresVar(String cadenaVars) {
		Map<String, String> map = new HashMap<String, String>();
		if (StringUtils.isBlank(cadenaVars)) {
			return map;
		}
		StringTokenizer tok = new StringTokenizer(cadenaVars, "@", true);
		while (tok.hasMoreTokens()) {
			String entry = tok.nextToken();
			if (entry.length() == 1) {
				entry = tok.nextToken(" ").trim();
				map.put("@" + entry, "");
				try {
					tok.nextToken("@");
				} catch (Exception e) {
					// TODO: handle exception
				}
			}
		}
		return map;
	}

	public static List<String> parse(String regex, String string) {
		Pattern pat = Pattern.compile(regex, Pattern.MULTILINE);
		Matcher matcher = pat.matcher(string);
		List<String> result = new ArrayList<String>();
		if (matcher.matches()) {
			int groups = matcher.groupCount();
			for (int i = 1; i <= groups; i++) {
				result.add(matcher.group(i));
			}
		} else {
			System.err.println("Not matched");
		}
		return result;
	}

	public static void main(String[] args) {

		System.out.println("12345678".substring(0, 8));
		System.out.println("12345@AD@AD".lastIndexOf("@AD"));
		System.out.println("12345678".lastIndexOf("1"));
		System.out.println("1234567 9ABCG".lastIndexOf(" "));
		System.out.println("1234567 9ABCG".lastIndexOf(" "));
		System.out.println("12345678".substring(0, 8));

		String string0 = "12345";

		String s = UtilsGeneric.truncate(string0, 5, " ", null, true);
		System.out.println("·· " + s);
		
		string0 = " 12345 ABCDEF";

		s = UtilsGeneric.truncate(string0, 5, " ", null, true);
		System.out.println("·· " + s);

		System.out.println(StringUtils.trimToEmpty(""));
		System.out.println(StringUtils.trimToEmpty(null));
		System.out.println("{" + StringUtils.trimToEmpty(" asdf ") + "}");
		System.out.println("{" + StringUtils.trimToEmpty("asdf ") + "}");
		System.out.println("{" + StringUtils.trimToEmpty(" asdf") + "}");

		String regex1 = ":?([A-Z]*)/([A-Z]*)/([0-9]*)";
		regex1 = ":?([A-Z]*)/([A-Z]*)(/([0-9]{2,5})){1,3}";

		List<String> o = parse(regex1, ":ABCD//12356/12/78956");
		System.out.println(o);

		o = parse(regex1, ":ABCD//1231/4562/4566/4562/4566");
		System.out.println(o);

		o = parse(regex1, "ABCD//1231");
		System.out.println(o);

		o = parse(regex1, "://1231");
		System.out.println(o);

		String valor = "RETRIBUCIONALTITULAR REPOSICION DE, LA ENERGIA PAGADA Y NO, RETIRADA PERIODO ,SEPTIEMBRE 14 A ABRIL 2015.";
		List<String> sb = UtilsGeneric.splitInLines(valor, 35, " ", " ", true);
		for (String string : sb) {
			System.out.println(string);
		}

		// String cad = "Ã‘JSLKJJKSJFLÑIFADAD";
		// byte[] b = "Ã‘JSLKJJKSJFLÑIFADAD".getBytes("ISO-8859-1");
		// System.out.println(new String(b,"ISO-8859-1"));
		// System.out.println(new String(b,"UTF-8"));
		// String encoding = System.getProperty("file.encoding", "Cp1252");
		// System.out.println(encoding);
		// String a = newStringFromString(cad);
		// String at = newStringFromBytes(cad.getBytes(),"UTF-8");
		// String aa = newStringFromString(a);
		// System.out.println(newStringFromBytes(cad.getBytes(),"UTF-8"));
		// System.out.println(newStringFromBytes(cad.getBytes(),"ISO-8859-1"));
		// System.out.println(newStringFromBytes(cad.getBytes(),"Cp1252"));
		//
		// System.out.println(bigDecimalFromString("0.20"));
		// System.out.println(bigDecimalFromString("111110.20"));
		// System.out.println(bigDecimalFromString("8,000"));
		// System.out.println(bigDecimalFromString(".20"));
		// System.out.println(bigDecimalFromString(""));
		//
	}

}
