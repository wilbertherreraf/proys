package gob.bcb.core.persist;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate3.HibernateTransactionManager;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.transaction.TransactionStatus;

public class EntityUserTransactionBolsin {
	private static final Log log = LogFactory.getLog(EntityUserTransactionBolsin.class);
	private static SessionFactory sessionFactory;
	private static String nameSessionFactory;
	private static final ThreadLocal threadSession = new ThreadLocal();
	private static final ThreadLocal threadTransaction = new ThreadLocal();
	private static final ThreadLocal threadTransactionStatus = new ThreadLocal();

	public static boolean isActive() {
		TransactionStatus trxStatus = getTransactionStatus();
		return trxStatus != null && !trxStatus.isCompleted();
	}

	public static void flush() {
		TransactionStatus trxStatus = getTransactionStatus();
		try {
			if (isActive()) {
				log.info("Starting flushing transaction in this thread. " + nameSessionFactory);
				trxStatus.flush();
			}
		} catch (Exception e) {
			log.error("Error al realizar " + nameSessionFactory + " flush " + e.getMessage(), e);
			throw new RuntimeException(e);
		}
	}

	/**
	 * retorna la session activa si no se desea que se cree el parametro es
	 * false, true se creara una nueva session
	 *
	 * @param crearSession
	 * @return
	 */
	public static Session getSession(boolean crearSession) {
		Session session = (Session) threadSession.get();
		try {
			if (session == null) {
				session = SessionFactoryUtils.getSession(getSessionFactory(), crearSession);
				threadSession.set(session);
			}
		} catch (HibernateException ex) {
			throw new RuntimeException(ex);
		}
		return session;
	}

	/**
	 * recupera el session factory del objeto
	 *
	 * @return
	 */

	public static TransactionStatus getTransactionStatus() {
		TransactionStatus txStatus = (TransactionStatus) threadTransactionStatus.get();
		return txStatus; // transactionStatus;
	}

	/**
	 * Start a new database transaction.
	 */
	public static void begin() throws RuntimeException {
		HibernateTransactionManager hibernateTransactionManager = (HibernateTransactionManager) threadTransaction.get();
		try {
			if (hibernateTransactionManager == null) {
				log.info("Inicio de una nueva transaccion: " + nameSessionFactory);
				if (getSessionFactory() == null) {
					throw new RuntimeException("No se inicializo la variable sessionFactory " + nameSessionFactory);
				}

				hibernateTransactionManager = new HibernateTransactionManager(getSessionFactory());
				threadTransaction.set(hibernateTransactionManager);
			}
			// por simple control nos aseguramos que en el hilo no exista la tx
			TransactionStatus txStatus = (TransactionStatus) threadTransactionStatus.get();
			if (txStatus == null) {
				log.info("Iniciando threadTransactionStatus para la session " + nameSessionFactory);
				txStatus = hibernateTransactionManager.getTransaction(null);
				threadTransactionStatus.set(txStatus);
			} else {
				log.warn("Error de sistemas incosistencia: existe el objeto TransactionStatus sin hibernateTransactionManager " + nameSessionFactory);
				//throw new RuntimeException("Error de sistemas inconsistencia: existe el objeto TransactionStatus sin hibernateTransactionManager");
			}

		} catch (HibernateException e) {
			log.error("Error al realizar  " + nameSessionFactory + " beginTransaction " + e.getMessage(), e);
			throw new RuntimeException(e);
		} catch (Exception e) {
			log.error("Exception Error al realizar  " + nameSessionFactory + " beginTransaction " + e.getMessage(), e);
			throw new RuntimeException(e);
		}

	}

	/**
	 * Commit the database transaction.
	 */
	public static void commit() throws RuntimeException {
		log.info("llamada al proceso de commit." + nameSessionFactory);
		HibernateTransactionManager hibernateTransactionManager = (HibernateTransactionManager) threadTransaction.get();
		TransactionStatus txStatus = (TransactionStatus) threadTransactionStatus.get();
		try {
			if (hibernateTransactionManager != null && txStatus != null && !txStatus.isCompleted() && !txStatus.isRollbackOnly()) {
				// existe transaccion activa
				log.info("Antes del commit en: " + nameSessionFactory);
				hibernateTransactionManager.commit(txStatus);
				log.info("Commit hecho: " + nameSessionFactory);
			} else {
				log.warn("Intento de commit sin condiciones habiles para la operacion");
			}
			threadTransaction.set(null);
			threadTransactionStatus.set(null);
		} catch (HibernateException e) {
			log.error("Error al realizar " + nameSessionFactory + " commitTransaction(se realizara rollback) " + e.getMessage(), e);
			rollbackTransaction();
			throw new RuntimeException(e);
		} catch (Exception e) {
			log.error("Exception Error al realizar " + nameSessionFactory + " commitTransaction(se realizara rollback) " + e.getMessage(), e);
			rollbackTransaction();
			throw new RuntimeException(e);
		} finally {
			hibernateTransactionManager = null;
			txStatus = null;
		}
	}

	public static void closeTransaction() throws RuntimeException {
		try {
			HibernateTransactionManager tx = (HibernateTransactionManager) threadTransaction.get();
			threadTransaction.set(null);
			threadTransactionStatus.set(null);
			//log.info("Transacciones cerradas: " + nameSessionFactory);
		} catch (HibernateException e) {
			log.error("Error al realizar closeTransaction " + e.getMessage(), e);
			throw new RuntimeException(e);
		}
	}

	/**
	 * Closes the Session local to the thread.
	 */
	public static void closeSession(){
		//log.info("Cerrando session para el hilo: " + nameSessionFactory);
		Session session = (Session) threadSession.get();
		SessionFactoryUtils.closeSession(session);
	}

	/**
	 * Commit the database transaction.
	 */
	public static void rollbackTransaction() throws RuntimeException {
		//log.info("llamada al proceso de rollback: " + nameSessionFactory);
		HibernateTransactionManager hibernateTransactionManager = (HibernateTransactionManager) threadTransaction.get();
		TransactionStatus txStatus = (TransactionStatus) threadTransactionStatus.get();
		try {
			threadTransaction.set(null);
			threadTransactionStatus.set(null);

			if (hibernateTransactionManager != null && txStatus != null && !txStatus.isCompleted()) {
				log.info("Inicio de revertir datos en BDD: " + nameSessionFactory);
				hibernateTransactionManager.rollback(txStatus);
				log.info("Datos revertidos en BDD: " + nameSessionFactory);
			}
		} catch (HibernateException e) {
			log.error("Error al realizar " + nameSessionFactory + " rollbackTransaction " + e.getMessage(), e);
			throw new RuntimeException(e);
		} catch (Exception e) {
			log.error("Exception Error al realizar " + nameSessionFactory + " rollbackTransaction " + e.getMessage(), e);
			throw new RuntimeException(e);
		} finally {
			closeTransaction();			
			closeSession();
		}
	}
	public static void setNameSessionFactory(String nameSFactory) {
		nameSessionFactory = nameSFactory;
	}

	public static String getNameSessionFactory() {
		return nameSessionFactory;
	}

	public static void setSessionFactory(SessionFactory sFactory) {
		sessionFactory = sFactory;
	}

	public static SessionFactory getSessionFactory() {
		return sessionFactory;
	}
}
