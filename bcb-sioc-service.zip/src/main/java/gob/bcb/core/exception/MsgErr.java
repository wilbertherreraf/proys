/*
 * MsgErr.java
 *
 * Created on 21 de agosto de 2006, 09:30 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package gob.bcb.core.exception;

/**
 *
 * @author WHerrera
 */
/**
 * Clase que administra los codigos de error de las diferentes operaciones
 */
public final class MsgErr {

    /** Describe los codigos de error para Errores en el tratamiento, generacion o parseo de cadenas XML, sufijo 'X'
     **/
    public final static String msgErrors[] = {
    "0000 - La solicitud [TIPO OPERACION]:[DESCRIPCION OPERACION] , fue procesada satisfactoriamente",
    "X001 - Error al decodificar el mensaje XML recibido",
    "X002 - Documento XML mal generado",
    "X003 - Error en la lectura del documento XML",
    "X007 - Documento XML no valido:[MENSAJE EXCEPCION] ",
    "X008 - Error de parseo, la longitud  de la cadena XML es cero",
    "X009 - Error de Parseo del mensaje XML: No existe el TAG [NOMBRE TAG]",
    "X010 - Error al generar el documento XML de respuesta",
    "X011 - Excepcion indefinida al obtener el nombre del tipo de operacion",
    "X012 - Error en el mensaje XML de excepcion indefinida:[MENSAJE EXCEPCION]",
    "X013 - Formato de fecha no reconocido para:[NOMBRE TAG]" ,
    "X020 - No existe la firma digital del Banco Corresponsal",
    "X021 - No existe la firma digital del TGN",
    "X022 - La cuenta corriente existente en la seccion del Bco Corresponsal [CODIGO TGN A BCO CORRESPONSAL]  no tiene su respectiva cuenta en el mensaje del TGN",
    "X023 - Error de Excepcion indefinida al validar mensaje XML con documento XSD",
    "X024 - Error al extraer valor del TAG: [NOMBRE TAG]",
    "X025 - El documento XML esta codificado en UTF-8 pero contiene caracteres no permitidos(Ej. caracteres con acentos)",
    "X026 - Error en la formacion del documento XML no existe el tag [TAG A VALIDAR]",

    /** Describe los codigos de error para Errores en el tratamiento de la Firma Digital, sufijo 'F'
     **/
    "F001 - Error indeterminado en el Almacen de Claves",
    "F002 - Error en el algoritmo de seguridad en el Almacen de Claves",
    "F003 - El Certificado del BCB ha expirado o aun no es valido.",
    "F004 - Almacen de Claves no encontrado en la ruta y nombre especificados",
    "F005 - Falla o interrupcion en la operacin de entrado o salida manipulando el Archivo del Almacen de claves",
    "F006 - Error en la recuperacion de la Clave Privada",
    "F007 - Error presentado al extraer los datos del certificado del BCB del Almacen.",
    "F008 - Error en la configuracion del parser de XML",
    "F009 - Error en la manipulacion de los elementos de Firma Digital",

    /** Describe los codigos de error para la Revocacion de Certificados Digitales, sufijo 'R'
     **/
    "R003 - No existe Certificado Digital Valido para el keyname [ALIAS]",

    /** Describe los codigos de error para la Verificacion digital, sufijo 'VS'
     **/
    "VS02 - Firma digital no corresponde al participante originante.",
    "VS03 - Firma Digital no valida",

    /** Describe los codigos de error para la Verificacion de Firma, sufijo 'V'
     **/
    "V005 - Falla o interrupcion en la operacion de entrado o salida manipulando el Archivo del Almacen de claves",
    "V006 - No existe el TAG ds:KeyName o esta vacio",
    "V007 - Error en la manipulacion del archivo de Firma digital, No existen los TAG's de firma determinados",
    "V008 - Error de Excepcion desconocido en el tratamiento de certificado digital: [MENSAJE EXCEPCION]",
    "V009 - Error de Seguridad indeterminado en la verificacion de Firma Digital",
    "V010 - Certificado digital ha expirado.",
    "V011 - El Certificado utilizado todavia no es valido",
    "V012 - Certificado digital revocado.",
    "V013 - Existe un error en el Certificado Almacenado.",
    "V014 - No existe Certificado Digital Valido para procesar esta operacion.",
    "V015 - No se encuentra habilitado el KEYNAME [KEYNAME] para el tipo de operacion:[TIPO OPERACION]",

    /** Describe los codigos de error para el tratamiento de errores Internos de programa, sufijo 'I'
     **/
    "I001 - Error de configuracion para el manejo del archivo XML",
    "I002 - Error al parsear el archivo o No es una archivo XML bien formado",
    "I003 - Excepcion indefinida en el momento del manejo del archivo de parametros",
    "I004 - Error de entrada y salida en la lectura del archivo de parametros",
    "I005 - No existe el un valor para el TAG [TAG] especificado, en el archivo de parametros",
    "I006 - Error INTERNO desconocido:[MENSAJE EXCEPCION]",
    "I007 - Error interno en la configuracion del parser de datos de ingreso",
    "I008 - Error interno al momento de cargar los Datos de Ingreso",
    "I009 - Excepcion indefinida en el momento de parsear Datos de Entrada",
    "I010 - Error de entrada y salida en la lectura del archivo de parametros",
    "I011 - Error Interno al procesar el envio del mensaje de respuesta",
    "I012 - Error de E/S al registrar el mensaje recibido",
    "I013 - Error interno el proceso de obtener el certificado digital",
    "I014 - Error Interno al leer el contenido del documento: El archivo  no pudo ser hubicado.",
    "I015 - Error Interno Desconocido al leer el contenido del archivo.",
    "I017 - Error indefinido presentado al momento de la verificacion de Firma Digital"};

    /**
     * Metodo que permite buscar un valor dentro el array de errores
     * @parm value Cadena a buscar
     * @return Numero de indice encontrado
     **/
    public static int searchValue(String value){
		int in_list = -1;
                String idErr = "";
		for(int i = 0; i < msgErrors.length; i++){
                        idErr = msgErrors[i].substring(0, 4).toUpperCase();
			if (value.toUpperCase().equals(idErr)) {
				in_list = i;
				break;
			}
		}
		return in_list;
    }
    /**
     * Metodo que permite buscar un valor dentro el array de errores
     * @parm codErr Codigo de error a buscar
     * @return Cadena encontrada
     **/
    public static String getMsg(String codErr){
		String resp = "";
                int i = searchValue(codErr);
                if (i > -1 )
                        resp = msgErrors[i];
		return resp.toUpperCase();
    }
    public static String searchAndReplace(String strToSearch, String strToInsert, int pos) {
        String newStr = "";
        String strAux = "";
        strAux = strToSearch;
        int indice1 = -1, indice2 = -1;

        for(int posi = 1; posi <= pos; posi ++){
            indice1 = strAux.indexOf("[");
            if (indice1 == -1)
                break;
            String subcad2 = strAux.substring(indice1);
            indice2 = subcad2.indexOf("]");
            String subcad3 = subcad2.substring(0, indice2 + 1);
            if (posi == pos){
                newStr = newStr + strAux.substring(0, indice1) + strToInsert + subcad2.substring(indice2 + 1);
                break;
            }else{
                newStr = newStr + strAux.substring(0, indice1) + subcad3;
                strAux = subcad2.substring(indice2 + 1);
            }
        }
        return ((newStr.length()==0)?strToSearch : newStr);
    }
    /**
     * Metodo que reemplaza los campos del error por los parametros enviados al metodo
     * @parm codErr Codigo de error a buscar
     * @return Cadena encontrada
     **/
    public static String getMessage(String codErr){
        String strErr = "";
        int i = searchValue(codErr);
        if (i > -1 )
            strErr = msgErrors[i];
        return strErr;
    }
    public static String getMessage(String codErr, String param1){
        String strErr = "";
        int i = searchValue(codErr);
        if (i > -1 )
            strErr = searchAndReplace(msgErrors[i], param1, 1);
        return strErr;
    }
   public static String getMessage(String codErr, String param1, String param2){
        String strErr = "";
        int i = searchValue(codErr);
        if (i > -1 ){
            strErr = searchAndReplace(msgErrors[i], param1, 1);
            strErr = searchAndReplace(strErr, param2, 1);
        }
        return strErr;
    }
   public static String getMessage(String codErr, String param1, String param2, String param3) {
        String strErr = "";
        int i = searchValue(codErr);
        if (i > -1 ){
            strErr = searchAndReplace(msgErrors[i], param1, 1);
            strErr = searchAndReplace(strErr, param2, 1);
            strErr = searchAndReplace(strErr, param3, 1);
        }
        return strErr;
    }
   public static String getMessage(String codErr, String param1, String param2, String param3, String param4) {
        String strErr = "";
        int i = searchValue(codErr);
        if (i > -1 ){
            strErr = searchAndReplace(msgErrors[i], param1, 1);
            strErr = searchAndReplace(strErr, param2, 1);
            strErr = searchAndReplace(strErr, param3, 1);
            strErr = searchAndReplace(strErr, param4, 1);
        }
        return strErr;
    }
}
