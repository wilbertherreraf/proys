/**
 * WebServClientException.java
 *
 * Creado el 27 de mayo de 2003, 02:48 PM
 */
package gob.bcb.core.exception;

import org.apache.log4j.Logger;

/**
 * Excepcion de tipo FIRMA
 */
public class WebServClientException extends UncheckedException {

    /**
     * Crear una nueva instancia de <code>WebServClientException</code> sin mensaje.
     */
    public WebServClientException() {
    }
    /**
     * Construir una instancia de <code>WebServClientException</code> especifiacndo el mensaje.
     * @param msg el mensaje.
     */
    public WebServClientException(String msg) {
        super(msg);
    }
    public WebServClientException(String msg, Throwable t) {
		super(msg, t);
	}
    public WebServClientException(Throwable t) {
		super(t);
	}    
}
