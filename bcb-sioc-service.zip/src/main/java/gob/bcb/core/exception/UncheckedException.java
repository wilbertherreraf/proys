package gob.bcb.core.exception;

import java.util.ResourceBundle;
import org.apache.log4j.Logger;

public class UncheckedException extends java.lang.RuntimeException {

	private static final long serialVersionUID = 1L;

	private final MsgManager message;
	
	public UncheckedException() {
		message = null;
	}
	public UncheckedException(String msg) {
		super(msg);
		message = new MsgManager(msg);
	}
	public UncheckedException(String msg, Throwable t) {
		super(msg,t);
		message = new MsgManager(msg);
	}	
	public UncheckedException(MsgManager msg) {
		super(msg.toString());
		message = msg;
	}

	public UncheckedException(MsgManager msg, Throwable t) {
		super(t);
		message = msg;
	}

	public UncheckedException(Throwable cause) {
		super(cause);
		message = null;
	}

	public UncheckedException(Logger log, String msg, Object... params) {
		message = new MsgManager(msg, log, params);
	}

	public UncheckedException(ResourceBundle bundle, String msg, Object... params) {
		message = new MsgManager(msg, bundle, params);
	}

	public UncheckedException(Logger log, String msg, Throwable t, Object... params) {
		super(t);		
		message = new MsgManager(msg, log, params);
	}

	public UncheckedException(ResourceBundle bundle, String msg, Throwable t, Object... params) {
		super(t);
		message = new MsgManager(msg, bundle, params);
	}

	public String getCode() {
		if (null != message) {
			return message.getCode();
		}
		return null;
	}

    public String getMessage() {
        if (null != message) {
            return message.toString();
        } else {
        	return super.getMessage();
        }
    }
}