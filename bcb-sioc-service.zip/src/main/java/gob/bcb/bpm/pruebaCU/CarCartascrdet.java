package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name="car_cartascrdet")
public class CarCartascrdet  implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private CarCartascrdetPK id;
	
	@Column(name = "ccd_tipomov")
	private String ccdTipomov;
	@Column(name = "ccd_tipoemision")
	private String ccdTipoemision;
	@Column(name = "ccd_soccodigo")
	private String ccdSoccodigo;
	@Column(name = "ccd_detcodigo")
	private Integer ccdDetcodigo;
	@Column(name = "ccd_codbcoreceptor")
	private String ccdCodbcoreceptor;
	@Column(name = "ccd_codbcornocta")
	private String ccdCodbcornocta;	
	@Column(name = "ccd_estmovccred")
	private String ccdEstmovccred;
	@Temporal(TemporalType.DATE)
	@Column(name = "ccd_fechacont")
	private Date ccdFechacont;	
	@Temporal(TemporalType.DATE)
	@Column(name = "ccd_fechareg")
	private Date ccdFechareg;
	@Temporal(TemporalType.DATE)
	@Column(name = "ccd_fechacargo")
	private Date ccdFechacargo;
	@Column(name = "ccd_monto")
	private BigDecimal ccdMonto;
	@Column(name = "ccd_codmonmonto")
	private Integer ccdCodmonmonto;
	@Column(name = "ccd_montotrans")
	private BigDecimal ccdMontotrans;
	@Column(name = "ccd_codmontrans")
	private Integer ccdCodmontrans;
	@Column(name = "ccd_glosa")
	private String ccdGlosa;
	@Column(name = "ccd_nrodias")
	private Integer ccdNrodias;	
	@Column(name = "ccd_nit")
	private String ccdNit;
	@Column(name = "ccd_rengconcilia")
	private String ccdRengconcilia;
	@Column(name = "ccd_esqcodigo")
	private Integer ccdEsqcodigo;	
	@Column(name = "ccd_estregistro")
	private String ccdEstregistro;	
	@Column(name = "ccd_auditusr")
	private String ccdAuditusr;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ccd_auditfho")
	private Date ccdAuditfho;
	@Column(name = "ccd_auditwst")
	private String ccdAuditwst;
	
	public CarCartascrdet() {

	}

	public CarCartascrdetPK getId() {
		return id;
	}

	public void setId(CarCartascrdetPK id) {
		this.id = id;
	}

	public String getCcdTipomov() {
		return ccdTipomov;
	}

	public void setCcdTipomov(String ccdTipomov) {
		this.ccdTipomov = ccdTipomov;
	}

	public String getCcdSoccodigo() {
		return ccdSoccodigo;
	}

	public void setCcdSoccodigo(String ccdSoccodigo) {
		this.ccdSoccodigo = ccdSoccodigo;
	}

	public Integer getCcdDetcodigo() {
		return ccdDetcodigo;
	}

	public void setCcdDetcodigo(Integer ccdDetcodigo) {
		this.ccdDetcodigo = ccdDetcodigo;
	}

	public String getCcdCodbcoreceptor() {
		return ccdCodbcoreceptor;
	}

	public void setCcdCodbcoreceptor(String ccdCodbcoreceptor) {
		this.ccdCodbcoreceptor = ccdCodbcoreceptor;
	}

	public String getCcdEstmovccred() {
		return ccdEstmovccred;
	}

	public void setCcdEstmovccred(String ccdEstmovccred) {
		this.ccdEstmovccred = ccdEstmovccred;
	}

	public Date getCcdFechareg() {
		return ccdFechareg;
	}

	public void setCcdFechareg(Date ccdFechareg) {
		this.ccdFechareg = ccdFechareg;
	}

	public Date getCcdFechacargo() {
		return ccdFechacargo;
	}

	public void setCcdFechacargo(Date ccdFechacargo) {
		this.ccdFechacargo = ccdFechacargo;
	}

	public BigDecimal getCcdMonto() {
		return ccdMonto;
	}

	public void setCcdMonto(BigDecimal ccdMonto) {
		this.ccdMonto = ccdMonto;
	}

	public Integer getCcdCodmonmonto() {
		return ccdCodmonmonto;
	}

	public void setCcdCodmonmonto(Integer ccdCodmonmonto) {
		this.ccdCodmonmonto = ccdCodmonmonto;
	}

	public BigDecimal getCcdMontotrans() {
		return ccdMontotrans;
	}

	public void setCcdMontotrans(BigDecimal ccdMontotrans) {
		this.ccdMontotrans = ccdMontotrans;
	}

	public Integer getCcdCodmontrans() {
		return ccdCodmontrans;
	}

	public void setCcdCodmontrans(Integer ccdCodmontrans) {
		this.ccdCodmontrans = ccdCodmontrans;
	}

	public String getCcdGlosa() {
		return ccdGlosa;
	}

	public void setCcdGlosa(String ccdGlosa) {
		this.ccdGlosa = ccdGlosa;
	}

	public String getCcdNit() {
		return ccdNit;
	}

	public void setCcdNit(String ccdNit) {
		this.ccdNit = ccdNit;
	}

	public String getCcdAuditusr() {
		return ccdAuditusr;
	}

	public void setCcdAuditusr(String ccdAuditusr) {
		this.ccdAuditusr = ccdAuditusr;
	}

	public Date getCcdAuditfho() {
		return ccdAuditfho;
	}

	public void setCcdAuditfho(Date ccdAuditfho) {
		this.ccdAuditfho = ccdAuditfho;
	}

	public String getCcdAuditwst() {
		return ccdAuditwst;
	}

	public void setCcdAuditwst(String ccdAuditwst) {
		this.ccdAuditwst = ccdAuditwst;
	}

	public String getCcdRengconcilia() {
		return ccdRengconcilia;
	}

	public void setCcdRengconcilia(String ccdRengconcilia) {
		this.ccdRengconcilia = ccdRengconcilia;
	}

	public Integer getCcdEsqcodigo() {
		return ccdEsqcodigo;
	}

	public void setCcdEsqcodigo(Integer ccdEsqcodigo) {
		this.ccdEsqcodigo = ccdEsqcodigo;
	}

	public String getCcdTipoemision() {
		return ccdTipoemision;
	}

	public void setCcdTipoemision(String ccdTipoemision) {
		this.ccdTipoemision = ccdTipoemision;
	}

	public Date getCcdFechacont() {
		return ccdFechacont;
	}

	public void setCcdFechacont(Date ccdFechacont) {
		this.ccdFechacont = ccdFechacont;
	}

	public String getCcdEstregistro() {
		return ccdEstregistro;
	}

	public void setCcdEstregistro(String ccdEstregistro) {
		this.ccdEstregistro = ccdEstregistro;
	}

	public Integer getCcdNrodias() {
		return ccdNrodias;
	}

	public void setCcdNrodias(Integer ccdNrodias) {
		this.ccdNrodias = ccdNrodias;
	}

	public String getCcdCodbcornocta() {
		return ccdCodbcornocta;
	}

	public void setCcdCodbcornocta(String ccdCodbcornocta) {
		this.ccdCodbcornocta = ccdCodbcornocta;
	}
	
	
}
