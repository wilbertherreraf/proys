package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;

import java.math.BigDecimal;

/**
 * The persistent class for the soc_rengscomp database table.
 * 
 */
@Entity
@Table(name = "soc_rengscomp")
public class SocRengscomp implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SocRengscompId id;

	@Column(name = "cla_debehaber")
	private Character claDebehaber;

	private Integer moneda;

	@Column(name = "ren_afectable")
	private String renAfectable;

	@Column(name = "ren_glosa")
	private String renGlosa;

	@Column(name = "cta_movimiento")
	private String ctaMovimiento;

	@Column(name = "ren_mayor")
	private String renMayor;

	@Column(name = "ren_montomn")
	private BigDecimal renMontomn;

	@Column(name = "ren_montomo")
	private BigDecimal renMontomo;

	@Column(name = "ren_tipocambio")
	private BigDecimal renTipocambio;

	@Column(name = "det_codigo")
	private Integer detCodigo;

	@Column(name = "cve_esttransflip")
	private String cveEsttransflip;

	@Column(name = "tipo_transfer")
	private String tipoTransfer;

	@Column(name = "sol_coddestorig")
	private String solCoddestorig;

	@Column(name = "cta_destorig")
	private String ctaDestorig;

	@Column(name = "nro_solicitudlip")
	private String nroSolicitudlip;

	@Column(name = "nom_datoadic")
	private String nomDatoadic;

	public SocRengscomp() {
	}

	public SocRengscomp(SocRengscompId id) {
		this.id = id;
	}

	public SocRengscomp(SocRengscompId id, Integer moneda, Character claDebehaber, BigDecimal renTipocambio, BigDecimal renMontomo,
			BigDecimal renMontomn, String renMayor, String renAfectable, String renGlosa) {
		this.id = id;
		this.moneda = moneda;
		this.claDebehaber = claDebehaber;
		this.renTipocambio = renTipocambio;
		this.renMontomo = renMontomo;
		this.renMontomn = renMontomn;
		this.renMayor = renMayor;
		this.renAfectable = renAfectable;
		this.renGlosa = renGlosa;
	}

	public SocRengscomp(SocRengscompId id, Integer moneda, Character claDebehaber, BigDecimal renTipocambio, BigDecimal renMontomo,
			BigDecimal renMontomn, String renMayor, String renAfectable) {
		this.id = id;
		this.moneda = moneda;
		this.claDebehaber = claDebehaber;
		this.renTipocambio = renTipocambio;
		this.renMontomo = renMontomo;
		this.renMontomn = renMontomn;
		this.renMayor = renMayor;
		this.renAfectable = renAfectable;
	}

	public SocRengscompId getId() {
		return this.id;
	}

	public void setId(SocRengscompId id) {
		this.id = id;
	}

	public Character getClaDebehaber() {
		return this.claDebehaber;
	}

	public void setClaDebehaber(Character claDebehaber) {
		this.claDebehaber = claDebehaber;
	}

	public Integer getMoneda() {
		return this.moneda;
	}

	public void setMoneda(Integer moneda) {
		this.moneda = moneda;
	}

	public String getRenAfectable() {
		return this.renAfectable;
	}

	public void setRenAfectable(String renAfectable) {
		this.renAfectable = renAfectable;
	}

	public String getRenGlosa() {
		return this.renGlosa;
	}

	public void setRenGlosa(String renGlosa) {
		this.renGlosa = renGlosa;
	}

	public String getRenMayor() {
		return this.renMayor;
	}

	public void setRenMayor(String renMayor) {
		this.renMayor = renMayor;
	}

	public BigDecimal getRenMontomn() {
		return this.renMontomn;
	}

	public void setRenMontomn(BigDecimal renMontomn) {
		this.renMontomn = renMontomn;
	}

	public BigDecimal getRenMontomo() {
		return this.renMontomo;
	}

	public void setRenMontomo(BigDecimal renMontomo) {
		this.renMontomo = renMontomo;
	}

	public BigDecimal getRenTipocambio() {
		return this.renTipocambio;
	}

	public void setRenTipocambio(BigDecimal renTipocambio) {
		this.renTipocambio = renTipocambio;
	}

	public Integer getDetCodigo() {
		return detCodigo;
	}

	public void setDetCodigo(Integer detCodigo) {
		this.detCodigo = detCodigo;
	}

	public String getCtaMovimiento() {
		return ctaMovimiento;
	}

	public void setCtaMovimiento(String ctaMovimiento) {
		this.ctaMovimiento = ctaMovimiento;
	}

	public String getCveEsttransflip() {
		return cveEsttransflip;
	}

	public void setCveEsttransflip(String cveEsttransflip) {
		this.cveEsttransflip = cveEsttransflip;
	}

	public String getTipoTransfer() {
		return tipoTransfer;
	}

	public void setTipoTransfer(String tipoTransfer) {
		this.tipoTransfer = tipoTransfer;
	}

	public String getCtaDestorig() {
		return ctaDestorig;
	}

	public void setCtaDestorig(String ctaDestorig) {
		this.ctaDestorig = ctaDestorig;
	}

	public String getNroSolicitudlip() {
		return nroSolicitudlip;
	}

	public void setNroSolicitudlip(String nroSolicitudlip) {
		this.nroSolicitudlip = nroSolicitudlip;
	}

	public String getSolCoddestorig() {
		return solCoddestorig;
	}

	public void setSolCoddestorig(String solCoddestorig) {
		this.solCoddestorig = solCoddestorig;
	}

	public String toString() {
		return "SocRengscomp [id=" + id + ", claDebehaber=" + claDebehaber + ", moneda=" + moneda + ", renAfectable=" + renAfectable + ", renGlosa="
				+ renGlosa + ", ctaMovimiento=" + ctaMovimiento + ", renMayor=" + renMayor + ", renMontomn=" + renMontomn + ", renMontomo="
				+ renMontomo + ", renTipocambio=" + renTipocambio + ", detCodigo=" + detCodigo + ", cveEsttransflip=" + cveEsttransflip
				+ ", tipoTransfer=" + tipoTransfer + ", solCoddestorig=" + solCoddestorig + ", ctaDestorig=" + ctaDestorig + ", nroSolicitudlip="
				+ nroSolicitudlip + "]";
	}

	public String getNomDatoadic() {
		return nomDatoadic;
	}

	public void setNomDatoadic(String nomDatoadic) {
		this.nomDatoadic = nomDatoadic;
	}

}
