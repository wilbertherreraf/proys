/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-bpm-pruebaCU
 * gob.bcb.bpm.pruebaCU
 * 21/09/2011 - 10:21:05
 * Creado por Cecilia Uriona
 */
package gob.bcb.bpm.pruebaCU;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Map;

/**
 * Clase que contiene los metodos para crear los campos de un mensaje swift.
 * 
 * @author C. Cecilia Uriona
 * 
 */
public class GlosaRenglon {
	private static final Log log = LogFactory.getLog(GlosaRenglon.class);

	public static String crearGlosa(String tipo, SocDetallessol det) {
		log.info("XXX: Creando glosa: tipo: " + tipo + "; " + det);
		String glosa = "";

			String query = " select val_nombre" + " from soc_valorescla " + " where cla_codigo = 'cla_glosa_r' " + " and val_codigo = '" + tipo + "'";

			List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "val_nombre".split(","));
			if (resultado.size() == 1) {
				for (Map<String, Object> res : resultado) {
					// log.info("resultado" + res.toString());
					String definicion = (String) res.get("val_nombre");
					glosa = getVars(definicion, det);
				}
			} 
		return glosa;
	}

	public static String crearGlosa(String tipo, SocDetallesope det) {
		String glosa = "";

			String query = " select val_nombre" + " from soc_valorescla " + " where cla_codigo = 'cla_glosa_r' " + " and val_codigo = '" + tipo + "'";

			List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "val_nombre".split(","));
			if (resultado.size() == 1) {
				for (Map<String, Object> res : resultado) {
					// log.info("resultado" + res.toString());
					String definicion = (String) res.get("val_nombre");
					glosa = getVars(definicion, det);
				}
			} 


		return glosa;
	}

	private static String getVars(String definicion, SocDetallessol det) {
		String var = "";
		String valor = "";
		int longitud = 0;

		int j = definicion.indexOf("@");
		if (j >= 0) {
			longitud = definicion.indexOf(" ", j);
			if (longitud > 0) {
				var = definicion.substring(j, longitud);
				valor = definicion.substring(0, j) + reemplazarVar(var, det) + getVars(definicion.substring(longitud), det);
			} else {
				var = definicion.substring(j);
				valor = definicion.substring(0, j) + reemplazarVar(var, det);
			}
		} else {
			valor = definicion;
		}

		return valor;
	}

	private static String getVars(String definicion, SocDetallesope det) {
		String var = "";
		String valor = "";
		int longitud = 0;

		int j = definicion.indexOf("@");
		if (j >= 0) {
			longitud = definicion.indexOf(" ", j);
			if (longitud > 0) {
				var = definicion.substring(j, longitud);
				valor = definicion.substring(0, j) + reemplazarVar(var, det) + getVars(definicion.substring(longitud), det);
			} else {
				var = definicion.substring(j);
				valor = definicion.substring(0, j) + reemplazarVar(var, det);
			}
		} else {
			valor = definicion;
		}

		return valor;
	}

	private static String reemplazarVar(String var, SocDetallesope det) {
		String valor = "";

		if (var.equals("@ctaexp")) {
			valor = getExportador(det.getBenCodigo(), det.getDetCtabenef());
		}

		if (var.equals("@ctaexpc")) {
			valor = getExportadorC(det.getBenCodigo(), det.getDetCtabenef());
		}

		if (var.equals("@ctacon")) {
			valor = getConciliable(det.getId().getOpeCodigo());
		}

		if (var.equals("@ctacomi")) {
			valor = getCuentaComi(det.getId().getOpeCodigo());
		}

		if (var.equals("@ctaope")) {
			valor = getCuentaOpe(det.getId().getOpeCodigo());
		}

		return valor;
	}

	private static String reemplazarVar(String var, SocDetallessol det) {
		String valor = "";

		if (var.equals("@benef")) {
			valor = getBenef(det.getBenCodigo());
		}

		if (var.equals("@cuenta")) {
			valor = getCuenta(det.getDetCtabenef());
		}

		if (var.equals("@banco")) {
			valor = getBanco(det.getDetCtabenef());
		}

		if (var.equals("@plaza")) {
			valor = getPlaza(det.getDetCtabenef());
		}

		if (var.equals("@soli")) {
			valor = getSoli(det.getId().getSocCodigo());
		}

		if (var.equals("@ctalocal")) {
			valor = getCtaLocal(det.getId().getSocCodigo(), det.getId().getDetCodigo());
		}

		if (var.equals("@ctalocalc")) {
			valor = getCtaLocalC(det.getId().getSocCodigo(), det.getId().getDetCodigo());
		}

		if (var.equals("@ctalocalp")) {
			valor = getCtaLocalP(det.getId().getSocCodigo(), det.getId().getDetCodigo());
		}

		if (var.equals("@benlocal")) {
			valor = getBenLocal(det.getId().getSocCodigo(), det.getId().getDetCodigo());
		}

		if (var.equals("@nroctal")) {
			valor = getLocal(det.getId().getSocCodigo(), det.getId().getDetCodigo());
		}

		if (var.equals("@nrocta")) {
			valor = getCtaComi(det.getId().getSocCodigo());
		}

		if (var.equals("@nroctad")) {
			valor = getNroCuenta(det.getId().getSocCodigo());
		}

		if (var.equals("@cargo")) {
			valor = getNroCuenta(det.getId().getSocCodigo());
			if (!valor.equals(""))
				valor = "CGO. CTA. " + valor;
		}

		if (var.equals("@concepto")) {
			valor = "(UTILES DE ESCRITORIO)";
		}

		if (var.equals("@venta")) {
			if (det.getDetMontoord().compareTo(BigDecimal.valueOf(0.00)) == 0) {
				valor = reemplazarVar("@nroctad", det);
			} else {
				String montoT = "";
				montoT = det.getDetMonto().divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP).toString();

				int pos = 0;
				int ll = 0;
				int sep = 0;

				montoT = montoT.replace('.', ',');
				pos = montoT.indexOf(',');
				if (pos > -1) {
					montoT = montoT.substring(0, pos + 3);
					ll = pos - 1;
					sep = ll - 3;
					if (sep > -1) {
						valor = montoT.substring(0, sep + 1) + "." + montoT.substring(sep + 1);
						montoT = valor;
						ll = sep;
						sep = ll - 3;
						if (sep > -1)
							valor = montoT.substring(0, sep + 1) + "." + montoT.substring(sep + 1);
					}
				}
				valor = "VENTA DE DIVISAS EQUIVALENTE A USD " + valor;
			}
		}

		return valor;
	}

	private static String getBenef(String cod) {
		String valor = "";

		String query = " select ben_nombre" + " from soc_benefs " + " where ben_codigo = '" + cod + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "ben_nombre".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				// log.info("resultado" + res.toString());
				valor = (String) res.get("ben_nombre");
			}
		} else {
			log.info("Error al obtener beneficiario");
		}

		return valor;
	}

	private static String getCuenta(Integer cod) {
		String valor = "";

		String query = " select cta_nrocuenta" + " from soc_cuentas " + " where cta_codigo = '" + cod + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "cta_nrocuenta".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				// log.info("resultado" + res.toString());
				valor = (String) res.get("cta_nrocuenta");
			}
		} else {
			log.info("Error al obtener cuenta");
		}

		return valor;
	}

	private static String getCtaComi(String cod) {
		log.info("XXX:@@@@@@@@@@@@@@@");
		String valor = "";
		String valor1 = "";
		String ctaM = "";
		Integer cta = 0;

		String query = "select soc_cuentac, soc_nrocuentac, sol_codigo from soc_solicitudes " + " where soc_codigo = '" + cod + "'";
		log.info("XXX: getCtaComi0 " + query);
		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "soc_cuentac, soc_nrocuentac,sol_codigo".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				// log.info("resultado" + res.toString());
				cta = (Integer) res.get("soc_cuentac");
				String ctaN = (String) res.get("soc_nrocuentac");
				String solCodigo = (String) res.get("sol_codigo");
				
				query = "select cta_movimiento from soc_cuentassol " + " where cta_codigo = '" + cta + "' ";
				List<Map<String, Object>> resultado0 = Servicios.ejecutarQuery(query, "cta_movimiento".split(","));
				if (resultado0.size() == 1) {
					for (Map<String, Object> res0 : resultado0) {
						ctaM = (String) res0.get("cta_movimiento");
					}
					if (ctaM.equals("0818"))
						valor = "CUENTA NO. " + ctaN;
					else {
						if (ctaM.equals("3987") || ctaM.equals("5970"))
							valor = "LIB. " + ctaN;
						else
							valor = ctaN;
					}

					query = " select distinct cta_nombre from soc_solcuentas " + " where cta_numero = '" + ctaN + "' and sol_codigo = '" +solCodigo + "' ";
					log.info("XXX: getCtaComi " + query);
					List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query, "cta_nombre".split(","));
					if (resultado1.size() == 1) {
						for (Map<String, Object> res1 : resultado1) {
							// log.info("resultado" + res.toString());
							valor1 = (String) res1.get("cta_nombre");
						}
					} else {
						log.info("Error al obtener nombre cuenta");
						valor = "";
						valor1 = "";
					}
				}
				else {
					log.info("Error al obtener cuenta");
					valor = "";
					valor1 = "";
				}
			}
		} else {
			log.info("Error al obtener cuenta");
			valor = "";
			valor1 = "";
		}

		return valor + " " + valor1;
	}

	private static String getCuentaComi(String cod) {
		String valor = "";
		String valor1 = "";

		String query = " select ope_nrocuentac, cla_operacion, sol_codigo from soc_operaciones " + " where ope_codigo = '" + cod + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "ope_nrocuentac, cla_operacion, sol_codigo".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				// log.info("resultado" + res.toString());
				valor = (String) res.get("ope_nrocuentac");
				String solCodigo = (String) res.get("sol_codigo");
				
				query = " select distinct cta_nombre from soc_solcuentas " + " where cta_numero = '" + valor + "' and sol_codigo = '" + solCodigo + "' ";

				List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query, "cta_nombre".split(","));
				if (resultado1.size() == 1) {
					for (Map<String, Object> res1 : resultado1) {
						// log.info("resultado" + res.toString());
						valor1 = (String) res1.get("cta_nombre");
					}
				} else {
					log.info("Error al obtener nombre cuenta");
					valor = "";
					valor1 = "";
				}
			}
		} else {
			log.info("Error al obtener cuenta");
			valor = "";
			valor1 = "";
		}

		return valor + " " + valor1 + " (UTILES DE ESCRITORIO)";
	}

	private static String getCuentaOpe(String cod) {
		String valor = "";
		String valor1 = "";

		String query = " select ope_nrocuentad, sol_codigo from soc_operaciones " + " where ope_codigo = '" + cod + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "ope_nrocuentad, sol_codigo".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				// log.info("resultado" + res.toString());
				valor = (String) res.get("ope_nrocuentad");
				String solCodigo = (String) res.get("sol_codigo");
				
				query = " select distinct cta_nombre" + " from soc_solcuentas " + " where cta_numero = '" + valor + "' and sol_codigo = '" + solCodigo + "' ";

				List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query, "cta_nombre".split(","));
				if (resultado1.size() == 1) {
					for (Map<String, Object> res1 : resultado1) {
						// log.info("resultado" + res.toString());
						valor1 = (String) res1.get("cta_nombre");
					}
				} else {
					log.info("Error al obtener nombre cuenta");
					valor = "";
					valor1 = "";
				}
			}
		} else {
			log.info("Error al obtener cuenta");
			valor = "";
			valor1 = "";
		}

		return valor + " " + valor1;
	}

	private static String getNroCuenta(String cod) {
		String valor = "";
		String valor1 = "";
		String ctaM = "";
		Integer cta = 0;

		String query = " select soc_cuentad, soc_nrocuentad, sol_codigo from soc_solicitudes " + " where soc_codigo = '" + cod + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "soc_cuentad, soc_nrocuentad, sol_codigo".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				// log.info("resultado" + res.toString());

				cta = (Integer) res.get("soc_cuentad");
				String ctaN = (String) res.get("soc_nrocuentad");
				String solCodigo = (String) res.get("sol_codigo");
				
				query = " select cta_movimiento from soc_cuentassol " + " where cta_codigo = '" + cta + "'";
				List<Map<String, Object>> resultado0 = Servicios.ejecutarQuery(query, "cta_movimiento".split(","));
				if (resultado0.size() == 1) {
					for (Map<String, Object> res0 : resultado0) {
						ctaM = (String) res0.get("cta_movimiento");
					}
					if (ctaM.equals("0818"))
						valor = "CUENTA NO. " + ctaN;
					else {
						if (ctaM.equals("3987") || ctaM.equals("5970"))
							valor = "LIB. " + ctaN;
						else
							valor = ctaN;
					}
	
					query = "select distinct cta_nombre from soc_solcuentas " + " where cta_numero = '" + ctaN + "' and sol_codigo = '" + solCodigo + "' ";
					
					List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query, "cta_nombre".split(","));
					
					if (resultado1.size() == 1) {
						for (Map<String, Object> res1 : resultado1) {
							// log.info("resultado" + res.toString());
							valor1 = (String) res1.get("cta_nombre");
						}
					} else {
						log.info("Error al obtener nombre cuenta");
						valor = "";
						valor1 = "";
					}
				}
				else {
					log.info("Error al obtener cuenta");
					valor = "";
					valor1 = "";
				}
			}
		} else {
			log.info("Error al obtener cuenta");
			valor = "";
			valor1 = "";
		}

		return valor + " " + valor1;
	}

	private static String getBanco(Integer cod) {
		String valor = "";

		String query = " select b.bco_nombre" + " from soc_cuentas c, soc_bancos b" + " where c.bco_codigo = b.bco_codigo" + " and c.cta_codigo = '" + cod
				+ "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "bco_nombre".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				// log.info("resultado" + res.toString());
				valor = (String) res.get("bco_nombre");
			}
		} else {
			log.info("Error al obtener banco");
		}

		return valor;
	}

	private static String getPlaza(Integer cod) {
		String valor = "";

		String query = " select p.pla_nombre" + " from soc_cuentas c, soc_plazas p" + " where c.bco_codigo = p.bco_codigo" + " and c.pla_codigo = p.pla_codigo"
				+ " and c.cta_codigo = '" + cod + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "pla_nombre".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				// log.info("resultado" + res.toString());
				valor = (String) res.get("pla_nombre");
			}
		} else {
			log.info("Error al obtener plaza");
		}

		return valor;
	}

	private static String getSoli(String cod) {
		String valor = "";

		String query = " select s.sol_persona" + " from soc_detallessol d, soc_solicitudes l, soc_solicitante s" + " where d.soc_codigo = l.soc_codigo"
				+ " and l.sol_codigo = s.sol_codigo" + " and d.soc_codigo = '" + cod + "'" + " and d.det_codigo = 1";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "sol_persona".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				// log.info("resultado" + res.toString());
				valor = (String) res.get("sol_persona");
			}
		} else {
			log.info("Error al obtener solicitante");
		}

		return valor;
	}

	private static String getCtaLocal(String cod, Integer det) {
		String valor = "";

		String query = " select b.ben_nombre, c.cta_nrocuenta" + " from soc_detallessol d, soc_benefsloc b, soc_cuentasloc c" + " where d.soc_codigo = '" + cod
				+ "'" + " and d.det_codigo = " + det + " " + " and d.ben_codigo = b.ben_codigo" + " and d.det_ctabenef = c.cta_codigo";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "ben_nombre, cta_nrocuenta".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				// log.info("resultado" + res.toString());
				String cta = (String) res.get("cta_nrocuenta");
				if (cta.length() > 4)
					valor = "CTA. " + (String) res.get("cta_nrocuenta") + " " + (String) res.get("ben_nombre");
				else
					valor = "";
			}
		} else {
			log.info("Error al obtener cuenta local");
		}

		return valor;
	}

	private static String getCtaLocalC(String cod, Integer det) {
		String valor = "";

		String query = " select b.ben_nombre, c.cta_nrocuenta, c.cta_nrocuenta1, c.cta_nombre" + " from soc_detallessol d, soc_benefsloc b, soc_cuentasloc c"
				+ " where d.soc_codigo = '" + cod + "'" + " and d.det_codigo = " + det + " " + " and d.ben_codigo = b.ben_codigo"
				+ " and d.det_ctabenef = c.cta_codigo";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "ben_nombre, cta_nrocuenta, cta_nrocuenta1, cta_nombre".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				// log.info("resultado" + res.toString());
				String cta = (String) res.get("cta_nrocuenta1");
				if (cta != null) {
					if (cta.length() > 4)
						valor = "CTA. " + cta + " " + (String) res.get("cta_nombre");
					else
						valor = "";
				} else {
					cta = (String) res.get("cta_nrocuenta");
					if (cta.length() > 4)
						valor = "CTA. " + cta + " " + (String) res.get("ben_nombre");
					else
						valor = "";
				}
			}
		} else {
			log.info("Error al obtener cuenta local");
		}

		return valor;
	}

	private static String getCtaLocalP(String cod, Integer det) {
		String valor = "";

		valor = getCtaLocal(cod, det);
		if (!valor.equals(""))
			valor = "ABONO EN ";
		else
			valor = "";

		return valor;
	}

	private static String getBenLocal(String cod, Integer det) {
		String valor = "";

		String query = " select beneficiario" + " from soc_benefslocal" + " where soc_codigo = '" + cod + "'" + " and det_codigo = " + det + "";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "beneficiario".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				// log.info("resultado" + res.toString());
				valor = (String) res.get("beneficiario");
			}
		} else {
			log.info("Error al obtener benef local");
		}

		return valor;
	}

	private static String getLocal(String cod, Integer det) {
		String valor = "";

		String query = " select beneficiario, cta_benef" + " from soc_benefslocal" + " where soc_codigo = '" + cod + "'" + " and det_codigo = " + det + "";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "beneficiario, cta_benef".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				// log.info("resultado" + res.toString());
				valor = "CTA. " + (String) res.get("cta_benef") + " " + (String) res.get("beneficiario");
			}
		} else {
			log.info("Error al obtener benef local");
		}

		return valor;
	}

	private static String getExportador(String cod, String cta) {
		String valor = "";

		String query = " select b.ben_nombre, c.cta_nrocuenta" + " from soc_benefsexp b, soc_cuentasexp c" + " where b.ben_codigo = c.ben_codigo"
				+ " and b.ben_codigo = '" + cod + "'" + " and c.cta_codigo = '" + cta + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "ben_nombre, cta_nrocuenta".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				// log.info("resultado" + res.toString());
				valor = "CTA. " + (String) res.get("cta_nrocuenta") + " " + (String) res.get("ben_nombre");
			}
		} else {
			log.info("Error al obtener cuenta exportador");
		}

		return valor;
	}

	private static String getExportadorC(String cod, String cta) {
		String valor = "";

		String query = " select b.ben_nombre, c.cta_nrocuenta, c.cta_nrocuenta1" + " from soc_benefsexp b, soc_cuentasexp c"
				+ " where b.ben_codigo = c.ben_codigo" + " and b.ben_codigo = '" + cod + "'" + " and c.cta_codigo = '" + cta + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "ben_nombre, cta_nrocuenta, cta_nrocuenta1".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				// log.info("resultado" + res.toString());
				String cc = (String) res.get("cta_nrocuenta1");
				if (cc != null)
					valor = "CTA. " + cc + " " + (String) res.get("ben_nombre");
				else
					valor = "CTA. " + (String) res.get("cta_nrocuenta") + " " + (String) res.get("ben_nombre");
			}
		} else {
			log.info("Error al obtener cuenta exportador");
		}

		return valor;
	}

	private static String getConciliable(String cod) {
		String valor = "";

		String query = " select soc_correlativo" + " from soc_operaciones" + " where ope_codigo = '" + cod + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "soc_correlativo".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				// log.info("resultado" + res.toString());
				valor = (String) res.get("soc_correlativo");
			}
		} else {
			log.info("Error al obtener cuenta conciliable");
		}

		return valor;
	}

}
