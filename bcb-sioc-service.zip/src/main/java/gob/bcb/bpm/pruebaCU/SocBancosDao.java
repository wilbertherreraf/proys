package gob.bcb.bpm.pruebaCU;

import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.pojos.BancoPlaza;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public class SocBancosDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocBancosDao.class);

	public SocBancos saveOrUpdate(SocBancos socBancos, SocPlazas socPlazas) {
		SocBancos socBancoOld = getSocBancoByCodigo(socBancos.getBcoCodigo());

		if (StringUtils.isBlank(socBancos.getBcoNombre())) {
			throw new BusinessException("Nombre de Banco invalido");
		}
		if (StringUtils.isBlank(socPlazas.getPlaNombre())) {
			throw new BusinessException("Nombre de Plaza invalido");
		}

		socBancos.setBcoNombre(socBancos.getBcoNombre().trim().toUpperCase());
		
		if (socBancoOld == null) {
			String cod = generarCodigo();

			socBancos.setBcoCodigo(cod);
			socBancos.setClaVigente(Short.valueOf("1"));
			socBancos.setFechaHora(new Date());

			this.getHibernateTemplate().saveOrUpdate(socBancos);
		} else {
			socBancos.setFechaHora(new Date());
			this.getHibernateTemplate().merge(socBancos);
		}

		socBancoOld = getSocBancoByCodigo(socBancos.getBcoCodigo());
		log.debug("Salvado banco " + socBancoOld.toString());

		SocPlazasDao socPlazasDao = new SocPlazasDao();
		socPlazasDao.setSessionFactory(getSessionFactory());

		socPlazasDao.saveOrUpdate(socBancoOld, socPlazas);

		return socBancoOld;
	}

	public SocBancos getSocBancoByCodigo(String bcoCodigo) {
		log.debug("Entre a buscar getSocBancoByCodigo id: " + bcoCodigo);

		StringBuffer query = new StringBuffer();
		query = query.append("select be ");
		query = query.append("from SocBancos be ");
		query = query.append("where be.bcoCodigo = :bcoCodigo ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("bcoCodigo", bcoCodigo);

		List lista = consulta.list();

		if (lista.size() > 0) {
			return (SocBancos) lista.get(0);
		}
		return null;
	}

	public List<BancoPlaza> getBancosPlazas(String bcoCodigo, String plaBic) {
		SocPlazasDao socPlazasDao = new SocPlazasDao();
		socPlazasDao.setSessionFactory(getSessionFactory());

		List<BancoPlaza> bancoPlazaLista = new ArrayList<BancoPlaza>();
		StringBuffer query = new StringBuffer();
		query = query.append("select b ");
		query = query.append("from SocBancos b, SocPlazas p  ");
		query = query.append("where b.bcoCodigo = p.id.bcoCodigo ");
	
		if (!StringUtils.isBlank(bcoCodigo)) {
			query = query.append("and b.bcoCodigo = :bcoCodigo ");
		}

		if (!StringUtils.isBlank(plaBic)) {
			query = query.append("and p.plaBic = :plaBic ");
		}

		query = query.append("order by p.plaBic ");

		log.debug("Entre a buscar bancosPlazas id: " + bcoCodigo + " " + query.toString());

		Query consulta = getSession().createQuery(query.toString());

		if (!StringUtils.isBlank(bcoCodigo)) {
			consulta.setParameter("bcoCodigo", bcoCodigo);
		}

		if (!StringUtils.isBlank(plaBic)) {
			consulta.setParameter("plaBic", plaBic.trim().toUpperCase());
		}

		List<SocBancos> lista = consulta.list();
		for (SocBancos socBancos : lista) {
			BancoPlaza banco = new BancoPlaza();

			banco.setBcoCodigo(socBancos.getBcoCodigo());
			banco.setBcoNombre(socBancos.getBcoNombre());
			banco.setClaVigente(socBancos.getClaVigente());
			
			SocPlazas socPlazas = socPlazasDao.findSocPlazasByCodigo(banco.getBcoCodigo(), 1);
			
			banco.setPlaNombre(socPlazas.getPlaNombre());
			banco.setPlaBic(socPlazas.getPlaBic());
			banco.setPlaNrocuenta(socPlazas.getPlaNrocuenta());
			banco.setPlaIntermediario(socPlazas.getPlaIntermediario());
			banco.setPlaCodigo(socPlazas.getId().getPlaCodigo());
			banco.setPlaVigente(socPlazas.getClaVigente());

			banco.setSocBancos(socBancos);
			banco.setSocPlazas(socPlazas);

			bancoPlazaLista.add(banco);
		}
		
		log.debug("XXX:bancoPlazaLista " + bancoPlazaLista.size());
		return bancoPlazaLista;

	}
	public List<BancoPlaza> getBancosPlazasInter(String bcoCodigo, String plaBic) {
		SocPlazasDao socPlazasDao = new SocPlazasDao();
		socPlazasDao.setSessionFactory(getSessionFactory());

		List<BancoPlaza> bancoPlazaLista = new ArrayList<BancoPlaza>();
		StringBuffer query = new StringBuffer();
		query = query.append("select b ");
		query = query.append("from SocBancos b, SocPlazas p  ");
		query = query.append("where b.bcoCodigo = p.id.bcoCodigo ");
		query = query.append("and (p.plaBic is not null) ");		
		
		if (!StringUtils.isBlank(bcoCodigo)) {
			query = query.append("and b.bcoCodigo = :bcoCodigo ");
		}

		if (!StringUtils.isBlank(plaBic)) {
			query = query.append("and p.plaBic = :plaBic ");
		}

		query = query.append("order by p.plaBic ");

		log.debug("Entre a buscar bancosPlazas id: " + bcoCodigo + " " + query.toString());

		Query consulta = getSession().createQuery(query.toString());

		if (!StringUtils.isBlank(bcoCodigo)) {
			consulta.setParameter("bcoCodigo", bcoCodigo);
		}

		if (!StringUtils.isBlank(plaBic)) {
			consulta.setParameter("plaBic", plaBic.trim().toUpperCase());
		}

		List<SocBancos> lista = consulta.list();
		for (SocBancos socBancos : lista) {
			BancoPlaza banco = new BancoPlaza();

			banco.setBcoCodigo(socBancos.getBcoCodigo());
			banco.setBcoNombre(socBancos.getBcoNombre());
			banco.setClaVigente(socBancos.getClaVigente());
			
			SocPlazas socPlazas = socPlazasDao.findSocPlazasByCodigo(banco.getBcoCodigo(), 1);
			
			banco.setPlaNombre(socPlazas.getPlaNombre());
			banco.setPlaBic(socPlazas.getPlaBic());
			banco.setPlaNrocuenta(socPlazas.getPlaNrocuenta());
			banco.setPlaIntermediario(socPlazas.getPlaIntermediario());
			banco.setPlaCodigo(socPlazas.getId().getPlaCodigo());
			banco.setPlaVigente(socPlazas.getClaVigente());

			banco.setSocBancos(socBancos);
			banco.setSocPlazas(socPlazas);

			bancoPlazaLista.add(banco);
		}
		
		log.debug("getBancosPlazasInter " + bancoPlazaLista.size());
		return bancoPlazaLista;

	}

	public List<BancoPlaza> buscarBancosPlazas(String bcoNombre, String bcoCodigo, String plaNombre, String plaBic, String plaNrocuenta) {

		StringBuffer query = new StringBuffer();
		List<BancoPlaza> bancoPlazaLista = new ArrayList<BancoPlaza>();
		query = query
				.append("select b.bco_codigo,b.bco_nombre,b.cla_vigente, p.pla_nombre, p.pla_bic, p.pla_nrocuenta, p.pla_intermediario, p.pla_codigo, b.cla_vigente pla_vigente ");
		query = query.append("from soc_bancos b, soc_plazas p ");
		query = query.append("where b.bco_codigo = p.bco_codigo ");

		if (!StringUtils.isBlank(bcoCodigo)) {
			query = query.append("and b.bco_codigo = :bcoCodigo ");
		}

		if (!StringUtils.isBlank(bcoNombre)) {
			query = query.append("and upper(b.bco_nombre) like :bcoNombre ");
		}

		if (!StringUtils.isBlank(plaNombre)) {
			query = query.append("and upper(p.pla_nombre) like :plaNombre ");
		}

		if (!StringUtils.isBlank(plaBic)) {
			query = query.append("and upper(p.pla_bic) like :plaBic ");
		}

		query = query.append("order by b.bco_nombre ");

		log.debug("Entre a buscar bancosPlazas id: " + bcoCodigo + " " + query.toString());

		Query consulta = getSession().createSQLQuery(query.toString());

		if (!StringUtils.isBlank(bcoCodigo)) {
			consulta.setParameter("bcoCodigo", bcoCodigo);
		}

		if (!StringUtils.isBlank(bcoNombre)) {
			consulta.setParameter("bcoNombre", "%" + bcoNombre.toUpperCase() + "%");
		}

		if (!StringUtils.isBlank(plaNombre)) {
			consulta.setParameter("plaNombre", "%" + plaNombre.toUpperCase() + "%");
		}

		if (!StringUtils.isBlank(plaBic)) {
			consulta.setParameter("plaBic", plaBic.toUpperCase() + "%");
		}

		List lista = consulta.list();
		// log.info("XXX:bancosPlazas id: " + bcoCodigo + " " + lista.size());
		Iterator it = lista.iterator();

		try {

			while (it.hasNext()) {
				Object[] result = (Object[]) it.next();
				BancoPlaza banco = new BancoPlaza();

				banco.setBcoCodigo((String) result[0]);
				banco.setBcoNombre((String) result[1]);
				banco.setClaVigente((Short) result[2]);
				banco.setPlaNombre((String) result[3]);
				banco.setPlaBic((String) result[4]);
				banco.setPlaNrocuenta((String) result[5]);
				banco.setPlaIntermediario((String) result[6]);
				banco.setPlaCodigo((Integer) result[7]);
				banco.setPlaVigente((Short) result[8]);
				bancoPlazaLista.add(banco);
			}
		} catch (Exception e) {
			log.error("Error al bancoPlazaLista: " + e.getMessage());
			throw new RuntimeException("Error al bancoPlazaLista: " + e.getMessage());
		}
		log.debug("XXX:bancoPlazaLista " + bancoPlazaLista.size());
		return bancoPlazaLista;

	}

	public BancoPlaza bancoPlazaByCod(String bcoCodigo) {

		if (StringUtils.isBlank(bcoCodigo)) {
			return null;
		}
		List<BancoPlaza> bancoPlazaLista = getBancosPlazas(bcoCodigo, null);
		if (bancoPlazaLista.size() == 1) {
			return bancoPlazaLista.get(0);
		}
		return null;
	}

	public BancoPlaza bancoPlazaByBic(String plaBic) {

		if (StringUtils.isBlank(plaBic)) {
			return null;
		}
		List<BancoPlaza> bancoPlazaLista = getBancosPlazas(null, plaBic);
		if (bancoPlazaLista.size() > 0) {
			return bancoPlazaLista.get(0);
		}
		return null;
	}

	private String generarCodigo() {
		// 1327501391867 codigo menor de solicitudes en historico
		StringBuffer query = new StringBuffer();
		query = query.append("select max(to_number(bco_codigo)) ");
		query = query.append("from soc_bancos ");
		query = query.append("where bco_codigo not matches '*[a-z|A-Z|.|,]*' ");

		Query consulta = getSession().createSQLQuery(query.toString());

		log.debug("Entre a generarCodbanco " + consulta.toString());

		String codSolicitud = "0";
		Long codigo = Long.valueOf(0);

		BigDecimal maxi = BigDecimal.ZERO;
		List result = consulta.list();
		if (result.size() > 0)
			maxi = (BigDecimal) result.get(0);

		if (maxi != null) {
			codigo = Long.valueOf(maxi.toPlainString());
			codigo++;
		} else {
			codigo = Long.valueOf(1);
		}

		codSolicitud = String.format("%06d", codigo);

		log.debug("Cod solicitud nuevo: " + codSolicitud);
		return codSolicitud;
	}

}
