package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;

public class SocFacturasId implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "cpb_codigo")
	private String cpbCodigo;

	@Column(name = "ren_codigo")
	private Integer renCodigo;

	@Column(name = "fac_codigo")
	private Integer facCodigo;

	public SocFacturasId() {
	}

	public SocFacturasId(String cpbCodigo, Integer renCodigo, Integer facCodigo) {
		this.cpbCodigo = cpbCodigo;
		this.renCodigo = renCodigo;
		this.facCodigo = facCodigo;
	}

	public String getCpbCodigo() {
		return cpbCodigo;
	}

	public void setCpbCodigo(String cpbCodigo) {
		this.cpbCodigo = cpbCodigo;
	}

	public Integer getRenCodigo() {
		return renCodigo;
	}

	public void setRenCodigo(Integer renCodigo) {
		this.renCodigo = renCodigo;
	}

	public Integer getFacCodigo() {
		return facCodigo;
	}

	public void setFacCodigo(Integer facCodigo) {
		this.facCodigo = facCodigo;
	}

	
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((cpbCodigo == null) ? 0 : cpbCodigo.hashCode());
		result = prime * result + ((facCodigo == null) ? 0 : facCodigo.hashCode());
		result = prime * result + ((renCodigo == null) ? 0 : renCodigo.hashCode());
		return result;
	}

	
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SocFacturasId other = (SocFacturasId) obj;
		if (cpbCodigo == null) {
			if (other.cpbCodigo != null)
				return false;
		} else if (!cpbCodigo.equals(other.cpbCodigo))
			return false;
		if (facCodigo == null) {
			if (other.facCodigo != null)
				return false;
		} else if (!facCodigo.equals(other.facCodigo))
			return false;
		if (renCodigo == null) {
			if (other.renCodigo != null)
				return false;
		} else if (!renCodigo.equals(other.renCodigo))
			return false;
		return true;
	}


}
