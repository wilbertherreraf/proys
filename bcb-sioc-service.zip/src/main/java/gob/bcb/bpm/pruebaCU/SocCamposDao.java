package gob.bcb.bpm.pruebaCU;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class SocCamposDao  extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocCamposDao.class);
	
}
