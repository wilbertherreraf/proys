package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the soc_solicitudes database table.
 * 
 */
@Entity
@Table(name = "soc_solicitudes")
public class SocSolicitudes implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "soc_codigo")
	private String socCodigo;

	@Column(name = "cla_estado")
	private Character claEstado;

	@Column(name = "cla_estadows")
	private String claEstadows;
	
	@Column(name = "cla_tipo")
	private String claTipo;

	@Column(name = "esq_codigo")
	private Integer esqCodigo;

	@Column(name = "cve_subtipooper")
	private String cveSubtipooper;

	private String estacion;

	@Temporal(TemporalType.DATE)
	private Date fecha;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "fecha_reg")
	private Date fechaReg;

	@Temporal(TemporalType.DATE)
	@Column(name = "fecha_cont")
	private Date fechaCont;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "fecha_hora")
	private Date fechaHora;
	
	@Column(name = "cod_moneda")
	private Integer codMoneda;

	private String moneda;
	
	@Column(name = "cod_monedat")
	private Integer codMonedat;
	
	private String monedaT;

	@Column(name = "soc_correlativo")
	private String socCorrelativo;

	@Column(name = "referencia")
	private String referencia;

	@Column(name = "soc_cuentac")
	private Integer socCuentac;

	@Column(name = "soc_cuentad")
	private Integer socCuentad;

	@Column(name = "soc_montome")
	private BigDecimal socMontome;

	@Column(name = "soc_montomn")
	private BigDecimal socMontomn;

	@Column(name = "soc_montoord")
	private BigDecimal socMontoord;

	@Column(name = "soc_nrocuentac")
	private String socNrocuentac;

	@Column(name = "soc_nrocuentad")
	private String socNrocuentad;

	@Column(name = "soc_tipoc")
	private BigDecimal socTipoc;

	@Column(name = "sol_codigo")
	private String solCodigo;

	@Column(name = "sol_entsolic")
	private String solEntsolic;

	@Column(name = "tipo_retencion")
	private String tipoRetencion;

	@Column(name = "soc_tipnegociacion")
	private String socTipnegociacion;
	
	@Column(name="det_concepto")
	private String detConcepto;
	
	@Column(name="det_facturas")
	private String detFacturas;
	
	@Column(name="tipo_concepto")
	private String tipoConcepto;
	
	@Column(name="cod_solicitudorig")
	private String codSolicitudorig;

	@Column(name="cve_tipctasolic")
	private String cveTipctasolic;

	@Column(name = "usr_codreg")
	private String usrCodreg;

	@Column(name = "usr_codauto")
	private String usrCodauto;

	@Column(name = "usr_codigo")
	private String usrCodigo;

	public SocSolicitudes() {
	}

	public SocSolicitudes(String socCodigo, String solCodigo, String claTipo, String moneda) {
		this.socCodigo = socCodigo;
		this.solCodigo = solCodigo;
		this.claTipo = claTipo;
		this.moneda = moneda;
	}

	public SocSolicitudes(String socCodigo, String solCodigo, String claTipo, Integer socCuentad, String socNrocuentad, String moneda,
			Character claEstado, Date fecha, BigDecimal socMontome, String socCorrelativo) {
		this.socCodigo = socCodigo;
		this.solCodigo = solCodigo;
		this.claTipo = claTipo;
		this.socCuentad = socCuentad;
		this.socNrocuentad = socNrocuentad;
		this.moneda = moneda;
		this.claEstado = claEstado;
		this.fecha = fecha;
		this.socMontome = socMontome;
		this.socCorrelativo = socCorrelativo;
	}

	public SocSolicitudes(String socCodigo, String solCodigo, String claTipo, Integer socCuentad, String socNrocuentad, String moneda,
			Character claEstado, Date fecha, BigDecimal socMontome, Integer socCuentac, String socNrocuentac, String socCorrelativo,
			BigDecimal socMontoord, String monedaT) {
		this.socCodigo = socCodigo;
		this.solCodigo = solCodigo;
		this.claTipo = claTipo;
		this.socCuentad = socCuentad;
		this.socNrocuentad = socNrocuentad;
		this.moneda = moneda;
		this.claEstado = claEstado;
		this.fecha = fecha;
		this.socMontome = socMontome;
		this.socCuentac = socCuentac;
		this.socNrocuentac = socNrocuentac;
		this.socCorrelativo = socCorrelativo;
		this.socMontoord = socMontoord;
		this.monedaT = monedaT;
	}

	public SocSolicitudes(String socCodigo, String solCodigo, String claTipo, Integer socCuentad, String socNrocuentad, String moneda,
			Character claEstado, Date fecha, BigDecimal socMontome, Integer socCuentac, String socNrocuentac, String socCorrelativo,
			BigDecimal socMontoord, BigDecimal socMontomn, String socNropago, String monedaT) {
		this.socCodigo = socCodigo;
		this.solCodigo = solCodigo;
		this.claTipo = claTipo;
		this.socCuentad = socCuentad;
		this.socNrocuentad = socNrocuentad;
		this.moneda = moneda;
		this.claEstado = claEstado;
		this.fecha = fecha;
		this.socMontome = socMontome;
		this.socCuentac = socCuentac;
		this.socNrocuentac = socNrocuentac;
		this.socCorrelativo = socCorrelativo;
		this.socMontoord = socMontoord;
		this.socMontomn = socMontomn;
		this.monedaT = monedaT;
	}

	public SocSolicitudes(String socCodigo, String solCodigo, String claTipo, Integer socCuentad, String socNrocuentad, String moneda,
			Character claEstado, Date fecha, BigDecimal socMontome, Integer socCuentac, String socNrocuentac, String socCorrelativo,
			BigDecimal socMontoord, BigDecimal socMontomn, String socNropago, String monedaT, BigDecimal socTipoc) {
		this.socCodigo = socCodigo;
		this.solCodigo = solCodigo;
		this.claTipo = claTipo;
		this.socCuentad = socCuentad;
		this.socNrocuentad = socNrocuentad;
		this.moneda = moneda;
		this.claEstado = claEstado;
		this.fecha = fecha;
		this.socMontome = socMontome;
		this.socCuentac = socCuentac;
		this.socNrocuentac = socNrocuentac;
		this.socCorrelativo = socCorrelativo;
		this.socMontoord = socMontoord;
		this.socMontomn = socMontomn;
		this.monedaT = monedaT;
		this.socTipoc = socTipoc;
	}

	public String getSocCodigo() {
		return this.socCodigo;
	}

	public void setSocCodigo(String socCodigo) {
		this.socCodigo = socCodigo;
	}

	public Character getClaEstado() {
		return this.claEstado;
	}

	public void setClaEstado(Character claEstado) {
		this.claEstado = claEstado;
	}

	public String getClaTipo() {
		return this.claTipo;
	}

	public void setClaTipo(String claTipo) {
		this.claTipo = claTipo;
	}

	public String getCveSubtipooper() {
		return this.cveSubtipooper;
	}

	public void setCveSubtipooper(String cveSubtipooper) {
		this.cveSubtipooper = cveSubtipooper;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFecha() {
		return this.fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getMoneda() {
		return this.moneda;
	}

	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	public String getSocCorrelativo() {
		return this.socCorrelativo;
	}

	public void setSocCorrelativo(String socCorrelativo) {
		this.socCorrelativo = socCorrelativo;
	}

	public Integer getSocCuentac() {
		return this.socCuentac;
	}

	public void setSocCuentac(Integer socCuentac) {
		this.socCuentac = socCuentac;
	}

	public Integer getSocCuentad() {
		return this.socCuentad;
	}

	public void setSocCuentad(Integer socCuentad) {
		this.socCuentad = socCuentad;
	}

	public BigDecimal getSocMontome() {
		return this.socMontome;
	}

	public void setSocMontome(BigDecimal socMontome) {
		this.socMontome = socMontome;
	}

	public BigDecimal getSocMontomn() {
		return this.socMontomn;
	}

	public void setSocMontomn(BigDecimal socMontomn) {
		this.socMontomn = socMontomn;
	}

	public BigDecimal getSocMontoord() {
		return this.socMontoord;
	}

	public void setSocMontoord(BigDecimal socMontoord) {
		this.socMontoord = socMontoord;
	}

	public String getSocNrocuentac() {
		return this.socNrocuentac;
	}

	public void setSocNrocuentac(String socNrocuentac) {
		this.socNrocuentac = socNrocuentac;
	}

	public String getSocNrocuentad() {
		return this.socNrocuentad;
	}

	public void setSocNrocuentad(String socNrocuentad) {
		this.socNrocuentad = socNrocuentad;
	}

	public BigDecimal getSocTipoc() {
		return this.socTipoc;
	}

	public void setSocTipoc(BigDecimal socTipoc) {
		this.socTipoc = socTipoc;
	}

	public String getSolCodigo() {
		return this.solCodigo;
	}

	public void setSolCodigo(String solCodigo) {
		this.solCodigo = solCodigo;
	}

	public String getUsrCodigo() {
		return this.usrCodigo;
	}

	public void setUsrCodigo(String usrCodigo) {
		this.usrCodigo = usrCodigo;
	}

	public String getMonedaT() {
		return monedaT;
	}

	public void setMonedaT(String monedaT) {
		this.monedaT = monedaT;
	}

	public void setFechaReg(Date fechaReg) {
		this.fechaReg = fechaReg;
	}

	public Date getFechaReg() {
		return fechaReg;
	}

	public void setSolEntsolic(String solEntsolic) {
		this.solEntsolic = solEntsolic;
	}

	public String getSolEntsolic() {
		return solEntsolic;
	}

	public void setEsqCodigo(Integer esqCodigo) {
		this.esqCodigo = esqCodigo;
	}

	public Integer getEsqCodigo() {
		return esqCodigo;
	}

	public void setFechaCont(Date fechaCont) {
		this.fechaCont = fechaCont;
	}

	public Date getFechaCont() {
		return fechaCont;
	}

	public void setTipoRetencion(String tipoRetencion) {
		this.tipoRetencion = tipoRetencion;
	}

	public String getTipoRetencion() {
		return tipoRetencion;
	}

//	public void setGlosa(String glosa) {
//		this.glosa = glosa;
//	}
//
//	public String getGlosa() {
//		return glosa;
//	}

	public void setDetConcepto(String detConcepto) {
		this.detConcepto = detConcepto;
	}

	public String getDetConcepto() {
		return detConcepto;
	}

	public void setDetFacturas(String detFacturas) {
		this.detFacturas = detFacturas;
	}

	public String getDetFacturas() {
		return detFacturas;
	}

	public void setCodMoneda(Integer codMoneda) {
		this.codMoneda = codMoneda;
	}

	public Integer getCodMoneda() {
		return codMoneda;
	}

	public void setCodMonedat(Integer codMonedat) {
		this.codMonedat = codMonedat;
	}

	public Integer getCodMonedat() {
		return codMonedat;
	}

	public String getClaEstadows() {
		return claEstadows;
	}

	public void setClaEstadows(String claEstadows) {
		this.claEstadows = claEstadows;
	}

	public String getTipoConcepto() {
		return tipoConcepto;
	}

	public void setTipoConcepto(String tipoConcepto) {
		this.tipoConcepto = tipoConcepto;
	}

	public String getCodSolicitudorig() {
		return codSolicitudorig;
	}

	public void setCodSolicitudorig(String codSolicitudorig) {
		this.codSolicitudorig = codSolicitudorig;
	}

	public String getCveTipctasolic() {
		return cveTipctasolic;
	}

	public void setCveTipctasolic(String cveTipctasolic) {
		this.cveTipctasolic = cveTipctasolic;
	}

	public String getUsrCodreg() {
		return usrCodreg;
	}

	public void setUsrCodreg(String usrCodreg) {
		this.usrCodreg = usrCodreg;
	}

	public String getUsrCodauto() {
		return usrCodauto;
	}

	public void setUsrCodauto(String usrCodauto) {
		this.usrCodauto = usrCodauto;
	}

	public String getReferencia() {
		return referencia;
	}

	public void setReferencia(String referencia) {
		this.referencia = referencia;
	}

	public String getSocTipnegociacion() {
		return socTipnegociacion;
	}

	public void setSocTipnegociacion(String socTipnegociacion) {
		this.socTipnegociacion = socTipnegociacion;
	}

	
	public String toString() {
		return "SocSolicitudes [socCodigo=" + socCodigo + ", claEstado=" + claEstado + ", claEstadows=" + claEstadows + ", claTipo=" + claTipo
				+ ", esqCodigo=" + esqCodigo + ", cveSubtipooper=" + cveSubtipooper + ", estacion=" + estacion + ", fecha=" + fecha + ", fechaReg="
				+ fechaReg + ", fechaCont=" + fechaCont + ", fechaHora=" + fechaHora + ", codMoneda=" + codMoneda + ", moneda=" + moneda
				+ ", codMonedat=" + codMonedat + ", monedaT=" + monedaT + ", socCorrelativo=" + socCorrelativo + ", referencia=" + referencia
				+ ", socCuentac=" + socCuentac + ", socCuentad=" + socCuentad + ", socMontome=" + socMontome + ", socMontomn=" + socMontomn
				+ ", socMontoord=" + socMontoord + ", socNrocuentac=" + socNrocuentac + ", socNrocuentad=" + socNrocuentad + ", socTipoc=" + socTipoc
				+ ", solCodigo=" + solCodigo + ", solEntsolic=" + solEntsolic + ", tipoRetencion=" + tipoRetencion + ", socTipnegociacion="
				+ socTipnegociacion + ", detConcepto=" + detConcepto + ", detFacturas=" + detFacturas + ", tipoConcepto=" + tipoConcepto
				+ ", codSolicitudorig=" + codSolicitudorig + ", cveTipctasolic=" + cveTipctasolic + ", usrCodreg=" + usrCodreg + ", usrCodauto="
				+ usrCodauto + ", usrCodigo=" + usrCodigo + "]";
	}

	
}
