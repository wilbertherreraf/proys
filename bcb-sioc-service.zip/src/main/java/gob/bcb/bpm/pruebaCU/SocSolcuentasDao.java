package gob.bcb.bpm.pruebaCU;

import gob.bcb.service.exception.BusinessException;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public class SocSolcuentasDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocSolcuentasDao.class);

	public void saveOrUpdate(SocSolcuentas pm) {
		this.getHibernateTemplate().saveOrUpdate(pm);
	}

	public SocSolcuentas getByCodigo(String solCodigo, Integer ctaCodigo, Integer corrCuenta) {
		List<SocSolcuentas> lista = solCuentasLista(solCodigo, ctaCodigo, null, corrCuenta);
		if (lista.size() > 0) {
			return (SocSolcuentas) lista.get(0);
		}

		return null;
	}

	public SocSolcuentas registrarCtaSolicitante(SocSolicitudes socSolicitudes, SocSolcuentas socSolcuentas, String ctaMovimiento,
			String ctaAfectable, Integer codMoneda) {
		log.info("Salvando cuenta solicitante ctaMovimiento: " + ctaMovimiento + " Moneda:" + codMoneda + " cta: " + socSolcuentas.getCtaNumero());
		SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
		socCuentassolDao.setSessionFactory(getSessionFactory());

		SocSolcuentas socSolcuentasOld = findCtaSolicitante(socSolicitudes.getSolCodigo(), ctaMovimiento, ctaAfectable, codMoneda,
				socSolcuentas.getCtaNumero(), null);

		if (socSolcuentasOld == null) {
			SocCuentassol socCuentassol = socCuentassolDao.getByCtaMovMonedaVig(ctaMovimiento, codMoneda);
			if (socCuentassol == null) {
				throw new BusinessException("Cuenta contable " + ctaMovimiento + " moneda " + codMoneda
						+ " inexistente o suspendido en socCuentassol , comunique al administrador.");
			}

			Integer cod = generarCodigo(socSolicitudes.getSolCodigo(), socCuentassol.getCtaCodigo());

			SocSolcuentasPK socSolcuentasPK = new SocSolcuentasPK();
			socSolcuentasPK.setSolCodigo(socSolicitudes.getSolCodigo());
			socSolcuentasPK.setCtaCodigo(socCuentassol.getCtaCodigo());

			socSolcuentasPK.setCorrCuenta(cod);
			
			socSolcuentas.setId(socSolcuentasPK);
			socSolcuentas.setClaVigente(Short.valueOf("1"));
			socSolcuentas.setEstacion(socSolicitudes.getEstacion());
			socSolcuentas.setUsrCodigo(socSolicitudes.getUsrCodigo());
			socSolcuentas.setFechaHora(new Date());

			this.getHibernateTemplate().saveOrUpdate(socSolcuentas);
			log.info("Nueva cuenta solicitante registrado sol: " + socSolicitudes.getSolCodigo() + " cod cta:" + socCuentassol.getCtaCodigo()
					+ " cta: " + socSolcuentas.getCtaNumero());

			socSolcuentasOld = getByCodigo(socSolicitudes.getSolCodigo(), socSolcuentas.getId().getCtaCodigo(), cod);
		} else {
			if (socSolcuentasOld.getClaVigente() != null && socSolcuentasOld.getClaVigente().compareTo(Short.valueOf("1")) == 0){
				if (!StringUtils.isBlank(socSolcuentas.getCtaNombre()) && !StringUtils.isBlank(socSolcuentasOld.getCtaNombre())){
					if (socSolcuentas.getCtaNombre().trim().equalsIgnoreCase(socSolcuentasOld.getCtaNombre().trim())){
						// la cuenta es la misma que en la base no se actualiza
						return socSolcuentasOld;
					}
				}
			}
			
			socSolcuentasOld.setClaVigente(Short.valueOf("1"));
			if (!StringUtils.isBlank(socSolcuentas.getCtaNombre())){
				// actualizamos el nombre de la cuenta
				socSolcuentasOld.setCtaNombre(socSolcuentas.getCtaNombre());
			}
			socSolcuentasOld.setEstacion(socSolicitudes.getEstacion());
			socSolcuentasOld.setUsrCodigo(socSolicitudes.getUsrCodigo());
			socSolcuentasOld.setFechaHora(new Date());
			log.info("Actualizando cuenta solicitante registrado sol: " + socSolicitudes.getSolCodigo() + " cta: " + socSolcuentasOld.getCtaNumero());
			this.getHibernateTemplate().saveOrUpdate(socSolcuentasOld);
		}

		return socSolcuentasOld;
	}

	public List<SocSolcuentas> solCuentasLista(String solCodigo, Integer ctaCodigo, String ctaNumero, Integer corrCuenta) {
		StringBuffer query = new StringBuffer();
		query = query.append("select cc ");
		query = query.append("from SocSolcuentas cc ");
		query = query.append("where cc.id.ctaCodigo > 0 ");

		if (!StringUtils.isBlank(solCodigo)) {
			query = query.append("and cc.id.solCodigo = :solCodigo ");
		}

		if (!StringUtils.isBlank(ctaNumero)) {
			query = query.append("and cc.ctaNumero = :ctaNumero ");
		}

		if (ctaCodigo != null) {
			query = query.append("and cc.id.ctaCodigo = :ctaCodigo ");
		}
		if (corrCuenta != null) {
			query = query.append("and cc.id.corrCuenta = :corrCuenta ");
		}
		Query consulta = getSession().createQuery(query.toString());
		if (!StringUtils.isBlank(solCodigo)) {
			consulta.setParameter("solCodigo", solCodigo);
		}

		if (!StringUtils.isBlank(ctaNumero)) {
			consulta.setParameter("ctaNumero", ctaNumero);
		}

		if (ctaCodigo != null) {
			consulta.setInteger("ctaCodigo", ctaCodigo);
		}

		if (corrCuenta != null) {
			consulta.setInteger("corrCuenta", corrCuenta);
		}
		List lista = consulta.list();

		return lista;
	}

	public List<SocSolcuentas> cuentasEnCuentaSolicitante(String solCodigo, String ctaMovimiento, String ctaAfectable, Integer codMoneda,
			String ctaNumero, Integer claVigente) {
		StringBuffer query = new StringBuffer();
		query = query.append("select sc ");
		query = query.append("from SocSolcuentas sc ");
		query = query.append("where sc.id.solCodigo = :solCodigo ");
		query = query.append("and sc.id.ctaCodigo in (select s2.ctaCodigo from SocCuentassol s2 ");
		query = query.append("where s2.claVigente = 1 ");

		if (codMoneda != null)
			query = query.append("and s2.moneda = :codMoneda ");

		if (!StringUtils.isBlank(ctaAfectable))
			query = query.append("and s2.ctaAfectable = :ctaAfectable ");

		if (!StringUtils.isBlank(ctaMovimiento))
			query = query.append("and s2.ctaMovimiento = :ctaMovimiento ");

		query = query.append(" ) ");

		if (!StringUtils.isBlank(ctaNumero)) 
			query = query.append("AND sc.ctaNumero = :ctaNumero ");

		if (claVigente != null)
			query = query.append("and sc.claVigente = :claVigente ");

		log.info("Consulta cuentasEnCuentaSolicitante " + query.toString());
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("solCodigo", solCodigo);

		if (codMoneda != null) 
			consulta.setParameter("codMoneda", codMoneda);

		if (!StringUtils.isBlank(ctaAfectable)) 
			consulta.setParameter("ctaAfectable", ctaAfectable);

		if (!StringUtils.isBlank(ctaMovimiento)) 
			consulta.setParameter("ctaMovimiento", ctaMovimiento);

		if (!StringUtils.isBlank(ctaNumero)) {
			consulta.setParameter("ctaNumero", ctaNumero);
		}

		if (claVigente != null)
			consulta.setParameter("claVigente", claVigente);

		List<SocSolcuentas> lista = new ArrayList<SocSolcuentas>();
		List<SocSolcuentas> listaProvi = consulta.list();

		Map<String, String> mapaCtrl = new HashMap<String, String>();

		for (SocSolcuentas socSolcuentas : listaProvi) {
			if (!mapaCtrl.containsKey(socSolcuentas.getCtaNumero())) {
				lista.add(socSolcuentas);
				mapaCtrl.put(socSolcuentas.getCtaNumero(), socSolcuentas.getCtaNumero());
			}
		}
		return lista;
	}

	public SocSolcuentas findCtaSolicitante(String solCodigo, String ctaMovimiento, String ctaAfectable, Integer codMoneda, String ctaNumero,
			Integer claVigente) {
		StringBuffer query = new StringBuffer();
		query = query.append("select sc ");
		query = query.append("from SocSolcuentas sc ");
		query = query.append("where sc.id.solCodigo = :solCodigo ");
		query = query.append("and sc.id.ctaCodigo in (select s2.ctaCodigo from SocCuentassol s2 ");
		query = query.append("where s2.claVigente = 1 ");

		if (!StringUtils.isBlank(ctaAfectable)) {
			query = query.append("and s2.ctaAfectable = :ctaAfectable ");
		} else {
			query = query.append("and s2.moneda = :codMoneda ");
			query = query.append("and s2.ctaMovimiento = :ctaMovimiento ");
		}
		query = query.append(" ) ");

		query = query.append("AND sc.ctaNumero = :ctaNumero ");

		log.info("Consulta findCtaSolicitante " + query.toString());
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("solCodigo", solCodigo);

		if (!StringUtils.isBlank(ctaAfectable)) {
			consulta.setParameter("ctaAfectable", ctaAfectable);
		} else {
			consulta.setParameter("codMoneda", codMoneda);
			consulta.setParameter("ctaMovimiento", ctaMovimiento);
		}

		consulta.setParameter("ctaNumero", ctaNumero);

		List<SocSolcuentas> lista = consulta.list();

		if (lista.size() > 0) {
			return lista.get(0);
		}
		return null;
	}

	public Integer generarCodigo(String solCodigo, Integer ctaCodigo) {
		Integer maxDet = Integer.valueOf(0);
		StringBuffer query = new StringBuffer();
		query = query.append("select max(s.id.corrCuenta) ");
		query = query.append("from SocSolcuentas s ");
		query = query.append("where s.id.solCodigo = :solCodigo ");
		query = query.append("and s.id.ctaCodigo = :ctaCodigo ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("solCodigo", solCodigo);
		consulta.setInteger("ctaCodigo", ctaCodigo);

		log.info("Entre a generarCod " + consulta.toString());

		List result = consulta.list();
		if (result.size() > 0)
			maxDet = (Integer) result.get(0);

		if (maxDet == null)
			maxDet = 0;
		maxDet++;
		return maxDet;
	}

}
