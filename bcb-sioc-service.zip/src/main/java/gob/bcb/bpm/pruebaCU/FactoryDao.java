/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-bpm-mesaDeAyuda
 * gob.bcb.bpm.mesaDeAyuda.util.FactoryDao
 * 11/07/2011 - 09:59:02
 * Creado por eibanez
 */
package gob.bcb.bpm.pruebaCU;

import java.util.Collections;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * [JAVADOC_INCOMPLETO: DESARROLLADOR DEBE DOCUMENTAR CLASE]
 * 
 * 
 * @author eibanez
 * 
 */
public class FactoryDao {
	private static final Log log = LogFactory.getLog(FactoryDao.class);
	private Map<String, Object> daos;
	private SessionFactory sessionFactory;

	public FactoryDao() {
	}
	public void setDaos(Map<String, Object> mapaDaos) {
		daos = mapaDaos;
	}

	public Map<String, Object> getDaos0() {
		return Collections.unmodifiableMap(daos);
	}

	public Object getDao(String nombreDao) {
		return daos.get(nombreDao);
	}

	public void initFactory0(SessionFactory sessionFactory){
		for (Iterator<?> i = daos.keySet().iterator(); i.hasNext();) {
			String key = (String) i.next();
			HibernateDaoSupport hibernateDaoSupport =(HibernateDaoSupport) daos.get(key); 
			hibernateDaoSupport.setSessionFactory(sessionFactory);
		}

	}
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

}
