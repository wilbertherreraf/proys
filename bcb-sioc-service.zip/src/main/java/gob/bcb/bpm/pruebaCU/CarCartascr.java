package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "car_cartascr")
public class CarCartascr implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ccr_codcartacr")
	private String ccrCodcartacr;
	
	@Column(name = "ccr_tipoimpexp")
	private String ccrTipoimpexp;
	@Column(name = "ccr_anio")
	private Integer ccrAnio;
	@Column(name = "ccr_nrocorr")
	private Integer ccrNrocorr;
	@Column(name = "ccr_correlativo")	
	private String ccrCorrelativo;
	@Column(name = "ccr_soccodigo")	
	private String ccrSoccodigo;	
	@Column(name = "ccr_solcodigo")	
	private String ccrSolcodigo;	
	@Column(name = "ccr_bencodigo")	
	private String ccrBencodigo;	
	@Column(name = "ccr_bcocodigo")
	private String ccrBcocodigo;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "ccr_fechaemis")
	private Date ccrFechaemis;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "ccr_fechavtoval")
	private Date ccrFechavtoval;
	@Column(name = "ccr_fechavtopag")
	@Temporal(TemporalType.DATE)
	private Date ccrFechavtopag;
	@Column(name = "ccr_nrodias")
	private Integer ccrNrodias;
	@Column(name = "ccr_estadoccred")
	private String ccrEstadoccred;
	@Column(name = "ccr_codpais")
	private String ccrCodpais;
	@Column(name = "ccr_monto")
	private BigDecimal ccrMonto;	
	@Column(name = "ccr_saldo")
	private BigDecimal ccrSaldo;	
	@Column(name = "ccr_codmoneda")
	private Integer ccrCodmoneda;
	@Column(name = "ccr_codmontrans")
	private Integer ccrCodmontrans;	
	@Column(name = "ccr_nomproducto")
	private String ccrNomproducto;
	@Column(name = "ccr_nomimportador")
	private String ccrNomimportador;
	@Column(name = "ccr_nomexportador")
	private String ccrNomexportador;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ccr_auditfho")
	private Date ccrAuditfho;

	@Column(name = "ccr_auditusr")
	private String ccrAuditusr;

	@Column(name = "ccr_auditwst")
	private String ccrAuditwst;

	public CarCartascr() {
	}
	
	public String getCcrCodcartacr() {
		return ccrCodcartacr;
	}

	public void setCcrCodcartacr(String ccrCodcartacr) {
		this.ccrCodcartacr = ccrCodcartacr;
	}

	public String getCcrTipoimpexp() {
		return ccrTipoimpexp;
	}

	public void setCcrTipoimpexp(String ccrTipoimpexp) {
		this.ccrTipoimpexp = ccrTipoimpexp;
	}

	public Integer getCcrAnio() {
		return ccrAnio;
	}

	public void setCcrAnio(Integer ccrAnio) {
		this.ccrAnio = ccrAnio;
	}

	public String getCcrCorrelativo() {
		return ccrCorrelativo;
	}

	public void setCcrCorrelativo(String ccrCorrelativo) {
		this.ccrCorrelativo = ccrCorrelativo;
	}

	public String getCcrBcocodigo() {
		return ccrBcocodigo;
	}

	public void setCcrBcocodigo(String ccrBcocodigo) {
		this.ccrBcocodigo = ccrBcocodigo;
	}

	public Date getCcrFechaemis() {
		return ccrFechaemis;
	}

	public void setCcrFechaemis(Date ccrFechaemis) {
		this.ccrFechaemis = ccrFechaemis;
	}

	public Date getCcrFechavtoval() {
		return ccrFechavtoval;
	}

	public void setCcrFechavtoval(Date ccrFechavtoval) {
		this.ccrFechavtoval = ccrFechavtoval;
	}

	public Date getCcrFechavtopag() {
		return ccrFechavtopag;
	}

	public void setCcrFechavtopag(Date ccrFechavtopag) {
		this.ccrFechavtopag = ccrFechavtopag;
	}

	public Integer getCcrNrodias() {
		return ccrNrodias;
	}

	public void setCcrNrodias(Integer ccrNrodias) {
		this.ccrNrodias = ccrNrodias;
	}

	public String getCcrEstadoccred() {
		return ccrEstadoccred;
	}

	public void setCcrEstadoccred(String ccrEstadoccred) {
		this.ccrEstadoccred = ccrEstadoccred;
	}

	public String getCcrCodpais() {
		return ccrCodpais;
	}

	public void setCcrCodpais(String ccrCodpais) {
		this.ccrCodpais = ccrCodpais;
	}

	public BigDecimal getCcrMonto() {
		return ccrMonto;
	}

	public void setCcrMonto(BigDecimal ccrMonto) {
		this.ccrMonto = ccrMonto;
	}
	
	public Integer getCcrCodmoneda() {
		return ccrCodmoneda;
	}

	public void setCcrCodmoneda(Integer ccrCodmoneda) {
		this.ccrCodmoneda = ccrCodmoneda;
	}

	public Integer getCcrCodmontrans() {
		return ccrCodmontrans;
	}

	public void setCcrCodmontrans(Integer ccrCodmontrans) {
		this.ccrCodmontrans = ccrCodmontrans;
	}

	
	public String getCcrNomproducto() {
		return ccrNomproducto;
	}

	public void setCcrNomproducto(String ccrNomproducto) {
		this.ccrNomproducto = ccrNomproducto;
	}

	public String getCcrNomimportador() {
		return ccrNomimportador;
	}

	public void setCcrNomimportador(String ccrNomimportador) {
		this.ccrNomimportador = ccrNomimportador;
	}

	public String getCcrNomexportador() {
		return ccrNomexportador;
	}

	public void setCcrNomexportador(String ccrNomexportador) {
		this.ccrNomexportador = ccrNomexportador;
	}

	public Date getCcrAuditfho() {
		return ccrAuditfho;
	}

	public void setCcrAuditfho(Date ccrAuditfho) {
		this.ccrAuditfho = ccrAuditfho;
	}

	public String getCcrAuditusr() {
		return ccrAuditusr;
	}

	public void setCcrAuditusr(String ccrAuditusr) {
		this.ccrAuditusr = ccrAuditusr;
	}

	public String getCcrAuditwst() {
		return ccrAuditwst;
	}

	public void setCcrAuditwst(String ccrAuditwst) {
		this.ccrAuditwst = ccrAuditwst;
	}

	public Integer getCcrNrocorr() {
		return ccrNrocorr;
	}

	public void setCcrNrocorr(Integer ccrNrocorr) {
		this.ccrNrocorr = ccrNrocorr;
	}

	public String getCcrSolcodigo() {
		return ccrSolcodigo;
	}

	public void setCcrSolcodigo(String ccrSolcodigo) {
		this.ccrSolcodigo = ccrSolcodigo;
	}

	public String getCcrBencodigo() {
		return ccrBencodigo;
	}

	public void setCcrBencodigo(String ccrBencodigo) {
		this.ccrBencodigo = ccrBencodigo;
	}

	public String getCcrSoccodigo() {
		return ccrSoccodigo;
	}

	public void setCcrSoccodigo(String ccrSoccodigo) {
		this.ccrSoccodigo = ccrSoccodigo;
	}

	@Override
	public String toString() {
		return "CarCartascr [ccrCodcartacr=" + ccrCodcartacr + ", ccrTipoimpexp=" + ccrTipoimpexp + ", ccrAnio=" + ccrAnio + ", ccrNrocorr=" + ccrNrocorr + ", ccrCorrelativo="
				+ ccrCorrelativo + ", ccrSoccodigo=" + ccrSoccodigo + ", ccrSolcodigo=" + ccrSolcodigo + ", ccrBencodigo=" + ccrBencodigo + ", ccrBcocodigo=" + ccrBcocodigo
				+ ", ccrFechaemis=" + ccrFechaemis + ", ccrFechavtoval=" + ccrFechavtoval + ", ccrFechavtopag=" + ccrFechavtopag + ", ccrNrodias=" + ccrNrodias
				+ ", ccrEstadoccred=" + ccrEstadoccred + ", ccrCodpais=" + ccrCodpais + ", ccrMonto=" + ccrMonto + ", ccrCodmoneda=" + ccrCodmoneda + ", ccrCodmontrans="
				+ ccrCodmontrans + ", ccrNomproducto=" + ccrNomproducto + ", ccrNomimportador=" + ccrNomimportador + ", ccrNomexportador=" + ccrNomexportador + ", ccrAuditfho="
				+ ccrAuditfho + ", ccrAuditusr=" + ccrAuditusr + ", ccrAuditwst=" + ccrAuditwst + "]";
	}

	public BigDecimal getCcrSaldo() {
		return ccrSaldo;
	}

	public void setCcrSaldo(BigDecimal ccrSaldo) {
		this.ccrSaldo = ccrSaldo;
	}
	
	
}
