package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the soc_solicitudctas database table.
 * 
 */
@Embeddable
public class SocSolicitudctasPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="soc_codigo")
	private String socCodigo;

	@Column(name="tipo_cuenta")
	private String tipoCuenta;

    public SocSolicitudctasPK() {
    }
	public String getSocCodigo() {
		return this.socCodigo;
	}
	public void setSocCodigo(String socCodigo) {
		this.socCodigo = socCodigo;
	}
	public String getTipoCuenta() {
		return this.tipoCuenta;
	}
	public void setTipoCuenta(String tipoCuenta) {
		this.tipoCuenta = tipoCuenta;
	}
	
	public String toString() {
		return "SocSolicitudctasPK [socCodigo=" + socCodigo + ", tipoCuenta=" + tipoCuenta + "]";
	}
	
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((socCodigo == null) ? 0 : socCodigo.hashCode());
		result = prime * result + ((tipoCuenta == null) ? 0 : tipoCuenta.hashCode());
		return result;
	}
	
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SocSolicitudctasPK other = (SocSolicitudctasPK) obj;
		if (socCodigo == null) {
			if (other.socCodigo != null)
				return false;
		} else if (!socCodigo.equals(other.socCodigo))
			return false;
		if (tipoCuenta == null) {
			if (other.tipoCuenta != null)
				return false;
		} else if (!tipoCuenta.equals(other.tipoCuenta))
			return false;
		return true;
	}

}
