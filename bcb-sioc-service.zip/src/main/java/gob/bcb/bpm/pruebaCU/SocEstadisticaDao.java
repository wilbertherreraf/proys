/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.bpm.pruebaCU;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

import gob.bcb.service.commons.UserSessionHolder;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;

//import org.hibernate.Query;

/**
 * @author parenas
 * 
 */
@Transactional
public class SocEstadisticaDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocEstadisticaDao.class);
	
	public void saveOrUpdate(SocEstadistica pm) {
		pm.setFechaHora(new Date());
		if (UserSessionHolder.get(Constants.AUDIT_USER_ESTACION) != null)
			pm.setEstacion((String) UserSessionHolder.get(Constants.AUDIT_USER_ESTACION));

		if (UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID) != null)
			pm.setUsrCodigo((String) UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID));

		this.getHibernateTemplate().merge(pm);
	}
	
	
	public void saveOrUpdateSinAud(SocEstadistica pm) {
		pm.setFechaHora(new Date());
		this.getHibernateTemplate().merge(pm);
	}
	
	public void remove(SocEstadistica socEstadistica) {
		SocEstadistica socEstadisticaOld = getEstadistica(socEstadistica.getEstCodigo());

		if (socEstadisticaOld == null) {
			throw new BusinessException("Error No pudo encontrar la estadistica para " + socEstadistica.getEstCodigo());
		}

		
		socEstadisticaOld.setUsrCodigo(socEstadistica.getUsrCodigo());
		socEstadisticaOld.setEstacion(socEstadistica.getEstacion());
		socEstadisticaOld.setFechaHora(new Date());
		socEstadisticaOld.setClaEstado(Constants.CLAVE_ESTSOLIC_ANULADO);
		socEstadisticaOld.setCveEstado(Constants.CVE_TCONCEPTO_SUS);
		this.getHibernateTemplate().merge(socEstadisticaOld);
	}


	public SocEstadistica getEstadistica(String estCodigo) {
		SocEstadistica estadistica = null;
		StringBuffer consulta = new StringBuffer();
		consulta = consulta.append("select es ");
		consulta = consulta.append("from SocEstadistica es ");
		consulta = consulta.append("where es.estCodigo = :estCodigo ");

		Query query = getSession().createQuery(consulta.toString());
		query.setParameter("estCodigo", estCodigo);

		// log.info("Entre a buscar el objeto con el id: [" + solicitudId + "] "
		// + consulta.toString());

		List result = query.list();
		if (result.size() > 0) {
			estadistica = (SocEstadistica) result.get(0);
		}

		return estadistica;
	}
	
	public List<SocEstadistica> obtenerEstadisticasPorClaEstado(Character claEstado) {

		List<SocEstadistica> socEstadisticasLista = new ArrayList<SocEstadistica>();

		StringBuffer consulta = new StringBuffer();
		
		consulta.append("SELECT new gob.bcb.bpm.pruebaCU.SocEstadistica(es.estCodigo,es.solCodigo,es.claOperacion,es.estFecha,es.estMontome,es.estMontous,es.moneda,es.usrCodigo,es.fechaHora,es.estacion,es.descripcion,es.estMontomn,es.claEstado,es.cveEstado,v.valNombre, vo.valNombre) ");
		consulta.append("FROM SocEstadistica es, ");
		consulta.append("SocValorescla v, ");
		consulta.append("SocValorescla vo ");
		consulta.append("WHERE es.claEstado = v.id.valCodigo ");
		consulta.append("AND es.claOperacion = vo.id.valCodigo ");
		consulta.append("AND v.id.claCodigo = 'cve_estrepest' ");
		consulta.append("AND vo.id.claCodigo = 'cla_oprepest' ");
		consulta.append("AND es.claEstado = :claEstado ");
		

		Query query = getSession().createQuery(consulta.toString());

		query.setParameter("claEstado", claEstado);
	
		log.info("estadisticas con el claEstado: [claEstado = " + claEstado + "] " + consulta.toString());

		socEstadisticasLista = query.list();
		log.info("socEstadisticasLista = " + socEstadisticasLista.size());
		return socEstadisticasLista;
	}
	
	public List<SocEstadistica> obtenerEstadisticasPorFechaSolicitanteYEstado(Date fechaInicio, Date fechaFin, String solCodigo,Character cveEstado) {

		List<SocEstadistica> socEstadisticasLista = new ArrayList<SocEstadistica>();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String fechaDesde = format.format(fechaInicio);
		String fechaHasta = format.format(fechaFin);
		
		
		StringBuffer consulta = new StringBuffer();
		consulta.append("SELECT new gob.bcb.bpm.pruebaCU.SocEstadistica(es.estCodigo,es.solCodigo,es.claOperacion,es.estFecha,es.estMontome,es.estMontous,es.moneda,es.usrCodigo,es.fechaHora,es.estacion,es.descripcion,es.estMontomn,es.claEstado,es.cveEstado,v.valNombre, vo.valNombre) ");
		consulta.append("FROM SocEstadistica es, ");
		consulta.append("SocValorescla v, ");
		consulta.append("SocValorescla vo ");
		consulta.append("WHERE es.claEstado = v.id.valCodigo ");
		consulta.append("AND es.claOperacion = vo.id.valCodigo ");
		consulta.append("AND v.id.claCodigo = 'cve_estrepest' ");
		consulta.append("AND vo.id.claCodigo = 'cla_oprepest' ");
		
		if (cveEstado != null && !StringUtils.isBlank(cveEstado.toString().trim())) {
			consulta.append("AND es.claEstado = :claEstado ");
		} else{
			consulta.append("AND es.claEstado <> 'Z' ");
		}
				
		if (!StringUtils.isBlank(solCodigo)) {
			consulta.append("AND es.solCodigo = :solCodigo ");
		}
							
		if (fechaInicio != null) {
			consulta.append("AND DATE(es.estFecha) >= :fechaInicio ");
		}
		
		if (fechaFin != null) {
			consulta.append("AND DATE(es.estFecha) <= :fechaFin ");
		}
		
		Query query = getSession().createQuery(consulta.toString());
		if (cveEstado != null && !StringUtils.isBlank(cveEstado.toString().trim())) {
			query.setParameter("claEstado", cveEstado);	
		}
		if (!StringUtils.isBlank(solCodigo)) {
			query.setParameter("solCodigo", solCodigo);	
		}
		
		if (fechaInicio != null) {
			query.setParameter("fechaInicio", fechaDesde);	
		}
		
		if (fechaFin != null) {
			query.setParameter("fechaFin", fechaHasta);	
		}	
		
		log.info(query.toString());
		socEstadisticasLista = query.list();
		log.info("socEstadisticasLista = " + socEstadisticasLista.size());
		return socEstadisticasLista;
	}
	
	public List<SocEstadistica> obtenerEstadisticasRegistradosAlaFecha() {

		List<SocEstadistica> socEstadisticasLista = new ArrayList<SocEstadistica>();

		StringBuffer consulta = new StringBuffer();
		consulta.append("SELECT new gob.bcb.bpm.pruebaCU.SocEstadistica(es.estCodigo,es.solCodigo,es.claOperacion,es.estFecha,es.estMontome,es.estMontous,es.moneda,es.usrCodigo,es.fechaHora,es.estacion,es.descripcion,es.estMontomn,es.claEstado,es.cveEstado,v.valNombre, vo.valNombre) ");
		consulta.append("FROM SocEstadistica es, ");
		consulta.append("SocValorescla v, ");
		consulta.append("SocValorescla vo ");
		consulta.append("WHERE es.claEstado = v.id.valCodigo ");
		consulta.append("AND es.claOperacion = vo.id.valCodigo ");
		consulta.append("AND v.id.claCodigo = 'cve_estrepest' ");
		consulta.append("AND vo.id.claCodigo = 'cla_oprepest' ");
		consulta.append("AND es.claEstado = 'R' ");
		consulta.append("AND DATE(es.fechaHora) = :fechaActual");
		
		Query query = getSession().createQuery(consulta.toString());
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String fechaActual = dateFormat.format(new Date());
		query.setParameter("fechaActual", fechaActual);
		
		socEstadisticasLista = query.list();
		log.info("socEstadisticasLista = " + socEstadisticasLista.size());
		return socEstadisticasLista;
	}
	
	
	
	
	public String obtenerUlimoEstCod(){
		String resultado = "";
		StringBuffer consulta = new StringBuffer();
		consulta = consulta.append("select es.estCodigo ");
		consulta = consulta.append("from SocEstadistica es ");
		consulta = consulta.append("order by es.estCodigo desc ");
		Query query = getSession().createQuery(consulta.toString());
		List estCod = query.list();
		if(estCod.size()> 0 ){
			resultado = estCod.get(0).toString();
		}
		return resultado;
	}
	
	
}
