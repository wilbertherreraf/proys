package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the soc_datosmen database table.
 * 
 */
@Entity
@Table(name="soc_datosmen")
public class SocDatosmen implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SocDatosmenId id;

	@Column(name="dam_valor")
	private String damValor;

    public SocDatosmen() {
    }

    public SocDatosmen(SocDatosmenId id, String damValor) {
        this.id = id;
        this.damValor = damValor;
      }
    
	public SocDatosmenId getId() {
		return this.id;
	}

	public void setId(SocDatosmenId id) {
		this.id = id;
	}
	
	public String getDamValor() {
		return this.damValor;
	}

	public void setDamValor(String damValor) {
		this.damValor = damValor;
	}

	
	public String toString() {
		return "SocDatosmen [id=" + id + ", damValor=" + damValor + "]";
	}

}
