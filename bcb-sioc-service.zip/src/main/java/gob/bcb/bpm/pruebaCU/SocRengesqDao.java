package gob.bcb.bpm.pruebaCU;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public class SocRengesqDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocRengesqDao.class);

	public List<SocRengesq> getRengsEsquema(Integer id) {
		List<SocRengesq> lista = new ArrayList<SocRengesq>();

		StringBuffer query = new StringBuffer();
		query = query.append("select re ");
		query = query.append("from SocRengesq re ");
		query = query.append("where re.id.esqCodigo = :esqCodigo ");
		query = query.append("order by re.id.detCodigo ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("esqCodigo", id);

		lista = consulta.list();

		log.debug("Esquema size() " + lista.size() + " tipoOperacion " + id + "[" + ArrayUtils.toString(lista) + "]");
		return lista;
	}

	public List<SocRengesq> obtenerEsquemaByDefinicion(Integer esqCodigo, String esqDefinicion, String tipoCuenta, String ctaDestorig, String claCuenta) {
		List<SocRengesq> lista = new ArrayList<SocRengesq>();

		StringBuffer query = new StringBuffer();
		query = query.append("select re ");
		query = query.append("from SocRengesq re ");
		query = query.append("where re.claCuenta is not null ");
		
		if (esqCodigo != null){
			query = query.append("and re.id.esqCodigo = :esqCodigo ");			
		}

		if (!StringUtils.isBlank(esqDefinicion)){
			query = query.append("and re.esqDefinicion = :esqDefinicion ");			
		}

		if (!StringUtils.isBlank(tipoCuenta)){
			query = query.append("and re.tipoCuenta = :tipoCuenta ");			
		}
		
		if (!StringUtils.isBlank(ctaDestorig)){
			query = query.append("and re.ctaDestorig = :ctaDestorig ");			
		}		
		
		if (!StringUtils.isBlank(claCuenta)){
			query = query.append("and re.claCuenta = :claCuenta ");			
		}
		
		Query consulta = getSession().createQuery(query.toString());

		if (esqCodigo != null){
			consulta.setParameter("esqCodigo", esqCodigo);			
		}
		
		if (!StringUtils.isBlank(esqDefinicion)){
			consulta.setParameter("esqDefinicion", esqDefinicion);			
		}
		
		if (!StringUtils.isBlank(tipoCuenta)){
			consulta.setParameter("tipoCuenta", tipoCuenta);			
		}
		
		if (!StringUtils.isBlank(ctaDestorig)){
			consulta.setParameter("ctaDestorig", ctaDestorig);			
		}		
		
		if (!StringUtils.isBlank(claCuenta)){
			consulta.setParameter("claCuenta", claCuenta);			
		}
		
		lista = consulta.list();

		log.info("En obtenerEsquemaByDefinicion " + lista.size() + " esqCodigo " + esqCodigo + " esqDefinicion: " + esqDefinicion);
		return lista;

	}
}
