package gob.bcb.bpm.pruebaCU;

import gob.bcb.service.exception.BusinessException;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public class SocBenefslocDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocBenefslocDao.class);

	public void saveOrUpdate(SocBenefsloc pm) {
		// TODO Auto-generated method stub
		this.getHibernateTemplate().saveOrUpdate(pm);
	}

	public SocBenefsloc getBenefsByBenCodigo(String benCodigo) {
		log.debug("Entre a buscar getBenefsByBenCodigo id: " + benCodigo);

		SocBenefsloc benefs = null;
		StringBuffer query = new StringBuffer();
		query = query.append("select be ");
		query = query.append("from SocBenefsloc be ");
		query = query.append("where be.benCodigo = :benCodigo ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("benCodigo", benCodigo);

		@SuppressWarnings("unchecked")
		List lista = consulta.list();

		if (lista.size() > 0) {
			benefs = (SocBenefsloc) lista.get(0);
		}

		return benefs;
	}

	public String generarCodigo() {

		StringBuffer query = new StringBuffer();
		query = query.append("select max(to_number(ben_codigo)) ");
		query = query.append("from soc_benefsloc ");
		query = query.append("where ben_codigo not matches '*[a-z|A-Z|.|,]*' ");

		Query consulta = getSession().createSQLQuery(query.toString());

		log.debug("Entre a generarCod " + consulta.toString());

		String codSolicitud = "0";
		Long codigo = Long.valueOf(0);

		BigDecimal maxi = BigDecimal.ZERO;
		List result = consulta.list();
		if (result.size() > 0)
			maxi = (BigDecimal) result.get(0);

		if (maxi != null) {
			codigo = Long.valueOf(maxi.toPlainString());
			codigo++;
		} else {
			codigo = Long.valueOf(1);
		}

		codSolicitud = String.format("%06d", codigo);

		log.info("Cod Benef local nuevo: " + codSolicitud);
		return codSolicitud;
	}

	public List<SocBenefsloc> getBenefsBySolCodigo(String benCodigo, String solCodigo) {
		log.debug("Entre a buscar getBenefsBySolCodigo id: " + benCodigo);

		SocBenefsloc benefs = null;
		StringBuffer query = new StringBuffer();
		query = query.append("select be ");
		query = query.append("from SocBenefsloc be  ");
		query = query.append("where be.benNombre is not null ");

		if (!StringUtils.isBlank(benCodigo)) {			
			query = query.append("and be.benCodigo = :benCodigo ");
		}
		if (!StringUtils.isBlank(solCodigo)) {
			query = query.append("and be.solCodigo = :solCodigo ");
		}

		Query consulta = getSession().createQuery(query.toString());

		if (!StringUtils.isBlank(benCodigo)) {
			consulta.setParameter("benCodigo", benCodigo);
		}

		if (!StringUtils.isBlank(solCodigo)) {
			consulta.setParameter("solCodigo", solCodigo);
		}

		@SuppressWarnings("unchecked")
		List lista = consulta.list();

		return lista;
	}

	public SocBenefsloc guardarBenef(SocBenefsloc socBenefsloc) {
		SocBenefsloc socBenefslocOld = getBenefsByBenCodigo(socBenefsloc.getBenCodigo());

		if (StringUtils.isBlank(socBenefsloc.getBenNombre())){
			throw new BusinessException("Nombre de Beneficiario invalido");			
		}
		
		if (socBenefslocOld == null) {
			String cod = generarCodigo();
			socBenefsloc.setBenCodigo(cod);
			socBenefsloc.setClaVigente(Short.valueOf("1"));
			socBenefsloc.setFechaHora(new Date());

			saveOrUpdate(socBenefsloc);
		} else {
			socBenefsloc.setFechaHora(new Date());
			saveOrUpdate(socBenefsloc);
		}
		SocBenefsloc SocBenefslocNew = getBenefsByBenCodigo(socBenefsloc.getBenCodigo());
		return SocBenefslocNew;
	}

	public List<SocBenefsloc> findBenefsloc(String benNombre, String solCodigo, String ctaNrocuenta, Integer codMoneda, Short claVigente) {
		String query = "SELECT bb ";
		query = query.concat("FROM SocBenefsloc bb ");
		query = query.concat("WHERE trim(bb.benNombre) != '' ");

		if (!StringUtils.isBlank(benNombre)) {
			query = query.concat("and upper(bb.benNombre) like :benNombre ");
		}
		
		if (codMoneda != null) {
			query = query + "and exists (select 1 from SocCuentasloc c where c.benCodigo = bb.benCodigo and c.moneda = :codMoneda ) ";
		}
		
		if (!StringUtils.isBlank(ctaNrocuenta)) {
			query = query.concat("and exists (select 1 from SocCuentasloc c where c.benCodigo = bb.benCodigo and upper(c.ctaNrocuenta) like :ctaNrocuenta) ");			
		}
		
		if (!StringUtils.isBlank(solCodigo)) {
			query = query
					+ "AND exists (select 1 from SocSolbenefsloc ss where ss.id.benCodigo = bb.benCodigo and ss.id.solCodigo = :solCodigo ) ";
		}		
		
		query = query.concat("ORDER BY bb.benNombre ");

		Query consulta = getSession().createQuery(query);

		if (!StringUtils.isBlank(benNombre)) {
			consulta.setParameter("benNombre", "%" + benNombre.toUpperCase() + "%");
		}
		
		if (codMoneda != null) {
			consulta.setParameter("codMoneda", codMoneda);
		}

		if (!StringUtils.isBlank(ctaNrocuenta)) {
			consulta.setParameter("ctaNrocuenta", "%" + ctaNrocuenta.toUpperCase() + "%");
		}


		if (!StringUtils.isBlank(solCodigo)) {
			consulta.setParameter("solCodigo", solCodigo);
		}
		
		List lista = consulta.list();

		if (lista.size() == 0){
			log.info("Lista sin valores find benef " + benNombre + " " + ctaNrocuenta + " "+ solCodigo + ":: " + query);
		}
		return lista;
	}

	public List<Beneficiario> beneficiarios(String benNombre, String solCodigo, String ctaNrocuenta, Integer codMoneda, Short claVigente) {

		List<Beneficiario> beneficiarios = new ArrayList<Beneficiario>();
		List<SocBenefsloc> socBenefsLista = findBenefsloc(benNombre, solCodigo, ctaNrocuenta, codMoneda, claVigente);
		for (SocBenefsloc socBenefs : socBenefsLista) {
			Beneficiario benefi = new Beneficiario();

			benefi.setBenCodigo(socBenefs.getBenCodigo());
			//benefi.setSolCodigo(solCodigo);
			benefi.setBenNit(socBenefs.getBenNit());
			benefi.setBenFactura(socBenefs.getBenFactura());
			benefi.setBenNombre(socBenefs.getBenNombre());

			benefi.setClaVigente(socBenefs.getClaVigente());

			beneficiarios.add(benefi);

		}

		return beneficiarios;

	}

}
