package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the soc_participante database table.
 * 
 */
@Embeddable
public class SocParticipantePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="sol_codigo")
	private String solCodigo;

	@Column(name="cta_codigo")
	private int ctaCodigo;

    public SocParticipantePK() {
    }
	public String getSolCodigo() {
		return this.solCodigo;
	}
	public void setSolCodigo(String solCodigo) {
		this.solCodigo = solCodigo;
	}
	public int getCtaCodigo() {
		return this.ctaCodigo;
	}
	public void setCtaCodigo(int ctaCodigo) {
		this.ctaCodigo = ctaCodigo;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof SocParticipantePK)) {
			return false;
		}
		SocParticipantePK castOther = (SocParticipantePK)other;
		return 
			this.solCodigo.equals(castOther.solCodigo)
			&& (this.ctaCodigo == castOther.ctaCodigo);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.solCodigo.hashCode();
		hash = hash * prime + this.ctaCodigo;
		
		return hash;
    }
}