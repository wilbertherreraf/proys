package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the soc_benefs database table.
 * 
 */
@Entity
@Table(name="soc_benefs")
public class SocBenefs implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ben_codigo")
	private String benCodigo;

	@Column(name="ben_factura")
	private String benFactura;

	@Column(name="ben_nit")
	private String benNit;

	@Column(name="ben_nombre")
	private String benNombre;

	@Column(name="ben_direccion")
	private String benDireccion;
	
	@Column(name="ben_plaza")
	private String benPlaza;
	
	@Column(name="cla_entidad")
	private Integer claEntidad;

	@Column(name="cla_vigente")
	private Short claVigente;

	private String estacion;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="fecha_hora")
	private Date fechaHora;

	@Column(name="usr_codigo")
	private String usrCodigo;

    public SocBenefs() {
    }

	public String getBenCodigo() {
		return this.benCodigo;
	}

	public void setBenCodigo(String benCodigo) {
		this.benCodigo = benCodigo;
	}

	public String getBenFactura() {
		return this.benFactura;
	}

	public void setBenFactura(String benFactura) {
		this.benFactura = benFactura;
	}

	public String getBenNit() {
		return this.benNit;
	}

	public void setBenNit(String benNit) {
		this.benNit = benNit;
	}

	public String getBenNombre() {
		return this.benNombre;
	}

	public void setBenNombre(String benNombre) {
		this.benNombre = benNombre;
	}

	public Integer getClaEntidad() {
		return this.claEntidad;
	}

	public void setClaEntidad(Integer claEntidad) {
		this.claEntidad = claEntidad;
	}

	public Short getClaVigente() {
		return this.claVigente;
	}

	public void setClaVigente(Short claVigente) {
		this.claVigente = claVigente;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getUsrCodigo() {
		return this.usrCodigo;
	}

	public void setUsrCodigo(String usrCodigo) {
		this.usrCodigo = usrCodigo;
	}

	public String getBenDireccion() {
		return benDireccion;
	}

	public void setBenDireccion(String benDireccion) {
		this.benDireccion = benDireccion;
	}

	public String getBenPlaza() {
		return benPlaza;
	}

	public void setBenPlaza(String benPlaza) {
		this.benPlaza = benPlaza;
	}

	
	public String toString() {
		return "SocBenefs [benCodigo=" + benCodigo + ", benFactura=" + benFactura + ", benNit=" + benNit + ", benNombre=" + benNombre
				+ ", benDireccion=" + benDireccion + ", benPlaza=" + benPlaza + ", claEntidad=" + claEntidad + ", claVigente=" + claVigente
				+ ", estacion=" + estacion + ", fechaHora=" + fechaHora + ", usrCodigo=" + usrCodigo + "]";
	}

}
