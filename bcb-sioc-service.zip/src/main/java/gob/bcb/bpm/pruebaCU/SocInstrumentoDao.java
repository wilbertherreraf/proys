/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.bpm.pruebaCU;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
//import org.hibernate.Query;

/**
 * @author wherrera
 * 
 */
public class SocInstrumentoDao extends HibernateDaoSupport 
{
  private static final Log log = LogFactory.getLog(SocInstrumentoDao.class);

  public void saveOrUpdate(SocInstrumento pm)
  {
    log.info("Saving or updating " + pm);
    this.getHibernateTemplate().saveOrUpdate(pm);
  }
  public void eliminarInst(SocInstrumento pm) {
		log.info("Eliminando instrumento... " + pm);
		this.getHibernateTemplate().delete(pm);
	}
  
  public SocInstrumento getInstrumento(String id)
  { 
    log.info("Entre a buscar el objeto con el id: " + id);

    SocInstrumento inst = null;
      StringBuffer query = new StringBuffer();
      query = query.append(" select ii ");
      query = query.append(" from ");
      query = query.append(" SocInstrumento ii ");
      query = query.append(" where ii.insCodigo = ? ");

      List<SocInstrumento> lista = (List<SocInstrumento>) getHibernateTemplate().find(query.toString(), id);

      if (lista != null)
      {
        for (SocInstrumento ii1 : lista)
        {
          inst = ii1;
        }
      }


    return inst;
  }
  
}
