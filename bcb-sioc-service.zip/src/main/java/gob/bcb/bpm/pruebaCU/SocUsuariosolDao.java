package gob.bcb.bpm.pruebaCU;

import gob.bcb.service.commons.ConfigurationServ;
import gob.bcb.service.commons.EmailDetalle;
import gob.bcb.service.commons.UserSessionHolder;
import gob.bcb.service.servicioSioc.MsgMailListener;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public class SocUsuariosolDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocUsuariosolDao.class);

	public SocUsuariosolDao() {
//		log.info("Creando SocUsuariosolDao.... ");
	}
	public void saveOrUpdate(SocUsuariosol pm) {
		log.info("Saving or updating " + pm);
		this.getHibernateTemplate().saveOrUpdate(pm);
	}

	public SocUsuariosol getUsuario(String login) {
		StringBuffer query = new StringBuffer();
		query = query.append("select op ");
		query = query.append("from SocUsuariosol op ");
		query = query.append("where op.socUsuariosolPK.login = :login ");

//		log.info("getUsuario " + query.toString());
		Query consulta = getSession().createQuery(query.toString());		
		consulta.setParameter("login", login);

		List lista = consulta.list();
		
		if (lista.size() > 0){
			return (SocUsuariosol) lista.get(0);
		}

		return null;

	}

	public List<SocUsuariosol> getUsuariosSioc(String solCodigo, String login, String usrNotifica) {
		StringBuffer query = new StringBuffer();
		query = query.append("select op ");
		query = query.append("from SocUsuariosol op ");
		query = query.append("where op.socUsuariosolPK.solCodigo is not null ");

		if (!StringUtils.isBlank(solCodigo)) {
			query = query.append("and op.socUsuariosolPK.solCodigo = :solCodigo ");
		}
		if (!StringUtils.isBlank(login)) {
			query = query.append("and op.socUsuariosolPK.login = :login ");
		}
		if (!StringUtils.isBlank(usrNotifica)) {
			query = query.append("and op.usrNotifica = :usrNotifica ");
		}
		query = query.append("order by op.socUsuariosolPK.solCodigo ");

//		log.info("getUsuariosSioc " + query.toString());		
		Query consulta = getSession().createQuery(query.toString());

		if (!StringUtils.isBlank(solCodigo)) {
			consulta.setParameter("solCodigo", solCodigo);
		}
		if (!StringUtils.isBlank(login)) {
			consulta.setParameter("login", login);
		}
		if (usrNotifica != null) {
			consulta.setParameter("usrNotifica", usrNotifica);
		}
		
		List lista = consulta.list();

		return lista;

	}

	public String[] getUsuariosSiocMails(String solCodigo, String login, String usrNotifica) {
		List<SocUsuariosol> socUsuariosolLista = new ArrayList<SocUsuariosol>();
		StringBuffer query = new StringBuffer();
		query = query.append("select op ");
		query = query.append("from SocUsuariosol op ");
		query = query.append("where op.claVigente = 1 ");
		query = query.append("and op.usrEmail is not null ");

		if (!StringUtils.isBlank(solCodigo)) {
			query = query.append("and op.socUsuariosolPK.solCodigo in (" + solCodigo + ") ");
		}
		if (!StringUtils.isBlank(login)) {
			query = query.append("and op.socUsuariosolPK.login = :login ");
		}
		query = query.append("order by op.socUsuariosolPK.solCodigo ");

		Query consulta = getSession().createQuery(query.toString());

		if (!StringUtils.isBlank(login)) {
			consulta.setParameter("login", login);
		}

		socUsuariosolLista = consulta.list();

		List<SocUsuariosol> socUsuariosolList = new ArrayList<SocUsuariosol>();
		Map<String, String> correosMap = new HashMap<String, String>();

		for (SocUsuariosol socUsuariosol : socUsuariosolLista) {
			if (!StringUtils.isBlank(usrNotifica)) {
				if (!StringUtils.isBlank(socUsuariosol.getUsrNotifica())) {
					String[] tiposNotificaciones = socUsuariosol.getUsrNotifica().split(",");

					if (tiposNotificaciones != null && tiposNotificaciones.length > 0) {
						for (String tipoNot : tiposNotificaciones) {
							if (tipoNot.equalsIgnoreCase(usrNotifica)) {
								socUsuariosolList.add(socUsuariosol);
								correosMap.put(socUsuariosol.getUsrEmail(), socUsuariosol.getUsrEmail());
							}
						}
					}

				}
			} else {
				correosMap.put(socUsuariosol.getUsrEmail(), socUsuariosol.getUsrEmail());
			}
		}

		String emailAddresses[] = new String[correosMap.size()];
		int i = 0;
		for (Map.Entry<?, ?> entry : correosMap.entrySet()) {
			emailAddresses[i] = (String) entry.getValue();
			i++;
		}

		return emailAddresses;

	}

	public EmailDetalle formarMail(String tipoMensajemail, String subject, String content, String codSolicitantes) {
		String[] emails = null;

		SocParametrosDao socParametrosDao = new SocParametrosDao();
		socParametrosDao.setSessionFactory(getSessionFactory());
		
		SocParametros socParametros = socParametrosDao.getByCodigo("correoremitente");
		String correoremitente = socParametros.getParValor();
		
		if (tipoMensajemail.equalsIgnoreCase("SOLRECIBIDA")) {
			emails = getUsuariosSiocMails(codSolicitantes, null, null);
		} else if (tipoMensajemail.equalsIgnoreCase("SOLVENTADIRECTA")) {
			emails = getUsuariosSiocMails(codSolicitantes, null, null);
		} else if (tipoMensajemail.equalsIgnoreCase("ADJUDICACIONAUTO")) {
			emails = getUsuariosSiocMails(codSolicitantes, null, null);
		} else if (tipoMensajemail.equalsIgnoreCase("REGISTROTRANSEXTSISTFIN")) {
			emails = getUsuariosSiocMails(codSolicitantes, null, null);
		} else if (tipoMensajemail.equalsIgnoreCase("WSREGISTROSOLICTUD")) {
			emails = getUsuariosSiocMails(codSolicitantes, null, null);
		} else if (tipoMensajemail.equalsIgnoreCase("WSREGISTROSOLPENDIENTE")) {
			emails = getUsuariosSiocMails(codSolicitantes, null, null);
		} else if (tipoMensajemail.equalsIgnoreCase("WSSWIFTFERIADO")) {
			emails = getUsuariosSiocMails(codSolicitantes, null, null);
		} else if (tipoMensajemail.equalsIgnoreCase("WSSOLICITUDPROCESADA")) {
			emails = getUsuariosSiocMails(codSolicitantes, null, null);
		} else if (tipoMensajemail.equalsIgnoreCase("WSSOLCONCEPTOINVALIDO")) {
			emails = getUsuariosSiocMails(codSolicitantes, null, null);
		} else if (tipoMensajemail.equalsIgnoreCase("REGBENEF")) {
			emails = getUsuariosSiocMails(codSolicitantes, null, null);
		} else if (tipoMensajemail.equalsIgnoreCase("ERROREXCEPTION")) {
			emails = getUsuariosSiocMails("'900','SOPORTE'", null, codSolicitantes);
		}

		EmailDetalle emailDetalle = new EmailDetalle(emails, subject, content);
		emailDetalle.setFrom(correoremitente);

		List<EmailDetalle> EmailDetalleList = (List<EmailDetalle>) UserSessionHolder.get("emailsaenviar");

		if (EmailDetalleList == null) {
			EmailDetalleList = new ArrayList<EmailDetalle>();

		}
		EmailDetalleList.add(emailDetalle);

		UserSessionHolder.set("emailsaenviar", EmailDetalleList);

		return emailDetalle;
	}
}
