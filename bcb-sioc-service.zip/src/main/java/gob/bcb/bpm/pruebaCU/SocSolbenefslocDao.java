package gob.bcb.bpm.pruebaCU;

import gob.bcb.service.exception.BusinessException;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class SocSolbenefslocDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocSolbenefslocDao.class);

	public void saveOrUpdate(SocSolbenefsloc pm) {
		if (StringUtils.isBlank(pm.getId().getBenCodigo())){
			throw new BusinessException("codigo de beneficiario nulo");			
		}
		if (StringUtils.isBlank(pm.getId().getSolCodigo())){
			throw new BusinessException("codigo de solicitante nulo");			
		}		
		pm.setFechaHora(new Date());
		this.getHibernateTemplate().saveOrUpdate(pm);
	}
	public SocSolbenefsloc getSocSolbeneflocByCodigo(String solCodigo, String benCodigo) {
		log.debug("Entre a buscar getSocSolbenefslocByCodigo id: " + solCodigo);

		SocSolbenefsloc benefs = null;
		
		@SuppressWarnings("unchecked")
		List lista = getSocSolbenefslocByCodigo(solCodigo, benCodigo);

		if (lista.size() > 0) {
			benefs = (SocSolbenefsloc) lista.get(0);
		}

		return benefs;
	}
	public List<SocSolbenefsloc> getSocSolbenefslocByCodigo(String solCodigo, String benCodigo) {
		log.debug("Entre a buscar getSocSolbenefslocByCodigo id: " + solCodigo + " " + benCodigo);

		StringBuffer query = new StringBuffer();
		query = query.append("select be ");
		query = query.append("from SocSolbenefsloc be ");
		query = query.append("where be.claVigente is not null ");
		
		if (!StringUtils.isBlank(solCodigo)) {
			query = query.append("and be.id.solCodigo = :solCodigo ");			
		}
		if (!StringUtils.isBlank(benCodigo)) {
			query = query.append("and be.id.benCodigo = :benCodigo ");			
		}
		Query consulta = getSession().createQuery(query.toString());

		if (!StringUtils.isBlank(solCodigo)) {
			consulta.setParameter("solCodigo", solCodigo);			
		}
		if (!StringUtils.isBlank(benCodigo)) {
			consulta.setParameter("benCodigo", benCodigo);			
		}
		
		@SuppressWarnings("unchecked")
		List lista = consulta.list();
		return lista;
		
	}

}
