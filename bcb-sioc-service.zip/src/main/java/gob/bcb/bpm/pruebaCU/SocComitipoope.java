package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the soc_comitipoope database table.
 * 
 */
@Entity
@Table(name="soc_comitipoope")
public class SocComitipoope implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SocComitipoopePK id;

	@Column(name="cla_tipocargo")
	private String claTipocargo;

	@Column(name="cod_moneda")
	private String codMoneda;

	@Column(name="descrip")
	private String descrip;
	
	private BigDecimal valor;

    public SocComitipoope() {
    }

	public SocComitipoopePK getId() {
		return this.id;
	}

	public void setId(SocComitipoopePK id) {
		this.id = id;
	}
	
	public String getClaTipocargo() {
		return this.claTipocargo;
	}

	public void setClaTipocargo(String claTipocargo) {
		this.claTipocargo = claTipocargo;
	}

	public String getCodMoneda() {
		return this.codMoneda;
	}

	public void setCodMoneda(String codMoneda) {
		this.codMoneda = codMoneda;
	}

	public BigDecimal getValor() {
		return this.valor;
	}

	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}

	
	public String toString() {
		return "SocComitipoope [id=" + id + ", claTipocargo=" + claTipocargo + ", codMoneda=" + codMoneda + ", valor=" + valor + "]";
	}

	public String getDescrip() {
		return descrip;
	}

	public void setDescrip(String descrip) {
		this.descrip = descrip;
	}

}
