package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the soc_comitipoope database table.
 * 
 */
@Entity
@Table(name="soc_comitipoope")
public class SocComitipoope implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SocComitipoopePK id;

	@Column(name="cla_comisionopecomi")
	private String claComisionopecomi;
	
	@Column(name="cla_tipocargo")
	private String claTipocargo;

	@Column(name="cod_moneda")
	private Integer codMoneda;

	@Column(name="descrip")
	private String descrip;
	
	@Column(name="cla_cuenta")
	private String claCuenta;
	
	@Column(name="sct_tipocuenta")
	private String sctTipocuenta;

	@Column(name="cla_comisvarfact")
	private String claComisvarfact;
	
	@Column(name="cla_formapago")
	private String claFormapago;	
	
	@Column(name="cla_operacion")
	private String claOperacion;
	
	private BigDecimal valor;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "com_auditfho")
	private Date comAuditfho;

	@Column(name = "com_auditusr")
	private String comAuditusr;

	@Column(name = "com_auditwst")
	private String comAuditwst;
	
    public SocComitipoope() {
    }

	public SocComitipoopePK getId() {
		return this.id;
	}

	public void setId(SocComitipoopePK id) {
		this.id = id;
	}
	
	public String getClaTipocargo() {
		return this.claTipocargo;
	}

	public void setClaTipocargo(String claTipocargo) {
		this.claTipocargo = claTipocargo;
	}

	public Integer getCodMoneda() {
		return this.codMoneda;
	}

	public void setCodMoneda(Integer codMoneda) {
		this.codMoneda = codMoneda;
	}

	public BigDecimal getValor() {
		return this.valor;
	}

	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}

	public String getDescrip() {
		return descrip;
	}

	public void setDescrip(String descrip) {
		this.descrip = descrip;
	}

	public String getClaCuenta() {
		return claCuenta;
	}

	public void setClaCuenta(String claCuenta) {
		this.claCuenta = claCuenta;
	}

	public String getSctTipocuenta() {
		return sctTipocuenta;
	}

	public void setSctTipocuenta(String sctTipocuenta) {
		this.sctTipocuenta = sctTipocuenta;
	}

	public String getClaComisionopecomi() {
		return claComisionopecomi;
	}

	public void setClaComisionopecomi(String claComisionopecomi) {
		this.claComisionopecomi = claComisionopecomi;
	}

	public String getClaComisvarfact() {
		return claComisvarfact;
	}

	public void setClaComisvarfact(String claComisvarfact) {
		this.claComisvarfact = claComisvarfact;
	}

	public String getClaFormapago() {
		return claFormapago;
	}

	public void setClaFormapago(String claFormapago) {
		this.claFormapago = claFormapago;
	}

	public Date getComAuditfho() {
		return comAuditfho;
	}

	public void setComAuditfho(Date comAuditfho) {
		this.comAuditfho = comAuditfho;
	}

	public String getComAuditusr() {
		return comAuditusr;
	}

	public void setComAuditusr(String comAuditusr) {
		this.comAuditusr = comAuditusr;
	}

	public String getComAuditwst() {
		return comAuditwst;
	}

	public void setComAuditwst(String comAuditwst) {
		this.comAuditwst = comAuditwst;
	}

	@Override
	public String toString() {
		return "SocComitipoope [id=" + id + ", claComisionopecomi=" + claComisionopecomi + ", claTipocargo=" + claTipocargo + ", codMoneda=" + codMoneda + ", descrip=" + descrip
				+ ", claCuenta=" + claCuenta + ", sctTipocuenta=" + sctTipocuenta + ", claComisvarfact=" + claComisvarfact + ", claFormapago=" + claFormapago + ", valor=" + valor
				+ ", comAuditfho=" + comAuditfho + ", comAuditusr=" + comAuditusr + ", comAuditwst=" + comAuditwst + "]";
	}

	public String getClaOperacion() {
		return claOperacion;
	}

	public void setClaOperacion(String claOperacion) {
		this.claOperacion = claOperacion;
	}

	
}
