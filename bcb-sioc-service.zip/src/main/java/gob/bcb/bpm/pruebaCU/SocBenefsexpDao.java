package gob.bcb.bpm.pruebaCU;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;
@Transactional
public class SocBenefsexpDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocBenefsexpDao.class);

	public List<SocBenefs> findBenefsDelExt(String codSolicitante, String benCodigo, String claEntidad, String ctaNrocuenta, Integer codMoneda) {
		String query = "SELECT bb ";
		query = query.concat("FROM SocBenefsexp bb ");
		query = query.concat("WHERE trim(bb.benNombre) != '' ");

		if (codMoneda != null)
			query = query.concat(
					"and exists (select 1 from SocCuentasexp c where c.benCodigo = bb.benCodigo and c.moneda = :codMoneda ) ");

		if (!StringUtils.isBlank(ctaNrocuenta))
			query = query.concat(
					"and exists (select 1 from SocCuentasexp c where c.benCodigo = bb.benCodigo and upper(c.ctaNrocuenta) like :ctaNrocuenta) ");

		if (!StringUtils.isBlank(claEntidad))
			query = query.concat("AND bb.claEntidad = :claEntidad ");

		query = query.concat("ORDER BY bb.benNombre ");

		Query consulta = getSession().createQuery(query);

		if (codMoneda != null)
			consulta.setParameter("codMoneda", codMoneda);

		if (!StringUtils.isBlank(ctaNrocuenta))
			consulta.setParameter("ctaNrocuenta", "%" + ctaNrocuenta.toUpperCase() + "%");

		if (!StringUtils.isBlank(claEntidad))
			consulta.setParameter("claEntidad", claEntidad);

		List lista = consulta.list();

		if (lista.size() == 0) {
			log.info("Lista sin valores find benef Del Exterior " + ctaNrocuenta + " " + claEntidad + ":: " + query);
		}
		return lista;
	}
	
	public List<Beneficiario> beneficiariosdelExteriorSolicitante(String codSolicitante, String benCodigo, String claEntidad, String ctaNrocuenta, Integer codMoneda) {
		List<SocBenefs> socBenefsLista = findBenefsDelExt(codSolicitante,benCodigo,  claEntidad, ctaNrocuenta, codMoneda);
		List<Beneficiario> beneficiarios = new ArrayList<Beneficiario>();		
		for (SocBenefs socBenefs : socBenefsLista) {
			Beneficiario benefi = new Beneficiario();
			benefi.setBenCodigo(socBenefs.getBenCodigo());
			benefi.setSolCodigo(codSolicitante);
			benefi.setBenNit(socBenefs.getBenNit());
			benefi.setBenFactura(socBenefs.getBenFactura());
			benefi.setBenNombre(socBenefs.getBenNombre());
			benefi.setBenDireccion(socBenefs.getBenDireccion());
			benefi.setBenPlaza(socBenefs.getBenPlaza());
			if (socBenefs.getClaVigente() != null)
				benefi.setClaEntidad(Integer.valueOf(socBenefs.getClaVigente()));

			beneficiarios.add(benefi);			
		}
		return beneficiarios;
	}
}
