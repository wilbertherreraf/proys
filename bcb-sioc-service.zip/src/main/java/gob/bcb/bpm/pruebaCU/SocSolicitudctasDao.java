package gob.bcb.bpm.pruebaCU;

import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.ws.xml.consultasolic.CuentaSolicitud;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;
import gob.bcb.service.servicioTres.model.CuentaMovimiento;
import gob.bcb.service.servicioTres.model.CuentaMovimientoDao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public class SocSolicitudctasDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocSolicitudctasDao.class);

	public void eliminarRegs(String codigo) {
		List<SocSolicitudctas> facts = getCuentas(codigo);
		int i = 0;
		while (facts.size() > 0) {
			SocSolicitudctas fact = facts.get(0);
			this.getHibernateTemplate().delete(fact);
			facts = getCuentas(codigo);
			i++;
		}
		log.info("Eliminados [ " + i + " ] regs.");
	}

	private SocSolicitudctas saveOrUpdate(SocSolicitudctas socSolicitudctas) {
		log.info("salvando SocSolicitudctas " + socSolicitudctas.toString());

		socSolicitudctas.setFechaHora(new Date());

		SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
		socCuentassolDao.setSessionFactory(getSessionFactory());

		validarDato(socSolicitudctas);

		SocCuentassol socCuentassol = socCuentassolDao.getByCtaMovMoneda(socSolicitudctas.getNroCuenta(), socSolicitudctas.getCodMoneda());

		if (socCuentassol == null || StringUtils.isBlank(socCuentassol.getCtaAfectable())) {
			throw new BusinessException("Cuenta inexistente " + socSolicitudctas.getNroCuenta() + " moneda " + socSolicitudctas.getCodMoneda()
					+ " para tipo cuenta " + socSolicitudctas.getId().getTipoCuenta() + " en registros del BCB");
		}

		socSolicitudctas.setCtaAfectable(socCuentassol.getCtaAfectable().trim());

		SocSolicitudctas socSolicitudctasNew = this.getHibernateTemplate().merge(socSolicitudctas);
		return socSolicitudctasNew;
	}

	public List<SocSolicitudctas> getCuentas(String codigo) {
		List<SocSolicitudctas> cuentas = null;

		StringBuilder query = new StringBuilder();

		query.append("select c ");
		query.append("from SocSolicitudctas c ");
		query.append("where c.id.socCodigo = :socCodigo ");

		logger.info("Consulta Cuentas Solicitud para [" + codigo + "] " + query.toString());

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("socCodigo", codigo);

		cuentas = consulta.list();

		return cuentas;
	}

	public List<SocSolicitudctas> getCuentas(String codigo, String tipo, String solCodigo, String nroCuenta, String nroCuentabco, Integer codMoneda,
			String cveTipcuenta) {

		StringBuilder query = new StringBuilder();

		query.append("select c from SocSolicitudctas c ");
		query.append("where c.id.socCodigo = :socCodigo ");

		if (!StringUtils.isBlank(tipo)) {
			query.append("and c.id.tipoCuenta = :tipo ");
		}
		if (!StringUtils.isBlank(solCodigo)) 
			query.append("and c.solCodigo = :solCodigo ");
		if (!StringUtils.isBlank(nroCuenta)) 
			query.append("and c.nroCuenta = :nroCuenta ");
		if (!StringUtils.isBlank(nroCuentabco)) 
			query.append("and c.nroCuentabco = :nroCuentabco ");
		if (codMoneda != null) {
			query.append("and c.codMoneda = :codMoneda ");
		}
		if (!StringUtils.isBlank(cveTipcuenta)) {
			query.append("and c.cveTipcuenta = :cveTipcuenta ");
		}
		log.info("Consultando ctas solicitud " + codigo + " => " + query.toString());
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("socCodigo", codigo);
		if (!StringUtils.isBlank(tipo)) {
			consulta.setParameter("tipo", tipo);
		}
		if (!StringUtils.isBlank(solCodigo)) {
			consulta.setParameter("solCodigo", solCodigo);
		}
		if (!StringUtils.isBlank(nroCuenta)) {
			consulta.setParameter("nroCuenta", nroCuenta);
		}
		if (!StringUtils.isBlank(nroCuentabco)) {
			consulta.setParameter("nroCuentabco", nroCuentabco);
		}
		if (codMoneda != null) {
			consulta.setParameter("codMoneda", codMoneda);
		}
		if (!StringUtils.isBlank(cveTipcuenta)) {
			consulta.setParameter("cveTipcuenta", cveTipcuenta);
		}
		List lista = consulta.list();

		return lista;

	}

	/**
	 * MÃ©todo que permite obtener una cuenta especÃ­fica con la que se procesÃ³
	 * una operaciÃ³n.
	 */

	public SocSolicitudctas getCuenta(String codigo, String tipoCuenta, String solCodigo, String nroCuenta, String nroCuentabco, Integer codMoneda) {
		SocSolicitudctas cuenta = null;

		StringBuilder query = new StringBuilder();

		query.append("select c from SocSolicitudctas c ");
		query.append("where c.id.socCodigo = :socCodigo ");

		if (!StringUtils.isBlank(tipoCuenta)) {
			query.append("and c.id.tipoCuenta = :tipo ");
		}
		if (!StringUtils.isBlank(solCodigo)) {
			query.append("and c.solCodigo = :solCodigo ");
		}
		if (!StringUtils.isBlank(nroCuenta)) {
			query.append("and c.nroCuenta = :nroCuenta ");
		}
		if (!StringUtils.isBlank(nroCuentabco)) {
			query.append("and c.nroCuentabco = :nroCuentabco ");
		}
		if (codMoneda != null) {
			query.append("and c.codMoneda = :codMoneda ");
		}

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("socCodigo", codigo);
		if (!StringUtils.isBlank(tipoCuenta)) {
			consulta.setParameter("tipo", tipoCuenta);
		}
		if (!StringUtils.isBlank(solCodigo)) {
			consulta.setParameter("solCodigo", solCodigo);
		}
		if (!StringUtils.isBlank(nroCuenta)) {
			consulta.setParameter("nroCuenta", nroCuenta);
		}
		if (!StringUtils.isBlank(nroCuentabco)) {
			consulta.setParameter("nroCuentabco", nroCuentabco);
		}
		if (codMoneda != null) {
			consulta.setParameter("codMoneda", codMoneda);
		}
		List lista = consulta.list();
		if (lista.size() == 0) {
			log.debug("Sin registros para getCuenta [solCodigo = " + solCodigo + ", codigo =" + codigo + ", tipo = " + tipoCuenta + ", nroCuenta= "
					+ nroCuenta + "; nroCuentabco=" + nroCuentabco + "; moneda =" + codMoneda + "] " + query.toString());
		}
		if (lista.size() > 0) {
			return (SocSolicitudctas) lista.get(0);
		}

		return cuenta;

	}
	public SocSolicitudctas getCuentaByAfectable(String codigo, String ctaAfectable) {
		SocSolicitudctas cuenta = null;

		StringBuilder query = new StringBuilder();

		query.append("select c from SocSolicitudctas c ");
		query.append("where c.id.socCodigo = :socCodigo ");
		query.append("and c.ctaAfectable = :ctaAfectable ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("socCodigo", codigo);
		consulta.setParameter("ctaAfectable", ctaAfectable);
		List lista = consulta.list();
		
		if (lista.size() > 0) {
			return (SocSolicitudctas) lista.get(0);
		}

		return cuenta;
	}

	public SocSolicitudctas nuevo(String socCodigo, String tipo, Integer codMoneda, String descripLibreta, String nroCuenta, String nroLibreta,
			String codBanco, String nroCuentabco, String solCodigo, String cveTipcuenta, String cveTipocomis, String ctaAfectable) {

		SocSolicitudctas socSolicitudctas = getCuenta(socCodigo, tipo, null, null, null, null);

		if (socSolicitudctas == null) {

			SocSolicitudctasPK socSolicitudctasPK = new SocSolicitudctasPK();
			socSolicitudctasPK.setSocCodigo(socCodigo);
			socSolicitudctasPK.setTipoCuenta(tipo);

			socSolicitudctas = new SocSolicitudctas();
			socSolicitudctas.setId(socSolicitudctasPK);
		}

		socSolicitudctas.setNroCuenta((nroCuenta != null ? nroCuenta.trim() : null));
		socSolicitudctas.setCodMoneda(codMoneda);
		socSolicitudctas.setNroLibreta((nroLibreta != null ? nroLibreta.trim() : null));
		socSolicitudctas.setDescripLibreta(descripLibreta);
		socSolicitudctas.setNroCuentabco((nroCuentabco != null ? nroCuentabco.trim() : null));
		socSolicitudctas.setCodBanco(codBanco);
		socSolicitudctas.setSolCodigo((solCodigo != null ? solCodigo.trim() : null));
		socSolicitudctas.setCveTipcuenta(cveTipcuenta);
		socSolicitudctas.setCveTipocomis(cveTipocomis);
		socSolicitudctas.setCtaAfectable((ctaAfectable != null ? ctaAfectable.trim() : null));

		return socSolicitudctas;
	}

	public void crearSolicitudctasLista(SocSolicitudes socSolicitudes, List<SocSolicitudctas> socSolicitudctasLista,
			List<SocDetallessol> socDetallessolLista) {
		if (socSolicitudctasLista == null) {
			throw new BusinessException("Lista parametro SocSolicitudctas nulo");
		}
		eliminarRegs(socSolicitudes.getSocCodigo());
		log.info("crear Solicitudctas Lista " + socSolicitudctasLista.size());

		SocSolicitudctas socSolicitudctasBENEFMT = null;
		for (SocSolicitudctas socSolicitudctas : socSolicitudctasLista) {
			if (StringUtils.isBlank(socSolicitudctas.getId().getTipoCuenta())
					|| (StringUtils.isBlank(socSolicitudctas.getNroCuenta()) && StringUtils.isBlank(socSolicitudctas.getNroLibreta()))) {
				continue;
			}
			log.info("TipoCuenta: " + socSolicitudctas.getId().getTipoCuenta() + " " + socSolicitudctas.getCveTipocomis());
			if (socSolicitudctas.getId() != null && socSolicitudctas.getId().getTipoCuenta() != null
					&& socSolicitudctas.getId().getTipoCuenta().equals(Constants.COD_CLAVE_BENEFMT)) {

				socSolicitudctasBENEFMT = completarTipoCtaBenefMT(socSolicitudes, socSolicitudctas);

			} else {
				crearCuentaSolicitud(socSolicitudes, socSolicitudctas, socDetallessolLista);
			}
		}

		if (socSolicitudctasBENEFMT == null)
			completarTipoCtaBenefMT(socSolicitudes, null);
	}

	private void crearCuentaSolicitud(SocSolicitudes socSolicitudes, SocSolicitudctas socSolicitudctas, List<SocDetallessol> socDetallessolLista) {
		log.info("Ingresando a crearCuentaSolicitud " + socSolicitudctas.getId().getTipoCuenta());

		if (socSolicitudctas.getId() == null) {
			throw new BusinessException("Id nulo para objeto socSolicitudctas " + socSolicitudes.getSocCodigo() + " para "
					+ socSolicitudctas.getId().getTipoCuenta() + " avise al administrador ");
		}

		SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
		socSolicitanteDao.setSessionFactory(getSessionFactory());

		SocSolcuentasDao socSolcuentasDao = new SocSolcuentasDao();
		socSolcuentasDao.setSessionFactory(getSessionFactory());

		SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
		socCuentassolDao.setSessionFactory(getSessionFactory());

		// buscamos el solicitante
		SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCod(socSolicitudes.getSolCodigo());

		socSolicitudctas.getId().setSocCodigo(socSolicitudes.getSocCodigo());

		if (StringUtils.isBlank(socSolicitudctas.getNroCuenta()) && StringUtils.isBlank(socSolicitudctas.getNroLibreta())) {
			throw new BusinessException("cuenta movimiento y nro cuenta son nulos para " + socSolicitudctas.getId().getTipoCuenta());
		}

		if (socSolicitudctas.getCodMoneda() == null) {
			throw new BusinessException("Moneda nulo para " + socSolicitudctas.getId().getTipoCuenta());
		}

		if (StringUtils.isBlank(socSolicitudctas.getNroCuenta())) {
			// si no esta registrado la cta movimiento se busca la misma
			List<SocSolcuentas> socSolcuentasLista = socSolcuentasDao.cuentasEnCuentaSolicitante(socSolicitudes.getSolCodigo(), null, null,
					socSolicitudctas.getCodMoneda(), socSolicitudctas.getNroLibreta(), null);

			if (socSolcuentasLista.size() == 0) {
				throw new BusinessException(socSolicitudctas.getId().getTipoCuenta() + ": Nro cuenta " + socSolicitudctas.getNroLibreta() + " ["
						+ socSolicitudctas.getCodMoneda() + "]" + " no registrado para solicitante " + socSolicitante.getSolPersona());
			}

			if (socSolcuentasLista.size() > 1) {
				log.warn("Atencion!! Cuenta duplicadas en socSolcuentas " + socSolicitante.getSolPersona() + " moneda: "
						+ socSolicitudctas.getCodMoneda() + " " + socSolicitudctas.getNroLibreta());

				String ctaAfectable = "";
				int nro = 1;
				for (SocSolcuentas socSolcuentas : socSolcuentasLista) {
					// control que no exista en mas de una entidad la
					// misma cuenta
					SocCuentassol socCuentassol = socCuentassolDao.getByCodigo(socSolcuentas.getId().getCtaCodigo());
					if (nro == 1) {
						ctaAfectable = socCuentassol.getCtaAfectable();
					}

					if (StringUtils.isBlank(socCuentassol.getCtaAfectable())) {
						throw new BusinessException(
								"Cuenta " + socCuentassol.getCtaCodigo() + " parametrizado sin cta afectable, comunique al administrador");
					}

					if (!ctaAfectable.trim().equals(socCuentassol.getCtaAfectable().trim())) {
						throw new BusinessException("Cuenta duplicadas en socSolcuentas solicitante: " + socSolicitante.getSolPersona() + " moneda: "
								+ socSolicitudctas.getCodMoneda() + " nro cta-libreta: " + socSolicitudctas.getNroLibreta());
					}
					nro++;
				}

			}

			SocCuentassol socCuentassol = socCuentassolDao.getByCodigo(socSolcuentasLista.get(0).getId().getCtaCodigo());

			socSolicitudctas.setNroCuenta(socCuentassol.getCtaMovimiento());
			socSolicitudctas.setCtaAfectable(socCuentassol.getCtaAfectable());
		}

		if (StringUtils.isBlank(socSolicitudctas.getNroCuenta())) {
			throw new BusinessException(
					"Cuenta movimiento " + socSolicitudctas.getId().getTipoCuenta() + " nulo para solicitante " + socSolicitante.getSolCodigo());
		}
		// capturamos el codsolicitante de la cta movimiento
		CuentaMovimientoDao cuentaMovimientoDao = new CuentaMovimientoDao();
		cuentaMovimientoDao.setSessionFactory(SiocCoinService.getSessionFactory());

		CuentaMovimiento cuentaMovimiento = cuentaMovimientoDao.getCuentaMovimiento(socSolicitudctas.getNroCuenta());

		if (socSolicitudes.getCveTipctasolic().equals(Constants.CLAVE_GENERADOPOR_SISTEMA)) {
			// si es generado por el sistema siocweb se actualiza
			log.info("Actualizando[ANTES: " + socSolicitudctas.getSolCodigo() + "] Cod solicitante[" + cuentaMovimiento.getCodPersona()
					+ "] para cta [" + socSolicitudctas.getNroCuenta() + "] encontrado");

			socSolicitudctas.setSolCodigo(cuentaMovimiento.getCodPersona().trim());
		} else {
			if (StringUtils.isBlank(socSolicitudctas.getSolCodigo())) {
				socSolicitudctas.setSolCodigo(cuentaMovimiento.getCodPersona().trim());
			}
		}

		if (StringUtils.isBlank(socSolicitudctas.getSolCodigo())) {
			throw new BusinessException(
					"Codigo de solicitante socSolicitudctas.SolCodigo para " + socSolicitudctas.getId().getTipoCuenta() + " nulo");
		}

		// descripcon libreta
		if (!StringUtils.isBlank(socSolicitudctas.getNroLibreta()) && StringUtils.isBlank(socSolicitudctas.getDescripLibreta())) {
			// llenamos el campo descrip libreta
			if (!StringUtils.isBlank(socSolicitudctas.getCveTipocomis())) {
				if (!socSolicitudctas.getSolCodigo().equals(Constants.COD_BCB)) {
					if (socSolicitudctas.getCveTipocomis().equals(Constants.CLAVE_TIPOCOMIS_SOLIC)) {
						// en el bcb no hay libretas
						List<SocSolcuentas> socSolcuentasLista = socSolcuentasDao.cuentasEnCuentaSolicitante(socSolicitudes.getSolCodigo(), null,
								null, socSolicitudctas.getCodMoneda(), socSolicitudctas.getNroLibreta(), null);

						if (socSolcuentasLista.size() == 0) {
							throw new BusinessException(socSolicitudctas.getId().getTipoCuenta() + ": Nro cuenta " + socSolicitudctas.getNroLibreta()
									+ " [" + socSolicitudctas.getCodMoneda() + "]" + " no registrado para solicitante "
									+ socSolicitante.getSolPersona());
						}

						socSolicitudctas.setDescripLibreta(socSolcuentasLista.get(0).getCtaNombre());

					} else if (socSolicitudctas.getCveTipocomis().equals(Constants.CLAVE_TIPOCOMIS_BENEF)) {
						if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRACTA)) {
							SocBenefsDao socBenefsDao = new SocBenefsDao();
							socBenefsDao.setSessionFactory(getSessionFactory());

							if (socDetallessolLista.size() == 1) {
								List<CuentasBen> listaCuentasB = socBenefsDao.recuperarCuentasB(socSolicitudes,
										socDetallessolLista.get(0).getBenCodigo(), socSolicitudctas.getCodMoneda(), null,
										socSolicitudctas.getNroLibreta(), null, null);

								if (listaCuentasB.size() == 0) {
									throw new BusinessException(socSolicitudctas.getId().getTipoCuenta() + ": Nro cuenta "
											+ socSolicitudctas.getNroLibreta() + " [" + socSolicitudctas.getCodMoneda() + "]"
											+ " no registrado para beneficiario " + socDetallessolLista.get(0).getBenCodigo());
								}
								socSolicitudctas.setDescripLibreta(listaCuentasB.get(0).getBenNombre());
							}
						}
						if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRADELEXT)) {
							SocBenefsDao socBenefsDao = new SocBenefsDao();
							socBenefsDao.setSessionFactory(getSessionFactory());
							
							List<CuentasBen> listaCuentasB = socBenefsDao.recuperarCuentasB(socSolicitudes,
									socDetallessolLista.get(0).getBenCodigo(), socSolicitudctas.getCodMoneda(), null,
									socSolicitudctas.getNroLibreta(), null, socSolicitudctas.getCtaAfectable());
							if (listaCuentasB.size() == 1) {
								socSolicitudctas.setDescripLibreta(listaCuentasB.get(0).getBenNombre());
							}
							
						}
					}

				}

			}
		}

		socSolicitudctas.setCodUsuario(socSolicitudes.getUsrCodigo());
		socSolicitudctas.setEstacion(socSolicitudes.getEstacion());

		SocSolicitudctas socSolicitudctasNew = saveOrUpdate(socSolicitudctas);

		if (socSolicitudctasNew.getSolCodigo() != null) {
			if (!socSolicitudctasNew.getSolCodigo().equals(Constants.COD_BCB)) {
				if (!socSolicitante.getSolCodigo().trim().equals(socSolicitudctasNew.getSolCodigo().trim())) {
					// la cuenta pertenece a otra entidad
					if (StringUtils.isBlank(socSolicitudctasNew.getNroLibreta())) {
						// control libretas: si la cta es afectable del sigma
						// debe
						// tener
						// libreta si la cta es fiscal debe tener cuenta
						if (socSolicitante.getClaEntidad().equals(Constants.CLAVE_CLAENTIDAD_SISTPUBLICO)) {

							Boolean afectSigma = cuentaMovimientoDao.IsAfectableSigma(socSolicitudctasNew.getCtaAfectable());

							if (afectSigma && socSolicitudctasNew.getNroCuenta().equals(Constants.CTA_CUT)
									&& !socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS)) {
								throw new BusinessException(socSolicitudctasNew.getId().getTipoCuenta() + ": Cuenta "
										+ socSolicitudctasNew.getNroCuenta() + " [" + socSolicitudctasNew.getCodMoneda() + "]"
										+ " con afectable sigma, no registra nro de libreta para solicitante  " + socSolicitante.getSolPersona());
							}
						}
						log.info("XXX: socSolicitante.getSolCodigo()" + socSolicitante.getSolCodigo() + " socSolicitudctasNew.getSolCodigo() "
								+ socSolicitudctasNew.getSolCodigo());
						SocSolicitante socSolicitanteCta = socSolicitanteDao.solicitanteByCodigo(socSolicitudctasNew.getSolCodigo());

						if (socSolicitanteCta != null) {
							if (socSolicitanteCta.getClaEntidad() == null) {
								throw new BusinessException("Solicitante " + socSolicitudctasNew.getSolCodigo()
										+ " no registra tipo de entidad, comunique al administrador.");
							}

							if (socSolicitanteCta.getClaEntidad().equals(Constants.CLAVE_CLAENTIDAD_SISTFINANCIERO)) {
								throw new BusinessException(socSolicitudctasNew.getId().getTipoCuenta() + ": Cuenta "
										+ socSolicitudctasNew.getNroCuenta() + " [" + socSolicitudctasNew.getCodMoneda() + "]"
										+ " del sistema financiero, no registra nro de cuenta para solicitante  " + socSolicitante.getSolPersona());

							}
						}
					}
				}
			}
		}
	}

	public SocSolicitudctas fromServicioSiocCta(SocSolicitudes socSolicitudes, CuentaSolicitud cuentaSolicitud) {
		log.info("Mapeando ctas solicitud de ServicioSioc " + cuentaSolicitud.getTipoCuenta());

		SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
		socSolicitanteDao.setSessionFactory(getSessionFactory());

		SocSolcuentasDao socSolcuentasDao = new SocSolcuentasDao();
		socSolcuentasDao.setSessionFactory(getSessionFactory());

		if (StringUtils.isBlank(cuentaSolicitud.getTipoCuenta())) {
			throw new BusinessException("tipo cuenta invalida, revise los datos");
		}

		if (StringUtils.isBlank(cuentaSolicitud.getCodMonedaCta())) {
			throw new BusinessException("Moneda invalida en tipo cuenta " + cuentaSolicitud.getTipoCuenta());
		}

		if (!NumberUtils.isNumber(cuentaSolicitud.getCodMonedaCta())) {
			throw new BusinessException("Valor Moneda invalida en tipo cuenta " + cuentaSolicitud.getTipoCuenta() + " no es numero");
		}

		Integer codMoneda = Integer.valueOf(cuentaSolicitud.getCodMonedaCta());
		SocSolicitante socSolicitanteCta = socSolicitanteDao.solicitanteByCodSigep(cuentaSolicitud.getCodBanco());

		SocSolicitudctasPK socSolicitudctasPK = new SocSolicitudctasPK();
		socSolicitudctasPK.setSocCodigo(socSolicitudes.getSocCodigo());
		socSolicitudctasPK.setTipoCuenta(cuentaSolicitud.getTipoCuenta());

		SocSolicitudctas socSolicitudctas = new SocSolicitudctas();
		socSolicitudctas.setId(socSolicitudctasPK);

		socSolicitudctas.setCodMoneda(codMoneda);
		socSolicitudctas.setCveTipcuenta("S");
		socSolicitudctas.setDescripLibreta(cuentaSolicitud.getDescripcionLibreta());
		socSolicitudctas.setCodBanco(cuentaSolicitud.getCodBanco());
		socSolicitudctas.setCveTipocomis(cuentaSolicitud.getAsumeComision());

		if (socSolicitanteCta.getSolCodigo().trim().equals(Constants.COD_BCB)) {
			// en el proceso crearCuentaSolicitud se llenara codigo
			// socSolicitudctas.setSolCodigo
			socSolicitudctas.setNroCuenta(cuentaSolicitud.getNroCuenta());
			socSolicitudctas.setNroLibreta(cuentaSolicitud.getNroLibreta());

			if (!StringUtils.isBlank(socSolicitudctas.getNroLibreta())) {
				// registramos el nro de cta libreta del solicitante
				SocSolcuentas socSolcuentas = new SocSolcuentas();
				socSolcuentas.setCtaNumero(socSolicitudctas.getNroLibreta());
				socSolcuentas.setCtaNombre(socSolicitudctas.getDescripLibreta());

				socSolcuentasDao.registrarCtaSolicitante(socSolicitudes, socSolcuentas, socSolicitudctas.getNroCuenta(), null,
						socSolicitudctas.getCodMoneda());
			}
		} else {
			// es cuenta sigma o una cuenta de un bco comercial
			socSolicitudctas.setNroLibreta(cuentaSolicitud.getNroCuenta());
			// solo se registra si es una entidad diferente al BCB
			socSolicitudctas.setSolCodigo(socSolicitanteCta.getSolCodigo());

			if (!StringUtils.isBlank(socSolicitudctas.getNroLibreta())) {

				if (socSolicitanteCta.getClaEntidad().equals(Constants.CLAVE_CLAENTIDAD_SISTFINANCIERO)) {
					// se asume que es un cta fiscal
					if (socSolicitanteCta.getSolCodigo().trim().equals(Constants.COD_IFA_BUSA)) {
						// insertamos el numero de cuenta fiscal
						socSolicitudctas.setNroCuenta(Constants.CTA_FISCAL);

						SocSolcuentas socSolcuentas = new SocSolcuentas();
						socSolcuentas.setCtaNumero(socSolicitudctas.getNroLibreta());
						socSolcuentas.setCtaNombre(socSolicitudctas.getDescripLibreta());

						socSolcuentasDao.registrarCtaSolicitante(socSolicitudes, socSolcuentas, socSolicitudctas.getNroCuenta(), null,
								socSolicitudctas.getCodMoneda());
					}
				}
			}

		}

		return socSolicitudctas;
	}

	public List<SocSolicitudctas> fromServicioSiocCtas(SocSolicitudes socSolicitudes, List<CuentaSolicitud> cuentaSolicitudLista) {
		log.info("Mapeando ctas solicitud Lista de ServicioSioc regs. " + cuentaSolicitudLista.size());
		List<SocSolicitudctas> socSolicitudctasLista = new ArrayList<SocSolicitudctas>();
		for (CuentaSolicitud cuentaSolicitud : cuentaSolicitudLista) {
			SocSolicitudctas socSolicitudctas = fromServicioSiocCta(socSolicitudes, cuentaSolicitud);
			socSolicitudctasLista.add(socSolicitudctas);
		}
		return socSolicitudctasLista;
	}

	public void completarCtasMovDestino(SocSolicitudes socSolicitudes) {
		log.info("Completando cuentas solicitud: " + socSolicitudes.getSocCodigo() + " " + socSolicitudes.getCveTipctasolic());
		SocSolicitudctas socSolicitudctasMOVPROV = getCuenta(socSolicitudes.getSocCodigo(), Constants.COD_CLAVE_MOVPROVISION, null, null, null, null);

		if (socSolicitudctasMOVPROV == null) {
			throw new BusinessException("Solicitud no registra Cuenta MOVPROVISION, cod solicitud EsqCodigo: " + socSolicitudes.getEsqCodigo());
		}
		SocEsquemasDao socEsquemasDao = new SocEsquemasDao();
		socEsquemasDao.setSessionFactory(getSessionFactory());

		SocRengesqDao socRengesqDao = new SocRengesqDao();
		socRengesqDao.setSessionFactory(getSessionFactory());

		// las ctas de transitorias de comisiones todos deben tener
		// cuenta transitoria de comisines BS
		SocSolicitudctas socSolicitudctas = null;

		// control de cuenta gasots y comisiones
		SocSolicitudctas socSolicitudctasCOMGADM = getCuenta(socSolicitudes.getSocCodigo(), Constants.COD_CLAVE_COMGADM, null, null, null, null);

		if (socSolicitudctasCOMGADM == null) {
			if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRADELEXT)) {
				List<SocRengesq> socRengesqLista = socRengesqDao.obtenerEsquemaByDefinicion(socSolicitudes.getEsqCodigo(), null, null, null,
						Constants.COD_CLAVE_DIFCAMB);
				if (socRengesqLista.size() > 0) {
					throw new BusinessException("Solicitud TD no registra Cuenta COMGADM, cod solicitud EsqCodigo: " + socSolicitudes.getEsqCodigo());
				}
			} else 
				throw new BusinessException("Solicitud no registra Cuenta COMGADM, cod solicitud EsqCodigo: " + socSolicitudes.getEsqCodigo());
		}

		// si no existe la cuenta por diferencial cambiario se considera el
		// de comisiones y gastos

		List<SocRengesq> socRengesqLista = socRengesqDao.obtenerEsquemaByDefinicion(socSolicitudes.getEsqCodigo(), null, null, null,
				Constants.COD_CLAVE_DIFCAMB);

		if (socRengesqLista.size() > 0) {
			// existe cta de diferencial cambiario
			if (socSolicitudes.getCveTipctasolic().equals(Constants.CLAVE_GENERADOPOR_SISTEMA)) {
				if (socSolicitudctasCOMGADM == null)
					throw new BusinessException("DIFCAMB: Solicitud requiere cta COMGADM, solicitud EsqCodigo: " + socSolicitudes.getEsqCodigo());
				
				// si es generado por el sistema siempre se actualiza
				SocSolicitudctas socSolicitudctasDIFCAMB = nuevo(socSolicitudes.getSocCodigo(), Constants.COD_CLAVE_DIFCAMB,
						socSolicitudctasCOMGADM.getCodMoneda(), socSolicitudctasCOMGADM.getDescripLibreta(), socSolicitudctasCOMGADM.getNroCuenta(),
						socSolicitudctasCOMGADM.getNroLibreta(), socSolicitudctasCOMGADM.getCodBanco(), socSolicitudctasCOMGADM.getNroCuentabco(),
						socSolicitudctasCOMGADM.getSolCodigo(), socSolicitudctasCOMGADM.getCveTipcuenta(), socSolicitudctasCOMGADM.getCveTipocomis(),
						socSolicitudctasCOMGADM.getCtaAfectable());

				socSolicitudctasDIFCAMB.setCodUsuario(socSolicitudes.getUsrCodigo());
				socSolicitudctasDIFCAMB.setEstacion(socSolicitudes.getEstacion());

				saveOrUpdate(socSolicitudctasDIFCAMB);

			} else {
				socSolicitudctas = getCuenta(socSolicitudes.getSocCodigo(), Constants.COD_CLAVE_DIFCAMB, null, null, null, null);
				if (socSolicitudctas == null) {
					if (socSolicitudctasCOMGADM == null)
						throw new BusinessException("DIFCAMB: Solicitud requiere Cuenta COMGADM, solicitud EsqCodigo: " + socSolicitudes.getEsqCodigo());
					
					SocSolicitudctas socSolicitudctasDIFCAMB = nuevo(socSolicitudes.getSocCodigo(), Constants.COD_CLAVE_DIFCAMB,
							socSolicitudctasCOMGADM.getCodMoneda(), socSolicitudctasCOMGADM.getDescripLibreta(),
							socSolicitudctasCOMGADM.getNroCuenta(), socSolicitudctasCOMGADM.getNroLibreta(), socSolicitudctasCOMGADM.getCodBanco(),
							socSolicitudctasCOMGADM.getNroCuentabco(), socSolicitudctasCOMGADM.getSolCodigo(),
							socSolicitudctasCOMGADM.getCveTipcuenta(), socSolicitudctasCOMGADM.getCveTipocomis(),
							socSolicitudctasCOMGADM.getCtaAfectable());

					socSolicitudctasDIFCAMB.setCodUsuario(socSolicitudes.getUsrCodigo());
					socSolicitudctasDIFCAMB.setEstacion(socSolicitudes.getEstacion());

					saveOrUpdate(socSolicitudctasDIFCAMB);
				}
			}

		}

		socRengesqLista = socRengesqDao.obtenerEsquemaByDefinicion(socSolicitudes.getEsqCodigo(), null, null, null, Constants.CLAVE_CLACTA_COMTRANS);

		if (socRengesqLista.size() > 0) {
			// la operacion tiene comisiones por transferencia
			// si no existe la cta de comisines por transferencia
			if (socSolicitudes.getCveTipctasolic().equals(Constants.CLAVE_GENERADOPOR_SISTEMA)) {
				// si es generado por el sistema siempre se actualiza
				socSolicitudctas = getCuenta(socSolicitudes.getSocCodigo(), Constants.COD_CLAVE_COMCTRA, null, null, null, null);

				if (socSolicitudctas == null) {
					if (socSolicitudctasCOMGADM == null)
						throw new BusinessException("COMCTRA: Solicitud requiere cta COMGADM, solicitud EsqCodigo: " + socSolicitudes.getEsqCodigo());
					
					SocSolicitudctas socSolicitudctasCOMCTRA = nuevo(socSolicitudes.getSocCodigo(), Constants.COD_CLAVE_COMCTRA,
							socSolicitudctasCOMGADM.getCodMoneda(), socSolicitudctasCOMGADM.getDescripLibreta(),
							socSolicitudctasCOMGADM.getNroCuenta(), socSolicitudctasCOMGADM.getNroLibreta(), socSolicitudctasCOMGADM.getCodBanco(),
							socSolicitudctasCOMGADM.getNroCuentabco(), socSolicitudctasCOMGADM.getSolCodigo(),
							socSolicitudctasCOMGADM.getCveTipcuenta(), socSolicitudctasCOMGADM.getCveTipocomis(),
							socSolicitudctasCOMGADM.getCtaAfectable());

					socSolicitudctasCOMCTRA.setCodUsuario(socSolicitudes.getUsrCodigo());
					socSolicitudctasCOMCTRA.setEstacion(socSolicitudes.getEstacion());

					saveOrUpdate(socSolicitudctasCOMCTRA);
				}
			} else {
				socSolicitudctas = getCuenta(socSolicitudes.getSocCodigo(), Constants.COD_CLAVE_COMCTRA, null, null, null, null);

				if (socSolicitudctas == null) {
					if (socSolicitudctasCOMGADM == null)
						throw new BusinessException("COMCTRA: Solicitud requiere Cuenta COMGADM, solicitud EsqCodigo: " + socSolicitudes.getEsqCodigo());
					
					SocSolicitudctas socSolicitudctasCOMCTRA = nuevo(socSolicitudes.getSocCodigo(), Constants.COD_CLAVE_COMCTRA,
							socSolicitudctasCOMGADM.getCodMoneda(), socSolicitudctasCOMGADM.getDescripLibreta(),
							socSolicitudctasCOMGADM.getNroCuenta(), socSolicitudctasCOMGADM.getNroLibreta(), socSolicitudctasCOMGADM.getCodBanco(),
							socSolicitudctasCOMGADM.getNroCuentabco(), socSolicitudctasCOMGADM.getSolCodigo(),
							socSolicitudctasCOMGADM.getCveTipcuenta(), socSolicitudctasCOMGADM.getCveTipocomis(),
							socSolicitudctasCOMGADM.getCtaAfectable());

					socSolicitudctasCOMCTRA.setCodUsuario(socSolicitudes.getUsrCodigo());
					socSolicitudctasCOMCTRA.setEstacion(socSolicitudes.getEstacion());

					saveOrUpdate(socSolicitudctasCOMCTRA);
				}
				log.info("salvado COMCTRA " + socSolicitudctas.getId().getTipoCuenta() + " " + socSolicitudctas.getCveTipocomis());
			}
		}
	}

	public void validarCuentas(SocSolicitudes socSolicitudes) {
		log.info("Validando cuentas " + socSolicitudes.getSocCodigo());
		SocRengesqDao socRengesqDao = new SocRengesqDao();
		socRengesqDao.setSessionFactory(getSessionFactory());

		List<SocRengesq> socRengesqLista = socRengesqDao.obtenerEsquemaByDefinicion(socSolicitudes.getEsqCodigo(), null, null, null, null);
		for (SocRengesq socRengesq : socRengesqLista) {

			SocSolicitudctas socSolicitudctas = null;
			boolean controla = false;
			if (socRengesq.getClaCuenta().equals(Constants.COD_CLAVE_MOVPROVISION)) {
				controla = true;
				socSolicitudctas = getCuenta(socSolicitudes.getSocCodigo(), socRengesq.getClaCuenta(), null, null, null, null);

				if (socSolicitudctas != null) {
					if (socSolicitudes.getClaTipo().equals(Constants.CLAVE_TIPOOPER_VENTA)) {
						// control de cuenta debito para venta, la misma debe
						// esta
						// en
						// bolivianos
						if (socSolicitudctas.getCodMoneda().compareTo(Constants.COD_MONEDA_BS) != 0) {
							throw new BusinessException(
									"Operacion de Venta de divisas Cuenta MOVPROVISION en moneda invalida " + socSolicitudctas.getCodMoneda());
						}
					}
				}
			}

			if (socRengesq.getClaCuenta().equals(Constants.COD_CLAVE_COMGADM) || socRengesq.getClaCuenta().equals(Constants.COD_CLAVE_DIFCAMB)) {

				socSolicitudctas = getCuenta(socSolicitudes.getSocCodigo(), socRengesq.getClaCuenta(), null, null, null, null);
				controla = true;
			}

			if (controla && socSolicitudctas == null) {
				throw new BusinessException(
						"Solicitud no registra Cuenta " + socRengesq.getClaCuenta() + "[Tipo Oper: " + socSolicitudes.getEsqCodigo() + "]");
			}

		}

	}

	public void validarDato(SocSolicitudctas socSolicitudctas) {
		if (StringUtils.isBlank(socSolicitudctas.getNroCuenta())) {
			throw new BusinessException("Cuenta Afectable nulo  para " + socSolicitudctas.getId().getTipoCuenta());
		}

		if (socSolicitudctas.getCodMoneda() == null) {
			throw new BusinessException("Moneda nulo  para " + socSolicitudctas.getId().getTipoCuenta());
		}

		if (StringUtils.isBlank(socSolicitudctas.getSolCodigo())) {
			throw new BusinessException(
					"Codigo de solicitante socSolicitudctas.SolCodigo para " + socSolicitudctas.getId().getTipoCuenta() + " nulo");
		}

	}

	public SocSolicitudctas completarTipoCtaBenefMT(SocSolicitudes socSolicitudes, SocSolicitudctas socSolicitudctasBENEFMt) {

		// crea en SocSolicitudctas la cuenta del beneficiario BENEFMT para TE
		SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
		socCuentassolDao.setSessionFactory(getSessionFactory());

		SocCuentasDao socCuentasDao = new SocCuentasDao();
		socCuentasDao.setSessionFactory(getSessionFactory());

		log.info("En completarTipoCtaBenefMT " + socSolicitudes.getSocCodigo() + " " + socSolicitudes.getCveSubtipooper());
		SocSolicitudctas socSolicitudctasBENEFMT = null;
		if ((socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT))) {
			log.info("Completando cta BENEFMT  " + socSolicitudes.getSocCodigo());

			if (socSolicitudctasBENEFMt != null && socSolicitudctasBENEFMt.getId() != null
					&& !StringUtils.isBlank(socSolicitudctasBENEFMt.getCtaAfectable())) {

				if (!StringUtils.isBlank(socSolicitudctasBENEFMt.getId().getTipoCuenta())
						&& socSolicitudctasBENEFMt.getId().getTipoCuenta().equals(Constants.COD_CLAVE_BENEFMT)) {

					SocCuentassol socCuentassol = socCuentassolDao.getByAfectable(socSolicitudctasBENEFMt.getCtaAfectable());
					if (socCuentassol != null) {

						socSolicitudctasBENEFMT = nuevo(socSolicitudes.getSocCodigo(), Constants.COD_CLAVE_BENEFMT, socCuentassol.getMoneda(),
								socCuentassol.getCtaNommovimiento(), socCuentassol.getCtaMovimiento(), socSolicitudctasBENEFMt.getNroLibreta(),
								socSolicitudctasBENEFMt.getCodBanco(), socSolicitudctasBENEFMt.getNroCuentabco(), Constants.COD_BCB, "C", "T",
								socSolicitudctasBENEFMt.getCtaAfectable());
					}
				}
			}

			if (socSolicitudctasBENEFMT == null) {

				// existen las cuentas en soccuentas y soccuentassol
				SocCuentas socCuentas = socCuentassolDao.getSocCuentaBanqueroExt(socSolicitudes, socSolicitudes.getCodMonedat(), null);
				if (socCuentas == null) {
					socCuentas = new SocCuentas();
				}

				SocCuentassol socCuentassol = socCuentassolDao.getSocCuentasolBanqueroExt(socSolicitudes, socSolicitudes.getCodMonedat(),
						socCuentas.getCtaAfectable());

				if (socCuentassol != null) {
					// if
					// ((socSolicitudes.getSocTipnegociacion().equals(Constants.CLAVE_TIPNEGOCIA_NORMAL)))
					// {
					// la solicitud es sin negociacion
					socSolicitudctasBENEFMT = nuevo(socSolicitudes.getSocCodigo(), Constants.COD_CLAVE_BENEFMT, socCuentassol.getMoneda(),
							socCuentassol.getCtaNommovimiento(), socCuentassol.getCtaMovimiento(), socCuentas.getCtaNrocuenta(),
							socCuentas.getBcoCodigo(), null, Constants.COD_BCB, "C", "T", socCuentassol.getCtaAfectable());

					// } else if
					// ((socSolicitudes.getSocTipnegociacion().equals(Constants.CLAVE_TIPNEGOCIA_OPER)))
					// {
					// la solicitud puede es q es con negociacion mayor al
					// limite

					// }

				} else {
					// no existe la cuenta de la moneda
					if (socSolicitudes.getSocTipnegociacion().equals(Constants.CLAVE_TIPNEGOCIA_OPER)) {
						// es en otras monedas por defecto se registra en USD
						socCuentassol = socCuentassolDao.getSocCuentasolBanqueroExt(socSolicitudes, Constants.COD_MONEDA_USD, null);
						socCuentas = socCuentassolDao.getSocCuentaBanqueroExt(socSolicitudes, Constants.COD_MONEDA_USD,
								socCuentassol.getCtaAfectable());

						socSolicitudctasBENEFMT = nuevo(socSolicitudes.getSocCodigo(), Constants.COD_CLAVE_BENEFMT, socCuentassol.getMoneda(),
								socCuentassol.getCtaNommovimiento(), socCuentassol.getCtaMovimiento(), socCuentas.getCtaNrocuenta(),
								socCuentas.getBcoCodigo(), null, Constants.COD_BCB, "C", "T", socCuentassol.getCtaAfectable());

					}
				}
			}

			if (socSolicitudctasBENEFMT != null) {
				socSolicitudctasBENEFMT.setCodUsuario(socSolicitudes.getUsrCodigo());
				socSolicitudctasBENEFMT.setEstacion(socSolicitudes.getEstacion());

				saveOrUpdate(socSolicitudctasBENEFMT);

				socSolicitudctasBENEFMT = getCuenta(socSolicitudes.getSocCodigo(), Constants.COD_CLAVE_BENEFMT, null, null, null, null);
			}
		}

		return socSolicitudctasBENEFMT;
	}
}
