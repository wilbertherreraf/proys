package gob.bcb.bpm.pruebaCU;

import gob.bcb.service.exception.BusinessException;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public class SocCuentaslocDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocCuentaslocDao.class);

	public void guardar(SocCuentasloc pm) {
		pm.setFechaHora(new Date());

		this.getHibernateTemplate().saveOrUpdate(pm);		
	}
	public void saveOrUpdate(SocCuentasloc pm) {
		log.info("Salvando SocCuentasloc " + pm.getCtaCodigo() + " " + pm.getClaVigente());

		if (StringUtils.isBlank(pm.getBenCodigo())) {
			throw new BusinessException("codigo de beneficiario nulo");
		}

		if (StringUtils.isBlank(pm.getCtaNrocuenta())) {
			throw new BusinessException("Nro de Cuenta de beneficiario nulo");
		}

		if (pm.getCtaCtacodigo() == null) {
			throw new BusinessException("Codigo de Cuenta contable de beneficiario nulo");
		}

		if (pm.getCtaCodigo() == null){
			List<SocCuentasloc> socCuentaslocLista = findSocCuentasloc(null, pm.getBenCodigo(), pm.getCtaCtacodigo(), pm.getCtaNrocuenta(), pm.getMoneda());
			if (socCuentaslocLista.size() > 0){
				throw new BusinessException("Cuenta de beneficiario " + pm.getCtaNrocuenta() + " existente para beneficiario");
			}
		}

		SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
		socCuentassolDao.setSessionFactory(getSessionFactory());
		
		SocCuentassol socCuentassol = socCuentassolDao.getByCodigo(pm.getCtaCtacodigo());
		if (socCuentassol == null){
			throw new BusinessException("Codigo de Cuenta contable de beneficiario inexistente en cuentassol " + pm.getCtaCtacodigo());
		}
		
		pm.setMoneda(socCuentassol.getMoneda());
		
		SocCuentasloc socCuentaslocOld = getSocCuentasByCodigo(pm.getCtaCodigo());
		if (socCuentaslocOld == null) {
			Integer cod = generarCodigo();

			pm.setClaVigente(Short.valueOf("1"));
			pm.setCtaCodigo(cod);
		}

		pm.setFechaHora(new Date());

		this.getHibernateTemplate().saveOrUpdate(pm);
	}

	public SocCuentasloc getSocCuentasByCodigo(Integer ctaCodigo) {
		log.debug("Entre a buscar getSocCuentasByCodigo id: " + ctaCodigo);

		SocCuentasloc benefs = null;
		StringBuffer query = new StringBuffer();
		query = query.append("select be ");
		query = query.append("from SocCuentasloc be ");
		query = query.append("where be.ctaCodigo = :ctaCodigo ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("ctaCodigo", ctaCodigo);

		@SuppressWarnings("unchecked")
		List lista = consulta.list();

		if (lista.size() > 0) {
			benefs = (SocCuentasloc) lista.get(0);
		}

		return benefs;
	}

	public List<SocCuentasloc> findSocCuentasloc(Integer ctaCodigo, String benCodigo, Integer ctaCtacodigo, String ctaNrocuenta, Integer moneda) {
		log.debug("Entre a buscar findSocCuentasloc");

		StringBuffer query = new StringBuffer();
		query = query.append("select be ");
		query = query.append("from SocCuentasloc be ");
		query = query.append("where be.ctaNrocuenta is not null ");

		if (ctaCodigo != null) {
			query = query.append("and be.ctaCodigo = :ctaCodigo ");
		}
		if (!StringUtils.isBlank(benCodigo)) {
			query = query.append("and be.benCodigo = :benCodigo ");
		}
		if (ctaCtacodigo != null) {
			query = query.append("and be.ctaCtacodigo = :ctaCtacodigo ");
		}
		if (!StringUtils.isBlank(ctaNrocuenta)) {
			query = query.append("and be.ctaNrocuenta = :ctaNrocuenta ");
		}
		if (moneda != null) {
			query = query.append("and be.moneda = :moneda ");
		}

		Query consulta = getSession().createQuery(query.toString());

		if (ctaCodigo != null) {
			consulta.setParameter("ctaCodigo", ctaCodigo);
		}
		if (!StringUtils.isBlank(benCodigo)) {
			consulta.setParameter("benCodigo", benCodigo);
		}
		if (ctaCtacodigo != null) {
			consulta.setParameter("ctaCtacodigo", ctaCtacodigo);
		}
		if (!StringUtils.isBlank(ctaNrocuenta)) {
			consulta.setParameter("ctaNrocuenta", ctaNrocuenta);
		}
		if (moneda != null) {
			consulta.setParameter("moneda", moneda);
		}

		List lista = consulta.list();

		return lista;
	}

	public List<SocCuentasloc> cuentasBeneficiarioLoc(Integer ctaCodigo, Integer ctaCtacodigo, String benCodigo, String ctaNrocuenta,
			Integer codMoneda, String ctaAfectable, Short claVigente) {
		StringBuffer query = new StringBuffer();
		query = query.append("select sc ");
		query = query.append("from SocCuentasloc sc, SocCuentassol b ");
		query = query.append("where sc.ctaCtacodigo = b.ctaCodigo ");

		if (ctaCodigo != null) {
			query = query.append("and sc.ctaCodigo = :ctaCodigo ");
		} else {
			if (claVigente != null)
				query = query.append("and sc.claVigente = :claVigente ");
		}

		if (ctaCtacodigo != null) {
			query = query.append("and sc.ctaCtacodigo = :ctaCtacodigo ");
		}

		if (!StringUtils.isBlank(benCodigo)) {
			query = query.append("and sc.benCodigo = :benCodigo ");
		}

		if (!StringUtils.isBlank(ctaNrocuenta)) {
			query = query.append("and sc.ctaNrocuenta = :ctaNrocuenta ");
		}

		if (codMoneda != null)
			query = query.append("and sc.moneda = :codMoneda ");

		if (!StringUtils.isBlank(ctaAfectable)) {
			query = query.append("and b.ctaAfectable = :ctaAfectable ");
		}
		
		Query consulta = getSession().createQuery(query.toString());

		if (ctaCodigo != null) {
			consulta.setParameter("ctaCodigo", ctaCodigo);
		} else {
			if (claVigente != null)
				consulta.setParameter("claVigente", claVigente);
		}

		if (ctaCtacodigo != null) {
			consulta.setParameter("ctaCtacodigo", ctaCtacodigo);
		}
		if (!StringUtils.isBlank(benCodigo)) {
			consulta.setParameter("benCodigo", benCodigo);
		}

		if (!StringUtils.isBlank(ctaNrocuenta)) {
			consulta.setParameter("ctaNrocuenta", ctaNrocuenta);
		}

		if (codMoneda != null)
			consulta.setParameter("codMoneda", codMoneda);

		if (!StringUtils.isBlank(ctaAfectable)) {
			consulta.setParameter("ctaAfectable", ctaAfectable);
		}
		
		List lista = consulta.list();
		if (lista.size() == 0){
			log.info("Ctas Locales Recuperados sin registros: benCodigo: " + benCodigo + " ctaNrocuenta:" +ctaNrocuenta + " ctaAfectable:" + ctaAfectable );
		}
		return lista;
	}

	public Integer generarCodigo() {
		Integer maxDet = Integer.valueOf(0);
		StringBuffer query = new StringBuffer();
		query = query.append("select max(ctaCodigo) ");
		query = query.append("from SocCuentasloc ");

		Query consulta = getSession().createQuery(query.toString());

		log.debug("Entre a generarCod " + consulta.toString());

		List result = consulta.list();
		if (result.size() > 0)
			maxDet = (Integer) result.get(0);

		if (maxDet == null)
			maxDet = 0;
		maxDet++;
		return maxDet;
	}

}
