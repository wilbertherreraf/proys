/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-bpm-pruebaCU
 * gob.bcb.bpm.pruebaCU
 * 21/09/2011 - 10:21:05
 * Creado por Cecilia Uriona
 */
package gob.bcb.bpm.pruebaCU;

import gob.bcb.core.utils.UtilsDate;
import gob.bcb.core.utils.UtilsFile;
import gob.bcb.service.servicioSioc.common.MensSwiftUtiles;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Clase que contiene los metodos para crear los campos de un mensaje swift.
 * 
 * @author C. Cecilia Uriona
 * 
 */
public class Swift {
	private static final Log log = LogFactory.getLog(Swift.class);

	public static String[][] crearSwift(SocSolicitudes sol, SocOperaciones ope, SocDetallesope det, SocMensajes men) {
		if (sol != null) {
			log.info("Ingresando a crear Swift(Solicitud) " + sol.toString() + " " + det.getDetInfo() + " " + det.getDetConcepto());
		} else {
			log.info("Ingresando a crear Swift(Operacion) " + ope.getOpeCodigo() + " " + det.getDetInfo() + " " + det.getDetConcepto());
		}

		String[][] mensaje = null;

		String valor = "";

		String query = " select e.cam_codigo, c.cam_definicion" + " from soc_camposesq e, soc_campos c" + " where cla_esquema = '"
				+ men.getClaEsquema() + "'" + " and e.cam_codigo = c.cam_codigo";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "cam_codigo,cam_definicion".split(","));
		if (resultado.size() > 0) {
			int i = 0;
			mensaje = new String[resultado.size()][2];
			for (Map<String, Object> res : resultado) {

				if ((res.get("cam_definicion") != null) && !res.get("cam_definicion").equals("")) {
					valor = (String) res.get("cam_definicion");
				} else {
					if (sol != null) {
						valor = getCampo((String) res.get("cam_codigo"), sol, det, null, men);
					} else {
						valor = getCampo((String) res.get("cam_codigo"), null, det, ope, men);
					}
				}

				if (!StringUtils.isBlank(valor)) {
					mensaje[i][0] = (String) res.get("cam_codigo");
					mensaje[i][1] = valor;
					i++;
				}
			}
		} else {
			log.info("Datos de Esquema mensaje SWIFT '" + men.getClaEsquema() + "' inexistente");
			throw new RuntimeException("Datos de Esquema mensaje SWIFT '" + men.getClaEsquema() + "' inexistente");
		}

		log.info("Mensaje Swift " + ArrayUtils.toString(mensaje));

		return mensaje;
	}

	public static String[][] crearSwift(SocSolicitudes sol, SocDetallesope det, SocMensajes men) {
		return crearSwift(sol, null, det, men);
	}

	public static String[][] crearSwift(SocOperaciones ope, SocDetallesope det, SocMensajes men) {
		return crearSwift(null, ope, det, men);
	}

	private static String getCampo(String campo, SocSolicitudes sol, SocDetallesope det, SocOperaciones ope, SocMensajes men) {
		String valor = "";

		if (campo.equals("0G")) {
			valor = men.getClaEsquema().substring(0, 3);
		} else if (campo.equals("0H")) {
			valor = get0H(det.getMoneda());
		} else if (campo.equals(":20")) {
			valor = get20(men.getUsrCodigo(), men.getMenNroswift());
		} else if (campo.equals(":21")) {
			valor = "NONREF";
		} else if (campo.equals(":23B")) {
			valor = "CRED";
		} else if (campo.equals(":32A")) {
			valor = get32A(men.getMenFechavalor(), det.getMoneda(), det.getDetMonto());
		} else if (campo.equals(":33B")) {
			valor = get33B(det.getMoneda(), det.getDetMontoOrd());
		} else if (campo.equals(":50A")) {
			valor = "BCEBBOLP";
		} else if (campo.equals(":50K")) {
			if (sol != null) {
				valor = get50K(sol.getSolCodigo(), sol.getSocCuentad());
			} else {
				valor = get50K(ope.getSolCodigo(), "3918");
			}
		} else if (campo.equals(":52A")) {
			if (sol != null) {
				valor = get52A(sol.getSolCodigo());
			} else {
				valor = get52A(ope.getSolCodigo());
			}
		} else if (campo.equals(":53B")) {
			valor = get53B(det.getMoneda());
		} else if (campo.equals(":56A")) {
			valor = get56A(det.getDetCtabenef());
		} else if (campo.equals(":57A")) {
			valor = get57A(det.getDetCtabenef());
		} else if (campo.equals(":57D")) {
			valor = get57D(det.getDetCtabenef());
		} else if (campo.equals(":58D")) {
			valor = get58D(det.getDetCtabenef());
		} else if (campo.equals(":59")) {
			valor = get59(det.getDetCtabenef());
			if (!StringUtils.isBlank(valor)){
				String[] valorSplit = valor.split("\r\n");
				if (valorSplit.length > 5){
					throw new RuntimeException("Numero de lineas [" + valorSplit.length + "] campo :59 excede el permitido 5");				
				}
			}
		} else if (campo.equals(":70")) {
			if (det.getDetFacturas() != null) {
				valor = det.getDetFacturas();
			} else {
				valor = det.getDetConcepto();
			}
			valor = MensSwiftUtiles.cortarTexto(valor, "", false);
		} else if (campo.equals(":71A")) {
			valor = "OUR";
		} else if (campo.equals(":72")) {
			valor = MensSwiftUtiles.cortarTexto(det.getDetInfo(), "//", true);
		}

		return valor;
	}

	private static String get0H(Integer mon) {
		String valor = "";
		String bic = "";

		String query = "select pla_bic " + "from soc_plazas p, soc_valorescla v " + "where v.cla_codigo = 'cla_banquero' " + "and v.val_codigo = '"
				+ mon + "' " + "and p.bco_codigo = v.val_nombre " + "and p.pla_codigo = 1";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "pla_bic".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				log.debug("resultado" + res.toString());
				bic = (String) res.get("pla_bic");
			}
			if (bic.length() == 11)
				valor = bic.substring(0, 8) + "X" + bic.substring(8);
			else
				valor = bic;
		} else {
			log.info("Error al obtener el banquero");
		}

		return valor;
	}

	private static String get20(String usuario, Integer nroS) {
		String valor = "";
		String ini = "";

		String query = " select val_nombre" + " from soc_valorescla " + " where cla_codigo = 'cla_abrev' " + " and val_codigo = '" + usuario + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "val_nombre".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				log.debug("resultado" + res.toString());
				ini = (String) res.get("val_nombre");
			}
		} else {
			log.error("Error al iniciales de usuario " + usuario + " registre en valorescla");
			throw new RuntimeException("Error al iniciales de usuario " + usuario + " registre en valorescla");
		}

		String corr = String.format("%04d", nroS);
		String fecStr = UtilsDate.stringFromDate(new Date(), "ddMMyy");

		valor = corr + "/" + fecStr + "/" + ini;

		return valor;
	}

	private static String get32A(Date fecha, Integer mon, BigDecimal monto) {
		String valor = "";
		String moneda = "";

		String query = " select val_nombre" + " from soc_valorescla " + " where cla_codigo = 'cla_moneda'" + " and val_codigo = '" + mon + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "val_nombre".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				log.debug("resultado" + res.toString());
				moneda = (String) res.get("val_nombre");
			}
		} else {
			log.error("Error al obtener la moneda");
			throw new RuntimeException("Error al obtener la moneda " + mon + " inexistente");
		}

		BigDecimal monto1 = monto.divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
		String mm = monto1.toString().replace('.', ',');
		int pos = 0;
		pos = mm.indexOf(',');
		if (pos > -1) {
			mm = mm.substring(0, pos + 3);
		}
		String fecStr = UtilsDate.stringFromDate(fecha, "yyMMdd");
		valor = fecStr + moneda + mm;

		return valor;
	}

	private static String get33B(Integer mon, BigDecimal montoOrd) {
		String valor = "";
		String moneda = "";

		String query = " select val_nombre" + " from soc_valorescla " + " where cla_codigo = 'cla_moneda'" + " and val_codigo = '" + mon + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "val_nombre".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				log.debug("resultado" + res.toString());
				moneda = (String) res.get("val_nombre");
			}
		} else {
			log.error("Error al obtener la moneda");
			throw new RuntimeException("Error al obtener la moneda " + mon + " inexistente");
		}

		log.info("moneda:" + moneda + " montoord " + montoOrd.toString());

		if (montoOrd.compareTo(BigDecimal.valueOf(0)) > 0) {
			BigDecimal monto = montoOrd.divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
			String mm = monto.toString().replace('.', ',');
			int pos = 0;
			pos = mm.indexOf(',');
			if (pos > -1) {
				mm = mm.substring(0, pos + 3);
			}
			valor = moneda + mm;
		}
		log.debug("valor:" + valor);

		return valor;
	}

	private static String get50K(String sol, Integer cuenta) {
		String valor = "";
		String query = "";
		String cta = "";
		String persona = "";
		String direccion = "";
		String plaza = "";

		query = " select cta_movimiento as cuenta" + " from soc_cuentassol " + " where cta_codigo = '" + cuenta + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "cuenta".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				log.debug("resultado" + res.toString());
				cta = (String) res.get("cuenta");
			}

			if (cta.equals("0818")) {
				query = " select cta_numero as cuenta" + " from soc_solcuentas " + " where cta_codigo = '" + cuenta + "'" + " and sol_codigo = '"
						+ sol + "'";

				List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query, "cuenta".split(","));
				if (resultado1.size() == 1) {
					for (Map<String, Object> res : resultado1) {
						log.debug("resultado" + res.toString());
						cta = (String) res.get("cuenta");
					}
				} else {
					log.info("Error al obtener la cuenta del solicitante");
				}
			}
		} else {
			log.info("Error al obtener la cuenta del solicitante");
		}

		query = " select sol_persona, sol_direccion, sol_plaza" + " from soc_solicitante " + " where sol_codigo = '" + sol + "'";

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query, "sol_persona, sol_direccion, sol_plaza".split(","));
		if (resultado1.size() == 1) {
			for (Map<String, Object> res : resultado1) {
				log.debug("resultado" + res.toString());
				persona = (String) res.get("sol_persona");
				direccion = (String) res.get("sol_direccion");
				plaza = (String) res.get("sol_plaza");
			}
		} else {
			log.info("Error al obtener la cuenta del solicitante");
		}

		valor = "/" + cta + "\r\n" + MensSwiftUtiles.cortarTexto(persona, "", false)
		+ (StringUtils.isBlank(direccion) ? "" : "\r\n" + MensSwiftUtiles.cortarTexto(direccion, "", false))
		+ (StringUtils.isBlank(plaza) ? "" : "\r\n" + MensSwiftUtiles.cortarTexto(plaza, "", false));
		
		return valor;
	}

	private static String get50K(String sol, String cuenta) {
		String valor = "";
		String query = "";
		String persona = "";
		String direccion = "";
		String plaza = "";

		query = " select sol_persona, sol_direccion, sol_plaza" + " from soc_solicitante " + " where sol_codigo = '" + sol + "'";

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query, "sol_persona, sol_direccion, sol_plaza".split(","));
		if (resultado1.size() == 1) {
			for (Map<String, Object> res : resultado1) {
				log.debug("resultado" + res.toString());
				persona = (String) res.get("sol_persona");
				direccion = (String) res.get("sol_direccion");
				plaza = (String) res.get("sol_plaza");
			}
		} else {
			log.info("Error al obtener la cuenta del solicitante");
		}
		valor = "/" + cuenta + (StringUtils.isBlank(persona) ? "" : "\r\n" + MensSwiftUtiles.cortarTexto(persona, "", false))
		+ (StringUtils.isBlank(direccion) ? "" : "\r\n" + MensSwiftUtiles.cortarTexto(direccion, "", false))
		+ (StringUtils.isBlank(plaza) ? "" : "\r\n" + MensSwiftUtiles.cortarTexto(plaza, "", false));
		
		return valor;
	}

	private static String get52A(String sol) {
		String valor = "";

		String query = " select sol_bic" + " from soc_solicitante " + " where sol_codigo = '" + sol + "'";

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query, "sol_bic".split(","));
		if (resultado1.size() == 1) {
			for (Map<String, Object> res : resultado1) {
				log.debug("resultado" + res.toString());
				valor = (String) res.get("sol_bic");
			}
		} else {
			log.info("Error al obtener solicitante");
		}

		return valor;
	}

	private static String get53B(Integer mon) {
		String valor = "";
		String cuenta = "";

		String query = "select c.cta_nommovimiento " + "from soc_cuentassol c, soc_valorescla v " + "where v.cla_codigo = 'cla_cuenta_bcb' "
				+ "and v.val_codigo = '" + mon + "' " + "and v.val_nombre = c.cta_codigo";

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query, "cta_nommovimiento".split(","));
		if (resultado1.size() == 1) {
			for (Map<String, Object> res : resultado1) {
				log.debug("resultado" + res.toString());
				cuenta = (String) res.get("cta_nommovimiento");
			}
		} else {
			log.info("Error al obtener cuenta de banquero");
		}

		valor = "/" + cuenta + "\r\n" + "BANCO CENTRAL DE BOLIVIA";

		return valor;
	}

	private static String get56A(String cuenta) {
		String valor = "";

		String query = "select pla_intermediario " + "from soc_plazas p, soc_cuentas c " + "where p.bco_codigo = c.bco_codigo "
				+ "and p.pla_codigo = c.pla_codigo " + "and c.cta_codigo = '" + cuenta + "'";

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query, "pla_intermediario".split(","));
		if (resultado1.size() == 1) {
			for (Map<String, Object> res : resultado1) {
				log.debug("resultado" + res.toString());
				valor = (String) res.get("pla_intermediario");
			}
		} else {
			log.info("Error al obtener intermediario");
		}

		return valor;
	}

	private static String get57A(String cuenta) {
		String valor = "";

		String query = "select pla_bic " + "from soc_plazas p, soc_cuentas c " + "where p.bco_codigo = c.bco_codigo "
				+ "and p.pla_codigo = c.pla_codigo " + "and c.cta_codigo = '" + cuenta + "'";

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query, "pla_bic".split(","));
		if (resultado1.size() == 1) {
			for (Map<String, Object> res : resultado1) {
				log.debug("resultado" + res.toString());
				valor = (String) res.get("pla_bic");
			}
		} else {
			log.info("Error al obtener banco beneficiario");
		}

		return valor;
	}

	private static String get57D(String cuenta) {
		String valor = "";
		String cta = "";
		String banco = "";
		String plaza = "";

		String query = "select p.pla_nrocuenta, b.bco_nombre, p.pla_nombre " + "from soc_plazas p, soc_bancos b, soc_cuentas c "
				+ "where p.bco_codigo = c.bco_codigo " + "and p.pla_codigo = c.pla_codigo " + "and p.bco_codigo = b.bco_codigo "
				+ "and c.cta_codigo = '" + cuenta + "'";

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query, "pla_nrocuenta, bco_nombre, pla_nombre".split(","));
		if (resultado1.size() == 1) {
			for (Map<String, Object> res : resultado1) {
				log.debug("resultado" + res.toString());
				cta = (String) res.get("pla_nrocuenta");
				banco = (String) res.get("bco_nombre");
				plaza = (String) res.get("pla_nombre");
			}
		} else {
			log.info("Error al obtener banco beneficiario");
		}

		if (cta.substring(0, 2).equals("FW"))
			cta = "/" + cta;

		valor = "/" + cta + "\r\n" + MensSwiftUtiles.cortarTexto(banco, "", false) + "\r\n" + MensSwiftUtiles.cortarTexto(plaza, "", false);
		return valor;
	}

	private static String get58D(String cuenta) {
		String valor = "";
		String cta = "";
		String benef = "";

		String query = "select c.cta_nrocuenta, b.ben_nombre " + "from soc_cuentas c, soc_benefs b " + "where c.ben_codigo = b.ben_codigo "
				+ "and c.cta_codigo = '" + cuenta + "'";

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query, "cta_nrocuenta, ben_nombre".split(","));
		if (resultado1.size() == 1) {
			for (Map<String, Object> res : resultado1) {
				log.debug("resultado" + res.toString());
				cta = (String) res.get("cta_nrocuenta");
				benef = (String) res.get("ben_nombre");
			}
		} else {
			log.info("Error al obtener beneficiario");
		}

		valor = "/" + cta + "\r\n" + MensSwiftUtiles.cortarTexto(benef, "", false);
		return valor;
	}

	private static String get59(String cuenta) {
		String valor = "";
		String cta = "";
		String benef = "";
		String benDireccion = "";
		String benPlaza = "";

		String query = "select c.cta_nrocuenta, b.ben_nombre, b.ben_direccion, b.ben_plaza " + "from soc_cuentas c, soc_benefs b "
				+ "where c.ben_codigo = b.ben_codigo " + "and c.cta_codigo = '" + cuenta + "'";

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query, "cta_nrocuenta, ben_nombre,ben_direccion, ben_plaza".split(","));
		if (resultado1.size() == 1) {
			for (Map<String, Object> res : resultado1) {
				log.debug("resultado" + res.toString());
				cta = (String) res.get("cta_nrocuenta");
				benef = (String) res.get("ben_nombre");
				benDireccion = (String) res.get("ben_direccion");
				benPlaza = (String) res.get("ben_plaza");
			}
		} else {
			throw new RuntimeException("Error Swift campo 59, datos de beneficiario incorrectos para cuenta " + cuenta);
		}

		if (StringUtils.isBlank(benDireccion) || StringUtils.isBlank(cta) || StringUtils.isBlank(benef) || StringUtils.isBlank(benPlaza)) {
			throw new RuntimeException("Datos incompletos en parametrizacion de beneficiario de cta: " + cuenta + " verifique la parametrizacion");
		}
		cta = cta.trim();
		benef = benef.trim();
		benDireccion = benDireccion.trim();
		benPlaza = benPlaza.trim();

		valor = "/" + cta + (StringUtils.isBlank(benef) ? "" : "\r\n" + MensSwiftUtiles.cortarTexto(benef, "", false))
				+ (StringUtils.isBlank(benDireccion) ? "" : "\r\n" + MensSwiftUtiles.cortarTexto(benDireccion, "", false))
				+ (StringUtils.isBlank(benPlaza) ? "" : "\r\n" + MensSwiftUtiles.cortarTexto(benPlaza, "", false));

		if (!StringUtils.isBlank(valor)){
			String[] valorSplit = valor.split("\r\n");
			if (valorSplit.length > 5){
				valor = "/" + cta + (StringUtils.isBlank(benef) ? "" : "\r\n" + MensSwiftUtiles.cortarTexto(benef, "", false))
						+ ("\r\n" + MensSwiftUtiles.cortarTexto(benDireccion +", " + benPlaza, "", false));
			}
		}
		
		return valor;
	}

	public static String crearSwiftTexto(String codIns) {
		String texto = "";

		for (int i = 1; i <= 4; i++) {
			texto = texto + bloqueInicio(i) + bloqueValor(codIns, i) + bloqueFin(i);
		}
		log.info("Swift generado codIns " + codIns);
		log.info(texto);		
		return texto;
	}

	private static String bloqueInicio(int bloque) {
		String texto = "";

		texto = "{" + bloque + ":";
		if (bloque == 4)
			// texto = texto + System.getProperty("line.separator");
			texto = texto + "\r\n";

		return texto;
	}

	private static String bloqueValor(String codigo, int bloque) {
		String texto = "";
		String campo = "";
		String valor = "";

		String query = " select d.cam_codigo, d.dam_valor" + " from soc_datosmen d, soc_campos c" + " where d.ins_codigo = '" + codigo + "'"
				+ " and d.cam_codigo = c.cam_codigo" + " and c.cam_bloque = " + bloque + " order by d.cam_codigo";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "cam_codigo, dam_valor".split(","));
		if (resultado.size() > 0) {
			for (Map<String, Object> res : resultado) {
				log.debug("resultado" + res.toString());
				campo = (String) res.get("cam_codigo");
				valor = (String) res.get("dam_valor");
				if (campo.equals(":32A") || campo.equals(":33B")) {
					valor.replace('.', ',');
				}
				texto = texto + campoInicio(campo) + valor + campoFin(campo);
			}
		} else {
			throw new RuntimeException("Datos de mensaje SWIFT inexistentes en base de datos para codigo " + codigo + " nro bloque:" + bloque);
		}

		return texto;
	}

	private static String campoInicio(String campo) {
		String texto = "";

		char c = campo.charAt(0);
		switch (c) {
		case '0':
			texto = "";
			break;
		case ':':
			texto = campo + ":";
			break;
		default:
			texto = "{" + campo + ":";
			break;
		}

		return texto;
	}

	private static String campoFin(String campo) {
		String texto = "";

		char c = campo.charAt(0);
		switch (c) {
		case '0':
			texto = "";
			break;
		case ':':
			// texto = System.getProperty("line.separator");
			texto = "\r\n";
			break;
		default:
			texto = "}";
		}

		return texto;
	}

	private static String bloqueFin(int bloque) {
		String texto = "";

		if (bloque == 4)
			texto = "-}";
		else
			texto = "}";

		return texto;
	}

	/*
	 * reemplaza la cadena \n \r por valores ascii
	 */
	public static String replaceEOL(String s) {
		char c;
		int len = s.length();
		StringBuffer sbuf = new StringBuffer(len);

		int i = 0;
		while (i < len) {
			c = s.charAt(i++);
			if (c == '\\') {
				c = s.charAt(i++);
				if (c == 'n') {
					c = '\n';
				} else if (c == 'r') {
					c = '\r';
					// } else if (c == 't') {
					// c = '\t';
					// } else if (c == 'f') {
					// c = '\f';
					// } else if (c == '\b') {
					// c = '\b';
					// } else if (c == '\"') {
					// c = '\"';
					// } else if (c == '\'') {
					// c = '\'';
					// } else if (c == '\\') {
					// c = '\\';
				}
			}
			sbuf.append(c);
		}
		return sbuf.toString();
	}

	
}
