package gob.bcb.bpm.pruebaCU;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

import gob.bcb.service.exception.BusinessException;

@Transactional
public class GenMonedaDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(GenMonedaDao.class);

	public GenMoneda saveOrUpdate(GenMoneda genMoneda) {

		GenMoneda genMonedaOld = findByCodigo(genMoneda.getCodMoneda());

		if (genMoneda.getCodMoneda() == null) {
			throw new BusinessException("Codigo de Moneda invalida");
		}
		if (StringUtils.isBlank(genMoneda.getMonNombre())) {
			throw new BusinessException("Nombre Moneda invalida");
		}
		if (StringUtils.isBlank(genMoneda.getMonSigla())) {
			throw new BusinessException("sigla Moneda invalida");
		}
		if (StringUtils.isBlank(genMoneda.getDesSwift())) {
			throw new BusinessException("sigla swift Moneda invalida(si no tiene copie la sigla)");
		}
		genMoneda.setDesSwift(genMoneda.getDesSwift().trim().toUpperCase());
		genMoneda.setMonNombre(genMoneda.getMonNombre().trim().toUpperCase());
		genMoneda.setMonSigla(genMoneda.getMonSigla().trim().toUpperCase());

		if (genMonedaOld == null) {
			genMoneda.setFechaHora(new Date());
			this.getHibernateTemplate().saveOrUpdate(genMoneda);
			genMonedaOld = findByCodigo(genMoneda.getCodMoneda());
		} else {
			genMonedaOld.setDesSwift(genMoneda.getDesSwift());
			genMonedaOld.setMonNombre(genMoneda.getMonNombre());
			genMonedaOld.setMonSigla(genMoneda.getMonSigla());
			genMonedaOld.setFechaHora(new Date());
			genMonedaOld.setEstacion(genMoneda.getEstacion());
			genMonedaOld.setUsrCodigo(genMoneda.getUsrCodigo());			

			this.getHibernateTemplate().saveOrUpdate(genMonedaOld);
		}
		log.info("Moneda actualizada " + genMonedaOld.toString());
		return genMonedaOld;
	}

	public GenMoneda findByCodMoneda(Integer codMoneda) {
		String jpql = "SELECT h FROM GenMoneda h where h.codMoneda = :codMoneda";
		Query query = getSession().createQuery(jpql);
		query.setParameter("codMoneda", codMoneda);

		List result = query.list();
		if (result.size() != 1) {
			throw new BusinessException("Moneda [" + codMoneda + "] inexistente en GenMoneda");
		}

		return (GenMoneda) result.get(0);
	}

	public GenMoneda findByCodigo(Integer codMoneda) {
		String jpql = "SELECT h FROM GenMoneda h where h.codMoneda = :codMoneda";
		Query query = getSession().createQuery(jpql);
		query.setParameter("codMoneda", codMoneda);

		List result = query.list();
		if (result.size() > 0) {
			return (GenMoneda) result.get(0);
		}

		return null;
	}

	public List<GenMoneda> getMonedas() {
		String jpql = "SELECT h FROM GenMoneda h";

		Query query = getSession().createQuery(jpql);

		List<GenMoneda> result = query.list();

		return result;
	}

	public List<GenMoneda> getMonedas(Integer codMoneda) {
		String jpql = "SELECT h FROM GenMoneda h ";

		if (codMoneda != null) {
			jpql = jpql.concat("where h.codMoneda = :codMoneda");
		}

		Query query = getSession().createQuery(jpql);

		if (codMoneda != null) {
			query.setParameter("codMoneda", codMoneda);
		}
		List<GenMoneda> result = query.list();

		return result;
	}

	public List<GenMoneda> getMonedasLista(List<Integer> codMonedaList, boolean inList) {
		String jpql = "SELECT h FROM GenMoneda h ";

		if (inList) {
			if (codMonedaList != null && codMonedaList.size() > 0) {
				jpql = jpql.concat("where h.codMoneda in (:codMonedaList)");
			}
		} else {
			if (codMonedaList != null && codMonedaList.size() > 0) {
				jpql = jpql.concat("where h.codMoneda not in (:codMonedaList)");
			}
		}
		log.debug("XXX: moneditas" + jpql);
		Query query = getSession().createQuery(jpql);

		if (codMonedaList != null && codMonedaList.size() > 0)
			query.setParameterList("codMonedaList", codMonedaList);
		else {

		}

		List<GenMoneda> result = query.list();

		return result;
	}
}
