package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the gen_feriado database table.
 * 
 */
@Entity
@Table(name="gen_feriado")
public class GenFeriado implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private GenFeriadoPK id;

	@Column(name="desc_feriado")
	private String descFeriado;

    public GenFeriado() {
    }

	public GenFeriadoPK getId() {
		return this.id;
	}

	public void setId(GenFeriadoPK id) {
		this.id = id;
	}
	
	public String getDescFeriado() {
		return this.descFeriado;
	}

	public void setDescFeriado(String descFeriado) {
		this.descFeriado = descFeriado;
	}

}