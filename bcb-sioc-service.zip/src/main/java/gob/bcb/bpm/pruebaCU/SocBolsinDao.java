/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.bpm.pruebaCU;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.joda.time.DateTime;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

import gob.bcb.core.utils.UtilsDate;
import gob.bcb.service.commons.ConfigurationServ;
import gob.bcb.service.commons.UserSessionHolder;
import gob.bcb.service.qnatives.coin.CalendarioComun;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.mail.MsgLogic;
import gob.bcb.service.servicioSioc.pojos.CuentaS;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;

//import org.hibernate.Query;

@Transactional
public class SocBolsinDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocBolsinDao.class);

	public void saveOrUpdate(SocBolsin pm) {
		log.info("Saving or updating " + pm);
		this.getHibernateTemplate().saveOrUpdate(pm);

	}

	public void eliminar(SocBolsin pm) {
		this.getHibernateTemplate().delete(pm);
	}

	public SocBolsin getBySocCodigo(String socCodigo) {

		StringBuffer query = new StringBuffer();
		query = query.append("select re ");
		query = query.append("from SocBolsin re ");
		query = query.append("where re.socCodigo = :socCodigo ");

		log.info("Consultando socbolsin [" + socCodigo + "] " + query.toString());

		Query consulta = getSession().createQuery(query.toString());
		consulta.setString("socCodigo", socCodigo);
		
		List lista = consulta.list();
		if (lista.size() > 0) {
			return (SocBolsin) lista.get(0);
		}

		return null;

	}
	public List<SocBolsin> getByEstadoFecha(Date fecha, String claEstado, String claTipsolic) {

		StringBuffer query = new StringBuffer();
		query = query.append("select re ");
		query = query.append("from SocBolsin re ");
		query = query.append("where re.fecha = :fecha ");
		query = query.append("and re.claEstado  in (" + claEstado + ") ");
		query = query.append("and re.claTipsolic in (" + claTipsolic + ") ");
		
		log.info("Consultando socbolsin [" + fecha + "] " + query.toString());

		Query consulta = getSession().createQuery(query.toString());
		consulta.setDate("fecha", fecha);
		//consulta.setString("claEstado", claEstado);		
		
		List lista = consulta.list();

		return lista;

	}
	
	private static final Object monitor = new Object();
	public SocBolsin nuevoBolsin(SocBolsin solicitudB) {
		String solCodigo = "";
		synchronized (monitor) {
			Date hoy = new Date();
			solCodigo = Long.toString(hoy.getTime());
			log.info("XXX: cod ing " + solCodigo);
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {

			}
			
		}
		solicitudB.setSocCodigo(solCodigo);
		solicitudB.setSeq(1);
		solicitudB.setMontoAdj(BigDecimal.valueOf(0.00));
		
		solicitudB.setFecha(new Date());
		solicitudB.setFechaHora(new Date());
		solicitudB.setUsrCodigo((String) UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID));
		solicitudB.setEstacion((String) UserSessionHolder.get(Constants.AUDIT_USER_ESTACION));
		
		validar(solicitudB);
		this.getHibernateTemplate().save(solicitudB);
		
		if (solicitudB.getClaTipsolic() != null && solicitudB.getClaTipsolic().trim().equalsIgnoreCase("G")) {
			if (solicitudB.getClaEstado() != null && solicitudB.getClaEstado().equals('B')) {
				// solo se envia mail si el emisor o el que inserta el
				// registro es un usuario del BCB = "B"
				// si es de tipo de compra por pub general se envia
				// correo a los involucrados

				SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
				socSolicitanteDao.setSessionFactory(getSessionFactory());

				SocUsuariosolDao socUsuariosolDao = new SocUsuariosolDao();
				socUsuariosolDao.setSessionFactory(getSessionFactory());
				
				SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCod(solicitudB.getSolCodigo());
				SocSolicitante socSolicitanteBenef = socSolicitanteDao.solicitanteByCod(solicitudB.getBenef());

				String subject = "Bolsin BCB: Solicitud de compra de divisas CLIENTE";
				String content = MsgLogic.mensajeSolicitudBolsin(solicitudB, socSolicitante, socSolicitanteBenef, subject);

				socUsuariosolDao.formarMail("SOLRECIBIDA", subject, content, "'900','" + solicitudB.getSolCodigo() + "'");
			}
		}
		
		return solicitudB;
	}
	/**
	 * RErorna la demanda de solicidutes venta de divisas por bolsin o venta
	 * directa
	 * 
	 * @param fecha
	 * @param tipoSolicitud
	 *            = 'BO' suma de bolsin tipoSolicitud = 'VD' demanda de venta
	 *            directa tipoSolicitud = 'TO' o vacio o nulo demanda de todo
	 * @param estado
	 * @return
	 */
	public BigDecimal getDemanda(Date fecha, String tipoSolicitud, String estado) {
		if (tipoSolicitud == null) {
			tipoSolicitud = "";
		}

		BigDecimal tt = BigDecimal.valueOf(0.00);
		StringBuffer query = new StringBuffer();
		query = query.append("select cc ");
		query = query.append("from SocBolsin cc ");
		query = query.append("where cc.fecha = ? ");
		// vd0
		if (tipoSolicitud.equalsIgnoreCase("BO")) {
			query = query.append(" and cc.claEstado in ('0','1','2','3','5') ");
			query = query.append(" and cc.claTipsolic in ('E','G') ");
		} else if (tipoSolicitud.equalsIgnoreCase("VD")) {
			query = query.append(" and cc.claEstado = '5' ");
			query = query.append(" and cc.claTipsolic in ('ED','GD') ");
		}

		List<SocBolsin> lista = (List<SocBolsin>) getHibernateTemplate().find(query.toString(), fecha);

		if (lista.size() > 0) {
			for (SocBolsin cc : lista) {
				tt = tt.add(cc.getMontoSol());
			}
		}

		return tt;
	}

	public void validar(SocBolsin socBolsin) {
		SocHorarioDao socHorarioDao = new SocHorarioDao();
		socHorarioDao.setSessionFactory(getSessionFactory());
		Date horarecep = (Date) UserSessionHolder.get(Constants.AUDIT_HORA_RECEPCION);
		
		if (socBolsin.getClaTipsolic() == null) {
			throw new RuntimeException("Tipo de Solicitud con valor nulo");
		}

		if (socBolsin.getMontoSol() == null || socBolsin.getMontoSol().compareTo(BigDecimal.ZERO) <= 0) {
			throw new RuntimeException("Monto solicitado nulo o cero");
		}
		
		if (StringUtils.isBlank(socBolsin.getOrigenFondos()) || socBolsin.getOrigenFondos().trim().length() <20){
			throw new RuntimeException("Campo Origen de Recursos requerido, (minimo 20 caracteres)");				
		}

		if (StringUtils.isBlank(socBolsin.getDestinoFondos()) || socBolsin.getDestinoFondos().trim().length() <20){
			throw new RuntimeException("Campo Destino de Recursos requerido, (minimo 20 caracteres)");				
		}

		if (StringUtils.isBlank(socBolsin.getMotivoFondos()) || socBolsin.getMotivoFondos().trim().length() <20){
			throw new RuntimeException("Campo Motivo de la Transaccion requerido, (minimo 20 caracteres)");				
		}

		if ((socBolsin.getClaTipsolic().trim().equalsIgnoreCase("G") || socBolsin.getClaTipsolic().trim().equalsIgnoreCase("GD"))) {
			// si la venta es al publico en general
			if (StringUtils.isEmpty(socBolsin.getBenef())) {
				throw new RuntimeException("Solicitante-beneficiario con valor nulo");
			}
			SocSolicitante socSolicitante = Servicios.getSocSolicitante(socBolsin.getBenef());
			if (socSolicitante == null) {
				throw new RuntimeException("Solicitante-beneficiario inexistente");
			}
			if (socSolicitante.getSolPlaza() == null || socSolicitante.getSolPlaza().trim().isEmpty()) {
				throw new RuntimeException("Solicitante-beneficiario " + socBolsin.getBenef() + " con PLAZA nulo");
			}
			if (StringUtils.isEmpty(socSolicitante.getSolNit())) {
				throw new RuntimeException("Solicitante-beneficiario con NIT nulo");
			}
			if (StringUtils.isEmpty(socSolicitante.getSolFactura())) {
				throw new RuntimeException("Solicitante-beneficiario  con Nombre factura nulo");
			}
			// agregar el tipo de operacion para venta bolsin
			if (socBolsin.getClaEstado() != null && socBolsin.getClaEstado().equals('B') && StringUtils.isEmpty(socBolsin.getBolCtamn())) {
				// whf ojooo se quitO por contingencia
				// throw new RuntimeException("Solicitud " +
				// socBolsin.getBenef() + " con Cta MN nulo");
			}
			if (socBolsin.getClaEstado() != null && socBolsin.getClaEstado().equals('B') && StringUtils.isEmpty(socBolsin.getBolCtame())) {
				// throw new RuntimeException("Solicitud " +
				// socBolsin.getBenef() + " con Cta ME nulo");
			}

		}

		// validaciones si es venta directa
		if ((socBolsin.getClaTipsolic().trim().equalsIgnoreCase("ED") || socBolsin.getClaTipsolic().trim().equalsIgnoreCase("GD"))) {
			
			// control de horarios
			boolean enHorario = socHorarioDao.operacionEstaEnHorario("VENTA_DIRECTA", horarecep, (String) UserSessionHolder.get(Constants.COD_IFA_REQUEST));

			if (!enHorario) {
				throw new RuntimeException("Tipo de Operacion VENTA_DIRECTA, fuera de horario "
						+ UtilsDate.stringFromDate(horarecep, Constants.FORMAT_DATE_TIME));
			}

			Integer horaIni = Servicios.getHoraLimite("ventadirectaini");
			Integer horaFin = Servicios.getHoraLimite("ventadirectafin");
			DateTime horaActual = new DateTime(new Date());

			if (horaActual.getHourOfDay() < horaIni || horaActual.getHourOfDay() >= horaFin) {
				//throw new RuntimeException("Operacion de Venta directa de divisas fuera de horario");
			}

			// si el monto solicitado supera al monto disponible
			BigDecimal sumaMonto = getDemanda(socBolsin.getFecha(), "VD", "");
			
			BigDecimal sumaMontoTotal = sumaMonto.add(socBolsin.getMontoSol());

			Double dispevd = Double.valueOf(Servicios.getParam("@disponiblevd"));
			BigDecimal disponibleVD = BigDecimal.valueOf(dispevd);
			
			log.info("demanda a la fecha[" + UtilsDate.stringFromDate(socBolsin.getFecha(), "dd/MM/yyyy")+"] " + sumaMonto + " mas solicitud " + sumaMontoTotal);
			
			if (sumaMontoTotal.compareTo(disponibleVD) > 0) {
				// si el monto adjudicado al momento es mayor al monto
				// disponible
				// whf vd2
				throw new RuntimeException("Su solicitud no fue realizada, el monto solicitado [" + socBolsin.getMontoSol()
						+ "] excede al monto disponible [ " + disponibleVD.subtract(sumaMonto) + "] ");
			}
			
		}

		// validar si la venta es de bolsin y esta suspendida
		if ((socBolsin.getClaTipsolic().trim().equalsIgnoreCase("E") || socBolsin.getClaTipsolic().trim().equalsIgnoreCase("G"))) {
			// validar si la entidad esta suspendida para venta y compra

			String query = "SELECT val_nombre " + "FROM soc_valorescla WHERE cla_codigo = 'cla_afec_b' " + "AND val_codigo = trim('"
					+ socBolsin.getSolCodigo() + "') and cla_vigente = 1";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query, "val_nombre".split(","));
			if (resultado1.size() == 0) {
				log.error("Cuenta afectable Inexistente o se encuentra suspendida: " + socBolsin.getSolCodigo());
				throw new RuntimeException("Cuenta afectable Inexistente o se encuentra suspendida: " + socBolsin.getSolCodigo());
			}
		}

		if ((socBolsin.getClaTipsolic().trim().equalsIgnoreCase("ED") || socBolsin.getClaTipsolic().trim().equalsIgnoreCase("GD"))) {
			// validar si la entidad esta suspendida para venta y compra

			String query = "SELECT val_nombre " + "FROM soc_valorescla WHERE cla_codigo = 'cla_afec_vd' " + "AND val_codigo = trim('"
					+ socBolsin.getSolCodigo() + "') and cla_vigente = 1";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query, "val_nombre".split(","));
			if (resultado1.size() == 0) {
				log.error("Cuenta afectable Inexistente o se encuentra suspendida: " + socBolsin.getSolCodigo());
				throw new RuntimeException("Cuenta afectable Inexistente o se encuentra suspendida: " + socBolsin.getSolCodigo());
			}
		}
	}

	public Map<String, Object> provisionBolsin(FactoryDao factoryDao, SocBolsin solicitudB) {
		log.info("XXX: Entrando a provisionBolsin " + solicitudB.getSocCodigo() + " : " + solicitudB.getCorr() + " : " + solicitudB.getSolCodigo());
		final Integer MONUS = 34;
		final Integer MONBS = 69;

		// inicio provision
		String codComprobante1 = null;
		Date hoy1 = new Date();
		DateTime hoy2 = new DateTime();

		BigDecimal tcUS = QueryProcessor.getTipoCambio(MONUS, new Date());
		BigDecimal tcBS = BigDecimal.valueOf(1);

		String query = "SELECT cta_afectable " + "FROM soc_cuentassol WHERE cta_codigo = " + solicitudB.getCuentaD();

		String afec = "";
		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "cta_afectable".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				afec = (String) res.get("cta_afectable");
			}
		} else {
			log.error("No existe cuenta afectable para " + solicitudB.getCuentaD());
			throw new RuntimeException("No existe cuenta afectable para " + solicitudB.getCuentaD());

		}

		Map<String, Object> mapaParametros1 = new HashMap<String, Object>();
		mapaParametros1.put("consulta", "saldo");
		mapaParametros1.put("afec", afec);
		mapaParametros1.put("gestion", hoy2.getYear());
		mapaParametros1.put("periodo", hoy2.getMonthOfYear());
		mapaParametros1.put("dia", hoy2.getDayOfMonth());

		log.info("Llamando al servicio de coin: get saldo");

		// /validamos el registro
		validar(solicitudB);

		SiocCoinService siocCoinService = new SiocCoinService();
		Map<String, Object> mapaResultado1 = siocCoinService.executeTask(mapaParametros1);

		BigDecimal saldo = (BigDecimal) mapaResultado1.get("saldo");
		BigDecimal monto = solicitudB.getMontoMN().multiply(BigDecimal.valueOf(-1));

		if (saldo.compareTo(monto) > 0) {
			log.error("No existe saldo suficiente en la cuenta de encaje: " + afec);
			if (!ConfigurationServ.getConfigurationHome().startsWith("e:")){
				log.error("XXX: ojoooooooooooooooooooo borrar esta linea " + monto);				
				// solo para test 
				throw new RuntimeException("No existe saldo suficiente en la cuenta de encaje: " + afec);				
			}
		}

		String glosaComprob = "";
		String mayorctaafect_vd = "000108";
		if (solicitudB.getClaTipsolic().equals("E") || solicitudB.getClaTipsolic().equals("G")) {
			// si esta en proceso de bolsin
			glosaComprob = "PROVISION DE FONDOS POR SOLICITUD DE DIVISAS " + solicitudB.getCorr();
			glosaComprob = glosaComprob.concat(" PARA LA SESION DEL BOLSIN DE LA FECHA");
		} else if (solicitudB.getClaTipsolic().equals("ED") || solicitudB.getClaTipsolic().equals("GD")) {
			mayorctaafect_vd = Servicios.getParam("mayorctaafect_vd");
			glosaComprob = "VENTA DE USD EN EL DIA SEGUN SOLICITUD DE DIVISAS " + solicitudB.getCorr();
		}

		codComprobante1 = Long.toString(hoy1.getTime());
		SocComprobante comprobante1 = new SocComprobante(codComprobante1, solicitudB.getSocCodigo(), hoy2.getYear(), hoy2.getMonthOfYear(),
				hoy2.getDayOfMonth(), tcUS, glosaComprob);

		SocComprobanteDao comprobanteDao = (SocComprobanteDao) factoryDao.getDao("socComprobanteDao");
		comprobanteDao.saveOrUpdate(comprobante1);
		log.info("Comprobante guardado: ");

		query = "SELECT val_nombre " + "FROM soc_valorescla WHERE cla_codigo = 'cla_afec_b' " + "AND val_codigo = trim('" + solicitudB.getSolCodigo()
				+ "')";
		if (solicitudB.getClaTipsolic().equals("ED") || solicitudB.getClaTipsolic().equals("GD")) {
			query = "SELECT val_nombre " + "FROM soc_valorescla WHERE cla_codigo = 'cla_afec_vd' " + "AND val_codigo = trim('"
					+ solicitudB.getSolCodigo() + "')  and cla_vigente = 1";
		}

		String afecB = "";
		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query, "val_nombre".split(","));
		if (resultado1.size() == 1) {
			for (Map<String, Object> res : resultado1) {
				afecB = (String) res.get("val_nombre");
			}
		} else {
			log.error("No existe cuenta afectable para solicitante: " + solicitudB.getSolCodigo());
			throw new RuntimeException("No existe cuenta afectable para solicitante: " + solicitudB.getSolCodigo());
		}
		SocRengscomp renglon1 = new SocRengscomp(new SocRengscompId(codComprobante1, 1), MONBS, 'D', tcBS, solicitudB.getMontoMN(),
				solicitudB.getMontoMN(), "000110", afec);
		renglon1.setRenGlosa("");
		SocRengscomp renglon2 = new SocRengscomp(new SocRengscompId(codComprobante1, 2), MONBS, 'H', tcBS, solicitudB.getMontoMN(),
				solicitudB.getMontoMN(), mayorctaafect_vd, afecB);
		SocRengscompDao rengsCompDao = (SocRengscompDao) factoryDao.getDao("socRengscompDao");
		rengsCompDao.saveOrUpdate(renglon1);
		rengsCompDao.saveOrUpdate(renglon2);

		log.info("Renglones generados para SocBolsin.SocCodigo: " + solicitudB.getSocCodigo());

		List<SocRengscomp> rengs = new ArrayList<SocRengscomp>();
		rengs.add(renglon1);
		rengs.add(renglon2);

		Map<String, Object> mapaParametros2 = new HashMap<String, Object>();
		mapaParametros2.put("comp", comprobante1);
		mapaParametros2.put("rengs", rengs);

		return mapaParametros2;
	}

	/**
	 * Proceso de creacion de registros en sioc de subasta o de venta directa,
	 * si es subasta es posterior al calculo del tipo de cambio
	 * 
	 * @param factoryDao
	 * @param solic
	 * @param tcCompra
	 * @param tcVenta
	 * @param tcBase
	 * @param nroSolicitud
	 * @return
	 */
	public Map<String, Object> entregaBolsin(FactoryDao factoryDao, SocBolsin solic, BigDecimal tcCompra, BigDecimal tcVenta, BigDecimal tcBase,
			Integer nroSolicitud) {
		log.info("XXX: Entrando a entregaBolsin " + solic.getSocCodigo() + " : " + solic.getCorr() + " : " + solic.getSolCodigo());

		// ////////////////////////////
		// INICIO contabilizacion de cuenta de provision a cuenta de en mn
		Date hoy1 = new Date();
		DateTime hoy2 = new DateTime();
		final Integer MONUS = 34;
		final Integer MONBS = 69;
		BigDecimal tcBS = BigDecimal.valueOf(1);

		Map<String, Object> mapaParametros2 = new HashMap<String, Object>();
		//if (solic.getMontoAdj().compareTo(BigDecimal.valueOf(0)) > 0) {
			hoy2 = new DateTime();
			hoy1 = new Date();

			// whf
			CalendarioComun calendarioComun = new CalendarioComun();
			calendarioComun.setSessionFactory(SiocCoinService.getSessionFactory());
			Date fechaHabil = calendarioComun.fecHabilAntesDespuesDe(hoy1, 1);
			DateTime fechaHabil1 = new DateTime(fechaHabil);

			String codComprobante1 = Long.toString(hoy1.getTime());

			String glosaComprob = "ENTREGA DE DIVISAS ADJUDICADAS EN SESION DEL BOLSIN DE FECHA " + hoy2.getDayOfMonth() + "/"
					+ hoy2.getMonthOfYear() + "/" + hoy2.getYear();

			if (solic.getClaTipsolic().equals("ED") || solic.getClaTipsolic().equals("GD")) {
				// si es venta directa
				glosaComprob = "VENTA DE DIVISAS DE FECHA " + hoy2.getDayOfMonth() + "/" + hoy2.getMonthOfYear() + "/" + hoy2.getYear();
				fechaHabil1 = new DateTime(new Date());
			}

			SocComprobante comprobante1 = new SocComprobante(codComprobante1, solic.getSocCodigo(), fechaHabil1.getYear(),
					fechaHabil1.getMonthOfYear(), fechaHabil1.getDayOfMonth(), tcCompra, glosaComprob);

			SocComprobanteDao comprobanteDao = (SocComprobanteDao) factoryDao.getDao("socComprobanteDao");
			comprobanteDao.saveOrUpdate(comprobante1);

			log.info("Comprobante en SIOC guardado SocBolsin.CpbCodigo: " + comprobante1.getCpbCodigo());

			SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
			socCuentassolDao.setSessionFactory(getSessionFactory());
			List<CuentaS> cuentas = socCuentassolDao.listaCuentasSolicitante(solic.getSolCodigo(), 34, null, null, null, null,null,true);

			if (cuentas == null || cuentas.size() != 1) {
				throw new RuntimeException("Cuenta inexistente entidad [" + solic.getSolCodigo() + "] moneda " + 34);
			}

			CuentaS cuentaS = cuentas.get(0);
			
			String query = "select ss.cta_codigo, cc.cta_afectable " + "from soc_solcuentas ss, soc_cuentassol cc "
					+ "where ss.cta_codigo = cc.cta_codigo " + "and cc.moneda = '34' " + "and ss.sol_codigo = '" + solic.getSolCodigo() + "'";

			String afec = cuentaS.getCtaAfectable();
			String afecB = "";

//			List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "cta_codigo, cta_afectable".split(","));
//			if (resultado.size() == 1) {
//				for (Map<String, Object> res : resultado) {
//					afec = (String) res.get("cta_afectable");
//				}
//			} else {
//				log.error("No existe cuenta afectable para solicitante: " + solic.getSolCodigo());
//				throw new RuntimeException("No existe cuenta afectable para solicitante: " + solic.getSolCodigo());
//			}

			query = "SELECT val_nombre " + "FROM soc_valorescla WHERE cla_codigo = 'cla_afec_b' " + "AND val_codigo = trim('" + solic.getSolCodigo()
					+ "')  and cla_vigente = 1 ";
			// vd0
			String mayorctaafect_vd = "000108";
			if (solic.getClaTipsolic().equals("ED") || solic.getClaTipsolic().equals("GD")) {
				mayorctaafect_vd = Servicios.getParam("mayorctaafect_vd");
				query = "SELECT val_nombre " + "FROM soc_valorescla WHERE cla_codigo = 'cla_afec_vd' " + "AND val_codigo = trim('"
						+ solic.getSolCodigo() + "')";
			}
			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query, "val_nombre".split(","));
			if (resultado1.size() == 1) {
				for (Map<String, Object> res : resultado1) {
					afecB = (String) res.get("val_nombre");
				}
			} else {
				log.error("No existe cuenta afectable para solicitante: " + solic.getSolCodigo());
				throw new RuntimeException("No existe cuenta afectable para solicitante: " + solic.getSolCodigo());
			}

			String soli = Servicios.getSolicitante(solic.getSolCodigo());

			SocSolicitante socSolicitante = null;

			if (solic.getBenef() != null)
				socSolicitante = Servicios.getSocSolicitante(solic.getBenef());

			String conceptoCompro = "";
			if (solic.getClaTipsolic() == null || solic.getClaTipsolic().trim().equals("E") || solic.getClaTipsolic().trim().equals("ED")) {
				// si es entidad financiera el solicitante
				conceptoCompro = soli;
				conceptoCompro = "SOL. VENTA DE DIVISAS POR USD. " + solic.getMontoAdj() + " A BS. " + solic.getCotiz() + " BENEF. " + conceptoCompro;
				if (solic.getClaTipsolic().trim().equals("ED")) {
					conceptoCompro = "USD. " + solic.getMontoAdj() + " BENEF. " + soli;
				}
			} else {
				if ((socSolicitante != null)
						&& (socSolicitante.getSolPersona() != null)
						&& (solic.getClaTipsolic() != null && (solic.getClaTipsolic().trim().equals("G") || solic.getClaTipsolic().trim()
								.equals("GD"))))
					// si se encontr� el beneficiario y ademas el tipo
					// de solicitud es a publico en general
					if (solic.getBolCtamn() != null && !solic.getBolCtamn().trim().isEmpty() && solic.getBolCtame() != null
							&& !solic.getBolCtame().trim().isEmpty())
						conceptoCompro = socSolicitante.getSolPersona() + " CTA. MN. " + solic.getBolCtamn() + " CTA. ME. " + solic.getBolCtame();
					else
						conceptoCompro = socSolicitante.getSolPersona();
				else
					conceptoCompro = soli;

				if (solic.getClaTipsolic().trim().equals("GD")) {
					conceptoCompro = "USD. " + solic.getMontoAdj() + " BENEF. " + conceptoCompro;
				} else {
					conceptoCompro = "SOL. NRO. " + nroSolicitud + " POR USD. " + solic.getMontoAdj() + " A BS. " + solic.getCotiz() + " BENEF. "
							+ conceptoCompro;
				}
			}
			SocRengscomp renglon1 = new SocRengscomp(new SocRengscompId(codComprobante1, 1), MONBS, 'D', tcBS, solic.getMontoAdj().multiply(
					solic.getCotiz()), solic.getMontoAdj().multiply(solic.getCotiz()), mayorctaafect_vd, afecB);

			SocRengscomp renglon2 = new SocRengscomp(new SocRengscompId(codComprobante1, 2), MONUS, 'H', tcCompra, solic.getMontoAdj(), solic
					.getMontoAdj().multiply(tcCompra), "000110", afec, conceptoCompro);

			// diferencial cambiario
			Double diff_cv = Double.valueOf(Servicios.getParam("@diffcv"));
			// para el monto excento
			BigDecimal comiV = solic.getMontoAdj().multiply(BigDecimal.valueOf(diff_cv));

			SocRengscomp renglon3 = new SocRengscomp(new SocRengscompId(codComprobante1, 3), MONBS, 'H', tcBS, comiV.multiply(BigDecimal.valueOf(1)),
					comiV.multiply(BigDecimal.valueOf(1)), Servicios.getParam("@mventaBolsin"), Servicios.getParam("@cventaBolsin_vd"));

			SocRengscompDao rengsCompDao = (SocRengscompDao) factoryDao.getDao("socRengscompDao");

			rengsCompDao.saveOrUpdate(renglon1);
			rengsCompDao.saveOrUpdate(renglon2);
			rengsCompDao.saveOrUpdate(renglon3);

			// creamos la lista de renglones para retorno
			List<SocRengscomp> rengs = new ArrayList<SocRengscomp>();
			rengs.add(renglon1);
			rengs.add(renglon2);
			rengs.add(renglon3);

			BigDecimal diftc = solic.getCotiz().subtract(tcVenta);
			if (diftc.compareTo(BigDecimal.valueOf(0.005)) > 0) {
				SocRengscomp renglon4 = new SocRengscomp(new SocRengscompId(codComprobante1, 4), MONBS, 'H', tcBS, solic.getMontoAdj()
						.multiply(diftc), solic.getMontoAdj().multiply(diftc), "000153", "004378");

				rengsCompDao.saveOrUpdate(renglon4);
				rengs.add(renglon4);
			}

			log.info("Renglones guardados: ");
			// Codigo para la emision de factura sin credito
			// fiscal

			String nit = "";
			char cveRuc = 'P';

			log.info("Llamando al servicio de coin: get nit");

			if (solic.getClaTipsolic() != null && (solic.getClaTipsolic().equalsIgnoreCase("G") || solic.getClaTipsolic().equalsIgnoreCase("GD"))) {
				// si la venta es a publico en general
				nit = socSolicitante.getSolNit();
				soli = socSolicitante.getSolFactura();
			} else {
				SiocCoinService siocCoinService = new SiocCoinService();

				Map<String, Object> mapaParametros3 = new HashMap<String, Object>();
				mapaParametros3.put("consulta", "nit");
				mapaParametros3.put("soli", solic.getSolCodigo().trim());

				Map<String, Object> mapaResultado3 = siocCoinService.executeTask(mapaParametros3);

				nit = (String) mapaResultado3.get("nit");
			}

			if (nit == null || nit.trim().isEmpty()) {
				log.error("No existe NIT para solicitante: " + soli);
				throw new RuntimeException("No existe NIT para solicitante: " + soli);
			}

			SocFacturasId socFacturasId = new SocFacturasId(codComprobante1, 3, 1);

			SocFacturas factura = new SocFacturas(socFacturasId, nit, soli, solic.getMontoAdj().multiply(solic.getCotiz()), BigDecimal.valueOf(0),
					solic.getMontoAdj().multiply(solic.getCotiz()), tcBase, "VENTA DE DIVISAS", cveRuc);
			SocFacturasDao socFacturaDao = (SocFacturasDao) factoryDao.getDao("socFacturasDao");
			socFacturaDao.saveOrUpdate(factura);

			// creamos para retorno
			List<SocFacturas> facts = new ArrayList<SocFacturas>();
			facts.add(factura);

			mapaParametros2.put("comp", comprobante1);
			mapaParametros2.put("rengs", rengs);
			mapaParametros2.put("facts", facts);
		//}

		return mapaParametros2;
		// FIN contabilizacion de cuenta de provision a cuenta de en mn
		// /////////////////////////////
	}
	
	public Map<String, String> revisaPendientesVentadirecta() {
		log.info("Entrando proceso auto en revisaPendientesVentadirecta : ");
	
		Date hoy = new Date();
		CalendarioComun calendarioComun = new CalendarioComun();
		calendarioComun.setSessionFactory(SiocCoinService.getSessionFactory());
		boolean isHabil = calendarioComun.isHabil(hoy);
		log.info("Fecha hoy: " + UtilsDate.stringFromDate(hoy, "dd/MM/yyyy")  );
		
		if (!isHabil) {
			log.warn("Proceso de adjudicacion ejecutado en dia inhabil");
			throw new RuntimeException("Proceso de adjudicacion ejecutado en dia inhabil " + hoy);
		}
		// filtramos las solcititudes pendientes solo de venta directa
		List<SocBolsin> listaBolsin = gob.bcb.bpm.pruebaCU.Servicios.getSocBolsinList("'9'", hoy, null, "'ED','GD'");

		Map<String, String> msgRepuesta = new HashMap<String, String>();
		String msgError = "";
		msgRepuesta.put("00002", "Fecha : " + UtilsDate.stringFromDate(hoy, "dd/MM/yyyy"));		
		
		if (listaBolsin.size() == 0) {
			msgError = "Proceso de adjudicacion de fecha sin solicitudes registradas.";
			log.info(msgError);
			msgRepuesta.put("00003", msgError);
		}
		
		for (SocBolsin socBolsin : listaBolsin) {
			log.info("borrado logico de registro no autorizado ... " +  (socBolsin.getSocCodigo()));			
			SocBolsin socBolsinOld = getBySocCodigo(socBolsin.getSocCodigo());
			SocSolicitante socSolicitante = Servicios.getSocSolicitante(socBolsinOld.getSolCodigo());
			if (socSolicitante != null && socSolicitante.getClaEntidad().equals("SF")){
				msgRepuesta.put(socBolsinOld.getCorr(), socBolsinOld.getCorr());
				socBolsinOld.setClaEstado('Z');
				socBolsinOld.setFechaHora(new Date());
				socBolsinOld.setUsrCodigo("JOBSIOC");
				saveOrUpdate(socBolsinOld);
				log.info("Revision Venta Directa Eliminando ... " +  socBolsinOld.toString());
			}
			//eliminar(socBolsinOld);
			
		}
		// si no existe registros a procesar se sale del proceso
		return msgRepuesta;		
	}	
}
