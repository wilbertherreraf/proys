package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the soc_campos database table.
 * 
 */
@Entity
@Table(name="soc_campos")
public class SocCampos implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="cam_codigo")
	private String camCodigo;

	@Column(name="cam_bloque")
	private Short camBloque;

	@Column(name="cam_definicion")
	private String camDefinicion;

	@Column(name="cam_nombre")
	private String camNombre;

	@Column(name="cla_vigente")
	private Short claVigente;

	private String estacion;

    @Temporal( TemporalType.TIMESTAMP)
	@Column(name="fecha_hora")
	private Date fechaHora;

	@Column(name="usr_codigo")
	private String usrCodigo;

    public SocCampos() {
    }

	public String getCamCodigo() {
		return this.camCodigo;
	}

	public void setCamCodigo(String camCodigo) {
		this.camCodigo = camCodigo;
	}

	public Short getCamBloque() {
		return this.camBloque;
	}

	public void setCamBloque(Short camBloque) {
		this.camBloque = camBloque;
	}

	public String getCamDefinicion() {
		return this.camDefinicion;
	}

	public void setCamDefinicion(String camDefinicion) {
		this.camDefinicion = camDefinicion;
	}

	public String getCamNombre() {
		return this.camNombre;
	}

	public void setCamNombre(String camNombre) {
		this.camNombre = camNombre;
	}

	public Short getClaVigente() {
		return this.claVigente;
	}

	public void setClaVigente(Short claVigente) {
		this.claVigente = claVigente;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getUsrCodigo() {
		return this.usrCodigo;
	}

	public void setUsrCodigo(String usrCodigo) {
		this.usrCodigo = usrCodigo;
	}

}