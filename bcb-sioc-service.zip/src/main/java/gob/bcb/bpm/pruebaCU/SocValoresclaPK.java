package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the soc_valorescla database table.
 * 
 */
@Embeddable
public class SocValoresclaPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="cla_codigo")
	private String claCodigo;

	@Column(name="val_codigo")
	private String valCodigo;

    public SocValoresclaPK() {
    }
	public String getClaCodigo() {
		return this.claCodigo;
	}
	public void setClaCodigo(String claCodigo) {
		this.claCodigo = claCodigo;
	}
	public String getValCodigo() {
		return this.valCodigo;
	}
	public void setValCodigo(String valCodigo) {
		this.valCodigo = valCodigo;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof SocValoresclaPK)) {
			return false;
		}
		SocValoresclaPK castOther = (SocValoresclaPK)other;
		return 
			this.claCodigo.equals(castOther.claCodigo)
			&& this.valCodigo.equals(castOther.valCodigo);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.claCodigo.hashCode();
		hash = hash * prime + this.valCodigo.hashCode();
		
		return hash;
    }
}