/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.bpm.pruebaCU;

//import java.util.ArrayList;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

//import org.hibernate.Query;

/**
 * @author wherrera
 * 
 */
@Transactional
public class SocDatosmenDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocDatosmenDao.class);

	public void saveOrUpdate(SocDatosmen pm) {
		// log.info("Saving or updating " + pm);
		this.getHibernateTemplate().saveOrUpdate(pm);
	}

	public void eliminarDato(SocDatosmen pm) {
		// log.info("Eliminando datos mensaje... " + pm);
		this.getHibernateTemplate().delete(pm);
	}

	public List<SocDatosmen> getDatos(String insCodigo) {
		List<SocDatosmen> lista = new ArrayList<SocDatosmen>();

		StringBuffer query = new StringBuffer();

		query = query.append("select da ");
		query = query.append("from SocDatosmen da ");
		query = query.append("where da.id.insCodigo = :insCodigo ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("insCodigo", insCodigo);

		lista = consulta.list();

		return lista;
	}

	public SocDatosmen getSocDatosmen(String insCodigo, String camCodigo) {
		SocDatosmen socDatosmen = null;

		StringBuffer query = new StringBuffer();

		query = query.append("select da ");
		query = query.append("from SocDatosmen da ");
		query = query.append("where da.id.insCodigo = :insCodigo ");
		query = query.append("and da.id.camCodigo = :camCodigo ");

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("insCodigo", insCodigo);
		consulta.setParameter("camCodigo", camCodigo);

		List lista = consulta.list();

		if (lista.size() > 0) {
			socDatosmen = (SocDatosmen) lista.get(0);
		}
		return socDatosmen;
	}

	public List<SocDatosmen> crearSocDatosmen(List<SocDatosmen> socDatosmenlista) {
		if (socDatosmenlista == null || socDatosmenlista.size() == 0) {
			throw new RuntimeException("error al actualizar datos de mensaje swift sin valores");
		}

		// se eliminan todos los datos ya que puede ser que el esq o el numero
		// de registros sea diferente
		StringBuffer query = new StringBuffer();
		query = query.append("delete from soc_datosmen ");
		query = query.append("where ins_codigo = :insCodigo ");
		
		Query consulta = getSession().createSQLQuery(query.toString());
		
		consulta.setParameter("insCodigo", socDatosmenlista.get(0).getId().getInsCodigo());
		int rowCount = consulta.executeUpdate();
		log.info("Eliminando " + rowCount + " SocDatosmen... " + socDatosmenlista.get(0).getId().getInsCodigo());		

		List<SocDatosmen> socDatosmenListNew = new ArrayList<SocDatosmen>();

		for (SocDatosmen socDatosmen : socDatosmenlista) {
			saveOrUpdate(socDatosmen);
			socDatosmenListNew.add(socDatosmen);
			//log.info("Registro creado datos: " + socDatosmen.toString());
		}

		return socDatosmenListNew;
	}

}
