package gob.bcb.bpm.pruebaCU;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;

@Transactional
public class SocComitipoopeDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocComitipoopeDao.class);

	public List<SocComitipoope> comisionesByTipoOper(String claComision) {
		List<SocComitipoope> lista = new ArrayList<SocComitipoope>();

		StringBuffer query = new StringBuffer();

		query = query.append("select da ");
		query = query.append("from SocComitipoope da ");
		query = query.append("where da.id.claComision = :claComision ");

		log.debug("procesando " + query.toString() + " " + claComision);
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("claComision", claComision);

		lista = consulta.list();

		return lista;
	}
	
	public List<SocComitipoope> comisionesByClaOperacion(String claOperacion) {
		List<SocComitipoope> lista = new ArrayList<SocComitipoope>();

		StringBuffer query = new StringBuffer();

		query = query.append("select da ");
		query = query.append("from SocComitipoope da ");
		query = query.append("where da.claOperacion = :claOperacion ");

		log.debug("procesando " + query.toString() + " " + claOperacion);
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("claOperacion", claOperacion);

		lista = consulta.list();

		return lista;
	}	

	public List<SocComitipoope> comisionesUnicosClaComision() {
		Map<String, SocComitipoope> controlMap = new HashMap<String, SocComitipoope>();
		StringBuffer query = new StringBuffer();

		query = query.append(" select da");
		query = query.append(" from SocComitipoope da");

		Query consulta = getSession().createQuery(query.toString());

		List<SocComitipoope> lista = consulta.list();
		List<SocComitipoope> result = new ArrayList<SocComitipoope>();

		for (SocComitipoope socComitipoope : lista) {
			if (!controlMap.containsKey(socComitipoope.getId().getClaComision().trim())) {
				result.add(socComitipoope);
				controlMap.put(socComitipoope.getId().getClaComision().trim(), socComitipoope);
			}
		}
		return result;
	}

	public List<SocComitipoope> comisionesByCodCargo(Integer codCargo) {
		List<SocComitipoope> lista = new ArrayList<SocComitipoope>();
		// whf ojo cambiar o filtrar det_comi
		StringBuffer query = new StringBuffer();

		query = query.append("select da ");
		query = query.append("from SocComitipoope da ");
		query = query.append("where da.id.codCargo = :codCargo ");

		log.debug("procesando " + query.toString() + " codCargo: " + codCargo);
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("codCargo", codCargo);

		lista = consulta.list();

		return lista;
	}

	public SocComitipoope comisionByCodCargoTipoComis(Integer codCargo, String claComision) {
		SocComitipoope socComitipoope = null;

		StringBuffer query = new StringBuffer();

		query = query.append("select da ");
		query = query.append("from SocComitipoope da ");
		query = query.append("where da.id.codCargo = :codCargo ");
		query = query.append("and da.id.claComision = :claComision ");

		log.debug("procesando " + query.toString() + " codCargo: " + codCargo + " claComision: " + claComision);
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("codCargo", codCargo);
		consulta.setParameter("claComision", claComision);
		List lista = consulta.list();

		if (lista.size() > 0) {
			socComitipoope = (SocComitipoope) lista.get(0);
		}
		return socComitipoope;
	}

	public List<SocComitipoope> comisionByTipoCargo(Integer codCargo, String claTipocargo) {
		StringBuffer query = new StringBuffer();

		query = query.append("select da ");
		query = query.append("from SocComitipoope da ");
		query = query.append("where da.id.codCargo = :codCargo ");
		query = query.append("and da.claTipocargo = :claTipocargo ");

		log.debug("procesando " + query.toString() + " codCargo: " + codCargo + " claTipocargo: " + claTipocargo);
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("codCargo", codCargo);
		consulta.setParameter("claTipocargo", claTipocargo);
		List lista = consulta.list();

		return lista;
	}

	public SocComitipoope comisionByCargoClaCuenta(Integer codCargo, String claCuenta) {
		StringBuffer query = new StringBuffer();

		query = query.append("select da ");
		query = query.append("from SocComitipoope da ");
		query = query.append("where da.id.codCargo = :codCargo ");
		query = query.append("and da.claCuenta = :claCuenta ");

		log.debug("procesando " + query.toString() + " codCargo: " + codCargo + " claCuenta: " + claCuenta);
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("codCargo", codCargo);
		consulta.setParameter("claCuenta", claCuenta);
		List lista = consulta.list();

		if (lista.size() == 1) {
			return (SocComitipoope) lista.get(0);
		}
		return null;
	}

	public SocComitipoope comisionByCargoClaComisionopecomi(Integer codCargo, String claComisionopecomi) {
		StringBuffer query = new StringBuffer();

		query = query.append("select da ");
		query = query.append("from SocComitipoope da ");
		query = query.append("where da.id.codCargo = :codCargo ");
		query = query.append("and da.claComisionopecomi = :claComisionopecomi ");

		log.debug("procesando " + query.toString() + " codCargo: " + codCargo + " claComisionopecomi: " + claComisionopecomi);
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("codCargo", codCargo);
		consulta.setParameter("claComisionopecomi", claComisionopecomi);
		List lista = consulta.list();

		if (lista.size() == 1) {
			return (SocComitipoope) lista.get(0);
		}
		return null;
	}

	public List<SocComitipoope> comisionBySctTipocuenta(Integer codCargo, String sctTipocuenta) {
		StringBuffer query = new StringBuffer();

		query = query.append("select da ");
		query = query.append("from SocComitipoope da ");
		query = query.append("where da.id.codCargo = :codCargo ");
		query = query.append("and da.sctTipocuenta = :sctTipocuenta ");

		log.debug("procesando " + query.toString() + " codCargo: " + codCargo + " sctTipocuenta: " + sctTipocuenta);
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("codCargo", codCargo);
		consulta.setParameter("sctTipocuenta", sctTipocuenta);
		List lista = consulta.list();

		return lista;
	}

	public void actualizarComisionParaClaComision(SocComitipoope socComitipoopeIn) {
		if (StringUtils.isBlank(socComitipoopeIn.getDescrip())) {
			throw new BusinessException("Descripción de la comisión inválida.");
		}

		if (StringUtils.isBlank(socComitipoopeIn.getClaTipocargo())) {
			throw new BusinessException("Tipo cargo nulo, comunique a sistemas.");
		}
		
		if (socComitipoopeIn.getValor() == null) {
			throw new BusinessException("Valor de la comisión nulo.");
		}
		
		log.info("Actualizado comision " + socComitipoopeIn.toString());
		
		if (socComitipoopeIn.getClaTipocargo().equals(Constants.CLAVE_TIPOCARGO_PORCENTAJE) || socComitipoopeIn.getClaTipocargo().equals(Constants.CLAVE_TIPOCARGO_DIASCARTA)) {
			if (socComitipoopeIn.getValor().compareTo(BigDecimal.valueOf(100)) > 0 || socComitipoopeIn.getValor().compareTo(BigDecimal.valueOf(0)) < 0) {
				throw new BusinessException("Valor de comisión de tipo porcentaje debe estar entre 0-100.");
			}
		}
		if (socComitipoopeIn.getId() == null) {
			throw new BusinessException("Error interno comunique a sistemas (socComitipoopeIn.getId() nulo).");
		}
		
		List<SocComitipoope> socComitipoopeLista = comisionesByTipoOper(socComitipoopeIn.getId().getClaComision());
		if (socComitipoopeLista.size() == 0) {
			throw new BusinessException("No existen valores para comisión " + socComitipoopeIn.getId().getClaComision() + ", comunique a sistemas.");
		}

		for (SocComitipoope socComitipoope : socComitipoopeLista) {
			socComitipoope.setDescrip(socComitipoopeIn.getDescrip());
			socComitipoope.setValor(socComitipoopeIn.getValor());
			socComitipoope.setComAuditfho(new Date());
			socComitipoope.setComAuditusr(socComitipoopeIn.getComAuditusr());
			socComitipoope.setComAuditwst(socComitipoopeIn.getComAuditwst());

			this.getHibernateTemplate().saveOrUpdate(socComitipoope);
			log.info("Actualizado comision " + socComitipoope.toString());
		}
	}
}
