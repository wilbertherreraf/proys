/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-sirAladi
 * gob.bcb.portal.sirAladi.commons.Servicios
 * 26/07/2011 - 14:35:05
 * Creado por Gustavo Flores
 */
package gob.bcb.bpm.pruebaCU;

import gob.bcb.service.commons.handlerdb.DBSourceHandlerFactory;

import gob.bcb.service.servicioSioc.common.Constants;

import java.lang.reflect.Array;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.SessionFactoryUtils;

/**
 * Clase que contiene los metodos para comunicarse con la capa de bpm y
 * servicios.
 * 
 * @author Gustavo Flores
 * 
 */
public class Servicios {
	private static final Log log = LogFactory.getLog(Servicios.class);

	public static List<Map<String, Object>> ejecutarQuery(String query) {
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		List<Map<String, Object>> resultado = null;
		// log.info("Ejecutando el query: " + query);
		try {
			// Class.forName(DRIVER);
			// con = DriverManager.getConnection(URL, LOGIN, PASSWORD);
			con = DBSourceHandlerFactory.Factory.newInstance(Constants.PROP_ALIAS_SIOC).getHandler().getConnection();
			stmt = con.createStatement();
			rs = stmt.executeQuery(query);
			int nroColumnas = rs.getMetaData().getColumnCount();
			ResultSetMetaData md = rs.getMetaData();
			resultado = new ArrayList<Map<String, Object>>();
			while (rs.next()) {
				Map<String, Object> fila = new LinkedHashMap<String, Object>();
				for (int i = 1; i <= nroColumnas; i++)
					fila.put(md.getColumnLabel(i), rs.getObject(i));
				resultado.add(fila);
			}
			// log.info("Query ejecutado satisfactoriamente");
		} catch (Exception e) {
			log.error("Error al ejecutar el query: " + e.getMessage());
		} finally {
			try {
				if (rs != null)
					rs.close();
			} catch (Exception e1) {
				log.error("Error al cerrar la conexion a DB: " + e1.getMessage());
			}
			try {
				if (stmt != null)
					stmt.close();
			} catch (Exception e1) {
				log.error("Error al cerrar la conexion a DB: " + e1.getMessage());
			}
			try {
				if (con != null)
					con.close();
			} catch (Exception e1) {
				log.error("Error al cerrar la conexion a DB: " + e1.getMessage());
			}
		}
		return resultado;
	}

	public static List<Map<String, Object>> ejecutarQuery(String query, String[] namesColumns) {
		log.info("Consulta nativa : " + query);
		if (!QueryProcessor.isActive()) {
			QueryProcessor.begin();
		}
		Session session = SessionFactoryUtils.getSession(QueryProcessor.getSessionFactory(), false);
		List<Map<String, Object>> resultado = new ArrayList<Map<String, Object>>();
		SQLQuery sQLQuery = session.createSQLQuery(query);
		List result = sQLQuery.list();
		Iterator iter = result.iterator();
		if (!iter.hasNext()) {
			log.info("No objects to display." + query);
			return resultado;
		}

		while (iter.hasNext()) {
			Map<String, Object> fila = new LinkedHashMap<String, Object>();
			Object objeto = iter.next();
			if (objeto != null) {
				Class clazz = objeto.getClass();
				if (clazz.isArray()) {
					// Object[] obj = (Object[]) iter.next();
					int length = Array.getLength(objeto);
					if (length != 0) {
						Object[] obj = (Object[]) objeto;
						// Array.newInstance(wrapperType, length);
						for (int i = 0; i < length; i++) {
							fila.put((i > namesColumns.length ? String.valueOf(i) : namesColumns[i].trim()), obj[i]);
						}
						resultado.add(fila);
					}
				} else {
					fila.put(namesColumns[0], objeto);
					resultado.add(fila);
				}
			} else {
				fila.put(namesColumns[0], objeto);
				resultado.add(fila);
			}

		}
		return resultado;
	}

	public static String getTipoEnt(String codigo) {
		String query = " select cla_entidad" + " from soc_solicitante " + " where sol_codigo = '" + codigo + "' ";

		String tipoEnt = "";

		List<Map<String, Object>> resultado1 = ejecutarQuery(query, "cla_entidad".split(","));
		if (resultado1.size() == 1) {
			for (Map<String, Object> res : resultado1) {
				// log.info("resultado" + res.toString());
				tipoEnt = (String) res.get("cla_entidad");
			}
		} else {
			log.info("Error al obtener tipo de entidad");
		}

		return tipoEnt;
	}

	public static String getCodigoSol(String corr) {
		String query = " select soc_codigo" + " from soc_solicitudes " + " where soc_correlativo = '" + corr + "' ";

		String codigo = "";

		List<Map<String, Object>> resultado1 = ejecutarQuery(query, "soc_codigo".split(","));
		if (resultado1.size() == 1) {
			for (Map<String, Object> res : resultado1) {
				// log.info("resultado" + res.toString());
				codigo = (String) res.get("soc_codigo");
			}
		} else {
			log.info("Error al obtener tipo de entidad");
		}

		return codigo;
	}

	public static String getEsquema(String codigo) {
		String esq = "";

		String query = " select cla_esquema" + " from soc_cuentas " + " where cta_codigo = '" + codigo + "'";

		List<Map<String, Object>> resultado = ejecutarQuery(query, "cla_esquema".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				esq = (String) res.get("cla_esquema");
			}
		} else {
			log.info("Error al obtener esquema de mensaje");
		}

		return esq;
	}

	public static String getAfectable(int codigo) {
		String afec = "";

		String query = " select cta_afectable" + " from soc_cuentassol " + " where cta_codigo = " + codigo;

		List<Map<String, Object>> resultado = ejecutarQuery(query, "cta_afectable".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				log.info("resultado" + res.toString());
				afec = (String) res.get("cta_afectable");
			}
		} else {
			log.info("Error al obtener afectable");
		}

		return afec;
	}
	public static String getValorNombreClave(String clave, String cod) {
		String ctaS = "";

		String query = "SELECT val_nombre " + "FROM soc_valorescla WHERE cla_codigo = '" + clave + "' " + "AND val_codigo = '" + cod + "' ";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "val_nombre".split(","));
		for (Map<String, Object> res : resultado) {
			ctaS = (String) res.get("val_nombre");
		}

		return ctaS;
	}

	public static Integer getMoneda(String moneda) {
		int mon = 0;

		String query = " select val_codigo" + " from soc_valorescla " + " where cla_codigo = 'cla_moneda' " + " and val_nombre = '" + moneda + "' ";

		List<Map<String, Object>> resultado = ejecutarQuery(query, "val_codigo".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				// log.info("resultado" + res.toString());
				mon = Integer.parseInt((res.get("val_codigo")).toString());
			}
		} else {
			log.error("Error al obtener código de moneda " + moneda);
			throw new RuntimeException("Error al obtener código de moneda " + moneda);
		}

		return mon;
	}

	public static Integer getGenITF(Integer codigo) {
		String query = " select gen_itf" + " from soc_cuentassol " + " where cta_codigo = '" + codigo + "'";

		Integer genera = 0;

		List<Map<String, Object>> resultado1 = ejecutarQuery(query, "gen_itf".split(","));
		if (resultado1.size() == 1) {
			for (Map<String, Object> res : resultado1) {
				// log.info("resultado" + res.toString());
				genera = (Integer) res.get("gen_itf");
			}
		}

		return genera;
	}
	public static Integer afectablePorITF(String cta_afectable) {
		String query = " select count(gen_itf) gen_itf " + " from soc_cuentassol " + " where cta_afectable = '" + cta_afectable + "' and gen_itf != 0 ";

		Integer genera = 0;

		List<Map<String, Object>> resultado1 = ejecutarQuery(query, "gen_itf".split(","));
		if (resultado1.size() == 1) {
			for (Map<String, Object> res : resultado1) {
				// log.info("resultado" + res.toString());
				BigDecimal ite_efe = (BigDecimal) res.get("gen_itf");
				//genera = (Integer) res.get("gen_itf");
				if (ite_efe.compareTo(BigDecimal.ZERO) != 0)
					genera =  1;
			}
		}

		return genera;
	}

	public static Integer getTipoInst(String codigo) {
		int tipo = 0;

		String query = " select cla_instrumento" + " from soc_instrumento " + " where ins_codigo = '" + codigo + "' ";

		List<Map<String, Object>> resultado = ejecutarQuery(query, "cla_instrumento".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				// log.info("resultado" + res.toString());
				tipo = Integer.parseInt((res.get("cla_instrumento")).toString());
			}
		} else {
			log.info("Error al obtener tipo de instrumento");
		}

		return tipo;
	}

	public static String getParam(String param) {
		String valor = "";

		String query = "SELECT par_valor " + "FROM soc_parametros WHERE par_codigo = '" + param + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				// log.info("resultado" + res.toString());
				valor = (String) res.get("par_valor");
			}
		} else {
			log.error("Error al obtener parametro inexistente: " + param);
			throw new RuntimeException("Error al obtener parametro inexistente: " + param);
		}

		return valor;
	}

	public static int getCodigoB() {
		int cod = 0;
		int cnt = 0;
		String cntS = "";

		String query = " select count(ben_codigo) as cnt, max(ben_codigo) as cod" + " from soc_benefsreg ";

		List<Map<String, Object>> rrs = ejecutarQuery(query, "cnt, cod".split(","));
		if (rrs.size() == 1) {
			for (Map<String, Object> rr : rrs) {
				log.info("resultado" + rr.toString());
				cntS = rr.get("cnt").toString();
				cnt = Integer.parseInt(cntS);
				if (cnt > 0) {
					cod = (Integer) rr.get("cod");
					cod++;
				} else
					cod = 1;
			}
		} else {
			log.info("Error al obtener correlativo");
		}

		return cod;
	}

	public static BigDecimal getDemanda(Date fecha) {
		BigDecimal total = BigDecimal.valueOf(0.00);

		Calendar fechaAl = GregorianCalendar.getInstance();
		fechaAl.setTime(fecha);
		String strFecha = " mdy(" + (fechaAl.get(Calendar.MONTH) + 1) + "," + fechaAl.get(Calendar.DAY_OF_MONTH) + "," + fechaAl.get(Calendar.YEAR)
				+ ") ";
		String query = " select sum(montosol) as total" + " from soc_bolsin " + " where fecha = " + strFecha + "  and cla_tipsolic in ('G','E') ";
		log.info(query);
		List<Map<String, Object>> resultado = ejecutarQuery(query, "total".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				// log.info("resultado" + res.toString());
				total = (BigDecimal) res.get("total");
			}
		} else {
			log.info("Error al obtener el total vendido");
		}

		return total;
	}

	public static String getComision(String tipo) {
		String comi = "";

		String query = " select val_nombre" + " from soc_valorescla " + " where cla_codigo = 'cla_comision' " + " and val_codigo = '" + tipo + "' ";

		List<Map<String, Object>> resultado = ejecutarQuery(query, "val_nombre".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				log.info("resultado" + res.toString());
				comi = (String) res.get("val_nombre");
			}
		} else {
			log.info("Error al obtener valor de comisi�n");
		}

		return comi;
	}

	/**
	 * retorna las comisiones en moneda bs segun el tipo
	 * 
	 * @param montoUS
	 * @param tipo
	 * @return
	 */
	public static BigDecimal getComisiones(BigDecimal montoUS, String tipo, Integer countSwift) {
		log.info("Calculando comisiones " + montoUS + " tipo: " + tipo + " count swift: " + countSwift);
		BigDecimal montoC = BigDecimal.valueOf(0.00);
		BigDecimal valor = BigDecimal.valueOf(0.00);
		String comision = "";

		// CCUH SIOC V.2
		// R-04 Incluir opciones separadas para IDH, RegalÃƒÂ­as
		// Se crearon nuevos tipos de operaciÃƒÂ³n para estos procesos
		// 02-07-2013
		if (tipo.equals("TCRG") || tipo.equals("TCID")) {
			tipo = "TC";
		}
		BigDecimal tcSus = QueryProcessor.getTipoCambio(34, new Date());
		String query = "select cc.cla_comision, vv.val_nombre " + "from soc_comitipoope cc, soc_valorescla vv "
				+ "where vv.cla_codigo = 'cla_comision' " + "and cc.cla_comision = vv.val_codigo " + "and cc.cla_operacion = '" + tipo + "' ";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "cla_comision, val_nombre".split(","));
		if (resultado.size() > 0) {
			for (Map<String, Object> res : resultado) {
				log.info("resultado " + res.toString());
				valor = BigDecimal.valueOf(Double.parseDouble((String) res.get("val_nombre")));
				comision = (String) res.get("cla_comision");
				if ((comision.trim().equalsIgnoreCase("CTRF") || comision.trim().equalsIgnoreCase("CTRA") || comision.trim().equalsIgnoreCase("CDEX"))) {
					BigDecimal comiUS = montoUS.multiply(valor.divide(BigDecimal.valueOf(100)))
							.divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
					BigDecimal comiBs = comiUS.multiply(tcSus).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
					montoC = montoC.add(comiBs);
				} else if (comision.equals("SWFT"))
					montoC = montoC.add(valor.multiply(BigDecimal.valueOf(countSwift)));
				else
					montoC = montoC.add(valor);
			}
		}
		log.info("Comision[" + montoC + "] por: " + montoUS + " tipo: " + tipo + " count swift: " + countSwift);
		return montoC;
	}

	public static String getSolicitante(String sol) {
		String soli = "";

		String query = " select sol_persona" + " from soc_solicitante " + " where sol_codigo = '" + sol + "'";

		List<Map<String, Object>> resultado = ejecutarQuery(query, "sol_persona".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				log.debug("resultado" + res.toString());
				soli = (String) res.get("sol_persona");
			}
		} else {
			log.info("Error al obtener solicitante");
		}

		return soli;
	}

	public static SocSolicitante getSocSolicitante(String codigo) {
		if (codigo == null || codigo.trim().isEmpty()) {
			return null;
		}
		codigo = codigo.trim();
		SocSolicitante solicitante = null;
		String query = " select sol_codigo,sol_persona,cla_entidad,sol_direccion,sol_plaza,sol_bic,cla_vigente,sol_telefono,sol_fax,usr_codigo,fecha_hora,estacion,sigla,login,sol_nit,sol_factura "
				+ " from soc_solicitante s " + " where s.sol_codigo = '" + codigo + "'";
		List<Map<String, Object>> resultado1 = ejecutarQuery(
				query,
				"sol_codigo,sol_persona,cla_entidad,sol_direccion,sol_plaza,sol_bic,cla_vigente,sol_telefono,sol_fax,usr_codigo,fecha_hora,estacion,sigla,login,sol_nit,sol_factura"
						.split(","));
		if (resultado1.size() > 0) {
			for (Map<String, Object> res : resultado1) {
				solicitante = new SocSolicitante((String) res.get("sol_codigo"), (String) res.get("sol_persona"), (String) res.get("cla_entidad"),
						(String) res.get("sol_direccion"), (String) res.get("sol_plaza"), (String) res.get("sol_bic"),
						(Short) res.get("cla_vigente"), (String) res.get("usr_codigo"), (Date) res.get("fecha_hora"), (String) res.get("estacion"),
						(String) res.get("sigla"));
				solicitante.setSolNit((String) res.get("sol_nit"));
				solicitante.setSolFactura((String) res.get("sol_factura"));
			}
		}

		return solicitante;
	}

	public static Integer getHoraLimite(String opcion) {
		// vd0
		Integer hora = 0;

		String query = "select val_nombre " + "from soc_valorescla " + "where cla_codigo = 'cla_horas' " + "and val_codigo = '" + opcion + "'";

		List<Map<String, Object>> resultado = ejecutarQuery(query, "val_nombre".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				hora = Integer.parseInt((res.get("val_nombre")).toString());
			}
		}

		return hora;
	}

	public static List<SocBolsin> getSocBolsinList(String claEstado, Date fecha, String codIFASolicitante, String tipoSolic) {

		List<SocBolsin> solicitudes = new ArrayList<SocBolsin>();
		SocBolsin solicitudB;

		String query = " select s.*, ss.sol_persona, "
				+ " (select trim(v.val_nombre) from soc_valorescla v where v.cla_codigo = 'cla_tipsolic' and v.val_codigo = s.cla_tipsolic) as cla_tipsolicdesc, "
				+ " (select trim(v.val_nombre) from soc_valorescla v where v.cla_codigo = 'cla_estado' and v.val_codigo = s.cla_estado) as cla_estadodesc "
				+ " from soc_bolsin s, soc_solicitante ss " + " where s.sol_codigo = ss.sol_codigo" + " and s.cla_estado in (" + claEstado + ") ";

		if (fecha != null) {
			Calendar fechaAl = GregorianCalendar.getInstance();
			fechaAl.setTime(fecha);
			String strFecha = " mdy(" + (fechaAl.get(Calendar.MONTH) + 1) + "," + fechaAl.get(Calendar.DAY_OF_MONTH) + ","
					+ fechaAl.get(Calendar.YEAR) + ") ";
			query += " and s.fecha = " + strFecha;
		}
		// whf rq02
		if (!StringUtils.isEmpty(codIFASolicitante)) {
			query += " and s.sol_codigo = '" + codIFASolicitante + "' ";
			if (!StringUtils.isEmpty(tipoSolic)) {
				query += " and s.cla_tipsolic in (" + tipoSolic + ") ";
			}
		} else {
			// whf vd
			// si es nulo viene de un usuario BCB para operaciones bolsin
			if (!StringUtils.isEmpty(tipoSolic))
				query += " and s.cla_tipsolic in (" + tipoSolic + ") ";
		}
		log.info("XXX:$$$$$$$$$$$$$ " + query);
		// log.info("Query ejecutado: " + query);
		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() > 0) {
			for (Map<String, Object> res : resultado) {
				solicitudB = new SocBolsin((String) res.get("soc_codigo"), (String) res.get("sol_codigo"), (Date) res.get("fecha"),
						(String) res.get("corr"), (Integer) res.get("seq"), (Integer) res.get("cuentad"), (BigDecimal) res.get("cotiz"),
						(BigDecimal) res.get("montosol"), (BigDecimal) res.get("montoadj"), (BigDecimal) res.get("montomn"),
						((String) res.get("cla_estado")).charAt(0), (String) res.get("benef"), (String) res.get("usr_codigo"),
						(Date) res.get("fecha_hora"), (String) res.get("estacion"));
				solicitudB.setClaTipsolic((String) res.get("cla_tipsolic"));
				solicitudB.setBolCtamn((String) res.get("bol_ctamn"));
				solicitudB.setBolCtame((String) res.get("bol_ctame"));
				solicitudes.add(solicitudB);
			}
		}
		return solicitudes;
	}

	public static List<Map<String, Object>> obtenerEsquema(String tipoOperacion, String subTipoOperacion) {
		if (StringUtils.isBlank(tipoOperacion) || StringUtils.isBlank(subTipoOperacion)) {
			log.error("Error al obtener esquemas para operacion parametros invalidos [TIPO: " + tipoOperacion + ", subtipo: " + subTipoOperacion
					+ "]");
			throw new RuntimeException("Error al obtener esquemas para operacion parametros invalidos [TIPO: " + tipoOperacion + ", subtipo: "
					+ subTipoOperacion + "]");
		}
		
		// whfr01 glosas		
		String query = "select re.esq_codigo, re.det_codigo, re.cla_cuenta, re.esq_dh, re.esq_definicion, re.cla_glosa_r, re.repetible, ee.glosa_comp "
				+ "from soc_rengesq re, soc_esquemas ee " + "where re.esq_codigo = ee.esq_codigo " + "and ee.cla_operacion = '" + tipoOperacion
				+ "' ";
		query += "and ee.cla_subtipo = '" + subTipoOperacion + "' ";
		query += "order by re.det_codigo ";

		List<Map<String, Object>> resultado = ejecutarQuery(query,
				"esq_codigo, det_codigo, cla_cuenta, esq_dh, esq_definicion, cla_glosa_r, repetible, glosa_comp".split(","));

		if (resultado == null || resultado.size() == 0) {
			log.error("Error al obtener esquemas para operacion " + tipoOperacion + " subtipo: " + subTipoOperacion);
			throw new RuntimeException("Error al obtener esquemas para operacion " + tipoOperacion + " subtipo: " + subTipoOperacion);
		}
		log.info("Esquema size() " + resultado.size() + " tipoOperacion " + tipoOperacion + " subtipo: " + subTipoOperacion + "["
				+ ArrayUtils.toString(resultado) + "]");
		return resultado;
	}
	
}
