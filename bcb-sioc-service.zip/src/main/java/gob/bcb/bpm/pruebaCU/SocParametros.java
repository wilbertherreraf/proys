package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the soc_parametros database table.
 * 
 */
@Entity
@Table(name="soc_parametros")
public class SocParametros implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="par_codigo")
	private String parCodigo;

	private String estacion;

    @Temporal( TemporalType.TIMESTAMP)
	@Column(name="fecha_hora")
	private Date fechaHora;

	@Column(name="par_nombre")
	private String parNombre;

	@Column(name="par_valor")
	private String parValor;

	@Column(name="usr_codigo")
	private String usrCodigo;

    public SocParametros() {
    }

	public String getParCodigo() {
		return this.parCodigo;
	}

	public void setParCodigo(String parCodigo) {
		this.parCodigo = parCodigo;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getParNombre() {
		return this.parNombre;
	}

	public void setParNombre(String parNombre) {
		this.parNombre = parNombre;
	}

	public String getParValor() {
		return this.parValor;
	}

	public void setParValor(String parValor) {
		this.parValor = parValor;
	}

	public String getUsrCodigo() {
		return this.usrCodigo;
	}

	public void setUsrCodigo(String usrCodigo) {
		this.usrCodigo = usrCodigo;
	}

}