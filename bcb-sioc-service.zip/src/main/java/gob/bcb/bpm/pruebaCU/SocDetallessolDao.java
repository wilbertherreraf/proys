/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.bpm.pruebaCU;

import gob.bcb.service.commons.UserSessionHolder;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.pojos.BancoPlaza;
import gob.bcb.service.servicioSioc.pojos.Detallesol;
import gob.bcb.service.servicioSioc.ws.xml.consultasolic.DetalleSolicitud;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;
import gob.bcb.service.servicioTres.model.CuentaMovimiento;
import gob.bcb.service.servicioTres.model.CuentaMovimientoDao;
import gob.bcb.swift.dao.SwfMensajeBean;
import gob.bcb.swift.dao.SwfMttransferBean;
import gob.bcb.swift.model.SwfMensaje;
import gob.bcb.swift.model.SwfMttransfer;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

//import org.hibernate.Query;

/**
 * @author parenas
 * 
 */
@Transactional
public class SocDetallessolDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocDetallessolDao.class);

	public void saveOrUpdate(SocDetallessol pm) {
		pm.setFechaHora(new Date());
		if (UserSessionHolder.get(Constants.AUDIT_USER_ESTACION) != null)
			pm.setEstacion((String) UserSessionHolder.get(Constants.AUDIT_USER_ESTACION));
		if (UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID) != null)
			pm.setUsrCodigo((String) UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID));

		this.getHibernateTemplate().saveOrUpdate(pm);
	}

	public void saveOrUpdateSinAud(SocDetallessol pm) {
		pm.setFechaHora(new Date());

		this.getHibernateTemplate().saveOrUpdate(pm);
	}

	public void eliminarRegs(String codigo) {
		List<SocDetallessol> facts = getDetalles(codigo);
		int i = 0;
		while (facts.size() > 0) {
			SocDetallessol fact = facts.get(0);
			this.getHibernateTemplate().delete(fact);
			facts = getDetalles(codigo);
			i++;
		}
		log.info("Eliminados [ " + i + " ] regs.");
	}

	public List<SocDetallessol> getDetalles(String socCodigo) {
		List<SocDetallessol> lista = new ArrayList<SocDetallessol>();
		StringBuffer query = new StringBuffer();
		query = query.append("select de ");
		query = query.append("from SocDetallessol de ");
		query = query.append("where de.id.socCodigo = :codigo ");
		query = query.append("order by de.id.detCodigo ");

		log.debug("Entre a buscar el objeto con el id: " + socCodigo + " " + query.toString());

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("codigo", socCodigo);

		lista = consulta.list();

		return lista;
	}

	public SocDetallessol getDetalle(String socCodigo, Integer detCodigo) {
		SocDetallessol socDetallessol = null;
		StringBuffer query = new StringBuffer();
		query = query.append(" select de ");
		query = query.append(" from ");
		query = query.append(" SocDetallessol de ");
		query = query.append(" where de.id.socCodigo = :socCodigo ");
		query = query.append(" and de.id.detCodigo = :detCodigo ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("socCodigo", socCodigo);
		consulta.setParameter("detCodigo", detCodigo);

		List lista = consulta.list();
		if (lista.size() > 0) {
			socDetallessol = (SocDetallessol) lista.get(0);
		}
		return socDetallessol;
	}

	/**
	 * Crea el detalle de una solicitud
	 * 
	 * @param solicitud
	 * @param detalle
	 * @param codDetalle
	 * @return
	 */
	public SocDetallessol nuevo(SocSolicitudes solicitud, SocDetallessol detalle, Integer codDetalle) {
		if (codDetalle == null || codDetalle.compareTo(Integer.valueOf(0)) <= 0)
			codDetalle = 1;
		SocDetallessolId socDetallessolId = new SocDetallessolId(solicitud.getSocCodigo(), codDetalle);
		detalle.setId(socDetallessolId);
		saveOrUpdate(detalle);
		return detalle;
	}

	public void nuevo(SocSolicitudes solicitud, List<SocDetallessol> socDetallessolLista) {

		if (socDetallessolLista.size() == 1) {
			nuevo(solicitud, socDetallessolLista.get(0), null);
			return;
		}

		Integer codDetalle = 1;
		for (SocDetallessol detalle : socDetallessolLista) {
			nuevo(solicitud, detalle, codDetalle);
			codDetalle++;
		}
	}

	private SocDetallessol crearActualizar(SocSolicitudes solicitud, SocDetallessol detalle) {
		if (detalle.getId() == null || (detalle.getId().getDetCodigo() == null) || (detalle.getId().getDetCodigo().compareTo(0) == 0)) {
			throw new BusinessException("Codigo Detalle nulo");
		}
		log.debug("Estoy en crearActualizar Detalle  [" + solicitud.getSocCodigo() + ", " + detalle.toString() + "]");
		SocDetallessol socDetallessolOld = getDetalle(solicitud.getSocCodigo(), detalle.getId().getDetCodigo());

		if (socDetallessolOld == null) {
			log.info("Creando nuevo detalle " + solicitud.getSocCodigo() + " -> " + detalle.getId().getDetCodigo());
			detalle.getId().setSocCodigo(solicitud.getSocCodigo());
			detalle.setClaEstadodet("P");
			detalle.setUsrCodigo(solicitud.getUsrCodigo());
			detalle.setFechaHora(new Date());
			detalle.setEstacion(solicitud.getEstacion());

			validarDatos(solicitud, detalle);

			saveOrUpdate(detalle);

			log.debug("Detalle  [" + solicitud.getSocCodigo() + ", " + detalle.getId().getDetCodigo() + "] creado " + detalle.toString());
		} else {

			socDetallessolOld.setBenCodigo(detalle.getBenCodigo());
			socDetallessolOld.setDetMonto(detalle.getDetMonto());
			socDetallessolOld.setCodMoneda(detalle.getCodMoneda());
			socDetallessolOld.setDetMontoord(detalle.getDetMontoord());
			socDetallessolOld.setCodBanco(detalle.getCodBanco());
			socDetallessolOld.setNroCuentabco(detalle.getNroCuentabco());
			socDetallessolOld.setDetCtabenef(detalle.getDetCtabenef());
			socDetallessolOld.setCtaCodigo(detalle.getCtaCodigo());
			socDetallessolOld.setCodBancointer(detalle.getCodBancointer());
			socDetallessolOld.setNroCuentabcointer(detalle.getNroCuentabcointer());
			socDetallessolOld.setDetConcepto(detalle.getDetConcepto());
			socDetallessolOld.setDetInfo(detalle.getDetInfo());
			socDetallessolOld.setDetFacturas(detalle.getDetFacturas());
			socDetallessolOld.setBeneficiario(detalle.getBeneficiario());
			socDetallessolOld.setDetCodttransfer(detalle.getDetCodttransfer());
			socDetallessolOld.setDetFacturas(detalle.getDetFacturas());
			socDetallessolOld.setUsrCodigo(solicitud.getUsrCodigo());
			socDetallessolOld.setFechaHora(new Date());
			socDetallessolOld.setEstacion(solicitud.getEstacion());
			socDetallessolOld.setCodMonedatdet(solicitud.getCodMonedat());

			if ((solicitud.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT))) {
				if (solicitud.getSocTipnegociacion().equals(Constants.CLAVE_TIPNEGOCIA_OPER)) {

				}
			}

			validarDatos(solicitud, socDetallessolOld);

			saveOrUpdate(socDetallessolOld);
			log.debug("Detalle  [" + solicitud.getSocCodigo() + ", " + socDetallessolOld.getId().getDetCodigo() + "] actualizado "
					+ socDetallessolOld.toString());
		}

		return detalle;
	}

	public List<SocDetallessol> crearActualizarDetalles(SocSolicitudes solicitud, List<SocDetallessol> socDetallessolLista) {
		if (socDetallessolLista == null) {
			throw new BusinessException("Lista Detalles beneficiario nulo");
		}

		eliminarRegs(solicitud.getSocCodigo());

		log.info("crearActualizarDetalles " + solicitud.getSocCodigo() + " " + socDetallessolLista.size());
		Integer codDetalle = 1;
		for (SocDetallessol detalle : socDetallessolLista) {
			crearActualizar(solicitud, detalle);
			codDetalle++;
		}
		List<SocDetallessol> socDetallessolListaNew = getDetalles(solicitud.getSocCodigo());
		return socDetallessolListaNew;
	}

	private SocDetallessol fromServicioSiocDetalle(SocSolicitudes socSolicitudes, DetalleSolicitud detalleSolicitud) {
		log.info("Mapeando SocDetallessol de detalleSolicitud " + detalleSolicitud.getCodDetalle());

		SocDetallessol socDetallessol = new SocDetallessol();

		if (detalleSolicitud.getCodDetalle() <= 0) {
			throw new BusinessException("Codigo detalle debe ser mayor a CERO");
		}

		SocDetallessolId socDetallessolId = new SocDetallessolId(socSolicitudes.getSocCodigo(), detalleSolicitud.getCodDetalle());

		socDetallessol.setId(socDetallessolId);

		socDetallessol.setBenCodigo(detalleSolicitud.getCodBeneficiario());
		socDetallessol.setDetMonto(detalleSolicitud.getMontoDetalle());
		socDetallessol.setCodMoneda(Integer.valueOf(detalleSolicitud.getCodMonedaDet()));
		socDetallessol.setDetMontoord(socDetallessol.getDetMonto());
		socDetallessol.setNroCuentabco(detalleSolicitud.getNroCuenta());
		socDetallessol.setCodBancointer(detalleSolicitud.getBancoIntermediario());
		socDetallessol.setNroCuentabcointer(detalleSolicitud.getNroCuentaIntermediario());
		socDetallessol.setCodBanco(detalleSolicitud.getCodBanco());
		socDetallessol.setDetConcepto(socSolicitudes.getDetConcepto());

		String tipoConcepto = socSolicitudes.getTipoConcepto();
		if (!StringUtils.isBlank(tipoConcepto)) {
			if (tipoConcepto.equals("F")) {
				tipoConcepto = "INV";
			}
		}
		socDetallessol.setTipoConcepto(tipoConcepto);

		if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRACTA)) {
			socDetallessol.setCodBancointer(detalleSolicitud.getCodBanco());

			SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
			socSolicitanteDao.setSessionFactory(getSessionFactory());

			SocBenefsDao socBenefsDao = new SocBenefsDao();
			socBenefsDao.setSessionFactory(getSessionFactory());

			SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCodSigep(detalleSolicitud.getCodBanco());
			socDetallessol.setCodBanco(socSolicitante.getSolCodigo());

			// es cta en sistema financiero
			List<CuentasBen> listaCuentasB = socBenefsDao.recuperarCuentasB(socSolicitudes, socDetallessol.getBenCodigo(),
					socSolicitudes.getCodMonedat(), null, socDetallessol.getNroCuentabco(), null, null);

			Map<String, BancoPlaza> mapaCrtl = new HashMap<String, BancoPlaza>();

			for (CuentasBen cuentasBen : listaCuentasB) {
				if (!mapaCrtl.containsKey(String.valueOf(cuentasBen.getCtaAfectable()))) {
					mapaCrtl.put(String.valueOf(cuentasBen.getCtaAfectable()), null);
					// registramos la cta afectable en NroCuentabcointer
					socDetallessol.setNroCuentabcointer(cuentasBen.getCtaAfectable());
				}
			}
			if (mapaCrtl.size() == 0) {
				throw new BusinessException("Cuenta " + socDetallessol.getNroCuentabco() + " inexistente");
			}
			if (mapaCrtl.size() > 1) {
				throw new BusinessException("Cuenta " + socDetallessol.getNroCuentabco()
						+ " con mas de una cta afectable registrada, avise al administrador");
			}
		}
		// registrado
		socDetallessol.setCodBanco((socDetallessol.getCodBanco() != null ? socDetallessol.getCodBanco().trim() : null));
		socDetallessol.setNroCuentabco((socDetallessol.getNroCuentabco() != null ? socDetallessol.getNroCuentabco().trim() : null));
		socDetallessol.setNroCuentabcointer((socDetallessol.getNroCuentabcointer() != null ? socDetallessol.getNroCuentabcointer().trim() : null));

		socDetallessol.setClaEstadodet("P");
		socDetallessol.setBeneficiario(detalleSolicitud.getNomBeneficiario());

		completarDatosDetalle(socSolicitudes, socDetallessol);

		return socDetallessol;
	}

	public List<SocDetallessol> fromServicioSiocDetalles(SocSolicitudes socSolicitudes, List<DetalleSolicitud> detalleSolicitudLista) {
		log.info("Mapeando Lista SocDetallessol de detalleSolicitud " + socSolicitudes.getCodSolicitudorig());

		if (detalleSolicitudLista == null || detalleSolicitudLista.size() == 0) {
			throw new BusinessException("Solicitud sin datos de beneficiarios");
		}

		List<SocDetallessol> socDetallessolLista = new ArrayList<SocDetallessol>();

		// para control de id
		Map<Integer, Integer> ctrlIds = new HashMap<Integer, Integer>();

		for (DetalleSolicitud detalleSolicitud : detalleSolicitudLista) {

			SocDetallessol socDetallessol = fromServicioSiocDetalle(socSolicitudes, detalleSolicitud);
			socDetallessolLista.add(socDetallessol);

			if (!ctrlIds.containsKey(detalleSolicitud.getCodDetalle())) {
				ctrlIds.put(detalleSolicitud.getCodDetalle(), detalleSolicitud.getCodDetalle());
			} else {
				throw new BusinessException("Codigo detalle solicitud " + detalleSolicitud.getCodDetalle() + " duplicada");
			}
		}
		return socDetallessolLista;

	}

	public void validarDatos(SocSolicitudes socSolicitudes, SocDetallessol socDetallessol) {
		if (socDetallessol.getId() == null || (socDetallessol.getId().getDetCodigo() == null)
				|| (socDetallessol.getId().getDetCodigo().compareTo(0) == 0)) {
			throw new BusinessException("Codigo Detalle nulo");
		}

		if (socDetallessol.getCodMoneda() == null) {
			throw new BusinessException("Moneda Detalle " + socDetallessol.getId().getDetCodigo() + " nulo");
		}
		if (!socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_ORDPAG)) {
			if (StringUtils.isBlank(socDetallessol.getBenCodigo())) {
				throw new BusinessException("Codigo beneficiario, Detalle " + socDetallessol.getId().getDetCodigo() + " nulo");
			}
		}

		if (socDetallessol.getDetMonto() == null || socDetallessol.getDetMonto().compareTo(BigDecimal.ZERO) <= 0) {
			throw new BusinessException("Monto operacion, Detalle " + socDetallessol.getId().getDetCodigo() + " invalido");
		}

		if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)) {
			if (StringUtils.isBlank(socDetallessol.getCodBanco())) {
				throw new BusinessException("Codigo banco, Detalle " + socDetallessol.getId().getDetCodigo() + " nulo");
			}

			if (StringUtils.isBlank(socDetallessol.getNroCuentabco())) {
				throw new BusinessException("Nro cuenta beneficiario nulo, Detalle " + socDetallessol.getId().getDetCodigo());
			}

			if (StringUtils.isBlank(socDetallessol.getDetCodttransfer())) {
				throw new BusinessException("Tipo de mensaje swift nulo, Detalle " + socDetallessol.getId().getDetCodigo());
			}
			// if (socDetallessol.getCtaCodigo() == null) {
			// throw new BusinessException("Codigo de cta contable, Detalle " +
			// socDetallessol.getId().getDetCodigo() + " nulo");
			// }
		}
	}

	public List<Detallesol> recuperarListaDetallessol(SocSolicitudes socSolicitudes) {
		List<SocDetallessol> socDetallessolLista = getDetalles(socSolicitudes.getSocCodigo());
		List<Detallesol> detallesolLista = recuperarListaDetallessol(socSolicitudes, socDetallessolLista);
		return detallesolLista;

	}

	public List<Detallesol> recuperarListaDetallessol(SocSolicitudes socSolicitudes, List<SocDetallessol> socDetallessolLista) {
		List<Detallesol> detallesolLista = new ArrayList<Detallesol>();
		for (SocDetallessol socDetallessol : socDetallessolLista) {
			Detallesol detallesol = getDetallesolFromSocDetallesol(socSolicitudes, socDetallessol);
			detallesolLista.add(detallesol);
		}
		return detallesolLista;
	}

	public Detallesol recuperarDetallesol(SocSolicitudes socSolicitudes, SocDetallessol socDetallessol) {
		SocDetallessol socDetallessolOld = getDetalle(socSolicitudes.getSocCodigo(), socDetallessol.getId().getDetCodigo());
		Detallesol detallesol = getDetallesolFromSocDetallesol(socSolicitudes, socDetallessolOld);
		return detallesol;
	}

	public Detallesol getDetallesolFromSocDetallesol(SocSolicitudes socSolicitudes, SocDetallessol socDetallessol) {

		SocBancosDao socBancosDao = new SocBancosDao();
		socBancosDao.setSessionFactory(getSessionFactory());

		SocBenefsDao socBenefsDao = new SocBenefsDao();
		socBenefsDao.setSessionFactory(getSessionFactory());

		SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
		socCuentassolDao.setSessionFactory(getSessionFactory());

		SocOrdenesPagoDao socOrdenesPagoDao = new SocOrdenesPagoDao();
		socOrdenesPagoDao.setSessionFactory(getSessionFactory());

		SwfMensajeBean swfMensajeBean = new SwfMensajeBean();
		swfMensajeBean.setSessionFactory(getSessionFactory());

		GenMonedaDao genMonedaDao = new GenMonedaDao();
		genMonedaDao.setSessionFactory(getSessionFactory());

		SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
		socSolicitanteDao.setSessionFactory(getSessionFactory());

		SocSolicitudctasDao socSolicitudctasDao = new SocSolicitudctasDao();
		socSolicitudctasDao.setSessionFactory(getSessionFactory());
		/*****************************/
		log.debug("recuperando datos beneficiario " + socSolicitudes.getSocCodigo() + " - " + socDetallessol.getId().getDetCodigo());

		Detallesol detallesol = new Detallesol();

		detallesol.setSocCodigo(socSolicitudes.getSocCodigo());
		detallesol.setBenCodigo(socDetallessol.getBenCodigo());
		detallesol.setSocDetallessol(socDetallessol);

		Beneficiario beneficiario = socBenefsDao.recuperarBeneficiario(socSolicitudes, socDetallessol);

		detallesol.setBeneficiarioDet(new Beneficiario());

		detallesol.setBenNombre(socDetallessol.getBeneficiario());

		if (beneficiario != null) {
			detallesol.setBeneficiarioDet(beneficiario);
			detallesol.setBenNombre(beneficiario.getBenNombre());
		}

		detallesol.setDetConcepto(socDetallessol.getDetConcepto());
		detallesol.setCtaCodigo(socDetallessol.getCtaCodigo());

		detallesol.setCodMoneda(socDetallessol.getCodMoneda());

		GenMoneda genMoneda = genMonedaDao.findByCodMoneda(socDetallessol.getCodMoneda());

		detallesol.setMoneda(genMoneda.getMonSigla());

		detallesol.setCodBanco(socDetallessol.getCodBanco());
		detallesol.setNroCuentabcointer(socDetallessol.getNroCuentabcointer());

		if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)) {
			// SocCuentassol socCuentassol =
			// socCuentassolDao.cuentaBeneficiario(socSolicitudes,
			// socDetallessol);
			SocSolicitudctas socSolicitudctas = socSolicitudctasDao.getCuenta(socSolicitudes.getSocCodigo(), Constants.COD_CLAVE_BENEFMT, null, null,
					null, null);
			SocCuentassol socCuentassol = null;

			if (socSolicitudctas != null) {
				socCuentassol = socCuentassolDao.getByAfectable(socSolicitudctas.getCtaAfectable());
			}

			if (socCuentassol == null) {
				socCuentassol = socCuentassolDao.getSocCuentasolBanqueroExt(socSolicitudes, socSolicitudes.getCodMonedat(), null);
			}
			detallesol.setSocCuentassol(new SocCuentassol());

			if (socCuentassol != null) {
				detallesol.setSocCuentassol(socCuentassol);
			}

			BancoPlaza bancoPlaza = socBancosDao.bancoPlazaByCod(detallesol.getCodBanco());
			if (bancoPlaza == null) {
				bancoPlaza = new BancoPlaza();
			}
			detallesol.setBcoNombre(bancoPlaza.getBcoNombre());

			detallesol.setBancoPlaza(bancoPlaza);

			BancoPlaza bancoPlazainter = socBancosDao.bancoPlazaByCod(detallesol.getCodBancointer());

			if (bancoPlazainter == null) {
				bancoPlazainter = new BancoPlaza();
			}

			detallesol.setBancoPlazainter(bancoPlazainter);

			SwfMttransferBean swfMttransferBean = new SwfMttransferBean();
			swfMttransferBean.setSessionFactory(getSessionFactory());

			SwfMttransfer swfMttransfer = new SwfMttransfer();
			if (socDetallessol.getDetCodttransfer() != null) {
				swfMttransfer = swfMttransferBean.findByCodigo(socDetallessol.getDetCodttransfer());
			}
			if (swfMttransfer == null) {
				swfMttransfer = new SwfMttransfer();
			}

			SwfMensaje swfMensaje = swfMensajeBean.findByCodoperacion(socDetallessol.getId().getSocCodigo(), socDetallessol.getId().getDetCodigo());
			if (swfMensaje == null) {
				swfMensaje = new SwfMensaje();
			}
			detallesol.setSwfMensaje(swfMensaje);
			detallesol.setSwfMttransfer(swfMttransfer);

		} else if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRACTA)) {

			SocCuentassol socCuentassol = socCuentassolDao.getByAfectable(socDetallessol.getNroCuentabcointer());
			detallesol.setSocCuentassol(new SocCuentassol());

			if (socCuentassol != null) {
				detallesol.setSocCuentassol(socCuentassol);
			}

			SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCodigo(detallesol.getCodBanco());
			if (socSolicitante == null) {
				socSolicitante = new SocSolicitante();
			}
			detallesol.setBcoNombre(socSolicitante.getSolPersona());

		} else if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_ORDPAG)) {
			if (!StringUtils.isBlank(socDetallessol.getId().getSocCodigo())) {
				SocOrdenesPago socOrdenesPago = socOrdenesPagoDao.getOrdenBySocCod(socDetallessol.getId().getSocCodigo(), socDetallessol.getId()
						.getDetCodigo());

				if (socOrdenesPago != null) {
					detallesol.setSocOrdenesPago(socOrdenesPago);
				}
			}
		}

		return detallesol;
	}

	public SocDetallessol completarDatosDetalle(SocSolicitudes socSolicitudes, SocDetallessol socDetallessol) {
		SocBenefsDao socBenefsDao = new SocBenefsDao();
		socBenefsDao.setSessionFactory(getSessionFactory());

		SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
		socCuentassolDao.setSessionFactory(getSessionFactory());

		log.info("En completar datos detalle " + socDetallessol.getBenCodigo());

		if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)) {
			List<CuentasBen> listaCuentasB = socBenefsDao.cuentasBenefExterior(socSolicitudes.getSolCodigo(), socDetallessol.getBenCodigo(), null,
					socSolicitudes.getCodMonedat(), socDetallessol.getCodBanco(), socDetallessol.getNroCuentabco(), null, null, null, true);

			if (listaCuentasB.size() > 0) {
				socDetallessol.setCtaCodigo(listaCuentasB.get(0).getCtaCodigoCont());
				socDetallessol.setDetInfo(listaCuentasB.get(0).getCtaInfo() !=null ? listaCuentasB.get(0).getCtaInfo().trim():null);
				socDetallessol.setCodBancointer(listaCuentasB.get(0).getBcoCodigoI());
				// seteo del numero de cuenta si el bco del beneficiario es
				// reconocido por el mismo
				socDetallessol.setNroCuentabcointer(listaCuentasB.get(0).getPlaNroCuenta() != null ? listaCuentasB.get(0).getPlaNroCuenta().trim():null);

				if (StringUtils.isBlank(listaCuentasB.get(0).getClaEsquema())) {
					throw new BusinessException("Cta de beneficario sin tipo de esquema swift, benef: " + socDetallessol.getBenCodigo() + " moneda: "
							+ socSolicitudes.getCodMonedat() + " banco: " + socDetallessol.getCodBanco());
				}
				socDetallessol.setDetCodttransfer(listaCuentasB.get(0).getClaEsquema());
			} else {
				log.info("XXX: AVISO NULOOOOOOOOOOOOO ");
			}
		} else if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRACTA)) {
			// capturamos el codsolicitante de la cta movimiento
			SocCuentassol socCuentassol = socCuentassolDao.getByAfectable(socDetallessol.getNroCuentabcointer());

			if (socCuentassol == null) {
				throw new BusinessException("Cta afectable no registrada en socCuentassol " + socDetallessol.getNroCuentabcointer());
			}

			CuentaMovimientoDao cuentaMovimientoDao = new CuentaMovimientoDao();
			cuentaMovimientoDao.setSessionFactory(SiocCoinService.getSessionFactory());

			CuentaMovimiento cuentaMovimiento = cuentaMovimientoDao.getCuentaMovimiento(socCuentassol.getCtaMovimiento());
			socDetallessol.setCodBanco(cuentaMovimiento.getCodPersona());

		} else if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_ORDPAG)) {

			List<CuentasBen> listaCuentasB = socBenefsDao.recuperarCuentasB(socSolicitudes, socDetallessol.getBenCodigo(),
					socSolicitudes.getCodMonedat(), socDetallessol.getCodBanco(), socDetallessol.getNroCuentabco(), null, null);

			if (listaCuentasB == null || listaCuentasB.size() > 0) {
				socDetallessol.setCodBanco(listaCuentasB.get(0).getBcoCodigo());
				socDetallessol.setCtaCodigo(listaCuentasB.get(0).getCtaCodigoCont());
				socDetallessol.setNroCuentabcointer(listaCuentasB.get(0).getCtaAfectable());
			}
		} else if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRADELEXT)) {
			// capturamos el codsolicitante de la cta movimiento
			SocCuentassol socCuentassol = socCuentassolDao.getByAfectable(socDetallessol.getNroCuentabcointer());

			if (socCuentassol == null) {
				throw new BusinessException("Cta afectable no registrada en socCuentassol " + socDetallessol.getNroCuentabcointer());
			}

			CuentaMovimientoDao cuentaMovimientoDao = new CuentaMovimientoDao();
			cuentaMovimientoDao.setSessionFactory(SiocCoinService.getSessionFactory());

			CuentaMovimiento cuentaMovimiento = cuentaMovimientoDao.getCuentaMovimiento(socCuentassol.getCtaMovimiento());
			socDetallessol.setCodBanco(cuentaMovimiento.getCodPersona());
		}

		return socDetallessol;
	}
}
