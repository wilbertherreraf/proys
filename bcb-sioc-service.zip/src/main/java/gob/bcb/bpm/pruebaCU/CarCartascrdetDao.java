package gob.bcb.bpm.pruebaCU;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

import gob.bcb.core.utils.UtilsDate;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.pojos.Detallesol;

@Transactional
public class CarCartascrdetDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(CarCartascrdetDao.class);

	public void saveOrUpdate(CarCartascrdet pm) {
		log.info("Saving or updating " + pm);
		pm.setCcdAuditfho(new Date());

		this.getHibernateTemplate().saveOrUpdate(pm);
	}

	public CarCartascrdet findByCodcartacrNroccreddet(String codcartacr, Integer nroccreddet) throws BusinessException {

		StringBuffer query = new StringBuffer();
		query = query.append("select cc ");
		query = query.append("from CarCartascrdet cc ");
		query = query.append("where cc.id.ccdCodcartacr = :ccdCodcartacr ");
		query = query.append("and cc.id.ccdNroccreddet = :ccdNroccreddet ");
		query = query.append("and cc.ccdEstregistro = 'V' ");

		// log.info("procesando carta det " + codcartacr + ", nroccreddet: " +
		// nroccreddet + " -> " + query.toString());
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("ccdCodcartacr", codcartacr);
		consulta.setParameter("ccdNroccreddet", nroccreddet);

		List<CarCartascrdet> lista = consulta.list();

		if (lista.size() > 0) {
			return lista.get(0);
		}

		throw new BusinessException("Registro Cartascr detalle inexistente " + codcartacr + ", nroccreddet: " + nroccreddet);
	}

	public List<CarCartascrdet> findByCodcartacr(String codcartacr) throws BusinessException {

		StringBuffer query = new StringBuffer();
		query = query.append("select cc ");
		query = query.append("from CarCartascrdet cc ");
		query = query.append("where cc.id.ccdCodcartacr = :ccdCodcartacr ");
		query = query.append("and cc.ccdEstregistro = 'V' ");

		// log.info("procesando carta det: " + codcartacr + " -> " + query.toString());
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("ccdCodcartacr", codcartacr);

		List<CarCartascrdet> lista = consulta.list();

		return lista;
	}

	public CarCartascrdet findByCodcartacrCcdTipomov(String codcartacr, String ccdTipomov, String ccdTipoemision) throws BusinessException {

		StringBuffer query = new StringBuffer();
		query = query.append("select cc ");
		query = query.append("from CarCartascrdet cc ");
		query = query.append("where cc.id.ccdCodcartacr = :ccdCodcartacr ");
		// query = query.append("and cc.ccdTipomov = :ccdTipomov ");
		query = query.append("and cc.ccdTipoemision = :ccdTipoemision ");
		query = query.append("and cc.ccdEstregistro = 'V' ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("ccdCodcartacr", codcartacr);
		// consulta.setParameter("ccdTipomov", ccdTipomov);
		consulta.setParameter("ccdTipoemision", ccdTipoemision);

		List<CarCartascrdet> lista = consulta.list();

		if (lista.size() == 1) {
			return lista.get(0);
		}

		throw new BusinessException("Registro inexistente con (" + lista.size() + ") registros encontrados para: " + codcartacr + ", ccdTipomov: " + ccdTipomov
				+ ", ccdTipoemision: " + ccdTipoemision);
	}

	public CarCartascrdet findByCodcartacrCcdTipomov(String codcartacr, String ccdTipomov, String ccdTipoemision, String ccdEstmovccred) throws BusinessException {

		StringBuffer query = new StringBuffer();
		query = query.append("select cc ");
		query = query.append("from CarCartascrdet cc ");
		query = query.append("where cc.id.ccdCodcartacr = :ccdCodcartacr ");
		// query = query.append("and cc.ccdTipomov = :ccdTipomov ");
		query = query.append("and cc.ccdEstmovccred = :ccdEstmovccred ");
		query = query.append("and cc.ccdTipoemision = :ccdTipoemision ");
		query = query.append("and cc.ccdEstregistro = 'V' ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("ccdCodcartacr", codcartacr);
		// consulta.setParameter("ccdTipomov", ccdTipomov);
		consulta.setParameter("ccdEstmovccred", ccdEstmovccred);
		consulta.setParameter("ccdTipoemision", ccdTipoemision);

		List<CarCartascrdet> lista = consulta.list();

		if (lista.size() == 1) {
			return lista.get(0);
		}

		throw new BusinessException(
				"Registro inexistente, encontrados(" + lista.size() + ") regs. para: " + codcartacr + ", ccdTipomov: " + ccdTipomov + " ccdEstmovccred: " + ccdEstmovccred);
	}

	public CarCartascrdet findByCodcartacrEstmovccred(String codcartacr, String ccdEstmovccred) throws BusinessException {

		StringBuffer query = new StringBuffer();
		query = query.append("select cc ");
		query = query.append("from CarCartascrdet cc ");
		query = query.append("where cc.id.ccdCodcartacr = :ccdCodcartacr ");
		query = query.append("and cc.ccdEstmovccred = :ccdEstmovccred ");
		query = query.append("and cc.ccdEstregistro = 'V' ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("ccdCodcartacr", codcartacr);
		consulta.setParameter("ccdEstmovccred", ccdEstmovccred);

		List<CarCartascrdet> lista = consulta.list();
		if (lista.size() == 1) {
			return lista.get(0);
		}

		throw new BusinessException("Encontrados(" + lista.size() + ") registros para: " + codcartacr + ", ccdEstmovccred: " + ccdEstmovccred);
	}

	/**
	 * Retorna un entero si existe algun registro en estado diferente a autorizado
	 * 
	 * @param codcartacr
	 *            codigo de la carta
	 * @return CERO si no existe pendientes, o el codigo secuencial del registro
	 *         detalle
	 * @throws BusinessException
	 */
	public Integer existePagoEnmiendaPendiente(String codcartacr) throws BusinessException {

		StringBuffer query = new StringBuffer();
		query = query.append("select cd ");
		query = query.append("from CarCartascrdet cd ");
		query = query.append("where cd.id.ccdCodcartacr = :ccdCodcartacr ");
		query = query.append("and cd.ccdEstmovccred != :ccdEstmovccred ");
		query = query.append("and cd.ccdEstregistro = 'V' ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("ccdCodcartacr", codcartacr);
		consulta.setParameter("ccdEstmovccred", Constants.CLAVE_CCRED_ESTMOVDETALLE_AUTORIZADO);

		List<CarCartascrdet> lista = consulta.list();

		if (lista.size() == 1) {
			return lista.get(0).getId().getCcdNroccreddet();
		}
		if (lista.size() == 0) {
			return 0;
		}

		throw new BusinessException("Encontrados(" + lista.size() + ") registros para: " + codcartacr + ", con estados inconsistentes, avise al administrador.");
	}

	public Integer nextNroCorrDetalle(String ccdCodcartacr) {
		Integer maxDet = Integer.valueOf(0);
		StringBuffer query = new StringBuffer();
		query = query.append("select max(cc.id.ccdNroccreddet) ");
		query = query.append("from CarCartascrdet cc ");
		query = query.append("where cc.id.ccdCodcartacr = :ccdCodcartacr ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("ccdCodcartacr", ccdCodcartacr);

		log.info("Entre a generar ccdCodcartacr " + consulta.toString());

		List result = consulta.list();
		if (result.size() > 0)
			maxDet = (Integer) result.get(0);

		if (maxDet == null)
			maxDet = 0;
		maxDet++;
		return maxDet;
	}

	public List<CarCartascrdet> findByTipoemision(String ccdCodcartacr, String ccdTipoemision) {
		StringBuffer query = new StringBuffer();

		query = query.append("SELECT cd ");
		query = query.append("FROM CarCartascrdet cd ");
		query = query.append("WHERE cd.id.ccdCodcartacr = :ccdCodcartacr ");
		// query = query.append("and cd.ccdTipomov = :ccdTipomov ");
		query = query.append("and cd.ccdTipoemision = :ccdTipoemision ");
		// query = query.append("and cd.ccdEstmovccred = :ccdEstmovccred ");
		query = query.append("and cd.ccdEstregistro = 'V' ");

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("ccdCodcartacr", ccdCodcartacr);
		consulta.setParameter("ccdTipoemision", ccdTipoemision);
		// consulta.setParameter("ccdEstmovccred",
		// Constants.CLAVE_CCRED_ESTMOVDETALLE_AUTORIZADO);

		List result = consulta.list();
		return result;
	}

	public BigDecimal sumaPagos(String ccdCodcartacr) {

		List<CarCartascrdet> lista = findByTipoemision(ccdCodcartacr, Constants.CLAVE_CCRED_TIPOEMISION_PAGO);
		BigDecimal total = BigDecimal.ZERO;

		for (CarCartascrdet carCartascrdet : lista) {
			if (carCartascrdet.getCcdEstmovccred().equals(Constants.CLAVE_CCRED_ESTMOVDETALLE_AUTORIZADO)) {
				total = total.add(carCartascrdet.getCcdMontotrans());
			}
		}

		return total;
	}

	public CarCartascrdet findByCodCartaSocCodigo0(String ccdCodcartacr, String ccdSoccodigo) throws BusinessException {

		StringBuffer query = new StringBuffer();
		query = query.append("select cc ");
		query = query.append("from CarCartascrdet cc ");
		query = query.append("WHERE cc.id.ccdCodcartacr = :ccdCodcartacr ");
		query = query.append("and cc.ccdSoccodigo = :ccdSoccodigo ");
		query = query.append("and cc.ccdEstregistro = 'V' ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("ccdCodcartacr", ccdCodcartacr);
		consulta.setParameter("ccdSoccodigo", ccdSoccodigo);

		List<CarCartascrdet> lista = consulta.list();

		if (lista.size() == 1) {
			return lista.get(0);
		}

		throw new BusinessException("Registro Cartascr detalle inexistente " + ccdSoccodigo + ", ccdCodcartacr: " + ccdCodcartacr);
	}

	public CarCartascrdet findBySocCodigoDetcodigo(String ccdSoccodigo, Integer ccdDetcodigo) throws BusinessException {

		StringBuffer query = new StringBuffer();
		query = query.append("select cc ");
		query = query.append("from CarCartascrdet cc ");
		query = query.append("where cc.ccdSoccodigo = :ccdSoccodigo ");
		query = query.append("and cc.ccdDetcodigo = :ccdDetcodigo ");
		query = query.append("and cc.ccdEstregistro = 'V' ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("ccdSoccodigo", ccdSoccodigo);
		consulta.setParameter("ccdDetcodigo", ccdDetcodigo);

		List<CarCartascrdet> lista = consulta.list();

		if (lista.size() > 0) {
			return lista.get(0);
		}

		throw new BusinessException("Registro Cartascr detalle inexistente " + ccdSoccodigo + ", ccdDetcodigo: " + ccdDetcodigo);
	}

	public CarCartascrdet findBySocCodigoDetcodigoEstDet(String ccdSoccodigo, Integer ccdDetcodigo, String ccdEstmovccred) throws BusinessException {

		StringBuffer query = new StringBuffer();
		query = query.append("select cc ");
		query = query.append("from CarCartascrdet cc ");
		query = query.append("where cc.ccdSoccodigo = :ccdSoccodigo ");
		query = query.append("and cc.ccdDetcodigo = :ccdDetcodigo ");
		query = query.append("and cc.ccdEstmovccred = :ccdEstmovccred ");
		query = query.append("and cc.ccdEstregistro = 'V' ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("ccdSoccodigo", ccdSoccodigo);
		consulta.setParameter("ccdDetcodigo", ccdDetcodigo);
		consulta.setParameter("ccdEstmovccred", ccdEstmovccred);

		List<CarCartascrdet> lista = consulta.list();

		if (lista.size() > 0) {
			return lista.get(0);
		}

		throw new BusinessException("Carta de credito inexistente para solicitud: " + ccdSoccodigo + " o con estado invalido.");
	}

	public CarCartascrdet findBySocCodigo(String ccdSoccodigo) throws BusinessException {

		StringBuffer query = new StringBuffer();
		query = query.append("select cc ");
		query = query.append("from CarCartascrdet cc ");
		query = query.append("where cc.ccdSoccodigo = :ccdSoccodigo ");
		query = query.append("and cc.ccdEstregistro = 'V' ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("ccdSoccodigo", ccdSoccodigo);

		List<CarCartascrdet> lista = consulta.list();

		if (lista.size() == 1) {
			return lista.get(0);
		}

		throw new BusinessException("Carta de credito inexistente para solicitud: " + ccdSoccodigo);
	}

	public List<CarCartascrdet> findListaBySocCodigo(String ccdSoccodigo) throws BusinessException {

		StringBuffer query = new StringBuffer();
		query = query.append("select cc ");
		query = query.append("from CarCartascrdet cc ");
		query = query.append("where cc.ccdSoccodigo = :ccdSoccodigo ");
		query = query.append("and cc.ccdEstregistro = 'V' ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("ccdSoccodigo", ccdSoccodigo);

		List<CarCartascrdet> lista = consulta.list();

		return lista;
	}

	public CarCartascrdet findBySocCodigoEstDet(String ccdSoccodigo, String ccdEstmovccred) throws BusinessException {

		StringBuffer query = new StringBuffer();
		query = query.append("select cc ");
		query = query.append("from CarCartascrdet cc ");
		query = query.append("where cc.ccdSoccodigo = :ccdSoccodigo ");
		query = query.append("and cc.ccdEstmovccred = :ccdEstmovccred ");
		query = query.append("and cc.ccdEstregistro = 'V' ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("ccdSoccodigo", ccdSoccodigo);
		consulta.setParameter("ccdEstmovccred", ccdEstmovccred);

		List<CarCartascrdet> lista = consulta.list();

		if (lista.size() == 1) {
			return lista.get(0);
		}

		throw new BusinessException("Registro detalle inexistente " + ccdSoccodigo + " estado " + ccdEstmovccred);
	}

	public BigDecimal totalMontoCarta(String ccdCodcartacr) {
		List<CarCartascrdet> lista = emisionesCarta(ccdCodcartacr);

		BigDecimal total = BigDecimal.ZERO;

		for (CarCartascrdet carCartascrdet : lista) {
			if (carCartascrdet.getCcdEstmovccred().equals(Constants.CLAVE_CCRED_ESTMOVDETALLE_AUTORIZADO))
				if (carCartascrdet.getCcdTipoemision().equals(Constants.CLAVE_CCRED_TIPOEMISION_EMISION)
						|| carCartascrdet.getCcdTipoemision().equals(Constants.CLAVE_CCRED_TIPOEMISION_INCREMENTO)) {
					total = total.add(carCartascrdet.getCcdMontotrans());
				} else if (carCartascrdet.getCcdTipoemision().equals(Constants.CLAVE_CCRED_TIPOEMISION_DECREMENTO)) {
					total = total.subtract(carCartascrdet.getCcdMontotrans());
				}
		}

		return total;
	}

	public List<CarCartascrdet> emisionesCarta(String ccdCodcartacr) {
		StringBuffer query = new StringBuffer();
		query = query.append("select cc ");
		query = query.append("from CarCartascrdet cc ");
		query = query.append("where cc.id.ccdCodcartacr = :ccdCodcartacr ");
		// query = query.append("and cc.ccdEstmovccred = :ccdEstmovccred ");
		query = query.append("and cc.ccdEstregistro = 'V' ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("ccdCodcartacr", ccdCodcartacr);
		// consulta.setParameter("ccdEstmovccred", ccdEstmovccred);

		List<CarCartascrdet> lista = consulta.list();

		List<CarCartascrdet> carCartascrdetLista = new ArrayList<CarCartascrdet>();
		for (CarCartascrdet carCartascrdet : lista) {
			if (carCartascrdet.getCcdTipoemision().equals(Constants.CLAVE_CCRED_TIPOEMISION_EMISION)
					|| carCartascrdet.getCcdTipoemision().equals(Constants.CLAVE_CCRED_TIPOEMISION_INCREMENTO)
					|| carCartascrdet.getCcdTipoemision().equals(Constants.CLAVE_CCRED_TIPOEMISION_DECREMENTO)
					|| carCartascrdet.getCcdTipoemision().equals(Constants.CLAVE_CCRED_TIPOEMISION_MODIFICACION)
					|| carCartascrdet.getCcdTipoemision().equals(Constants.CLAVE_CCRED_TIPOEMISION_AMPLIACION)
					|| carCartascrdet.getCcdTipoemision().equals(Constants.CLAVE_CCRED_TIPOEMISION_REDUCCION)) {
				carCartascrdetLista.add(carCartascrdet);
			}
		}

		return carCartascrdetLista;
	}

	public BigDecimal totalMontoCartaAFecha(String ccdCodcartacr, Date ccdFechacont) {
		StringBuffer query = new StringBuffer();
		query = query.append("select cc ");
		query = query.append("from CarCartascrdet cc ");
		query = query.append("where cc.id.ccdCodcartacr = :ccdCodcartacr ");
		query = query.append("and cc.ccdEstmovccred = :ccdEstmovccred ");
		query = query.append("and cc.ccdFechacont <= :ccdFechacont ");
		// query = query.append("and cc.ccdTipomov = :ccdTipomov ");
		query = query.append("and cc.ccdEstregistro = 'V' ");

		// log.info("procesando carta det: " + ccdCodcartacr + " -> " +
		// query.toString());
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("ccdCodcartacr", ccdCodcartacr);
		consulta.setParameter("ccdEstmovccred", Constants.CLAVE_CCRED_ESTMOVDETALLE_AUTORIZADO);
		consulta.setDate("ccdFechacont", ccdFechacont);
		// consulta.setParameter("ccdTipomov",
		// Constants.CLAVE_CCRED_TIPOMOVDETALLE_APERTURA);

		List<CarCartascrdet> lista = consulta.list();

		BigDecimal total = BigDecimal.ZERO;

		for (CarCartascrdet carCartascrdet : lista) {
			if (carCartascrdet.getCcdTipoemision().equals(Constants.CLAVE_CCRED_TIPOEMISION_EMISION)
					|| carCartascrdet.getCcdTipoemision().equals(Constants.CLAVE_CCRED_TIPOEMISION_INCREMENTO)) {
				total = total.add(carCartascrdet.getCcdMontotrans());
			} else if (carCartascrdet.getCcdTipoemision().equals(Constants.CLAVE_CCRED_TIPOEMISION_DECREMENTO)) {
				total = total.subtract(carCartascrdet.getCcdMontotrans());
			}
		}

		return total;
	}

	public BigDecimal totalPagosCartaAFecha(String ccdCodcartacr, Date ccdFechacont) {
		StringBuffer query = new StringBuffer();

		query = query.append("SELECT sum(cc.ccdMontotrans) ");
		query = query.append("FROM CarCartascrdet cc ");
		query = query.append("WHERE cc.id.ccdCodcartacr = :ccdCodcartacr ");
		// query = query.append("and cc.ccdTipomov = :ccdTipomov ");
		query = query.append("and cc.ccdFechacont <= :ccdFechacont ");
		query = query.append("and cc.ccdEstmovccred = :ccdEstmovccred ");
		query = query.append("and cc.ccdEstregistro = 'V' ");

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("ccdCodcartacr", ccdCodcartacr);
		consulta.setDate("ccdFechacont", ccdFechacont);
		// consulta.setParameter("ccdTipomov",
		// Constants.CLAVE_CCRED_TIPOMOVDETALLE_PAGO);
		consulta.setParameter("ccdEstmovccred", Constants.CLAVE_CCRED_ESTMOVDETALLE_AUTORIZADO);

		List<CarCartascrdet> lista = consulta.list();

		BigDecimal total = BigDecimal.ZERO;

		for (CarCartascrdet carCartascrdet : lista) {
			if (carCartascrdet.getCcdTipoemision().equals(Constants.CLAVE_CCRED_TIPOEMISION_PAGO)) {
				total = total.add(carCartascrdet.getCcdMontotrans());
			}
		}

		return total;
	}

	public Integer ultimoRegistroDeVctoFecha(String ccdCodcartacr) {
		StringBuffer query = new StringBuffer();

		query = query.append("SELECT cc ");
		query = query.append("FROM CarCartascrdet cc ");
		query = query.append("WHERE cc.id.ccdCodcartacr = :ccdCodcartacr ");
		// query = query.append("and cc.ccdTipomov = :ccdTipomov ");
		query = query.append("and cc.ccdEstmovccred = :ccdEstmovccred ");
		query = query.append("and cc.ccdEstregistro = 'V' ");
		query = query.append("order by cc.id.ccdNroccreddet ");

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("ccdCodcartacr", ccdCodcartacr);
		// consulta.setParameter("ccdTipomov",
		// Constants.CLAVE_CCRED_TIPOMOVDETALLE_PAGO);
		consulta.setParameter("ccdEstmovccred", Constants.CLAVE_CCRED_ESTMOVDETALLE_AUTORIZADO);

		List<CarCartascrdet> lista = consulta.list();

		Integer ccdDetcodigo = 0;
		Date fechaVcto = null;

		for (CarCartascrdet carCartascrdet : lista) {
			if (!carCartascrdet.getCcdTipoemision().equals(Constants.CLAVE_CCRED_TIPOEMISION_PAGO)) {
				if (fechaVcto == null) {
					fechaVcto = carCartascrdet.getCcdFechacargo();
					ccdDetcodigo = carCartascrdet.getId().getCcdNroccreddet();
				}

				if (UtilsDate.compara(fechaVcto, carCartascrdet.getCcdFechacargo()) != 0) {
					fechaVcto = carCartascrdet.getCcdFechacargo();
					ccdDetcodigo = carCartascrdet.getId().getCcdNroccreddet();
				}
			}
		}

		return ccdDetcodigo;
	}

	public List<Detallesol> obtenerEmisionesCarta(String ccdCodcartacr) {
		List<Detallesol> detallesolLista = new ArrayList<Detallesol>();
		if (StringUtils.isBlank(ccdCodcartacr)) {
			return detallesolLista;
		}

		SocValoresclaDao socValoresclaDao = new SocValoresclaDao();
		socValoresclaDao.setSessionFactory(getSessionFactory());

		List<CarCartascrdet> carCartascrdetLista = emisionesCarta(ccdCodcartacr);

		for (CarCartascrdet carCartascrdet : carCartascrdetLista) {
			Detallesol detallesol = new Detallesol();
			detallesol.setCarCartascrdet(carCartascrdet);

			SocValorescla socValorescla = socValoresclaDao.getValoresByCod(Constants.CVE_ESTADO_OPERACION_CARTACREDITO, carCartascrdet.getCcdEstmovccred());
			detallesol.setSocValorescla(socValorescla);

			SocValorescla socValorescla2 = socValoresclaDao.getValoresByCod(Constants.CVE_TIPOEMISION, carCartascrdet.getCcdTipoemision());
			detallesol.setSocValorescla2(socValorescla2);

			detallesolLista.add(detallesol);
		}
		return detallesolLista;
	}

	public List<Detallesol> obtenerPagosCarta(String ccdCodcartacr) {
		List<Detallesol> detallesolLista = new ArrayList<Detallesol>();
		if (StringUtils.isBlank(ccdCodcartacr)) {
			return detallesolLista;
		}

		SocValoresclaDao socValoresclaDao = new SocValoresclaDao();
		socValoresclaDao.setSessionFactory(getSessionFactory());

		List<CarCartascrdet> carCartascrdetLista = findByTipoemision(ccdCodcartacr, Constants.CLAVE_CCRED_TIPOEMISION_PAGO);

		for (CarCartascrdet carCartascrdet : carCartascrdetLista) {
			Detallesol detallesol = new Detallesol();
			detallesol.setCarCartascrdet(carCartascrdet);

			SocValorescla socValorescla = socValoresclaDao.getValoresByCod(Constants.CVE_ESTADO_OPERACION_CARTACREDITO, String.valueOf(carCartascrdet.getCcdEstmovccred()));
			detallesol.setSocValorescla(socValorescla);

			SocValorescla socValorescla2 = socValoresclaDao.getValoresByCod(Constants.CVE_TIPOEMISION, String.valueOf(carCartascrdet.getCcdTipoemision()));
			detallesol.setSocValorescla2(socValorescla2);

			detallesolLista.add(detallesol);
		}
		return detallesolLista;
	}
}
