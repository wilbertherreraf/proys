package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;

/**
 * The persistent class for the soc_cuentassol database table.
 * 
 */
@Entity
@Table(name = "soc_cuentassol")
public class SocCuentassol implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "cta_codigo")
	private Integer ctaCodigo;

	@Column(name = "cla_vigente")
	private Short claVigente;

	@Column(name = "cta_afectable")
	private String ctaAfectable;
	
	@Column(name = "cta_movimiento")
	private String ctaMovimiento;

	@Column(name = "partida")
	private String partida;

	@Column(name = "cve_imptsigma")
	private String cveImptsigma;

	@Column(name = "cve_imptiva")
	private String cveImptiva;

	@Column(name = "cve_imptppto")
	private String cveImptppto;

	@Column(name = "cta_nommovimiento")
	private String ctaNommovimiento;
	
	@Column(name = "cla_cuenta")
	private String claCuenta;	
	
	private String estacion;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "fecha_hora")
	private Date fechaHora;

	@Column(name = "gen_itf")
	private Integer genItf;

	private Integer moneda;

	@Column(name = "usr_codigo")
	private String usrCodigo;

	public SocCuentassol() {
	}

	public SocCuentassol(Integer ctaCodigo) {
		this.ctaCodigo = ctaCodigo;
	}

	public SocCuentassol(Integer ctaCodigo, String ctaMovimiento, Integer moneda, String ctaNommovimiento, String ctaAfectable, Short claVigente,
			String usrCodigo, Date fechaHora, String estacion) {
		this.ctaCodigo = ctaCodigo;
		this.ctaMovimiento = ctaMovimiento;
		this.moneda = moneda;
		this.ctaNommovimiento = ctaNommovimiento;
		this.ctaAfectable = ctaAfectable;
		this.claVigente = claVigente;
		this.usrCodigo = usrCodigo;
		this.fechaHora = fechaHora;
		this.estacion = estacion;
	}

	public Integer getCtaCodigo() {
		return this.ctaCodigo;
	}

	public void setCtaCodigo(Integer ctaCodigo) {
		this.ctaCodigo = ctaCodigo;
	}

	public Short getClaVigente() {
		return this.claVigente;
	}

	public void setClaVigente(Short claVigente) {
		this.claVigente = claVigente;
	}

	public String getCtaAfectable() {
		return this.ctaAfectable;
	}

	public void setCtaAfectable(String ctaAfectable) {
		this.ctaAfectable = ctaAfectable;
	}

	public String getCtaMovimiento() {
		return this.ctaMovimiento;
	}

	public void setCtaMovimiento(String ctaMovimiento) {
		this.ctaMovimiento = ctaMovimiento;
	}

	public String getCtaNommovimiento() {
		return this.ctaNommovimiento;
	}

	public void setCtaNommovimiento(String ctaNommovimiento) {
		this.ctaNommovimiento = ctaNommovimiento;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public Integer getGenItf() {
		return this.genItf;
	}

	public void setGenItf(Integer genItf) {
		this.genItf = genItf;
	}

	public Integer getMoneda() {
		return this.moneda;
	}

	public void setMoneda(Integer moneda) {
		this.moneda = moneda;
	}

	public String getUsrCodigo() {
		return this.usrCodigo;
	}

	public void setUsrCodigo(String usrCodigo) {
		this.usrCodigo = usrCodigo;
	}

	
	public String toString() {
		return "SocCuentassol [ctaCodigo=" + ctaCodigo + ", claVigente="
				+ claVigente + ", ctaAfectable=" + ctaAfectable
				+ ", ctaMovimiento=" + ctaMovimiento + ", ctaNommovimiento="
				+ ctaNommovimiento + ", estacion=" + estacion + ", fechaHora="
				+ fechaHora + ", genItf=" + genItf + ", moneda=" + moneda
				+ ", usrCodigo=" + usrCodigo + "]";
	}

	public String getPartida() {
		return partida;
	}

	public void setPartida(String partida) {
		this.partida = partida;
	}

	public String getCveImptsigma() {
		return cveImptsigma;
	}

	public void setCveImptsigma(String cveImptsigma) {
		this.cveImptsigma = cveImptsigma;
	}

	public String getCveImptiva() {
		return cveImptiva;
	}

	public void setCveImptiva(String cveImptiva) {
		this.cveImptiva = cveImptiva;
	}

	public String getCveImptppto() {
		return cveImptppto;
	}

	public void setCveImptppto(String cveImptppto) {
		this.cveImptppto = cveImptppto;
	}

	public String getClaCuenta() {
		return claCuenta;
	}

	public void setClaCuenta(String claCuenta) {
		this.claCuenta = claCuenta;
	}


}
