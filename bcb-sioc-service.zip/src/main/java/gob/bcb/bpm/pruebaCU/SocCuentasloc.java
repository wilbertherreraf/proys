package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the soc_cuentasloc database table.
 * 
 */
@Entity
@Table(name="soc_cuentasloc")
public class SocCuentasloc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="cta_codigo")
	private Integer ctaCodigo;

	@Column(name="ben_codigo")
	private String benCodigo;

	@Column(name="cla_vigente")
	private short claVigente;

	@Column(name="cta_ctacodigo")
	private Integer ctaCtacodigo;

	@Column(name="cta_ctacodigo1")
	private Integer ctaCtacodigo1;

	@Column(name="cta_nombre")
	private String ctaNombre;

	@Column(name="cve_tconcepto")
	private String cveTconcepto;
	
	@Column(name="cta_nrocuenta")
	private String ctaNrocuenta;

	@Column(name="cta_nrocuenta1")
	private String ctaNrocuenta1;

	private String estacion;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="fecha_hora")
	private Date fechaHora;

	private Integer moneda;

	private Integer moneda1;

	@Column(name="usr_codigo")
	private String usrCodigo;

    public SocCuentasloc() {
    }

	public Integer getCtaCodigo() {
		return this.ctaCodigo;
	}

	public void setCtaCodigo(Integer ctaCodigo) {
		this.ctaCodigo = ctaCodigo;
	}

	public String getBenCodigo() {
		return this.benCodigo;
	}

	public void setBenCodigo(String benCodigo) {
		this.benCodigo = benCodigo;
	}

	public short getClaVigente() {
		return this.claVigente;
	}

	public void setClaVigente(short claVigente) {
		this.claVigente = claVigente;
	}

	public Integer getCtaCtacodigo() {
		return this.ctaCtacodigo;
	}

	public void setCtaCtacodigo(Integer ctaCtacodigo) {
		this.ctaCtacodigo = ctaCtacodigo;
	}

	public Integer getCtaCtacodigo1() {
		return this.ctaCtacodigo1;
	}

	public void setCtaCtacodigo1(Integer ctaCtacodigo1) {
		this.ctaCtacodigo1 = ctaCtacodigo1;
	}

	public String getCtaNombre() {
		return this.ctaNombre;
	}

	public void setCtaNombre(String ctaNombre) {
		this.ctaNombre = ctaNombre;
	}

	public String getCtaNrocuenta() {
		return this.ctaNrocuenta;
	}

	public void setCtaNrocuenta(String ctaNrocuenta) {
		this.ctaNrocuenta = ctaNrocuenta;
	}

	public String getCtaNrocuenta1() {
		return this.ctaNrocuenta1;
	}

	public void setCtaNrocuenta1(String ctaNrocuenta1) {
		this.ctaNrocuenta1 = ctaNrocuenta1;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public Integer getMoneda() {
		return this.moneda;
	}

	public void setMoneda(Integer moneda) {
		this.moneda = moneda;
	}

	public Integer getMoneda1() {
		return this.moneda1;
	}

	public void setMoneda1(Integer moneda1) {
		this.moneda1 = moneda1;
	}

	public String getUsrCodigo() {
		return this.usrCodigo;
	}

	public void setUsrCodigo(String usrCodigo) {
		this.usrCodigo = usrCodigo;
	}

	public String getCveTconcepto() {
		return cveTconcepto;
	}

	public void setCveTconcepto(String cveTconcepto) {
		this.cveTconcepto = cveTconcepto;
	}

}