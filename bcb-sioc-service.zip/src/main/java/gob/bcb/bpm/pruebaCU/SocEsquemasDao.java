package gob.bcb.bpm.pruebaCU;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

import gob.bcb.service.exception.BusinessException;

@Transactional
public class SocEsquemasDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocEsquemasDao.class);

	public SocEsquemas esquemaByCod(Integer esqCodigo) {

		SocEsquemas socEsquemas = null;

		StringBuffer query = new StringBuffer();
		query = query.append("select cp ");
		query = query.append("from SocEsquemas cp ");
		query = query.append("where cp.esqCodigo = :esqCodigo ");

//		log.info("Entre a buscar esquemas id [" + esqCodigo + "] " + query.toString());

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("esqCodigo", esqCodigo);

		List<SocEsquemas> lista = consulta.list();

		if (lista == null || lista.size() == 0) {
			throw new BusinessException("Esquema no encontrando codTipoperacion " + esqCodigo);
		}

		if (lista.size() > 0) {
			socEsquemas = lista.get(0);
		}

		return socEsquemas;

	}

	public SocEsquemas esquemaByCodTipooperacion(String codTipoperacion) {
		SocEsquemas socEsquemas = null;

		StringBuffer query = new StringBuffer();
		query = query.append("select cp ");
		query = query.append("from SocEsquemas cp ");
		query = query.append("where cp.codTipoperacion = :codTipoperacion ");

//		log.info("Entre a esquemaByCod id [" + codTipoperacion + "] " + query.toString());

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("codTipoperacion", codTipoperacion);

		List<SocEsquemas> lista = consulta.list();

		if (lista == null || lista.size() == 0) {
			throw new BusinessException("Esquema no encontrando codTipoperacion " + codTipoperacion);
		}

		if (lista.size() > 0) {
			socEsquemas = lista.get(0);
		}
		return socEsquemas;
	}

	public List<SocEsquemas> obtenerEsquema0(String codTipooper, String codTipoperacion, String tipoRetencion, String codMonedaSolicitud,
			String codMonedaTrans, String cveSubtipooper, String tipoTransfer, Integer codEsqref, Integer codCargo) {

		SocEsquemas socEsquemas = new SocEsquemas();
		socEsquemas.setCodTipooper(codTipooper);
		socEsquemas.setCodTipoperacion(codTipoperacion);
		socEsquemas.setTipoRetencion(tipoRetencion);
		socEsquemas.setCodMoneda(codMonedaSolicitud);
		socEsquemas.setCveTiposolic(codMonedaTrans);
		socEsquemas.setCveSubtipooper(cveSubtipooper);
		socEsquemas.setTipoTransfer(tipoTransfer);
		socEsquemas.setCodEsqref(codEsqref);
		socEsquemas.setCodCargo(codCargo);

		List lista = obtenerEsquema(socEsquemas);
		return lista;

	}

	public List<SocEsquemas> obtenerEsquema(SocEsquemas socEsquemas) {
		StringBuffer query = new StringBuffer();
		query = query.append("select e ");
		query = query.append("from SocEsquemas e ");
		query = query.append("where e.claVigente = '1' ");

		if (!StringUtils.isBlank(socEsquemas.getCodTipooper()))
			query = query.append("and e.codTipooper = :codTipooper ");

		if (!StringUtils.isBlank(socEsquemas.getCodTipoperacion()))
			query = query.append("and e.codTipoperacion = :codTipoperacion ");

		if (!StringUtils.isBlank(socEsquemas.getCveTiposolic()))
			query = query.append("and e.cveTiposolic = :cveTiposolic ");

		if (!StringUtils.isBlank(socEsquemas.getTipoRetencion()))
			query = query.append("and e.tipoRetencion = :tipoRetencion ");

		if (!StringUtils.isBlank(socEsquemas.getCodMoneda()))
			query = query.append("and e.codMoneda = :codMoneda ");

		if (!StringUtils.isBlank(socEsquemas.getCveSubtipooper()))
			query = query.append("and e.cveSubtipooper = :cveSubtipooper ");

		if (!StringUtils.isBlank(socEsquemas.getTipoTransfer())) {
			query = query.append("and e.tipoTransfer = :tipoTransfer ");
		}

		if (socEsquemas.getCodEsqref() != null)
			query = query.append("and e.codEsqref = :codEsqref ");

		if (socEsquemas.getCodCargo() != null)
			query = query.append("and e.codCargo = :codCargo ");

		if (!StringUtils.isBlank(socEsquemas.getGenera()))
			query = query.append("and e.genera = :genera ");

//		log.info("Entre a buscar esquemas [CodTipooper: " + socEsquemas.getCodTipooper() + " CodTipoperacion:" + socEsquemas.getCodTipoperacion()
//				+ " TipoRetencion:" + socEsquemas.getTipoRetencion() + " CodMoneda(solic):" + socEsquemas.getCodMoneda()
//				+ " CveTiposolic(mon transf):" + socEsquemas.getCveTiposolic() + " CveSubtipooper:" + socEsquemas.getCveSubtipooper()
//				+ " TipoTransfer:" + socEsquemas.getTipoTransfer() + " CodEsqref:" + socEsquemas.getCodEsqref() + " CodCargo"
//				+ socEsquemas.getCodCargo() + "] " + query.toString());
//
//		log.info("Entre a buscar esquemas : " + socEsquemas.toString() + " :: " + query.toString());

		Query consulta = getSession().createQuery(query.toString());

		if (!StringUtils.isBlank(socEsquemas.getCodTipooper()))
			consulta.setParameter("codTipooper", socEsquemas.getCodTipooper());

		if (!StringUtils.isBlank(socEsquemas.getCodTipoperacion()))
			consulta.setParameter("codTipoperacion", socEsquemas.getCodTipoperacion());

		if (!StringUtils.isBlank(socEsquemas.getCveTiposolic()))
			consulta.setParameter("cveTiposolic", socEsquemas.getCveTiposolic());

		if (!StringUtils.isBlank(socEsquemas.getTipoRetencion()))
			consulta.setParameter("tipoRetencion", socEsquemas.getTipoRetencion());

		if (!StringUtils.isBlank(socEsquemas.getCodMoneda()))
			consulta.setParameter("codMoneda", socEsquemas.getCodMoneda());

		if (!StringUtils.isBlank(socEsquemas.getCveSubtipooper()))
			consulta.setParameter("cveSubtipooper", socEsquemas.getCveSubtipooper());

		if (!StringUtils.isBlank(socEsquemas.getTipoTransfer()))
			consulta.setParameter("tipoTransfer", socEsquemas.getTipoTransfer());

		if (socEsquemas.getCodEsqref() != null)
			consulta.setParameter("codEsqref", socEsquemas.getCodEsqref());

		if (socEsquemas.getCodCargo() != null)
			consulta.setParameter("codCargo", socEsquemas.getCodCargo());

		if (!StringUtils.isBlank(socEsquemas.getGenera()))
			consulta.setParameter("genera", socEsquemas.getGenera());

		List lista = consulta.list();
		log.info("Esquemas recuperados " + lista.size());

		return lista;
	}
	
	public boolean existsClaveCuenta(Integer esqCodigo, String claCuenta) {
		StringBuffer query = new StringBuffer();
		query = query.append("select re ");
		query = query.append("from SocEsquemas e, SocRengesq re ");
		query = query.append("where e.esqCodigo = re.id.esqCodigo ");
		query = query.append("and e.esqCodigo = :esqCodigo ");
		query = query.append("and re.claCuenta = :claCuenta ");		

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("esqCodigo", esqCodigo);
		consulta.setParameter("claCuenta", claCuenta);		

		List<SocEsquemas> lista = consulta.list();

		return lista.size() > 0;		
	}
}
