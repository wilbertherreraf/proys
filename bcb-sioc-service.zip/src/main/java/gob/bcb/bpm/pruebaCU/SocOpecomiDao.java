/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.bpm.pruebaCU;

import gob.bcb.service.commons.UserSessionHolder;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.ws.xml.consultasolic.Factura;
import gob.bcb.service.servicioSioc.ws.xml.consultasolic.ServicioSioc;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;
import gob.bcb.service.servicioSiocCoin.dao.ConsultasComunes;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

//import org.hibernate.Query;

/**
 * @author wherrera
 * 
 */
@Transactional
public class SocOpecomiDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocOpecomiDao.class);

	public void eliminarRegs0(String opecodigo, String cve_tipocomis) {
		// cve_tipocomis ; V = Variable
		StringBuffer query = new StringBuffer();
		query = query.append("delete from soc_opecomi  ");
		query = query.append("where ope_codigo = :opecodigo ");
		query = query.append("and cla_estadovar != 'C' ");
		query = query.append("and cve_tipocomis	= :cveTipocomis ");

		Query consulta = getSession().createSQLQuery(query.toString());

		consulta.setParameter("opecodigo", opecodigo);
		consulta.setParameter("cveTipocomis", cve_tipocomis);
		consulta.executeUpdate();
		
		log.info("Eliminando soc_opecomi... " + opecodigo + " cve_tipocomis: " + cve_tipocomis);

	}
	public void eliminarRegs(String opecodigo, String cve_tipocomis) {
		// cve_tipocomis ; V = Variable
		List<SocOpecomi> lista = getByCveTipocomis(opecodigo, null, null, cve_tipocomis);
		List<SocOpecomi> listaRemove = new ArrayList<SocOpecomi>();
		for (SocOpecomi socOpecomi : lista) {
			if(!socOpecomi.getClaEstadovar().equals("C")){
				listaRemove.add(socOpecomi);
			}
		}
		if (listaRemove.size() > 0){
			this.getHibernateTemplate().deleteAll(listaRemove);
			log.info("Eliminando soc_opecomi... " + opecodigo + " cve_tipocomis: " + cve_tipocomis + " len : " + listaRemove.size());
		}

	}

	public void saveOrUpdate(SocOpecomi pm) {
		// pm.setFechaHora(new Date());
		if (UserSessionHolder.get(Constants.AUDIT_USER_ESTACION) != null)
			pm.setEstacion((String) UserSessionHolder.get(Constants.AUDIT_USER_ESTACION));

		if (UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID) != null)
			pm.setUsrCodigo((String) UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID));

		this.getHibernateTemplate().merge(pm);
	}

	public List<SocOpecomi> getComis(String opeCodigo) {
		List<SocOpecomi> lista = new ArrayList<SocOpecomi>();

		StringBuffer query = new StringBuffer();

		query = query.append("select co ");
		query = query.append("from SocOpecomi co ");
		query = query.append("where co.id.opeCodigo = :opeCodigo ");

		log.info("Consulta lista comisiones getComis opeCodigo: " + opeCodigo + " --> " + query.toString());
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("opeCodigo", opeCodigo);

		lista = consulta.list();

		return lista;
	}

	public List<SocOpecomi> getOpeComisByDetCodClaComis(String opeCodigo, Integer detCodigo, String claComision) {
		List<SocOpecomi> lista = new ArrayList<SocOpecomi>();

		StringBuffer query = new StringBuffer();

		query = query.append("select co ");
		query = query.append("from SocOpecomi co ");
		query = query.append("where co.id.opeCodigo = :opeCodigo ");

		if (detCodigo != null)
			query = query.append("and co.id.detCodigo = :detCodigo ");

		if (!StringUtils.isBlank(claComision)) {
			query = query.append("and co.id.claComision = :claComision ");
		}

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("opeCodigo", opeCodigo);

		if (detCodigo != null)
			consulta.setParameter("detCodigo", detCodigo);

		if (!StringUtils.isBlank(claComision)) {
			consulta.setParameter("claComision", claComision);
		}

		lista = consulta.list();

		return lista;
	}

	public SocOpecomi findByCveTipocomis(String opeCodigo, Integer detCodigo, String claComision, String cveTipocomis) {
		List<SocOpecomi> lista = getByCveTipocomis(opeCodigo, detCodigo, claComision, cveTipocomis);
		if (lista.size() == 1) {
			return lista.get(0);
		}
		return null;
	}

	public List<SocOpecomi> getByCveTipocomis(String opeCodigo, Integer detCodigo, String claComision, String cveTipocomis) {
		List<SocOpecomi> lista = new ArrayList<SocOpecomi>();

		StringBuffer query = new StringBuffer();

		query = query.append("select co ");
		query = query.append("from SocOpecomi co ");
		query = query.append("where co.id.opeCodigo = :opeCodigo ");

		if (detCodigo != null)
			query = query.append("and co.id.detCodigo = :detCodigo ");

		if (!StringUtils.isBlank(claComision)) {
			query = query.append("and co.id.claComision = :claComision ");
		}

		if (!StringUtils.isBlank(cveTipocomis)) {
			query = query.append("and co.cveTipocomis = :cveTipocomis ");
		}

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("opeCodigo", opeCodigo);

		if (detCodigo != null)
			consulta.setParameter("detCodigo", detCodigo);

		if (!StringUtils.isBlank(claComision)) {
			consulta.setParameter("claComision", claComision);
		}

		if (!StringUtils.isBlank(cveTipocomis)) {
			consulta.setParameter("cveTipocomis", cveTipocomis);
		}

		lista = consulta.list();

		return lista;
	}

	public SocOpecomi getOpeComisByDetCodClaCom(String opeCodigo, Integer detCodigo, String claComision) {
		List<SocOpecomi> lista = getOpeComisByDetCodClaComis(opeCodigo, detCodigo, claComision);
		if (lista.size() == 1) {
			return lista.get(0);
		}
		return null;
	}

	public SocOpecomi crearRegistro(SocSolicitudes socSolicitudes, String opeCodigo, Integer detCodigo, String claComision, BigDecimal ocoMonto,
			BigDecimal montoMo, Integer codMoneda, String glosa, String nit, String factura, String ctaCodigo, String cveTipocomis,
			BigDecimal tipoCambio) {
		// ojooo falta valores auditoria
		SocOpecomi socOpecomiOld = nuevoRegistro(opeCodigo, detCodigo, claComision, ocoMonto, montoMo, codMoneda, glosa, nit, factura, ctaCodigo,
				cveTipocomis, tipoCambio);
		socOpecomiOld.setUsrCodigo(socSolicitudes.getUsrCodigo());
		socOpecomiOld.setEstacion(socSolicitudes.getEstacion());

		saveOrUpdate(socOpecomiOld);

		return socOpecomiOld;
	}

	public SocOpecomi nuevoRegistro(String opeCodigo, Integer detCodigo, String claComision, BigDecimal ocoMonto, BigDecimal montoMo,
			Integer codMoneda, String glosa, String nit, String factura, String ctaCodigo, String cveTipocomis, BigDecimal tipoCambio) {

		SocOpecomi socOpecomiOld = getOpeComisByDetCodClaCom(opeCodigo, detCodigo, claComision);
		if (socOpecomiOld == null) {
			// encontrado
			SocOpecomiId socOpecomiId = new SocOpecomiId(claComision, opeCodigo, detCodigo);
			socOpecomiOld = new SocOpecomi();
			socOpecomiOld.setId(socOpecomiId);
			socOpecomiOld.setClaEstadovar("P");

		}
		socOpecomiOld.setOcoMonto(ocoMonto);
		socOpecomiOld.setMontoMo(montoMo);
		socOpecomiOld.setCodMoneda(codMoneda);
		socOpecomiOld.setNit(nit);
		socOpecomiOld.setFactura(factura);
		socOpecomiOld.setNroCuenta(ctaCodigo);
		socOpecomiOld.setTipoCambio((tipoCambio != null ? tipoCambio.setScale(7, BigDecimal.ROUND_HALF_UP) : tipoCambio));
		socOpecomiOld.setCveTipocomis(cveTipocomis);
		socOpecomiOld.setFechaHora(new Date());
		log.info("Variable actualizada " + socOpecomiOld.toString());
		return socOpecomiOld;
	}

	public void crearSocOpecomiLista(SocSolicitudes socSolicitudes, List<SocOpecomi> socOpecomiLista) {
		for (SocOpecomi socOpecomi : socOpecomiLista) {
			log.info("Guardando socOpecomi " + socSolicitudes.getSocCodigo() + " tipo " + socOpecomi.getId().getClaComision());

			socOpecomi.getId().setOpeCodigo(socSolicitudes.getSocCodigo());
			socOpecomi.setUsrCodigo(socSolicitudes.getUsrCodigo());
			socOpecomi.setEstacion(socSolicitudes.getEstacion());
			socOpecomi.setFechaHora(new Date());

			this.getHibernateTemplate().merge(socOpecomi);
		}
	}

	public List<SocOpecomi> fromServicioSiocFactura(SocSolicitudes socSolicitudes, ServicioSioc servicioSioc) {
		if (servicioSioc.getDatosOperacion().getSolicitud().getFacturaciones() == null
				|| servicioSioc.getDatosOperacion().getSolicitud().getFacturaciones().getFactura() == null
				|| servicioSioc.getDatosOperacion().getSolicitud().getFacturaciones().getFactura().size() == 0) {
			throw new BusinessException("Solicitud sin datos de facturaciones ");
		}

		List<Factura> facturaLista = servicioSioc.getDatosOperacion().getSolicitud().getFacturaciones().getFactura();

		log.info("Mapeando from ServicioSioc Facturas " + facturaLista.size());
		List<SocOpecomi> socOpecomiLista = new ArrayList<SocOpecomi>();

		for (Factura factura : facturaLista) {
			SocOpecomiId socOpecomiId = new SocOpecomiId(factura.getTipoFactura(), socSolicitudes.getSocCodigo(), 0);
			SocOpecomi socOpecomiOld = new SocOpecomi();
			socOpecomiOld.setId(socOpecomiId);
			socOpecomiOld.setClaEstadovar("P");			
			// por defecto factura N no registrado en coin
			socOpecomiOld.setNroCuenta("N");
			socOpecomiOld.setOcoMonto(BigDecimal.ZERO);
			socOpecomiOld.setMontoMo(BigDecimal.ZERO);
			socOpecomiOld.setNit(factura.getNit());

			if (StringUtils.isBlank(factura.getNit())) {
				throw new BusinessException("Solicitud en tipo factura " + factura.getTipoFactura() + " con nit nulo");
			}

			socOpecomiOld.setFactura(factura.getRazonSocial());
			if (StringUtils.isBlank(factura.getRazonSocial())) {
				throw new BusinessException("Solicitud en tipo factura " + factura.getTipoFactura() + " con razon social nulo");
			}
			socOpecomiOld.setCveTipocomis("F");

			socOpecomiLista.add(socOpecomiOld);
		}

		log.info("Despues de facturitas " + socOpecomiLista.size());

		return socOpecomiLista;
	}

	public List<SocOpecomi> recuperarFacturas(SocSolicitudes socSolicitudes, List<SocDetallessol> socDetallessolLista) {
		log.info("En recuperar Facturas " + socSolicitudes.getSolCodigo());

		SocRengesqDao socRengesqDao = new SocRengesqDao();
		socRengesqDao.setSessionFactory(getSessionFactory());

		SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
		socSolicitanteDao.setSessionFactory(getSessionFactory());

		SocBenefsDao socBenefsDao = new SocBenefsDao();
		socBenefsDao.setSessionFactory(getSessionFactory());

		SocSolicitudctasDao socSolicitudctasDao = new SocSolicitudctasDao();
		socSolicitudctasDao.setSessionFactory(getSessionFactory());

		// ***************************************//

		List<SocOpecomi> socOpecomiLista = new ArrayList<SocOpecomi>();

		if (socSolicitudes.getEsqCodigo() == null) {
			throw new BusinessException("Solicitud [" + socSolicitudes.getSocCodigo() + "] sin codigo de esquema");
		}

		SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCod(socSolicitudes.getSolCodigo().trim());

		String nitSolic = StringUtils.trimToEmpty(socSolicitante.getSolNit());
		String razonSolic = StringUtils.trimToEmpty(socSolicitante.getSolFactura());
		String tipoFacturaSolic = "N";

		if (StringUtils.isBlank(socSolicitante.getSolNit()) || StringUtils.isBlank(socSolicitante.getSolFactura())) {
			log.info("Buscando nit en coin " + socSolicitudes.getSolCodigo());
			// se busca en coin el nit
			ConsultasComunes consultasComunes = new ConsultasComunes();
			consultasComunes.setSessionFactory(SiocCoinService.getSessionFactory());

			Map<String, Object> result = consultasComunes.persona(socSolicitudes.getSolCodigo().trim());

			if (result != null) {
				nitSolic = (String) result.get("ruc");
				razonSolic = (String) result.get("nompersona");

				if (!StringUtils.isBlank(nitSolic)) {
					tipoFacturaSolic = "P";
				}

				log.info("Consulta coin " + socSolicitudes.getSolCodigo() + " Nit " + nitSolic + " razonSolic: " + razonSolic);
			}
		}

		if (StringUtils.isBlank(razonSolic)) {
			razonSolic = socSolicitante.getSolPersona();
		}

		List<SocRengesq> socRengesqLista = socRengesqDao.getRengsEsquema(socSolicitudes.getEsqCodigo());

		boolean comGAdm = true;

		Beneficiario beneficiario = null;

		for (SocRengesq socRengesq : socRengesqLista) {
			if (!socRengesq.getClaCuenta().equalsIgnoreCase(Constants.CLAVE_CLACTA_UTIL)
					&& !socRengesq.getClaCuenta().equalsIgnoreCase(Constants.CLAVE_CLACTA_SWFT)
					&& !socRengesq.getClaCuenta().equalsIgnoreCase(Constants.CLAVE_CLACTA_COMTRANS)
					&& !socRengesq.getClaCuenta().equalsIgnoreCase(Constants.CLAVE_CLACTA_VENTA)) {
				continue;
			}

			String tipoFactura = "";
			String claCuenta = "";
			boolean registraFactura = false;

			SocOpecomiId socOpecomiId = new SocOpecomiId();
			socOpecomiId.setDetCodigo(0);
			socOpecomiId.setOpeCodigo(socSolicitudes.getSocCodigo());

			SocOpecomi socOpecomi = new SocOpecomi();
			socOpecomi.setId(socOpecomiId);
			// N ; no registrado factura en agenda coin
			socOpecomi.setClaEstadovar("P");
			socOpecomi.setNroCuenta("N");
			socOpecomi.setOcoMonto(BigDecimal.ZERO);
			socOpecomi.setMontoMo(BigDecimal.ZERO);
			socOpecomi.setCveTipocomis("F");
			socOpecomi.setFechaHora(new Date());
			socOpecomi.setEstacion(socSolicitudes.getEstacion());
			socOpecomi.setUsrCodigo(socSolicitudes.getUsrCodigo());

			if (socRengesq.getEsqDh() == 'H'
					&& (socRengesq.getClaCuenta().equalsIgnoreCase(Constants.CLAVE_CLACTA_UTIL) || socRengesq.getClaCuenta().equalsIgnoreCase(
							Constants.CLAVE_CLACTA_SWFT))) {
				// swift utiles
				tipoFactura = Constants.CLAVE_TIPOFACT_ADM;
				claCuenta = Constants.COD_CLAVE_COMGADM;
				registraFactura = comGAdm;
				comGAdm = false;

			} else if (socRengesq.getEsqDh() == 'H' && socRengesq.getClaCuenta().equalsIgnoreCase(Constants.CLAVE_CLACTA_COMTRANS)) {
				// transferencia
				tipoFactura = Constants.CLAVE_TIPOFACT_CTRA;
				claCuenta = Constants.COD_CLAVE_COMCTRA;
				registraFactura = true;

			} else if (socRengesq.getEsqDh() == 'H' && socRengesq.getClaCuenta().equalsIgnoreCase(Constants.CLAVE_CLACTA_VENTA)) {
				// venta de divisas siempre va al solicitante

				tipoFactura = Constants.CLAVE_TIPOFACT_VDD;

				SocOpecomi socOpecomiOld = getOpeComisByDetCodClaCom(socSolicitudes.getSocCodigo(), 0, tipoFactura);

				if (socOpecomiOld != null) {
					// ya fue registrado se verifica que exista en coin
					if (socSolicitudes.getCveTipctasolic().equals(Constants.CLAVE_GENERADOPOR_WS)) {
						continue;
					}
				}

				socOpecomi.getId().setClaComision(tipoFactura);
				socOpecomi.setNit(nitSolic);
				socOpecomi.setFactura(razonSolic);
				//socOpecomi.setClaEstadovar(tipoFacturaSolic);
				socOpecomi.setNroCuenta(tipoFacturaSolic);

				this.getHibernateTemplate().merge(socOpecomi);

				log.info(socSolicitudes.getSocCodigo() + ":Registrando factura : " + socRengesq.getClaCuenta() + " tipoFactura ="
						+ socOpecomi.getId().getClaComision() + " nit: " + socOpecomi.getNit() + " razon:" + socOpecomi.getFactura());
			}

			if (registraFactura) {
				// buscamos si ya fue registrado
				SocOpecomi socOpecomiOld = getOpeComisByDetCodClaCom(socSolicitudes.getSocCodigo(), 0, tipoFactura);

				if (socOpecomiOld != null) {
					// ya fue registrado por ws
					if (socSolicitudes.getCveTipctasolic().equals(Constants.CLAVE_GENERADOPOR_WS)) {
						continue;
					}
				}

				socOpecomi.getId().setClaComision(tipoFactura);

				// control de la cuenta que asume la comision
				SocSolicitudctas socSolicitudctas = socSolicitudctasDao.getCuenta(socSolicitudes.getSocCodigo(), claCuenta, null, null, null, null);

				if (socSolicitudctas == null) {
					throw new BusinessException("Solicitud no registra cuenta " + claCuenta + " en socsolicitudctas");
				}

				if (StringUtils.isBlank(socSolicitudctas.getCveTipocomis())) {
					throw new BusinessException("Solicitud [" + socSolicitudes.getSocCodigo() + "] con Cuenta " + claCuenta
							+ " con valor invalido debe ser (B o S) en campo CveTipocomis,  avise a sistemas");
				}

				if (socSolicitudctas.getCveTipocomis().equals(Constants.CLAVE_TIPOCOMIS_SOLIC)) {
					// la cuenta de comision es del solicitante
					socOpecomi.setNit(nitSolic);
					socOpecomi.setFactura(razonSolic);
					//socOpecomi.setClaEstadovar(tipoFacturaSolic);
					socOpecomi.setNroCuenta(tipoFacturaSolic);

				} else if (socSolicitudctas.getCveTipocomis().equals(Constants.CLAVE_TIPOCOMIS_BENEF)) {
					// la cuenta de comision es del beneficiario
					if (socDetallessolLista.size() != 1) {
						throw new BusinessException("Solicitud [" + socSolicitudes.getSocCodigo() + "] con Factura al beneficiario con ["
								+ socDetallessolLista.size() + "] beneficiarios registrados");
					}

					String nitBen = null;
					String razonBen = null;

					SocDetallessol socDetallessol = socDetallessolLista.get(0);

					beneficiario = socBenefsDao.recuperarBeneficiario(socSolicitudes, socDetallessol);

					if (beneficiario != null) {
						log.warn("Beneficiario [" + socDetallessol.getBenCodigo() + "] existente para " + socSolicitudes.getCveSubtipooper());

						nitBen = beneficiario.getBenNit();
						razonBen = beneficiario.getBenFactura();

						if (StringUtils.isBlank(razonBen)) {
							razonBen = beneficiario.getBenNombre();
						}
					}

					socOpecomi.setNit(nitBen);
					socOpecomi.setFactura(razonBen);
				}

				this.getHibernateTemplate().merge(socOpecomi);
				log.info(socSolicitudes.getSocCodigo() + "::Registrando factura : " + socRengesq.getClaCuenta() + " tipoFactura ="
						+ socOpecomi.getId().getClaComision() + " nit: " + socOpecomi.getNit() + " razon:" + socOpecomi.getFactura());
			}

		}

		List<SocOpecomi> lista = getByCveTipocomis(socSolicitudes.getSocCodigo(), 0, null, "F");
		for (SocOpecomi socOpecomi2 : lista) {
			if (StringUtils.isBlank(socOpecomi2.getNit())) {
				throw new BusinessException("Solicitud tipo factura " + socOpecomi2.getId().getClaComision() + " con NIT invalido");
			}
		}

		log.info("Fin En recuperarFacturaSolicitante " + socSolicitudes.getSolCodigo() + " " + socOpecomiLista.size());

		return lista;
	}

	public SocOpecomi recuperarFacturaBenef(SocSolicitudes socSolicitudes, SocDetallessol socDetallessol, String claComision) {
		log.info("En recuperarFacturaBenef " + socSolicitudes.getSolCodigo() + " BenCodigo: " + socDetallessol.getBenCodigo());

		SocBenefsDao socBenefsDao = new SocBenefsDao();
		socBenefsDao.setSessionFactory(getSessionFactory());

		SocBenefs socBenefs = socBenefsDao.getBenefsByBenCodigo(socDetallessol.getBenCodigo());

		SocOpecomi socOpecomiCADM = nuevoRegistro(socSolicitudes.getSocCodigo(), 0, claComision, BigDecimal.ZERO, BigDecimal.ZERO, null, null,
				socBenefs.getBenNit(), socBenefs.getBenFactura(), null, "F", null);

		return socOpecomiCADM;
	}

}
