package gob.bcb.bpm.pruebaCU;

import java.util.Calendar;

import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public class GenFeriadoDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(GenFeriadoDao.class);

	public void saveOrUpdate(GenFeriado pm) {
		this.getHibernateTemplate().saveOrUpdate(pm);		
	}
	public void eliminar(GenFeriado pm) {
		this.getHibernateTemplate().delete(pm);
	}

	public boolean isHabil(Date fechaFeriado, Integer codMoneda) {
		return getByFechaMoneda(fechaFeriado, codMoneda) == null;
	}
	
	public GenFeriado getByFechaMoneda(Date fechaFeriado, Integer codMoneda) {
		StringBuffer query = new StringBuffer();
		query = query.append("select re ");
		query = query.append("from GenFeriado re ");
		query = query.append("where re.id.fechaFeriado = :fechaFeriado ");
		query = query.append("and re.id.codMoneda = :codMoneda ");		

		Query consulta = getSession().createQuery(query.toString());
		log.info("getByFechaMoneda [fechaFeriado= " + fechaFeriado + ", moneda= " + codMoneda + "] " + query.toString());
		consulta.setDate("fechaFeriado", fechaFeriado);
		consulta.setParameter("codMoneda", codMoneda);

		List lista = consulta.list();
		
		if  (lista.size() > 0 ){
			return (GenFeriado) lista.get(0);
		}
		return null;
	}
	public Date fecHabilAntesDespuesDe(Date fecha, Integer codMoneda, int diasAntes) {
		if (diasAntes == 0) {
			return fecha;
		}

		if (diasAntes > 365) {
			throw new RuntimeException("El numero de dias para calcular fecha habil antes de " + diasAntes
					+ " dias es mayor al permitido 365.");
		}

		int diasAbs = (diasAntes < 0 ? -diasAntes : diasAntes);
		int signo = (diasAntes < 0 ? -1 : 1);

		int contDias = 1;
		int cont = 1;

		Calendar fecEval = null;
		fecEval = Calendar.getInstance();
		fecEval.setTime(fecha);

		while (cont <= diasAbs && contDias <= 365) {
			fecEval.setTime(fecha);
			fecEval.add(Calendar.DAY_OF_YEAR, signo * contDias);

			if (isHabil(fecEval.getTime(), codMoneda)) {
				cont++;
			} 
			contDias++;
		}

		if ((cont > diasAntes) && (fecEval.getTime().before(fecha) || fecEval.getTime().after(fecha))) {
			return fecEval.getTime();
		} else {
			return null;
		}
	}	

	public List<GenFeriado> getGenFeriadoList() {
		StringBuffer query = new StringBuffer();
		
		query = query.append("SELECT h ");
		query = query.append("FROM GenFeriado h ");
		query = query.append("order by h.id.fechaFeriado ");		
		Query consulta = getSession().createQuery(query.toString());
		
		return consulta.list();
	}

}
