package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.util.Date;


/**
 * The persistent class for the soc_benefsexp database table.
 * 
 */
@Entity
@Table(name="soc_benefsexp")
public class SocBenefsexp implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ben_codigo")
	private Integer benCodigo;

	@Column(name="ben_contacto")
	private String benContacto;

	@Column(name="ben_depto")
	private String benDepto;

	@Column(name="ben_direccion")
	private String benDireccion;

	@Column(name="ben_email")
	private String benEmail;

	@Column(name="ben_factura")
	private String benFactura;

	@Column(name="ben_fax")
	private String benFax;

	@Column(name="ben_nit")
	private String benNit;

	@Column(name="ben_nombre")
	private String benNombre;

	@Column(name="ben_telefono")
	private String benTelefono;

	@Column(name="cla_entidad")
	private String claEntidad;

	@Column(name="cla_vigente")
	private short claVigente;

	private String estacion;

	@Temporal( TemporalType.TIMESTAMP)	
	@Column(name="fecha_hora")
	private Date fechaHora;

	@Column(name="usr_codigo")
	private String usrCodigo;

    public SocBenefsexp() {
    }

	public Integer getBenCodigo() {
		return this.benCodigo;
	}

	public void setBenCodigo(Integer benCodigo) {
		this.benCodigo = benCodigo;
	}

	public String getBenContacto() {
		return this.benContacto;
	}

	public void setBenContacto(String benContacto) {
		this.benContacto = benContacto;
	}

	public String getBenDepto() {
		return this.benDepto;
	}

	public void setBenDepto(String benDepto) {
		this.benDepto = benDepto;
	}

	public String getBenDireccion() {
		return this.benDireccion;
	}

	public void setBenDireccion(String benDireccion) {
		this.benDireccion = benDireccion;
	}

	public String getBenEmail() {
		return this.benEmail;
	}

	public void setBenEmail(String benEmail) {
		this.benEmail = benEmail;
	}

	public String getBenFactura() {
		return this.benFactura;
	}

	public void setBenFactura(String benFactura) {
		this.benFactura = benFactura;
	}

	public String getBenFax() {
		return this.benFax;
	}

	public void setBenFax(String benFax) {
		this.benFax = benFax;
	}

	public String getBenNit() {
		return this.benNit;
	}

	public void setBenNit(String benNit) {
		this.benNit = benNit;
	}

	public String getBenNombre() {
		return this.benNombre;
	}

	public void setBenNombre(String benNombre) {
		this.benNombre = benNombre;
	}

	public String getBenTelefono() {
		return this.benTelefono;
	}

	public void setBenTelefono(String benTelefono) {
		this.benTelefono = benTelefono;
	}

	public String getClaEntidad() {
		return this.claEntidad;
	}

	public void setClaEntidad(String claEntidad) {
		this.claEntidad = claEntidad;
	}

	public short getClaVigente() {
		return this.claVigente;
	}

	public void setClaVigente(short claVigente) {
		this.claVigente = claVigente;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getUsrCodigo() {
		return this.usrCodigo;
	}

	public void setUsrCodigo(String usrCodigo) {
		this.usrCodigo = usrCodigo;
	}

}