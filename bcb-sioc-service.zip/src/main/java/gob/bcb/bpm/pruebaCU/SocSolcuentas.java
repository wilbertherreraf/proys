package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the soc_solcuentas database table.
 * 
 */
@Entity
@Table(name="soc_solcuentas")
public class SocSolcuentas implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SocSolcuentasPK id;

	@Column(name="cla_vigente")
	private Short claVigente;

	@Column(name="cta_nombre")
	private String ctaNombre;

	@Column(name="cta_numero")
	private String ctaNumero;

	private String estacion;

	@Temporal(TemporalType.TIMESTAMP)	
	@Column(name="fecha_hora")
	private Date fechaHora;

	@Column(name="usr_codigo")
	private String usrCodigo;

    public SocSolcuentas() {
    }

	public SocSolcuentasPK getId() {
		return this.id;
	}

	public void setId(SocSolcuentasPK id) {
		this.id = id;
	}
	
	public Short getClaVigente() {
		return this.claVigente;
	}

	public void setClaVigente(Short claVigente) {
		this.claVigente = claVigente;
	}

	public String getCtaNombre() {
		return this.ctaNombre;
	}

	public void setCtaNombre(String ctaNombre) {
		this.ctaNombre = ctaNombre;
	}

	public String getCtaNumero() {
		return this.ctaNumero;
	}

	public void setCtaNumero(String ctaNumero) {
		this.ctaNumero = ctaNumero;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getUsrCodigo() {
		return this.usrCodigo;
	}

	public void setUsrCodigo(String usrCodigo) {
		this.usrCodigo = usrCodigo;
	}

	
	public String toString() {
		return "SocSolcuentas [id=" + id + ", claVigente=" + claVigente + ", ctaNombre=" + ctaNombre + ", ctaNumero=" + ctaNumero + ", estacion="
				+ estacion + ", fechaHora=" + fechaHora + ", usrCodigo=" + usrCodigo + "]";
	}

	
}
