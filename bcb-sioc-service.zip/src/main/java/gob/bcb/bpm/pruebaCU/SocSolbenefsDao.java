package gob.bcb.bpm.pruebaCU;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public class SocSolbenefsDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocSolbenefsDao.class);

	public void saveOrUpdate(SocSolbenefs socSolbenefs) {
		
		SocSolbenefs socSolbenefsOld = getSocSolbenefByCodigo(socSolbenefs.getId().getSolCodigo(), socSolbenefs.getId().getBenCodigo());
		if (socSolbenefsOld == null){
			socSolbenefs.setClaVigente(Short.valueOf("1"));
			socSolbenefs.setFechaHora(new Date());
		} else {
			socSolbenefs.setFechaHora(new Date());			
		}
		
		this.getHibernateTemplate().merge(socSolbenefs);
	}
	public SocSolbenefs getSocSolbenefByCodigo(String solCodigo, String benCodigo) {
		log.debug("Entre a buscar getSocSolbenefsByCodigo id: " + solCodigo);

		SocSolbenefs benefs = null;
		
		List lista = getSocSolbenefsByCodigo(solCodigo, benCodigo);

		if (lista.size() > 0) {
			benefs = (SocSolbenefs) lista.get(0);
		}

		return benefs;
	}
	public List<SocSolbenefs> getSocSolbenefsByCodigo(String solCodigo, String benCodigo) {
		log.debug("Entre a buscar getSocSolbenefsByCodigo id: " + solCodigo + " " + benCodigo);

		StringBuffer query = new StringBuffer();
		query = query.append("select be ");
		query = query.append("from SocSolbenefs be ");
		query = query.append("where be.claVigente is not null ");
		
		if (!StringUtils.isBlank(solCodigo)) {
			query = query.append("and be.id.solCodigo = :solCodigo ");			
		}
		if (!StringUtils.isBlank(benCodigo)) {
			query = query.append("and be.id.benCodigo = :benCodigo ");			
		}
		Query consulta = getSession().createQuery(query.toString());

		if (!StringUtils.isBlank(solCodigo)) {
			consulta.setParameter("solCodigo", solCodigo);			
		}
		if (!StringUtils.isBlank(benCodigo)) {
			consulta.setParameter("benCodigo", benCodigo);			
		}
		
		@SuppressWarnings("unchecked")
		List lista = consulta.list();
		return lista;
		
	}
	
}
