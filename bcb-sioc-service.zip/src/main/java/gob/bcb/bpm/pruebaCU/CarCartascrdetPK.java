package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class CarCartascrdetPK  implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name = "ccd_codcartacr")
	private String ccdCodcartacr;
	@Column(name = "ccd_nroccreddet")
	private Integer ccdNroccreddet;
	
	public CarCartascrdetPK() {
	}

	public String getCcdCodcartacr() {
		return ccdCodcartacr;
	}

	public void setCcdCodcartacr(String ccdCodcartacr) {
		this.ccdCodcartacr = ccdCodcartacr;
	}

	public Integer getCcdNroccreddet() {
		return ccdNroccreddet;
	}

	public void setCcdNroccreddet(Integer ccdNroccreddet) {
		this.ccdNroccreddet = ccdNroccreddet;
	}
	
	
}
