package gob.bcb.bpm.pruebaCU;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public class SocSolicitanteDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocSolicitanteDao.class);

	public void saveOrUpdate(SocSolicitante arg0) {
		this.getHibernateTemplate().saveOrUpdate(arg0);

	}

	public SocSolicitante solicitanteByCod(String solCodigo) {
		SocSolicitante socSolicitante = null;

		List<SocSolicitante> lista = solicitantesByCod(solCodigo, null);

		if (lista == null || lista.size() == 0) {
			throw new RuntimeException("Solicitante no encontrando " + solCodigo);
		}

		if (lista.size() > 0) {
			socSolicitante = lista.get(0);
		}

		return socSolicitante;
	}

	/**
	 * retorna el solicitante pero sin emitir exception sin no existe
	 * 
	 * @param solCodigo
	 * @return
	 */
	public SocSolicitante solicitanteByCodigo(String solCodigo) {
		SocSolicitante socSolicitante = null;

		List<SocSolicitante> lista = solicitantesByCod(solCodigo, null);

		if (lista.size() > 0) {
			socSolicitante = lista.get(0);
		}

		return socSolicitante;
	}

	public List<SocSolicitante> solicitantesByCod(String solCodigo, String claEntidad) {
		StringBuffer query = new StringBuffer();

		query = query.append("select cp ");
		query = query.append("from SocSolicitante cp ");

		if (!StringUtils.isBlank(solCodigo)) {
			query = query.append("where trim(cp.solCodigo) = :solCodigo ");
		} else {
			query = query.append("where cp.claVigente = 1 ");
		}

		if (!StringUtils.isBlank(claEntidad)) {
			query = query.append("and cp.claEntidad in (:claEntidad) ");
		}

		query = query.append("order by cp.solPersona ");
		log.debug("Entre a buscar solicitanteByCod id [" + solCodigo + ", " + claEntidad + "] " + query.toString());

		Query consulta = getSession(true).createQuery(query.toString());

		if (!StringUtils.isBlank(solCodigo)) {
			consulta.setParameter("solCodigo", solCodigo.trim());
		}

		if (!StringUtils.isBlank(claEntidad)) {
			List estadosList = new ArrayList();
			estadosList.addAll(Arrays.asList(claEntidad.split(",")));

			consulta.setParameterList("claEntidad", estadosList);
		}

		List<SocSolicitante> lista = consulta.list();

		return lista;
	}

	public SocSolicitante solicitanteByCodSigep(String solCodigo) {
		SocSolicitante socSolicitante = null;

		StringBuffer query = new StringBuffer();
		query = query.append("select cp ");
		query = query.append("from SocSolicitante cp ");
		query = query.append("where cp.solCodsigep = :solCodigo ");
		query = query.append("and cp.claVigente = 1 ");

		log.debug("Entre a buscar solicitanteByCodSigep id [" + solCodigo + "] " + query.toString());

		Query consulta = getSession(true).createQuery(query.toString());

		consulta.setParameter("solCodigo", solCodigo);

		List<SocSolicitante> lista = consulta.list();

		if (lista == null || lista.size() == 0) {
			throw new RuntimeException("Codigo sigep no encontrando " + solCodigo);
		}

		if (lista.size() > 1) {
			throw new RuntimeException("Entidad sigep " + solCodigo + " registrado " + lista.size() + " veces, avise al administrador");
		}

		socSolicitante = lista.get(0);

		return socSolicitante;

	}
	
	public List<Beneficiario> getListaBeneficiariosSolicitantes(String solCodigo, String claEntidad) {
		List<Beneficiario> beneficiarios = new ArrayList<Beneficiario>();
		List<SocSolicitante> socSolicitanteLista = solicitantesByCod(solCodigo, claEntidad);
		for (SocSolicitante socSolicitante : socSolicitanteLista) {
			Beneficiario benefi = new Beneficiario();
			benefi.setBenCodigo(socSolicitante.getSolCodigo());
			benefi.setSolCodigo(socSolicitante.getSolCodigo());
			benefi.setBenNit(socSolicitante.getSolNit());
			benefi.setBenFactura(socSolicitante.getSolFactura());
			benefi.setBenNombre(socSolicitante.getSolPersona());
			benefi.setBenDireccion(socSolicitante.getSolDireccion());
			benefi.setBenPlaza(socSolicitante.getSolPlaza());

			if (socSolicitante.getClaVigente() != null)
				benefi.setClaEntidad(Integer.valueOf(socSolicitante.getClaVigente()));
			beneficiarios.add(benefi);
		}
		return beneficiarios;
	}
}
