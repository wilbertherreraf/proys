/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.bpm.pruebaCU;


/**
 *
 * @author CUriona
 */

@SuppressWarnings("serial")
public class Datos implements java.io.Serializable {
	private String menCodigo;
	private Integer camBloque;
	private String camCodigo;
    private String mdtValor;
    private String camNombre;
    private String mesCodigo;
    private String camDefinicion;
    public Datos() {
    	
    }

	public Datos(String menCodigo, Integer camBloque, String camCodigo,
			String mdtValor, String camNombre) {
		super();
		this.menCodigo = menCodigo;
		this.camBloque = camBloque;
		this.camCodigo = camCodigo;
		this.mdtValor = mdtValor;
		this.camNombre = camNombre;
	}

	public String getMenCodigo() {
		return menCodigo;
	}

	public void setMenCodigo(String menCodigo) {
		this.menCodigo = menCodigo;
	}

	public Integer getCamBloque() {
		return camBloque;
	}

	public void setCamBloque(Integer camBloque) {
		this.camBloque = camBloque;
	}

	public String getCamCodigo() {
		return camCodigo;
	}

	public void setCamCodigo(String camCodigo) {
		this.camCodigo = camCodigo;
	}

	public String getMdtValor() {
		return mdtValor;
	}

	public void setMdtValor(String mdtValor) {
		this.mdtValor = mdtValor;
	}

	public String getCamNombre() {
		return camNombre;
	}

	public void setCamNombre(String camNombre) {
		this.camNombre = camNombre;
	}

	public String getMesCodigo() {
		return mesCodigo;
	}

	public void setMesCodigo(String mesCodigo) {
		this.mesCodigo = mesCodigo;
	}

	public String getCamDefinicion() {
		return camDefinicion;
	}

	public void setCamDefinicion(String camDefinicion) {
		this.camDefinicion = camDefinicion;
	}
    
}