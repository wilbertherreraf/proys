/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.bpm.pruebaCU;

import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.pojos.BancoPlaza;
import gob.bcb.swift.commons.ConstantsSwift;
import gob.bcb.swift.dao.SwfPersonactaBean;
import gob.bcb.swift.model.SwfPersonacta;
import gob.bcb.swift.model.SwfPersonactaPK;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;
@Transactional
public class SocBenefsregDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocBenefsregDao.class);

	public void saveOrUpdate(SocBenefs socBenefs, SocBenefsreg socBenefsreg) {
		log.info("Saving or updating " + socBenefsreg);

		SocBenefsreg socBenefsregOld = getBenefsregByCodBen(socBenefsreg.getSolCodigo(), socBenefsreg.getBenCodigo(), socBenefsreg.getCuentab());

		if (socBenefsregOld == null) {
			Integer cod = generarCodigo();

			socBenefsreg.setNroRegbenef(cod);
			socBenefsreg.setBenCodigo(socBenefs.getBenCodigo());
		}

		this.getHibernateTemplate().saveOrUpdate(socBenefsreg);
	}

	public SocBenefsreg getBenefsregByCodigo(Integer nroRegbenef) {

		StringBuffer query = new StringBuffer();
		query = query.append("select be ");
		query = query.append("from SocBenefsreg be ");
		query = query.append("where be.nroRegbenef = :nroRegbenef ");

		log.debug("Entre a buscar getBenefsregByCod id: " + nroRegbenef);
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("nroRegbenef", nroRegbenef);
		List lista = consulta.list();

		if (lista.size() > 0) {
			return (SocBenefsreg) lista.get(0);
		}

		return null;
	}

	public SocBenefsreg getBenefsregByCodBen(String solCodigo, String benCodigo, String cuentab) {

		StringBuffer query = new StringBuffer();
		query = query.append("select be ");
		query = query.append("from SocBenefsreg be ");
		query = query.append("where be.benCodigo = :benCodigo ");
		query = query.append("and be.solCodigo = :solCodigo ");
		query = query.append("and be.cuentab = :cuentab ");

		log.debug("Entre a buscar getBenefsregByCod id: " + solCodigo + " " + benCodigo);
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("benCodigo", benCodigo);
		consulta.setParameter("solCodigo", solCodigo);
		consulta.setParameter("cuentab", cuentab);

		List lista = consulta.list();

		if (lista.size() > 0) {
			return (SocBenefsreg) lista.get(0);
		}

		return null;
	}

	public Solicitud registroBenef(Solicitud solicitudTO) {
		log.info("Registro de nuevo beneficiario " + solicitudTO.getBeneficiario().getSocBenefs().toString());
		SocUsuariosolDao socUsuariosolDao = new SocUsuariosolDao();
		socUsuariosolDao.setSessionFactory(getSessionFactory());

		SocBancosDao socBancosDao = new SocBancosDao();
		socBancosDao.setSessionFactory(getSessionFactory());

		SocBenefsDao socBenefsDao = new SocBenefsDao();
		socBenefsDao.setSessionFactory(getSessionFactory());

		SocSolbenefsDao socSolbenefsDao = new SocSolbenefsDao();
		socSolbenefsDao.setSessionFactory(getSessionFactory());

		SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
		socSolicitanteDao.setSessionFactory(getSessionFactory());
		
		Beneficiario beneficiario = solicitudTO.getBeneficiario();
		SocBenefs socBenefs = beneficiario.getSocBenefs();
		// 1. registro del beneficiario
		socBenefs.setUsrCodigo(solicitudTO.getCodUsuarioAudit());
		socBenefs.setEstacion(solicitudTO.getCodEstacionAudit());
		socBenefs.setFechaHora(new Date());

		SocBenefs socBenefsNew = socBenefsDao.saveOrUpdate(socBenefs);

		SocBenefsreg socBenefsreg = beneficiario.getSocBenefsreg();

		// 3. registro de datos temporales del registro del beneficiario
		socBenefsreg.setBenEstcta(Constants.CVE_ESTBENEF_REG);

		socBenefsreg.setUsrCodigo(solicitudTO.getCodUsuarioAudit());
		socBenefsreg.setEstacion(solicitudTO.getCodEstacionAudit());
		socBenefsreg.setFechaHora(new Date());

		validarDato(socBenefsreg);

		if (socBenefsreg.getNroRegbenef() == null) {
			Integer cod = generarCodigo();

			socBenefsreg.setNroRegbenef(cod);
		}

		socBenefsreg.setBenCodigo(socBenefsNew.getBenCodigo());

		this.getHibernateTemplate().saveOrUpdate(socBenefsreg);
		SocBenefsreg socBenefsregNew = getBenefsregByCodigo(socBenefsreg.getNroRegbenef());
		
		SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCod(socBenefsregNew.getSolCodigo());

		beneficiario.setSocBenefs(socBenefsNew);
		beneficiario.setSocBenefsreg(socBenefsregNew);

		solicitudTO.setBeneficiario(beneficiario);
		
		//if (!solicitudTO.getCodPersonaAudit().equals(Constants.COD_BCB)) {
			String tipoMensajemail = "REGBENEF";
			String content = "Se registro en el sistema SIOC un nuevo beneficiario " + "\r\n";
			content += "\r\n";
			content += "Nro registro:" + socBenefsregNew.getNroRegbenef();		
			content += "\r\n";
			content += "Nombre:" + socBenefsNew.getBenNombre();
			content += "\r\n";
			content += "Entidad:" + socSolicitante.getSolPersona();		
			String subject = "Registro de beneficiario exterior:" + socBenefsregNew.getBenCodigo();
			socUsuariosolDao.formarMail(tipoMensajemail, subject, content, "'900'");
		//}
		log.info("Fin registro de nuevo beneficiario " + socBenefsregNew.toString());
		return solicitudTO;
	}

	public Solicitud preautorizarBenef(Solicitud solicitudTO) {
		SocBancosDao socBancosDao = new SocBancosDao();
		socBancosDao.setSessionFactory(getSessionFactory());

		SwfPersonactaBean swfPersonactaBean = new SwfPersonactaBean();
		swfPersonactaBean.setSessionFactory(getSessionFactory());

		SocBenefsDao socBenefsDao = new SocBenefsDao();
		socBenefsDao.setSessionFactory(getSessionFactory());

		SocSolbenefsDao socSolbenefsDao = new SocSolbenefsDao();
		socSolbenefsDao.setSessionFactory(getSessionFactory());

		SocCuentasDao socCuentasDao = new SocCuentasDao();
		socCuentasDao.setSessionFactory(getSessionFactory());
		/*********************/

		log.info("preautorizarBenef Solic de reg beneficiario " + solicitudTO.getBeneficiario().getSocBenefsreg().getNroRegbenef());
		Beneficiario beneficiario = solicitudTO.getBeneficiario();

		SocBenefsreg socBenefsregSelected = beneficiario.getSocBenefsreg();
		SocCuentas socCuentas = beneficiario.getSocCuentas();
		if (socCuentas == null){
			socCuentas = new SocCuentas();
		}

		validarDato(socBenefsregSelected);

		SocBenefs socBenefs = beneficiario.getSocBenefs();

		socBenefs.setUsrCodigo(solicitudTO.getCodUsuarioAudit());
		socBenefs.setEstacion(solicitudTO.getCodEstacionAudit());
		socBenefs.setFechaHora(new Date());

		// 1. actualizamos el beneficiario
		SocBenefs socBenefsNew = socBenefsDao.saveOrUpdate(socBenefs);

		// 3. salvamos los bancos si los mismos no fueron creados

		if (StringUtils.isBlank(socBenefsregSelected.getBcoCodigo())) {
			log.info("Cta sin banco seleccionado se crea...");
			// SocBancos socBancos = beneficiario.getSocBancos();
			SocBancos socBancos = new SocBancos();
			SocPlazasId socPlazasId = new SocPlazasId();
			SocPlazas socPlazas = new SocPlazas();
			socPlazas.setId(socPlazasId);

			socBancos.setBcoNombre(socBenefsregSelected.getBanco());
			socPlazas.setPlaNombre(socBenefsregSelected.getPlaza());
			
			if (!StringUtils.isBlank(socBenefsregSelected.getBic())) {
				if (!StringUtils.isBlank(socBenefsregSelected.getIdent())) {
					if (socBenefsregSelected.getIdent().equals(Constants.CVE_TIPOBCOINST_BIC)) {
						socPlazas.setPlaBic(socBenefsregSelected.getBic());
					}
				}
			}

			socBancos.setUsrCodigo(solicitudTO.getCodUsuarioAudit());
			socBancos.setEstacion(solicitudTO.getCodEstacionAudit());

			//SocPlazas socPlazas = beneficiario.getSocPlazas();
			SocBancos socBancosnew = socBancosDao.saveOrUpdate(socBancos, socPlazas);

			socBenefsregSelected.setBcoCodigo(socBancosnew.getBcoCodigo());

		}

		// 5. salvamos el bco intermediario si corresponde
		if (socBenefsregSelected.getBenTipoctainst().equals(Constants.CVE_TIPOCTAINST_CONINT)) {
			if (StringUtils.isBlank(socBenefsregSelected.getBcoCodigointer())) {
				log.info("Cta sin banco intermediario seleccionado se crea...");
				//SocBancos socBancos = beneficiario.getSocBancosInter();
				SocBancos socBancos = new SocBancos();
				SocPlazasId socPlazasId = new SocPlazasId();
				SocPlazas socPlazas = new SocPlazas();
				socPlazas.setId(socPlazasId);
				
				socBancos.setUsrCodigo(solicitudTO.getCodUsuarioAudit());
				socBancos.setEstacion(solicitudTO.getCodEstacionAudit());
				
				socBancos.setBcoNombre(socBenefsregSelected.getBancoInt());
				socPlazas.setPlaNombre(socBenefsregSelected.getPlazaInt());
				socPlazas.setPlaBic(socBenefsregSelected.getBicInt());
				//SocPlazas socPlazas = beneficiario.getSocPlazasInter();
				SocBancos socBancosnew = socBancosDao.saveOrUpdate(socBancos, socPlazas);

				socBenefsregSelected.setBcoCodigointer(socBancosnew.getBcoCodigo());
			}
		}

		// 6. salvamos la cuenta
		socCuentas.setSolCodigo(socBenefsregSelected.getSolCodigo());
		socCuentas.setBenCodigo(socBenefsNew.getBenCodigo());
		socCuentas.setBcoCodigo(socBenefsregSelected.getBcoCodigo());
		socCuentas.setPlaCodigo(1);
		socCuentas.setClaVigente(Short.valueOf("0"));
		socCuentas.setCtaNrocuenta(socBenefsregSelected.getCuentab());
		socCuentas.setMoneda(socBenefsregSelected.getCodMoneda());
		socCuentas.setCtaInfo(socBenefsregSelected.getInfo());		
		socCuentas.setBcoNrocuentaben(socBenefsregSelected.getBcoNrocuentaben());
		socCuentas.setCveTipbcoben(socBenefsregSelected.getIdent());
		socCuentas.setBcoCodigointer(socBenefsregSelected.getBcoCodigointer());

		socCuentas.setUsrCodigo(solicitudTO.getCodUsuarioAudit());
		socCuentas.setEstacion(solicitudTO.getCodEstacionAudit());

		SocCuentas socCuentasnew = socCuentasDao.saveOrUpdate(socCuentas);

		// 2. registro del la rel solicitante beneficiario
		SocSolbenefsId socSolbenefsId = new SocSolbenefsId();
		socSolbenefsId.setBenCodigo(socBenefsNew.getBenCodigo());
		socSolbenefsId.setSolCodigo(socBenefsregSelected.getSolCodigo());

		SocSolbenefs socSolbenef = new SocSolbenefs();
		socSolbenef.setId(socSolbenefsId);

		socSolbenef.setClaVigente(Short.valueOf("1"));
		socSolbenef.setCtaCodigobco(socCuentasnew.getCtaCodigo());
		socSolbenef.setEstacion(solicitudTO.getCodEstacionAudit());
		socSolbenef.setUsrCodigo(solicitudTO.getCodUsuarioAudit());

		// ******** salvando relacion solicitante beneficiario *********//
		socSolbenefsDao.saveOrUpdate(socSolbenef);

		socBenefsregSelected.setCtaCodigobco(socCuentasnew.getCtaCodigo());
		socBenefsregSelected.setBenEstcta(Constants.CVE_ESTBENEF_VERIF);
		socBenefsregSelected.setUsrCodigo(solicitudTO.getCodUsuarioAudit());
		socBenefsregSelected.setEstacion(solicitudTO.getCodEstacionAudit());
		socBenefsregSelected.setFechaHora(new Date());

		this.getHibernateTemplate().saveOrUpdate(socBenefsregSelected);

		log.info("Preautorizando registro beneficiao..." + socBenefsregSelected.getNroRegbenef());

		beneficiario.setSocBenefs(socBenefsNew);
		beneficiario.setSocBenefsreg(socBenefsregSelected);
		beneficiario.setSocCuentas(socCuentasnew);

		solicitudTO.setBeneficiario(beneficiario);

		return solicitudTO;
	}

	public Solicitud autorizarBenef(Solicitud solicitudTO) {
		SocBancosDao socBancosDao = new SocBancosDao();
		socBancosDao.setSessionFactory(getSessionFactory());

		SwfPersonactaBean swfPersonactaBean = new SwfPersonactaBean();
		swfPersonactaBean.setSessionFactory(getSessionFactory());

		SocBenefsDao socBenefsDao = new SocBenefsDao();
		socBenefsDao.setSessionFactory(getSessionFactory());

		SocSolbenefsDao socSolbenefsDao = new SocSolbenefsDao();
		socSolbenefsDao.setSessionFactory(getSessionFactory());

		SocCuentasDao socCuentasDao = new SocCuentasDao();
		socCuentasDao.setSessionFactory(getSessionFactory());
		/*********************/

		log.info("autorizarBenef beneficiario ");
		Beneficiario beneficiario = solicitudTO.getBeneficiario();

		SocBenefsreg socBenefsregSelected = getBenefsregByCodigo(solicitudTO.getBeneficiario().getSocBenefsreg().getNroRegbenef());

		SocCuentas socCuentas = socCuentasDao.getSocCuentasByCodigo(socBenefsregSelected.getCtaCodigobco());

		SocBenefs socBenefs = socBenefsDao.getBenefsByBenCodigo(socCuentas.getBenCodigo());

		socBenefs.setUsrCodigo(solicitudTO.getCodUsuarioAudit());
		socBenefs.setEstacion(solicitudTO.getCodEstacionAudit());
		socBenefs.setFechaHora(new Date());
		socBenefs.setClaVigente(Short.valueOf("1"));

		this.getHibernateTemplate().saveOrUpdate(socBenefs);

		socCuentas.setClaVigente(Short.valueOf("1"));
		socCuentas.setUsrCodigo(solicitudTO.getCodUsuarioAudit());
		socCuentas.setEstacion(solicitudTO.getCodEstacionAudit());

		this.getHibernateTemplate().saveOrUpdate(socCuentas);

		socBenefsregSelected.setBenEstcta(Constants.CVE_ESTBENEF_AUT);
		socBenefsregSelected.setUsrCodigo(solicitudTO.getCodUsuarioAudit());
		socBenefsregSelected.setEstacion(solicitudTO.getCodEstacionAudit());
		socBenefsregSelected.setFechaHora(new Date());

		this.getHibernateTemplate().saveOrUpdate(socBenefsregSelected);

		log.info("Autorizando registro beneficiao..." + socBenefsregSelected.getNroRegbenef());

		solicitudTO.setBeneficiario(beneficiario);

		return solicitudTO;
	}

	public Solicitud rechazarRegBenef(Solicitud solicitudTO) {
		SocBancosDao socBancosDao = new SocBancosDao();
		socBancosDao.setSessionFactory(getSessionFactory());

		SwfPersonactaBean swfPersonactaBean = new SwfPersonactaBean();
		swfPersonactaBean.setSessionFactory(getSessionFactory());

		SocBenefsDao socBenefsDao = new SocBenefsDao();
		socBenefsDao.setSessionFactory(getSessionFactory());

		SocSolbenefsDao socSolbenefsDao = new SocSolbenefsDao();
		socSolbenefsDao.setSessionFactory(getSessionFactory());

		SocCuentasDao socCuentasDao = new SocCuentasDao();
		socCuentasDao.setSessionFactory(getSessionFactory());
		/*********************/

		Beneficiario beneficiario = solicitudTO.getBeneficiario();
		log.info("Rechanzado registro beneficiario "  + solicitudTO.getBeneficiario().getSocBenefsreg().getNroRegbenef());
		SocBenefsreg socBenefsregSelected = getBenefsregByCodigo(solicitudTO.getBeneficiario().getSocBenefsreg().getNroRegbenef());

		SocCuentas socCuentas = socCuentasDao.getSocCuentasByCodigo(socBenefsregSelected.getCtaCodigobco());

		SocBenefs socBenefs = socBenefsDao.getBenefsByBenCodigo(socCuentas.getBenCodigo());

		socBenefs.setUsrCodigo(solicitudTO.getCodUsuarioAudit());
		socBenefs.setEstacion(solicitudTO.getCodEstacionAudit());
		socBenefs.setFechaHora(new Date());
		socBenefs.setClaVigente(Short.valueOf("0"));

		this.getHibernateTemplate().saveOrUpdate(socBenefs);

		socCuentas.setClaVigente(Short.valueOf("0"));
		socCuentas.setUsrCodigo(solicitudTO.getCodUsuarioAudit());
		socCuentas.setEstacion(solicitudTO.getCodEstacionAudit());

		this.getHibernateTemplate().saveOrUpdate(socCuentas);

		socBenefsregSelected.setBenEstcta(Constants.CVE_ESTBENEF_REG);
		socBenefsregSelected.setUsrCodigo(solicitudTO.getCodUsuarioAudit());
		socBenefsregSelected.setEstacion(solicitudTO.getCodEstacionAudit());
		socBenefsregSelected.setFechaHora(new Date());

		this.getHibernateTemplate().saveOrUpdate(socBenefsregSelected);

		log.info("Rechazado registro beneficiao..." + socBenefsregSelected.getNroRegbenef());

		solicitudTO.setBeneficiario(beneficiario);

		return solicitudTO;
	}
	
	public Solicitud registrarBeneficiario(Solicitud solicitudTO) {
		log.info("registrarBeneficiario nuevo beneficiario ");
		solicitudTO = registroBenef(solicitudTO);

		if (solicitudTO.getCodPersonaAudit().equals(Constants.COD_BCB)) {
			solicitudTO = preautorizarBenef(solicitudTO);
		}

		return solicitudTO;
	}

	public void validarDato(SocBenefsreg socBenefsreg) {
		if (StringUtils.isBlank(socBenefsreg.getSolCodigo())) {
			throw new BusinessException("Codigo de solicitante invalido");
		}
		if (StringUtils.isBlank(socBenefsreg.getIdent())) {
			throw new BusinessException("Tipo cuenta banco invalido");
		}

		if (StringUtils.isBlank(socBenefsreg.getBcoCodigo())) {
			if (StringUtils.isBlank(socBenefsreg.getBanco())) {
				throw new BusinessException("Banco con nombre invalido");
			}
			if (StringUtils.isBlank(socBenefsreg.getPlaza())) {
				throw new BusinessException("Plaza con nombre invalido");
			}
			if (socBenefsreg.getIdent().equals(Constants.CVE_TIPOBCOINST_BIC)) {
				if (StringUtils.isBlank(socBenefsreg.getBic())) {
					//throw new BusinessException("BIC banco beneficiario invalido");
				}
			}
		}

		if (StringUtils.isBlank(socBenefsreg.getCuentab())) {
			throw new BusinessException("Numero cuenta beneficiario invalido");
		}
		if (socBenefsreg.getCodMoneda() == null) {
			throw new BusinessException("Moneda cuenta beneficiario invalido");
		}
		if (socBenefsreg.getIdent().equals(Constants.CVE_TIPOBCOINST_ABA)) {
			if (StringUtils.isBlank(socBenefsreg.getBcoNrocuentaben())) {
				throw new BusinessException("Nro cta banco beneficiario invalido");
			}
		}
		if (StringUtils.isBlank(socBenefsreg.getBenTipoctainst())) {
			throw new BusinessException("Tipo de intermediario invalido");
		}

		if (socBenefsreg.getIdent().equals(Constants.CVE_TIPOBCOINST_INTER)
				|| socBenefsreg.getBenTipoctainst().equals(Constants.CVE_TIPOCTAINST_CONINT)) {
			if (StringUtils.isBlank(socBenefsreg.getBcoCodigointer())) {
				if (StringUtils.isBlank(socBenefsreg.getBancoInt())) {
					throw new BusinessException("Banco Intermediario con nombre invalido");
				}
				if (StringUtils.isBlank(socBenefsreg.getPlazaInt())) {
					throw new BusinessException("Banco Intermediario con Plaza invalido");
				}
				if (StringUtils.isBlank(socBenefsreg.getBicInt())) {
					//throw new BusinessException("Banco Intermediario con BIC invalido");
				}
			}
		}
	}

	private Integer generarCodigo() {
		StringBuffer query = new StringBuffer();
		query = query.append("select max(nro_regbenef) ");
		query = query.append("from soc_benefsreg ");

		Query consulta = getSession().createSQLQuery(query.toString());

		log.debug("Entre a generarCod " + consulta.toString());

		String codSolicitud = "0";
		Long codigo = Long.valueOf(0);

		Integer maxi = null;
		List result = consulta.list();
		if (result.size() > 0)
			maxi = (Integer) result.get(0);

		if (maxi == null) {
			maxi = 0;
		}

		maxi++;

		// codSolicitud = String.format("%06d", codigo);
		// Integer codBen = Integer.valueOf(codSolicitud);
		log.info("Cod registro benef nuevo: " + codigo);
		return maxi;
	}

}
