package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the soc_rengesq database table.
 * 
 */
@Embeddable
public class SocRengesqPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="esq_codigo")
	private Integer esqCodigo;

	@Column(name="det_codigo")
	private Integer detCodigo;

    public SocRengesqPK() {
    }
	public Integer getEsqCodigo() {
		return this.esqCodigo;
	}
	public void setEsqCodigo(Integer esqCodigo) {
		this.esqCodigo = esqCodigo;
	}
	public Integer getDetCodigo() {
		return this.detCodigo;
	}
	public void setDetCodigo(Integer detCodigo) {
		this.detCodigo = detCodigo;
	}
	
	public String toString() {
		return "SocRengesqPK [esqCodigo=" + esqCodigo + ", detCodigo=" + detCodigo + "]";
	}
	
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((detCodigo == null) ? 0 : detCodigo.hashCode());
		result = prime * result + ((esqCodigo == null) ? 0 : esqCodigo.hashCode());
		return result;
	}
	
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SocRengesqPK other = (SocRengesqPK) obj;
		if (detCodigo == null) {
			if (other.detCodigo != null)
				return false;
		} else if (!detCodigo.equals(other.detCodigo))
			return false;
		if (esqCodigo == null) {
			if (other.esqCodigo != null)
				return false;
		} else if (!esqCodigo.equals(other.esqCodigo))
			return false;
		return true;
	}


}
