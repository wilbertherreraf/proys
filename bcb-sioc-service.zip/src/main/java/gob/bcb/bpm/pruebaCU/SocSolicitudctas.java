package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the soc_solicitudctas database table.
 * 
 */
@Entity
@Table(name="soc_solicitudctas")
public class SocSolicitudctas implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SocSolicitudctasPK id;

	@Column(name="cod_moneda")
	private Integer codMoneda;

	@Column(name="cod_usuario")
	private String codUsuario;

	@Column(name="descrip_libreta")
	private String descripLibreta;

	@Column(name="cod_banco")
	private String codBanco;

	@Column(name="sol_codigo")
	private String solCodigo;
	
	@Column(name="nro_cuentabco")
	private String nroCuentabco;
	
	@Column(name="cve_tipcuenta")
	private String cveTipcuenta;

	@Column(name="cve_tipocomis")
	private String cveTipocomis;
	
	@Column(name="cta_afectable")
	private String ctaAfectable;
	
	private String estacion;

    @Temporal( TemporalType.TIMESTAMP)
	@Column(name="fecha_hora")
	private Date fechaHora;

	@Column(name="nro_cuenta")
	private String nroCuenta;

	@Column(name="nro_libreta")
	private String nroLibreta;

    public SocSolicitudctas() {
    }

	public SocSolicitudctasPK getId() {
		return this.id;
	}

	public void setId(SocSolicitudctasPK id) {
		this.id = id;
	}
	
	public Integer getCodMoneda() {
		return this.codMoneda;
	}

	public void setCodMoneda(Integer codMoneda) {
		this.codMoneda = codMoneda;
	}

	public String getCodUsuario() {
		return this.codUsuario;
	}

	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}

	public String getDescripLibreta() {
		return this.descripLibreta;
	}

	public void setDescripLibreta(String descripLibreta) {
		this.descripLibreta = descripLibreta;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getNroCuenta() {
		return this.nroCuenta;
	}

	public void setNroCuenta(String nroCuenta) {
		this.nroCuenta = nroCuenta;
	}

	public String getNroLibreta() {
		return this.nroLibreta;
	}

	public void setNroLibreta(String nroLibreta) {
		this.nroLibreta = nroLibreta;
	}

	public String getNroCuentabco() {
		return nroCuentabco;
	}

	public void setNroCuentabco(String nroCuentabco) {
		this.nroCuentabco = nroCuentabco;
	}

	public String getCodBanco() {
		return codBanco;
	}

	public void setCodBanco(String codBanco) {
		this.codBanco = codBanco;
	}

	public String getSolCodigo() {
		return solCodigo;
	}

	public void setSolCodigo(String solCodigo) {
		this.solCodigo = solCodigo;
	}

	public String getCveTipcuenta() {
		return cveTipcuenta;
	}

	public void setCveTipcuenta(String cveTipcuenta) {
		this.cveTipcuenta = cveTipcuenta;
	}

	public String getCveTipocomis() {
		return cveTipocomis;
	}

	public void setCveTipocomis(String cveTipocomis) {
		this.cveTipocomis = cveTipocomis;
	}

	public String getCtaAfectable() {
		return ctaAfectable;
	}

	public void setCtaAfectable(String ctaAfectable) {
		this.ctaAfectable = ctaAfectable;
	}

	
	public String toString() {
		return "SocSolicitudctas [id=" + id + ", codMoneda=" + codMoneda + ", codUsuario=" + codUsuario + ", descripLibreta=" + descripLibreta
				+ ", codBanco=" + codBanco + ", solCodigo=" + solCodigo + ", nroCuentabco=" + nroCuentabco + ", cveTipcuenta=" + cveTipcuenta
				+ ", cveTipocomis=" + cveTipocomis + ", ctaAfectable=" + ctaAfectable + ", estacion=" + estacion + ", fechaHora=" + fechaHora
				+ ", nroCuenta=" + nroCuenta + ", nroLibreta=" + nroLibreta + "]";
	}

}
