package gob.bcb.bpm.pruebaCU;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.TemporalType;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.pojos.BancoPlaza;
import gob.bcb.service.servicioSioc.pojos.Detallesol;

@Transactional
public class CarCartascrDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(CarCartascrDao.class);

	public void saveOrUpdate(CarCartascr pm) {
		log.info("Saving or updating CarCartascr " + pm);
		pm.setCcrAuditfho(new Date());

		this.getHibernateTemplate().saveOrUpdate(pm);
	}

	public CarCartascr findByCodcartacr(String codcartacr) throws BusinessException {
		StringBuffer query = new StringBuffer();
		query = query.append("select cc ");
		query = query.append("from CarCartascr cc ");
		query = query.append("where cc.ccrCodcartacr = :ccrCodcartacr ");

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("ccrCodcartacr", codcartacr);

		List<CarCartascr> lista = consulta.list();

		if (lista.size() > 0) {
			return lista.get(0);
		}
		throw new BusinessException("Registro inexistente " + codcartacr);
	}

	public CarCartascr findByCodcartacrEstcred(String codcartacr, String ccrEstadoccred) throws BusinessException {
		StringBuffer query = new StringBuffer();
		query = query.append("select cc ");
		query = query.append("from CarCartascr cc ");
		query = query.append("where cc.ccrCodcartacr = :ccrCodcartacr ");
		query = query.append("and cc.ccrEstadoccred = :ccrEstadoccred ");

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("ccrCodcartacr", codcartacr);
		consulta.setParameter("ccrEstadoccred", ccrEstadoccred);

		List<CarCartascr> lista = consulta.list();

		if (lista.size() > 0) {
			return lista.get(0);
		}
		throw new BusinessException("Registro inexistente " + codcartacr + " o con estado diferente a: " + ccrEstadoccred);
	}

	public CarCartascr findBySoccodigo(String ccrSoccodigo) throws BusinessException {
		StringBuffer query = new StringBuffer();
		query = query.append("select cc ");
		query = query.append("from CarCartascr cc ");
		query = query.append("where cc.ccrSoccodigo = :ccrSoccodigo ");

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("ccrSoccodigo", ccrSoccodigo);

		List<CarCartascr> lista = consulta.list();

		if (lista.size() == 1) {
			return lista.get(0);
		}
		throw new BusinessException("Registro inexistente para solicitud: " + ccrSoccodigo);
	}

	public List<CarCartascr> findCarCartascrdetVigentesPendientes() {
		StringBuffer query = new StringBuffer();
		query = query.append("select cc ");
		query = query.append("from CarCartascr cc ");
		query = query.append("where cc.ccrEstadoccred = :ccrEstadoccred ");
		query = query.append("and not exists ( ");
		query = query.append("select 1 ");
		query = query.append("from CarCartascrdet cd ");
		query = query.append("where cd.ccdEstmovccred != :ccdEstmovccred ");
		query = query.append("and cd.ccdEstregistro = 'V' ");
		query = query.append("and cd.id.ccdCodcartacr = cc.ccrCodcartacr ");
		query = query.append(") ");
		query = query.append("and exists ( ");
		query = query.append("select 1 ");
		query = query.append("from CarCartascrdet cd ");
		query = query.append("where cd.ccdEstregistro = 'V' ");
		query = query.append("and cd.id.ccdCodcartacr = cc.ccrCodcartacr ");
		query = query.append(") ");
		query = query.append("order by cc.ccrCodcartacr ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("ccrEstadoccred", Constants.CLAVE_CCRED_ESTCARTACRED_VIGENTE);
		consulta.setParameter("ccdEstmovccred", Constants.CLAVE_CCRED_ESTMOVDETALLE_AUTORIZADO);
		List<CarCartascr> lista = consulta.list();

		return lista;
	}

	public Integer nextNroCorr(String codcartacr, String ccrtipoimpexp, Integer ccranio) {
		StringBuffer query = new StringBuffer();
		query = query.append("select max(ccrNrocorr) ");
		query = query.append("from CarCartascr ");
		query = query.append("where ccrTipoimpexp = :ccrtipoimpexp ");
		query = query.append("and ccrAnio = :ccranio ");

		if (!StringUtils.isBlank(codcartacr)) {
			query = query.append("and ccrCodcartacr != :codcartacr ");
		}

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("ccrtipoimpexp", ccrtipoimpexp);
		consulta.setParameter("ccranio", ccranio);

		if (!StringUtils.isBlank(codcartacr)) {
			consulta.setParameter("codcartacr", codcartacr);
		}
		// log.debug("nextNroCorr " + consulta.toString());
		Integer maxDet = Integer.valueOf(0);
		List result = consulta.list();
		if (result.size() > 0)
			maxDet = (Integer) result.get(0);

		if (maxDet == null)
			maxDet = 0;
		maxDet++;
		return maxDet;
	}

	public String generarCodigo() {
		StringBuffer query = new StringBuffer();
		query = query.append("select max(to_number(ccr_codcartacr)) ");
		query = query.append("from car_cartascr ");
		query = query.append("where ccr_codcartacr not matches '*[a-z|A-Z|.|,]*' ");

		Query consulta = getSession().createSQLQuery(query.toString());

		String codSolicitud = "0";
		Long codigo = Long.valueOf(0);

		BigDecimal maxi = BigDecimal.ZERO;
		List result = consulta.list();
		if (result.size() > 0)
			maxi = (BigDecimal) result.get(0);

		if (maxi != null) {
			codigo = Long.valueOf(maxi.toPlainString());
			codigo++;
		} else {
			codigo = Long.valueOf(1);
		}

		codSolicitud = String.format("%06d", codigo);

		log.info("Cod carta nuevo: " + codSolicitud);
		return codSolicitud;
	}

	public List<CarCartascrdet> findCarCartascrdetForNotif() {
		StringBuffer query = new StringBuffer();
		query = query.append("select cd ");
		query = query.append("from CarCartascr cc, CarCartascrdet cd, SocSolicitudes s ");
		query = query.append("where cc.ccrCodcartacr = cd.id.ccdCodcartacr ");
		query = query.append("and cd.ccdSoccodigo = s.socCodigo ");
		query = query.append("and s.claEstadows != :claEstadows ");
		query = query.append("and s.claEstado != 'Z' ");
		query = query.append("and cd.ccdEstregistro = 'V' ");
		query = query.append("and cd.ccdEstmovccred = :ccdEstmovccred ");

		query = query.append("order by cd.id.ccdCodcartacr, cd.id.ccdNroccreddet ");

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("claEstadows", Constants.CLAVE_ESTWS_NOTIF);
		consulta.setParameter("ccdEstmovccred", Constants.CLAVE_CCRED_ESTMOVDETALLE_AUTORIZADO);

		List<CarCartascrdet> lista = consulta.list();
		return lista;
	}

	public List<CarCartascrdet> findCarCartascrdet(CarCartascr carCartascr, CarCartascrdet carCartascrdet) {
		StringBuffer query = new StringBuffer();
		query = query.append("select cd ");
		query = query.append("from CarCartascr cc, CarCartascrdet cd ");
		query = query.append("where cc.ccrCodcartacr = cd.id.ccdCodcartacr ");
		query = query.append("and cd.ccdEstregistro = 'V' ");

		if (!StringUtils.isBlank(carCartascr.getCcrCodcartacr())) {
			query = query.append("and cc.ccrCodcartacr = :ccrCodcartacr ");
		}

		if (!StringUtils.isBlank(carCartascr.getCcrSolcodigo())) {
			query = query.append("and cc.ccrSolcodigo = :ccrSolcodigo ");
		}

		if (!StringUtils.isBlank(carCartascr.getCcrEstadoccred())) {
			query = query.append("and cc.ccrEstadoccred = :ccrEstadoccred ");
		}

		if (carCartascr.getCcrFechaemis() != null) {
			query = query.append("and cc.ccrFechaemis >= :ccrFechaemis ");
		}

		if (carCartascr.getCcrFechavtopag() != null) {
			query = query.append("and cc.ccrFechaemis <= :ccrFechavtopag ");
		}

		// if (!StringUtils.isBlank(carCartascrdet.getCcdTipomov())) {
		// query = query.append("and cd.ccdTipomov = :ccdTipomov ");
		// }

		if (!StringUtils.isBlank(carCartascrdet.getCcdTipoemision())) {
			query = query.append("and cd.ccdTipoemision = :ccdTipoemision ");
		}

		if (carCartascrdet.getCcdFechareg() != null) {
			query = query.append("and cd.ccdFechacont >= :ccdFechareg ");
		}

		if (carCartascrdet.getCcdFechacargo() != null) {
			query = query.append("and cd.ccdFechacont <= :ccdFechacargo ");
		}

		if (!StringUtils.isBlank(carCartascrdet.getCcdEstmovccred())) {
			query = query.append("and cd.ccdEstmovccred = :ccdEstmovccred ");
		}
		query = query.append("order by cd.id.ccdCodcartacr, cd.id.ccdNroccreddet ");

		Query consulta = getSession().createQuery(query.toString());

		if (!StringUtils.isBlank(carCartascr.getCcrCodcartacr())) {
			consulta.setParameter("ccrCodcartacr", carCartascr.getCcrCodcartacr());
		}

		if (!StringUtils.isBlank(carCartascr.getCcrSolcodigo())) {
			consulta.setParameter("ccrSolcodigo", carCartascr.getCcrSolcodigo());
		}

		if (!StringUtils.isBlank(carCartascr.getCcrEstadoccred())) {
			consulta.setParameter("ccrEstadoccred", carCartascr.getCcrEstadoccred());
		}

		if (carCartascr.getCcrFechaemis() != null) {
			consulta.setParameter("ccrFechaemis", carCartascr.getCcrFechaemis());
		}

		if (carCartascr.getCcrFechavtopag() != null) {
			consulta.setParameter("ccrFechavtopag", carCartascr.getCcrFechavtopag());
		}

		// if (!StringUtils.isBlank(carCartascrdet.getCcdTipomov())) {
		// consulta.setParameter("ccdTipomov", carCartascrdet.getCcdTipomov());
		// }

		if (!StringUtils.isBlank(carCartascrdet.getCcdTipoemision())) {
			consulta.setParameter("ccdTipoemision", carCartascrdet.getCcdTipoemision());
		}

		if (carCartascrdet.getCcdFechareg() != null) {
			consulta.setParameter("ccdFechareg", carCartascrdet.getCcdFechareg());
		}

		if (carCartascrdet.getCcdFechacargo() != null) {
			consulta.setParameter("ccdFechacargo", carCartascrdet.getCcdFechacargo());
		}

		if (!StringUtils.isBlank(carCartascrdet.getCcdEstmovccred())) {
			consulta.setParameter("ccdEstmovccred", carCartascrdet.getCcdEstmovccred());
		}

		List<CarCartascrdet> lista = consulta.list();
		return lista;
	}

	public List<Detallesol> buscarCartas(CarCartascr carCartascrIn, CarCartascrdet carCartascrdetIn) {
		List<Detallesol> detallesolLista = new ArrayList<Detallesol>();

		SocValoresclaDao socValoresclaDao = new SocValoresclaDao();
		socValoresclaDao.setSessionFactory(getSessionFactory());

		SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
		socSolicitanteDao.setSessionFactory(getSessionFactory());

		List<CarCartascrdet> carCartascrdetLista = findCarCartascrdet(carCartascrIn, carCartascrdetIn);

		Map<String, CarCartascr> carCartascrCrtl = new HashMap<String, CarCartascr>();

		for (CarCartascrdet carCartascrdet : carCartascrdetLista) {
			if (!carCartascrCrtl.containsKey(carCartascrdet.getId().getCcdCodcartacr())) {

				Detallesol detallesol = new Detallesol();
				CarCartascr carCartascr = findByCodcartacr(carCartascrdet.getId().getCcdCodcartacr());
				detallesol.setCarCartascr(carCartascr);

				SocValorescla socValorescla = socValoresclaDao.getValoresByCod(Constants.CVE_ESTADO_OPERACION_CARTACREDITO, String.valueOf(carCartascrdet.getCcdEstmovccred()));
				detallesol.setSocValorescla(socValorescla);

				SocValorescla socValorescla2 = socValoresclaDao.getValoresByCod(Constants.CVE_TIPOEMISION, String.valueOf(carCartascrdet.getCcdTipoemision()));
				detallesol.setSocValorescla2(socValorescla2);

				SocValorescla socValorescla3 = socValoresclaDao.getValoresByCod(Constants.CVE_ESTADO_CARTACREDITO, String.valueOf(carCartascr.getCcrEstadoccred()));
				detallesol.setSocValorescla3(socValorescla3);

				SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCod(carCartascr.getCcrSolcodigo());
				detallesol.setSocSolicitante(socSolicitante);

				CarCartascr carCartascrAux = new CarCartascr();
				carCartascrAux.setCcrCodcartacr(carCartascr.getCcrCodcartacr());

				List<CarCartascrdet> carCartascrListaAux = findCarCartascrdet(carCartascrAux, carCartascrdetIn);
				detallesol.setCarCartascrdet(carCartascrListaAux.get(0));

				detallesolLista.add(detallesol);

				carCartascrCrtl.put(carCartascr.getCcrCodcartacr(), carCartascr);
			}
		}
		return detallesolLista;
	}

	public List<Detallesol> cartasVigentesPendientes() {
		List<Detallesol> detallesolLista = new ArrayList<Detallesol>();

		SocValoresclaDao socValoresclaDao = new SocValoresclaDao();
		socValoresclaDao.setSessionFactory(getSessionFactory());

		SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
		socSolicitanteDao.setSessionFactory(getSessionFactory());

		List<CarCartascr> carCartascrLista = findCarCartascrdetVigentesPendientes();

		Map<String, CarCartascr> carCartascrCrtl = new HashMap<String, CarCartascr>();

		CarCartascrdet carCartascrdet = new CarCartascrdet();
		// carCartascrdet.setCcdTipomov(Constants.CLAVE_CCRED_TIPOMOVDETALLE_APERTURA);
		carCartascrdet.setCcdTipoemision(Constants.CLAVE_CCRED_TIPOEMISION_EMISION);
		carCartascrdet.setCcdEstmovccred(Constants.CLAVE_CCRED_ESTMOVDETALLE_AUTORIZADO);

		for (CarCartascr carCartascr : carCartascrLista) {
			Detallesol detallesol = new Detallesol();
			detallesol.setCarCartascr(carCartascr);

			SocValorescla socValorescla = socValoresclaDao.getValoresByCod(Constants.CVE_ESTADO_CARTACREDITO, String.valueOf(carCartascr.getCcrEstadoccred()));
			detallesol.setSocValorescla(socValorescla);

			SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCod(carCartascr.getCcrSolcodigo());
			detallesol.setSocSolicitante(socSolicitante);

			CarCartascr carCartascrAux = new CarCartascr();
			carCartascrAux.setCcrCodcartacr(carCartascr.getCcrCodcartacr());

			List<CarCartascrdet> carCartascrListaAux = findCarCartascrdet(carCartascrAux, carCartascrdet);
			detallesol.setCarCartascrdet(carCartascrListaAux.get(0));

			detallesolLista.add(detallesol);

			carCartascrCrtl.put(carCartascr.getCcrCodcartacr(), carCartascr);
		}
		return detallesolLista;
	}

	public List<Detallesol> buscarCartasForNotif() {
		List<Detallesol> detallesolLista = new ArrayList<Detallesol>();

		SocValoresclaDao socValoresclaDao = new SocValoresclaDao();
		socValoresclaDao.setSessionFactory(getSessionFactory());

		SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
		socSolicitanteDao.setSessionFactory(getSessionFactory());

		List<CarCartascrdet> carCartascrdetLista = findCarCartascrdetForNotif();

		for (CarCartascrdet carCartascrdet : carCartascrdetLista) {
			Detallesol detallesol = new Detallesol();
			CarCartascr carCartascr = findByCodcartacr(carCartascrdet.getId().getCcdCodcartacr());
			detallesol.setCarCartascr(carCartascr);

			SocValorescla socValorescla = socValoresclaDao.getValoresByCod(Constants.CVE_ESTADO_OPERACION_CARTACREDITO, String.valueOf(carCartascrdet.getCcdEstmovccred()));
			detallesol.setSocValorescla(socValorescla);

			SocValorescla socValorescla2 = socValoresclaDao.getValoresByCod(Constants.CVE_TIPOEMISION, String.valueOf(carCartascrdet.getCcdTipoemision()));
			detallesol.setSocValorescla2(socValorescla2);

			SocValorescla socValorescla3 = socValoresclaDao.getValoresByCod(Constants.CVE_ESTADO_CARTACREDITO, String.valueOf(carCartascr.getCcrEstadoccred()));
			detallesol.setSocValorescla3(socValorescla3);

			SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCod(carCartascr.getCcrSolcodigo());
			detallesol.setSocSolicitante(socSolicitante);

			detallesol.setCarCartascrdet(carCartascrdet);

			detallesolLista.add(detallesol);
		}

		return detallesolLista;
	}

}
