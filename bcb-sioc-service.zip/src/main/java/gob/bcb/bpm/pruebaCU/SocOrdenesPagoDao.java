/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.bpm.pruebaCU;

import gob.bcb.service.commons.UserSessionHolder;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author wherrera
 * 
 */
@Transactional
public class SocOrdenesPagoDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocOrdenesPagoDao.class);

	public void saveOrUpdate(SocOrdenesPago pm) {
		log.info("Saving or updating " + pm);
		pm.setFechaHora(new Date());
		pm.setEstacion((String) UserSessionHolder.get(Constants.AUDIT_USER_ESTACION));
		pm.setUsrCodigo((String) UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID));

		this.getHibernateTemplate().saveOrUpdate(pm);
	}

	public void eliminar(SocOrdenesPago pm) {
		log.info("Eliminando SocOrdenesPago... " + pm);
		this.getHibernateTemplate().delete(pm);
	}
	public void eliminarCbp(String opaNroordenpago) {

		StringBuffer query = new StringBuffer();
		query = query.append("delete from soc_ordenespago  ");
		query = query.append("where opa_nroordenpago = :opaNroordenpago ");
		
		Query consulta = getSession().createSQLQuery(query.toString());
		
		consulta.setParameter("opaNroordenpago", opaNroordenpago);
		int rowCount = consulta.executeUpdate();
		log.info("Eliminando " + rowCount + " SocOrdenesPago... " + opaNroordenpago);		
	}

	public SocOrdenesPago getOrden(String insCodigo) {

		SocOrdenesPago opa = null;
		StringBuffer query = new StringBuffer();
		query = query.append("select oo ");
		query = query.append("from SocOrdenesPago oo ");
		query = query.append("where oo.insCodigo = :insCodigo ");

		log.info("procesando getOrden " + insCodigo + " -> " + query.toString());
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("insCodigo", insCodigo);

		List<SocOrdenesPago> lista = consulta.list();

		if (lista.size() > 0) {
			opa = lista.get(0);
		}

		return opa;
	}

	public SocOrdenesPago getOrdenBySocCod(String socCodigo, Integer detCodigo) {

		SocOrdenesPago opa = null;
		StringBuffer query = new StringBuffer();
		query = query.append("select oo ");
		query = query.append("from SocOrdenesPago oo ");
		query = query.append("where oo.socCodigo = :socCodigo ");
		query = query.append("and oo.opaImp = :detCodigo ");

		log.info("procesando getOrden socCodigo " + socCodigo + " detCodigo " + detCodigo + " -> " + query.toString());
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("socCodigo", socCodigo);
		consulta.setParameter("detCodigo", detCodigo);

		List<SocOrdenesPago> lista = consulta.list();

		if (lista.size() > 0) {
			opa = lista.get(0);
		}

		return opa;
	}

	public List<SocOrdenesPago> getOrdenesBySocCod(String socCodigo) {

		StringBuffer query = new StringBuffer();
		query = query.append("select oo ");
		query = query.append("from SocOrdenesPago oo ");
		query = query.append("where oo.socCodigo = :socCodigo ");

		log.debug("procesando getOrden socCodigo " + socCodigo + " -> " + query.toString());
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("socCodigo", socCodigo);

		List<SocOrdenesPago> lista = consulta.list();

		return lista;
	}
	public List<SocOrdenesPago> getOrdenesByComprob(String opaNroordenpago) {

		StringBuffer query = new StringBuffer();
		query = query.append("select oo ");
		query = query.append("from SocOrdenesPago oo ");
		query = query.append("where oo.opaNroordenpago = :opaNroordenpago ");

		log.info("procesando getOrden socCodigo " + opaNroordenpago + " -> " + query.toString());		
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("opaNroordenpago", opaNroordenpago);

		List<SocOrdenesPago> lista = consulta.list();

		return lista;
	}

	public List<SocOrdenesPago> getOrdenesByCodComprob(String opaNroordenpago, Character claEstadoopa) {

		StringBuffer query = new StringBuffer();
		query = query.append("select oo ");
		query = query.append("from SocOrdenesPago oo ");
		query = query.append("where oo.opaNroordenpago = :opaNroordenpago ");
		
		if (claEstadoopa != null)
			query = query.append("and oo.claEstadoopa = :claEstadoopa ");

		log.info("procesando getOrdenes opaNroordenpago " + opaNroordenpago + " claEstadoopa " + claEstadoopa + " -> " + query.toString());
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("opaNroordenpago", opaNroordenpago);
		
		if (claEstadoopa != null)
			consulta.setParameter("claEstadoopa", claEstadoopa);

		List<SocOrdenesPago> lista = consulta.list();

		return lista;
	}

	public SocOrdenesPago actualizar(SocSolicitudes socSolicitudes, SocDetallessol detalle, String tipo, Integer opaReng, String nroComprob) {
		SocOrdenesPago socOrdenesPago = getOrdenBySocCod(socSolicitudes.getSocCodigo(), detalle.getId().getDetCodigo());
		log.info("En registro de orden de pago " + socSolicitudes.getSocCodigo() + " - " + detalle.getId().getDetCodigo());
		if (socOrdenesPago == null) {
			socOrdenesPago = new SocOrdenesPago();
			
			String insCodigo = detalle.getId().getSocCodigo() + String.format("%03d", detalle.getId().getDetCodigo());
			
			socOrdenesPago.setInsCodigo(insCodigo);

			GregorianCalendar opaFechavenc = new GregorianCalendar();
			opaFechavenc.setTime(socSolicitudes.getFecha());
			opaFechavenc.add(Calendar.DATE, 30);

			socOrdenesPago.setOpaFechavenc(opaFechavenc.getTime());
			socOrdenesPago.setOpaFecha(new Date());
			// OP Generado
			socOrdenesPago.setClaEstadoopa('G');
			socOrdenesPago.setOpaImp(detalle.getId().getDetCodigo());
			socOrdenesPago.setOpaBenef(detalle.getBeneficiario());
			socOrdenesPago.setSocCodigo(detalle.getId().getSocCodigo());
			socOrdenesPago.setCodMoneda(socSolicitudes.getCodMonedat());
			socOrdenesPago.setMonto(detalle.getDetMontotrans());
			socOrdenesPago.setConcepto(socSolicitudes.getDetConcepto());
			socOrdenesPago.setOpaReng(opaReng);
			socOrdenesPago.setOpaNroordenpago(nroComprob);
			
			saveOrUpdate(socOrdenesPago);

			log.info("Orden de pago creado " + socOrdenesPago.toString());
		} else {
			if (socOrdenesPago.getClaEstadoopa().equals('G')) {
				// la orden ya existe
				if (tipo.equals("ACTDET")) {
					GregorianCalendar opaFechavenc = new GregorianCalendar();
					opaFechavenc.setTime(socSolicitudes.getFecha());
					opaFechavenc.add(Calendar.DATE, 30);

					socOrdenesPago.setOpaFechavenc(opaFechavenc.getTime());
					socOrdenesPago.setOpaFecha(new Date());
					socOrdenesPago.setOpaBenef(detalle.getBeneficiario());
					socOrdenesPago.setCodMoneda(socSolicitudes.getCodMonedat());
					socOrdenesPago.setMonto(detalle.getDetMontotrans());
					socOrdenesPago.setConcepto(socSolicitudes.getDetConcepto());

					saveOrUpdate(socOrdenesPago);

				} else if (tipo.equals("ACTRENG")) {
					GregorianCalendar opaFechavenc = new GregorianCalendar();
					opaFechavenc.setTime(socSolicitudes.getFecha());
					opaFechavenc.add(Calendar.DATE, 30);

					socOrdenesPago.setOpaFechavenc(opaFechavenc.getTime());
					socOrdenesPago.setOpaFecha(new Date());
					socOrdenesPago.setMonto(detalle.getDetMontotrans());
					socOrdenesPago.setCodMoneda(socSolicitudes.getCodMonedat());
					socOrdenesPago.setOpaReng(opaReng);
					socOrdenesPago.setOpaNroordenpago(nroComprob);

					saveOrUpdate(socOrdenesPago);
				}

				log.info("Orden de pago actualizado " + socOrdenesPago.toString());
			}
		}
		//QueryProcessor.flush();
		return socOrdenesPago;
	}

	private List<SocOrdenesPago> autorizarOP(SocComprobante socComprobante, SocDetallessol detalle, String tipo) {
		List<SocOrdenesPago> lista = getOrdenesByCodComprob(socComprobante.getCpbCodigo(), 'G');
		if (lista == null || lista.size() == 0) {
			return lista;
		}
		
		log.info("ingresando a autorizarOP " + socComprobante.toString());
		
		if (!socComprobante.getCveEstadocpb().equals(Constants.CLAVE_ESTCOMP_CONTAB)) {
			throw new RuntimeException("Error al autorizar ordenes de pago comprobante [" + socComprobante.getCpbCodigo() + "] con estado invalido "
					+ socComprobante.getCveEstadocpb());
		}

		if (StringUtils.isBlank(socComprobante.getCpbNrocpbte())) {
			throw new RuntimeException("Error al autorizar ordenes de pago comprobante [" + socComprobante.getCpbCodigo()
					+ "] con nro comprob contable nulo ");
		}

		List<OrdenPago> ops = new ArrayList<OrdenPago>();

		for (SocOrdenesPago socOrdenesPago2 : lista) {
			OrdenPago ordenPago = new OrdenPago();

			ordenPago.setNroComprob(socOrdenesPago2.getInsCodigo());
			ordenPago.setNroReng(socOrdenesPago2.getOpaReng());
			ordenPago.setNroImp(socOrdenesPago2.getOpaImp());
			ordenPago.setTipoOp('I');
			ordenPago.setMonto(socOrdenesPago2.getMonto());
			ordenPago.setMoneda(socOrdenesPago2.getCodMoneda());
			ordenPago.setBenef(socOrdenesPago2.getOpaBenef());
			ordenPago.setConcepto(socOrdenesPago2.getConcepto());

			ops.add(ordenPago);
		}

		if (ops.size() > 0) {
			
			Map<String, Object> mapaParametros3 = new HashMap<String, Object>();
			mapaParametros3.put("consulta", "ops");
			mapaParametros3.put("comp", socComprobante.getCpbNrocpbte());
			mapaParametros3.put("ops", ops);

			log.info("Llamando al servicio de coin: crear OP " + ops.toString());

			SiocCoinService siocCoinService = new SiocCoinService();
			siocCoinService.executeTask(mapaParametros3);

			// ahora el proceso es automatico se crea e inmediatamente se autoriza
			
			for (SocOrdenesPago socOrdenesPago2 : lista) {
				mapaParametros3 = new HashMap<String, Object>();
				mapaParametros3.put("consulta", "opa");
				mapaParametros3.put("comp", socComprobante.getCpbNrocpbte());
				mapaParametros3.put("imp", socOrdenesPago2.getOpaImp());

				log.info("Llamando al servicio de coin: autorizar OP " + socOrdenesPago2.toString());

				Map<String, Object> mapaResultado3 = siocCoinService.executeTask(mapaParametros3);
				
				socOrdenesPago2.setClaEstadoopa('P');
				socOrdenesPago2.setOpaNroordenpago(socComprobante.getCpbNrocpbte());

				saveOrUpdate(socOrdenesPago2);
				log.info("Orden de pago autorizado  " + socOrdenesPago2.toString());
			}
			QueryProcessor.flush();
			
		}
		return lista;
	}
	
	public void revalidarOP(SocOrdenesPago socOrdenesPago){
		SocOrdenesPago socOrdenesPagoOld = getOrden(socOrdenesPago.getInsCodigo());

		if (socOrdenesPagoOld == null) {
			throw new BusinessException("Orden de pago [" + socOrdenesPago.getInsCodigo() + "]inexistente ");
		}
		
		SocComprobanteDao socComprobanteDao = new SocComprobanteDao();
		socComprobanteDao.setSessionFactory(getSessionFactory());
		SocComprobante socComprobante = socComprobanteDao.getComprobante(socOrdenesPagoOld.getOpaNroordenpago());
		if (socComprobante == null){
			
		}
		
		GregorianCalendar opaFechavenc = new GregorianCalendar();
		opaFechavenc.setTime(socOrdenesPagoOld.getOpaFechavenc());
		opaFechavenc.add(Calendar.DATE, 30);
		socOrdenesPagoOld.setOpaFechavenc(opaFechavenc.getTime());
		
		String nroComprob = socComprobante.getCpbNrocpbte();
		Integer imp = socOrdenesPagoOld.getOpaImp();

		Map<String, Object> mapaParametros3 = new HashMap<String, Object>();
		mapaParametros3.put("consulta", "opaR");
		mapaParametros3.put("comp", nroComprob);
		mapaParametros3.put("imp", imp);
		mapaParametros3.put("fecha", opaFechavenc.getTime());

		log.info("Llamando al servicio de coin: revalidar OP");

		SiocCoinService siocCoinService = new SiocCoinService();
		Map<String, Object> mapaResultado3 = siocCoinService.executeTask(mapaParametros3);
		nroComprob = (String) mapaResultado3.get("comp");
		
		socOrdenesPagoOld.setUsrCodigo(socOrdenesPago.getUsrCodigo());
		socOrdenesPagoOld.setEstacion(socOrdenesPago.getEstacion());
		
		this.getHibernateTemplate().saveOrUpdate(socOrdenesPagoOld);		
	
	}
}
