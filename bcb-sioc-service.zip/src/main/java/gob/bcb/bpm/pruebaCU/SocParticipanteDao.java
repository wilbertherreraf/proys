/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.bpm.pruebaCU;

//import java.util.ArrayList;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

//import org.hibernate.Query;

/**
 * @author parenas
 * 
 */
public class SocParticipanteDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocParticipanteDao.class);

	public void saveOrUpdate(SocParticipante pm) {
		log.info("Saving or updating " + pm);
		this.getHibernateTemplate().saveOrUpdate(pm);
	}

	public List<SocParticipante> getParticipantes() {
		List<SocParticipante> lista = new ArrayList<SocParticipante>();
		Query consulta = getSession().createQuery("from SocParticipante");
		lista = consulta.list();

		return lista;
	}

	public SocParticipante getParticipante(String solCodigo) {
		log.info("Entre a buscar el objeto con el id: " + solCodigo);

		SocParticipante part = null;
		StringBuffer query = new StringBuffer();
		query = query.append("select pp ");
		query = query.append("from SocParticipante pp ");
		query = query.append("where pp.id.solCodigo = :solCodigo ");

		Query consulta = getSession().createQuery(query.toString());
		consulta.setString("solCodigo", solCodigo);

		List lista = consulta.list();
		if (lista.size() > 0) {
			return (SocParticipante) lista.get(0);
		}
		return null;
	}

}
