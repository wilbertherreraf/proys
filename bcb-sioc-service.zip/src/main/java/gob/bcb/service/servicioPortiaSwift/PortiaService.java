/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-service-prototype
 * gob.bcb.service.prototype.server.PortiaService
 * 13/05/2011 - 13:58:49
 * Creado por scriales
 */
package gob.bcb.service.servicioPortiaSwift;

import gob.bcb.bpm.pruebaCU.FactoryDao;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import gob.bcb.core.persist.EntityUserTransactionPortia;
import gob.bcb.service.commons.UserSessionHolder;
import gob.bcb.service.servicioPortiaSwift.model.Loader;
import gob.bcb.service.servicioPortiaSwift.model.LoaderDao;
import gob.bcb.service.servicioSioc.common.Constants;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * ServiceWorkerProducer del prototipo, reemplazar por el del servicio.
 * 
 * @author scriales
 * 
 */
public class PortiaService extends EntityUserTransactionPortia {
	private static final Log log = LogFactory.getLog(PortiaService.class);
	private FactoryDao factoryDao;

	/**
	 * Constructor
	 */
	public PortiaService() {
		setNameSessionFactory(Constants.PROP_ALIAS_PORTIA);		
		log.info("nuevo PortiaService ha sido creado. " + getNameSessionFactory());
		factoryDao = new FactoryDao();
		Map<String, Object> mapa = new HashMap<String, Object>();

		LoaderDao loaderDao = new LoaderDao();
		mapa.put("LoaderDao", loaderDao);

		for (Iterator<?> i = mapa.keySet().iterator(); i.hasNext();) {
			String key = (String) i.next();
			HibernateDaoSupport hibernateDaoSupport =(HibernateDaoSupport) mapa.get(key); 
			hibernateDaoSupport.setSessionFactory(getSessionFactory());
			hibernateDaoSupport.getHibernateTemplate().setAllowCreate(false);
		}		
		factoryDao.setDaos(mapa);		
	}

	public void setFactoryDao(FactoryDao factoryDao) {
		this.factoryDao = factoryDao;
	}

	public FactoryDao getFactoryDao() {
		return factoryDao;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.feature.BcbAbstractServiceWorker#executeTask()
	 */

	public Map<String, Object> executeTask(Map<String, Object> mapaParametros) {

		// capturando el mapa de parametros de la clase padre

		Map<String, Object> mapaRespuesta = new HashMap<String, Object>();
		String tipoCon = (String) mapaParametros.get("consulta");
		log.info("===>[" + getNameSessionFactory() + "] llamando a la tarea " + tipoCon + "");
		begin();

		if (tipoCon.equals("crear")) {
			LoaderDao loaderDao = (LoaderDao) factoryDao.getDao("LoaderDao");
			flush();
			//int nroS = Servicios.getCorr();
			String USUARIO = (String) UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID);
			String ESTACION = (String) UserSessionHolder.get(Constants.AUDIT_USER_ESTACION);

			if (mapaParametros.containsKey("usuarioaudit")){
				USUARIO = (String) mapaParametros.get("usuarioaudit");
			}
			if (mapaParametros.containsKey("estacionaudit")){
				ESTACION = (String) mapaParametros.get("estacionaudit");
			}			
			//Loader maxIdLoader =  loaderDao.findMax();
			Loader maxIdLoader =  loaderDao.nuevoCodSwift(Constants.CODAPP_SIOC, ESTACION, USUARIO);
//			Long idLoader = Long.valueOf(0L);
//			if (maxIdLoader != null){
//				idLoader = maxIdLoader.getIdLoader(); 
//			}
//			idLoader++;
//			
//			//Loader ll = new Loader(Long.valueOf(i), 0, 0, nroS, '1', "SIOCWEB", ESTACION, new Date(), USUARIO);
//			Loader ll = new Loader(idLoader, 0, 0, nroS, '1', "SIOCWEB", ESTACION, new Date(), USUARIO);
//			
//			loaderDao.saveOrUpdate(ll);
			//log.info("Guardando portiawift " + nroS + ", idLoader: " + ll.getIdLoader());
			log.info("Nro swift Portia asignado " + maxIdLoader.getNumeroSwift() + " id " + maxIdLoader.getIdLoader());			

			/////////////////////////////
			mapaRespuesta.put("swift", maxIdLoader.getNumeroSwift());
			mapaRespuesta.put("loader", maxIdLoader);
		}

		flush();
		return mapaRespuesta;
	}
}
