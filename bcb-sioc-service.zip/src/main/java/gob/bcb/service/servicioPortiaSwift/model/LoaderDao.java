/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.service.servicioPortiaSwift.model;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

//import org.hibernate.Query;

/**
 * @author parenas
 * 
 */
public class LoaderDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(LoaderDao.class);

	public void saveOrUpdate(Loader pm) {
		log.info("Saving or updating " + pm);
		// this.getHibernateTemplate().merge(pm);
		this.getHibernateTemplate().saveOrUpdate(pm);
	}

	public Loader find(Long id) {
		Loader lista0 = null;

		StringBuffer query = new StringBuffer();
		query = query.append(" select re ");
		query = query.append(" from ");
		query = query.append(" Loader re ");
		query = query.append(" where re.idLoader = :codigo ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("codigo", id);

		List lista = consulta.list();
		if (lista.size() > 0) {
			Loader loader = (Loader) lista.get(0);
			return loader;
		}
		return null;
	}

	public Loader findMax() {
		StringBuffer query = new StringBuffer();
		query = query.append(" select re ");
		query = query.append(" from Loader re ");
		query = query.append(" where re.idLoader = (select max(r1.idLoader) from Loader r1) ");

		Query consulta = getSession().createQuery(query.toString());

		List lista = consulta.list();
		if (lista.size() > 0) {
			Loader loader = (Loader) lista.get(0);
			return loader;
		}
		return null;
	}

	public Loader findByCodigo(Long idLoader) {

		StringBuilder query = new StringBuilder();
		
	    query = query.append(" select re ");
	    query = query.append(" from Loader re ");
	    query = query.append(" where re.idLoader = :idLoader ");

		Query consulta = getSession().createQuery(query.toString());
		
		consulta.setParameter("idLoader", idLoader);
		
		List lista =  consulta.list();
		if (lista.size() > 0){
			return (Loader) lista.get(0); 
		}

		return null;		
	}	
	
	public Loader findByNroSwift(Integer nroSwift) {

		StringBuffer query = new StringBuffer();
		query = query.append("select re ");
		query = query.append("from Loader re ");
		query = query.append("where re.numeroSwift = :codigo ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("codigo", nroSwift);

		List lista = consulta.list();
		if (lista.size() > 0) {
			Loader loader = (Loader) lista.get(0);
			return loader;
		}
		return null;
	}

	public Loader nuevoCodSwift(String idSistema, String auditWst, String auditUsr) {
		Integer codSwift = maxNroSwift();
		Long idLoader = getCodigo();

		logger.info("numero SWIFT obtenito: " + codSwift + " idLoader " + idLoader);

		Loader loader = new Loader();
		loader.setIdLoader(idLoader);
		loader.setIdBase(0);
		loader.setIdPortia(0);
		loader.setNumeroSwift(codSwift);
		loader.setEstado('0');
		loader.setDescrip(idSistema);
		loader.setEstacion(auditWst);
		loader.setFechaHora(new Date());
		loader.setUsuario(auditUsr);
		saveOrUpdate(loader);
		
		this.getHibernateTemplate().save(loader);
		
		Loader loaderNew = findByCodigo(idLoader);
		logger.info("registro Swift en PORTIA a crear: " + loaderNew.toString());
		return loader;
	}

	public Integer maxNroSwift() {

		StringBuilder jsql = new StringBuilder();
		jsql.append("select max(l.numeroSwift) from Loader l");

		Query query = getSession().createQuery(jsql.toString());

		List result = query.list();
		if (result.size() > 0) {
			Integer maximo = (Integer) result.get(0);
			return (maximo == null ? Integer.valueOf(1) : ++maximo);
		}

		return Integer.valueOf(0);
	}
	public Long getCodigo() {
		Loader loader = findMax();
		if (loader == null){
			logger.error("No se pudo recuperar nro swift");
			return 1L;
			//throw new RuntimeException("No se pudo recuperar nro swift");
		}
 
		Long codigo = loader.getIdLoader() + 1;
		logger.info("IdLoader : " + codigo);		
		return codigo;

	}
	
}
