/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gob.bcb.service.servicioPortiaSwift.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * 
 * @author faflores
 */
@Entity
@Table(name = "loader")
@NamedQueries({ @NamedQuery(name = "Loader.findAll", query = "SELECT l FROM Loader l") })
public class Loader implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@Basic(optional = false)
	@Column(name = "id_loader")
	private Long idLoader;
	@Basic(optional = false)
	@Column(name = "id_base")
	private Integer idBase;
	@Basic(optional = false)
	@Column(name = "id_portia")
	private Integer idPortia;
	@Basic(optional = false)
	@Column(name = "numero_swift")
	private Integer numeroSwift;
	@Column(name = "estado")
	private char estado;
	@Column(name = "descrip")
	private String descrip;
	@Basic(optional = false)
	@Column(name = "estacion")
	private String estacion;
	@Basic(optional = false)
	@Column(name = "fecha_hora")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fechaHora;
	@Basic(optional = false)
	@Column(name = "usuario")
	private String usuario;

	public Loader() {
	}

	public Loader(Long idLoader) {
		this.idLoader = idLoader;
	}

	public Loader(Long idLoader, Integer idBase, Integer idPortia, Integer numeroSwift, char estado, String descrip, String estacion, Date fechaHora,
			String usuario) {
		this.idLoader = idLoader;
		this.idBase = idBase;
		this.idPortia = idPortia;
		this.numeroSwift = numeroSwift;
		this.estado = estado;
		this.descrip = descrip;
		this.estacion = estacion;
		this.fechaHora = fechaHora;
		this.usuario = usuario;
	}

	public Long getIdLoader() {
		return idLoader;
	}

	public void setIdLoader(Long idLoader) {
		this.idLoader = idLoader;
	}

	public Integer getIdBase() {
		return idBase;
	}

	public void setIdBase(Integer idBase) {
		this.idBase = idBase;
	}

	public Integer getIdPortia() {
		return idPortia;
	}

	public void setIdPortia(Integer idPortia) {
		this.idPortia = idPortia;
	}

	public Integer getNumeroSwift() {
		return numeroSwift;
	}

	public void setNumeroSwift(Integer numeroSwift) {
		this.numeroSwift = numeroSwift;
	}

	public char getEstado() {
		return estado;
	}

	public void setEstado(char estado) {
		this.estado = estado;
	}

	public String getDescrip() {
		return descrip;
	}

	public void setDescrip(String descrip) {
		this.descrip = descrip;
	}

	public String getEstacion() {
		return estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	
	public int hashCode() {
		int hash = 0;
		hash += (idLoader != null ? idLoader.hashCode() : 0);
		return hash;
	}

	
	public boolean equals(Object object) {
		// TODO: Warning - this method won't work in the case the id fields are
		// not
		// set
		if (!(object instanceof Loader)) {
			return false;
		}
		Loader other = (Loader) object;
		if ((this.idLoader == null && other.idLoader != null) || (this.idLoader != null && !this.idLoader.equals(other.idLoader))) {
			return false;
		}
		return true;
	}

	
	public String toString() {
		return "gob.bcb.service.servicioPortiaSwift.model.Loader[idLoader=" + idLoader + "]";
	}

}
