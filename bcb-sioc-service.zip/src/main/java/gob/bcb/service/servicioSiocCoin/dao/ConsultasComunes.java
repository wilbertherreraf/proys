package gob.bcb.service.servicioSiocCoin.dao;

import gob.bcb.core.utils.UtilsQNatives;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class ConsultasComunes extends HibernateDaoSupport {
	private Logger log = Logger.getLogger(ConsultasComunes.class);

	public Map<String, Object> persona(String codPersona) {
		Session session = getSession();

		StringBuffer query = new StringBuffer();
		query = query.append("select trim(nom_persona) || '' nompersona, ruc || '' ruc ");
		query = query.append("from persona ");
		query = query.append("where cod_persona = :codPersona ");

		log.info("Consulta Persona coin " + codPersona + " " + query.toString());

		Query consulta = session.createSQLQuery(query.toString());

		consulta.setParameter("codPersona", codPersona);

		List result = consulta.list();

		List<Map<String, Object>> resultado = UtilsQNatives.convertListToMap(result, "nompersona,ruc".split(","));

		if (resultado.size() > 0) {
			return resultado.get(0);
		}
		return null;
	}
}
