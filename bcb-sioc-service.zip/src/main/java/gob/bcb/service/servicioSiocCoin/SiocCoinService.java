/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-service-prototype
 * bcb.service.prototype.server.SiocCoinService
 * 13/05/2011 - 13:58:49
 * Creado por scriales
 */
package gob.bcb.service.servicioSiocCoin;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.jdbc.Work;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import gob.bcb.bpm.pruebaCU.FactoryDao;
import gob.bcb.bpm.pruebaCU.OrdenPago;
import gob.bcb.bpm.pruebaCU.QueryProcessor;
import gob.bcb.bpm.pruebaCU.SocComprobante;
import gob.bcb.bpm.pruebaCU.SocComprobanteDao;
import gob.bcb.bpm.pruebaCU.SocFacturas;
import gob.bcb.bpm.pruebaCU.SocRengscomp;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.core.exception.DataBaseException;
import gob.bcb.core.persist.EntityUserTransactionCoin;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioTres.model.Comprobante;
import gob.bcb.service.servicioTres.model.ComprobanteDao;
import gob.bcb.service.servicioTres.model.EstadoComprobDao;
import gob.bcb.service.servicioTres.model.FactorConvMnDao;
import gob.bcb.service.servicioTres.model.FacturaConceptoDao;
import gob.bcb.service.servicioTres.model.FacturaConceptoSinCreditoDao;
import gob.bcb.service.servicioTres.model.FacturaDao;
import gob.bcb.service.servicioTres.model.FacturaSinCreditoDao;
import gob.bcb.service.servicioTres.model.ImpOrdenPago;
import gob.bcb.service.servicioTres.model.ImpOrdenPagoDao;
import gob.bcb.service.servicioTres.model.ImpPresupDao;
import gob.bcb.service.servicioTres.model.ImpSigmaDao;
import gob.bcb.service.servicioTres.model.RengComprobDao;
import gob.bcb.service.servicioTres.model.RengConciliaDao;
import gob.bcb.service.servicioTres.model.SaldoConciliaDao;
import gob.bcb.service.servicioTres.model.Servicios;

/**
 * ServiceWorkerProducer del prototipo, reemplazar por el del servicio.
 * 
 * @author wherrera
 * 
 */
public class SiocCoinService extends EntityUserTransactionCoin {
	private static final Log log = LogFactory.getLog(SiocCoinService.class);
	private FactoryDao factoryDao;
	private static final int NUM_INTENTOS_POR_KEY_LOCKED = 50;
	private static final int TIEMPO_ESPERA_POR_KEY_LOCKED = 100;	
	/**
	 * Constructor
	 */
	public SiocCoinService() {
		setNameSessionFactory(Constants.PROP_ALIAS_COIN);
		// log.info("nuevo SiocCoinService ha sido creado. " +
		// getNameSessionFactory());
		factoryDao = new FactoryDao();
		Map<String, Object> mapa = new HashMap<String, Object>();

		FactorConvMnDao factorConvMnDao = new FactorConvMnDao();
		mapa.put("FactorConvMnDao", factorConvMnDao);
		ComprobanteDao comprobanteDao = new ComprobanteDao();
		mapa.put("ComprobanteDao", comprobanteDao);
		EstadoComprobDao estadoComprobDao = new EstadoComprobDao();
		mapa.put("EstadoComprobDao", estadoComprobDao);
		RengComprobDao rengComprobDao = new RengComprobDao();
		mapa.put("RengComprobDao", rengComprobDao);
		ImpSigmaDao impSigmaDao = new ImpSigmaDao();
		mapa.put("ImpSigmaDao", impSigmaDao);
		ImpPresupDao impPresupDao = new ImpPresupDao();
		mapa.put("ImpPresupDao", impPresupDao);
		ImpOrdenPagoDao impOrdenPagoDao = new ImpOrdenPagoDao();
		mapa.put("ImpOrdenPagoDao", impOrdenPagoDao);
		FacturaDao facturaDao = new FacturaDao();
		mapa.put("FacturaDao", facturaDao);
		FacturaConceptoDao facturaConceptoDao = new FacturaConceptoDao();
		mapa.put("FacturaConceptoDao", facturaConceptoDao);
		RengConciliaDao rengConciliaDao = new RengConciliaDao();
		mapa.put("RengConciliaDao", rengConciliaDao);
		SaldoConciliaDao saldoConciliaDao = new SaldoConciliaDao();
		mapa.put("SaldoConciliaDao", saldoConciliaDao);
		FacturaSinCreditoDao facturaSinCreditoDao = new FacturaSinCreditoDao();
		mapa.put("FacturaSinCreditoDao", facturaSinCreditoDao);
		FacturaConceptoSinCreditoDao facturaConceptoSinCreditoDao = new FacturaConceptoSinCreditoDao();
		mapa.put("FacturaConceptoSinCreditoDao", facturaConceptoSinCreditoDao);

		for (Iterator<?> i = mapa.keySet().iterator(); i.hasNext();) {
			String key = (String) i.next();
			HibernateDaoSupport hibernateDaoSupport = (HibernateDaoSupport) mapa.get(key);
			hibernateDaoSupport.setSessionFactory(getSessionFactory());
			hibernateDaoSupport.getHibernateTemplate().setAllowCreate(false);
		}
		factoryDao.setDaos(mapa);

	}

	public void setFactoryDao(FactoryDao factoryDao) {
		this.factoryDao = factoryDao;
	}

	public FactoryDao getFactoryDao() {
		return factoryDao;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.feature.BcbAbstractServiceWorker#executeTask()
	 */

	private static final Object monitor = new Object();

	public Map<String, Object> executeTask(Map<String, Object> mapaParametros) {
		Map<String, Object> mapaRespuesta = new HashMap<String, Object>();
		String tipoCon = (String) mapaParametros.get("consulta");

		begin();

		if (tipoCon.equals("tc")) {
			Date fecha = (Date) mapaParametros.get("fecha");
			int moneda = (Integer) mapaParametros.get("moneda");
			FactorConvMnDao dao = (FactorConvMnDao) factoryDao.getDao("FactorConvMnDao");
			BigDecimal tc = dao.getTC(moneda, fecha);
			// cargando la respuesta a mapa
			mapaRespuesta.put("tc", tc);
			flush();

			return mapaRespuesta;
		}

		ImpOrdenPagoDao ordenPagoDao = (ImpOrdenPagoDao) factoryDao.getDao("ImpOrdenPagoDao");

		log.debug("=> => => ===>[" + getNameSessionFactory() + "] llamando a la tarea {" + tipoCon + "} <= <= <= ");
		if (tipoCon.equals("dia")) {
			Date dia = null;

			String query = " select fecha_dia " + "from dia " + "where cve_estado_dia = 'A'";

			List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "fecha_dia".split(","));
			if (resultado.size() == 1) {
				for (Map<String, Object> res : resultado) {
					dia = (Date) res.get("fecha_dia");
				}
			} else {
				log.error("No existe un da abierto ");
				throw new RuntimeException("No existe un da abierto ");
			}

			// cargando la respuesta a mapa
			mapaRespuesta.put("dia", dia);
		} else if (tipoCon.equals("crear")) {
			SocComprobanteDao socCompDao = new SocComprobanteDao();
			socCompDao.setSessionFactory(QueryProcessor.getSessionFactory());
			
			SocComprobante comprob = (SocComprobante) mapaParametros.get("comp");
			List<SocRengscomp> rengs = socCompDao.completarCodigosMayores(comprob.getCpbCodigo());			
			log.info("Inicio crear comprobante " + comprob.getCpbCodigo());
			
			String nroEsquemaContbcb = socCompDao.obtenerNroEsquemaContbcb(comprob);
			comprob.setEsqCodesqcont(nroEsquemaContbcb);
			
			//List<SocRengscomp> rengs = (List<SocRengscomp>) mapaParametros.get("rengs");
			List<SocFacturas> facts = (List<SocFacturas>) mapaParametros.get("facts");

			ComprobanteDao compDao = (ComprobanteDao) factoryDao.getDao("ComprobanteDao");
			// ##### crear comprobante coin ##### //
			String comp = compDao.CrearComprobante(comprob, rengs, facts);
			
			comprob.setCpbNrocpbte(comp);
			comprob.setCveEstadocpb(Constants.CLAVE_ESTCOMP_CONTAB);

			socCompDao.saveOrUpdate(comprob);
			log.info("Comprobante [nrocompro: " + comp + ", CpbCodigo: " + comprob.getCpbCodigo() + "] creado satisfactoriamente");
			mapaRespuesta.put("comp", comp);
			mapaRespuesta.put("socComprobante", comprob);

		} else if (tipoCon.equals("ops")) {

			// Modificado para adecuacin del core
			String comprob = (String) mapaParametros.get("comp");
			List<OrdenPago> ops = (List<OrdenPago>) mapaParametros.get("ops");

			String comp = ordenPagoDao.CrearOrdenPago(comprob, ops);
			mapaRespuesta.put("comp", comp);

		} else if (tipoCon.equals("opa")) {

			// Modificado para adecuacin del core
			String comprob = (String) mapaParametros.get("comp");
			Integer imp = (Integer) mapaParametros.get("imp");

			ImpOrdenPago op = ordenPagoDao.getOrdenPago(comprob, imp);

			op.setCveEstadoOp('P');
			op.setFechaHora(new Date());
			ordenPagoDao.saveOrUpdate(op);
			mapaRespuesta.put("comp", comprob);

		} else if (tipoCon.equals("opaA")) {
			// Modificado para adecuacin del core
			String comprob = (String) mapaParametros.get("comp");
			Integer imp = (Integer) mapaParametros.get("imp");

			ImpOrdenPago op = ordenPagoDao.getOrdenPago(comprob, imp);

			op.setCveEstadoOp('Y');
			op.setFechaHora(new Date());
			ordenPagoDao.saveOrUpdate(op);

			mapaRespuesta.put("comp", comprob);

		} else if (tipoCon.equals("opActualizar")) {
			// Modificado para adecuacin del core
			String comprob = (String) mapaParametros.get("comp");
			Integer imp = (Integer) mapaParametros.get("imp");

			ImpOrdenPago op = ordenPagoDao.getOrdenPago(comprob, imp);

			mapaRespuesta.put("estado", op.getCveEstadoOp());

		} else if (tipoCon.equals("opaR")) {

			// Modificado para adecuaci del core
			String comprob = (String) mapaParametros.get("comp");
			Integer imp = (Integer) mapaParametros.get("imp");
			Date ff = (Date) mapaParametros.get("fecha");

			ImpOrdenPago op = ordenPagoDao.getOrdenPago(comprob, imp);
			if (op == null) {
				throw new RuntimeException("Orden de pago inexistente " + comprob + " " + imp);
			}
			if (op.getCveEstadoOp() == 'P') {
				op.setFechaVencim(ff);
				op.setFechaReval(new Date());
				op.setFechaHora(new Date());
				ordenPagoDao.saveOrUpdate(op);
			} else {
				throw new RuntimeException("Orden de pago " + comprob + " " + imp + " con estado invalido " + op.getCveEstadoOp());
			}
			mapaRespuesta.put("comp", comprob);
		} else if (tipoCon.equals("mayor")) {
			// Modificado para adecuacin del core
			String cod_movimiento = (String) mapaParametros.get("movi");

			// String movi = (String)
			// request.getParameterFromQueryRequest("movi");
			String mayor = "";
			String cod_mayor = "";

			String query = "select m.nro_mayor || '' nro_mayor, substr(c.cod_tipo_cuenta, 1, 4) cod_mayor ";
			query = query.concat("from cuenta_movimiento c, cuenta_mayor m ");
			query = query.concat("where substr(c.cod_tipo_cuenta, 1, 4) = m.cod_mayor "); 
			query = query.concat("and m.nro_centro = 1 "); 
			query = query.concat("and c.cod_movimiento = '" + cod_movimiento + "'");

			List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "nro_mayor,cod_mayor".split(","));
			if (resultado.size() == 1) {
				for (Map<String, Object> res : resultado) {
					mayor = (String) res.get("nro_mayor");
					cod_mayor = (String) res.get("cod_mayor");
				}
			} else {
				log.error("Error al obtener nmero de mayor " + cod_movimiento);
				throw new RuntimeException("Error al obtener nmero de mayor " + cod_movimiento);
			}

			mapaRespuesta.put("mayor", mayor);
			mapaRespuesta.put("cod_mayor", cod_mayor);			
		} else if (tipoCon.equals("nit")) {
			// Modificado para adecuacin del core
			String soli = (String) mapaParametros.get("soli");

			// String soli = (String)
			// request.getParameterFromQueryRequest("soli");
			String nit = "";

			String query = " select ruc || '' ruc " + "from persona " + "where trim(cod_persona) = '" + soli + "'";

			List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "ruc".split(","));
			if (resultado.size() == 1) {
				for (Map<String, Object> res : resultado) {
					nit = (String) res.get("ruc");
				}
			} else {
				log.error("Error al obtener NIT");
			}

			mapaRespuesta.put("nit", nit);
		} else if (tipoCon.equals("persona")) {
			// Modificado para adecuacin del core
			String soli = (String) mapaParametros.get("soli");

			// String soli = (String)
			// request.getParameterFromQueryRequest("soli");
			String persona = "";
			String nit = "";

			String query = " select trim(nom_persona) || '' persona,  ruc || '' ruc " + "from persona " + "where trim(cod_persona) = '" + soli + "'";

			List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "persona,ruc".split(","));
			if (resultado.size() == 1) {
				for (Map<String, Object> res : resultado) {
					log.info("resultado" + res.toString());
					persona = (String) res.get("persona");
					nit = (String) res.get("ruc");
				}
			}

			mapaRespuesta.put("persona", persona);
			mapaRespuesta.put("nit", nit);

		} else if (tipoCon.equals("saldo")) {
			// Modificado para adecuacin del core
			String afec = (String) mapaParametros.get("afec");
			Integer gestion = (Integer) mapaParametros.get("gestion");
			Integer periodo = (Integer) mapaParametros.get("periodo");
			Integer dia = (Integer) mapaParametros.get("dia");

			BigDecimal saldo = BigDecimal.valueOf(0.00);

			saldo = Servicios.getSaldo(afec, gestion, periodo, dia);

			mapaRespuesta.put("saldo", saldo);
		} else if (tipoCon.equals("concilia")) {
			// Modificado para adecuacin del core
			String comprob = (String) mapaParametros.get("comprob");

			int nro = 0;

			nro = Servicios.getConciliable(comprob);

			mapaRespuesta.put("nro", nro);
		}
		flush();
		return mapaRespuesta;
	}

	public List<Comprobante> contabilizar(List<Solicitud> solicitudLista) {
		log.info("############## [CONTA] ##############");
		List<Comprobante> comprobanteLista = null;
		synchronized (monitor) {

			long startTime = System.currentTimeMillis();
//			ComprobanteDao compDao = new ComprobanteDao();
//			compDao.setSessionFactory(getSessionFactory());

			ImpOrdenPagoDao impOrdenPagoDao = new ImpOrdenPagoDao();
			impOrdenPagoDao.setSessionFactory(getSessionFactory());

			// begin();

			boolean existsKeyLocked = false;
			int intentos = 0;
			
		
			do {
				begin();
				//Session session = getSessionFactory().getCurrentSession();	
//				Session session = getSessionFactory().getCurrentSession();
//				Transaction tx = session.beginTransaction();
								
//				//transaction.begin();
				log.info("===>Antes del isolation<=== TRANSACTION_SERIALIZABLE ");
				
				existsKeyLocked = false;
				try {
					log.info("getSessionFactory().getCurrentSession().isConnected() " + getSessionFactory().getCurrentSession().connection().getTransactionIsolation());					
					comprobanteLista = new ArrayList<Comprobante>();					
					intentos++;
					//getSessionFactory().getCurrentSession().connection().setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
					getSessionFactory().getCurrentSession().doWork( new Work() {
						@Override
						public void execute(Connection connection) throws SQLException {
							connection.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
						}
					} );
					log.info("getTransactionIsolation() " + getSessionFactory().getCurrentSession().connection().getTransactionIsolation());
					String nroComprob = "";
					ComprobanteDao compDao = new ComprobanteDao();
					compDao.setSessionFactory(getSessionFactory());

					log.info("===>Despues del isolation<===");
					for (Solicitud solicitud : solicitudLista) {

						Comprobante cpbNew = compDao.crearComprobante(solicitud.getSocComprobanteLista().get(0), nroComprob,
								solicitud.getSocRengscompLista(), solicitud.getSocFacturasLista(), solicitud.getSocOrdenesPagoLista());
						
						getSessionFactory().getCurrentSession().flush();
						// autorizamos el comprobante
						// Comprobante cpbNew =
						// compDao.cambiarEstadoComprobante(cpb);

						comprobanteLista.add(cpbNew);

						solicitud.getSocComprobanteLista().get(0).setCpbNrocpbte(cpbNew.getComprobanteId().getNroComprob());

						solicitud.getSocComprobanteLista().get(0).setCveEstadocpb(Constants.CLAVE_ESTCOMP_CONTAB);

						impOrdenPagoDao.autorizarOrdenPago(cpbNew, solicitud.getSocOrdenesPagoLista());

						log.info("autorizando... " + cpbNew.getComprobanteId().getNroComprob() + " "
								+ solicitud.getSocComprobanteLista().get(0).getCpbCodigo() + " "
								+ solicitud.getSocComprobanteLista().get(0).getCveEstadocpb());
					}
					
					getSessionFactory().getCurrentSession().flush();
					
					long endTime = System.currentTimeMillis();
					log.info("duracion autorizacion conta. (" + (endTime - startTime) + " ms.)");
					
				} catch (Exception e) {
					StringBuilder sb = new StringBuilder();
					int count = 0;
					for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
						if (cause instanceof SQLException) {
							count++;
							sb.append(cause.getMessage());
							sb.append(" , ");
						}
					}
					String consent = (count > 0 ? sb.toString().replace(", null ,", "") : e.getMessage().replace(", null ,", ""));
					//log.info("/////////////////////////////////////////////////");
					//log.info(consent);
					existsKeyLocked = consent.toLowerCase().contains("key value locked".toLowerCase());

					if (existsKeyLocked && intentos <= NUM_INTENTOS_POR_KEY_LOCKED) {
						log.error("KEY LOCKED!!!! [" +intentos+ " de "+ NUM_INTENTOS_POR_KEY_LOCKED +"]" + consent );

						try {
//							getTransaction().rollback();
//							tx.rollback();
//							session.close();							
							rollbackTransaction();
							Thread.sleep(TIEMPO_ESPERA_POR_KEY_LOCKED);
						} catch (Exception e1) {
							log.error(e1);
						}

						continue;
					}
					log.error("---)) Error en BAse de datos "  + e.getMessage(), e);		
					if (existsKeyLocked) {
						throw new DataBaseException("Aplicacion ocupada, intente nuevamente");						
					} else {
						throw new DataBaseException(e);
					}

				} finally{
//					if (session.isOpen()){
						
//					}
						//session.close();
				}
				
			} while (existsKeyLocked && intentos <= NUM_INTENTOS_POR_KEY_LOCKED);
		}

		return comprobanteLista;
	}

	public List<Comprobante> contabilizar0(List<Solicitud> solicitudLista) {
		List<Comprobante> comprobanteLista = new ArrayList<Comprobante>();

		synchronized (monitor) {

			long startTime = System.currentTimeMillis();
			ComprobanteDao compDao = new ComprobanteDao();
			compDao.setSessionFactory(getSessionFactory());

			ImpOrdenPagoDao impOrdenPagoDao = new ImpOrdenPagoDao();
			impOrdenPagoDao.setSessionFactory(getSessionFactory());

			String nroComprob = compDao.getNroComprob(1, 'G');
			Long nro = Long.valueOf(nroComprob.trim());
			begin();
			for (Solicitud solicitud : solicitudLista) {
				Comprobante cpbNew = compDao.crearComprobante(solicitud.getSocComprobanteLista().get(0), nroComprob,
						solicitud.getSocRengscompLista(), solicitud.getSocFacturasLista(), solicitud.getSocOrdenesPagoLista());

				comprobanteLista.add(cpbNew);

				solicitud.getSocComprobanteLista().get(0).setCpbNrocpbte(cpbNew.getComprobanteId().getNroComprob());
				solicitud.getSocComprobanteLista().get(0).setCveEstadocpb(Constants.CLAVE_ESTCOMP_CONTAB);
				nro++;

				impOrdenPagoDao.autorizarOrdenPago(cpbNew, solicitud.getSocOrdenesPagoLista());

				log.info("XXX: autorizando " + cpbNew.getComprobanteId().getNroComprob() + " "
						+ solicitud.getSocComprobanteLista().get(0).getCpbCodigo() + " "
						+ solicitud.getSocComprobanteLista().get(0).getCveEstadocpb());
			}

			long endTime = System.currentTimeMillis();
			log.info("duracion autorizacion conta. (" + (endTime - startTime) + " ms.)");
		}

		return comprobanteLista;
	}	
}
