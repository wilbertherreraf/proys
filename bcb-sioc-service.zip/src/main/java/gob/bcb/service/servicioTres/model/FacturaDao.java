/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.service.servicioTres.model;

import gob.bcb.bpm.pruebaCU.SocFacturas;
import gob.bcb.service.commons.UserSessionHolder;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * @author parenas
 * 
 */
public class FacturaDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(FacturaDao.class);

	public void crearFacturas(Comprobante idC, List<SocFacturas> facts) {
		
		if (facts.size() == 0){
			return;
		}
		
		FacturaSinCreditoDao facturaSinCreditoDao = new FacturaSinCreditoDao();
		facturaSinCreditoDao.setSessionFactory(getSessionFactory());

		FacturaConceptoDao facturaCDao = new FacturaConceptoDao();
		facturaCDao.setSessionFactory(getSessionFactory());
		
		for (SocFacturas fact : facts) {
			if (fact.getFacMontoexcento().compareTo(BigDecimal.valueOf(0)) == 0) {
				Map<String,String> resp = getLoteFacConCredito();
				String ordenSinCredito = resp.get("nroorden");
				String codFacSinCredito = resp.get("codfactura");

				Factura factura = new Factura(new FacturaId(idC.getComprobanteId().getNroCentro(), idC.getComprobanteId().getCveTipoComprob(), idC
						.getComprobanteId().getNroComprob(), fact.getId().getRenCodigo(), fact.getId().getFacCodigo()), fact.getCveRuc(),
						fact.getFacNit(), fact.getFacNombre(), ordenSinCredito, codFacSinCredito, new Date(), fact.getFacMontomn(), BigDecimal.valueOf(0), 'V',
						idC.getEstacion(), new Date(), idC.getCodUsuario(), 'D', fact.getFacMontoiva());

				//saveOrUpdate(factura);
				this.getHibernateTemplate().save(factura);
				FacturaConcepto factC = new FacturaConcepto(new FacturaConceptoId(idC.getComprobanteId().getNroCentro(), idC.getComprobanteId()
						.getCveTipoComprob(), idC.getComprobanteId().getNroComprob(), fact.getId().getRenCodigo(), fact.getId().getFacCodigo()),
						fact.getFacNit(), fact.getFacNombre(), fact.getFacConcepto());

				facturaCDao.saveOrUpdate(factC);
			} else if (fact.getFacMontoexcento().compareTo(BigDecimal.valueOf(0)) > 0) {
				Map<String,String> resp = getLoteFacSinCredito();
				String ordenSinCredito = resp.get("nroorden");
				String codFacSinCredito = resp.get("codfactura");
				
				FacturaSinCredito factura = new FacturaSinCredito(new FacturaSinCreditoId(idC.getComprobanteId().getNroCentro(), idC
						.getComprobanteId().getCveTipoComprob(), idC.getComprobanteId().getNroComprob(), fact.getId().getRenCodigo(), fact.getId()
						.getFacCodigo()), fact.getCveRuc(), fact.getFacNit(), fact.getFacNombre(), ordenSinCredito, codFacSinCredito,
						fact.getFacConcepto(), fact.getFacPreciounitario(), new Date(), fact.getFacMontomn(), BigDecimal.valueOf(0), 'V',
						idC.getEstacion(), new Date(), idC.getCodUsuario(), 'D', fact.getFacMontoiva(), fact.getFacMontoexcento());
				facturaSinCreditoDao.saveOrUpdate(factura);

			}
		}
		log.info("Facturas guardadas [" + idC.getComprobanteId().getNroComprob() + "] " + facts.size());

	}

	public Boolean CrearFactura(RengComprobId idC, List<SocFacturas> facts) {
		Boolean creado = false;
		String orden = null;
		String codFac = null;

		for (SocFacturas fact : facts) {
			if (fact.getFacMontoexcento().compareTo(BigDecimal.valueOf(0)) == 0) {
				orden = this.getOrden();
				codFac = this.getCodFac();
				Factura factura = new Factura(new FacturaId(idC.getNroCentro(), idC.getCveTipoComprob(), idC.getNroComprob(), idC.getNroReng(), fact
						.getId().getFacCodigo()), fact.getCveRuc(), fact.getFacNit(), fact.getFacNombre(), orden, codFac, new Date(),
						fact.getFacMontomn(), BigDecimal.valueOf(0), 'V', (String) UserSessionHolder.get(Constants.AUDIT_USER_ESTACION), new Date(),
						(String) UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID), 'D', fact.getFacMontoiva());

				this.getHibernateTemplate().saveOrUpdate(factura);

				FacturaConcepto factC = new FacturaConcepto(new FacturaConceptoId(idC.getNroCentro(), idC.getCveTipoComprob(), idC.getNroComprob(),
						idC.getNroReng(), fact.getId().getFacCodigo()), fact.getFacNit(), fact.getFacNombre(), fact.getFacConcepto());

				// FacturaConceptoDao facturaCDao = (FacturaConceptoDao)
				// SiocCoinService.factoryDao.getDao("FacturaConceptoDao");

				FacturaConceptoDao facturaCDao = new FacturaConceptoDao();
				facturaCDao.setSessionFactory(getSessionFactory());
				facturaCDao.saveOrUpdate(factC);
				creado = true;
			}
		}
		log.info("Factura guardada: ");
		return creado;
	}

	public Boolean CrearFacturaSinCredito(RengComprobId idC, List<SocFacturas> facts) {
		Boolean creado = false;
		creado = true;
		String orden = null;
		String codFac = null;

		for (SocFacturas fact : facts) {
			if (fact.getFacMontoexcento().compareTo(BigDecimal.valueOf(0)) > 0) {
				orden = this.getOrdenSinCredito();
				codFac = this.getCodFacSinCredito();
				FacturaSinCredito factura = new FacturaSinCredito(new FacturaSinCreditoId(idC.getNroCentro(), idC.getCveTipoComprob(),
						idC.getNroComprob(), idC.getNroReng(), fact.getId().getFacCodigo()), fact.getCveRuc(), fact.getFacNit(), fact.getFacNombre(),
						orden, codFac, fact.getFacConcepto(), fact.getFacPreciounitario(), new Date(), fact.getFacMontomn(), BigDecimal.valueOf(0),
						'V', (String) UserSessionHolder.get(Constants.AUDIT_USER_ESTACION), new Date(),
						(String) UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID), 'D', fact.getFacMontoiva(), fact.getFacMontoexcento());
				// FacturaSinCreditoDao facturaSinCreditoDao =
				// (FacturaSinCreditoDao)
				// SiocCoinService.factoryDao.getDao("FacturaSinCreditoDao");
				FacturaSinCreditoDao facturaSinCreditoDao = new FacturaSinCreditoDao();
				facturaSinCreditoDao.setSessionFactory(getSessionFactory());
				facturaSinCreditoDao.saveOrUpdate(factura);

				creado = true;
			}
		}
		log.info("Factura guardada: ");
		return creado;
	}

	private String getOrden() {
		String orden = "";

		String query = " select nro_orden || '' nro_orden " + "from lote_facturas " + "where nro_centro = '1' " + "and cve_vigente = 'V'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "nro_orden".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				log.info("resultado" + res.toString());
				orden = (String) res.get("nro_orden");
			}
		} else {
			log.info("Error al obtener n�mero de orden");
		}

		return orden;
	}

	private String getCodFac() {
		String codF = "";

		String query = " select cod_factura || '' cod_factura " + "from lote_facturas " + "where nro_centro = '1' " + "and cve_vigente = 'V'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "cod_factura".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				log.debug("resultado" + res.toString());
				codF = (String) res.get("cod_factura");
			}
		} else {
			log.info("Error al obtener c�digo de factura");
		}

		return codF;
	}
	private Map<String,String> getLoteFacConCredito() {
		Map<String,String> resp = new HashMap<String,String>();
		String codF = "";
		String orden = "";
		String query = "select nro_orden || '' nro_orden, cod_factura || '' cod_factura " + "from lote_facturas " + "where nro_centro = '1' " + "and cve_vigente = 'V'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "nro_orden,cod_factura".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {

				codF = (String) res.get("cod_factura");
				orden = (String) res.get("nro_orden");
			}
		} else {
			throw new BusinessException("No se pudo obtener orden y cod factura en facturas sin credito");
		}
		resp.put("nroorden", orden);
		resp.put("codfactura", codF);
		
		return resp;
	}	

	
	private String getOrdenSinCredito() {
		String orden = "";

		String query = " select nro_orden || '' nro_orden " + "from lote_facturas_sin_credito " + "where nro_centro = '1' " + "and cve_vigente = 'V'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "nro_orden".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				log.debug("resultado" + res.toString());
				orden = (String) res.get("nro_orden");
			}
		} else {
			log.info("Error al obtener n�mero de orden sin credito fiscal.");
		}

		return orden;
	}

	private String getCodFacSinCredito() {
		String codF = "";

		String query = " select cod_factura || '' cod_factura " + "from lote_facturas_sin_credito " + "where nro_centro = '1' "
				+ "and cve_vigente = 'V'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "cod_factura".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				log.debug("resultado" + res.toString());
				codF = (String) res.get("cod_factura");
			}
		} else {
			log.info("Error al obtener c�digo de factura sin credito fiscal.");
		}

		return codF;
	}
	
	private Map<String,String> getLoteFacSinCredito() {
		Map<String,String> resp = new HashMap<String,String>();
		String codF = "";
		String orden = "";
		String query = "select nro_orden || '' nro_orden, cod_factura || '' cod_factura " + "from lote_facturas_sin_credito " + "where nro_centro = '1' "
				+ "and cve_vigente = 'V' AND cve_tipo_fact_sin_cred = 'ME' ";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "nro_orden,cod_factura".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {

				codF = (String) res.get("cod_factura");
				orden = (String) res.get("nro_orden");
			}
		} else {
			throw new BusinessException("No se pudo obtener orden y cod factura en facturas sin credito");
		}
		resp.put("nroorden", orden);
		resp.put("codfactura", codF);
		
		return resp;
	}	
}