/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.service.servicioTres.model;

import gob.bcb.bpm.pruebaCU.OrdenPago;

import gob.bcb.bpm.pruebaCU.SocOrdenesPago;
import gob.bcb.service.commons.UserSessionHolder;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

//import org.hibernate.Query;

public class ImpOrdenPagoDao extends HibernateDaoSupport {
	private static final char TIPO_C = 'G';
	private static final int CENTRO = 1;
	private static final String UNIDAD = "D0004";
	private static final char ESTADO = 'C';
	private static final Log log = LogFactory.getLog(ImpOrdenPagoDao.class);

	public void saveOrUpdate(ImpOrdenPago pm) {
		log.info("Saving or updating " + pm);
		this.getHibernateTemplate().saveOrUpdate(pm);
	}

	public ImpOrdenPago getOrdenPago(String id, int imp) {
		log.info("Entre a buscar el objeto con el id: " + id);

		ImpOrdenPago op = null;
		StringBuffer query = new StringBuffer();
		query = query.append("select op ");
		query = query.append("from ImpOrdenPago op ");
		query = query.append("where op.id.nroComprob = :comp ");
		query = query.append("and op.id.nroCentro = 1 ");
		query = query.append("and op.id.cveTipoComprob = '" + TIPO_C + "' ");
		query = query.append("and op.id.nroImp = :imp ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("comp", id);
		consulta.setParameter("imp", imp);

		op = (ImpOrdenPago) consulta.uniqueResult();

		return op;
	}

	public List<ImpOrdenPago> crearOrdenPago(Comprobante comprobante, List<SocOrdenesPago> socOrdenesPagoLista) {
		List<ImpOrdenPago> impOrdenPagoLista = new ArrayList<ImpOrdenPago>(); 
		for (SocOrdenesPago op : socOrdenesPagoLista) {
			ImpOrdenPagoId idC = new ImpOrdenPagoId(comprobante.getComprobanteId().getNroCentro(),
					comprobante.getComprobanteId().getCveTipoComprob(), comprobante.getComprobanteId().getNroComprob(), op.getOpaReng(),
					op.getOpaImp());

			ImpOrdenPago impOrdenPago = new ImpOrdenPago(idC, 'I', op.getMonto(), op.getCodMoneda().toString(), op.getOpaBenef(),
					op.getConcepto(), comprobante.getCodUnidad(), ESTADO, op.getOpaFechavenc(), comprobante.getCodUsuario(), new Date(),
					comprobante.getEstacion());

			//this.saveOrUpdate(impOrdenPago);
			this.getHibernateTemplate().save(impOrdenPago);
			log.info("Orden Pago guardada: " + impOrdenPago.toString());
		}

		return impOrdenPagoLista;
	}
	
	public void autorizarOrdenPago(Comprobante comprobante, List<SocOrdenesPago> socOrdenesPagoLista) {

		for (SocOrdenesPago socOrdenesPago : socOrdenesPagoLista) {
			log.info("autorizando orden de pago "  + socOrdenesPago.getInsCodigo());			
			ImpOrdenPago op = getOrdenPago(comprobante.getComprobanteId().getNroComprob(), socOrdenesPago.getOpaImp());
			if (op != null){
				if (op.getCveEstadoOp() == 'C'){
					op.setCveEstadoOp('P');
					op.setFechaHora(new Date());
					op.setEstacion(comprobante.getEstacion());
					op.setCodUsuario(comprobante.getCodUsuario());
					
					this.getHibernateTemplate().saveOrUpdate(op);
				} else {
					log.error("Atencio!! : orden de pago "  + comprobante.getComprobanteId().getNroComprob() +" - "+ socOrdenesPago.getOpaImp() + " en estado invalido para autorizar " + op.getCveEstadoOp());
					throw new BusinessException("Orden de pago en COIN "  + comprobante.getComprobanteId().getNroComprob() +" - "+ socOrdenesPago.getOpaImp() + " en estado invalido para autorizar " + op.getCveEstadoOp());					
				}
			} else {
				log.error("Atencio!! : orden de pago "  + comprobante.getComprobanteId().getNroComprob() +" - "+ socOrdenesPago.getOpaImp() + " inexistente en coin ");
				throw new BusinessException("Orden de pago "  + comprobante.getComprobanteId().getNroComprob() +" - "+ socOrdenesPago.getOpaImp() + " inexistente en coin");
			}
		}

	}
	
	public String CrearOrdenPago(String comp, List<OrdenPago> ops) {
		for (OrdenPago op : ops) {
			ImpOrdenPagoId idC = new ImpOrdenPagoId(CENTRO, TIPO_C, comp, op.getNroReng(), op.getNroImp());

			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DATE, 30);
			Date fecha = cal.getTime();
			ImpOrdenPago impOrdenPago = new ImpOrdenPago(idC, op.getTipoOp(), op.getMonto(), op.getMoneda().toString(), op.getBenef(),
					op.getConcepto(), UNIDAD, ESTADO, fecha, (String) UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID), new Date(),
					(String) UserSessionHolder.get(Constants.AUDIT_USER_ESTACION));

			this.saveOrUpdate(impOrdenPago);
			log.info("Orden Pago guardada: " + impOrdenPago.toString());
		}

		return comp;
	}

}
