/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gob.bcb.service.servicioTres.model;



import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * 
 * @author faflores
 */
@Entity
@Table(name = "imp_orden_pago")
@NamedQueries({ @NamedQuery(name = "ImpOrdenPago.findAll", query = "SELECT i FROM ImpOrdenPago i") })
public class ImpOrdenPago implements Serializable
{
  private static final long serialVersionUID = 1L;
  @EmbeddedId
  protected ImpOrdenPagoId id;
  @Basic(optional = false)
  @Column(name = "cve_tipo_op")
  private char cveTipoOp;
  @Basic(optional = false)
  @Column(name = "monto_imp_mo")
  private BigDecimal montoImpMo;
  @Basic(optional = false)
  @Column(name = "cod_moneda")
  private String codMoneda;
  @Column(name = "serie")
  private String serie;
  @Column(name = "nro_cheque")
  private Integer nroCheque;
  @Basic(optional = false)
  @Column(name = "nom_benef")
  private String nomBenef;
  @Column(name = "cve_tipo_id")
  private Character cveTipoId;
  @Column(name = "nro_id_benef")
  private String nroIdBenef;
  @Column(name = "cve_registro_ruc")
  private Character cveRegistroRuc;
  @Basic(optional = false)
  @Column(name = "concepto")
  private String concepto;
  @Column(name = "nom_cobrador")
  private String nomCobrador;
  @Column(name = "cve_tipo_id_cob")
  private Character cveTipoIdCob;
  @Column(name = "nro_id_cobrador")
  private String nroIdCobrador;
  @Column(name = "observacion")
  private String observacion;
  @Basic(optional = false)
  @Column(name = "cod_unidad_sol")
  private String codUnidadSol;
  @Basic(optional = false)
  @Column(name = "cve_estado_op")
  private char cveEstadoOp;
  @Basic(optional = false)
  @Column(name = "fecha_vencim")
  @Temporal(TemporalType.DATE)
  private Date fechaVencim;
  @Column(name = "nro_mov_pago")
  private Integer nroMovPago;
  @Basic(optional = false)
  @Column(name = "cod_usuario")
  private String codUsuario;
  @Basic(optional = false)
  @Column(name = "fecha_hora")
  @Temporal(TemporalType.TIMESTAMP)
  private Date fechaHora;
  @Basic(optional = false)
  @Column(name = "estacion")
  private String estacion;
  @Column(name = "fecha_reval")
  @Temporal(TemporalType.DATE)
  private Date fechaReval;
  @JoinColumns({
        @JoinColumn(name = "nro_centro", referencedColumnName = "nro_centro", insertable = false, updatable = false),
        @JoinColumn(name = "cve_tipo_comprob", referencedColumnName = "cve_tipo_comprob", insertable = false, updatable = false),
        @JoinColumn(name = "nro_comprob", referencedColumnName = "nro_comprob", insertable = false, updatable = false),
        @JoinColumn(name = "nro_reng", referencedColumnName = "nro_reng", insertable = false, updatable = false) })
  @ManyToOne(optional = false)
  private RengComprob rengComprob;

  public ImpOrdenPago()
  {
  }

  public ImpOrdenPago(ImpOrdenPagoId id)
  {
    this.id = id;
  }

  public ImpOrdenPago(ImpOrdenPagoId id, char cveTipoOp, BigDecimal montoImpMo,
      String codMoneda, String nomBenef, String concepto, String codUnidadSol,
      char cveEstadoOp, Date fechaVencim, String codUsuario, Date fechaHora,
      String estacion)
  {
    this.id = id;
    this.cveTipoOp = cveTipoOp;
    this.montoImpMo = montoImpMo;
    this.codMoneda = codMoneda;
    this.nomBenef = nomBenef;
    this.concepto = concepto;
    this.codUnidadSol = codUnidadSol;
    this.cveEstadoOp = cveEstadoOp;
    this.fechaVencim = fechaVencim;
    this.codUsuario = codUsuario;
    this.fechaHora = fechaHora;
    this.estacion = estacion;
  }

  public ImpOrdenPago(int nroCentro, char cveTipoComprob, String nroComprob,
      int nroReng, int nroImp)
  {
    this.id = new ImpOrdenPagoId(nroCentro, cveTipoComprob, nroComprob, nroReng, nroImp);
  }

  public ImpOrdenPagoId getId()
  {
    return id;
  }

  public void setId(ImpOrdenPagoId id)
  {
    this.id = id;
  }

  public char getCveTipoOp()
  {
    return cveTipoOp;
  }

  public void setCveTipoOp(char cveTipoOp)
  {
    this.cveTipoOp = cveTipoOp;
  }

  public BigDecimal getMontoImpMo()
  {
    return montoImpMo;
  }

  public void setMontoImpMo(BigDecimal montoImpMo)
  {
    this.montoImpMo = montoImpMo;
  }

  public String getCodMoneda()
  {
    return codMoneda;
  }

  public void setCodMoneda(String codMoneda)
  {
    this.codMoneda = codMoneda;
  }

  public String getSerie()
  {
    return serie;
  }

  public void setSerie(String serie)
  {
    this.serie = serie;
  }

  public Integer getNroCheque()
  {
    return nroCheque;
  }

  public void setNroCheque(Integer nroCheque)
  {
    this.nroCheque = nroCheque;
  }

  public String getNomBenef()
  {
    return nomBenef;
  }

  public void setNomBenef(String nomBenef)
  {
    this.nomBenef = nomBenef;
  }

  public Character getCveTipoId()
  {
    return cveTipoId;
  }

  public void setCveTipoId(Character cveTipoId)
  {
    this.cveTipoId = cveTipoId;
  }

  public String getNroIdBenef()
  {
    return nroIdBenef;
  }

  public void setNroIdBenef(String nroIdBenef)
  {
    this.nroIdBenef = nroIdBenef;
  }

  public Character getCveRegistroRuc()
  {
    return cveRegistroRuc;
  }

  public void setCveRegistroRuc(Character cveRegistroRuc)
  {
    this.cveRegistroRuc = cveRegistroRuc;
  }

  public String getConcepto()
  {
    return concepto;
  }

  public void setConcepto(String concepto)
  {
    this.concepto = concepto;
  }

  public String getNomCobrador()
  {
    return nomCobrador;
  }

  public void setNomCobrador(String nomCobrador)
  {
    this.nomCobrador = nomCobrador;
  }

  public Character getCveTipoIdCob()
  {
    return cveTipoIdCob;
  }

  public void setCveTipoIdCob(Character cveTipoIdCob)
  {
    this.cveTipoIdCob = cveTipoIdCob;
  }

  public String getNroIdCobrador()
  {
    return nroIdCobrador;
  }

  public void setNroIdCobrador(String nroIdCobrador)
  {
    this.nroIdCobrador = nroIdCobrador;
  }

  public String getObservacion()
  {
    return observacion;
  }

  public void setObservacion(String observacion)
  {
    this.observacion = observacion;
  }

  public String getCodUnidadSol()
  {
    return codUnidadSol;
  }

  public void setCodUnidadSol(String codUnidadSol)
  {
    this.codUnidadSol = codUnidadSol;
  }

  public char getCveEstadoOp()
  {
    return cveEstadoOp;
  }

  public void setCveEstadoOp(char cveEstadoOp)
  {
    this.cveEstadoOp = cveEstadoOp;
  }

  public Date getFechaVencim()
  {
    return fechaVencim;
  }

  public void setFechaVencim(Date fechaVencim)
  {
    this.fechaVencim = fechaVencim;
  }

  public Integer getNroMovPago()
  {
    return nroMovPago;
  }

  public void setNroMovPago(Integer nroMovPago)
  {
    this.nroMovPago = nroMovPago;
  }

  public String getCodUsuario()
  {
    return codUsuario;
  }

  public void setCodUsuario(String codUsuario)
  {
    this.codUsuario = codUsuario;
  }

  public Date getFechaHora()
  {
    return fechaHora;
  }

  public void setFechaHora(Date fechaHora)
  {
    this.fechaHora = fechaHora;
  }

  public String getEstacion()
  {
    return estacion;
  }

  public void setEstacion(String estacion)
  {
    this.estacion = estacion;
  }

  public Date getFechaReval()
  {
    return fechaReval;
  }

  public void setFechaReval(Date fechaReval)
  {
    this.fechaReval = fechaReval;
  }

  public RengComprob getRengComprob()
  {
    return rengComprob;
  }

  public void setRengComprob(RengComprob rengComprob)
  {
    this.rengComprob = rengComprob;
  }

  
  public int hashCode()
  {
    int hash = 0;
    hash += (id != null ? id.hashCode() : 0);
    return hash;
  }

  
  public boolean equals(Object object)
  {
    // TODO: Warning - this method won't work in the case the id fields are not
    // set
    if (!(object instanceof ImpOrdenPago))
    {
      return false;
    }
    ImpOrdenPago other = (ImpOrdenPago) object;
    if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id)))
    {
      return false;
    }
    return true;
  }


public String toString() {
	return "ImpOrdenPago [id=" + id + ", cveTipoOp=" + cveTipoOp + ", montoImpMo=" + montoImpMo + ", codMoneda=" + codMoneda + ", serie=" + serie
			+ ", nroCheque=" + nroCheque + ", nomBenef=" + nomBenef + ", cveTipoId=" + cveTipoId + ", nroIdBenef=" + nroIdBenef + ", cveRegistroRuc="
			+ cveRegistroRuc + ", concepto=" + concepto + ", nomCobrador=" + nomCobrador + ", cveTipoIdCob=" + cveTipoIdCob + ", nroIdCobrador="
			+ nroIdCobrador + ", observacion=" + observacion + ", codUnidadSol=" + codUnidadSol + ", cveEstadoOp=" + cveEstadoOp + ", fechaVencim="
			+ fechaVencim + ", nroMovPago=" + nroMovPago + ", codUsuario=" + codUsuario + ", fechaHora=" + fechaHora + ", estacion=" + estacion
			+ ", fechaReval=" + fechaReval + ", rengComprob=" + rengComprob + "]";
}

 
}
