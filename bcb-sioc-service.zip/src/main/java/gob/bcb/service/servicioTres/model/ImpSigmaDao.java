/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.service.servicioTres.model;

//import java.util.ArrayList;
import java.math.BigDecimal;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

//import org.hibernate.Query;

public class ImpSigmaDao extends HibernateDaoSupport{
	private static final Log log = LogFactory.getLog(ImpSigmaDao.class);

	public Integer CrearImputacion(RengComprobId idI, BigDecimal monto, char dh, String glosa) {
		int imp = 0;
		String conc = "";

		if (idI.getNroReng() == 1)
			conc = "DEV";
		else {
			if (idI.getNroReng() == 2)
				conc = "CRV";
			else {
				if (glosa.indexOf("DIFERENCIA", 0) < 0)
					conc = "COB";
				else {
					if (dh == 'D')
						conc = "DEV";
					else
						conc = "CRV";
				}
			}
		}

		ImpSigma imp1 = new ImpSigma(new ImpSigmaId(idI.getNroCentro(), idI.getCveTipoComprob(), idI.getNroComprob(), idI.getNroReng(), 1), monto,
				conc, idI.getNroComprob());

		this.getHibernateTemplate().saveOrUpdate(imp1);
		log.info("Imputaci�n sigma guardada: ");

		return imp;
	}

}
