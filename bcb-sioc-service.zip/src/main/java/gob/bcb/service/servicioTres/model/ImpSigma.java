/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gob.bcb.service.servicioTres.model;



import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * 
 * @author faflores
 */
@Entity
@Table(name = "imp_sigma")
@NamedQueries({ @NamedQuery(name = "ImpSigma.findAll", query = "SELECT i FROM ImpSigma i") })
public class ImpSigma implements Serializable {
	private static final long serialVersionUID = 1L;
	@EmbeddedId
	protected ImpSigmaId id;
	@Column(name = "desc_imp")
	private String descImp;
	@Basic(optional = false)
	@Column(name = "monto_imp_mo")
	private BigDecimal montoImpMo;
	@Basic(optional = false)
	@Column(name = "cve_tipo_sigma")
	private String cveTipoSigma;
	@Basic(optional = false)
	@Column(name = "nro_doc_sigma")
	private String nroDocSigma;

	public ImpSigma() {
	}

	public ImpSigma(ImpSigmaId id) {
		this.id = id;
	}

	public ImpSigma(ImpSigmaId id, BigDecimal montoImpMo, String cveTipoSigma, String nroDocSigma) {
		this.id = id;
		this.montoImpMo = montoImpMo;
		this.cveTipoSigma = cveTipoSigma;
		this.nroDocSigma = nroDocSigma;
	}

	public ImpSigma(int nroCentro, char cveTipoComprob, String nroComprob, int nroReng, int nroImp) {
		this.id = new ImpSigmaId(nroCentro, cveTipoComprob, nroComprob, nroReng, nroImp);
	}

	public ImpSigmaId getId() {
		return id;
	}

	public void setId(ImpSigmaId id) {
		this.id = id;
	}

	public String getDescImp() {
		return descImp;
	}

	public void setDescImp(String descImp) {
		this.descImp = descImp;
	}

	public BigDecimal getMontoImpMo() {
		return montoImpMo;
	}

	public void setMontoImpMo(BigDecimal montoImpMo) {
		this.montoImpMo = montoImpMo;
	}

	public String getCveTipoSigma() {
		return cveTipoSigma;
	}

	public void setCveTipoSigma(String cveTipoSigma) {
		this.cveTipoSigma = cveTipoSigma;
	}

	public String getNroDocSigma() {
		return nroDocSigma;
	}

	public void setNroDocSigma(String nroDocSigma) {
		this.nroDocSigma = nroDocSigma;
	}

	
	public int hashCode() {
		int hash = 0;
		hash += (id != null ? id.hashCode() : 0);
		return hash;
	}

	
	public boolean equals(Object object) {
		// TODO: Warning - this method won't work in the case the id fields are
		// not
		// set
		if (!(object instanceof ImpSigma)) {
			return false;
		}
		ImpSigma other = (ImpSigma) object;
		if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
			return false;
		}
		return true;
	}

	
	public String toString() {
		return "gob.bcb.service.servicioTres.model.ImpSigma[id=" + id + "]";
	}

}
