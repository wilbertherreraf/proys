/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gob.bcb.service.servicioTres.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * 
 * @author faflores
 */
@Embeddable
public class RengConciliaId implements Serializable
{
  @Basic(optional = false)
  @Column(name = "nro_concilia")
  private int nroConcilia;
  @Basic(optional = false)
  @Column(name = "gestion")
  private int gestion;
  @Basic(optional = false)
  @Column(name = "sec_reng_concilia")
  private int secRengConcilia;

  public RengConciliaId()
  {
  }

  public RengConciliaId(int nroConcilia, int gestion, int secRengConcilia)
  {
    this.nroConcilia = nroConcilia;
    this.gestion = gestion;
    this.secRengConcilia = secRengConcilia;
  }

  public int getNroConcilia()
  {
    return nroConcilia;
  }

  public void setNroConcilia(int nroConcilia)
  {
    this.nroConcilia = nroConcilia;
  }

  public int getGestion()
  {
    return gestion;
  }

  public void setGestion(int gestion)
  {
    this.gestion = gestion;
  }

  public int getSecRengConcilia()
  {
    return secRengConcilia;
  }

  public void setSecRengConcilia(int secRengConcilia)
  {
    this.secRengConcilia = secRengConcilia;
  }

  
  public int hashCode()
  {
    int hash = 0;
    hash += (int) nroConcilia;
    hash += (int) gestion;
    hash += (int) secRengConcilia;
    return hash;
  }

  
  public boolean equals(Object object)
  {
    // TODO: Warning - this method won't work in the case the id fields are not
    // set
    if (!(object instanceof RengConciliaId))
    {
      return false;
    }
    RengConciliaId other = (RengConciliaId) object;
    if (this.nroConcilia != other.nroConcilia)
    {
      return false;
    }
    if (this.gestion != other.gestion)
    {
      return false;
    }
    if (this.secRengConcilia != other.secRengConcilia)
    {
      return false;
    }
    return true;
  }

  
  public String toString()
  {
    return "gob.bcb.service.servicioTres.model.RengConciliaId[nroConcilia=" + nroConcilia + ", gestion=" + gestion + ", secRengConcilia=" + secRengConcilia + "]";
  }

}
