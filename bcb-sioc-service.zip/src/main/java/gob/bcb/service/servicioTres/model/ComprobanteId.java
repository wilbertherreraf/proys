/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gob.bcb.service.servicioTres.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * 
 * @author faflores
 */
@Embeddable
public class ComprobanteId implements Serializable {
	@Basic(optional = false)
	@Column(name = "nro_centro")
	private int nroCentro;
	@Basic(optional = false)
	@Column(name = "cve_tipo_comprob")
	private char cveTipoComprob;
	@Basic(optional = false)
	@Column(name = "nro_comprob")
	private String nroComprob;

	public ComprobanteId() {
	}

	public ComprobanteId(int nroCentro, char cveTipoComprob, String nroComprob) {
		this.nroCentro = nroCentro;
		this.cveTipoComprob = cveTipoComprob;
		this.nroComprob = nroComprob;
	}

	public int getNroCentro() {
		return nroCentro;
	}

	public void setNroCentro(int nroCentro) {
		this.nroCentro = nroCentro;
	}

	public char getCveTipoComprob() {
		return cveTipoComprob;
	}

	public void setCveTipoComprob(char cveTipoComprob) {
		this.cveTipoComprob = cveTipoComprob;
	}

	public String getNroComprob() {
		return nroComprob;
	}

	public void setNroComprob(String nroComprob) {
		this.nroComprob = nroComprob;
	}

	
	public int hashCode() {
		int hash = 0;
		hash += (int) nroCentro;
		hash += (int) cveTipoComprob;
		hash += (nroComprob != null ? nroComprob.hashCode() : 0);
		return hash;
	}

	
	public boolean equals(Object object) {
		if (!(object instanceof ComprobanteId)) {
			return false;
		}
		ComprobanteId other = (ComprobanteId) object;
		if (this.nroCentro != other.nroCentro) {
			return false;
		}
		if (this.cveTipoComprob != other.cveTipoComprob) {
			return false;
		}
		if ((this.nroComprob == null && other.nroComprob != null) || (this.nroComprob != null && !this.nroComprob.equals(other.nroComprob))) {
			return false;
		}
		return true;
	}

	
	public String toString() {
		return "gob.bcb.service.servicioTres.model.ComprobanteId[nroCentro=" + nroCentro + ", cveTipoComprob=" + cveTipoComprob + ", nroComprob="
				+ nroComprob + "]";
	}

}
