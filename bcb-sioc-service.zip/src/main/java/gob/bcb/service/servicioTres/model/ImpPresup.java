/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gob.bcb.service.servicioTres.model;



import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * 
 * @author faflores
 */
@Entity
@Table(name = "imp_presup")
@NamedQueries({ @NamedQuery(name = "ImpPresup.findAll", query = "SELECT i FROM ImpPresup i") })
public class ImpPresup implements Serializable
{
  private static final long serialVersionUID = 1L;
  @EmbeddedId
  protected ImpPresupId id;
  @Basic(optional = false)
  @Column(name = "monto_imp_mn")
  private BigDecimal montoImpMn;
  @Basic(optional = false)
  @Column(name = "gestion")
  private int gestion;
  @Basic(optional = false)
  @Column(name = "nro_cp")
  private int nroCp;
  @Basic(optional = false)
  @Column(name = "nro_reng_cp")
  private int nroRengCp;
  @Basic(optional = false)
  @Column(name = "cve_dev_real")
  private char cveDevReal;
  @Basic(optional = false)
  @Column(name = "cve_reform_aut")
  private char cveReformAut;

  public ImpPresup()
  {
  }

  public ImpPresup(ImpPresupId id)
  {
    this.id = id;
  }

  public ImpPresup(ImpPresupId id, BigDecimal montoImpMn, int gestion,
      int nroCp, int nroRengCp, char cveDevReal, char cveReformAut)
  {
    this.id = id;
    this.montoImpMn = montoImpMn;
    this.gestion = gestion;
    this.nroCp = nroCp;
    this.nroRengCp = nroRengCp;
    this.cveDevReal = cveDevReal;
    this.cveReformAut = cveReformAut;
  }

  public ImpPresup(int nroCentro, char cveTipoComprob, String nroComprob,
      int nroReng, int nroImp)
  {
    this.id = new ImpPresupId(nroCentro, cveTipoComprob, nroComprob, nroReng, nroImp);
  }

  public ImpPresupId getId()
  {
    return id;
  }

  public void setId(ImpPresupId id)
  {
    this.id = id;
  }

  public BigDecimal getMontoImpMn()
  {
    return montoImpMn;
  }

  public void setMontoImpMn(BigDecimal montoImpMn)
  {
    this.montoImpMn = montoImpMn;
  }

  public int getGestion()
  {
    return gestion;
  }

  public void setGestion(int gestion)
  {
    this.gestion = gestion;
  }

  public int getNroCp()
  {
    return nroCp;
  }

  public void setNroCp(int nroCp)
  {
    this.nroCp = nroCp;
  }

  public int getNroRengCp()
  {
    return nroRengCp;
  }

  public void setNroRengCp(int nroRengCp)
  {
    this.nroRengCp = nroRengCp;
  }

  public char getCveDevReal()
  {
    return cveDevReal;
  }

  public void setCveDevReal(char cveDevReal)
  {
    this.cveDevReal = cveDevReal;
  }

  public char getCveReformAut()
  {
    return cveReformAut;
  }

  public void setCveReformAut(char cveReformAut)
  {
    this.cveReformAut = cveReformAut;
  }

  
  public int hashCode()
  {
    int hash = 0;
    hash += (id != null ? id.hashCode() : 0);
    return hash;
  }

  
  public boolean equals(Object object)
  {
    // TODO: Warning - this method won't work in the case the id fields are not
    // set
    if (!(object instanceof ImpPresup))
    {
      return false;
    }
    ImpPresup other = (ImpPresup) object;
    if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id)))
    {
      return false;
    }
    return true;
  }

  
  public String toString()
  {
    return "gob.bcb.service.servicioTres.model.ImpPresup[id=" + id + "]";
  }

}
