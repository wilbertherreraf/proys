/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gob.bcb.service.servicioTres.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * 
 * @author faflores
 */
@Entity
@Table(name = "cuenta_movimiento")
@NamedQueries({ @NamedQuery(name = "CuentaMovimiento.findAll", query = "SELECT c FROM CuentaMovimiento c") })
public class CuentaMovimiento implements Serializable
{
  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @Column(name = "cod_movimiento")
  private String codMovimiento;
  @Basic(optional = false)
  @Column(name = "nom_movimiento")
  private String nomMovimiento;
  @Basic(optional = false)
  @Column(name = "cod_tipo_cuenta")
  private String codTipoCuenta;
  @Basic(optional = false)
  @Column(name = "cve_tipo_persona")
  private char cveTipoPersona;
  @Basic(optional = false)
  @Column(name = "cod_persona")
  private String codPersona;
  @Basic(optional = false)
  @Column(name = "cve_estado_cuenta")
  private char cveEstadoCuenta;
  @Basic(optional = false)
  @Column(name = "cod_usuario")
  private String codUsuario;
  @Basic(optional = false)
  @Column(name = "fecha_hora")
  @Temporal(TemporalType.TIMESTAMP)
  private Date fechaHora;
  @Column(name = "estacion")
  private String estacion;

  public CuentaMovimiento()
  {
  }

  public CuentaMovimiento(String codMovimiento)
  {
    this.codMovimiento = codMovimiento;
  }

  public CuentaMovimiento(String codMovimiento, String nomMovimiento,
      String codTipoCuenta, char cveTipoPersona, String codPersona,
      char cveEstadoCuenta, String codUsuario, Date fechaHora)
  {
    this.codMovimiento = codMovimiento;
    this.nomMovimiento = nomMovimiento;
    this.codTipoCuenta = codTipoCuenta;
    this.cveTipoPersona = cveTipoPersona;
    this.codPersona = codPersona;
    this.cveEstadoCuenta = cveEstadoCuenta;
    this.codUsuario = codUsuario;
    this.fechaHora = fechaHora;
  }

  public String getCodMovimiento()
  {
    return codMovimiento;
  }

  public void setCodMovimiento(String codMovimiento)
  {
    this.codMovimiento = codMovimiento;
  }

  public String getNomMovimiento()
  {
    return nomMovimiento;
  }

  public void setNomMovimiento(String nomMovimiento)
  {
    this.nomMovimiento = nomMovimiento;
  }

  public String getCodTipoCuenta()
  {
    return codTipoCuenta;
  }

  public void setCodTipoCuenta(String codTipoCuenta)
  {
    this.codTipoCuenta = codTipoCuenta;
  }

  public char getCveTipoPersona()
  {
    return cveTipoPersona;
  }

  public void setCveTipoPersona(char cveTipoPersona)
  {
    this.cveTipoPersona = cveTipoPersona;
  }

  public String getCodPersona()
  {
    return codPersona;
  }

  public void setCodPersona(String codPersona)
  {
    this.codPersona = codPersona;
  }

  public char getCveEstadoCuenta()
  {
    return cveEstadoCuenta;
  }

  public void setCveEstadoCuenta(char cveEstadoCuenta)
  {
    this.cveEstadoCuenta = cveEstadoCuenta;
  }

  public String getCodUsuario()
  {
    return codUsuario;
  }

  public void setCodUsuario(String codUsuario)
  {
    this.codUsuario = codUsuario;
  }

  public Date getFechaHora()
  {
    return fechaHora;
  }

  public void setFechaHora(Date fechaHora)
  {
    this.fechaHora = fechaHora;
  }

  public String getEstacion()
  {
    return estacion;
  }

  public void setEstacion(String estacion)
  {
    this.estacion = estacion;
  }

  
  public int hashCode()
  {
    int hash = 0;
    hash += (codMovimiento != null ? codMovimiento.hashCode() : 0);
    return hash;
  }

  
  public boolean equals(Object object)
  {
    // TODO: Warning - this method won't work in the case the id fields are not
    // set
    if (!(object instanceof CuentaMovimiento))
    {
      return false;
    }
    CuentaMovimiento other = (CuentaMovimiento) object;
    if ((this.codMovimiento == null && other.codMovimiento != null) || (this.codMovimiento != null && !this.codMovimiento.equals(other.codMovimiento)))
    {
      return false;
    }
    return true;
  }

  
  public String toString()
  {
    return "gob.bcb.service.servicioTres.model.CuentaMovimiento[codMovimiento=" + codMovimiento + "]";
  }

}
