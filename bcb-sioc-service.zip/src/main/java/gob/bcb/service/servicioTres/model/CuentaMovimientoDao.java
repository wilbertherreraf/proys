package gob.bcb.service.servicioTres.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import gob.bcb.bpm.pruebaCU.SocRengesq;
import gob.bcb.core.utils.UtilsQNatives;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.pojos.CuentaS;

public class CuentaMovimientoDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(CuentaMovimientoDao.class);

	public CuentaMovimiento getCuentaMovimiento(String codMovimiento) {
		log.debug("COIN:getCuentaMovimiento Entre a buscar el objeto con el codMovimiento: "
				+ codMovimiento);

		StringBuffer query = new StringBuffer();
		query = query.append("select cp ");
		query = query.append("from CuentaMovimiento cp ");
		query = query.append("where cp.codMovimiento = :codMovimiento ");
		//query = query.append("and cp.cveEstadoCuenta = 'V'  ");		

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("codMovimiento", codMovimiento);

		List lista = consulta.list();

		if (lista.size() > 0) {
			return (CuentaMovimiento) lista.get(0);
		}
		
		log.error("Cuenta movimiento : " + codMovimiento
				+ " inexistente en base CONTBCB.Cuenta_Movimiento");
		throw new RuntimeException("Cuenta movimiento : " + codMovimiento
				+ " inexistente en base CONTBCB.Cuenta_Movimiento");
	}

	public CuentaMovimiento findCuentaMovimiento(String codMovimiento) {
		log.debug("COIN:getCuentaMovimiento Entre a buscar el objeto con el codMovimiento: "
				+ codMovimiento);

		StringBuffer query = new StringBuffer();
		query = query.append("select cp ");
		query = query.append("from CuentaMovimiento cp ");
		query = query.append("where cp.codMovimiento = :codMovimiento ");

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("codMovimiento", codMovimiento);

		List lista = consulta.list();

		if (lista.size() > 0) {
			return (CuentaMovimiento) lista.get(0);
		}
		log.error("Cuenta movimiento : " + codMovimiento
				+ " inexistente en base CONTBCB.Cuenta_Movimiento");		
		return null;
	}
	
	public Boolean IsAfectableSigma(String cuenta) {
		// int sigma = 0;

		String query = "select count(nro_afectable) as sigma ";
		query = query.concat("from afectable_sigma ");
		query = query.concat("where nro_afectable = :cuenta ");
		query = query.concat("and cve_vigente = 'V' ");

		Query consulta = getSession().createSQLQuery(query);
		consulta.setParameter("cuenta", cuenta);

		Long codigo = Long.valueOf(0);

		BigDecimal maxi = BigDecimal.ZERO;
		List result = consulta.list();
		if (result.size() > 0)
			maxi = (BigDecimal) result.get(0);

		if (maxi != null) {
			codigo = Long.valueOf(maxi.toPlainString());
		} else {
			codigo = Long.valueOf(0);
		}

		return codigo.compareTo(Long.valueOf(1)) >= 0;
	}

	public List<String> partidaPresup(String cuenta) {
		log.info("Buscando partida presup " + cuenta);
		List<String> result = new ArrayList<String>();
		try {

			String query = "select cod_partida ";
			query = query.concat("from afectable_partida ");
			query = query.concat("where nro_afectable = :cuenta ");
			query = query.concat("and cve_vigente = 'V' ");

			Query consulta = getSession().createSQLQuery(query);
			consulta.setParameter("cuenta", cuenta);

			result = consulta.list();

		} catch (Exception e) {
			throw new RuntimeException("Error al obtener Codigo Part Presup: "
					+ e.getMessage(), e);
		}

		return result;
	}

	public List<CuentaAfectable> cuentasFondosVista() {
		StringBuffer query = new StringBuffer();
		query = query.append("select ca ");
		query = query.append("from CuentaMovimiento cm, CuentaAfectable ca ");
		query = query.append("where cm.codMovimiento = ca.codMovimiento ");
		query = query.append("and cm.cveEstadoCuenta = 'V' ");
		query = query.append("and ca.cveEstadoCuenta = 'V' ");
		query = query.append("and ca.nroCentro = 1 ");
		query = query.append("and cm.codTipoCuenta like '0010%' ");

		Query consulta = getSession().createQuery(query.toString());

		List lista = consulta.list();

		return lista;
	}

	public List<CuentaAfectable> cuentasFondosVistaByCodMoneda(String codMoneda) {
		StringBuffer query = new StringBuffer();
		query = query.append("select ca ");
		query = query.append("from CuentaMovimiento cm, CuentaAfectable ca ");
		query = query.append("where cm.codMovimiento = ca.codMovimiento ");
		query = query.append("and cm.cveEstadoCuenta = 'V' ");
		query = query.append("and ca.cveEstadoCuenta = 'V' ");
		query = query.append("and ca.nroCentro = 1 ");
		query = query.append("and ca.codMoneda = :codMoneda ");		
		query = query.append("and cm.codTipoCuenta like '0010%' ");

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("codMoneda", codMoneda);
		
		List lista = consulta.list();

		return lista;
	}
	
	public CuentaAfectable cuentaAfectableByCodMovCodmoneda(String codMovimiento, String codMoneda) {
		StringBuffer query = new StringBuffer();
		query = query.append("select ca ");
		query = query.append("from CuentaAfectable ca ");
		query = query.append("where ca.codMovimiento = :codMovimiento ");
		query = query.append("and ca.codMoneda = :codMoneda ");		
		query = query.append("and ca.cveEstadoCuenta = 'V' ");		

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("codMovimiento", codMovimiento);		
		consulta.setParameter("codMoneda", codMoneda);
		
		List lista = consulta.list();

		if (lista.size() > 0) {
			return (CuentaAfectable) lista.get(0);
		}
		
		throw new RuntimeException("Cuenta afectable : " + codMovimiento + " - " + codMoneda + "  inexistente en base CONTBCB.Cuenta_Afectable");
	}

	public CuentaMayor findByCodMovCuentaMayor(String codMovimiento) {
		StringBuffer query = new StringBuffer();
		query = query.append("select my ");
		query = query.append("from CuentaMovimiento cm, CuentaMayor my ");
		query = query.append("where substr(cm.codTipoCuenta, 1, 4) = my.codMayor ");
		query = query.append("and cm.codMovimiento = :codMovimiento ");		
		query = query.append("and my.nroCentro = 1 ");	
		query = query.append("and cm.cveEstadoCuenta = 'V' ");
		query = query.append("and my.cveEstadoCuenta = 'V' ");		

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("codMovimiento", codMovimiento);

		List lista = consulta.list();

		if (lista.size() > 0) {
			return (CuentaMayor) lista.get(0);
		}
		log.error("Cuenta movimiento : " + codMovimiento
				+ " inexistente en base CONTBCB.CuentaMayor");		
		throw new RuntimeException("Inexistente mayor CONTBCB.Cuenta_mayor para cuenta movimiento: " + codMovimiento);
	}

	public boolean nroAfectableEsConciliable(String nroAfectable){

		StringBuffer query = new StringBuffer();
		query = query.append("select nro_afectable ");
		query = query.append("from afectable_concilia ");
		query = query.append("where nro_afectable = :nroAfectable ");
		query = query.append("and cve_estado_cuenta = 'V' ");		

		//log.info("Cuenta es conciliable " + nroAfectable + " " + query.toString());
		
		Query consulta = getSession().createSQLQuery(query.toString());
		consulta.setParameter("nroAfectable", nroAfectable);
		
		List lista = consulta.list();

		List<Map<String, Object>> resultadoQuery = UtilsQNatives.convertListToMap(lista, "nro_afectable".split(","));
		
		return (resultadoQuery.size() > 0);
	}	
	
	public CuentaS recuperarDatosCuenta(String codMovimiento, String codMoneda, SocRengesq socRengesq) {
		CuentaS cuentaS = new CuentaS();

		//CuentaMovimiento cuentaMovimiento = getCuentaMovimiento(codMovimiento);		
		CuentaAfectable cuentaAfectable = cuentaAfectableByCodMovCodmoneda(codMovimiento, codMoneda);
		CuentaMayor cuentaMayor = findByCodMovCuentaMayor(codMovimiento);
		
		//if (socRengesq.getEsqDh().equals('H') && cuentaMovimiento.getCodPersona() != null && cuentaMovimiento.getCodPersona().trim().equals(Constants.COD_BCB)) {
			List<String> codPartidas = partidaPresup(cuentaAfectable.getNroAfectable());
			cuentaS.setCodPartidas(codPartidas);
		//}
		
		//if (cuentaS.getCodPartidas().size() == 0 && (cuentaMovimiento.getCodPersona() == null || !cuentaMovimiento.getCodPersona().equals(Constants.COD_BCB))) {
			Boolean afectSigma = IsAfectableSigma(cuentaAfectable.getNroAfectable());
			cuentaS.setAfectSigma(afectSigma);			
		//}
		
		if (cuentaS.getCodPartidas().size() == 0 && !cuentaS.getAfectSigma()) {
			Boolean esConciliable = nroAfectableEsConciliable(cuentaAfectable.getNroAfectable());
			cuentaS.setEsConciliable(esConciliable);				
		}
		
		//cuentaS.setCtaCodigo(socCuentassol.getCtaCodigo());
		cuentaS.setCtaMovi(codMovimiento);
		cuentaS.setClaVigente(Short.valueOf("1"));
		Integer codMonedaInt = Integer.valueOf(codMoneda);
		cuentaS.setMoneda(codMonedaInt);
		//cuentaS.setCtaNommovimiento(socCuentassol.getCtaNommovimiento());
		cuentaS.setCtaAfectable(cuentaAfectable.getNroAfectable());
		//cuentaS.setSocCuentassol(socCuentassol);
		cuentaS.setCtaMayor(cuentaMayor.getNroMayor());
		cuentaS.setCodMayor(cuentaMayor.getCodMayor());		
		
		return cuentaS;
	}
}
