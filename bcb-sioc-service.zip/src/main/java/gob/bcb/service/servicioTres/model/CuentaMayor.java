/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gob.bcb.service.servicioTres.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * 
 * @author faflores
 */
@Entity
@Table(name = "cuenta_mayor")
@NamedQueries({ @NamedQuery(name = "CuentaMayor.findAll", query = "SELECT c FROM CuentaMayor c") })
public class CuentaMayor implements Serializable
{
  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @Column(name = "nro_mayor")
  private String nroMayor;
  @Basic(optional = false)
  @Column(name = "nro_centro")
  private int nroCentro;
  @Basic(optional = false)
  @Column(name = "cod_mayor")
  private String codMayor;
  @Basic(optional = false)
  @Column(name = "cve_estado_cuenta")
  private char cveEstadoCuenta;
  @Basic(optional = false)
  @Column(name = "cod_usuario")
  private String codUsuario;
  @Basic(optional = false)
  @Column(name = "fecha_hora")
  @Temporal(TemporalType.TIMESTAMP)
  private Date fechaHora;
  @Column(name = "estacion")
  private String estacion;

  public CuentaMayor()
  {
  }

  public CuentaMayor(String nroMayor)
  {
    this.nroMayor = nroMayor;
  }

  public CuentaMayor(String nroMayor, int nroCentro, String codMayor,
      char cveEstadoCuenta, String codUsuario, Date fechaHora)
  {
    this.nroMayor = nroMayor;
    this.nroCentro = nroCentro;
    this.codMayor = codMayor;
    this.cveEstadoCuenta = cveEstadoCuenta;
    this.codUsuario = codUsuario;
    this.fechaHora = fechaHora;
  }

  public String getNroMayor()
  {
    return nroMayor;
  }

  public void setNroMayor(String nroMayor)
  {
    this.nroMayor = nroMayor;
  }

  public int getNroCentro()
  {
    return nroCentro;
  }

  public void setNroCentro(int nroCentro)
  {
    this.nroCentro = nroCentro;
  }

  public String getCodMayor()
  {
    return codMayor;
  }

  public void setCodMayor(String codMayor)
  {
    this.codMayor = codMayor;
  }

  public char getCveEstadoCuenta()
  {
    return cveEstadoCuenta;
  }

  public void setCveEstadoCuenta(char cveEstadoCuenta)
  {
    this.cveEstadoCuenta = cveEstadoCuenta;
  }

  public String getCodUsuario()
  {
    return codUsuario;
  }

  public void setCodUsuario(String codUsuario)
  {
    this.codUsuario = codUsuario;
  }

  public Date getFechaHora()
  {
    return fechaHora;
  }

  public void setFechaHora(Date fechaHora)
  {
    this.fechaHora = fechaHora;
  }

  public String getEstacion()
  {
    return estacion;
  }

  public void setEstacion(String estacion)
  {
    this.estacion = estacion;
  }

  
  public int hashCode()
  {
    int hash = 0;
    hash += (nroMayor != null ? nroMayor.hashCode() : 0);
    return hash;
  }

  
  public boolean equals(Object object)
  {
    // TODO: Warning - this method won't work in the case the id fields are not
    // set
    if (!(object instanceof CuentaMayor))
    {
      return false;
    }
    CuentaMayor other = (CuentaMayor) object;
    if ((this.nroMayor == null && other.nroMayor != null) || (this.nroMayor != null && !this.nroMayor.equals(other.nroMayor)))
    {
      return false;
    }
    return true;
  }

  
  public String toString()
  {
    return "gob.bcb.service.servicioTres.model.CuentaMayor[nroMayor=" + nroMayor + "]";
  }

}
