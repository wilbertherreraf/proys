/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.service.servicioTres.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import gob.bcb.bpm.pruebaCU.SocComprobante;
import gob.bcb.bpm.pruebaCU.SocFacturas;
import gob.bcb.bpm.pruebaCU.SocRengscomp;
import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;

//import org.hibernate.Query;

/**
 * @author parenas
 * 
 */
public class RengComprobDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(RengComprobDao.class);

	private String AFECIVA;
	private String ACREE;
	private String SINCREDITO;
	private String SIN_CREDITO_BOLSIN;
	private String SIN_CREDITO_BOLSIN_VD;

	private boolean consultadosParams = false;

	public List<RengComprob> crearRenglones(Comprobante comprobante, SocComprobante socComprobante, List<SocRengscomp> rengs) {
		if (rengs == null || rengs.size() <= 1) {
			throw new RuntimeException("Comprobante Contable: " + comprobante.getComprobanteId().getNroComprob() + " sin registros de renglones");
		}
		iniciarParams();
		List<RengComprob> rengComprobLista = new ArrayList<RengComprob>();
		log.info("Generando renglones coin " + comprobante.getComprobanteId().getNroComprob());
		for (SocRengscomp socRengscomp : rengs) {
			RengComprob rengComprob = new RengComprob(
					new RengComprobId(comprobante.getComprobanteId().getNroCentro(), comprobante.getComprobanteId().getCveTipoComprob(),
							comprobante.getComprobanteId().getNroComprob(), socRengscomp.getId().getRenCodigo()),
					socRengscomp.getClaDebehaber(), socRengscomp.getRenMontomo(), socRengscomp.getRenTipocambio(), socRengscomp.getRenGlosa(),
					socRengscomp.getRenMayor(), socRengscomp.getRenAfectable(), socRengscomp.getRenMontomn());

			this.getHibernateTemplate().save(rengComprob);

			log.info("Renglon COIN: " + rengComprob.toString());

			Map<String, String> decodeMap = UtilsGeneric.paramsLista(socRengscomp.getNomDatoadic());

			if (decodeMap.containsKey("TIPOSIGMA") && decodeMap.containsKey("DOCSIGMA")) {
				String tipoSigma = decodeMap.get("TIPOSIGMA");
				String docSigma = decodeMap.get("DOCSIGMA");

				docSigma = docSigma.replace("@NROCOMPROBANTE", comprobante.getComprobanteId().getNroComprob());

				ImpSigma impSigma = new ImpSigma(
						new ImpSigmaId(comprobante.getComprobanteId().getNroCentro(), comprobante.getComprobanteId().getCveTipoComprob(),
								comprobante.getComprobanteId().getNroComprob(), rengComprob.getId().getNroReng(), 1),
						rengComprob.getMontoMo(), tipoSigma, docSigma);

				this.getHibernateTemplate().save(impSigma);
			}

			if (decodeMap.containsKey("PPTOCP") && decodeMap.containsKey("PPTORENG")) {
				Integer cp = Integer.parseInt(decodeMap.get("PPTOCP"));
				int rengCP = Integer.parseInt(decodeMap.get("PPTORENG"));

				ImpPresup imp1 = new ImpPresup(
						new ImpPresupId(comprobante.getComprobanteId().getNroCentro(), comprobante.getComprobanteId().getCveTipoComprob(),
								comprobante.getComprobanteId().getNroComprob(), rengComprob.getId().getNroReng(), 1),
						rengComprob.getMontoMo(), comprobante.getGestion(), cp, rengCP, ImpPresupDao.DEV_REAL, ImpPresupDao.REFORM);

				this.getHibernateTemplate().save(imp1);
			}

			RengConciliaDao conciliaDao = new RengConciliaDao();
			conciliaDao.setSessionFactory(getSessionFactory());

			if (decodeMap.containsKey("RCONCNROCON") && decodeMap.containsKey("RCONCGESTION")) {
				// existe renglon concilia se actualiza el saldo conciliable
				Integer nroConcilia = Integer.parseInt(decodeMap.get("RCONCNROCON"));
				int gestion = Integer.parseInt(decodeMap.get("RCONCGESTION"));
				log.info("SALDO CONCILIA: actualizando saldo " + nroConcilia + "-" + gestion);
				String glosa = RengConciliaDao.getFormatoCodConcilia(nroConcilia, gestion);
				rengComprob.setGlosaReng(glosa);
				
				conciliaDao.actualizaSaldoConcilia(comprobante, rengComprob, nroConcilia, gestion);
				
				this.getHibernateTemplate().saveOrUpdate(rengComprob);
			}

			if (decodeMap.containsKey("SALDOCONC")) {
				// existe renglon concilia
				log.info("SALDO CONCILIA: registrando saldo concilia " + comprobante.getComprobanteId().getNroComprob());
				RengConcilia rengConcilia = conciliaDao.nuevoRengConcilia(comprobante, rengComprob);
				String glosa = RengConciliaDao.getFormatoCodConcilia(rengConcilia.getId().getNroConcilia(), rengConcilia.getId().getGestion());				
				rengComprob.setGlosaReng(glosa);
				
				this.getHibernateTemplate().saveOrUpdate(rengComprob);
			}

			rengComprobLista.add(rengComprob);
		}

		return rengComprobLista;
	}

	public Boolean CrearRenglones(ComprobanteId idC, List<SocRengscomp> rengs, List<SocFacturas> facts) {
		Boolean creado = false;
		iniciarParams();
		for (SocRengscomp reng : rengs) {

			log.info("Guardando " + idC.getNroComprob() + " renglon: " + reng.toString());

			creado = false;
			RengComprob reng1 = new RengComprob(
					new RengComprobId(idC.getNroCentro(), idC.getCveTipoComprob(), idC.getNroComprob(), reng.getId().getRenCodigo()),
					reng.getClaDebehaber(), reng.getRenMontomo(), reng.getRenTipocambio(), reng.getRenGlosa(), reng.getRenMayor(),
					reng.getRenAfectable(), reng.getRenMontomn());

			// this.saveOrUpdate(reng1);
			this.getHibernateTemplate().saveOrUpdate(reng1);
			creado = true;

			if (IsAfectableSigma(reng1.getNroAfectable())) {
				ImpSigmaDao impSigmaDao = new ImpSigmaDao();
				impSigmaDao.setSessionFactory(getSessionFactory());
				impSigmaDao.CrearImputacion(reng1.getId(), reng1.getMontoMo(), reng1.getCveDebeHaber(), reng1.getGlosaReng());
			}
			// ceci - whf ver posibilidasd de consultar afectable_partida en
			// COIN
			String partida = IsPresupuestaria(reng1.getNroAfectable());
			if (!partida.equals("")) {
				ImpPresupDao impPresupDao = new ImpPresupDao();
				impPresupDao.setSessionFactory(getSessionFactory());
				impPresupDao.CrearImputacion(reng1.getId(), reng1.getMontoMo(), partida);
			}

			if (reng1.getNroAfectable().equals(AFECIVA)) {
				FacturaDao facturaDao = new FacturaDao();
				facturaDao.setSessionFactory(getSessionFactory());
				facturaDao.CrearFactura(reng1.getId(), facts);
			}

			// verifica que la cuenta afectable del renglon genera o no factura
			// sin credito
			if (reng1.getNroAfectable().equals(SINCREDITO) || reng1.getNroAfectable().equals(SIN_CREDITO_BOLSIN)
					|| reng1.getNroAfectable().equals(SIN_CREDITO_BOLSIN_VD)) {
				FacturaDao facturaDao = new FacturaDao();
				facturaDao.setSessionFactory(getSessionFactory());
				facturaDao.CrearFacturaSinCredito(reng1.getId(), facts);
			}

			if (reng1.getNroAfectable().equals(ACREE)) {
				RengConciliaDao conciliaDao = new RengConciliaDao();
				conciliaDao.setSessionFactory(getSessionFactory());
				Integer concil = conciliaDao.CrearConcilia(reng1);
				String conc = String.format("%07d", concil);
				reng1.setGlosaReng("(CC:H-" + conc + "-" + Servicios.obtGestion() + ")");
				// this.saveOrUpdate(reng1);
				this.getHibernateTemplate().saveOrUpdate(reng1);
			}
		}

		SiocCoinService.flush();

		return creado;
	}

	private Boolean IsAfectableSigma(String cuenta) {
		Boolean afectable = false;
		// int sigma = 0;
		BigDecimal sigmaS = BigDecimal.valueOf(0);

		String query = "select count(nro_afectable) as sigma " + "from afectable_sigma " + "where nro_afectable = '" + cuenta + "' "
				+ "and cve_vigente = 'V'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "sigma".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {

				sigmaS = (BigDecimal) res.get("sigma");
				// sigma = BigDecimal.
				if (sigmaS.compareTo(BigDecimal.valueOf(0)) > 0)
					afectable = true;
			}
		}

		return afectable;
	}

	private String IsPresupuestaria(String cuenta) {
		String partida = "";

		if (cuenta.equals("001712")) {
			partida = "1159906";
		} else if (cuenta.equals("001708")) {
			partida = "1159902";
		} else if (cuenta.equals("001761")) {
			partida = "1115320";
		} else if (cuenta.equals(SINCREDITO)) {
			partida = ServiciosSioc.getParam("@partidaVenta");
			// partida = "1115311";
		} else if (cuenta.equals(SIN_CREDITO_BOLSIN)) {
			partida = ServiciosSioc.getParam("@partidaBolsin");
		} else if (cuenta.equals(SIN_CREDITO_BOLSIN_VD)) {
			partida = ServiciosSioc.getParam("@partidaBolsin_vd");
		} else if (cuenta.equals("007795")) {
			partida = "1115316";
		} else if (cuenta.equals("010159")) {
			partida = "1115336";
		} else {
			// no tiene partida presupuestaria
			partida = "";
		}
		// ojooo
		log.info("XXX: partidita " + cuenta + " " + partida);
		return partida;
	}

	public void iniciarParams() {
		if (!consultadosParams) {

			AFECIVA = ServiciosSioc.getParam("@civa");
			ACREE = ServiciosSioc.getParam("@cacreedores");
			SINCREDITO = ServiciosSioc.getParam("@cventa");
			SIN_CREDITO_BOLSIN = ServiciosSioc.getParam("@cventaBolsin");
			SIN_CREDITO_BOLSIN_VD = ServiciosSioc.getParam("@cventaBolsin_vd");

			consultadosParams = true;
		}
	}
}
