/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.service.servicioTres.model;

//import java.util.ArrayList;
import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import gob.bcb.core.utils.UtilsDate;

//import org.hibernate.Query;

/**
 * @author parenas
 * 
 */
public class FactorConvMnDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(FactorConvMnDao.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gob.bcb.service.pruebaCU.model.SolicitudDao#saveOrUpdate(gob.bcb.service
	 * .pruebaCU .model.Solicitud)
	 */
	
	public void saveOrUpdate(FactorConvMn pm) {
		log.info("Saving or updating " + pm);
		this.getHibernateTemplate().saveOrUpdate(pm);
	}

	public BigDecimal getTC(int moneda, Date fecha) {
		BigDecimal tc = BigDecimal.valueOf(0);
		Session session = null;

		session = getSession();
		// session =
		// SessionFactoryUtils.getSession(EntityUserTransactionCoin.getSessionFactory(Constants.PROP_ALIAS_COIN),
		// false);
		StringBuffer query = new StringBuffer();
		query = query.append(" select factor ");
		query = query.append(" from ");
		query = query.append(" FactorConvMn f ");
		query = query.append(" where f.id.codMoneda = :moneda ");
		query = query.append(" and f.id.fechaDia = :fecha ");

		Query consulta = session.createQuery(query.toString());

		consulta.setParameter("moneda", String.valueOf(moneda));
		consulta.setParameter("fecha", fecha);
		//log.info("XXX: Cons TC: " + query.toString());
		tc = (BigDecimal) consulta.uniqueResult();

		if (tc == null)
			tc = BigDecimal.valueOf(0);
		
		if (tc.compareTo(BigDecimal.valueOf(0) ) == 0){
			throw new RuntimeException("El tipo de cambio para fecha [" + UtilsDate.stringFromDate(fecha, "dd/MM/yyyy") + ", mon: " + moneda + "] es CERO o nulo, verifique los datos");
		}
		
//		log.info("TC de moneda: " + moneda + " para fecha: " + UtilsDate.stringFromDate(fecha, "dd/MM/yyyy") + "[" + tc.toPlainString() + "]");
		return tc;
	}

}
