/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gob.bcb.service.servicioTres.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * 
 * @author faflores
 */
@Embeddable
public class ImpOrdenPagoId implements Serializable
{
  @Basic(optional = false)
  @Column(name = "nro_centro")
  private int nroCentro;
  @Basic(optional = false)
  @Column(name = "cve_tipo_comprob")
  private char cveTipoComprob;
  @Basic(optional = false)
  @Column(name = "nro_comprob")
  private String nroComprob;
  @Basic(optional = false)
  @Column(name = "nro_reng")
  private int nroReng;
  @Basic(optional = false)
  @Column(name = "nro_imp")
  private int nroImp;

  public ImpOrdenPagoId()
  {
  }

  public ImpOrdenPagoId(int nroCentro, char cveTipoComprob, String nroComprob,
      int nroReng, int nroImp)
  {
    this.nroCentro = nroCentro;
    this.cveTipoComprob = cveTipoComprob;
    this.nroComprob = nroComprob;
    this.nroReng = nroReng;
    this.nroImp = nroImp;
  }

  public int getNroCentro()
  {
    return nroCentro;
  }

  public void setNroCentro(int nroCentro)
  {
    this.nroCentro = nroCentro;
  }

  public char getCveTipoComprob()
  {
    return cveTipoComprob;
  }

  public void setCveTipoComprob(char cveTipoComprob)
  {
    this.cveTipoComprob = cveTipoComprob;
  }

  public String getNroComprob()
  {
    return nroComprob;
  }

  public void setNroComprob(String nroComprob)
  {
    this.nroComprob = nroComprob;
  }

  public int getNroReng()
  {
    return nroReng;
  }

  public void setNroReng(int nroReng)
  {
    this.nroReng = nroReng;
  }

  public int getNroImp()
  {
    return nroImp;
  }

  public void setNroImp(int nroImp)
  {
    this.nroImp = nroImp;
  }

  
  public int hashCode()
  {
    int hash = 0;
    hash += (int) nroCentro;
    hash += (int) cveTipoComprob;
    hash += (nroComprob != null ? nroComprob.hashCode() : 0);
    hash += (int) nroReng;
    hash += (int) nroImp;
    return hash;
  }

  
  public boolean equals(Object object)
  {
    // TODO: Warning - this method won't work in the case the id fields are not
    // set
    if (!(object instanceof ImpOrdenPagoId))
    {
      return false;
    }
    ImpOrdenPagoId other = (ImpOrdenPagoId) object;
    if (this.nroCentro != other.nroCentro)
    {
      return false;
    }
    if (this.cveTipoComprob != other.cveTipoComprob)
    {
      return false;
    }
    if ((this.nroComprob == null && other.nroComprob != null) || (this.nroComprob != null && !this.nroComprob.equals(other.nroComprob)))
    {
      return false;
    }
    if (this.nroReng != other.nroReng)
    {
      return false;
    }
    if (this.nroImp != other.nroImp)
    {
      return false;
    }
    return true;
  }

  
  public String toString()
  {
    return "gob.bcb.service.servicioTres.model.ImpOrdenPagoId[nroCentro=" + nroCentro + ", cveTipoComprob=" + cveTipoComprob + ", nroComprob=" + nroComprob + ", nroReng=" + nroReng + ", nroImp=" + nroImp + "]";
  }

}
