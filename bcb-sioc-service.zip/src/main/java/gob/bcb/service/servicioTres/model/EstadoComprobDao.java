package gob.bcb.service.servicioTres.model;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class EstadoComprobDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(EstadoComprobDao.class);

	public EstadoComprob getEstadoComprob(String id, String estComprob) {
		log.info("Entre a buscar el objeto con el id: " + id);
// whf ojooooo poner anotaciones a estadistico y cambiar xml de config 
		EstadoComprob estadoComprob = null;

			StringBuffer query = new StringBuffer();
			query = query.append(" select cp ");
			query = query.append(" from ");
			query = query.append(" EstadoComprob cp ");
			query = query.append(" where cp.id.nroComprob = ? ");
			query = query.append(" and cp.id.cveEstadoComprob = ? ");
			query = query.append(" and cp.id.nroCentro = 1 ");
			query = query.append(" and cp.id.cveTipoComprob = 'G' ");

			List<EstadoComprob> lista = (List<EstadoComprob>) getHibernateTemplate().find(query.toString(), id, estComprob);

			if (lista != null) {
				for (EstadoComprob comp : lista) {
					estadoComprob = comp;
				}
			}


		return estadoComprob;
	}

}
