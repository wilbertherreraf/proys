/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gob.bcb.service.servicioTres.model;



import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * 
 * @author faflores
 */
@Entity
@Table(name = "comprobante")
@NamedQueries({ @NamedQuery(name = "Comprobante.findAll", query = "SELECT c FROM Comprobante c") })
@org.hibernate.annotations.Entity(dynamicUpdate = true)
public class Comprobante implements Serializable
{
  private static final long serialVersionUID = 1L;
  @EmbeddedId
  protected ComprobanteId id;
  @Basic(optional = false)
  @Column(name = "gestion")
  private Integer gestion;
  @Basic(optional = false)
  @Column(name = "nro_periodo")
  private Integer nroPeriodo;
  @Basic(optional = false)
  @Column(name = "nro_dia")
  private Integer nroDia;
  @Column(name = "fecha_valor")
  @Temporal(TemporalType.DATE)
  private Date fechaValor;
  @Basic(optional = false)
  @Column(name = "factor_conv_us_mn")
  private BigDecimal factorConvUsMn;
  @Basic(optional = false)
  @Column(name = "glosa_comprob")
  private String glosaComprob;
  @Column(name = "cod_esquema")
  private String codEsquema;
  @Column(name = "cve_subesquema")
  private Character cveSubesquema;
  @Column(name = "nro_operacion")
  private Integer nroOperacion;
  @Basic(optional = false)
  @Column(name = "cve_estado_comprob")
  private char cveEstadoComprob;
  @Basic(optional = false)
  @Column(name = "cod_usuario")
  private String codUsuario;
  @Basic(optional = false)
  @Column(name = "fecha_hora")
  @Temporal(TemporalType.TIMESTAMP)
  private Date fechaHora;
  @Column(name = "estacion")
  private String estacion;
  @Column(name = "nro_aprobacion")
  private Integer nroAprobacion;
  @Basic(optional = false)
  @Column(name = "cod_unidad")
  private String codUnidad;
  @Column(name = "cve_dev_real")
  private Character cveDevReal;

  public Comprobante()
  {
  }

  public Comprobante(ComprobanteId id)
  {
    this.id = id;
  }

  public Comprobante(ComprobanteId id, Integer gestion, Integer nroPeriodo,
      Integer nroDia, BigDecimal factorConvUsMn, String glosaComprob,
      char cveEstadoComprob, String codUsuario, Date fechaHora, String codUnidad)
  {
    this.id = id;
    this.gestion = gestion;
    this.nroPeriodo = nroPeriodo;
    this.nroDia = nroDia;
    this.factorConvUsMn = factorConvUsMn;
    this.glosaComprob = glosaComprob;
    this.cveEstadoComprob = cveEstadoComprob;
    this.codUsuario = codUsuario;
    this.fechaHora = fechaHora;
    this.codUnidad = codUnidad;
  }

  public Comprobante(ComprobanteId id, Integer gestion, Integer nroPeriodo,
      Integer nroDia, Date fechaValor, BigDecimal factorConvUsMn,
      String glosaComprob, String codEsquema, char cveEstadoComprob,
      String codUsuario,
      Date fechaHora, String estacion, String codUnidad,
      Character cveDevReal)
  {
    this.id = id;
    this.gestion = gestion;
    this.nroPeriodo = nroPeriodo;
    this.nroDia = nroDia;
    this.fechaValor = fechaValor;
    this.factorConvUsMn = factorConvUsMn;
    this.glosaComprob = glosaComprob;
    this.codEsquema = codEsquema;
    this.cveEstadoComprob = cveEstadoComprob;
    this.codUsuario = codUsuario;
    this.fechaHora = fechaHora;
    this.estacion = estacion;
    this.codUnidad = codUnidad;
    this.cveDevReal = cveDevReal;
  }

  public Comprobante(int nroCentro, char cveTipoComprob, String nroComprob)
  {
    this.id = new ComprobanteId(nroCentro, cveTipoComprob, nroComprob);
  }

  public ComprobanteId getComprobanteId()
  {
    return id;
  }

  public void setComprobanteId(ComprobanteId id)
  {
    this.id = id;
  }

  public Integer getGestion()
  {
    return gestion;
  }

  public void setGestion(Integer gestion)
  {
    this.gestion = gestion;
  }

  public Integer getNroPeriodo()
  {
    return nroPeriodo;
  }

  public void setNroPeriodo(Integer nroPeriodo)
  {
    this.nroPeriodo = nroPeriodo;
  }

  public Integer getNroDia()
  {
    return nroDia;
  }

  public void setNroDia(Integer nroDia)
  {
    this.nroDia = nroDia;
  }

  public Date getFechaValor()
  {
    return fechaValor;
  }

  public void setFechaValor(Date fechaValor)
  {
    this.fechaValor = fechaValor;
  }

  public BigDecimal getFactorConvUsMn()
  {
    return factorConvUsMn;
  }

  public void setFactorConvUsMn(BigDecimal factorConvUsMn)
  {
    this.factorConvUsMn = factorConvUsMn;
  }

  public String getGlosaComprob()
  {
    return glosaComprob;
  }

  public void setGlosaComprob(String glosaComprob)
  {
    this.glosaComprob = glosaComprob;
  }

  public String getCodEsquema()
  {
    return codEsquema;
  }

  public void setCodEsquema(String codEsquema)
  {
    this.codEsquema = codEsquema;
  }

  public Character getCveSubesquema()
  {
    return cveSubesquema;
  }

  public void setCveSubesquema(Character cveSubesquema)
  {
    this.cveSubesquema = cveSubesquema;
  }

  public Integer getNroOperacion()
  {
    return nroOperacion;
  }

  public void setNroOperacion(Integer nroOperacion)
  {
    this.nroOperacion = nroOperacion;
  }

  public char getCveEstadoComprob()
  {
    return cveEstadoComprob;
  }

  public void setCveEstadoComprob(char cveEstadoComprob)
  {
    this.cveEstadoComprob = cveEstadoComprob;
  }

  public String getCodUsuario()
  {
    return codUsuario;
  }

  public void setCodUsuario(String codUsuario)
  {
    this.codUsuario = codUsuario;
  }

  public Date getFechaHora()
  {
    return fechaHora;
  }

  public void setFechaHora(Date fechaHora)
  {
    this.fechaHora = fechaHora;
  }

  public String getEstacion()
  {
    return estacion;
  }

  public void setEstacion(String estacion)
  {
    this.estacion = estacion;
  }

  public Integer getNroAprobacion()
  {
    return nroAprobacion;
  }

  public void setNroAprobacion(Integer nroAprobacion)
  {
    this.nroAprobacion = nroAprobacion;
  }

  public String getCodUnidad()
  {
    return codUnidad;
  }

  public void setCodUnidad(String codUnidad)
  {
    this.codUnidad = codUnidad;
  }

  public Character getCveDevReal()
  {
    return cveDevReal;
  }

  public void setCveDevReal(Character cveDevReal)
  {
    this.cveDevReal = cveDevReal;
  }

  
  public int hashCode()
  {
    int hash = 0;
    hash += (id != null ? id.hashCode() : 0);
    return hash;
  }

  
  public boolean equals(Object object)
  {
    // TODO: Warning - this method won't work in the case the id fields are not
    // set
    if (!(object instanceof Comprobante))
    {
      return false;
    }
    Comprobante other = (Comprobante) object;
    if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id)))
    {
      return false;
    }
    return true;
  }

  
  public String toString()
  {
    return "gob.bcb.service.servicioTres.model.Comprobante[id=" + id + "]";
  }

}
