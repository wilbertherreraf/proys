/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gob.bcb.service.servicioTres.model;



import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * 
 * @author faflores
 */
@Entity
@Table(name = "factura_concepto")
@NamedQueries({ @NamedQuery(name = "FacturaConcepto.findAll", query = "SELECT f FROM FacturaConcepto f") })
public class FacturaConcepto implements Serializable
{
  private static final long serialVersionUID = 1L;
  @EmbeddedId
  protected FacturaConceptoId id;
  @Column(name = "nit")
  private String nit;
  @Column(name = "nombre")
  private String nombre;
  @Column(name = "concepto")
  private String concepto;
  @Column(name = "fch_limite")
  @Temporal(TemporalType.DATE)
  private Date fchLimite;
  @Column(name = "llave_sin")
  private String llaveSin;
  @Column(name = "cod_control")
  private String codControl;

  public FacturaConcepto()
  {
  }

  public FacturaConcepto(FacturaConceptoId id)
  {
    this.id = id;
  }

  public FacturaConcepto(int nroCentro, char cveTipoComprob, String nroComprob,
      int nroReng, int nroSecuencia)
  {
    this.id = new FacturaConceptoId(nroCentro, cveTipoComprob, nroComprob, nroReng, nroSecuencia);
  }

  public FacturaConcepto(FacturaConceptoId id, String nit, String nombre,
      String concepto, Date fchLimite, String llaveSin, String codControl)
  {
    this.id = id;
    this.nit = nit;
    this.nombre = nombre;
    this.concepto = concepto;
    this.fchLimite = fchLimite;
    this.llaveSin = llaveSin;
    this.codControl = codControl;
  }

  public FacturaConcepto(FacturaConceptoId id, String nit, String nombre,
      String concepto)
  {
    this.id = id;
    this.nit = nit;
    this.nombre = nombre;
    this.concepto = concepto;
  }

  public FacturaConceptoId getId()
  {
    return id;
  }

  public void setId(FacturaConceptoId id)
  {
    this.id = id;
  }

  public String getNit()
  {
    return nit;
  }

  public void setNit(String nit)
  {
    this.nit = nit;
  }

  public String getNombre()
  {
    return nombre;
  }

  public void setNombre(String nombre)
  {
    this.nombre = nombre;
  }

  public String getConcepto()
  {
    return concepto;
  }

  public void setConcepto(String concepto)
  {
    this.concepto = concepto;
  }

  public Date getFchLimite()
  {
    return fchLimite;
  }

  public void setFchLimite(Date fchLimite)
  {
    this.fchLimite = fchLimite;
  }

  public String getLlaveSin()
  {
    return llaveSin;
  }

  public void setLlaveSin(String llaveSin)
  {
    this.llaveSin = llaveSin;
  }

  public String getCodControl()
  {
    return codControl;
  }

  public void setCodControl(String codControl)
  {
    this.codControl = codControl;
  }

  
  public int hashCode()
  {
    int hash = 0;
    hash += (id != null ? id.hashCode() : 0);
    return hash;
  }

  
  public boolean equals(Object object)
  {
    // TODO: Warning - this method won't work in the case the id fields are not
    // set
    if (!(object instanceof FacturaConcepto))
    {
      return false;
    }
    FacturaConcepto other = (FacturaConcepto) object;
    if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id)))
    {
      return false;
    }
    return true;
  }

  
  public String toString()
  {
    return "gob.bcb.service.servicioTres.model.FacturaConcepto[id=" + id + "]";
  }

}
