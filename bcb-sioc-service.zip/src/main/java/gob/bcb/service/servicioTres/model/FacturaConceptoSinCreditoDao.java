/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.service.servicioTres.model;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * @author parenas
 * 
 */
public class FacturaConceptoSinCreditoDao extends HibernateDaoSupport 
{
  private static final Log log = LogFactory.getLog(FacturaConceptoSinCreditoDao.class);

  /*
   * (non-Javadoc)
   * @see
   * gob.bcb.service.pruebaCU.model.SolicitudDao#saveOrUpdate(gob.bcb.service
   * .pruebaCU .model.Solicitud)
   */
  
  public void saveOrUpdate(FacturaConceptoSinCredito pm)
  {
    log.info("Saving or updating " + pm);
    this.getHibernateTemplate().saveOrUpdate(pm);
  }

}
