/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gob.bcb.service.servicioTres.model;



import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * 
 * @author faflores
 */
@Entity
@Table(name = "factor_conv_mn")
@NamedQueries({ @NamedQuery(name = "FactorConvMn.findAll", query = "SELECT f FROM FactorConvMn f") })
public class FactorConvMn implements Serializable
{
  private static final long serialVersionUID = 1L;
  @EmbeddedId
  protected FactorConvMnId id;
  @Basic(optional = false)
  @Column(name = "factor")
  private BigDecimal factor;

  public FactorConvMn()
  {
  }

  public FactorConvMn(FactorConvMnId id)
  {
    this.id = id;
  }

  public FactorConvMn(FactorConvMnId id, BigDecimal factor)
  {
    this.id = id;
    this.factor = factor;
  }

  public FactorConvMn(String codMoneda, Date fechaDia)
  {
    this.id = new FactorConvMnId(codMoneda, fechaDia);
  }

  public FactorConvMnId getId()
  {
    return id;
  }

  public void setId(FactorConvMnId id)
  {
    this.id = id;
  }

  public BigDecimal getFactor()
  {
    return factor;
  }

  public void setFactor(BigDecimal factor)
  {
    this.factor = factor;
  }

  
  public int hashCode()
  {
    int hash = 0;
    hash += (id != null ? id.hashCode() : 0);
    return hash;
  }

  
  public boolean equals(Object object)
  {
    // TODO: Warning - this method won't work in the case the id fields are not
    // set
    if (!(object instanceof FactorConvMn))
    {
      return false;
    }
    FactorConvMn other = (FactorConvMn) object;
    if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id)))
    {
      return false;
    }
    return true;
  }

  
  public String toString()
  {
    return "gob.bcb.service.servicioTres.model.FactorConvMn[id=" + id + "]";
  }

}
