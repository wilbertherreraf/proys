/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.service.servicioTres.model;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.joda.time.DateTime;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * @author parenas
 * 
 */
public class ImpPresupDao extends HibernateDaoSupport {
	public static final char DEV_REAL = 'A';
	public static final char REFORM = 'N';

	private static final Log log = LogFactory.getLog(ImpPresupDao.class);


	public Integer CrearImputacion(RengComprobId idI, BigDecimal monto, String partida) {
		int imp = 0;
		DateTime hoyT = new DateTime();
		
		String rengCPS = GetCPRenglon(partida);
		log.info("XXX: " + partida + " - " + rengCPS);
		int j = rengCPS.indexOf("-");
		Integer cp = Integer.parseInt(rengCPS.substring(0, j));
		int rengCP = Integer.parseInt(rengCPS.substring(j + 1));

		ImpPresup imp1 = new ImpPresup(new ImpPresupId(idI.getNroCentro(), idI.getCveTipoComprob(), idI.getNroComprob(), idI.getNroReng(), 1), monto,
				hoyT.getYear(), cp, rengCP, DEV_REAL, REFORM);

		//this.saveOrUpdate(imp1);
		this.getHibernateTemplate().saveOrUpdate(imp1);
		log.info("Imputaci�n presupuestaria guardada: " + idI.getNroCentro() + ", " + idI.getCveTipoComprob() + ", " + idI.getNroComprob() + ", "
				+ idI.getNroReng() + ", " + monto + ", " + partida + ", " + cp + ", " + DEV_REAL + ", " + REFORM);

		return imp;
	}

	public static String GetCPRenglon(String partida) {
		String rengCP = "";

		String query = "select val_nombre " + " from soc_valorescla " + " where cla_codigo = 'cla_rengcp' " + " and val_codigo = '" + partida + "'";

		List<Map<String, Object>> resultado = ServiciosSioc.ejecutarQuery(query, "val_nombre".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				rengCP = (String) res.get("val_nombre");
			}
		} else {
			log.error("No se encuentra su CP para la partida " + partida + " en la parametrizaci�n");
			throw new RuntimeException("No se encuentra su CP para la partida " + partida + " en la parametrizaci�n");
		}

		return rengCP;
	}

}
