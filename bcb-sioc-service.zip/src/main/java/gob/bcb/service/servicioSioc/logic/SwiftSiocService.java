package gob.bcb.service.servicioSioc.logic;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import gob.bcb.bpm.pruebaCU.GenFeriadoDao;
import gob.bcb.bpm.pruebaCU.GenMoneda;
import gob.bcb.bpm.pruebaCU.GenMonedaDao;
import gob.bcb.bpm.pruebaCU.SocBancosDao;
import gob.bcb.bpm.pruebaCU.SocCuentas;
import gob.bcb.bpm.pruebaCU.SocCuentassolDao;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocDetallessolDao;
import gob.bcb.bpm.pruebaCU.SocParametros;
import gob.bcb.bpm.pruebaCU.SocParametrosDao;
import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.bpm.pruebaCU.SocSolicitanteDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.SocSolicitudesDao;
import gob.bcb.bpm.pruebaCU.SocUsuariosol;
import gob.bcb.bpm.pruebaCU.SocUsuariosolDao;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.ClienteLvdSioc;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.mail.MsgLogic;
import gob.bcb.service.servicioSioc.pojos.BancoPlaza;
import gob.bcb.swift.commons.ConstantsSwift;
import gob.bcb.swift.dao.SwfMensajeBean;
import gob.bcb.swift.dao.SwfMensajeLocal;
import gob.bcb.swift.model.SwfMensaje;
import gob.bcb.swift.pojos.SwiftDatos;
import gob.bcb.swift.service.SwiftMessageService;

public class SwiftSiocService extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SwiftSiocService.class);

	public void generarMensSwift(Solicitud solicitudTO) {
		String codUsuarioSwift = solicitudTO.getCodUsuarioAudit();

		SocSolicitudesDao socSolicitudesDao = new SocSolicitudesDao();
		socSolicitudesDao.setSessionFactory(getSessionFactory());

		SocDetallessolDao socDetallessolDao = new SocDetallessolDao();
		socDetallessolDao.setSessionFactory(getSessionFactory());

		SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
		socSolicitanteDao.setSessionFactory(getSessionFactory());

		SwfMensajeLocal swfMensajeLocal = new SwfMensajeBean();
		swfMensajeLocal.setSessionFactory(getSessionFactory());

		SocSolicitudes solicitudOld = socSolicitudesDao.getSolicitud(solicitudTO.getSolicitud().getSocCodigo());

		if (solicitudOld == null) {
			log.error("Swift: Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
			throw new BusinessException("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
		}

		if ((solicitudOld.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)) && solicitudOld.getCodMonedat().compareTo(Constants.COD_MONEDA_BS) != 0
				&& solicitudOld.getSocTipnegociacion().equals(Constants.CLAVE_TIPNEGOCIA_NORMAL)) {

			if (solicitudOld.getFechaCont() == null) {
				log.error("Fecha valor mensaje swift" + solicitudOld.getSocCodigo() + " nulo");
				throw new BusinessException("Fecha valor mensaje swift" + solicitudOld.getSocCodigo() + " nulo");
			}

			Date fechaValor = solicitudOld.getFechaCont();

			if (UtilsDate.compara(solicitudOld.getFechaCont(), new Date()) < 0) {
				log.error("Fecha valor mensaje swift menor [" + UtilsDate.stringFromDate(fechaValor, "dd/MM/yyyy") + "] a hoy, " + solicitudOld.getSocCodigo());
				throw new BusinessException("Fecha valor mensaje swift menor [" + UtilsDate.stringFromDate(fechaValor, "dd/MM/yyyy") + "] a hoy, " + solicitudOld.getSocCodigo());
			}

			log.info("Inicio : generarMensSwift " + solicitudOld.getSocCodigo() + " " + UtilsDate.stringFromDate(fechaValor, "dd/MM/yyyy"));

			List<SocDetallessol> socDetallessolListaPrev = socDetallessolDao.getDetalles(solicitudOld.getSocCodigo());

			if (socDetallessolListaPrev.size() == 0) {
				log.error("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] sin beneficiarios registrados");
				throw new BusinessException("Swift: Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] sin beneficiarios registrados");
			}

			List<SocDetallessol> socDetallessolLista = new ArrayList<SocDetallessol>();
			int cont = 0;
			// controlamos si ya fue generado los mensajes
			for (SocDetallessol socDetallessol : socDetallessolListaPrev) {
				SwfMensaje swfMensaje = swfMensajeLocal.findByCodoperacion(solicitudTO.getSolicitud().getSocCodigo(), socDetallessol.getId().getDetCodigo());

				if (swfMensaje == null) {
					// no fue registrado
					socDetallessolLista.add(socDetallessol);

				} else {
					if (!swfMensaje.getMenCveestswift().equals(ConstantsSwift.PAR_ESTSWIFT_AUTO)) {
						socDetallessolLista.add(socDetallessol);
					} else {
						cont++;
					}
				}
			}

			if (socDetallessolLista.size() == 0) {
				log.warn(
						"Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] Mensajes swift sin beneficiarios a procesar!!! swifts autorizados: " + cont + " mensajes");
				return;
			}

			// se valida que la fecha sea habil
			GenFeriadoDao genFeriadoDao = new GenFeriadoDao();
			genFeriadoDao.setSessionFactory(getSessionFactory());

			SocUsuariosolDao socUsuariosolDao = new SocUsuariosolDao();
			socUsuariosolDao.setSessionFactory(getSessionFactory());

			SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCod(solicitudTO.getSolicitud().getSolCodigo());
			solicitudTO.setSocSolicitante(socSolicitante);

			log.info("Proceso de registrarMensajeSwift iniciado " + UtilsDate.stringFromDate(fechaValor, "dd/MM/yyyy"));
			boolean isHabil = genFeriadoDao.isHabil(fechaValor, solicitudOld.getCodMonedat());

			if (isHabil == false) {
				log.warn("Mensajes SWIFT no generados POR FERIADO para fecha " + fechaValor + " moneda " + solicitudOld.getCodMonedat());
				Map<String, String> paramsMailRespuesta = new HashMap<String, String>();
				paramsMailRespuesta.put("observacion", "Mensajes SWIFT no generados POR FERIADO para fecha " + fechaValor + " moneda " + solicitudOld.getCodMonedat());

				String subject = "AVISO: Swift NO GENERADO POR FERIADO " + socSolicitante.getSigla() + " - " + solicitudOld.getSocCodigo();
				String content = MsgLogic.textoSolicitud(solicitudTO, 0, null, paramsMailRespuesta);

				socUsuariosolDao.formarMail("WSSWIFTFERIADO", subject, content, "'900'");

				return;
			}

			List<SocUsuariosol> socUsuariosolLista = socUsuariosolDao.getUsuariosSioc(Constants.COD_BCB, codUsuarioSwift, null);

			if (socUsuariosolLista.size() != 1) {
				throw new BusinessException("Swift: Error de parametrizacion usuario: " + codUsuarioSwift + " no registrado en usuarios SIOC");
			}

			if (StringUtils.isBlank(socUsuariosolLista.get(0).getUsrIniciales())) {
				throw new BusinessException("Swift: Error de parametrizacion usuario " + codUsuarioSwift + " con iniciales swift nulo");
			}

			GenMonedaDao genMonedaDao = new GenMonedaDao();
			genMonedaDao.setSessionFactory(getSessionFactory());

			GenMoneda genMoneda = null;

			for (SocDetallessol socDetallessol : socDetallessolLista) {
				genMoneda = genMonedaDao.findByCodMoneda(socDetallessol.getCodMonedatdet());
				crearMensajeSwift(solicitudTO, socDetallessol, socUsuariosolLista.get(0), genMoneda);
			}

			// si es de transferencia
			// se controla que se haya realizado la actualizacion de mensajes
			// swift
			socDetallessolLista = socDetallessolDao.getDetalles(solicitudTO.getSolicitud().getSocCodigo());
			for (SocDetallessol socDetallessol : socDetallessolLista) {

				SwfMensaje swfMensaje = swfMensajeLocal.findByCodoperacion(solicitudTO.getSolicitud().getSocCodigo(), socDetallessol.getId().getDetCodigo());
				if (swfMensaje == null) {
					log.error("Mensaje Swift no fue creado o actualizado, actualice los valores para " + solicitudTO.getSolicitud().getSocCodigo() + " detalle "
							+ socDetallessol.getId().getDetCodigo());

					throw new BusinessException("Mensaje Swift no fue creado o actualizado, actualice los valores para " + solicitudTO.getSolicitud().getSocCodigo() + " detalle "
							+ socDetallessol.getId().getDetCodigo());
				}
			}

		}
	}

	private SwfMensaje crearMensajeSwift(Solicitud solicitud, SocDetallessol socDetallessol, SocUsuariosol socUsuariosol, GenMoneda genMoneda) {
		log.info("creando mensaje:  " + solicitud.getSolicitud().getSocCodigo() + " " + socDetallessol.getId().getDetCodigo());

		SwfMensajeLocal swfMensajeLocal = new SwfMensajeBean();
		swfMensajeLocal.setSessionFactory(getSessionFactory());

		SwiftMessageService swiftMessageService = new SwiftMessageService();
		swiftMessageService.setSessionFactory(getSessionFactory());

		SocBancosDao socBancosDao = new SocBancosDao();
		socBancosDao.setSessionFactory(getSessionFactory());

		SocDetallessolDao socDetallessolDao = new SocDetallessolDao();
		socDetallessolDao.setSessionFactory(getSessionFactory());

		SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
		socCuentassolDao.setSessionFactory(getSessionFactory());

		// **************/

		SwiftDatos swiftDatos = new SwiftDatos();

		swiftDatos.setAuditusr(solicitud.getSolicitud().getUsrCodigo());
		swiftDatos.setAuditwst(solicitud.getSolicitud().getEstacion());

		swiftDatos.setSolicitudTO(solicitud);
		swiftDatos.setSocDetallessol(socDetallessol);

		SwfMensaje swfMensaje = swfMensajeLocal.findByCodoperacion(solicitud.getSolicitud().getSocCodigo(), socDetallessol.getId().getDetCodigo());

		if (swfMensaje != null) {
			if (swfMensaje.getMenCveestswift().trim().equals(ConstantsSwift.PAR_ESTSWIFT_AUTO)) {
				throw new BusinessException(
						"Swift: Operacion " + solicitud.getSolicitud().getSocCodigo() + " " + socDetallessol.getId().getDetCodigo() + " con estado autorizado");
			}
		}

		socDetallessolDao.validarDatos(solicitud.getSolicitud(), socDetallessol);

		if (swfMensaje == null) {
			swfMensaje = new SwfMensaje();
			swfMensaje.setMenCodoperacion(solicitud.getSolicitud().getSocCodigo());
			swfMensaje.setMenDetcodigo(socDetallessol.getId().getDetCodigo());
		}

		Calendar c = GregorianCalendar.getInstance();

		SocCuentas socCuentas = socCuentassolDao.getSocCuentaBanqueroExt(solicitud.getSolicitud(), socDetallessol.getCodMonedatdet(), null);

		if (socCuentas == null) {
			throw new BusinessException("Swift: Operacion " + solicitud.getSolicitud().getSocCodigo() + " det: " + socDetallessol.getId().getDetCodigo()
					+ " sin cuenta en banco(soccuentas) exterior moneda " + socDetallessol.getCodMonedatdet());
		}

		// SocValorescla socValorescla =
		// socValoresclaDao.getValoresByCod("cla_banquero",
		// String.valueOf((solicitud.getSolicitud().getCodMonedat())));

		BancoPlaza bancoPlazaSender = socBancosDao.bancoPlazaByCod(Constants.COD_BCB_SWIFT);
		// BancoPlaza bancoPlazaReceiver =
		// socBancosDao.bancoPlazaByCod(socValorescla.getValNombre());
		BancoPlaza bancoPlazaReceiver = socBancosDao.bancoPlazaByCod(socCuentas.getBcoCodigo());
		// BancoPlaza bancoPlazaReceiver =
		// socBancosDao.bancoPlazaByCod(socCuentasLista.get(0).getBcoCodigo());

		swfMensaje.setMenBic(bancoPlazaReceiver.getPlaBic());
		swfMensaje.setMenCodmt(socDetallessol.getDetCodttransfer());
		swfMensaje.setMenBicemisor(bancoPlazaSender.getPlaBic());
		swfMensaje.setMenGestion(c.get(Calendar.YEAR));
		swfMensaje.setMenMonto(socDetallessol.getDetMontotrans());
		swfMensaje.setMenCodmon(solicitud.getSolicitud().getCodMonedat());
		swfMensaje.setMenCodmonswift(genMoneda.getDesSwift());
		swfMensaje.setMenFecreg(new Date());
		swfMensaje.setMenFecvalor(solicitud.getSolicitud().getFechaCont());
		swfMensaje.setMenCveestswift(ConstantsSwift.PAR_ESTSWIFT_PEND);
		swfMensaje.setMenCodusrswf(socUsuariosol.getUsrIniciales());
		swfMensaje.setMenAuditusr(solicitud.getCodUsuarioAudit());
		swfMensaje.setMenAuditwst(solicitud.getCodEstacionAudit());

		swiftDatos.setSwfMensaje(swfMensaje);

		SwfMensaje swfMensajeNew = swiftMessageService.generarMensaje(swiftDatos);

		return swfMensajeNew;
	}

	public Solicitud autorizarSwift(Solicitud solicitudTO) {
		SocSolicitudesDao socSolicitudesDao = new SocSolicitudesDao();
		socSolicitudesDao.setSessionFactory(getSessionFactory());

		SocSolicitudes solicitudOld = socSolicitudesDao.getSolicitud(solicitudTO.getSolicitud().getSocCodigo());

		if (solicitudOld == null) {
			log.error("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
			throw new BusinessException("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
		}

		if (solicitudOld.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)) {
			log.info("Inicio : autorizacion Swift " + solicitudTO.getSolicitud().getSocCodigo());
			if (solicitudOld.getSocTipnegociacion().equals(Constants.CLAVE_TIPNEGOCIA_OPER)) {
				log.info("Operacion[[" + solicitudTO.getSolicitud().getSocCodigo() + "] con tipo negociacion " + solicitudOld.getSocTipnegociacion() + ", no se genera swifts ");
				return solicitudTO;
			}
			
			SocParametrosDao socParametrosDao = new SocParametrosDao();
			socParametrosDao.setSessionFactory(getSessionFactory());

			SocDetallessolDao socDetallessolDao = new SocDetallessolDao();
			socDetallessolDao.setSessionFactory(getSessionFactory());

			SwfMensajeBean swfMensajeBean = new SwfMensajeBean();
			swfMensajeBean.setSessionFactory(getSessionFactory());

			SocParametros socParametros = socParametrosDao.getByCodigo(ConstantsSwift.PARAM_PATHSWIFT);

			String pathSwift = socParametros.getParValor();

			List<SocDetallessol> socDetallessolLista = socDetallessolDao.getDetalles(solicitudOld.getSocCodigo());

			SwiftMessageService swiftMessageService = new SwiftMessageService();
			swiftMessageService.setSessionFactory(getSessionFactory());

			ClienteLvdSioc clienteLvdSioc = new ClienteLvdSioc(getSessionFactory());
			clienteLvdSioc.initClienteLvd();
			clienteLvdSioc.getSessionLavado(solicitudTO.getCodUsuarioAudit());
			
			for (SocDetallessol socDetallessol : socDetallessolLista) {
				log.info("Detalle  Swift " + solicitudTO.getSolicitud().getSocCodigo() + " - " + socDetallessol.getId().getDetCodigo());
				SwfMensaje swfMensaje = swfMensajeBean.findByCodoperacion(solicitudTO.getSolicitud().getSocCodigo(), socDetallessol.getId().getDetCodigo());

				if (swfMensaje == null) {
					throw new BusinessException(
							"Mensaje Swift para [" + solicitudTO.getSolicitud().getSocCodigo() + "-" + socDetallessol.getId().getDetCodigo() + "] inexistente");
				}

				if (swfMensaje.getMenCveestswift().equals(ConstantsSwift.PAR_ESTSWIFT_PREAUT)) {
					// ******* guardamos swifttttttttttttttt**********//
					// marcamos el detalle como Transferido
					socDetallessol.setClaEstadodet("T");
					socDetallessol.setEstacion(solicitudTO.getCodEstacionAudit());
					socDetallessol.setUsrCodigo(solicitudTO.getCodUsuarioAudit());
					socDetallessol.setFechaHora(new Date());

					swfMensajeBean.getHibernateTemplate().merge(socDetallessol);

					swfMensaje.setMenCveestswift(ConstantsSwift.PAR_ESTSWIFT_AUTO);
					swfMensaje.setMenAuditusr(solicitudTO.getCodUsuarioAudit());
					swfMensaje.setMenAuditwst(solicitudTO.getCodEstacionAudit());
					swfMensaje.setMenAuditfho(new Date());

					swfMensajeBean.getHibernateTemplate().merge(swfMensaje);
					if (clienteLvdSioc.getClienteLvd() != null && (swfMensaje.getMenNrolavado() != null && swfMensaje.getMenNrolavado().compareTo(0) > 0)){
						clienteLvdSioc.preautorizarSwift(swfMensaje);					
					} else {
						swiftMessageService.autorizarMensaje(swfMensaje, pathSwift);						
					}
				}
			}
			clienteLvdSioc.cerrarSession(solicitudTO.getCodUsuarioAudit());
		}
		return solicitudTO;
	}

	public Solicitud rechazarSwfMensaje(Solicitud solicitudTO) {
		SwfMensaje swfMensajePar = solicitudTO.getSwfMensaje();
		if (swfMensajePar == null) {
			throw new BusinessException("Parametro swfMensaje nulo en objeto solicitud, avise al adminsitrador");
		}
		SwfMensajeBean swfMensajeBean = new SwfMensajeBean();
		swfMensajeBean.setSessionFactory(getSessionFactory());

		SwfMensaje swfMensaje = swfMensajeBean.findByCodigo(swfMensajePar.getMenCodmen());

		if (swfMensaje == null) {
			throw new BusinessException("Mensaje Swift [" + swfMensajePar.getMenCodmen() + "] inexistente");
		}

		log.info("Rechazando mensaje swift " + swfMensajePar.getMenCodmen());

		if (swfMensaje.getMenCveestswift().equals(ConstantsSwift.PAR_ESTSWIFT_AUTO) || swfMensaje.getMenCveestswift().equals(ConstantsSwift.PAR_ESTSWIFT_RECH)) {
			throw new BusinessException("Mensaje Swift [" + swfMensajePar.getMenCodmen() + "] en estado invalido " + swfMensaje.getMenCveestswift()
					+ " debe estar en pendiente o preautorizado para continuar");
		}

		swfMensaje.setMenCveestswift(ConstantsSwift.PAR_ESTSWIFT_RECH);
		swfMensaje.setMenAuditusr(solicitudTO.getCodUsuarioAudit());
		swfMensaje.setMenAuditwst(solicitudTO.getCodEstacionAudit());
		swfMensaje.setMenAuditfho(new Date());

		swfMensajeBean.getHibernateTemplate().merge(swfMensaje);

		return solicitudTO;
	}

	public Solicitud autorizarSwfMensaje(Solicitud solicitudTO) {
		log.info("Autorizando mensaje swift ");
		SwfMensaje swfMensajePar = solicitudTO.getSwfMensaje();
		if (swfMensajePar == null) {
			throw new BusinessException("Parametro swfMensaje nulo en objeto solicitud, avise al adminsitrador");
		}
		SocSolicitudesDao socSolicitudesDao = new SocSolicitudesDao();
		socSolicitudesDao.setSessionFactory(getSessionFactory());

		SocDetallessolDao socDetallessolDao = new SocDetallessolDao();
		socDetallessolDao.setSessionFactory(getSessionFactory());

		SwfMensajeBean swfMensajeBean = new SwfMensajeBean();
		swfMensajeBean.setSessionFactory(getSessionFactory());

		SwfMensaje swfMensaje = swfMensajeBean.findByCodigo(swfMensajePar.getMenCodmen());

		if (swfMensaje == null) {
			throw new BusinessException("Mensaje Swift [" + swfMensajePar.getMenCodmen() + "] inexistente");
		}

		SocSolicitudes solicitudOld = socSolicitudesDao.getSolicitud(swfMensaje.getMenCodoperacion());

		if (solicitudOld == null) {
			log.error("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
			throw new BusinessException("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
		}
		solicitudTO.setSolicitud(solicitudOld);
		log.info("Autorizando mensaje swift " + swfMensajePar.getMenCodmen());
		if (!swfMensaje.getMenCveestswift().equals(ConstantsSwift.PAR_ESTSWIFT_PREAUT)) {
			throw new BusinessException(
					"Mensaje Swift [" + swfMensajePar.getMenCodmen() + "] en estado invalido " + swfMensaje.getMenCveestswift() + " debe estar en preautorizado para continuar");
		}

		SocDetallessol socDetallessol = socDetallessolDao.getDetalle(swfMensaje.getMenCodoperacion(), swfMensaje.getMenDetcodigo());
		if (socDetallessol == null) {
			throw new BusinessException("Detalle del beneficiario [" + swfMensaje.getMenCodoperacion() + " - " + swfMensaje.getMenDetcodigo() + "] inexistente");
		}

		SocParametrosDao socParametrosDao = new SocParametrosDao();
		socParametrosDao.setSessionFactory(getSessionFactory());

		SocParametros socParametros = socParametrosDao.getByCodigo(ConstantsSwift.PARAM_PATHSWIFT);

		String pathSwift = socParametros.getParValor();

		SwiftMessageService swiftMessageService = new SwiftMessageService();
		swiftMessageService.setSessionFactory(getSessionFactory());
		// ******* guardamos swifttttttttttttttt**********//
		// marcamos el detalle como Transferido
		socDetallessol.setClaEstadodet("T");
		socDetallessol.setEstacion(solicitudTO.getCodEstacionAudit());
		socDetallessol.setUsrCodigo(solicitudTO.getCodUsuarioAudit());
		socDetallessol.setFechaHora(new Date());

		swfMensajeBean.getHibernateTemplate().merge(socDetallessol);

		swfMensaje.setMenCveestswift(ConstantsSwift.PAR_ESTSWIFT_AUTO);
		swfMensaje.setMenAuditusr(solicitudTO.getCodUsuarioAudit());
		swfMensaje.setMenAuditwst(solicitudTO.getCodEstacionAudit());
		swfMensaje.setMenAuditfho(new Date());

		swfMensajeBean.getHibernateTemplate().merge(swfMensaje);

		swiftMessageService.autorizarMensaje(swfMensaje, pathSwift);
		return solicitudTO;
	}

	public Solicitud preAutorizarSwfMensaje(Solicitud solicitudTO) {
		log.info("PRE Autorizando SOLO mensaje swift ");
		SwfMensaje swfMensajePar = solicitudTO.getSwfMensaje();
		if (swfMensajePar == null) {
			throw new BusinessException("Parametro swfMensaje nulo en objeto solicitud, avise al adminsitrador");
		}

		SocSolicitudesDao socSolicitudesDao = new SocSolicitudesDao();
		socSolicitudesDao.setSessionFactory(getSessionFactory());

		SocDetallessolDao socDetallessolDao = new SocDetallessolDao();
		socDetallessolDao.setSessionFactory(getSessionFactory());

		SwfMensajeBean swfMensajeBean = new SwfMensajeBean();
		swfMensajeBean.setSessionFactory(getSessionFactory());

		SwfMensaje swfMensaje = swfMensajeBean.findByCodigo(swfMensajePar.getMenCodmen());

		if (swfMensaje == null) {
			throw new BusinessException("Mensaje Swift [" + swfMensajePar.getMenCodmen() + "] inexistente");
		}

		SocSolicitudes solicitudOld = socSolicitudesDao.getSolicitud(swfMensaje.getMenCodoperacion());

		if (solicitudOld == null) {
			log.error("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
			throw new BusinessException("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
		}
		solicitudTO.setSolicitud(solicitudOld);
		log.info("Autorizando mensaje swift " + swfMensajePar.getMenCodmen());
		if (!swfMensaje.getMenCveestswift().equals(ConstantsSwift.PAR_ESTSWIFT_PEND)) {
			throw new BusinessException(
					"Mensaje Swift [" + swfMensajePar.getMenCodmen() + "] en estado invalido " + swfMensaje.getMenCveestswift() + " debe estar en pendiente para continuar");
		}

		SocDetallessol socDetallessol = socDetallessolDao.getDetalle(swfMensaje.getMenCodoperacion(), swfMensaje.getMenDetcodigo());
		if (socDetallessol == null) {
			throw new BusinessException("Detalle del beneficiario [" + swfMensaje.getMenCodoperacion() + " - " + swfMensaje.getMenDetcodigo() + "] inexistente");
		}

		SocParametrosDao socParametrosDao = new SocParametrosDao();
		socParametrosDao.setSessionFactory(getSessionFactory());

		SocParametros socParametros = socParametrosDao.getByCodigo(ConstantsSwift.PARAM_PATHSWIFT);
		String pathSwift = socParametros.getParValor();

		SwiftMessageService swiftMessageService = new SwiftMessageService();
		swiftMessageService.setSessionFactory(getSessionFactory());

		swfMensaje.setMenAuditusr(solicitudTO.getCodUsuarioAudit());
		swfMensaje.setMenAuditwst(solicitudTO.getCodEstacionAudit());

		// ******* guardamos swifttttttttttttttt**********//
		ClienteLvdSioc clienteLvdSioc = new ClienteLvdSioc(getSessionFactory());
		clienteLvdSioc.initClienteLvd();
		clienteLvdSioc.getSessionLavado(solicitudTO.getCodUsuarioAudit());		
		swiftMessageService.actualizarCorrelativo(swfMensaje, pathSwift,clienteLvdSioc);
		
		clienteLvdSioc.cerrarSession(solicitudTO.getCodUsuarioAudit());		

		log.info("Swift PRE autorizado " + solicitudTO.getSolicitud().getSocCodigo() + " mensaje " + swfMensaje.getMenCodmen());
		return solicitudTO;
	}

	// TE SF
	// 1. se registra y se envia email B
	// al dia siguiente el aut del sf provisiona genera provision 61 R genra itf
	// el operador bcb geenra la operacion
	public Solicitud preAutorizarSwift(Solicitud solicitudTO) {
		log.info("Inicio : PRE autorizarSwift " + solicitudTO.getSolicitud().getSocCodigo());
		SocSolicitudesDao socSolicitudesDao = new SocSolicitudesDao();
		socSolicitudesDao.setSessionFactory(getSessionFactory());

		SocDetallessolDao socDetallessolDao = new SocDetallessolDao();
		socDetallessolDao.setSessionFactory(getSessionFactory());

		SwfMensajeBean swfMensajeBean = new SwfMensajeBean();
		swfMensajeBean.setSessionFactory(getSessionFactory());

		SocSolicitudes solicitudOld = socSolicitudesDao.getSolicitud(solicitudTO.getSolicitud().getSocCodigo());

		if (solicitudOld == null) {
			log.error("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
			throw new BusinessException("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
		}

		if (!solicitudTO.getCodPersonaAudit().equals(Constants.COD_BCB)) {
			if (solicitudTO.getSolicitud().getCveTipctasolic().equals(Constants.CLAVE_GENERADOPOR_SISTEMA)) {
				return solicitudTO;
			}
		}

		if (solicitudOld.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)) {
			if (solicitudOld.getSocTipnegociacion().equals(Constants.CLAVE_TIPNEGOCIA_OPER)) {
				log.info("Operacion[[" + solicitudTO.getSolicitud().getSocCodigo() + "] con tipo negociacion " + solicitudOld.getSocTipnegociacion() + ", no se genera swifts ");
				return solicitudTO;
			}
			
			ClienteLvdSioc clienteLvdSioc = new ClienteLvdSioc(getSessionFactory());

			SocParametrosDao socParametrosDao = new SocParametrosDao();
			socParametrosDao.setSessionFactory(getSessionFactory());

			SocParametros socParametros = socParametrosDao.getByCodigo(ConstantsSwift.PARAM_PATHSWIFT);

			String pathSwift = socParametros.getParValor();

			SwiftMessageService swiftMessageService = new SwiftMessageService();
			swiftMessageService.setSessionFactory(getSessionFactory());

			List<SocDetallessol> socDetallessolLista = socDetallessolDao.getDetalles(solicitudOld.getSocCodigo());

			clienteLvdSioc.initClienteLvd();
			clienteLvdSioc.getSessionLavado(solicitudTO.getCodUsuarioAudit());

			for (SocDetallessol socDetallessol : socDetallessolLista) {
				SwfMensaje swfMensaje = swfMensajeBean.findByCodoperacion(solicitudTO.getSolicitud().getSocCodigo(), socDetallessol.getId().getDetCodigo());

				if (swfMensaje == null) {
					throw new BusinessException("Mensaje Swift para [" + solicitudTO.getSolicitud().getSocCodigo() + "-" + socDetallessol.getId().getDetCodigo()
							+ "] inexistente, actualice la operacion");
				}
				if (swfMensaje.getMenCveestswift().equals(ConstantsSwift.PAR_ESTSWIFT_PEND)) {
					swfMensaje.setMenAuditusr(solicitudTO.getCodUsuarioAudit());
					swfMensaje.setMenAuditwst(solicitudTO.getCodEstacionAudit());

					// ******* guardamos swifttttttttttttttt**********//
					swiftMessageService.actualizarCorrelativo(swfMensaje, pathSwift, clienteLvdSioc);

					log.info("mensaje swift PRE autorizado " + solicitudTO.getSolicitud().getSocCodigo() + " - " + socDetallessol.getId().getDetCodigo() + " codmensaje: "
							+ swfMensaje.getMenCodmen());
				}
			}
			clienteLvdSioc.cerrarSession(solicitudTO.getCodUsuarioAudit());
		}
		return solicitudTO;
	}
}
