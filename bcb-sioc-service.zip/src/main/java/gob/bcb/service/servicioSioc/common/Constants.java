package gob.bcb.service.servicioSioc.common;

public interface Constants {
	public static final String CODAPP_SIOC = "SIOCWEB";	
	public static final String FORMAT_DATE_DB = "dd/MM/yyyy";
	
	/**
	 * Formato de fecha hora para datos que requieran hora
	 */
	public static final String FORMAT_DATE_TIME = "yyyy-MM-dd HH:mm:ss:SSS";
	
	static final String PROP_ALIAS_SIOC = "sioc";
	static final String PROP_ALIAS_BOLSIN = "bolsin";
	static final String PROP_ALIAS_COIN = "coin";
	static final String PROP_ALIAS_PORTIA = "portia";
	static final String PROP_ALIAS_BDWEB = "bdweb";
	public static final String OPERACION_RECEIVED = "Received";	
	public static final String OPERACION_SUCCESS = "A00000";
	public static final String OPERACION_FASE = "fase";
	public static final String SERVICE_EXCEPTION = "ERROR_DE_VALIDACION";
	public static final String OPERACION_SENDED = "Sended";
	public static final String UNKNOWN_EXCEPTION = "UnknownException";	
	public static final String RUNTIME_EXCEPTION = "RuntimeException";	
	public static final String DATABASE_EXCEPTION = "DataBaseException";
	public static final String SECURITY_EXCEPTION = "SecurityException";	
	public static final String UNSUPPORTED_OPERATION_EXCEPTION = "UnsupportedOperationException";
	
	static final String PARAM_USUARIO_TASK = "usuarioTask";
	static final String PARAM_USUARIO_CONT = "@usuario";
	public static final String OBJ_NAME_SOLICITUDTO = "objsolicitudto";
	// ########## INICIO: VALORES DESTINADOS A AUDITORIA ########//
	static final String AUDIT_HORA_RECEPCION = "ReceivedDate";
	static final String AUDIT_COD_TIPO_OPERACION = "codTipoOperacion";	
	static final String AUDIT_USER_ESTACION = "estacion";
	static final String AUDIT_USER_SESSION_ID = "userID";
	// usuario contable
	static final String AUDIT_USER_DATABASE_ID = "userDatabase";	
	
	static final String TIPO_OPERACION_ADJUD_AUTO = "adjudicacion";
	static final String TIPO_OPERACION_RETIRO_AUTO = "retiroAuto";	
	static final String TIPO_OPERACION_REVISAVD_AUTO = "revisaVDAuto";
	static final String TIPO_OPERACION_TRANSEXTMEFP = "TRANS_EXT_MONMEFP";
	
	static final String COD_IFA_REQUEST = "codIFARequest";
	static final String COD_IFA_MEFP = "237";
	static final String COD_IFA_BUSA = "913";	
	static final String COD_BCB = "900";
	static final String COD_BCB_SWIFT = "000000";
	static final String COD_BCB_SIGEP = "1004";
	static final String CTA_TRANSIT_PROV = "4088";	
	static final String CTA_TRANSIT_SECPUBGOI = "6818";
	static final String CTA_FISCAL = "0818";
	static final String CTA_CUT = "3987";	
	
	static final String COD_CLAVE_MOVPROVISION = "MOVPROVISION";
	static final String COD_CLAVE_MOVDESTINO = "MOVDESTINO";
	static final String COD_CLAVE_TRANSIT_SECPUBGOI = "TRANSIT_SECPUBGOI";	
	static final String COD_CLAVE_TRANSCOMIS = "TRANSCOMIS";
	static final String COD_CLAVE_TRANSCOMISUSD = "TRANSCOMISUSD";
	static final String COD_CLAVE_TRANSPROVUSD = "TRANSPROVUSD";
	static final String COD_CLAVE_COMGADMGOI = "TRANSCOMISGOI";
	static final String COD_CLAVE_BENEFMT = "BENEFMT";	
	
	static final String COD_CLAVE_COMGADM = "COMGADM";
	static final String COD_CLAVE_COMCTRA = "COMCTRA";
	static final String COD_CLAVE_FONDOSVISTA = "FONDOS_VISTA";
	static final String COD_CLAVE_CTAACREEDORES = "CTA_ACREEDORES";	
	
	static final String COD_VAR_COMUTIL = "COMUTIL";
	static final String COD_VAR_COMSWIFT = "COMSWIFT";
	static final String COD_VAR_VENTAUSD = "VENTAUSD";
	static final String COD_VAR_COMTRANSF = "COMTRANSF";
	static final String COD_VAR_MONTOGASTOCOM = "MONTOGASTOCOM";
	static final String COD_VAR_MONTOGASTOADM = "MONTOGASTOADM";
	static final String COD_VAR_MONTOCOMTRANSEXT = "MONTOCOMTRANSEXT";
	static final String COD_VAR_TOTTRANSMT = "TOTTRANSMT";
	static final String COD_VAR_MONTONEGOC = "MONTONEGOC";	
	static final String COD_VAR_MONTOD = "MONTOD";	
	static final String COD_VAR_TOTDEBITO = "TOTDEBITO";
	
	static final String COD_VAR_MONTODIFCAMBVENDIV= "MONTODIFCAMBVENDIV";
	
	//static final String COD_CLAVE_COMCTRAGOI = "COMCTRAGOI";
	static final String COD_CLAVE_DIFCAMB = "DIFCAMB";
	static final String COD_CLAVE_ITFPROV = "ITFPROV";	
	static final String COD_CLAVE_ITFCOM = "ITFCOM";	
	
	static final String CLAVE_TIPOOPER_VENTA = "VE";	
	static final String CLAVE_TIPOOPER_TRAEXT = "TE";
	static final String CLAVE_TIPOOPER_TRACTA = "TC";	
	static final String CLAVE_TIPOOPER_DELEXT = "TD";
	static final String CLAVE_TIPOOPER_DELEXT_REGISACREE = "ACR";	
	static final String CLAVE_TIPOOPER_DELEXT_REGACREE = "RGAC";	
	static final String CLAVE_TIPOOPER_DELEXT_DEVFONDOSVISTA = "DVFV";	
	
	static final String CLAVE_TIPOOPER_ITF = "ITF";	
	static final String CLAVE_SUBTIPOOPER_TRAEXT = "TE";	
	static final String CLAVE_SUBTIPOOPER_TRACTA = "TC";	
	static final String CLAVE_SUBTIPOOPER_ORDPAG = "OP";	
	static final String CLAVE_SUBTIPOOPER_CARTAS = "CC";
	static final String CLAVE_SUBTIPOOPER_TRADELEXT = "TD";
	
	static final String CLAVE_TIPOCARGO_TRANSFER = "P";
	static final String CLAVE_TIPOESQ_OPER = "O";
	static final String CLAVE_TIPOESQ_PROV = "P";	
	static final String CLAVE_TIPOESQ_RET = "R";
	static final String CLAVE_TIPOESQ_ITF = "I";	
	static final String CLAVE_GENERADOPOR_SISTEMA = "S";	
	static final String CLAVE_GENERADOPOR_WS = "W";	
	static final Integer COD_MONEDA_BS = 69;
	static final Integer COD_MONEDA_USD = 34;	
	static final String CLAVE_TIPORETENCION_SINDESC = "S";	
	static final String CLAVE_TIPORETENCION_CONDESC = "D";
	static final String CLAVE_TIPORETENCION_CONDESCPARCIAL = "P";	
	static final String CLAVE_TIPOTRANSFER_SINPROV = "S";	
	static final String CLAVE_TIPOTRANSFER_CONPROV = "P";	
	static final String CLAVE_CLAENTIDAD_SISTPUBLICO = "SP";
	static final String CLAVE_CLAENTIDAD_SISTFINANCIERO = "SF";
	
	static final String CLAVE_CARGOTIPOCOMIS_SWFT = "SWFT";
	static final String CLAVE_CARGOTIPOCOMIS_UTIL = "UTIL";	
	
	static final String CLAVE_DELEXT_TIPCONCEPTO_ORDPAGO = "BOP";	
	static final String CLAVE_DELEXT_TIPCONCEPTO_ACREEDORES = "BAC";	
	static final String CLAVE_DELEXT_TIPCONCEPTO_SECPUB = "SP";	
	static final String CLAVE_DELEXT_TIPCONCEPTO_SISTFIN = "SF";	
	
	static final String CLAVE_DELEXT_MOTIVO_TRANS_REMESAS = "REM";
	static final String CLAVE_DELEXT_MOTIVO_TRANS_ORGANISMO = "ORG";
	static final String CLAVE_DELEXT_MOTIVO_TRANS_GIROS = "GIR";
	static final String CLAVE_DELEXT_MOTIVO_TRANS_OPERBANCO = "BCO";	
	
	// FACTURA
	static final String COD_TIPOREGVARIABLE_FACT = "F";
	static final String COD_TIPOREGVARIABLE_VARIABLE = "V";	
	
	// TC(S): P(MOD,ACT) [preauto]-> 1(FS==FC) [autotransferencia]-> C
	// TC(BCB):P(MOD,ACT,FC) [preauto]-> 1(FS==FC) [autotransferencia]-> C
	
	// TE(S): P(MOD,ACT) [operverificado]-> V [aprobar]-> D(ACT(FS)) [preauto]-> 1(FS==FC) [autotransferencia]-> C
	// TE(BCB): P(MOD,ACT,FC) [preauto]-> 1(FS==FC) [autotransferencia]-> C
	
	static final Character CLAVE_ESTSOLIC_PENDIENTE = 'P';
	static final Character CLAVE_ESTSOLIC_APROBADO = 'D';	//x aproba(D)o	
	static final Character CLAVE_ESTSOLIC_PREAUT = '1';
	static final Character CLAVE_ESTSOLIC_CONTAB = 'C';	
	static final Character CLAVE_ESTSOLIC_ANULADO = 'Z';
	//static final Character CLAVE_ESTSOLIC_AUTXSOLIC = 'A';	
	static final Character CLAVE_ESTSOLIC_VERIFICADO = 'V';
	
	static final Character CLAVE_ESTSOLIC_REGIS = 'R';	
	static final String CLAVE_ESTWS_PROCESADO = "P";	
	static final String CLAVE_ESTWS_AUTO = "A";	
	static final String CLAVE_ESTWS_NOTIF = "N";	
	static final String CLAVE_ESTWS_REVERT = "R";
	static final String CLAVE_ESTWS_PROV = "V";	
	static final String CLAVE_TIPOCOMIS_SOLIC = "S";
	static final String CLAVE_TIPOCOMIS_BENEF = "B";
	static final String CLAVE_CLACTA_COMTRANS = "CTA_COMTRANEXT";
	static final String CLAVE_CLACTA_VENTA = "CTA_DIFCAMBVDD";	
	static final String CLAVE_CLACTA_SWFT = "CTA_GASTOSCOM";	
	static final String CLAVE_CLACTA_UTIL = "CTA_UTILESESC";	
	static final String CLAVE_CLACTA_IVA = "CTA_DEBFISCAL";
	
	static final String CLAVE_TIPOFACT_ADM = "ADM";
	static final String CLAVE_TIPOFACT_CTRA = "CTRA";	
	static final String CLAVE_TIPOFACT_VDD = "VDD";	
	
	static final String CLAVE_ESTCOMP_AUT = "A";	
	static final String CLAVE_ESTCOMP_CONTAB = "C";	
	static final String CLAVE_ESTCOMP_PEND = "P";
	static final Integer CODESQ_DIFCAMB = 304;
	// remotitos
	static final String CLAVE_ESTSWIFT = "men_cveestswift";	
	static final String CLAVE_CONCEPTOFAC = "cve_conceptofac";	

	static final String CLAVE_TIPNEGOCIA_NORMAL = "N";
	static final String CLAVE_TIPNEGOCIA_OPER = "M";
	
	static final String PROP_BCB_KEY_STORE_FILE = "bcb.keystoreFile";
	static final String PROP_BCB_KEY_STORE_PASS = "bcb.keystorePass";
	static final String PROP_BCB_PRIVATE_KEY_ALIAS = "bcb.privateKeyAlias";
	static final String PROP_BCB_PRIVATE_KEY_PASS = "bcb.privateKeyPass";
	static final String PROP_BCB_CERTIFICATE_ALIAS = "bcb.certificateAlias";

	// cliente ws
	static final String WSDL_DIR_NAME = "wsdl";
	static final String FILE_NAME_WSDL_SIGEPAVISODEBITO = "mefpnotificadebito.wsdl";
	
	static final Integer SOL_TRANS_EXT_SIST_FIN = 61;
	
	static final String CVE_ESTBENEF_REG = "R";	
	static final String CVE_ESTBENEF_VERIF = "1";	
	static final String CVE_ESTBENEF_AUT = "A";	
	
	static final String CVE_TIPOCTAINST_CONINT = "I";
	static final String CVE_TIPOCTAINST_SININT = "D";	
	
	static final String CVE_TIPOBCOINST_BIC = "B";	
	static final String CVE_TIPOBCOINST_ABA = "F";	
	static final String CVE_TIPOBCOINST_INTER = "I";	
	
	static final String CVE_TCONCEPTO_VARIOS = "V";	
	static final String CVE_TCONCEPTO_REGALIAS = "RG";
	static final String CVE_TCONCEPTO_IDH = "IH";	
	static final Character CVE_TCONCEPTO_SUS = 'S';
	static final String CLA_OPERACION_ESTADISTICA_CLAVE = "cla_oprepest";
	static final String CVE_ESTADO_ESTADISTICA_CLAVE = "cve_estrepest";

	/******** lavado parametros ******/
	public static final String LAVADO_VERIFICA_LAVADO  = "verifica-lavado";
	public static final String PAR_LAVADO_VERIFICA  = "S";
	/**
	 * Resp 000 : exito en scaneo
	 */
	public static final String COD_RESP_EXITO = "000";	
	/**
	 * error 01: scaneo con registros positivos
	 */
	public static final String COD_RESP_ERR_01 = "E01";
	/**
	 * Error 02 :excepcion en proceso scaneo
	 */
	public static final String COD_RESP_ERR_02 = "E02";	
	/**
	 * direccion donde reside el servicio de lavado ej. http://swfapp.bcb.com:8881/swfadmapp/
	 */
	public static final String LAVADO_RESOURCE = "url-lavado";	
	/**
	 * url del servidor de verficación de OTP
	 */
	public static final String OTP_RESOURCE = "url-otp";	
	/******** lavado resources ******/
	public static final String PATH_RESOURCE_API_SEARCH = "/api/_search";
	public static final String PATH_RESOURCE_API_BIC = "/api/bic";	
	public static final String PATH_RESOURCE_API_PARAM = "/api/param";	
	public static final String PATH_RESOURCE_API_OFACLIST = "/api/ofaclist";	
	public static final String PATH_RESOURCE_API_LVD = "/api/swift";		
	
}
