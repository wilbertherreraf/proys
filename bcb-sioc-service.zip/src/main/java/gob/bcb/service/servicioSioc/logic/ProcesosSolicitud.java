package gob.bcb.service.servicioSioc.logic;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.SessionFactory;

import gob.bcb.bpm.pruebaCU.QueryProcessor;
import gob.bcb.bpm.pruebaCU.SocComprobante;
import gob.bcb.bpm.pruebaCU.SocComprobanteDao;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocDetallessolDao;
import gob.bcb.bpm.pruebaCU.SocEsquemas;
import gob.bcb.bpm.pruebaCU.SocEsquemasDao;
import gob.bcb.bpm.pruebaCU.SocHorarioDao;
import gob.bcb.bpm.pruebaCU.SocOpecomi;
import gob.bcb.bpm.pruebaCU.SocOpecomiDao;
import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.bpm.pruebaCU.SocSolicitanteDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudctas;
import gob.bcb.bpm.pruebaCU.SocSolicitudctasDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.SocSolicitudesDao;
import gob.bcb.bpm.pruebaCU.SocUsuariosolDao;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.mail.MsgLogic;
import gob.bcb.service.servicioSioc.wssigepclient.ClientSigepWSHandler;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;

/**
 * @author wherrera
 * 
 */
public class ProcesosSolicitud {
	private static final Log log = LogFactory.getLog(ProcesosSolicitud.class);
	private SocEsquemasDao socEsquemasDao = new SocEsquemasDao();
	private SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
	private SocDetallessolDao socDetallessolDao = new SocDetallessolDao();
	private CalcularVariables calcularVariables;
	private SocSolicitudctasDao socSolicitudctasDao = new SocSolicitudctasDao();
	private SocSolicitudesDao socSolicitudesDao = new SocSolicitudesDao();
	private SocOpecomiDao socOpecomiDao = new SocOpecomiDao();
	private SocComprobanteDao comprobanteDao = new SocComprobanteDao();
	private SocUsuariosolDao socUsuariosolDao = new SocUsuariosolDao();
	private SessionFactory sessionFactory;
	private SocHorarioDao socHorarioDao = new SocHorarioDao();

	public ProcesosSolicitud() {

	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
		inicializar();
	}

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public Solicitud recuperarSolicitudSimple(String socCodigo) {
		log.info("Entre a recuperarSolicitud con el id: [" + socCodigo + "] ");
		Solicitud solicitud = new Solicitud();

		SocSolicitudes solicitudOld = socSolicitudesDao.getSolicitud(socCodigo);

		if (solicitudOld == null) {
			log.error("Solicitud [" + socCodigo + "] inexistente");
			throw new BusinessException("Solicitud [" + socCodigo + "] inexistente");
		}

		solicitud.setSolicitud(solicitudOld);

		SocEsquemas socEsquemas = socEsquemasDao.esquemaByCod(solicitudOld.getEsqCodigo());

		solicitud.setSocEsquemas(socEsquemas);

		List<SocDetallessol> socDetallessolLista = socDetallessolDao.getDetalles(solicitudOld.getSocCodigo());
		solicitud.setSocDetallessolLista(socDetallessolLista);

		List<SocOpecomi> socOpecomiLista = socOpecomiDao
				.getOpeComisByDetCodClaComis(solicitud.getSolicitud().getSocCodigo(), null, null);
		solicitud.setSocOpecomiLista(socOpecomiLista);

		SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCod(solicitud.getSolicitud().getSolCodigo());
		solicitud.setSocSolicitante(socSolicitante);
		return solicitud;

	}

	public Solicitud modificaSolicitud(Solicitud solicitudTO) {
		// DETERminamos si se modifica la solicitud en campos
		if (solicitudTO.getCodPersonaAudit().equals(Constants.COD_BCB)) {
			log.info("Inicio : modificaSolicitud " + solicitudTO.getSolicitud().getSocCodigo());

			SocSolicitudes solicitudOld = socSolicitudesDao.getSolicitud(solicitudTO.getSolicitud().getSocCodigo());

			if (solicitudOld == null) {
				log.error("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
				throw new BusinessException(
						"Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
			}

			if (solicitudOld.getClaEstado().equals(Constants.CLAVE_ESTSOLIC_CONTAB)
					|| solicitudOld.getClaEstado().equals(Constants.CLAVE_ESTSOLIC_PREAUT)
					|| solicitudOld.getClaEstado().equals(Constants.CLAVE_ESTSOLIC_VERIFICADO)
					|| solicitudOld.getClaEstado().equals(Constants.CLAVE_ESTSOLIC_ANULADO)) {
				throw new BusinessException("Solicitud con estado invalido[" + solicitudOld.getClaEstado()
						+ "] no puede continuar " + solicitudTO.getSolicitud().getSocCodigo());
			}

			solicitudOld.setDetConcepto(solicitudTO.getSolicitud().getDetConcepto());
			solicitudOld.setUsrCodigo(solicitudTO.getCodUsuarioAudit());
			solicitudOld.setEstacion(solicitudTO.getCodEstacionAudit());

			socSolicitudesDao.getHibernateTemplate().saveOrUpdate(solicitudOld);

			log.info("solicitud modificada " + solicitudTO.getSolicitud().getSocCodigo());
		}

		return solicitudTO;
	}

	public Solicitud preAutorizarOperacionAutomatico(Solicitud solicitudTO) {
		// salvamos la fecha de operacion a hoy
		SocSolicitudes socSolicitudes = socSolicitudesDao.getSolicitud(solicitudTO.getSolicitud().getSocCodigo());

		if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRACTA)
				|| socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_ORDPAG)) {

			socSolicitudes.setFechaCont(new Date());
			socSolicitudes.setUsrCodigo(solicitudTO.getCodUsuarioAudit());
			socSolicitudes.setEstacion(solicitudTO.getCodEstacionAudit());

			socSolicitudesDao.saveOrUpdate(socSolicitudes);

			// actualizamos los datos de variables y generamos los compros
			calcularVariables.guardarVariablesSolicitud(solicitudTO, solicitudTO.getSolicitud().getFecha());

			comprobanteDao.procesarSolicitud(solicitudTO);

			comprobanteDao.controlComprobantes(solicitudTO);

			socSolicitudesDao.cambiarEstadoSolicitud(socSolicitudes, Constants.CLAVE_ESTSOLIC_PREAUT, null);

			QueryProcessor.flush();

			ContabilizarService contabilizarService = new ContabilizarService();
			contabilizarService.setSessionFactory(getSessionFactory());

			contabilizarService.autorizarComprobante(solicitudTO, null);
			contabilizarService.verificaSolicitud(solicitudTO);

			//notificarDebito(solicitudTO);
		}
		return solicitudTO;
	}

	/**
	 * Cambia de estado a pre autorizado, T locales(generados por el
	 * solicitante): PRE condicion= la solicitud debe estar en pendiente se
	 * actualiza la fecha solicitud
	 * 
	 * @param solicitudTO
	 * @return
	 */
	public Solicitud preAutorizar(Solicitud solicitudTO) {
		log.info("Inicio : pre autorizar fecha " + solicitudTO.getSolicitud().getSocCodigo() + " "
				+ solicitudTO.getCodUsuarioAudit());
		Date fecha = solicitudTO.getSolicitud().getFechaCont();

		SocSolicitudes solicitudOld = socSolicitudesDao.getSolicitud(solicitudTO.getSolicitud().getSocCodigo());

		if (solicitudOld == null) {
			log.error("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
			throw new BusinessException("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
		}

		if (solicitudOld.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)
				&& solicitudTO.getCodPersonaAudit().equals(Constants.COD_BCB)) {
			// si la transfeencia es al exterior y el usuario es del bcb se
			// controla que haya ingresado una fecha
			if (fecha == null) {
				log.error("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] sin fecha valor");
				throw new BusinessException(
						"Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] sin fecha valor");
			}

			solicitudOld.setFechaCont(fecha);
		}

		SocEsquemas socEsquemas = socEsquemasDao.esquemaByCod(solicitudOld.getEsqCodigo());
		socHorarioDao.controlHorario(solicitudTO, socEsquemas, "PRE");

		ActualizarAFecha actualizarAFecha = new ActualizarAFecha();
		actualizarAFecha.setSessionFactory(getSessionFactory());

		SwiftSiocService swiftSiocService = new SwiftSiocService();
		swiftSiocService.setSessionFactory(getSessionFactory());
		// actualizamos a fecha hoy para asegurar valores
		actualizarAFecha.actualizarAFecha(solicitudTO);

		swiftSiocService.preAutorizarSwift(solicitudTO);

		comprobanteDao.controlComprobantes(solicitudTO);

		// en usrcodreg se almacena el usr pre auto
		solicitudTO.getSolicitud().setUsrCodreg(solicitudTO.getCodUsuarioAudit());

		boolean esCartas = solicitudTO.getSolicitud().getClaTipo().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS) 
				|| solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS);
		
		if (solicitudTO.getCodPersonaAudit().equals(Constants.COD_BCB)) {
			// cambiamos el estado a preautorizado
			if (!solicitudTO.getSolicitud().getClaEstado().equals(Constants.CLAVE_ESTSOLIC_PENDIENTE)
					&& !solicitudTO.getSolicitud().getClaEstado().equals(Constants.CLAVE_ESTSOLIC_APROBADO)) {
				throw new BusinessException(
						"Solicitud con estado invalido [" + solicitudTO.getSolicitud().getClaEstado()
								+ "]no puede pre autorizar " + solicitudTO.getSolicitud().getSocCodigo());
			}
			solicitudOld = socSolicitudesDao.cambiarEstadoSolicitud(solicitudTO.getSolicitud(),
					Constants.CLAVE_ESTSOLIC_PREAUT, null);

			if (esCartas) {
				CartasCredService cartasCredService = new CartasCredService(getSessionFactory(), SiocCoinService.getSessionFactory());
				cartasCredService.preAutorizarEmisionCartascr(solicitudTO);
			}			
		} else {
			if (solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)) {
				if (!solicitudTO.getSolicitud().getClaEstado().equals(Constants.CLAVE_ESTSOLIC_PENDIENTE)) {
					throw new BusinessException(
							"Solicitud con estado invalido [" + solicitudTO.getSolicitud().getClaEstado()
									+ "]no puede pre autorizar " + solicitudTO.getSolicitud().getSocCodigo());
				}

				// cambiamos el estado a verificado
				solicitudOld = socSolicitudesDao.cambiarEstadoSolicitud(solicitudTO.getSolicitud(),
						Constants.CLAVE_ESTSOLIC_VERIFICADO, null);

				SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCod(solicitudOld.getSolCodigo());

				if (!solicitudOld.getSolCodigo().trim().equals(Constants.COD_BCB)
						&& socSolicitante.getClaEntidad().equals(Constants.CLAVE_CLAENTIDAD_SISTFINANCIERO)) {
					log.info("Generando correo de aviso de transferencia al exterior " + solicitudOld.getSocCodigo());

					String subject = "Registro de transferencia al exterior:" + solicitudOld.getSocCorrelativo();
					String content = MsgLogic.mensajeRegistroTransExtSistFin(solicitudOld, socSolicitante);

					socUsuariosolDao.formarMail("REGISTROTRANSEXTSISTFIN", subject, content, "'900'");
				}
			} else if (solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRACTA)) {
				// cambiamos el estado a preautorizado
				if (!solicitudTO.getSolicitud().getClaEstado().equals(Constants.CLAVE_ESTSOLIC_PENDIENTE)) {
					throw new BusinessException(
							"Solicitud con estado invalido [" + solicitudTO.getSolicitud().getClaEstado()
									+ "]no puede pre autorizar " + solicitudTO.getSolicitud().getSocCodigo());
				}

				if (solicitudTO.getSolicitud().getCveTipctasolic().equals(Constants.CLAVE_GENERADOPOR_SISTEMA)) {
					SocSolicitudctas socSolicitudctasMOVPROVISION = socSolicitudctasDao.getCuenta(
							solicitudOld.getSocCodigo(), Constants.COD_CLAVE_MOVPROVISION, null, null, null, null);
					log.info("NroCuenta MOVPROVISION: " + socSolicitudctasMOVPROVISION.getNroCuenta());

					if (socSolicitudctasMOVPROVISION.getNroCuenta().equals(Constants.CTA_TRANSIT_PROV)
							|| socSolicitudctasMOVPROVISION.getNroCuenta().equals(Constants.CTA_TRANSIT_SECPUBGOI)) {

						solicitudOld = socSolicitudesDao.cambiarEstadoSolicitud(solicitudTO.getSolicitud(),
								Constants.CLAVE_ESTSOLIC_VERIFICADO, null);

					} else {
						solicitudOld = socSolicitudesDao.cambiarEstadoSolicitud(solicitudTO.getSolicitud(),
								Constants.CLAVE_ESTSOLIC_PREAUT, null);
					}
				} else {
					solicitudOld = socSolicitudesDao.cambiarEstadoSolicitud(solicitudTO.getSolicitud(),
							Constants.CLAVE_ESTSOLIC_PREAUT, null);
				}

			} else if (solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_ORDPAG)) {
				// cambiamos el estado a preautorizado
				if (!solicitudTO.getSolicitud().getClaEstado().equals(Constants.CLAVE_ESTSOLIC_PENDIENTE)) {
					throw new BusinessException(
							"Solicitud con estado invalido [" + solicitudTO.getSolicitud().getClaEstado()
									+ "]no puede pre autorizar " + solicitudTO.getSolicitud().getSocCodigo());
				}

				solicitudOld = socSolicitudesDao.cambiarEstadoSolicitud(solicitudTO.getSolicitud(),
						Constants.CLAVE_ESTSOLIC_VERIFICADO, null);
				
			} else if (solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRADELEXT)) {
				if (!solicitudTO.getSolicitud().getClaEstado().equals(Constants.CLAVE_ESTSOLIC_PENDIENTE)) {
					throw new BusinessException(
							"Solicitud con estado invalido [" + solicitudTO.getSolicitud().getClaEstado()
									+ "]no puede pre autorizar " + solicitudTO.getSolicitud().getSocCodigo());
				}
				// cambiamos el estado a aprobado
				solicitudOld = socSolicitudesDao.cambiarEstadoSolicitud(solicitudTO.getSolicitud(),
						Constants.CLAVE_ESTSOLIC_APROBADO, null);

				SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCod(solicitudOld.getSolCodigo());

				if (!solicitudOld.getSolCodigo().trim().equals(Constants.COD_BCB)
						&& socSolicitante.getClaEntidad().equals(Constants.CLAVE_CLAENTIDAD_SISTFINANCIERO)) {
					log.info("Generando correo de aviso de transferencia DEL exterior " + solicitudOld.getSocCodigo());

					String subject = "Aviso de transferencia del exterior:" + solicitudOld.getSocCorrelativo();
					String content = MsgLogic.mensajeRegistroTransExtSistFin(solicitudOld, socSolicitante);

					socUsuariosolDao.formarMail("REGISTROTRANSEXTSISTFIN", subject, content, "'900'");					
				}
			}
		}

		solicitudTO.setSolicitud(solicitudOld);
		log.info("Solicitud " + solicitudTO.getSolicitud().getSocCodigo() + " ha sido PREAUTORIZADA, estado: "
				+ solicitudOld.getClaEstado());
		return solicitudTO;
	}
	
	public Solicitud autorizar(Solicitud solicitudTO) {
		log.info("=====oo [Inicio : autorizar] oo===== " + solicitudTO.getSolicitud().getSocCodigo());

		SocSolicitudes solicitudOld = socSolicitudesDao.getSolicitud(solicitudTO.getSolicitud().getSocCodigo());

		if (solicitudOld == null) {
			log.error("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
			throw new BusinessException("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
		}
		ContabilizarService contabilizarService = new ContabilizarService();
		contabilizarService.setSessionFactory(getSessionFactory());

		SocEsquemas socEsquemas = socEsquemasDao.esquemaByCod(solicitudOld.getEsqCodigo());
		socHorarioDao.controlHorario(solicitudTO, socEsquemas, "AUT");

		solicitudTO.setSolicitud(solicitudOld);

		boolean esCartas = solicitudTO.getSolicitud().getClaTipo().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS) 
				|| solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS);
		
		if (solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRACTA)) {

			//actualizarAFecha.actualizarAFecha(solicitudTO);
			// se realiza la operacion contable de transferencia
			if (!solicitudTO.getCodPersonaAudit().equals(Constants.COD_BCB)) {
				if (solicitudTO.getSolicitud().getCveTipctasolic().equals(Constants.CLAVE_GENERADOPOR_SISTEMA)) {
					SocSolicitudctas socSolicitudctasMOVPROVISION = socSolicitudctasDao.getCuenta(
							solicitudOld.getSocCodigo(), Constants.COD_CLAVE_MOVPROVISION, null, null, null, null);
					log.info("XXX: MMMMMM " + socSolicitudctasMOVPROVISION.getNroCuenta());
					if (socSolicitudctasMOVPROVISION.getNroCuenta().equals(Constants.CTA_TRANSIT_PROV)
							|| socSolicitudctasMOVPROVISION.getNroCuenta().equals(Constants.CTA_TRANSIT_SECPUBGOI)) {

						socSolicitudesDao.cambiarEstadoSolicitud(solicitudTO.getSolicitud(),
								Constants.CLAVE_ESTSOLIC_APROBADO, null);

						solicitudOld = socSolicitudesDao.getSolicitud(solicitudTO.getSolicitud().getSocCodigo());
						solicitudTO.setSolicitud(solicitudOld);
					}
				}
			}

			if (solicitudTO.getSolicitud().getClaEstado().equals(Constants.CLAVE_ESTSOLIC_PREAUT)) {
				contabilizarService.autorizarComprobante(solicitudTO, null);
				contabilizarService.verificaSolicitud(solicitudTO);
			}
		} else if (solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRADELEXT)) {
			if (solicitudTO.getCodPersonaAudit().equals(Constants.COD_BCB)) {
				//actualizarAFecha.actualizarAFecha(solicitudTO);
				// se realiza la operacion contable de transferencia
				contabilizarService.autorizarComprobante(solicitudTO, null);
				contabilizarService.verificaSolicitud(solicitudTO);
			}
		} else if (solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_ORDPAG)) {
			if (solicitudTO.getCodPersonaAudit().equals(Constants.COD_BCB)) {
				// si es uusario bcb
				// la soslicitud fue fenerada por el bcb
				if (!solicitudTO.getSolicitud().getClaEstado().equals(Constants.CLAVE_ESTSOLIC_PREAUT)) {
					throw new BusinessException(
							"Solicitud con estado invalido [" + solicitudTO.getSolicitud().getClaEstado()
									+ "]no puede autorizar " + solicitudTO.getSolicitud().getSocCodigo());
				}
				//actualizarAFecha.actualizarAFecha(solicitudTO);
				// se realiza la operacion contable de transferencia
				contabilizarService.autorizarComprobante(solicitudTO, null);
				contabilizarService.verificaSolicitud(solicitudTO);
			} else {
				// el usuario es el solicitante
				if (!solicitudTO.getSolicitud().getSolEntsolic().equals(solicitudTO.getCodPersonaAudit())) {
					throw new BusinessException(
							"Solicitud no fue generada por el solicitante [" + solicitudTO.getCodPersonaAudit()
									+ "]no puede pre autorizar " + solicitudTO.getSolicitud().getSocCodigo());
				}

				if (!solicitudTO.getSolicitud().getCveTipctasolic().equals(Constants.CLAVE_GENERADOPOR_SISTEMA)) {
					throw new BusinessException("Solicitud no fue creada por el solicitante ["
							+ solicitudTO.getSolicitud().getCveTipctasolic() + "]no puede pre autorizar "
							+ solicitudTO.getSolicitud().getSocCodigo());
				}

				if (!solicitudTO.getSolicitud().getClaEstado().equals(Constants.CLAVE_ESTSOLIC_VERIFICADO)) {
					throw new BusinessException(
							"Solicitud con estado invalido [" + solicitudTO.getSolicitud().getClaEstado()
									+ "]no puede pre autorizar " + solicitudTO.getSolicitud().getSocCodigo());
				}
				solicitudTO.getSolicitud().setUsrCodreg(solicitudTO.getCodUsuarioAudit());
				// cambiamos el estado a verificado
				socSolicitudesDao.cambiarEstadoSolicitud(solicitudTO.getSolicitud(), Constants.CLAVE_ESTSOLIC_APROBADO,
						null);
			}

		} else if (solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT) && !esCartas) {
			// CAMBIA de acuerdo al usuario que genera la operacion en el
			// cliente
			if (solicitudTO.getCodPersonaAudit().equals(Constants.COD_BCB)) {
				// si es uusario bcb
				// la soslicitud fue fenerada por el bcb
				if (!solicitudTO.getSolicitud().getClaEstado().equals(Constants.CLAVE_ESTSOLIC_PREAUT)) {
					throw new BusinessException(
							"Solicitud con estado invalido [" + solicitudTO.getSolicitud().getClaEstado()
									+ "]no puede autorizar " + solicitudTO.getSolicitud().getSocCodigo());
				}
				//actualizarAFecha.actualizarAFecha(solicitudTO);
				// se realiza la operacion contable de transferencia
				contabilizarService.autorizarComprobante(solicitudTO, null);
				contabilizarService.verificaSolicitud(solicitudTO);
			} else {
				// el usuario es el solicitante
				if (!solicitudTO.getSolicitud().getSolEntsolic().equals(solicitudTO.getCodPersonaAudit())) {
					throw new BusinessException(
							"Solicitud no fue generada por el solicitante [" + solicitudTO.getCodPersonaAudit()
									+ "]no puede pre autorizar " + solicitudTO.getSolicitud().getSocCodigo());
				}

				if (!solicitudTO.getSolicitud().getCveTipctasolic().equals(Constants.CLAVE_GENERADOPOR_SISTEMA)) {
					throw new BusinessException("Solicitud no fue creada por el solicitante ["
							+ solicitudTO.getSolicitud().getCveTipctasolic() + "]no puede pre autorizar "
							+ solicitudTO.getSolicitud().getSocCodigo());
				}

				if (!solicitudTO.getSolicitud().getClaEstado().equals(Constants.CLAVE_ESTSOLIC_VERIFICADO)) {
					throw new BusinessException(
							"Solicitud con estado invalido [" + solicitudTO.getSolicitud().getClaEstado()
									+ "]no puede pre autorizar " + solicitudTO.getSolicitud().getSocCodigo());
				}
				solicitudTO.getSolicitud().setUsrCodreg(solicitudTO.getCodUsuarioAudit());
				//actualizarAFecha.actualizarAFecha(solicitudTO);
				// se realiza la operacion contable de transferencia
				contabilizarService.autorizarComprobante(solicitudTO, null);
				// cambiamos el estado a aprobado
				socSolicitudesDao.cambiarEstadoSolicitud(solicitudTO.getSolicitud(), Constants.CLAVE_ESTSOLIC_APROBADO,
						null);

				if (socEsquemas.getTipoTransfer() != null
						&& socEsquemas.getTipoTransfer().equals(Constants.CLAVE_TIPOTRANSFER_CONPROV)) {
					SocSolicitante socSolicitante = socSolicitanteDao
							.solicitanteByCod(solicitudTO.getSolicitud().getSolCodigo());

					if (!solicitudOld.getSolCodigo().trim().equals(Constants.COD_BCB)
							&& socSolicitante.getClaEntidad().equals(Constants.CLAVE_CLAENTIDAD_SISTFINANCIERO)) {

						// se realiza la operacion contable de transferencia
						SocEsquemas socEsquemasPROV = socEsquemasDao.esquemaByCod(socEsquemas.getCodEsqref());

						// se contabiliza a fecha de recepcion
						SocComprobante socComprobante = comprobanteDao.generaComprobante(solicitudTO, socEsquemasPROV,
								0, Constants.CLAVE_TIPOESQ_PROV, null, null);

						if (socComprobante == null) {
							throw new BusinessException(
									"Comprobante " + socEsquemasPROV.getEsqCodigo() + " no creado !!!!");
						}

						// ######### PROVISIONAR#########
						contabilizarService.autorizarComprobante(solicitudTO, socComprobante.getCpbCodigo());
					}
				}
			}
		} else if (esCartas) {
			if (solicitudTO.getCodPersonaAudit().equals(Constants.COD_BCB)) {
				if (UtilsDate.compara(solicitudTO.getSolicitud().getFechaCont(), new Date()) != 0) {
					throw new BusinessException("Fecha de contabilización difiere a fecha actual, actualice los datos.");					
				}
				
				if (!solicitudTO.getSolicitud().getClaEstado().equals(Constants.CLAVE_ESTSOLIC_PREAUT)) {
					throw new BusinessException(
							"Solicitud con estado invalido [" + solicitudTO.getSolicitud().getClaEstado()
									+ "]no puede autorizar " + solicitudTO.getSolicitud().getSocCodigo());
				}
				CartasCredService cartasCredService = new CartasCredService(getSessionFactory(), SiocCoinService.getSessionFactory());
				cartasCredService.obtenerRegistroDetallePreautorizado(solicitudTO.getSolicitud().getSocCodigo());
				
				//actualizarAFecha.actualizarAFecha(solicitudTO);
				// se realiza la operacion contable de transferencia
				contabilizarService.autorizarComprobante(solicitudTO, null);
				contabilizarService.verificaSolicitud(solicitudTO);
			}						
		}

		return solicitudTO;
	}

	/**
	 * Rechaza la solicitud por el autorizador cambiando el estado para que el
	 * operador pueda modificar
	 * 
	 * @param solicitudTO
	 */
	public void rechazar(Solicitud solicitudTO) {
		log.info("Inicio : rechazar " + solicitudTO.getSolicitud().getSocCodigo());
		SocSolicitudes solicitudOld = socSolicitudesDao.getSolicitud(solicitudTO.getSolicitud().getSocCodigo());

		if (solicitudOld == null) {
			log.error("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
			throw new BusinessException("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
		}
		boolean esCartas = (solicitudTO.getSolicitud().getClaTipo().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS) 
				|| solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS));
		solicitudTO.setSolicitud(solicitudOld);

		if (solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRACTA)
				|| solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_ORDPAG)
				|| solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRADELEXT)) {

			if (!solicitudTO.getSolicitud().getClaEstado().equals(Constants.CLAVE_ESTSOLIC_PREAUT)) {
				throw new BusinessException(
						"Solicitud con estado invalido [" + solicitudTO.getSolicitud().getClaEstado()
								+ "]no puede rechazar " + solicitudTO.getSolicitud().getSocCodigo());
			}

			// cambiamos el estado a pendiente
			socSolicitudesDao.cambiarEstadoSolicitud(solicitudTO.getSolicitud(), Constants.CLAVE_ESTSOLIC_PENDIENTE,
					null);

		} else if (solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT) && !esCartas) {
			if (solicitudTO.getCodPersonaAudit().equals(Constants.COD_BCB)) {
				// si es uusario bcb
				if (solicitudTO.getSolicitud().getSolEntsolic().equals(Constants.COD_BCB)) {
					// la soslicitud fue fenerada por el bcb
					if (!solicitudTO.getSolicitud().getClaEstado().equals(Constants.CLAVE_ESTSOLIC_PREAUT)) {
						throw new BusinessException(
								"Solicitud con estado invalido [" + solicitudTO.getSolicitud().getClaEstado()
										+ "]no puede rechazar " + solicitudTO.getSolicitud().getSocCodigo());
					}
					// cambiamos el estado a pendiente
					socSolicitudesDao.cambiarEstadoSolicitud(solicitudTO.getSolicitud(),
							Constants.CLAVE_ESTSOLIC_PENDIENTE, null);

				} else {
					// no es una solicitud generada por el bcb
					if (!solicitudTO.getSolicitud().getClaEstado().equals(Constants.CLAVE_ESTSOLIC_PREAUT)) {
						throw new BusinessException(
								"Solicitud generada por [" + solicitudTO.getSolicitud().getSolEntsolic()
										+ "] con estado invalido [" + solicitudTO.getSolicitud().getClaEstado()
										+ "]no puede rechazar " + solicitudTO.getSolicitud().getSocCodigo());
					}
					// cambiamos el estado a aprobado
					socSolicitudesDao.cambiarEstadoSolicitud(solicitudTO.getSolicitud(),
							Constants.CLAVE_ESTSOLIC_APROBADO, null);
				}

			} else {
				// el usuario es el solicitante
				if (!solicitudTO.getSolicitud().getSolEntsolic().equals(solicitudTO.getCodPersonaAudit())) {
					throw new BusinessException(
							"Solicitud no fue generada por el solicitante [" + solicitudTO.getCodPersonaAudit()
									+ "]no puede continuar " + solicitudTO.getSolicitud().getSocCodigo());
				}

				if (!solicitudTO.getSolicitud().getCveTipctasolic().equals(Constants.CLAVE_GENERADOPOR_SISTEMA)) {
					throw new BusinessException("Solicitud no fue creada por el solicitante ["
							+ solicitudTO.getSolicitud().getCveTipctasolic() + "]no puede continuar "
							+ solicitudTO.getSolicitud().getSocCodigo());
				}

				if (!solicitudTO.getSolicitud().getClaEstado().equals(Constants.CLAVE_ESTSOLIC_VERIFICADO)) {
					throw new BusinessException(
							"Solicitud con estado invalido [" + solicitudTO.getSolicitud().getClaEstado()
									+ "]no puede continuar " + solicitudTO.getSolicitud().getSocCodigo());
				}

				// cambiamos el estado a pendiente
				socSolicitudesDao.cambiarEstadoSolicitud(solicitudTO.getSolicitud(), Constants.CLAVE_ESTSOLIC_PENDIENTE,
						null);
			}
		} else if (esCartas) {
			if (solicitudTO.getCodPersonaAudit().equals(Constants.COD_BCB)) {
				
				if (solicitudTO.getSolicitud().getSolEntsolic().equals(Constants.COD_BCB)) {
					if (!solicitudTO.getSolicitud().getClaEstado().equals(Constants.CLAVE_ESTSOLIC_PREAUT)) {
						throw new BusinessException(
								"Solicitud generada por [" + solicitudTO.getSolicitud().getSolEntsolic()
										+ "] con estado invalido [" + solicitudTO.getSolicitud().getClaEstado()
										+ "]no puede rechazar " + solicitudTO.getSolicitud().getSocCodigo());
					}
					// la soslicitud fue fenerada por el bcb
					// cambiamos el estado a pendiente
					socSolicitudesDao.cambiarEstadoSolicitud(solicitudTO.getSolicitud(),
							Constants.CLAVE_ESTSOLIC_PENDIENTE, null);

				} else {
					// no es una solicitud generada por el bcb
					// cambiamos el estado a aprobado
					socSolicitudesDao.cambiarEstadoSolicitud(solicitudTO.getSolicitud(),
							Constants.CLAVE_ESTSOLIC_APROBADO, null);
				}
				CartasCredService cartasCredService = new CartasCredService(getSessionFactory(), SiocCoinService.getSessionFactory());
				cartasCredService.rechazarCartascrdet(solicitudTO);				
			}
		}

		log.info("Fin proceso rechazar " + solicitudTO.getSolicitud().getSocCodigo());
	}

	public void anular(Solicitud solicitudTO) {
		log.info("Inicio : anular " + solicitudTO.getSolicitud().getSocCodigo());

		socSolicitudesDao.validarEstado(solicitudTO.getSolicitud().getSocCodigo(), true);
		SocSolicitudes solicitudOld = socSolicitudesDao.getSolicitud(solicitudTO.getSolicitud().getSocCodigo());

		solicitudTO.setSolicitud(solicitudOld);

		if (!solicitudTO.getCodPersonaAudit().equals(Constants.COD_BCB)) {
			if (!solicitudTO.getSolicitud().getSolCodigo().equals(solicitudTO.getCodPersonaAudit())) {
				throw new BusinessException("Solicitud no pertenece al solicitante [" + solicitudTO.getCodPersonaAudit()
						+ "]no puede continuar " + solicitudTO.getSolicitud().getSocCodigo());
			}

			if (!solicitudTO.getSolicitud().getSolEntsolic().equals(solicitudTO.getCodPersonaAudit())) {
				throw new BusinessException(
						"Solicitud no fue generada por el solicitante [" + solicitudTO.getCodPersonaAudit()
								+ "]no puede continuar " + solicitudTO.getSolicitud().getSocCodigo());
			}

			if (!solicitudTO.getSolicitud().getCveTipctasolic().equals(Constants.CLAVE_GENERADOPOR_SISTEMA)) {
				throw new BusinessException(
						"Solicitud no fue creada por el solicitante [" + solicitudTO.getSolicitud().getCveTipctasolic()
								+ "]no puede continuar " + solicitudTO.getSolicitud().getSocCodigo());
			}

			if (!solicitudTO.getSolicitud().getClaEstado().equals(Constants.CLAVE_ESTSOLIC_VERIFICADO)
					&& !solicitudTO.getSolicitud().getClaEstado().equals(Constants.CLAVE_ESTSOLIC_PENDIENTE)
					&& !solicitudTO.getSolicitud().getClaEstado().equals(Constants.CLAVE_ESTSOLIC_PREAUT)) {
				throw new BusinessException(
						"Solicitud con estado invalido [" + solicitudTO.getSolicitud().getClaEstado()
								+ "]no puede continuar " + solicitudTO.getSolicitud().getSocCodigo());
			}
		}

		String codSolorigen = solicitudTO.getSolicitud().getCodSolicitudorig();
		socSolicitudesDao.cambiarEstadoSolicitud(solicitudTO.getSolicitud(), Constants.CLAVE_ESTSOLIC_ANULADO, null);
		
		Boolean esCartas = (solicitudTO.getSolicitud().getClaTipo().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS)
				|| solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS));
		
		if (esCartas) {
			CartasCredService cartasCredService = new CartasCredService(getSessionFactory(), SiocCoinService.getSessionFactory());
			cartasCredService.suspenderCartascrdet(solicitudTO);			
		}
		
		if (solicitudOld.getClaEstadows() != null
				&& solicitudOld.getClaEstadows().equals(Constants.CLAVE_ESTWS_PROCESADO)
				&& solicitudOld.getCveTipctasolic().equals(Constants.CLAVE_GENERADOPOR_WS)) {
			// si esta en pendiente
			if (!StringUtils.isBlank(codSolorigen)) {
				String statusCode = "D002";
				String consent = "La solicitud fue rechazada por falta de fondos numero de solicitud " + codSolorigen;

				ClientSigepWSHandler clientSigepWSHandler = new ClientSigepWSHandler(getSessionFactory(), SiocCoinService.getSessionFactory());
				clientSigepWSHandler.rechazarSolicitud(codSolorigen, statusCode, consent, null);

				log.info("Solicitud SIGEP anulada " + codSolorigen);
			}
		}
		log.info("Solicitud anulada " + solicitudTO.getSolicitud().getSocCodigo());
	}

	public Solicitud notificarDebito(Solicitud solicitudIn) {
		log.info("notificarDebito Solicitud " + solicitudIn.getSolicitud().toString());

		Solicitud solicitudTO = recuperarSolicitudSimple(solicitudIn.getSolicitud().getSocCodigo());
		Boolean esCartas = (solicitudTO.getSolicitud().getClaTipo().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS)
				|| solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS));

		if (esCartas) {
			solicitudTO.setCarCartascrdet(solicitudIn.getCarCartascrdet());
		}
		
		if (!solicitudTO.getSolicitud().getCveTipctasolic().equals(Constants.CLAVE_GENERADOPOR_WS)) {
			if (esCartas) {
				// todas las solicitudes con carta se comunican al MEFP
			} else {
				return solicitudTO;				
			}
		}
		
		// ====== notificar ========
		if (!solicitudTO.getSolicitud().getClaEstado().equals(Constants.CLAVE_ESTSOLIC_CONTAB)) {
			log.error("Error solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] con estado invalido '"
					+ solicitudTO.getSolicitud().getClaEstado()
					+ "' requiere estar contabilizado, no se puede notificar");
			throw new BusinessException("Error solicitud [" + solicitudTO.getSolicitud().getSocCodigo()
					+ "] con estado invalido '" + solicitudTO.getSolicitud().getClaEstado()
					+ "' requiere estar contabilizado, no se puede notificar");
		}

		if (StringUtils.isBlank(solicitudTO.getSolicitud().getClaEstadows())) {
			// si la solicitud no fue autorizada
			log.error("Error solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] con estado nulo");
			throw new BusinessException(
					"Error solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] con estado nulo");
		}

		if (solicitudTO.getSolicitud().getClaEstadows().equals(Constants.CLAVE_ESTWS_NOTIF)
				|| solicitudTO.getSolicitud().getClaEstadows().equals(Constants.CLAVE_ESTWS_REVERT)) {
			// si la solicitud fue notificada o revertida
			log.error("Error solicitud [" + solicitudTO.getSolicitud().getSocCodigo()
					+ "] con estado invalido, posiblemente ya fue notificado");
			throw new BusinessException("Error solicitud [" + solicitudTO.getSolicitud().getSocCodigo()
					+ "] con estado invalido, posiblemente ya fue notificado");
		}

		if (StringUtils.isBlank(solicitudTO.getSolicitud().getCodSolicitudorig())) {
			if (!esCartas) {
				log.error("Error solicitud [" + solicitudTO.getSolicitud().getSocCodigo()
						+ "] con codigo de operacion del solicitante  invalido");
				throw new BusinessException("Error solicitud [" + solicitudTO.getSolicitud().getSocCodigo()
						+ "] con codigo de operacion del solicitante  invalido");
			}
		}

		List<SocSolicitudctas> socSolicitudctasLista = socSolicitudctasDao.getCuentas(solicitudTO.getSolicitud().getSocCodigo());
		solicitudTO.setSocSolicitudctasLista(socSolicitudctasLista);

		ClientSigepWSHandler clientSigepWSHandler = new ClientSigepWSHandler(getSessionFactory(), SiocCoinService.getSessionFactory());		
		clientSigepWSHandler.confirmacionDebito(solicitudTO, null);

		SocSolicitudes socSolicitudes = socSolicitudesDao.cambiarEstadoSolicitud(solicitudTO.getSolicitud(), null,
				Constants.CLAVE_ESTWS_NOTIF);
		solicitudTO.setSolicitud(socSolicitudes);
		log.info("Solicitud " + solicitudTO.getSolicitud().getSocCodigo() + " notificada");
		return solicitudTO;
	}

	public void procesarPendientesAuto(String opcion) {
		log.warn("Entrando a procesarPendientesAuto no implementado");
	}

	public void controlCompros(Solicitud solicitud) {
		comprobanteDao.controlComprobantes(solicitud);
	}

	public CalcularVariables calculoMontosSolicitud(Solicitud solicitud) {

		CalcularVariables calcularVariables = new CalcularVariables(getSessionFactory());

		SocSolicitudes socSolicitudes = solicitud.getSolicitud();

		if (StringUtils.isBlank(socSolicitudes.getSolCodigo()) || StringUtils.isBlank(socSolicitudes.getClaTipo())
				|| StringUtils.isBlank(socSolicitudes.getCveSubtipooper())
				|| StringUtils.isBlank(socSolicitudes.getTipoRetencion())
				|| (socSolicitudes.getEsqCodigo() == null || socSolicitudes.getEsqCodigo().compareTo(0) == 0)
				|| (socSolicitudes.getCodMoneda() == null) || (socSolicitudes.getCodMonedat() == null)
				|| (socSolicitudes.getSocMontome() == null
						|| socSolicitudes.getSocMontome().compareTo(BigDecimal.ZERO) <= 0)) {
			// no cumple con los requerimientos basicos
			return calcularVariables;
		}

		log.info("En calculoMontosSolicitud");
		calcularVariables.calcularVariablesSolicitud(solicitud.getSolicitud(), solicitud.getSocDetallessolLista(),
				solicitud.getSocSolicitudctasLista());

		return calcularVariables;
	}

	public void preAutorizarSolicitud(Solicitud solicitudTO) {
		log.info("Inicio : preAutorizarSolicitud pre autorizar fecha " + solicitudTO.getSolicitud().getSocCodigo() + " "
				+ solicitudTO.getCodUsuarioAudit());

		SocSolicitudes solicitudOld = socSolicitudesDao.getSolicitud(solicitudTO.getSolicitud().getSocCodigo());
		
		if (solicitudOld == null) {
			log.error("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
			throw new BusinessException("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
		}
		
		Date fecha = solicitudOld.getFechaCont();
		
		if (solicitudOld.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)
				&& solicitudTO.getCodPersonaAudit().equals(Constants.COD_BCB)) {
			// si la transfeencia es al exterior y el usuario es del bcb se
			// controla que haya ingresado una fecha
			if (fecha == null) {
				log.error("Solicitud [" + solicitudOld.getSocCodigo() + "] sin fecha valor");
				throw new BusinessException(
						"Solicitud [" + solicitudOld.getSocCodigo() + "] sin fecha valor");
			}
		}

		SocEsquemas socEsquemas = socEsquemasDao.esquemaByCod(solicitudOld.getEsqCodigo());
		socHorarioDao.controlHorario(solicitudTO, socEsquemas, "PRE");

		// en usrcodreg se almacena el usr pre auto
		solicitudTO.getSolicitud().setUsrCodreg(solicitudTO.getCodUsuarioAudit());

		boolean esCartas = solicitudOld.getClaTipo().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS) 
				|| solicitudOld.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS);
		
		if (solicitudTO.getCodPersonaAudit().equals(Constants.COD_BCB)) {
			// cambiamos el estado a preautorizado
			if (!solicitudOld.getClaEstado().equals(Constants.CLAVE_ESTSOLIC_PENDIENTE)
					&& !solicitudOld.getClaEstado().equals(Constants.CLAVE_ESTSOLIC_APROBADO)) {
				throw new BusinessException(
						"Solicitud con estado invalido [" + solicitudOld.getClaEstado()
								+ "]no puede pre autorizar " + solicitudOld.getSocCodigo());
			}
			solicitudOld = socSolicitudesDao.cambiarEstadoSolicitud(solicitudTO.getSolicitud(),
					Constants.CLAVE_ESTSOLIC_PREAUT, null);

			if (esCartas) {
				CartasCredService cartasCredService = new CartasCredService(getSessionFactory(), SiocCoinService.getSessionFactory());
				cartasCredService.preAutorizarEmisionCartascr(solicitudTO);
			}			
		} else {
			throw new BusinessException("Usuario: " + solicitudTO.getCodUsuarioAudit() + " pertecene a " + solicitudTO.getCodPersonaAudit() + " no habilitado para preautorizar mensajes swift." );			
		}
		log.info("Solicitud " + solicitudTO.getSolicitud().getSocCodigo() + " ha sido PREAUTORIZADA, estado: "
				+ solicitudOld.getClaEstado());
	}

	public void preAutorizarActFecha(Solicitud solicitudTO) {
		log.info("Inicio : pre autorizar Actualizar fecha " + solicitudTO.getSolicitud().getSocCodigo() + " "
				+ solicitudTO.getCodUsuarioAudit());
		Date fecha = solicitudTO.getSolicitud().getFechaCont();

		SocSolicitudes solicitudOld = socSolicitudesDao.getSolicitud(solicitudTO.getSolicitud().getSocCodigo());

		if (solicitudOld == null) {
			log.error("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
			throw new BusinessException("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
		}

		if (solicitudOld.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)
				&& solicitudTO.getCodPersonaAudit().equals(Constants.COD_BCB)) {
			// si la transfeencia es al exterior y el usuario es del bcb se
			// controla que haya ingresado una fecha
			if (fecha == null) {
				log.error("Solicitud [" + solicitudOld.getSocCodigo() + "] sin fecha valor");
				throw new BusinessException(
						"Solicitud [" + solicitudOld.getSocCodigo() + "] sin fecha valor");
			}
		}

		if (solicitudTO.getCodPersonaAudit().equals(Constants.COD_BCB)) {
			// cambiamos el estado a preautorizado
			if (!solicitudOld.getClaEstado().equals(Constants.CLAVE_ESTSOLIC_PENDIENTE)
					&& !solicitudOld.getClaEstado().equals(Constants.CLAVE_ESTSOLIC_APROBADO)) {
				throw new BusinessException(
						"Solicitud con estado invalido [" + solicitudOld.getClaEstado()
								+ "]no puede pre autorizar " + solicitudOld.getSocCodigo());
			}
		}
		
		SocEsquemas socEsquemas = socEsquemasDao.esquemaByCod(solicitudOld.getEsqCodigo());
		socHorarioDao.controlHorario(solicitudTO, socEsquemas, "PRE");

		ActualizarAFecha actualizarAFecha = new ActualizarAFecha();
		actualizarAFecha.setSessionFactory(getSessionFactory());

		// actualizamos a fecha hoy para asegurar valores
		actualizarAFecha.actualizarAFecha(solicitudTO);

		log.info("Solicitud " + solicitudOld.getSocCodigo() + " actualizada antes de PREAUTORIZAR");
	}
	
	public void inicializar() {
		socEsquemasDao.setSessionFactory(getSessionFactory());
		socSolicitanteDao.setSessionFactory(getSessionFactory());
		socDetallessolDao.setSessionFactory(getSessionFactory());
		calcularVariables = new CalcularVariables(getSessionFactory());
		socSolicitudctasDao.setSessionFactory(getSessionFactory());
		socSolicitudesDao.setSessionFactory(getSessionFactory());
		socOpecomiDao.setSessionFactory(getSessionFactory());
		comprobanteDao.setSessionFactory(getSessionFactory());
		socHorarioDao.setSessionFactory(getSessionFactory());
		socUsuariosolDao.setSessionFactory(getSessionFactory());

//		log.info("inicializado procesossoliidtu...");
	}
}
