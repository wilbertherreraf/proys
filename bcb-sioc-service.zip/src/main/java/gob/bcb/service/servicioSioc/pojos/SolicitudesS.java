package gob.bcb.service.servicioSioc.pojos;

import gob.bcb.bpm.pruebaCU.CarCartascr;
import gob.bcb.bpm.pruebaCU.CarCartascrdet;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;

import java.math.BigDecimal;
import java.util.Date;

public class SolicitudesS implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String socCodigo;
	private String solCodigo;
	private Integer esqCodigo;	
	private String codSolicitudorig;
	private String solicitante;
	private String claTipo;
	private String tipo;	
	private String cveSubtipooper;
	private String moneda;
	private String monedaDesc;
	private String monedaT;	
	private String monedaTDesc;
	private Character claEstado;
	private String claEstadoDesc;
	private String claEstadows;	
	private Date fecha;
	private Date fechaReg;	
	private BigDecimal socMontome;
	private BigDecimal socMontoord;
	private BigDecimal socMontomn;
	private String socCorrelativo;	
	private String concepto;
	private String solEntsolic;
	private String tipoRetencion;
	private String tipoTransfer;
	private String provisiona;
	private String detConcepto;
	private String detFacturas;
	private String glosa;
	private SocSolicitudes socSolicitudes; 
	private Boolean panel1;
	private Boolean panel2;
	private Boolean panel3;
	private CarCartascr carCartascr = new CarCartascr();
	private CarCartascrdet carCartascrdet = new CarCartascrdet();

	public SolicitudesS() {
	}

	public SolicitudesS(String socCodigo, String solCodigo, String solicitante, String claTipo, String moneda, Character claEstado, Date fecha,
			BigDecimal socMontome, String socCorrelativo, BigDecimal socMontoord, BigDecimal socMontomn, String concepto) {
		this.socCodigo = socCodigo;
		this.solCodigo = solCodigo;
		this.solicitante = solicitante;
		this.claTipo = claTipo;
		this.moneda = moneda;
		this.claEstado = claEstado;
		this.fecha = fecha;
		this.socMontome = socMontome;
		this.socCorrelativo = socCorrelativo;
		this.socMontoord = socMontoord;
		this.socMontomn = socMontomn;
		this.concepto = concepto;
	}

	
	public String getCveSubtipooper() {
		return cveSubtipooper;
	}

	public void setCveSubtipooper(String cveSubtipooper) {
		this.cveSubtipooper = cveSubtipooper;
	}

	public String getMonedaT() {
		return monedaT;
	}

	public void setMonedaT(String monedaT) {
		this.monedaT = monedaT;
	}

	public String getSolEntsolic() {
		return solEntsolic;
	}

	public void setSolEntsolic(String solEntsolic) {
		this.solEntsolic = solEntsolic;
	}

	public String getTipoRetencion() {
		return tipoRetencion;
	}

	public void setTipoRetencion(String tipoRetencion) {
		this.tipoRetencion = tipoRetencion;
	}

	public String getTipoTransfer() {
		return tipoTransfer;
	}

	public void setTipoTransfer(String tipoTransfer) {
		this.tipoTransfer = tipoTransfer;
	}

	public String getProvisiona() {
		return provisiona;
	}

	public void setProvisiona(String provisiona) {
		this.provisiona = provisiona;
	}

	public String getDetConcepto() {
		return detConcepto;
	}

	public void setDetConcepto(String detConcepto) {
		this.detConcepto = detConcepto;
	}

	public String getDetFacturas() {
		return detFacturas;
	}

	public void setDetFacturas(String detFacturas) {
		this.detFacturas = detFacturas;
	}

	public String getGlosa() {
		return glosa;
	}

	public void setGlosa(String glosa) {
		this.glosa = glosa;
	}

	public String getSocCodigo() {
		return socCodigo;
	}

	public void setSocCodigo(String socCodigo) {
		this.socCodigo = socCodigo;
	}

	public String getSolCodigo() {
		return solCodigo;
	}

	public void setSolCodigo(String solCodigo) {
		this.solCodigo = solCodigo;
	}

	public String getSolicitante() {
		return solicitante;
	}

	public void setSolicitante(String solicitante) {
		this.solicitante = solicitante;
	}

	public String getClaTipo() {
		return claTipo;
	}

	public void setClaTipo(String claTipo) {
		this.claTipo = claTipo;
	}

	public String getMoneda() {
		return moneda;
	}

	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	public Character getClaEstado() {
		return claEstado;
	}

	public void setClaEstado(Character claEstado) {
		this.claEstado = claEstado;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public BigDecimal getSocMontome() {
		return socMontome;
	}

	public void setSocMontome(BigDecimal socMontome) {
		this.socMontome = socMontome;
	}

	public String getSocCorrelativo() {
		return socCorrelativo;
	}

	public void setSocCorrelativo(String socCorrelativo) {
		this.socCorrelativo = socCorrelativo;
	}

	public BigDecimal getSocMontomn() {
		return socMontomn;
	}

	public void setSocMontomn(BigDecimal socMontomn) {
		this.socMontomn = socMontomn;
	}

	public BigDecimal getSocMontoord() {
		return socMontoord;
	}

	public void setSocMontoord(BigDecimal socMontoord) {
		this.socMontoord = socMontoord;
	}

	public String getConcepto() {
		return concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public Boolean getPanel1() {
		return panel1;
	}

	public void setPanel1(Boolean panel1) {
		this.panel1 = panel1;
	}

	public Boolean getPanel2() {
		return panel2;
	}

	public void setPanel2(Boolean panel2) {
		this.panel2 = panel2;
	}

	public Boolean getPanel3() {
		return panel3;
	}

	public void setPanel3(Boolean panel3) {
		this.panel3 = panel3;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public void setClaEstadoDesc(String claEstadoDesc) {
		this.claEstadoDesc = claEstadoDesc;
	}

	public String getClaEstadoDesc() {
		return claEstadoDesc;
	}

	public String getCodSolicitudorig() {
		return codSolicitudorig;
	}

	public void setCodSolicitudorig(String codSolicitudorig) {
		this.codSolicitudorig = codSolicitudorig;
	}

	public Date getFechaReg() {
		return fechaReg;
	}

	public void setFechaReg(Date fechaReg) {
		this.fechaReg = fechaReg;
	}

	public String getClaEstadows() {
		return claEstadows;
	}

	public void setClaEstadows(String claEstadows) {
		this.claEstadows = claEstadows;
	}

	public String getMonedaDesc() {
		return monedaDesc;
	}

	public void setMonedaDesc(String monedaDesc) {
		this.monedaDesc = monedaDesc;
	}

	public String getMonedaTDesc() {
		return monedaTDesc;
	}

	public void setMonedaTDesc(String monedaTDesc) {
		this.monedaTDesc = monedaTDesc;
	}

	public Integer getEsqCodigo() {
		return esqCodigo;
	}

	public void setEsqCodigo(Integer esqCodigo) {
		this.esqCodigo = esqCodigo;
	}

	public SocSolicitudes getSocSolicitudes() {
		return socSolicitudes;
	}

	public void setSocSolicitudes(SocSolicitudes socSolicitudes) {
		this.socSolicitudes = socSolicitudes;
	}

	public CarCartascr getCarCartascr() {
		return carCartascr;
	}

	public void setCarCartascr(CarCartascr carCartascr) {
		this.carCartascr = carCartascr;
	}

	public CarCartascrdet getCarCartascrdet() {
		return carCartascrdet;
	}

	public void setCarCartascrdet(CarCartascrdet carCartascrdet) {
		this.carCartascrdet = carCartascrdet;
	}
}
