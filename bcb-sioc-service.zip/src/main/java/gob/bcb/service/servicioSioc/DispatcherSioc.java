package gob.bcb.service.servicioSioc;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.xml.security.transforms.TransformationException;
import org.hibernate.HibernateException;
import org.hibernate.exception.GenericJDBCException;
import org.xml.sax.SAXException;

import gob.bcb.bpm.pruebaCU.FactoryDao;
import gob.bcb.bpm.pruebaCU.QueryProcessor;
import gob.bcb.bpm.pruebaCU.SocParametros;
import gob.bcb.bpm.pruebaCU.SocParametrosDao;
import gob.bcb.bpm.pruebaCU.SocUsuariosol;
import gob.bcb.bpm.pruebaCU.SocUsuariosolDao;
import gob.bcb.core.exception.DataBaseException;
import gob.bcb.core.exception.InternaException;
import gob.bcb.core.exception.VerificaException;
import gob.bcb.core.exception.WebServClientException;
import gob.bcb.core.jms.BcbRequest;
import gob.bcb.core.jms.BcbRequestImpl;
import gob.bcb.core.jms.BcbResponseImpl;
import gob.bcb.core.jms.ResponseContext;
import gob.bcb.core.jms.client.MessageObjectBean;
import gob.bcb.core.persist.EntityUserTransactionCoin;
import gob.bcb.core.persist.EntityUserTransactionPortia;
import gob.bcb.core.persist.EntityUserTransactionSioc;
import gob.bcb.core.utils.FirmaDigHelper;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.core.utils.UtilsFile;
import gob.bcb.core.utils.UtilsXML;
import gob.bcb.service.commons.ConfigurationServ;
import gob.bcb.service.commons.EmailDetalle;
import gob.bcb.service.commons.UserSessionHolder;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.logic.RegistrarSolicitud;
import gob.bcb.service.servicioSioc.mail.MsgLogic;
import gob.bcb.service.servicioSioc.ws.MensajeSiocTO;

/**
 * clase que controla variables de la sesion
 * 
 * @author wherrera
 * 
 */
public class DispatcherSioc {
	private static Logger log = Logger.getLogger(DispatcherSioc.class);
	private static Map<String, FactoryDao> factoryDaoMap;
	private MensajeSiocTO mensajeSiocTO;
	private boolean isMensajeDelWS = false;


	public void doService(BcbRequest bcbRequest, ResponseContext responseContext) {
		isMensajeDelWS = false;
		Map<String, Object> paramsResp = new HashMap<String, Object>();
		BcbRequestImpl bcbRequestImpl = (BcbRequestImpl) bcbRequest;
		log.info("::Mensaje recibido::"
				+ UtilsDate.stringFromDate(new Date(), Constants.FORMAT_DATE_TIME)
				+ " IP Origen: "
				+ ((bcbRequestImpl.getMsgbcb().getMsgcabecera().getIdemisor() != null) ? bcbRequestImpl.getMsgbcb().getMsgcabecera().getIdemisor()
						: "SIN IP") + " ID: " + bcbRequest.getMsgbcb().getMsgcabecera().getNrooperacion());
		String statusCode = Constants.OPERACION_RECEIVED;
		String consent = null;

		UserSessionHolder.set(null, null);

		String codOperacion = bcbRequestImpl.getIdTipoOperacion();
		if (codOperacion == null) {
			log.error("Codigo de tipo de operacion nulo");
			responseContext.updateReponse(gob.bcb.service.servicioSioc.common.Constants.SERVICE_EXCEPTION, "Codigo de tipo de operacion NULO");
			return;
		}

		String idsistema = bcbRequestImpl.getMsgbcb().getMsgcabecera().getIdsistema();

		log.info("Inicio proceso operacion con Tipo Operacion en mensaje: " + codOperacion + " idsistema " + idsistema);

		try {

			MessageObjectBean transformMessageBean = (MessageObjectBean) bcbRequestImpl.getBody();
			Map<String, Object> mapParametros = (Map<String, Object>) transformMessageBean.getTransformedMessage();
			if (mapParametros.containsKey("opcion")) {
				isMensajeDelWS = ((String) mapParametros.get("opcion")).equals("REG_SOLWS");
			}

			mapParametros.put(Constants.AUDIT_COD_TIPO_OPERACION, codOperacion);

			if (mapParametros.containsKey("jobname")) {
				// para operaciones automaticas o programadas
				log.info("tarea ejecutada por job: " + ((String) mapParametros.get("jobname")));
			}

			// ///////////////////////////////////
			// Seteo de valores de sesion de usuario
			UserSessionHolder.set("idsistema", idsistema);
			UserSessionHolder.set("nrooperacion", bcbRequest.getMsgbcb().getMsgcabecera().getNrooperacion());

			UserSessionHolder.set(Constants.AUDIT_USER_ESTACION, bcbRequest.getMsgbcb().getMsgcabecera().getIdemisor());
			mapParametros.put(Constants.AUDIT_USER_ESTACION, bcbRequest.getMsgbcb().getMsgcabecera().getIdemisor());

			UserSessionHolder.set(Constants.AUDIT_HORA_RECEPCION, (Date) responseContext.getBcbResponse().getReceivedDate());

			SocUsuariosolDao socUsuariosolDao = new SocUsuariosolDao();
			socUsuariosolDao.setSessionFactory(QueryProcessor.getSessionFactory());

			SocUsuariosol socUsuariosol = socUsuariosolDao.getUsuario(bcbRequest.getMsgbcb().getMsgcabecera().getIdusuario());
			if (socUsuariosol == null){
				throw new RuntimeException("USUARIO INEXISTENTE " + bcbRequest.getMsgbcb().getMsgcabecera().getIdusuario() + " inexistente en soc_usuariosol");
			}

			String usrCodemp = null;
			String usrCodpte = socUsuariosol.getSocUsuariosolPK().getSolCodigo().trim();
			
			if (socUsuariosol.getSocUsuariosolPK().getSolCodigo().trim().equals(Constants.COD_BCB)){
				mapParametros.put(Constants.AUDIT_USER_DATABASE_ID, bcbRequest.getMsgbcb().getMsgcabecera().getIdusuario().trim());
			} else {
				log.info("Usuario Externo logueado " + bcbRequest.getMsgbcb().getMsgcabecera().getIdusuario() + " entidad " + socUsuariosol.getSocUsuariosolPK().getSolCodigo()
						+ " usuario coin " + bcbRequest.getMsgbcb().getMsgcabecera().getIdusuario());
				SocParametrosDao socParametrosDao = new SocParametrosDao();
				socParametrosDao.setSessionFactory(QueryProcessor.getSessionFactory());
				
				SocParametros socParametros = socParametrosDao.getByCodigo(Constants.PARAM_USUARIO_CONT);
				
				mapParametros.put(Constants.AUDIT_USER_DATABASE_ID, socParametros.getParValor().trim());
			}
			
			UserSessionHolder.set(Constants.AUDIT_USER_SESSION_ID, bcbRequest.getMsgbcb().getMsgcabecera().getIdusuario());
			mapParametros.put(Constants.AUDIT_USER_SESSION_ID, bcbRequest.getMsgbcb().getMsgcabecera().getIdusuario());

			UserSessionHolder.set(Constants.COD_IFA_REQUEST, usrCodpte);
			mapParametros.put(Constants.COD_IFA_REQUEST, usrCodpte);

			if (isMensajeDelWS) {
				UserSessionHolder.set(Constants.COD_IFA_REQUEST, Constants.COD_IFA_MEFP);
				mapParametros.put(Constants.COD_IFA_REQUEST, Constants.COD_IFA_MEFP);
			}
			
			log.info("Usuario interno logueado " + mapParametros.get(Constants.AUDIT_USER_SESSION_ID) + " entidad " + mapParametros.get(Constants.COD_IFA_REQUEST)
					+ " usuario coin " + mapParametros.get(Constants.AUDIT_USER_DATABASE_ID));			
			// #######EXECUTE SERVICE BUSSINESS #####

			QueryProcessor procesador = new QueryProcessor();
			procesador.setResponseContext(responseContext);

			if (isMensajeDelWS) {
				if (!mapParametros.containsKey("mensajeXML")) {
					log.error("Error en la recepcion del mensaje del WS No existe el parametro 'mensajeXML' en el mensaje, avise a sistemas");
					throw new RuntimeException(
							"Error en la recepcion del mensaje del WS No existe el parametro 'mensajeXML' en el mensaje, avise a sistemas");
				}

				String mensajeXML = (String) mapParametros.get("mensajeXML");
				log.info("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
				String mensajeBO = UtilsXML.tagToString(mensajeXML, "servicio_sioc");
				mensajeSiocTO = new MensajeSiocTO();
				mensajeSiocTO.transformaXML(mensajeBO);

				String idMensaje = mensajeSiocTO.getRespuestaSioc().getCabeceraRespuesta().getIdMensaje();

				String pathFile = "";

				if (StringUtils.isBlank(idMensaje)) {
					throw new RuntimeException("Error: mensaje sin tag id_mensaje");
				} else {
					if (RegistrarSolicitud.operacionesProvision
							.contains(mensajeSiocTO.getRespuestaSioc().getCabeceraRespuesta().getCodTipoOperacion())) {

						pathFile = UtilsFile.grabaEnArchivo(mensajeXML, ConfigurationServ.getConfigurationHome() + "/mensajes/"
								+ mensajeSiocTO.getRespuestaSioc().getCabeceraRespuesta().getCodTipoOperacion() + "_" + idMensaje + "_I.xml");
						log.info("Archivo XML salvado en " + pathFile);
					}
				}

				// //////////////////////////////
				// validar fima
				FirmaDigHelper firmaDigHelper = new FirmaDigHelper();

				firmaDigHelper.verify(mensajeXML);

				// //////////////////////////////
				mapParametros.put("mensajeSiocTO", mensajeSiocTO);
				mapParametros.put(Constants.AUDIT_COD_TIPO_OPERACION, mensajeSiocTO.getRespuestaSioc().getCabeceraRespuesta().getCodTipoOperacion());
			}

			// ######################################
			procesador.procesar(mapParametros);

			// ######################################

			consent = responseContext.getBcbResponse().getMsgBcbresp().getMsgsistemaresp().getDescripcion();
			statusCode = responseContext.getBcbResponse().getMsgBcbresp().getMsgsistemaresp().getCodestadoresp();
		} catch (GenericJDBCException e) {
			log.error(e.getMessage(), e);
			StringBuilder sb = new StringBuilder();
			int count = 0;
			for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
				if (cause instanceof SQLException) {
					count++;
					sb.append(cause.getMessage());
					sb.append(" , ");
				}
			}
			consent = (count > 0 ? sb.toString().replace(", null ,", "") : e.getMessage().replace(", null ,", ""));
			statusCode = "R000";
			paramsResp.put("exception", e);
			paramsResp.put("exceptionmsg", consent);
			paramsResp.put("tipoerror", "DB");
		} catch (HibernateException e) {
			log.error("Persistencia: " + e.getMessage(), e);
			StringBuilder sb = new StringBuilder();
			int count = 0;
			for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
				if (cause instanceof SQLException) {
					count++;
					sb.append(cause.getMessage());
					sb.append(" , ");
				}
			}
			consent = (count > 0 ? sb.toString().replace(", null ,", "") : e.getMessage().replace(", null ,", ""));
			statusCode = "R000";
			paramsResp.put("exception", e);
			paramsResp.put("exceptionmsg", consent);
			paramsResp.put("tipoerror", "DB");
		} catch (NullPointerException e) {
			log.error(e.getMessage(), e);
			consent = "el sistema encontro algun valor nulo, verifique los datos";
			statusCode = "D001";
			paramsResp.put("exception", e);
			paramsResp.put("exceptionmsg", consent);
			paramsResp.put("tipoerror", "DB");
		} catch (BusinessException e) {
			log.error(e.getMessage(), e);
			consent = e.getMessage();
			statusCode = "D001";
			paramsResp.put("exception", e);
			paramsResp.put("exceptionmsg", consent);
			paramsResp.put("tipoerror", "BS");
		} catch (WebServClientException e) {
			log.error(e.getMessage(), e);
			consent = e.getMessage();
			statusCode = "M000";
			paramsResp.put("exception", e);
			paramsResp.put("exceptionmsg", consent);
			paramsResp.put("tipoerror", "WS");
		} catch (DataBaseException e) {
			log.error(e.getMessage(), e);
			StringBuilder sb = new StringBuilder();
			int count = 0;
			for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
				if (cause instanceof SQLException) {
					count++;
					sb.append(cause.getMessage());
					sb.append(" , ");
				}
			}
			consent = (count > 0 ? sb.toString().replace(", null ,", "") : e.getMessage().replace(", null ,", ""));
			statusCode = "R000";
			paramsResp.put("exception", e);
			paramsResp.put("exceptionmsg", consent);
			paramsResp.put("tipoerror", "DB");
		} catch (ParserConfigurationException e) {
			log.error(e.getMessage(), e);
			consent = e.getMessage();
			statusCode = "X001";
			paramsResp.put("exception", e);
			paramsResp.put("exceptionmsg", consent);
			paramsResp.put("tipoerror", "RT");
		} catch (SAXException e) {
			log.error(e.getMessage(), e);
			consent = e.getMessage();
			statusCode = "X002";
			paramsResp.put("exception", e);
			paramsResp.put("exceptionmsg", consent);
			paramsResp.put("tipoerror", "RT");
		} catch (IOException e) {
			log.error(e.getMessage(), e);
			consent = e.getMessage();
			statusCode = "R000";
			paramsResp.put("exception", e);
			paramsResp.put("exceptionmsg", consent);
			paramsResp.put("tipoerror", "RT");
		} catch (TransformerException e) {
			log.error(e.getMessage(), e);
			consent = e.getMessage();
			statusCode = "X004";
			paramsResp.put("exception", e);
			paramsResp.put("exceptionmsg", consent);
			paramsResp.put("tipoerror", "RT");
		} catch (InternaException e) {
			log.error(e.getMessage(), e);
			consent = e.getMessage();
			statusCode = "X003";
			paramsResp.put("exception", e);
			paramsResp.put("exceptionmsg", consent);
			paramsResp.put("tipoerror", "RT");
		} catch (VerificaException e) {
			log.error(e.getMessage(), e);
			consent = e.getMessage();
			statusCode = "V000";
			paramsResp.put("exception", e);
			paramsResp.put("exceptionmsg", consent);
			paramsResp.put("tipoerror", "RT");
		} catch (RuntimeException e) {
			log.error("RuntimeException: " + e.getMessage(), e);
			StringBuilder sb = new StringBuilder();
			int count = 0;
			for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
				if (cause instanceof SQLException) {
					count++;
					sb.append(cause.getMessage());
					sb.append(" , ");
				}
			}
			consent = (count > 0 ? sb.toString().replace(", null ,", "") : e.getMessage().replace(", null ,", ""));
			statusCode = (count > 0 ? Constants.DATABASE_EXCEPTION : Constants.RUNTIME_EXCEPTION);
			statusCode = "R000";
			paramsResp.put("exception", e);
			paramsResp.put("exceptionmsg", consent);
			paramsResp.put("tipoerror", "RT");
		} catch (Exception e) {
			log.error("Exception: " + e.getMessage(), e);
			StringBuilder sb = new StringBuilder();
			int count = 0;
			for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
				if (cause instanceof SQLException) {
					count++;
					sb.append(cause.getMessage());
					sb.append(" , ");
				}
			}
			consent = (count > 0 ? sb.toString().replace(", null ,", "") : "Error desconocido:" + e.getMessage().replace(", null ,", ""));
			statusCode = (count > 0 ? Constants.DATABASE_EXCEPTION : Constants.UNKNOWN_EXCEPTION);
			statusCode = "R000";
			paramsResp.put("exception", e);
			paramsResp.put("exceptionmsg", consent);
			paramsResp.put("tipoerror", "RT");
		} finally {
			// se verifica que no haya una transaccion anterior local
			log.info((String) paramsResp.get("tipoerror") + "-Tarea u operacion concluida con mensaje:" + statusCode + " : " + consent);
			try {
				if (!statusCode.equalsIgnoreCase(Constants.OPERACION_SUCCESS)) {
					if (UserSessionHolder.get("idsistema") == null
							|| (UserSessionHolder.get("idsistema") != null && !((String) UserSessionHolder.get("idsistema")).equals(Constants.CODAPP_SIOC))) {
						Throwable ex = (Throwable) paramsResp.get("exception");
						String tipo = (String) paramsResp.get("tipoerror");

						SocUsuariosolDao socUsuariosolDao = new SocUsuariosolDao();
						socUsuariosolDao.setSessionFactory(QueryProcessor.getSessionFactory());

						String subject = "SIOC AVISO ERROR: " + consent;
						String content = MsgLogic.mailException(ex, consent);

						EmailDetalle emailDetalle = socUsuariosolDao.formarMail("ERROREXCEPTION", subject, content, tipo);
						MsgMailListener.enviar(emailDetalle);
					}
				}
				rollbackEntityManager();
			} catch (Exception e) {
				// ocurre un error en el rollback por defecto no se hace nada
				log.error("Error en rollback " + e.getMessage(), e);
			}

			if (!bcbRequestImpl.isDisableReplyTo()) {

				if (!statusCode.equalsIgnoreCase(Constants.OPERACION_SUCCESS)) {
					// hubo un error y se actualiza la respuesta
					Throwable ex = (Throwable) paramsResp.get("exception");
					String tipo = (String) paramsResp.get("tipoerror");

					log.info("Tarea u operacion con ERROR:" + tipo + " isMensajeDelWS " + isMensajeDelWS);
					// /////////////////////////////////
					if (isMensajeDelWS) {
						if (mensajeSiocTO == null) {
							mensajeSiocTO = new MensajeSiocTO();
						}
						String respuesta = mensajeSiocTO.respuestaErrorXML(statusCode, consent);

						FirmaDigHelper firmaDigHelper = new FirmaDigHelper();

						String firmadito;
						try {
							firmadito = firmaDigHelper.sign(respuesta);
						} catch (TransformationException e1) {
							log.error("Error TransformationException al firmar respuesta " + e1.getMessage(), e1);
							firmadito = respuesta;
						} catch (Exception e1) {
							log.error("Error al firmar respuesta " + e1.getMessage(), e1);
							firmadito = respuesta;
						}

						Map<String, Object> mapaRespuesta = new HashMap<String, Object>();
						mapaRespuesta.put("mensajeXML", firmadito);

						MessageObjectBean messageObjectBean1 = new MessageObjectBean();
						messageObjectBean1.setTransformedMessage(mapaRespuesta);

						BcbResponseImpl bcbResponseImpl = (BcbResponseImpl) responseContext.getBcbResponse();
						bcbResponseImpl.setBody(messageObjectBean1);

						try {
							log.info("Devolviendo mapa Respuesta: " + mapaRespuesta);
							bcbResponseImpl.sendResponseBcbMsg(statusCode, consent);
						} catch (Exception e) {
							responseContext.getBcbResponse().getMsgBcbresp().getMsgsistemaresp().setCodestadoresp(Constants.RUNTIME_EXCEPTION);

							SocUsuariosolDao socUsuariosolDao = new SocUsuariosolDao();
							socUsuariosolDao.setSessionFactory(QueryProcessor.getSessionFactory());

							String subject = "SIOC AVISO ERROR: " + e.getMessage();
							String content = MsgLogic.mailException(e, e.getMessage());

							EmailDetalle emailDetalle = socUsuariosolDao.formarMail("ERROREXCEPTION", subject, content, "RT");

							MsgMailListener.enviar(emailDetalle);
							throw new RuntimeException("ERROR AL ACTUALIZAR RESPUESTA " + e.getMessage());
						}

					} else {
						responseContext.updateReponse(statusCode, consent);
					}
				}
			}
		}
		log.info("::Mensaje procesado::" + UtilsDate.stringFromDate(new Date(), Constants.FORMAT_DATE_TIME) + " IP Origen: "
				+ bcbRequestImpl.getMsgbcb().getMsgcabecera().getIdemisor() + " ID:" + bcbRequestImpl.getMsgbcb().getMsgcabecera().getNrooperacion());
		UserSessionHolder.set(null, null);
	}

	public void rollbackEntityManager() {
		EntityUserTransactionPortia.rollbackTransaction();
		EntityUserTransactionCoin.rollbackTransaction();
		EntityUserTransactionSioc.rollbackTransaction();

	}

	public static void setFactoryDaoMap(Map<String, FactoryDao> factoryDaoMap) {
		DispatcherSioc.factoryDaoMap = factoryDaoMap;
	}

	public static Map<String, FactoryDao> getFactoryDaoMap() {
		return factoryDaoMap;
	}
}
