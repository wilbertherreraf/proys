package gob.bcb.service.servicioSioc.pojos;

import java.math.BigDecimal;

public class OperacionesCambiarias {
	
	private String codInstitucion;
	private String institucion;
	private BigDecimal ventasDia;
	private BigDecimal ventasBolsin;
	private BigDecimal compras;
	private BigDecimal alExterior;
	private BigDecimal delExterior;
	
		
	public OperacionesCambiarias() {
		
	}

	public OperacionesCambiarias(String codInstitucion, String institucion,
			BigDecimal ventasDia, BigDecimal ventasBolsin, BigDecimal compras,
			BigDecimal alExterior, BigDecimal delExterior) {
		super();
		this.codInstitucion = codInstitucion;
		this.institucion = institucion;
		this.ventasDia = ventasDia;
		this.ventasBolsin = ventasBolsin;
		this.compras = compras;
		this.alExterior = alExterior;
		this.delExterior = delExterior;
	}


	public String getCodInstitucion() {
		return codInstitucion;
	}


	public void setCodInstitucion(String codInstitucion) {
		this.codInstitucion = codInstitucion;
	}


	public String getInstitucion() {
		return institucion;
	}


	public void setInstitucion(String institucion) {
		this.institucion = institucion;
	}


	public BigDecimal getVentasDia() {
		return ventasDia;
	}
	public void setVentasDia(BigDecimal ventasDia) {
		this.ventasDia = ventasDia;
	}
	public BigDecimal getVentasBolsin() {
		return ventasBolsin;
	}
	public void setVentasBolsin(BigDecimal ventasBolsin) {
		this.ventasBolsin = ventasBolsin;
	}
	public BigDecimal getCompras() {
		return compras;
	}
	public void setCompras(BigDecimal compras) {
		this.compras = compras;
	}
	public BigDecimal getAlExterior() {
		return alExterior;
	}
	public void setAlExterior(BigDecimal alExterior) {
		this.alExterior = alExterior;
	}
	public BigDecimal getDelExterior() {
		return delExterior;
	}
	public void setDelExterior(BigDecimal delExterior) {
		this.delExterior = delExterior;
	}



	
	public String toString() {
		return "OperacionesCambiarias [codInstitucion=" + codInstitucion
				+ ", institucion=" + institucion + ", ventasDia=" + ventasDia
				+ ", ventasBolsin=" + ventasBolsin + ", compras=" + compras
				+ ", alExterior=" + alExterior + ", delExterior=" + delExterior
				+ "]";
	}
		
}
