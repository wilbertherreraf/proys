package gob.bcb.service.servicioSioc;

import gob.bcb.service.servicioSioc.dao.SocSolicitudesDaoLocal;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service("serviceDao")
@Transactional(propagation = Propagation.REQUIRED)
public class ServiceDaoImpl implements ServiceDao{
	private static Logger log = Logger.getLogger(ServiceDaoImpl.class);

	@Autowired
	private SocSolicitudesDaoLocal socSolicitudesDaoLocal;
	
	public ServiceDaoImpl() {
		log.info("ServiceDaoImpl DAO creado ...");
	}
	public SocSolicitudesDaoLocal getSocSolicitudesDaoLocal() {
		return socSolicitudesDaoLocal;
	}
	public void setSocSolicitudesDaoLocal(SocSolicitudesDaoLocal socSolicitudesDaoLocal) {
		this.socSolicitudesDaoLocal = socSolicitudesDaoLocal;
	}

}
