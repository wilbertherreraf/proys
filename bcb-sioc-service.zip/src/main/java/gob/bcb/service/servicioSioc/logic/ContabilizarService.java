package gob.bcb.service.servicioSioc.logic;

import gob.bcb.bpm.pruebaCU.SocComprobante;
import gob.bcb.bpm.pruebaCU.SocComprobanteDao;
import gob.bcb.bpm.pruebaCU.SocEsquemas;
import gob.bcb.bpm.pruebaCU.SocEsquemasDao;
import gob.bcb.bpm.pruebaCU.SocFacturas;
import gob.bcb.bpm.pruebaCU.SocFacturasDao;
import gob.bcb.bpm.pruebaCU.SocOpecomi;
import gob.bcb.bpm.pruebaCU.SocOpecomiDao;
import gob.bcb.bpm.pruebaCU.SocOrdenesPago;
import gob.bcb.bpm.pruebaCU.SocOrdenesPagoDao;
import gob.bcb.bpm.pruebaCU.SocRengesq;
import gob.bcb.bpm.pruebaCU.SocRengesqDao;
import gob.bcb.bpm.pruebaCU.SocRengscomp;
import gob.bcb.bpm.pruebaCU.SocRengscompDao;
import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.bpm.pruebaCU.SocSolicitanteDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudesDao;
import gob.bcb.bpm.pruebaCU.SocUsuariosolDao;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.mail.MsgLogic;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class ContabilizarService extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(ContabilizarService.class);

	public Map<String, Object> autorizarComprobante(Solicitud solicitud, String cpbCodigo) {
		// tipoProceso = P proceso de provision; R en proceso de Retiro
		SocComprobanteDao comprobanteDao = new SocComprobanteDao();
		comprobanteDao.setSessionFactory(getSessionFactory());

		SocRengscompDao socRengscompDao = new SocRengscompDao();
		socRengscompDao.setSessionFactory(getSessionFactory());

		SocFacturasDao socFacturasDao = new SocFacturasDao();
		socFacturasDao.setSessionFactory(getSessionFactory());

		SocOrdenesPagoDao socOrdenesPagoDao = new SocOrdenesPagoDao();
		socOrdenesPagoDao.setSessionFactory(getSessionFactory());

		Map<String, Object> repuesta = new HashMap<String, Object>();

		log.info("Estoy en autorizarComprobante " + solicitud.getSolicitud().getSocCodigo() + " codorig: "
				+ solicitud.getSolicitud().getCodSolicitudorig());
		// transferencia en etapa de tranferencia
		// barremos todos los debitos segun comprobante
		// recuperamos los comprobantes de la operacion

		List<SocComprobante> socComprobanteListaPrep = new ArrayList<SocComprobante>();

		if (StringUtils.isBlank(cpbCodigo)) {
			socComprobanteListaPrep = comprobanteDao.comprobantesByOpeCodigo(solicitud.getSolicitud().getSocCodigo(), null, null, Constants.CLAVE_ESTCOMP_PEND, null, Constants.CLAVE_TIPOESQ_OPER,
					null);
		} else {
			SocComprobante comprobante = comprobanteDao.getComprobante(cpbCodigo);
			if (comprobante == null) {
				throw new BusinessException("Comprobante inexistente " + cpbCodigo);
			}
			socComprobanteListaPrep.add(comprobante);
		}
		
		if (socComprobanteListaPrep.size() == 0) {
			log.warn("Operacion " + solicitud.getSolicitud().getSocCodigo() + " sin comprobantes generados, con estado pendiente");
			//throw new BusinessException("Operacion " + solicitud.getSolicitud().getSocCodigo() + " sin comprobantes generados, con estado pendiente");
		}
		
		List<SocComprobante> socComprobanteLista = new ArrayList<SocComprobante>();

		for (SocComprobante socComprobante : socComprobanteListaPrep) {
			if (!socComprobante.getCveEstadocpb().equals(Constants.CLAVE_ESTCOMP_CONTAB)) {
				if (!StringUtils.isBlank(socComprobante.getCpbNrocpbte())) {
					throw new BusinessException("Inconsistencia!! Comprobante " + socComprobante.getCpbNrocpbte() + " en estado ["
							+ socComprobante.getCveEstadocpb() + "] con numero de Comprobante coin[" + socComprobante.getCpbNrocpbte()
							+ "] asignado, avise a sistemas ");
				}

				socComprobanteLista.add(socComprobante);
			}
		}

		if (socComprobanteLista.size() == 0) {
			log.warn("Operacion " + solicitud.getSolicitud().getSocCodigo() + " sin comprobantes generados, con estado pendiente");			
			//throw new BusinessException("Operacion " + solicitud.getSolicitud().getSocCodigo() + " sin comprobantes registrados, no puede continuar");
		}

		SiocCoinService siocCoinService = new SiocCoinService();

		List<Solicitud> solicitudLista = new ArrayList<Solicitud>();

		// verificacion de comprobantes
		comprobanteDao.controlComprobantes(solicitud);
		
		for (SocComprobante socComprobante : socComprobanteLista) {
			socComprobante.setUsrCodigo(solicitud.getCodUsuarioCont());
			socComprobante.setEstacion(solicitud.getCodEstacionAudit());
			
			Solicitud solicitudItem = new Solicitud();
			solicitudItem.setCodEstacionAudit(solicitud.getCodEstacionAudit());
			solicitudItem.setCodUsuarioAudit(solicitud.getCodUsuarioAudit());
			solicitudItem.setCodUsuarioCont(solicitud.getCodUsuarioCont());

			solicitudItem.setSolicitud(solicitud.getSolicitud());

			List<SocComprobante> socComprobanteL = new ArrayList<SocComprobante>();
			socComprobanteL.add(socComprobante);

			solicitudItem.setSocComprobanteLista(socComprobanteL);

			List<SocRengscomp> socRengscompLista = socRengscompDao.getRenglones(socComprobante.getCpbCodigo());
			List<SocFacturas> socFacturasLista = socFacturasDao.getFacturas(socComprobante.getCpbCodigo());
			List<SocOrdenesPago> socOrdenesPagoLista = socOrdenesPagoDao.getOrdenesByComprob(socComprobante.getCpbCodigo());

			solicitudItem.setSocRengscompLista(socRengscompLista);
			solicitudItem.setSocFacturasLista(socFacturasLista);
			solicitudItem.setSocOrdenesPagoLista(socOrdenesPagoLista);

			solicitudLista.add(solicitudItem);
		}

		// $$$$$$$$$$$ INICIO CONTA CONTBCB $$$$$$$$$
		if (solicitudLista.size() > 0){
			log.info("====OOOOOOOO0 [INICIO CONTABILIZACION] 0OOOOOOOO==== " + solicitud.getSolicitud().getSocCodigo());
			log.info("Usuario: " + solicitud.getCodUsuarioCont() + "; estacion: " + solicitud.getCodEstacionAudit());		
			siocCoinService.contabilizar(solicitudLista);
		}
		// $$$$$$$$$$$ FIN CONTA CONTBCB $$$$$$$$$

		SocOpecomiDao socOpecomiDao = new SocOpecomiDao();
		socOpecomiDao.setSessionFactory(getSessionFactory());
		
		for (Solicitud solicitud2 : solicitudLista) {
			log.info("Autorizado comprob: " + solicitud2.getSocComprobanteLista().get(0).getCpbNrocpbte() + " "
					+ solicitud2.getSocComprobanteLista().get(0).getCpbCodigo() + " " + solicitud2.getSocComprobanteLista().get(0).getCveEstadocpb());

			SocComprobante socComprobanteNew = solicitud2.getSocComprobanteLista().get(0);
			
			//List<SocRengscomp> socRengscompLista = socRengscompDao.getRenglones(socComprobanteNew.getCpbCodigo());
			List<SocRengscomp> socRengscompLista = solicitud2.getSocRengscompLista();
			
			for (SocRengscomp socRengscomp : socRengscompLista) {
				// actualizamos variables como contabilizados
				if (!StringUtils.isBlank(socRengscomp.getNomDatoadic()) ){
					
					Map<String, String> decodeMap = UtilsGeneric.paramsLista(socRengscomp.getNomDatoadic());
					
					String defMonto = decodeMap.get("DEFVAR");
					if (!StringUtils.isBlank(defMonto)) {
						SocOpecomi socOpecomi = socOpecomiDao.getOpeComisByDetCodClaCom(solicitud.getSolicitud().getSocCodigo(), socRengscomp.getDetCodigo(), defMonto);
					
						if (socOpecomi != null){
							socOpecomi.setClaEstadovar("C");
							socOpecomiDao.saveOrUpdate(socOpecomi);						
						} 
					}
					if (decodeMap.containsKey("RCONCSECRENG")) {
						this.getHibernateTemplate().saveOrUpdate(socRengscomp);
					}					
				}
			}
			if (solicitud2.getSocOrdenesPagoLista().size() > 0) {
				List<SocOrdenesPago> socOrdenesPagoLista = socOrdenesPagoDao.getOrdenesByComprob(socComprobanteNew.getCpbCodigo());
				
				for (SocOrdenesPago socOrdenesPago : socOrdenesPagoLista) {
					
					socOrdenesPago.setUsrCodigo(solicitud.getCodUsuarioAudit());
					socOrdenesPago.setEstacion(solicitud.getCodEstacionAudit());
					socOrdenesPago.setClaEstadoopa('P');
					
					this.getHibernateTemplate().saveOrUpdate(socOrdenesPago);
				}
			}
			socComprobanteNew.setUsrCodauto(solicitud.getCodUsuarioAudit());
			socComprobanteNew.setEstacion(solicitud.getCodEstacionAudit());
			socComprobanteNew.setFechaHora(new Date());
			this.getHibernateTemplate().merge(socComprobanteNew);
		}

		log.info("====OOOOOOOO0 [FIN CONTABILIZACION] 0OOOOOOOO==== " + solicitud.getSolicitud().getSocCodigo());		

		return repuesta;
	}

	public void verificaSolicitud(Solicitud solicitud) {
		log.info("VERIFICANDO SOLICITUD " + solicitud.getSolicitud().getSocCodigo());
		SocComprobanteDao comprobanteDao = new SocComprobanteDao();
		comprobanteDao.setSessionFactory(getSessionFactory());

		SocRengesqDao socRengesqDao = new SocRengesqDao();
		socRengesqDao.setSessionFactory(getSessionFactory());
		
		SocEsquemasDao socEsquemasDao = new SocEsquemasDao();
		socEsquemasDao.setSessionFactory(getSessionFactory());
		
		SocRengscompDao socRengscompDao = new SocRengscompDao();
		socRengscompDao.setSessionFactory(getSessionFactory());

		SocSolicitudesDao socSolicitudesDao = new SocSolicitudesDao();
		socSolicitudesDao.setSessionFactory(getSessionFactory());

		SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
		socSolicitanteDao.setSessionFactory(getSessionFactory());

		SocUsuariosolDao socUsuariosolDao = new SocUsuariosolDao();
		socUsuariosolDao.setSessionFactory(getSessionFactory());
		
		List<SocComprobante> socComprobanteLista = comprobanteDao.comprobantesByOpeCodigo(solicitud.getSolicitud().getSocCodigo(), null, null,
				"P,1,C", null, Constants.CLAVE_TIPOESQ_OPER, null);

		if (socComprobanteLista.size() > 0) {
			boolean existeSinContabilizar = false;
			Integer cpbNrocpbte = 0;
			for (SocComprobante socComprobante : socComprobanteLista) {
				cpbNrocpbte = null;
				if (!StringUtils.isBlank(socComprobante.getCpbNrocpbte())) {
					if (NumberUtils.isNumber(socComprobante.getCpbNrocpbte())) {
						cpbNrocpbte = Integer.valueOf(socComprobante.getCpbNrocpbte());
					}
				}
				if (cpbNrocpbte == null || cpbNrocpbte.compareTo(Integer.valueOf(0)) == 0) {
					log.warn("Solicitud con [" + solicitud.getSolicitud().getSocCodigo() + "] con comprobante [" + socComprobante.getCpbCodigo()
							+ "] sin numero de comprobante COIN asignado ");
					existeSinContabilizar = true;
					break;
				}
				if (!socComprobante.getCveEstadocpb().equals(Constants.CLAVE_ESTCOMP_CONTAB)) {
					log.warn("Comprobante no contabilizado " + socComprobante.getCpbCodigo());
					// hay comprobantes sin contabilizar o sin numero de
					// solicitud de respuesta lip
					existeSinContabilizar = true;
					break;
				}
			}

			List<SocRengesq> socRengesqLista = socRengesqDao.getRengsEsquema(solicitud.getSolicitud().getEsqCodigo());

			Map<Integer, SocEsquemas> mapaEsq = new HashMap<Integer, SocEsquemas>();
			Integer posi = 0;
			Integer codEsquema = 0;

			for (SocRengesq socRengesq : socRengesqLista) {
				if (!StringUtils.isBlank(socRengesq.getTipoCuenta()) && NumberUtils.isNumber(socRengesq.getTipoCuenta())) {
					codEsquema = Integer.valueOf(socRengesq.getTipoCuenta());
					log.info("Verif Esq TipoCuenta " + codEsquema);
					SocEsquemas socEsquemasPROV = socEsquemasDao.esquemaByCod(codEsquema);

					mapaEsq.put(posi, socEsquemasPROV);
					posi++;
				}
			}

			for (SocRengesq socRengesq : socRengesqLista) {
				if (!StringUtils.isBlank(socRengesq.getCtaDestorig()) && NumberUtils.isNumber(socRengesq.getCtaDestorig())) {
					codEsquema = Integer.valueOf(socRengesq.getCtaDestorig());

					log.info("Verif Esq CtaDestorig " + codEsquema);
					// si la fecha contable NO es igual a la fecha de
					// hoy
					// se verifica si el esq es de provision
					SocEsquemas socEsquemasPROV = socEsquemasDao.esquemaByCod(codEsquema);

					mapaEsq.put(posi, socEsquemasPROV);
					posi++;
				}
			}

			for (int i = 0; i < mapaEsq.size(); i++) {
				SocEsquemas socEsquemasCmp = mapaEsq.get(i);
				List<SocComprobante> lista = comprobanteDao.comprobantesByOpeCodigo(solicitud.getSolicitud().getSocCodigo(), 0, null,
						Constants.CLAVE_ESTCOMP_CONTAB, null, null, socEsquemasCmp.getEsqCodigo());

				if (lista.size() == 0) {
					// el esquema ya fue creado y contabilizado
					log.info("Comprob " + solicitud.getSolicitud().getSocCodigo() + " esq " + socEsquemasCmp.getEsqCodigo()
							+ " no fue contabilizado ");
					existeSinContabilizar = true;
					break;
				}
			}

			log.warn(solicitud.getSolicitud().getSocCodigo() + ": Existe solicitudes sin contabilizar? " + existeSinContabilizar);
			if (!existeSinContabilizar) {
				solicitud.getSolicitud().setUsrCodauto(solicitud.getCodUsuarioAudit());

				socSolicitudesDao.cambiarEstadoSolicitud(solicitud.getSolicitud(), Constants.CLAVE_ESTSOLIC_CONTAB, null);
				
				if (solicitud.getSolicitud().getClaTipo().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS) || solicitud.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS)) {
					CartasCredService cartasCredService = new CartasCredService(getSessionFactory(), SiocCoinService.getSessionFactory());
					cartasCredService.autorizarCartascrdetParaSolicitudAutorizada(solicitud);
				}
				
				SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCod(solicitud.getSolicitud().getSolCodigo());

				SocEsquemas socEsquemasPROV = socEsquemasDao.esquemaByCod(solicitud.getSolicitud().getEsqCodigo());

				log.info("Solicitud contabilizada " + solicitud.getSocCodigo());

				String subject = "Aviso Sioc: Solicitud TRANSFERIDA " + socSolicitante.getSigla() + ": [" + socEsquemasPROV.getCodTipoperacion()
						+ "] - " + solicitud.getSolicitud().getSocCodigo();

				String content = MsgLogic.textoSolicitud(solicitud, 0, null, null);

				socUsuariosolDao.formarMail("WSSOLICITUDPROCESADA", subject, content, "'900','" + solicitud.getSolicitud().getSolCodigo() + "'");
			} else {
				if (solicitud.getSolicitud().getClaTipo().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS) || solicitud.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS)) {
					throw new BusinessException("Solicitud de carta de credito no fue contabilizada ");
				}				
			}
		}
	}	
}
