
package gob.bcb.service.servicioSioc.wssigepclient.consultas;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the gob.bcb.service.servicioSioc.wssigepclient.consultas package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ConfirmarOperacionDivisas_QNAME = new QName("http://mefp.gob.bo/itg", "confirmarOperacionDivisas");
    private final static QName _TestConeccionResponse_QNAME = new QName("http://mefp.gob.bo/itg", "TestConeccionResponse");
    private final static QName _ConfirmarOperacionDivisasResponse_QNAME = new QName("http://mefp.gob.bo/itg", "confirmarOperacionDivisasResponse");
    private final static QName _TestConeccion_QNAME = new QName("http://mefp.gob.bo/itg", "TestConeccion");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: gob.bcb.service.servicioSioc.wssigepclient.consultas
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link TestConeccionResponse }
     * 
     */
    public TestConeccionResponse createTestConeccionResponse() {
        return new TestConeccionResponse();
    }

    /**
     * Create an instance of {@link TestConeccion }
     * 
     */
    public TestConeccion createTestConeccion() {
        return new TestConeccion();
    }

    /**
     * Create an instance of {@link ConfirmarOperacionDivisas }
     * 
     */
    public ConfirmarOperacionDivisas createConfirmarOperacionDivisas() {
        return new ConfirmarOperacionDivisas();
    }

    /**
     * Create an instance of {@link ConfirmarOperacionDivisasResponse }
     * 
     */
    public ConfirmarOperacionDivisasResponse createConfirmarOperacionDivisasResponse() {
        return new ConfirmarOperacionDivisasResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConfirmarOperacionDivisas }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://mefp.gob.bo/itg", name = "confirmarOperacionDivisas")
    public JAXBElement<ConfirmarOperacionDivisas> createConfirmarOperacionDivisas(ConfirmarOperacionDivisas value) {
        return new JAXBElement<ConfirmarOperacionDivisas>(_ConfirmarOperacionDivisas_QNAME, ConfirmarOperacionDivisas.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TestConeccionResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://mefp.gob.bo/itg", name = "TestConeccionResponse")
    public JAXBElement<TestConeccionResponse> createTestConeccionResponse(TestConeccionResponse value) {
        return new JAXBElement<TestConeccionResponse>(_TestConeccionResponse_QNAME, TestConeccionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConfirmarOperacionDivisasResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://mefp.gob.bo/itg", name = "confirmarOperacionDivisasResponse")
    public JAXBElement<ConfirmarOperacionDivisasResponse> createConfirmarOperacionDivisasResponse(ConfirmarOperacionDivisasResponse value) {
        return new JAXBElement<ConfirmarOperacionDivisasResponse>(_ConfirmarOperacionDivisasResponse_QNAME, ConfirmarOperacionDivisasResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TestConeccion }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://mefp.gob.bo/itg", name = "TestConeccion")
    public JAXBElement<TestConeccion> createTestConeccion(TestConeccion value) {
        return new JAXBElement<TestConeccion>(_TestConeccion_QNAME, TestConeccion.class, null, value);
    }

}
