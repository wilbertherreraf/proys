package gob.bcb.service.servicioSioc.logic;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.SessionFactory;

import gob.bcb.bpm.pruebaCU.Beneficiario;
import gob.bcb.bpm.pruebaCU.CuentasBen;
import gob.bcb.bpm.pruebaCU.GenMoneda;
import gob.bcb.bpm.pruebaCU.GenMonedaDao;
import gob.bcb.bpm.pruebaCU.QueryProcessor;
import gob.bcb.bpm.pruebaCU.SocBancosDao;
import gob.bcb.bpm.pruebaCU.SocBenefsDao;
import gob.bcb.bpm.pruebaCU.SocComprobante;
import gob.bcb.bpm.pruebaCU.SocComprobanteDao;
import gob.bcb.bpm.pruebaCU.SocCuentasloc;
import gob.bcb.bpm.pruebaCU.SocCuentaslocDao;
import gob.bcb.bpm.pruebaCU.SocCuentassol;
import gob.bcb.bpm.pruebaCU.SocCuentassolDao;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocDetallessolDao;
import gob.bcb.bpm.pruebaCU.SocEsquemas;
import gob.bcb.bpm.pruebaCU.SocFacturasDao;
import gob.bcb.bpm.pruebaCU.SocOpecomi;
import gob.bcb.bpm.pruebaCU.SocOpecomiDao;
import gob.bcb.bpm.pruebaCU.SocOrdenesPagoDao;
import gob.bcb.bpm.pruebaCU.SocParametros;
import gob.bcb.bpm.pruebaCU.SocParametrosDao;
import gob.bcb.bpm.pruebaCU.SocRengesq;
import gob.bcb.bpm.pruebaCU.SocRengesqDao;
import gob.bcb.bpm.pruebaCU.SocRengesqPK;
import gob.bcb.bpm.pruebaCU.SocRengscomp;
import gob.bcb.bpm.pruebaCU.SocRengscompDao;
import gob.bcb.bpm.pruebaCU.SocRengscompId;
import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.bpm.pruebaCU.SocSolicitanteDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudctas;
import gob.bcb.bpm.pruebaCU.SocSolicitudctasDao;
import gob.bcb.bpm.pruebaCU.SocValorescla;
import gob.bcb.bpm.pruebaCU.SocValoresclaDao;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.bpm.pruebaCU.UtilsSioc;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.pojos.BancoPlaza;
import gob.bcb.service.servicioSioc.pojos.CuentaS;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;
import gob.bcb.service.servicioTres.model.CuentaMovimientoDao;
import gob.bcb.service.servicioTres.model.RengConciliaDao;

public class RenglonesComprobantes {
	private static final Log log = LogFactory.getLog(RenglonesComprobantes.class);
	private SessionFactory sessionFactory;

	public List<SocRengscomp> crearRengscomp(Solicitud solicitud, Integer codDetalle, SocComprobante socComprobante, SocEsquemas socEsquemas,
			Map<String, Object> params) {
		log.info("Estoy en crearRenglones " + solicitud.getSolicitud().toString() + " esquema[" + socEsquemas.getEsqCodigo() + "] "
				+ socComprobante.toString());

		List<SocRengscomp> socRengscompLista = new ArrayList<SocRengscomp>();

		SocRengesqDao socRengesqDao = new SocRengesqDao();
		socRengesqDao.setSessionFactory(getSessionFactory());

		SocRengscompDao socRengscompDao = new SocRengscompDao();
		socRengscompDao.setSessionFactory(getSessionFactory());

		SocOrdenesPagoDao socOrdenesPagoDao = new SocOrdenesPagoDao();
		socOrdenesPagoDao.setSessionFactory(getSessionFactory());

		SocFacturasDao socFacturasDao = new SocFacturasDao();
		socFacturasDao.setSessionFactory(getSessionFactory());

		SocDetallessolDao socDetallessolDao = new SocDetallessolDao();
		socDetallessolDao.setSessionFactory(getSessionFactory());

		SocOpecomiDao socOpecomiDao = new SocOpecomiDao();
		socOpecomiDao.setSessionFactory(getSessionFactory());

		SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
		socCuentassolDao.setSessionFactory(getSessionFactory());
		/******************************/

		List<SocRengesq> socRengesqLista = new ArrayList<SocRengesq>();
		List<SocRengesq> socRengesqListaDDB = socRengesqDao.getRengsEsquema(socEsquemas.getEsqCodigo());
		socRengesqLista.addAll(socRengesqListaDDB);

		Integer nroRenglon = 0;
		Integer nroRenConCredito = 0;
		Integer nroRenSinCredito = 0;

		for (SocRengesq socRengesq : socRengesqLista) {
			SocRengscomp socRengscomp = null;
			if (socRengesq.getEsqDh().equals('H')) {
				if (socRengesq.getRepetible() != null && socRengesq.getRepetible().compareTo(1) == 0) {
					// datos de detalle
					// ciclo que barre todos los beneficiarios, si el
					// codidetalle es el todos
					List<SocDetallessol> socDetallessolLista = socDetallessolDao.getDetalles(solicitud.getSolicitud().getSocCodigo());

					for (SocDetallessol socDetallessol2 : socDetallessolLista) {
						socRengscomp = crearRenglon(solicitud, socComprobante, socRengesq, socDetallessol2, socDetallessol2.getId().getDetCodigo(),
								socEsquemas, nroRenglon, params);

						if (socRengscomp != null) {
							nroRenglon = socRengscomp.getId().getRenCodigo();
							socRengscompLista.add(socRengscomp);

							if (socRengesq.getClaCuenta().equalsIgnoreCase("ORDENESPAGO")
									&& !socComprobante.getCveDettipocomp().equalsIgnoreCase(Constants.CLAVE_TIPOESQ_OPER)) {

								log.info("Actuqlizando renglon orden de pago " + socComprobante.getCveDettipocomp() + " "
										+ socRengscomp.getClaDebehaber());

								socOrdenesPagoDao.actualizar(solicitud.getSolicitud(), socDetallessol2, "ACTRENG", nroRenglon,
										socRengscomp.getId().getCpbCodigo());
							}
						}
					}

					// se salta al siquiente renglon
					continue;
				}
			}

			socRengscomp = crearRenglon(solicitud, socComprobante, socRengesq, null, codDetalle, socEsquemas, nroRenglon, params);

			if (socRengscomp != null) {
				nroRenglon = socRengscomp.getId().getRenCodigo();
				socRengscompLista.add(socRengscomp);
			}
		}

		log.info("Salvando renglones " + socRengscompLista.size());
		if (socRengscompLista.size() > 0) {
			for (SocRengscomp socRengscomp : socRengscompLista) {
				socRengscompDao.saveOrUpdate(socRengscomp);
			}

			QueryProcessor.flush();
			List<SocRengscomp> renglones = socRengscompDao.getRenglones(socComprobante.getCpbCodigo());

			log.info("Renglones creados para solicitud [SocCodigo= " + socComprobante.getOpeCodigo() + ", socComprobante= "
					+ socComprobante.getCpbCodigo() + "] nro. renglones: " + renglones.size() + " esquema= " + socComprobante.getEsqCodigo());

			crearAjuste(solicitud, socComprobante, codDetalle, renglones, socComprobante.getCpbCodigo(), socEsquemas);

			nroRenConCredito = 0;
			nroRenSinCredito = 0;
			// creacion de facturas
			if (!socComprobante.getCveDettipocomp().equalsIgnoreCase(Constants.CLAVE_TIPOESQ_OPER)) {
				for (SocRengscomp socRengscomp : renglones) {
					// determinamos el renglon iva si hay
					if (socRengscomp.getDetCodigo().compareTo(Integer.valueOf(0)) == 0) {
						if (socRengscomp.getClaDebehaber() == 'H') {

							SocCuentassol socCuentassol = socCuentassolDao.getByAfectable(socRengscomp.getRenAfectable());

							if (!StringUtils.isBlank(socCuentassol.getClaCuenta())) {
								if (socCuentassol.getClaCuenta().equals(Constants.CLAVE_CLACTA_IVA)) {
									nroRenConCredito = socRengscomp.getId().getRenCodigo();
								} else if (socCuentassol.getClaCuenta().equals(Constants.CLAVE_CLACTA_VENTA)) {
									nroRenSinCredito = socRengscomp.getId().getRenCodigo();
								}
							}
						}
					}
				}

				if (nroRenSinCredito > 0 || nroRenConCredito > 0) {
					// creamos las factuiras
					log.info("Comprobante con facturas RenSinCredito:" + nroRenSinCredito + " RenConCredito:" + nroRenConCredito);
					for (SocRengscomp socRengscomp : renglones) {
						if (socRengscomp.getDetCodigo().compareTo(Integer.valueOf(0)) == 0) {
							if (socRengscomp.getClaDebehaber() == 'H') {
								SocCuentassol socCuentassol = socCuentassolDao.getByAfectable(socRengscomp.getRenAfectable());
								if (!StringUtils.isBlank(socCuentassol.getClaCuenta()) && !StringUtils.isBlank(socCuentassol.getCveImptiva())) {
									if (socCuentassol.getCveImptiva().equals("C") || socCuentassol.getCveImptiva().equals("S")) {
										// se verifica si la cuenta esta
										// marcada
										// con
										// imputacion iva Con credito (C)
										Map<String, String> decodeMap = UtilsGeneric.paramsLista(socRengscomp.getNomDatoadic());

										if (!decodeMap.containsKey("DEFVAR")) {
											throw new BusinessException(
													"Lo siento esto no deberia ocurrir: Renglon no registra codigo de variable, avise a sistemas "
															+ socRengscomp.getNomDatoadic());
										}

										String varClaComision = decodeMap.get("DEFVAR");

										if (socCuentassol.getCveImptiva().equals("C")) {
											if (nroRenConCredito > 0) {
												socFacturasDao.crearFactura(solicitud, socRengscomp, nroRenConCredito, varClaComision,
														socCuentassol.getClaCuenta(), socCuentassol.getCveImptiva());
											}
										}
										if (socCuentassol.getCveImptiva().equals("S")) {
											if (nroRenSinCredito > 0) {
												socFacturasDao.crearFactura(solicitud, socRengscomp, nroRenSinCredito, varClaComision,
														socCuentassol.getClaCuenta(), socCuentassol.getCveImptiva());
											}
										}
									}
								}
							}
						}
					}
				}
			}
			
			// actualizamos el nro esquema contbcb en comprobante
			QueryProcessor.flush();
			
			if (!socComprobante.getCveDettipocomp().equalsIgnoreCase(Constants.CLAVE_TIPOESQ_OPER)){
				SocComprobanteDao socComprobanteDao = new SocComprobanteDao();
				socComprobanteDao.setSessionFactory(getSessionFactory());
				
				String nroEsquemaContbcb = socComprobanteDao.obtenerNroEsquemaContbcb(socComprobante);
				socComprobante.setEsqCodesqcont(nroEsquemaContbcb);
				socComprobanteDao.saveOrUpdate(socComprobante);
				socComprobante = socComprobanteDao.getComprobante(socComprobante.getCpbCodigo());
				
			}
			return renglones;
		}

		return socRengscompLista;
	}

	private SocRengscomp crearRenglon(Solicitud solicitud, SocComprobante socComprobante, SocRengesq socRengesq, SocDetallessol socDetallessol,
			Integer codDetalle, SocEsquemas socEsquemas, Integer nroRenglon, Map<String, Object> params) {
		// codDetalle es el registro en opecomi

		log.info(socComprobante.getCpbCodigo() + " Estoy en crearRenglon [esq: " + socComprobante.getEsqCodigo() + " => "
				+ socComprobante.getCveDettipocomp() + "] Rengesq[" + socRengesq.getEsqDefinicion() + "] " + socRengesq.getClaCuenta());

		Map<String, Object> montoConvertido = obtenerMonto(solicitud, socComprobante, socRengesq, socDetallessol, codDetalle, params);

		CuentaS cuentaS = (CuentaS) montoConvertido.get("cuentaS");
		BigDecimal monto = (BigDecimal) montoConvertido.get("montomo");

		if (monto != null && monto.compareTo(BigDecimal.ZERO) > 0) {
			SocRengscomp socRengscomp = new SocRengscomp();

			SocRengscompId socRengscompId = new SocRengscompId(socComprobante.getCpbCodigo(), 0);
			socRengscomp.setId(socRengscompId);

			socRengscomp.setMoneda(cuentaS.getMoneda());
			socRengscomp.setRenAfectable(cuentaS.getCtaAfectable());
			socRengscomp.setRenMayor(cuentaS.getCtaMayor());
			// WHF 20170405 para conocer el codigo de esquema se agrega el nro
			// maory en cada renglon
			// para ello se reutiliza el campo sol_coddestorig
			socRengscomp.setSolCoddestorig(cuentaS.getCodMayor());
			socRengscomp.setCtaMovimiento(cuentaS.getCtaMovi());

			char dh = (Character) montoConvertido.get("dh");

			// por ahora util para determinar el tipo concepto del benef idh o
			// regalicas
			socRengscomp.setTipoTransfer(cuentaS.getCveTipcuenta());

			socRengscomp.setCtaDestorig(socRengesq.getCtaDestorig());

			socRengscomp.setRenMontomo(monto);

			BigDecimal renMontomn = (BigDecimal) montoConvertido.get("montobs");
			BigDecimal tipocambiomoxbs = (BigDecimal) montoConvertido.get("tipocambiomoxbs");

			socRengscomp.setRenMontomn(renMontomn);
			socRengscomp.setRenTipocambio(tipocambiomoxbs);
			socRengscomp.setClaDebehaber(dh);
			socRengscomp.setDetCodigo(codDetalle);

			String glosaRenglon = generarGlosa(solicitud, socRengesq.getClaGlosaR(), socDetallessol, params);

			socRengscomp.setRenGlosa(glosaRenglon);

			// cadena de variables para el concepto sigma
			CuentaMovimientoDao cuentaMovimientoDao = new CuentaMovimientoDao();
			cuentaMovimientoDao.setSessionFactory(SiocCoinService.getSessionFactory());

			if (socRengscomp.getClaDebehaber() == 'D') {
				Boolean afectSigma = cuentaMovimientoDao.IsAfectableSigma(socRengscomp.getRenAfectable());
				if (afectSigma) {
					// es afectable sigma
					Map<String, String> decodeMap = UtilsGeneric.paramsLista(socRengesq.getNomDatoadic());

					if (!decodeMap.containsKey("TIPOSIGMA")) {
						throw new BusinessException("Cuenta afectable " + socRengscomp.getRenAfectable()
								+ " con afectacion sigma, sin parametrizacion de TIPOSIGMA en esquema " + socRengesq.getId().getEsqCodigo() + ":"
								+ socRengesq.getClaCuenta());
					}
					String tipoSigma = "";
					if (socRengscomp.getClaDebehaber() == 'D') {
						// si es al debe se toma la variavle tiposigma
						tipoSigma = decodeMap.get("TIPOSIGMA");
					} else if (socRengscomp.getClaDebehaber() == 'H') {
						// si es al debe se toma la variavle tiposigmah
						if (!decodeMap.containsKey("TIPOSIGMAH")) {
							throw new BusinessException("Cuenta afectable " + socRengscomp.getRenAfectable()
									+ " con afectacion sigma, sin parametrizacion de TIPOSIGMAH en esquema " + socRengesq.getId().getEsqCodigo() + ":"
									+ socRengesq.getClaCuenta());
						}

						tipoSigma = decodeMap.get("TIPOSIGMAH");
					}
					String docSigma = valorVariable(solicitud, "@DOCSIGMA", null, params);
					socRengscomp.setNomDatoadic("TIPOSIGMA=" + tipoSigma + "&DOCSIGMA=" + docSigma);
				}
				// determinamos si es a cuenta acreedores
				if (!StringUtils.isBlank(cuentaS.getSocCuentassol().getClaCuenta())
						&& cuentaS.getSocCuentassol().getClaCuenta().equals(Constants.COD_CLAVE_CTAACREEDORES)) {
					// es renglon con afectacion de cuentas acreedores
					// se verifica que el registro exista en CONTBCB
					SocSolicitudctasDao socSolicitudctasDao = new SocSolicitudctasDao();
					socSolicitudctasDao.setSessionFactory(getSessionFactory());

					SocSolicitudctas socSolicitudctas = socSolicitudctasDao.getCuenta(solicitud.getSolicitud().getSocCodigo(),
							socRengesq.getClaCuenta(), null, null, null, null);

					if (socSolicitudctas == null) {
						throw new BusinessException("Cuenta afectable " + socRengscomp.getRenAfectable()
								+ " ACREEDORES, sin valores en socSolicitudctas, comunique al adm. " + socRengesq.getId().getEsqCodigo() + ":"
								+ socRengesq.getClaCuenta());
					}
					if (StringUtils.isBlank(socSolicitudctas.getNroCuentabco())) {
						throw new BusinessException("Cuenta afectable " + socRengscomp.getRenAfectable()
								+ " ACREEDORES, sin datos de Saldo Conciliable en campo NroCuentabco, " + socRengesq.getId().getEsqCodigo() + ":"
								+ socRengesq.getClaCuenta());
					}
					// formato nroconcilia-gestion-secconcilia-nrocomprobante :
					String[] nroLibreta = socSolicitudctas.getNroCuentabco().split("-");
					// asignamos el codigo concilia al renglon
					// el formato debe ser XXXXXX-XXXX-X si nocontiene los tres
					// elementos se emitir al gun error
					socRengscomp.setNomDatoadic("RCONCNROCON=" + nroLibreta[0] + "&RCONCGESTION=" + nroLibreta[1] + "&RCONCSECRENG=" + nroLibreta[2]);
				}
			}

			if (socRengscomp.getClaDebehaber() == 'H') {
				if (!StringUtils.isBlank(cuentaS.getSocCuentassol().getClaCuenta())
						&& cuentaS.getSocCuentassol().getClaCuenta().equals(Constants.COD_CLAVE_CTAACREEDORES)) {
					socRengscomp.setNomDatoadic("SALDOCONC=" + Constants.COD_CLAVE_CTAACREEDORES);
				}
			}

			List<String> codPartidas = cuentaMovimientoDao.partidaPresup(socRengscomp.getRenAfectable());
			if (codPartidas.size() > 0) {

				String codPartida = "";

				SocValoresclaDao socValoresclaDao = new SocValoresclaDao();
				socValoresclaDao.setSessionFactory(getSessionFactory());

				for (String string : codPartidas) {
					log.info("buscando partidita en cla_rengcp " + string);
					SocValorescla socValorescla = socValoresclaDao.getValoresByCodigo("cla_rengcp", string);
					if (socValorescla != null) {
						codPartida = socValorescla.getValNombre();
					}
				}

				if (StringUtils.isBlank(codPartida)) {
					throw new BusinessException("Cuenta afectable " + socRengscomp.getRenAfectable()
							+ " sin partida presup registrada en cla_rengcp, comunique al administrador ");
				}

				String[] cePe = codPartida.split("-");
				Integer cp = Integer.parseInt(cePe[0]);
				int rengCP = Integer.parseInt(cePe[1]);

				if (!StringUtils.isBlank(socRengscomp.getNomDatoadic())) {
					socRengscomp.setNomDatoadic(socRengscomp.getNomDatoadic() + "&PPTOCP=" + cp + "&PPTORENG=" + rengCP);
				} else {
					socRengscomp.setNomDatoadic("PPTOCP=" + cp + "&PPTORENG=" + rengCP);
				}
			}

			if (!StringUtils.isBlank(socRengscomp.getNomDatoadic())) {
				socRengscomp.setNomDatoadic(socRengscomp.getNomDatoadic() + "&DEFVAR=" + montoConvertido.get("defMonto"));
			} else {
				socRengscomp.setNomDatoadic("DEFVAR=" + montoConvertido.get("defMonto"));
			}
			nroRenglon++;
			socRengscomp.getId().setRenCodigo(nroRenglon);
			return socRengscomp;
		}

		log.info(
				"renglon NO creado por importe menor o igual a CERO " + socRengesq.toString() + ", SOLICTUD: " + solicitud.getSolicitud().toString());
		return null;
	}

	private CuentaS obtenerCuenta(Solicitud solicitud, SocComprobante socComprobante, SocRengesq socRengesq, String defCta,
			SocDetallessol socDetallessol, Integer monedaMO) {
		SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
		socCuentassolDao.setSessionFactory(getSessionFactory());

		SocSolicitudctasDao socSolicitudctasDao = new SocSolicitudctasDao();
		socSolicitudctasDao.setSessionFactory(getSessionFactory());
		log.info("Obteniendo cuenta " + defCta + " esq: " + socRengesq.getId().getEsqCodigo() + ":" + socRengesq.getId().getDetCodigo());
		CuentaS cta = new CuentaS();
		// String defCta = socRengesq.getClaCuenta();
		SocCuentassol socCuentassol = null;
		if (StringUtils.isBlank(defCta)) {
			throw new BusinessException(
					"Variable cuenta nulo, avise a sistemas " + socRengesq.getId().getEsqCodigo() + ":" + socRengesq.getId().getDetCodigo());
		}

		defCta = defCta.trim();
		boolean evaluado = false;
		if (defCta.equalsIgnoreCase("BENEFMT")) {
			if (socDetallessol == null) {
				throw new BusinessException("Error al obtener cuenta " + defCta + " valor parametro detalle nulo, avise a sistemas");
			}

			if (solicitud.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)) {
				// se verifica en el siguiente
			} else {
				evaluado = true;
				socCuentassol = socCuentassolDao.getByAfectable(socDetallessol.getNroCuentabcointer());
				if (socCuentassol != null) {
					if (solicitud.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRACTA)) {

						SocCuentaslocDao socCuentaslocDao = new SocCuentaslocDao();
						socCuentaslocDao.setSessionFactory(getSessionFactory());

						List<SocCuentasloc> socCuentaslocLista = socCuentaslocDao.cuentasBeneficiarioLoc(null, null, socDetallessol.getBenCodigo(),
								socDetallessol.getNroCuentabco(), null, socCuentassol.getCtaAfectable(), null);

						if (socCuentaslocLista.size() > 0) {
							// si existe la cuenta se verifica el concepto si es
							// regalias o idh
							SocCuentasloc socCuentasloc = socCuentaslocLista.get(0);
							if (!StringUtils.isBlank(socCuentasloc.getCveTconcepto())) {
								log.info("Operacion tconcepto: " + socCuentasloc.getCveTconcepto());
								if (socCuentasloc.getCveTconcepto().equals(Constants.CVE_TCONCEPTO_REGALIAS)) {
									// regalias
									cta.setCveTipcuenta(socCuentasloc.getCveTconcepto());
								} else if (socCuentasloc.getCveTconcepto().equals(Constants.CVE_TCONCEPTO_IDH)) {
									// IDH
									cta.setCveTipcuenta(socCuentasloc.getCveTconcepto());
								}

							}
						}
					}
				}
			}
		} else if (defCta.equalsIgnoreCase("ITFAFECT")) {
			// se busca por la cta afectable que esta en Comprobante.getGenera()
			evaluado = true;
			socCuentassol = socCuentassolDao.getByAfectable(socComprobante.getGenera());
		}

		if (!evaluado) {
			// cuentas registradas en la solicitud
			SocSolicitudctas socSolicitudctas = socSolicitudctasDao.getCuenta(solicitud.getSolicitud().getSocCodigo(), defCta, null, null, null,
					null);

			if (socSolicitudctas != null) {
				evaluado = true;
				socCuentassol = socCuentassolDao.getByCtaMovMoneda(socSolicitudctas.getNroCuenta(), socSolicitudctas.getCodMoneda());

			} else {
				// la cuenta deberia estar en soccuentassol
				evaluado = true;
				socCuentassol = socCuentassolDao.getByClaveCuenta(defCta, monedaMO);
			}
		}

		if (socCuentassol == null) {
			throw new RuntimeException("Cuenta inexistente " + defCta + " en soc_cuentassol");
		}

		Map<String, Object> mapaParametros3 = new HashMap<String, Object>();
		mapaParametros3.put("consulta", "mayor");
		mapaParametros3.put("movi", socCuentassol.getCtaMovimiento());

		SiocCoinService siocCoinService = new SiocCoinService();
		Map<String, Object> mapaResultado3 = siocCoinService.executeTask(mapaParametros3);
		String mayor = (String) mapaResultado3.get("mayor");
		String codMayor = (String) mapaResultado3.get("cod_mayor");

		cta.setCtaCodigo(socCuentassol.getCtaCodigo());
		cta.setCtaMovi(socCuentassol.getCtaMovimiento());
		cta.setClaVigente(socCuentassol.getClaVigente());
		cta.setMoneda(socCuentassol.getMoneda());
		cta.setCtaNommovimiento(socCuentassol.getCtaNommovimiento());
		cta.setCtaAfectable(socCuentassol.getCtaAfectable());
		cta.setSocCuentassol(socCuentassol);
		cta.setCtaMayor(mayor);
		cta.setCodMayor(codMayor);

		return cta;
	}

	private Map<String, Object> obtenerMonto(Solicitud solicitud, SocComprobante socComprobante, SocRengesq socRengesq, SocDetallessol socDetallessol,
			Integer codDetalle, Map<String, Object> parametros) {

		SocOpecomiDao socOpecomiDao = new SocOpecomiDao();
		socOpecomiDao.setSessionFactory(getSessionFactory());

		String defMonto = socRengesq.getEsqDefinicion();
		char dh = socRengesq.getEsqDh();
		BigDecimal monto = null;
		Integer monedaMO = 0;

		log.debug("Obteniendo valor " + defMonto + " - " + socRengesq.getClaCuenta());

		CuentaS cuentaS = null;
		boolean evaluado = false;
		// if (defMonto.equalsIgnoreCase("MONTOD")) {
		// evaluado = true;
		// if (socDetallessol == null) {
		// throw new BusinessException("Error al obtener monto " + defMonto +
		// " valor parametro detalle nulo, avise a sistemas");
		// }
		// monto = socDetallessol.getDetMontotrans();
		// monedaMO = solicitud.getSolicitud().getCodMonedat();
		// }

		if (!evaluado) {
			// se ingresa para buscar si se ha guardado
			SocOpecomi socOpecomi = socOpecomiDao.getOpeComisByDetCodClaCom(solicitud.getSolicitud().getSocCodigo(), codDetalle, defMonto);

			if (socOpecomi != null) {
				evaluado = true;
				monto = socOpecomi.getMontoMo();
				monedaMO = socOpecomi.getCodMoneda();

				if (defMonto.equalsIgnoreCase("DIFERTC")) {
					if (socOpecomi.getOcoMonto().compareTo(BigDecimal.ZERO) < 0) {
						// falta de fondos
						dh = 'D';
					} else if (socOpecomi.getOcoMonto().compareTo(BigDecimal.ZERO) > 0) {
						dh = 'H';
						// si es devolucion debe ser a la cta de MOVPROVISION
						// ya que devuelve dicho monto a la cta origen de la trx
						// cuentaS = obtenerCuenta(solicitud, socComprobante,
						// socRengesq, Constants.COD_CLAVE_MOVPROVISION, null,
						// monedaMO);
					}

				} else if (defMonto.equalsIgnoreCase("AJUSTEDC")) {
					// ajuste menor a 0.04 ctvs
					if (socOpecomi.getOcoMonto().compareTo(BigDecimal.ZERO) < 0) {
						dh = 'D';
					} else if (socOpecomi.getOcoMonto().compareTo(BigDecimal.ZERO) > 0) {
						dh = 'H';
					}
				}

			} else {
				// si no esta almacenado con la clave esta variables especiales
				// ITF por ejemplo
				socOpecomi = socOpecomiDao.getOpeComisByDetCodClaCom(solicitud.getSolicitud().getSocCodigo(), codDetalle,
						defMonto + "-" + socComprobante.getGenera());
				if (socOpecomi != null) {
					evaluado = true;
					monto = socOpecomi.getMontoMo();
					monedaMO = socOpecomi.getCodMoneda();

					if (defMonto.equalsIgnoreCase("ITFDIF")) {
						if (socOpecomi.getOcoMonto().compareTo(BigDecimal.ZERO) < 0) {
							dh = 'D';
						} else if (socOpecomi.getOcoMonto().compareTo(BigDecimal.ZERO) > 0) {
							dh = 'H';
						}
					}
				}

			}
		}

		if (monto == null)
			monto = BigDecimal.ZERO;

		if (monto.compareTo(BigDecimal.ZERO) <= 0)
			log.warn("Atencion!!!: monto RENGLON en solicitud[" + solicitud.getSolicitud().getSocCodigo() + "] CERO defMonto:" + defMonto + ", esq:"
					+ socComprobante.getEsqCodigo());

		Map<String, Object> montoConvertido = new HashMap<String, Object>();
		montoConvertido.put("montobs", BigDecimal.ZERO);
		montoConvertido.put("montomo", BigDecimal.ZERO);
		montoConvertido.put("monto", BigDecimal.ZERO);

		if (monto.compareTo(BigDecimal.valueOf(0.00)) > 0) {
			if (cuentaS == null)
				cuentaS = obtenerCuenta(solicitud, socComprobante, socRengesq, socRengesq.getClaCuenta(), socDetallessol, monedaMO);

			montoConvertido = UtilsSioc.conversion(monto, monedaMO, cuentaS.getMoneda(), socComprobante.getCpbFecha(), null, "C");

			BigDecimal montomo = (BigDecimal) montoConvertido.get("montomo");

			montoConvertido = UtilsSioc.conversion(montomo, cuentaS.getMoneda(), Constants.COD_MONEDA_BS, socComprobante.getCpbFecha(), null, "C");

			BigDecimal renMontomn = (BigDecimal) montoConvertido.get("montomo");
			montoConvertido.put("montobs", renMontomn);
			montoConvertido.put("montomo", montomo);

			montoConvertido.put("dh", dh);
			montoConvertido.put("cuentaS", cuentaS);
			montoConvertido.put("defMonto", defMonto);
		}
		log.info("Valor " + defMonto + " - " + socRengesq.getClaCuenta() + ":: " + montoConvertido.get("montomo"));
		return montoConvertido;

	}

	private void crearAjuste(Solicitud solicitud, SocComprobante socComprobante, Integer codDetalle, List<SocRengscomp> renglones, String idC,
			SocEsquemas socEsquemas) {

		SocRengscompDao socRengscompDao = new SocRengscompDao();
		socRengscompDao.setSessionFactory(getSessionFactory());

		log.info("Entrando a crear Ajuste comprobante [" + idC + "]");
		BigDecimal debe = BigDecimal.valueOf(0);
		BigDecimal haber = BigDecimal.valueOf(0);

		if (renglones == null) {
			log.error("No se registraron ningun renglon sobre el comprobante " + idC);
			throw new BusinessException("No se registraron ningun renglon sobre el comprobante " + idC);
		}
		if (renglones.size() == 0) {
			return;
		}
		for (SocRengscomp reng : renglones) {
			log.info(
					"{" + reng.getId().getRenCodigo() + "} :[" + reng.getClaDebehaber() + "] MO:(" + reng.getMoneda() + ", " + reng.getRenTipocambio()
							+ ") \t\t\t" + reng.getRenMontomo() + " \t\t:" + reng.getRenMontomn() + " \t\t[" + reng.getCtaMovimiento() + "]");
			if (reng.getClaDebehaber() == 'D') {
				debe = debe.add(reng.getRenMontomn());
			} else {
				haber = haber.add(reng.getRenMontomn());
			}
		}
		BigDecimal diff = debe.subtract(haber).setScale(2, BigDecimal.ROUND_HALF_UP);
		log.info("Crear Ajuste comprobante [" + idC + "] DEBE: " + debe.toPlainString() + ", HABER: " + haber.toPlainString() + " Diferencia: "
				+ diff.toPlainString());

		if (diff.compareTo(BigDecimal.valueOf(0.00)) == 0) {
			return;
		}

		if (diff.abs().compareTo(BigDecimal.valueOf(0.08)) > 0) {
			log.error("Diferencia mayor al permitido " + diff);
			return;
		}
		SocRengesqDao socRengesqDao = new SocRengesqDao();
		socRengesqDao.setSessionFactory(getSessionFactory());

		// creamos o actualizamos al variable de diferencial cambiario
		SocOpecomiDao socOpecomiDao = new SocOpecomiDao();
		socOpecomiDao.setSessionFactory(getSessionFactory());

		SocOpecomi socOpecomi = socOpecomiDao.nuevoRegistro(solicitud.getSolicitud().getSocCodigo(), codDetalle, "AJUSTEDC", diff, diff.abs(),
				Constants.COD_MONEDA_BS, null, null, null, null, "V", null);
		socOpecomi.setUsrCodigo(solicitud.getCodUsuarioAudit());
		socOpecomi.setEstacion(solicitud.getCodEstacionAudit());

		socOpecomiDao.getHibernateTemplate().merge(socOpecomi);

		solicitud.getSocOpecomiMap().put("AJUSTEDC", socOpecomi);

		SocRengesq socRengesq = new SocRengesq();
		SocRengesqPK socRengesqPK = new SocRengesqPK();
		socRengesqPK.setDetCodigo(0);
		socRengesq.setEsqDh('D');
		socRengesq.setId(socRengesqPK);
		socRengesq.setEsqDefinicion("AJUSTEDC");
		// socRengesq.setClaGlosaR("AJUSTE POR DIFERENCIAL CAMBIARIO");

		SocParametrosDao socParametrosDao = new SocParametrosDao();
		socParametrosDao.setSessionFactory(getSessionFactory());

		SocParametros socParametros = socParametrosDao.getByCodigo("ctvs-lim");

		String ctvsLim = socParametros.getParValor();
		BigDecimal ctvsLimConvert = UtilsGeneric.bigDecimalFromString(ctvsLim.trim());

		if (diff.abs().compareTo(ctvsLimConvert) <= 0) {
			socRengesq.setClaCuenta("@aju");
		} else if (diff.abs().compareTo(BigDecimal.valueOf(0.08)) <= 0) {
			// OJOOO SI ES MAYOR A 0.04 CTVS SE DEBITA DE LA CUENTA DIFCAMB
			socRengesq.setClaCuenta("DIFCAMB");

			List<SocRengesq> lista = socRengesqDao.obtenerEsquemaByDefinicion(solicitud.getSolicitud().getEsqCodigo(), null, null, null, "DIFCAMB");
			if (lista.size() == 0) {
				throw new BusinessException("Diferencial mayor al ajuste, con esquema contable " + solicitud.getSolicitud().getEsqCodigo()
						+ " sin registro de tipo cuenta DIFCAMB");
			}
			socRengesq.setClaGlosaR(lista.get(0).getClaGlosaR());
			socRengesq.setNomDatoadic(lista.get(0).getNomDatoadic());
		}

		SocRengscomp socRengscompDC = crearRenglon(solicitud, socComprobante, socRengesq, null, codDetalle, socEsquemas, renglones.size(), null);

		socRengscompDao.saveOrUpdate(socRengscompDC);
		renglones.add(socRengscompDC);
	}

	public String generarGlosa(Solicitud solicitud, String glosaDefinicion, SocDetallessol socDetallessol, Map<String, Object> paramsGlosa) {

		if (StringUtils.isBlank(glosaDefinicion)) {
			return glosaDefinicion;
		}
		String glosaGenerada = glosaDefinicion;
		Map<String, String> params = UtilsGeneric.valoresVar(glosaDefinicion);
		for (Iterator<?> i = params.keySet().iterator(); i.hasNext();) {
			String key = (String) i.next();
			String valorVar = valorVariable(solicitud, key, socDetallessol, paramsGlosa);
			valorVar = Matcher.quoteReplacement(valorVar);
			params.put(key, valorVar);
			glosaGenerada = glosaGenerada.replaceAll(key, valorVar);
		}
		log.debug("Glosa Renglon Definicion: " + glosaDefinicion + " = > " + glosaGenerada);
		return glosaGenerada;
	}

	private String valorVariable(Solicitud solicitud, String var, SocDetallessol socDetallessol, Map<String, Object> paramsGlosa) {
		String valor = "";

		if (StringUtils.isBlank(var) || var.trim().length() <= 1 || !var.trim().startsWith("@")) {
			return valor;
		}

		SocBenefsDao socBenefsDao = new SocBenefsDao();
		socBenefsDao.setSessionFactory(getSessionFactory());

		SocBancosDao socBancosDao = new SocBancosDao();
		socBancosDao.setSessionFactory(getSessionFactory());

		GenMonedaDao genMonedaDao = new GenMonedaDao();
		genMonedaDao.setSessionFactory(getSessionFactory());

		SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
		socSolicitanteDao.setSessionFactory(getSessionFactory());

		SocSolicitudctasDao socSolicitudctasDao = new SocSolicitudctasDao();
		socSolicitudctasDao.setSessionFactory(getSessionFactory());

		SocOpecomiDao socOpecomiDao = new SocOpecomiDao();
		socOpecomiDao.setSessionFactory(getSessionFactory());

		String varSinArroba = var.substring(1).toUpperCase();

		boolean evaluado = false;

		if (var.equalsIgnoreCase("@montoprovision")) {
			valor = UtilsGeneric.formatearMonto(solicitud.getSolicitud().getSocMontome());
			evaluado = true;
		} else if (var.equalsIgnoreCase("@CORRECITE")) {
			valor = StringUtils.trimToEmpty(solicitud.getSolicitud().getSocCorrelativo());
			if (!StringUtils.isBlank(solicitud.getSolicitud().getReferencia())) {
				valor = valor + " CITE: " + solicitud.getSolicitud().getReferencia();
			}
			if (!StringUtils.isBlank(valor)) {
				// mmmMMM!!!! asi quiere el area :(
				valor = " SEGUN SOLICITUD " + valor;
			}
			evaluado = true;
		} else if (var.equalsIgnoreCase("@monedaprovision")) {
			GenMoneda genMoneda = genMonedaDao.findByCodMoneda(solicitud.getSolicitud().getCodMoneda());
			valor = genMoneda.getMonSigla();
			evaluado = true;
		} else if (var.equalsIgnoreCase("@SOLICITANTE")) {
			SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCodigo(solicitud.getSolicitud().getSolCodigo());
			valor = socSolicitante.getSolPersona();
			evaluado = true;
		} else if (var.equalsIgnoreCase("@PORCITF")) {
			BigDecimal porcItf = (BigDecimal) paramsGlosa.get(var);
			valor = UtilsGeneric.formatearMonto(porcItf);
			evaluado = true;
		} else if (var.equalsIgnoreCase("@ITFMO")) {
			BigDecimal porcItf = (BigDecimal) paramsGlosa.get(var);
			valor = UtilsGeneric.formatearMonto(porcItf);
			evaluado = true;
		} else if (var.equalsIgnoreCase("@ITF")) {
			BigDecimal porcItf = (BigDecimal) paramsGlosa.get(var);
			valor = UtilsGeneric.formatearMonto(porcItf);
			evaluado = true;
		} else if (var.equalsIgnoreCase("@GLOSASOL")) {
			valor = solicitud.getSolicitud().getDetConcepto();
			evaluado = true;
		} else if (var.equalsIgnoreCase("@INFOSOL")) {
			valor = solicitud.getSolicitud().getDetFacturas();
			evaluado = true;
		} else if (var.equalsIgnoreCase("@FECHASOL")) {
			valor = UtilsDate.stringFromDate(solicitud.getSolicitud().getFecha(), "dd/MM/yyyy");
			evaluado = true;
		} else if (var.equalsIgnoreCase("@monedatrans")) {
			GenMoneda genMoneda = genMonedaDao.findByCodMoneda(solicitud.getSolicitud().getCodMonedat());
			valor = genMoneda.getMonSigla();
			evaluado = true;
		} else if (var.equalsIgnoreCase("@NROMEFP")) {
			valor = solicitud.getSolicitud().getCodSolicitudorig();
			evaluado = true;
		} else if (var.equalsIgnoreCase("@DOCSIGMA")) {
			valor = solicitud.getSolicitud().getCodSolicitudorig();
			if (StringUtils.isBlank(valor)) {
				valor = "@NROCOMPROBANTE";
			}
			evaluado = true;
		} else if (var.equalsIgnoreCase("@VENTAUSD")) {
			evaluado = true;
			SocOpecomi socOpecomi = socOpecomiDao.getOpeComisByDetCodClaCom(solicitud.getSolicitud().getSocCodigo(), 0, Constants.COD_VAR_VENTAUSD);
			if (socOpecomi != null)
				valor = UtilsGeneric.formatearMonto(socOpecomi.getMontoMo());
		}

		if (!evaluado) {
			if (socDetallessol != null) {
				if (var.equalsIgnoreCase("@NOMBENEF")) {
					evaluado = true;
					Beneficiario beneficiario = socBenefsDao.recuperarBeneficiario(solicitud.getSolicitud(), socDetallessol);
					if (beneficiario != null)
						valor = beneficiario.getBenNombre();

				} else if (var.equalsIgnoreCase("@monedadet")) {
					GenMoneda genMoneda = genMonedaDao.findByCodMoneda(socDetallessol.getCodMoneda());
					valor = genMoneda.getMonSigla();
					evaluado = true;

				} else if (var.equalsIgnoreCase("@CUENTABEN")) {
					evaluado = true;
					String nomBenef = "";
					Beneficiario beneficiario = socBenefsDao.recuperarBeneficiario(solicitud.getSolicitud(), socDetallessol);
					if (beneficiario != null)
						nomBenef = beneficiario.getBenNombre();

					if (solicitud.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)) {
						valor = StringUtils.trimToEmpty(socDetallessol.getNroCuentabco());
						BancoPlaza bancoPlaza = socBancosDao.bancoPlazaByCod(socDetallessol.getCodBanco());
						if (bancoPlaza == null) {
							throw new RuntimeException("Datos de banco inexistente: " + socDetallessol.getCodBanco() + ", detalle: "
									+ socDetallessol.getId().getDetCodigo());
						}
						valor = nomBenef + ", CTA. " + valor + " " + StringUtils.trimToEmpty(bancoPlaza.getBcoNombre()) + " "
								+ StringUtils.trimToEmpty(bancoPlaza.getPlaNombre());

					} else {
						valor = StringUtils.trimToEmpty(socDetallessol.getNroCuentabco());
						valor = valor + " " + nomBenef;
					}

				} else if (var.equalsIgnoreCase("@BANCOBEN")) {
					evaluado = true;
					if (solicitud.getSolicitud().getClaTipo().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)) {
						BancoPlaza bancoPlaza = socBancosDao.bancoPlazaByCod(socDetallessol.getCodBanco());
						if (bancoPlaza == null) {
							throw new RuntimeException("Datos de banco inexistente: " + socDetallessol.getCodBanco() + ", detalle: "
									+ socDetallessol.getId().getDetCodigo());
						}

						valor = bancoPlaza.getBcoNombre();
					}
				} else if (var.equalsIgnoreCase("@plaza")) {
					evaluado = true;
					if (solicitud.getSolicitud().getClaTipo().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)) {
						BancoPlaza bancoPlaza = socBancosDao.bancoPlazaByCod(socDetallessol.getCodBanco());
						if (bancoPlaza == null) {
							throw new RuntimeException("Datos de banco inexistente: " + socDetallessol.getCodBanco() + ", detalle: "
									+ socDetallessol.getId().getDetCodigo());
						}

						valor = bancoPlaza.getPlaNombre();
					}
				} else if (var.equalsIgnoreCase("@NROCTALIBBEN")) {
					evaluado = true;
					valor = StringUtils.trimToEmpty(socDetallessol.getNroCuentabco());
					if (!StringUtils.isBlank(valor) && !StringUtils.isBlank(socDetallessol.getNroCuentabcointer())) {
						List<CuentasBen> listaCuentasB = socBenefsDao.recuperarCuentasB(solicitud.getSolicitud(), socDetallessol.getBenCodigo(), null,
								null, socDetallessol.getNroCuentabco(), null, socDetallessol.getNroCuentabcointer());
						if (listaCuentasB.size() == 1) {
							SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCodigo(listaCuentasB.get(0).getBcoCodigo());
							valor = "LIB. " + StringUtils.trimToEmpty(socDetallessol.getNroCuentabco());
							if (socSolicitante != null) {
								if (socSolicitante.getClaEntidad().equals(Constants.CLAVE_CLAENTIDAD_SISTFINANCIERO)) {
									valor = "CTA. " + StringUtils.trimToEmpty(socDetallessol.getNroCuentabco());
								}
							}
							valor = valor + " " + StringUtils.trimToEmpty(listaCuentasB.get(0).getCtaNombre());
						}
					}
				}
			}
		}

		if (!evaluado) {
			// si se encuentra en variables
			SocOpecomi socOpecomi = socOpecomiDao.getOpeComisByDetCodClaCom(solicitud.getSolicitud().getSocCodigo(), 0, varSinArroba);
			if (socOpecomi != null) {
				evaluado = true;
				valor = UtilsGeneric.formatearMonto(socOpecomi.getMontoMo());
			} else {
				if (var.equalsIgnoreCase("@nitctra")) {
					evaluado = true;
					socOpecomi = socOpecomiDao.getOpeComisByDetCodClaCom(solicitud.getSolicitud().getSocCodigo(), 0, "CTRA");
					if (socOpecomi != null)
						valor = socOpecomi.getNit();
				} else if (var.equalsIgnoreCase("@factctra")) {
					evaluado = true;
					socOpecomi = socOpecomiDao.getOpeComisByDetCodClaCom(solicitud.getSolicitud().getSocCodigo(), 0, "CTRA");
					if (socOpecomi != null)
						valor = socOpecomi.getFactura();
				} else if (var.equalsIgnoreCase("@nitvdd")) {
					evaluado = true;
					socOpecomi = socOpecomiDao.getOpeComisByDetCodClaCom(solicitud.getSolicitud().getSocCodigo(), 0, "VDD");
					if (socOpecomi != null)
						valor = socOpecomi.getNit();
				} else if (var.equalsIgnoreCase("@factvdd")) {
					evaluado = true;
					socOpecomi = socOpecomiDao.getOpeComisByDetCodClaCom(solicitud.getSolicitud().getSocCodigo(), 0, "VDD");
					if (socOpecomi != null)
						valor = socOpecomi.getFactura();
				} else if (var.equalsIgnoreCase("@nitadm") || var.equalsIgnoreCase("@nitswift") || var.equalsIgnoreCase("@nitutil")) {
					evaluado = true;
					socOpecomi = socOpecomiDao.getOpeComisByDetCodClaCom(solicitud.getSolicitud().getSocCodigo(), 0, "ADM");
					if (socOpecomi != null)
						valor = socOpecomi.getNit();
				} else if (var.equalsIgnoreCase("@factadm") || var.equalsIgnoreCase("@factswift") || var.equalsIgnoreCase("@factutil")) {
					evaluado = true;
					socOpecomi = socOpecomiDao.getOpeComisByDetCodClaCom(solicitud.getSolicitud().getSocCodigo(), 0, "ADM");
					if (socOpecomi != null)
						valor = socOpecomi.getFactura();
				}
			}
		}

		if (!evaluado) {
			if (var.startsWith("@CTALIB-")) {
				String tipoCuenta = var.substring("@CTALIB-".length());
				SocSolicitudctas socSolicitudctas = socSolicitudctasDao.getCuenta(solicitud.getSolicitud().getSocCodigo(), tipoCuenta, null, null,
						null, null);

				if (socSolicitudctas != null && !StringUtils.isBlank(socSolicitudctas.getNroLibreta())) {
					SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCodigo(socSolicitudctas.getSolCodigo());
					String tipoCta = "LIB. ";
					if (socSolicitante != null) {
						if (socSolicitante.getClaEntidad().equals(Constants.CLAVE_CLAENTIDAD_SISTFINANCIERO)) {
							tipoCta = "CTA. ";
						}
					}
					valor = tipoCta + (StringUtils.isBlank(socSolicitudctas.getNroLibreta()) ? "" : socSolicitudctas.getNroLibreta()) + " "
							+ (StringUtils.isBlank(socSolicitudctas.getDescripLibreta()) ? "" : socSolicitudctas.getDescripLibreta());

				}
			} else if (var.startsWith("@NROCONCILIA")) {
				SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
				socCuentassolDao.setSessionFactory(getSessionFactory());
				SocCuentassol socCuentassolAcr = socCuentassolDao.getByClaveCuenta(Constants.COD_CLAVE_CTAACREEDORES, Constants.COD_MONEDA_USD);

				SocSolicitudctas socSolicitudctas = socSolicitudctasDao.getCuentaByAfectable(solicitud.getSolicitud().getSocCodigo(),
						socCuentassolAcr.getCtaAfectable());
				if (socSolicitudctas != null) {
					if (!StringUtils.isBlank(socSolicitudctas.getNroCuentabco()) && socSolicitudctas.getNroCuentabco().split("-").length >= 3) {
						String[] nroLibreta = socSolicitudctas.getNroCuentabco().split("-");
						valor = RengConciliaDao.getFormatoCodConcilia(Integer.parseInt(nroLibreta[0]), Integer.parseInt(nroLibreta[1]));
					}
				}
			}
		}
		valor = StringUtils.trimToEmpty(valor);
		Pattern pattern = Pattern.compile("(" + '\r' + '\n' + "|" + '\n' + ")");
		Matcher matcher = pattern.matcher(valor);
		valor = matcher.replaceAll(" ");
		valor = StringUtils.trimToEmpty(valor);
		return valor;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}
}
