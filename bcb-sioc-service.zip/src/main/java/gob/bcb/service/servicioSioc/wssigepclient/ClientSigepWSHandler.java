package gob.bcb.service.servicioSioc.wssigepclient;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.ws.WebServiceException;
import javax.xml.ws.soap.SOAPFaultException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.xml.security.transforms.TransformationException;
import org.hibernate.SessionFactory;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import gob.bcb.bpm.pruebaCU.CarCartascr;
import gob.bcb.bpm.pruebaCU.CarCartascrdet;
import gob.bcb.bpm.pruebaCU.SocComitipoope;
import gob.bcb.bpm.pruebaCU.SocComitipoopeDao;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocDetallessolDao;
import gob.bcb.bpm.pruebaCU.SocEsquemas;
import gob.bcb.bpm.pruebaCU.SocEsquemasDao;
import gob.bcb.bpm.pruebaCU.SocOpecomi;
import gob.bcb.bpm.pruebaCU.SocOpecomiDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudctas;
import gob.bcb.bpm.pruebaCU.SocSolicitudctasDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.SocSolicitudesDao;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.core.exception.InternaException;
import gob.bcb.core.exception.VerificaException;
import gob.bcb.core.exception.WebServClientException;
import gob.bcb.core.utils.FirmaDigHelper;
import gob.bcb.core.utils.JAXBHelper;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.core.utils.UtilsFile;
import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.core.utils.UtilsXML;
import gob.bcb.core.utils.XmlUtils;
import gob.bcb.service.commons.ConfigurationServ;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.logic.CartasCredService;
import gob.bcb.service.servicioSioc.wssigepclient.consultas.OperacionesDivisas;
import gob.bcb.service.servicioSioc.wssigepclient.consultas.OperacionesDivisas_Service;
import gob.bcb.service.servicioSioc.wssigepclient.xml.consultasigep.DetalleSolicitud;
import gob.bcb.service.servicioSioc.wssigepclient.xml.consultasigep.DetallesSolicitud;
import gob.bcb.service.servicioSioc.wssigepclient.xml.consultasigep.MontoDetalle;
import gob.bcb.service.servicioSioc.wssigepclient.xml.consultasigep.MontosDetalle;
import gob.bcb.service.servicioSioc.wssigepclient.xml.consultasigep.RespuestaSigepVdd;
import gob.bcb.service.servicioSioc.wssigepclient.xml.consultasigep.ServicioSigepVdd;
import gob.bcb.service.servicioSioc.wssigepclient.xml.consultasigep.SolicitudRespuesta;

public class ClientSigepWSHandler {
	private static final Log log = LogFactory.getLog(ClientSigepWSHandler.class);
	private static final QName SERVICE_NAME = new QName("http://mefp.gob.bo/itg", "OperacionesDivisas");
	private static Map<String, URL> urlsWSDL = new ConcurrentHashMap<String, URL>();

	public static final String TIPOOPER_WS_CONFIRMACIONDEBITO = "C02";
	public static final String TIPOOPER_WS_RECHAZARSOLICITUD = "C05";	
	private final SessionFactory sessionFactorySioc;
	private final SessionFactory sessionFactoryCoin;
	private final SocEsquemasDao socEsquemasDao;
	private final SocOpecomiDao socOpecomiDao;
	private final SocComitipoopeDao socComitipoopeDao;
	private final SocSolicitudctasDao socSolicitudctasDao;
	private final CartasCredService cartasCredService;
	private final SocDetallessolDao socDetallessolDao;
	private final SocSolicitudesDao socSolicitudesDao;

	private static DocumentBuilderFactory documentBuilderFactory;

	public static Map<String, String> equivalenciasCodsOpecomiSigep = new HashMap<String, String>();
	static {
		equivalenciasCodsOpecomiSigep.put(Constants.COD_VAR_MONTOCOMTRANSEXT, Constants.COD_CLAVE_COMCTRA);
		equivalenciasCodsOpecomiSigep.put(Constants.COD_VAR_MONTOGASTOCOM, Constants.COD_VAR_COMSWIFT);
		equivalenciasCodsOpecomiSigep.put(Constants.COD_VAR_MONTOGASTOADM, Constants.COD_VAR_COMUTIL);
		equivalenciasCodsOpecomiSigep.put(Constants.COD_VAR_MONTOCOMENMIENDA, Constants.COD_VAR_COMENMIENDA);
		equivalenciasCodsOpecomiSigep.put(Constants.COD_VAR_MONTOCOMEMISCARTCRED, Constants.COD_VAR_COMEMISCC);
		equivalenciasCodsOpecomiSigep.put(Constants.COD_VAR_DIFERTC, Constants.COD_VAR_DIFERTC);
	}

	public ClientSigepWSHandler(SessionFactory sessionFactorySioc, SessionFactory sessionFactoryCoin) {
		this.sessionFactorySioc = sessionFactorySioc;
		this.sessionFactoryCoin = sessionFactoryCoin;

		this.cartasCredService = new CartasCredService(sessionFactorySioc, sessionFactoryCoin);

		this.socSolicitudesDao = new SocSolicitudesDao();
		this.socSolicitudesDao.setSessionFactory(sessionFactorySioc);

		this.socDetallessolDao = new SocDetallessolDao();
		this.socDetallessolDao.setSessionFactory(sessionFactorySioc);

		this.socEsquemasDao = new SocEsquemasDao();
		this.socEsquemasDao.setSessionFactory(sessionFactorySioc);

		this.socOpecomiDao = new SocOpecomiDao();
		this.socOpecomiDao.setSessionFactory(sessionFactorySioc);

		this.socComitipoopeDao = new SocComitipoopeDao();
		this.socComitipoopeDao.setSessionFactory(sessionFactorySioc);

		this.socSolicitudctasDao = new SocSolicitudctasDao();
		this.socSolicitudctasDao.setSessionFactory(sessionFactorySioc);
	}

	public static URL genURLPort(String fileNameWsdl) {
		if (urlsWSDL.containsKey(fileNameWsdl)) {
			return urlsWSDL.get(fileNameWsdl);
		}

		URL baseUrl = null;
		try {
			// log.info("XXX:ConfigurationServ.getConfigurationHome() " +
			// ConfigurationServ.getConfigurationHome());
			baseUrl = new URL("file:///" + ConfigurationServ.getConfigurationHome().concat("//").concat(Constants.WSDL_DIR_NAME).concat("//"));
			log.info(" configurando url wsdl baseUrl : " + baseUrl.getPath() + " directori " + "file:/" + ConfigurationServ.getConfigurationHome() + "/"
					+ Constants.WSDL_DIR_NAME);
		} catch (MalformedURLException e) {
			throw new RuntimeException("Error interno url de WSDL malformado " + e.getMessage());
		}
		URL wsdlURL = null;
		try {
			wsdlURL = new URL(baseUrl, fileNameWsdl);
			File h = new File(wsdlURL.getPath());
			if (!h.exists() || h.isDirectory()) {
				throw new RuntimeException(h.getAbsolutePath() + " archivo de configuración WSDL inexistente");
			}
			log.debug("wsdlURL : " + wsdlURL.getPath());
		} catch (MalformedURLException e) {
			throw new RuntimeException("Error al cargar WSDL " + fileNameWsdl + " " + e.getMessage());
		}
		urlsWSDL.put(fileNameWsdl, wsdlURL);
		return wsdlURL;
	}

	public RespuestaSigepVdd execWSServicioServicioSigepVdd(ServicioSigepVdd servicioSigep, String codSolicitudorig, Map<String, Object> parametros) {
		log.info("en confirmacionDebito XML: \n" + codSolicitudorig);

		URL wsdlURL = ClientSigepWSHandler.genURLPort(Constants.FILE_NAME_WSDL_SIGEPAVISODEBITO);

		String mensaje = transformaXML(servicioSigep);

		String msgXMLRespuesta = "";
		RespuestaSigepVdd respuestaSigep = null;
		try {
			log.info("Invoking confirmacionDebito... con mensaje XML: \n" + mensaje);
			OperacionesDivisas_Service ss = new OperacionesDivisas_Service(wsdlURL, SERVICE_NAME);
			OperacionesDivisas port = ss.getOperacionesDivisasPort();

			FirmaDigHelper firmaDigHelper = new FirmaDigHelper();
			String firmadito = firmaDigHelper.sign(mensaje);

			String pathFile = UtilsFile.grabaEnArchivo(firmadito,
					ConfigurationServ.getConfigurationHome() + "/mensajes/" + servicioSigep.getTipoOperacion() + "_" + servicioSigep.getCodSolicitud() + ".xml");
			log.info("Antes de enviar datos, Archivo consulta XML salvado en " + pathFile);

			if (!ConfigurationServ.getConfigurationHome().startsWith("e:/")) {

				msgXMLRespuesta = port.confirmarOperacionDivisas(firmadito);
				log.info("-------------XML Respuesta confirmacion debito -------");
				log.info(msgXMLRespuesta);
				log.info("------------------------------------------------------");
				// //////////////////////////////
				// validar fima
				// firmaDigHelper.verify(msgXMLRespuesta);

				String mensajeBO = UtilsXML.tagToString(msgXMLRespuesta, "respuesta_sigep_vdd");

				respuestaSigep = (RespuestaSigepVdd) transformaXML(mensajeBO);

			} else {
				respuestaSigep = new RespuestaSigepVdd();
				respuestaSigep.setCodEstado("P00");
				respuestaSigep.setDesEstado("P00");
			}
			log.info("Respuesta SIGEP: [" + respuestaSigep.getCodEstado() + "] " + respuestaSigep.getDesEstado());
		} catch (SOAPFaultException e) {
			log.error("Error al consultar TGN WS con mensaje: " + e.getMessage(), e);
			throw new WebServClientException("Error al consultar WS TGN con mensaje: " + e.getMessage());
		} catch (WebServiceException e) {
			log.error("Error al ejecutar consulta WS TGN con mensaje: " + e.getMessage());
			throw new WebServClientException("Error al ejecutar consulta WS TGN con mensaje: " + e.getMessage());
		} catch (NullPointerException e) {
			log.error("Error al consultar TGN WS con mensaje: " + e.getMessage(), e);
			throw new WebServClientException("Error al consultar WS TGN con mensaje: " + e.getMessage());
		} catch (InternaException e) {
			log.error("Error interno al consultar TGN WS con mensaje: " + e.getMessage(), e);
			throw new WebServClientException("Error interno al consultar TGN WS con mensaje: " + e.getMessage());
		} catch (VerificaException e) {
			log.error("Error de firma digital al consultar TGN WS con mensaje: " + e.getMessage(), e);
			throw new WebServClientException(e.getMessage());
		} catch (ParserConfigurationException e) {
			log.error("Error en documento XML con mensaje: " + e.getMessage(), e);
			throw new WebServClientException("Error en documento XML con mensaje: " + e.getMessage());
		} catch (SAXException e) {
			log.error("Error: en documento XML con mensaje: " + e.getMessage(), e);
			throw new WebServClientException("Error: en documento XML con mensaje: " + e.getMessage());
		} catch (IOException e) {
			log.error("Error: " + e.getMessage(), e);
			throw new WebServClientException("Error: " + e.getMessage());
		} catch (TransformationException e) {
			log.error("Error XML: " + e.getMessage(), e);
			throw new WebServClientException("Error XML: " + e.getMessage());
		} catch (Exception e) {
			log.error("Error al consultar TGN WS con mensaje: " + e.getMessage(), e);
			throw new WebServClientException("Error al consultar WS TGN con mensaje: " + e.getMessage());

		}

		if (respuestaSigep == null || !respuestaSigep.getCodEstado().equals("P00")) {
			throw new WebServClientException("Error en Servicio SIGEP en solicitud MEFP[" + codSolicitudorig + "] con mensaje: " + respuestaSigep.getDesEstado());
		}
		return respuestaSigep;

	}

	public RespuestaSigepVdd sendToWSServicioServicioSigepVdd(ServicioSigepVdd servicioSigep, String codSolicitudorig) {
		log.info("en sendToWSServicioServicioSigepVdd XML: \n" + codSolicitudorig);

		URL wsdlURL = ClientSigepWSHandler.genURLPort(Constants.FILE_NAME_WSDL_SIGEPAVISODEBITO);

		String msgXMLRespuesta = "";
		RespuestaSigepVdd respuestaSigep = null;
		try {
			final String firmadito = firmarYGuardar(servicioSigep, true) ;

			OperacionesDivisas_Service ss = new OperacionesDivisas_Service(wsdlURL, SERVICE_NAME);
			OperacionesDivisas port = ss.getOperacionesDivisasPort();

			if (!ConfigurationServ.getConfigurationHome().startsWith("e:/")) {
				log.info("Antes de enviar mensaje al TGN... esperando respuesta");				
				msgXMLRespuesta = port.confirmarOperacionDivisas(firmadito);
				log.info("-------------XML Respuesta confirmacion debito -------");
				log.info(msgXMLRespuesta);
				log.info("------------------------------------------------------");
				// //////////////////////////////
				// validar fima
				// firmaDigHelper.verify(msgXMLRespuesta);

				String mensajeBO = UtilsXML.tagToString(msgXMLRespuesta, "respuesta_sigep_vdd");

				respuestaSigep = (RespuestaSigepVdd) transformaXML(mensajeBO);

			} else {
				respuestaSigep = new RespuestaSigepVdd();
				respuestaSigep.setCodEstado("P00");
				respuestaSigep.setDesEstado("P00");
			}
			log.info("Respuesta SIGEP: [" + respuestaSigep.getCodEstado() + "] " + respuestaSigep.getDesEstado());
		} catch (SOAPFaultException e) {
			log.error("Error al consultar TGN WS con mensaje: " + e.getMessage(), e);
			throw new WebServClientException("Error al consultar WS TGN con mensaje: " + e.getMessage(), e);
		} catch (WebServiceException e) {
			log.error("Error al ejecutar consulta WS TGN con mensaje: " + e.getMessage(), e);
			throw new WebServClientException("Error al ejecutar consulta WS TGN con mensaje: " + e.getMessage(), e);
		} catch (NullPointerException e) {
			log.error("Error al consultar TGN WS con mensaje: " + e.getMessage(), e);
			throw new WebServClientException("Error al consultar WS TGN con mensaje: " + e.getMessage());
		} catch (InternaException e) {
			log.error("Error interno al consultar TGN WS con mensaje: " + e.getMessage(), e);
			throw new WebServClientException("Error interno al consultar TGN WS con mensaje: " + e.getMessage());
		} catch (VerificaException e) {
			log.error("Error de firma digital al consultar TGN WS con mensaje: " + e.getMessage(), e);
			throw new WebServClientException(e.getMessage());
		} catch (ParserConfigurationException e) {
			log.error("Error en documento XML con mensaje: " + e.getMessage(), e);
			throw new WebServClientException("Error en documento XML con mensaje: " + e.getMessage(), e);
		} catch (SAXException e) {
			log.error("Error: en documento XML con mensaje: " + e.getMessage(), e);
			throw new WebServClientException("Error: en documento XML con mensaje: " + e.getMessage(), e);
		} catch (IOException e) {
			log.error("Error: " + e.getMessage(), e);
			throw new WebServClientException("Error: " + e.getMessage(), e);
		} catch (Exception e) {
			log.error("Error al consultar TGN WS con mensaje: " + e.getMessage(), e);
			throw new WebServClientException("Error al consultar WS TGN con mensaje: " + e.getMessage(), e);

		}

		if (respuestaSigep == null || !respuestaSigep.getCodEstado().equals("P00")) {
			throw new WebServClientException("Error en Servicio SIGEP en solicitud MEFP[" + codSolicitudorig + "] con mensaje: " + respuestaSigep.getDesEstado());
		}
		return respuestaSigep;

	}

	public String firmarYGuardar(ServicioSigepVdd servicioSigep, boolean guardarArchivo) {
		try {
			log.info("en firmarYGuardar XML " + servicioSigep.getTipoOperacion() + "_" + servicioSigep.getCodSolicitud());			
			String mensaje = transformaXML(servicioSigep);			
			log.info("con mensaje XML firmado: \n" + mensaje);

			FirmaDigHelper firmaDigHelper = new FirmaDigHelper();
			final String firmadito = firmaDigHelper.sign(mensaje);

			if (guardarArchivo) {
				String pathFile = UtilsFile.grabaEnArchivo(firmadito,
						ConfigurationServ.getConfigurationHome() + "/mensajes/" + servicioSigep.getTipoOperacion() + "_" + servicioSigep.getCodSolicitud() + ".xml");
				log.info("Archivo XML salvado en " + pathFile);
			}
			return firmadito;

		} catch (NullPointerException e) {
			log.error("Error al firmar con mensaje: " + e.getMessage(), e);
			throw new WebServClientException("Error al firmar WS TGN con mensaje: " + e.getMessage());
		} catch (InternaException e) {
			log.error("Error interno al firmar  con mensaje: " + e.getMessage(), e);
			throw new WebServClientException("Error interno al firmar con mensaje: " + e.getMessage());
		} catch (VerificaException e) {
			log.error("Error de firma digital al firmar con mensaje: " + e.getMessage(), e);
			throw new WebServClientException(e.getMessage());
		} catch (ParserConfigurationException e) {
			log.error("Error en documento XML con mensaje: " + e.getMessage(), e);
			throw new WebServClientException("Error en documento XML con mensaje: " + e.getMessage());
		} catch (SAXException e) {
			log.error("Error: en documento XML con mensaje: " + e.getMessage(), e);
			throw new WebServClientException("Error: en documento XML con mensaje: " + e.getMessage());
		} catch (IOException e) {
			log.error("Error: " + e.getMessage(), e);
			throw new WebServClientException("Error: " + e.getMessage());
		} catch (TransformationException e) {
			log.error("Error XML: " + e.getMessage(), e);
			throw new WebServClientException("Error XML: " + e.getMessage());
		} catch (Exception e) {
			log.error("Error al firmar  con mensaje: " + e.getMessage(), e);
			throw new WebServClientException("Error al firmar con mensaje: " + e.getMessage());
		}
	}
	
	public RespuestaSigepVdd confirmacionDebito(Solicitud solicitudTO, Map<String, Object> parametros) {
		log.info("en confirmacionDebito XML: \n" + solicitudTO.getSolicitud().toString());

		ServicioSigepVdd servicioSigep = generarSigepVddConfirmacion(solicitudTO);
		
		return sendToWSServicioServicioSigepVdd(servicioSigep, solicitudTO.getSolicitud().getCodSolicitudorig());
	}

	public String confirmacionDebitoXMLFirmado(Solicitud solicitudTO) {
		log.info("en confirmacionDebitoXMLFirmado XML: \n" + solicitudTO.getSolicitud().toString());

		ServicioSigepVdd servicioSigep = generarSigepVddConfirmacion(solicitudTO);
		boolean guardarArchivo = !solicitudTO.getSolicitud().getClaEstadows().equals(Constants.CLAVE_ESTWS_NOTIF); 
		final String firmadito = firmarYGuardar(servicioSigep, guardarArchivo) ;
		
		return firmadito;
	}
	
	public ServicioSigepVdd generarSigepVddConfirmacion(Solicitud solicitudTO) {
		log.info("en generarSigepVdd: \n" + solicitudTO.getSolicitud().toString());

		ServicioSigepVdd servicioSigep = null;
		if (solicitudTO.getSolicitud().getClaTipo().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS)
				|| solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS)) {
			servicioSigep = actualizarConfirmacionCarta(solicitudTO);
		} else {
			servicioSigep = actualizarConfirmacionDebito(TIPOOPER_WS_CONFIRMACIONDEBITO, solicitudTO);
		}
		return servicioSigep;
	}
	
	public RespuestaSigepVdd rechazarSolicitud(String codSolicitudorig, String statusCode, String consent, Map<String, Object> parametros) {
		log.info("en rechazarSolicitud XML: \n" + codSolicitudorig);

		ServicioSigepVdd servicioSigep = rechazoDeSolicitud(TIPOOPER_WS_RECHAZARSOLICITUD, codSolicitudorig, statusCode, consent, parametros);
		return execWSServicioServicioSigepVdd(servicioSigep, codSolicitudorig, parametros);

	}

	private ServicioSigepVdd actualizarConfirmacionDebito(String codTipoOperacion, Solicitud solicitudTO) {

		Map<String, SocSolicitudctas> socSolicitudctasMap = new HashMap<String, SocSolicitudctas>();

		for (SocSolicitudctas socSolicitudctas : solicitudTO.getSocSolicitudctasLista()) {
			socSolicitudctasMap.put(socSolicitudctas.getId().getTipoCuenta(), socSolicitudctas);
		}

		ServicioSigepVdd servicioSigep = new ServicioSigepVdd();

		servicioSigep.setTipoOperacion(codTipoOperacion);
		servicioSigep.setFechaHora(UtilsDate.stringFromDate(solicitudTO.getSolicitud().getFechaReg(), "dd-MM-yyyy hh:mm:ss"));
		servicioSigep.setIdMensajeOrigen(UtilsDate.stringFromDate(new Date(), "yyyyMMdd") + "-" + UtilsGeneric.generateUUID().replaceAll("-", ""));
		servicioSigep.setCodSolicitud(solicitudTO.getSolicitud().getCodSolicitudorig());

		List<SocDetallessol> socDetallessolLista = solicitudTO.getSocDetallessolLista();
		if (socDetallessolLista.size() > 0) {
			if (socDetallessolLista.get(0).getFechaHora() != null)
				servicioSigep.setFechaTransferencia(UtilsDate.stringFromDate(socDetallessolLista.get(0).getFechaHora(), "dd-MM-yyyy hh:mm:ss"));

		}
		DetallesSolicitud detallesSolicitud = new DetallesSolicitud();

		int ultben = 1;

		for (SocDetallessol socDetallessol : socDetallessolLista) {
			DetalleSolicitud detalleSolicitud = new DetalleSolicitud();

			detalleSolicitud.setCodDetalle(socDetallessol.getId().getDetCodigo());
			detalleSolicitud.setCodBeneficiario(socDetallessol.getBenCodigo());
			detalleSolicitud.setMontoTransferido(socDetallessol.getDetMontotrans());

			if (socDetallessol.getCodMonedatdet() != null)
				detalleSolicitud.setCodMonedaTransferido(socDetallessol.getCodMonedatdet().toString());
			if (solicitudTO.getSolicitud().getSocTipoc() != null)
				detalleSolicitud.setTipoCambioTransferido(solicitudTO.getSolicitud().getSocTipoc().setScale(5, BigDecimal.ROUND_HALF_UP));

			MontosDetalle montosDetalle = new MontosDetalle();

			MontoDetalle montoDetalle = new MontoDetalle();
			montoDetalle = new MontoDetalle();
			SocOpecomi socOpecomi = solicitudTO.buscarClaComision(Constants.COD_VAR_MONTOTRANS, socDetallessol.getId().getDetCodigo());
			if (socOpecomi != null) {
				montoDetalle.setCodMonto(Constants.COD_VAR_MONTOTRANS);
				montoDetalle.setMonto(socOpecomi.getMontoMo());
				montoDetalle.setCodMoneda(socOpecomi.getCodMoneda().toString());
				if (socOpecomi.getTipoCambio() != null)
					montoDetalle.setTipoCambio(socOpecomi.getTipoCambio().setScale(5, BigDecimal.ROUND_HALF_UP));
				montoDetalle.setNroCuenta(socSolicitudctasMap.get(Constants.COD_CLAVE_MOVPROVISION).getNroCuenta());
				montosDetalle.getMontoDetalle().add(montoDetalle);
			}

			montoDetalle = new MontoDetalle();

			socOpecomi = solicitudTO.buscarClaComision(Constants.COD_VAR_COMTRANSF, socDetallessol.getId().getDetCodigo());
			if (socOpecomi != null) {
				montoDetalle.setCodMonto(Constants.COD_CLAVE_COMCTRA);
				montoDetalle.setMonto(socOpecomi.getMontoMo());
				montoDetalle.setCodMoneda(socOpecomi.getCodMoneda().toString());
				if (socOpecomi.getTipoCambio() != null)
					montoDetalle.setTipoCambio(socOpecomi.getTipoCambio().setScale(5, BigDecimal.ROUND_HALF_UP));
				montoDetalle.setNroCuenta(socSolicitudctasMap.get(Constants.COD_CLAVE_COMCTRA).getNroCuenta());
				montosDetalle.getMontoDetalle().add(montoDetalle);
			}

			montoDetalle = new MontoDetalle();
			socOpecomi = solicitudTO.buscarClaComision(Constants.COD_VAR_COMSWIFT, socDetallessol.getId().getDetCodigo());
			if (socOpecomi != null) {
				montoDetalle.setCodMonto(socOpecomi.getId().getClaComision());
				montoDetalle.setMonto(socOpecomi.getMontoMo());
				montoDetalle.setCodMoneda(socOpecomi.getCodMoneda().toString());
				if (socOpecomi.getTipoCambio() != null)
					montoDetalle.setTipoCambio(socOpecomi.getTipoCambio().setScale(5, BigDecimal.ROUND_HALF_UP));
				montoDetalle.setNroCuenta(socSolicitudctasMap.get(Constants.COD_CLAVE_COMGADM).getNroCuenta());
				montosDetalle.getMontoDetalle().add(montoDetalle);
			}

			if (socDetallessolLista.size() == ultben) {
				montoDetalle = new MontoDetalle();
				socOpecomi = solicitudTO.buscarClaComision(Constants.COD_VAR_COMUTIL, 0);
				if (socOpecomi != null) {
					montoDetalle.setCodMonto(socOpecomi.getId().getClaComision());
					montoDetalle.setMonto(socOpecomi.getMontoMo());
					montoDetalle.setCodMoneda(socOpecomi.getCodMoneda().toString());
					if (socOpecomi.getTipoCambio() != null)
						montoDetalle.setTipoCambio(socOpecomi.getTipoCambio().setScale(5, BigDecimal.ROUND_HALF_UP));
					montoDetalle.setNroCuenta(socSolicitudctasMap.get(Constants.COD_CLAVE_COMGADM).getNroCuenta());
					montosDetalle.getMontoDetalle().add(montoDetalle);
				}

				montoDetalle = new MontoDetalle();
				socOpecomi = solicitudTO.buscarClaComision(Constants.COD_VAR_DIFERTC, 0);

				if (socOpecomi != null && socOpecomi.getMontoMo() != null && socOpecomi.getMontoMo().compareTo(BigDecimal.ZERO) != 0) {
					montoDetalle.setCodMonto(socOpecomi.getId().getClaComision());
					montoDetalle.setMonto(socOpecomi.getOcoMonto());
					montoDetalle.setCodMoneda(socOpecomi.getCodMoneda().toString());
					if (socOpecomi.getTipoCambio() != null)
						montoDetalle.setTipoCambio(socOpecomi.getTipoCambio().setScale(5, BigDecimal.ROUND_HALF_UP));
					montoDetalle.setNroCuenta(socSolicitudctasMap.get(Constants.COD_CLAVE_DIFCAMB).getNroCuenta());
					montosDetalle.getMontoDetalle().add(montoDetalle);
				}
			}
			detalleSolicitud.getMontosDetalle().add(montosDetalle);
			detallesSolicitud.getDetalleSolicitud().add(detalleSolicitud);
			ultben++;
		}
		servicioSigep.setDetallesSolicitud(detallesSolicitud);

		return servicioSigep;
	}

	private ServicioSigepVdd actualizarConfirmacionCarta(Solicitud solicitudIn) {
		ServicioSigepVdd servicioSigep = new ServicioSigepVdd();

		Solicitud solicitud = cartasCredService.recuperarDatosCartaParaCodcartacr(solicitudIn.getCarCartascrdet().getId().getCcdCodcartacr(),
				solicitudIn.getCarCartascrdet().getId().getCcdNroccreddet());
		CarCartascr carCartascr = solicitud.getCarCartascr();
		CarCartascrdet carCartascrdet = solicitud.getCarCartascrdet();
		CarCartascrdet carCartascrdetEmis = cartasCredService.obtenerRegistroAperturaAutorizado(carCartascr.getCcrCodcartacr());

		SocSolicitudes solicitudEmis = socSolicitudesDao.getSolicitud(carCartascrdetEmis.getCcdSoccodigo());
		if (solicitudEmis == null) {
			throw new BusinessException("Solicitud inexistente " + carCartascrdetEmis.getCcdSoccodigo());
		}

		String codTipoOperacion = "";
		if (CartasCredService.esRegistroDeEmision(carCartascrdet)) {
			codTipoOperacion = TIPOOPER_WS_CONFIRMACIONDEBITO;
		} else if (CartasCredService.esRegistroDePago(carCartascrdet)) {
			codTipoOperacion = "C10";
		} else if (CartasCredService.esEnmiendaDeIncremento(carCartascrdet)) {
			codTipoOperacion = "C11";
		} else if (CartasCredService.esEnmiendaDeDecremento(carCartascrdet)) {
			codTipoOperacion = "C12";
		} else if (CartasCredService.esEnmiendaDeAmpliacion(carCartascrdet) || CartasCredService.esEnmiendaDeReduccion(carCartascrdet)
				|| CartasCredService.esEnmiendaDeModificacionDatos(carCartascrdet)) {
			codTipoOperacion = "C15";
		}

		servicioSigep.setTipoOperacion(codTipoOperacion);
		servicioSigep.setFechaHora(UtilsDate.stringFromDate(solicitud.getSolicitud().getFechaReg(), "dd-MM-yyyy hh:mm:ss"));
		servicioSigep.setIdMensajeOrigen(UtilsDate.stringFromDate(new Date(), "yyyyMMdd") + "-" + UtilsGeneric.generateUUID().replaceAll("-", ""));
		servicioSigep.setCodSolicitud(solicitudEmis.getCodSolicitudorig());

		List<SocDetallessol> socDetallessolLista = solicitud.getSocDetallessolLista();
		if (socDetallessolLista.size() > 0) {
			if (socDetallessolLista.get(0).getFechaHora() != null)
				servicioSigep.setFechaTransferencia(UtilsDate.stringFromDate(socDetallessolLista.get(0).getFechaHora(), "dd-MM-yyyy hh:mm:ss"));

		}
		DetallesSolicitud detallesSolicitud = new DetallesSolicitud();

		int ultben = 1;

		SocEsquemas socEsquemas = socEsquemasDao.esquemaByCod(solicitud.getSolicitud().getEsqCodigo());
		List<SocComitipoope> socComitipoopeLista = socComitipoopeDao.comisionesByCodCargo(socEsquemas.getCodCargo());

		for (SocDetallessol socDetallessol : socDetallessolLista) {
			DetalleSolicitud detalleSolicitud = armarDetalleCarta(solicitud, socDetallessol, carCartascr, carCartascrdet);

			MontosDetalle montosDetalle = new MontosDetalle();
			SocOpecomi socOpecomi = null;

			if (CartasCredService.esRegistroDeEmision(carCartascrdet) || CartasCredService.esEnmiendaDeIncremento(carCartascrdet)) {
				socOpecomi = socOpecomiDao.getOpeComisByDetCodClaCom(solicitud.getSolicitud().getSocCodigo(), 0, Constants.COD_VAR_TOTALPROV);
			} else if (CartasCredService.esRegistroDePago(carCartascrdet)) {
			} else if (CartasCredService.esEnmiendaDeDecremento(carCartascrdet)) {
				socOpecomi = socOpecomiDao.getOpeComisByDetCodClaCom(solicitud.getSolicitud().getSocCodigo(), 0, Constants.COD_VAR_TOTTRANSMT);
			}

			if (socOpecomi != null) {
				SocSolicitudctas socSolicitudctas = socSolicitudctasDao.getCuentaByAfectable(solicitud.getSolicitud().getSocCodigo(), socOpecomi.getNroCuenta());
				MontoDetalle montoDetalleMT = armarMontoDetalle(socOpecomi, Constants.COD_VAR_MONTOTRANS, socSolicitudctas);
				montosDetalle.getMontoDetalle().add(montoDetalleMT);
			}

			for (SocComitipoope socComitipoope : socComitipoopeLista) {
				if (socComitipoope.getClaFormapago().equals(Constants.CLAVE_FORMAPAGO_DETALLE)) {
					// solo para comisiones que tienen detalle
					SocOpecomi socOpecomiDet = socOpecomiDao.getOpeComisByDetCodClaCom(solicitud.getSolicitud().getSocCodigo(), socDetallessol.getId().getDetCodigo(),
							socComitipoope.getClaComisionopecomi() + "MO");

					if (socOpecomiDet != null) {
						SocSolicitudctas socSolicitudctas = socSolicitudctasDao.getCuentaByAfectable(solicitud.getSolicitud().getSocCodigo(), socOpecomiDet.getNroCuenta());

						if (equivalenciasCodsOpecomiSigep.containsKey(socComitipoope.getClaComisionopecomi())) {
							MontoDetalle montoDetalle = armarMontoDetalle(socOpecomiDet, equivalenciasCodsOpecomiSigep.get(socComitipoope.getClaComisionopecomi()),
									socSolicitudctas);
							montosDetalle.getMontoDetalle().add(montoDetalle);
						}
					}
				}
			}

			if (socDetallessolLista.size() == ultben) {
				for (SocComitipoope socComitipoope : socComitipoopeLista) {
					if (socComitipoope.getClaFormapago().equals(Constants.CLAVE_FORMAPAGO_UNICO)) {
						// solo para comisiones que tienen detalle
						SocOpecomi socOpecomiDet = socOpecomiDao.getOpeComisByDetCodClaCom(solicitud.getSolicitud().getSocCodigo(), 0,
								socComitipoope.getClaComisionopecomi() + "MO");

						if (socOpecomiDet != null) {
							SocSolicitudctas socSolicitudctas = socSolicitudctasDao.getCuentaByAfectable(solicitud.getSolicitud().getSocCodigo(), socOpecomiDet.getNroCuenta());

							if (equivalenciasCodsOpecomiSigep.containsKey(socComitipoope.getClaComisionopecomi())) {
								MontoDetalle montoDetalle = armarMontoDetalle(socOpecomiDet, equivalenciasCodsOpecomiSigep.get(socComitipoope.getClaComisionopecomi()),
										socSolicitudctas);
								montosDetalle.getMontoDetalle().add(montoDetalle);
							}
						}
					}
				}

				socOpecomi = socOpecomiDao.getOpeComisByDetCodClaCom(solicitud.getSolicitud().getSocCodigo(), 0, Constants.COD_VAR_DIFERTC);

				if (socOpecomi != null && socOpecomi.getMontoMo() != null && socOpecomi.getMontoMo().compareTo(BigDecimal.ZERO) != 0) {
					SocSolicitudctas socSolicitudctas = socSolicitudctasDao.getCuentaByAfectable(solicitud.getSolicitud().getSocCodigo(), socOpecomi.getNroCuenta());

					MontoDetalle montoDetalleMT = armarMontoDetalle(socOpecomi, socOpecomi.getId().getClaComision(), socSolicitudctas);
					montosDetalle.getMontoDetalle().add(montoDetalleMT);
				}
			}

			detalleSolicitud.getMontosDetalle().add(montosDetalle);
			detallesSolicitud.getDetalleSolicitud().add(detalleSolicitud);
			ultben++;
		}

		servicioSigep.setDetallesSolicitud(detallesSolicitud);

		return servicioSigep;
	}

	public ServicioSigepVdd rechazoDeSolicitud(String codTipoOperacion, String codSolicitudorig, String statusCode, String consent, Map<String, Object> parametros) {

		ServicioSigepVdd servicioSigep = new ServicioSigepVdd();
		servicioSigep.setTipoOperacion(codTipoOperacion);
		servicioSigep.setFechaHora(UtilsDate.stringFromDate(new Date(), "dd-MM-yyyy hh:mm:ss"));
		servicioSigep.setIdMensajeOrigen(UtilsDate.stringFromDate(new Date(), "yyyyMMdd") + "-" + UtilsGeneric.generateUUID().replace("-", ""));
		servicioSigep.setCodSolicitud(codSolicitudorig);

		SolicitudRespuesta solicitudRespuesta = new SolicitudRespuesta();
		solicitudRespuesta.setCodEstadoResp(statusCode);
		solicitudRespuesta.setDesEstadoResp(consent);

		servicioSigep.setSolicitudRespuesta(solicitudRespuesta);

		return servicioSigep;
	}

	private Object transformaXML(String mensajeXML) {

		Object mensajeJAXB = null;
		log.info("=======> inicio mensaje XML <========");
		log.info(mensajeXML);
		log.info("=======> fin mensaje XML <========");
		try {
			JAXBContext context = JAXBContext.newInstance(RespuestaSigepVdd.class);
			mensajeJAXB = JAXBHelper.convertXMLToMsgBcb(mensajeXML, context);
		} catch (Exception e) {
			log.error("Error al desparseo: " + e.getMessage(), e);
			throw new WebServClientException(e);
		}

		return mensajeJAXB;
	}

	private String transformaXML(ServicioSigepVdd servicioSigep) {
		String mensajeXML = null;
		try {

			JAXBContext context = JAXBContext.newInstance(ServicioSigepVdd.class);
			Document doc = JAXBHelper.toDocument(servicioSigep, documentBuilderFactory, context);
			mensajeXML = XmlUtils.getStringFromDom(doc);

		} catch (JAXBException e) {
			throw new WebServClientException(e);
		} catch (ParserConfigurationException e) {
			throw new WebServClientException(e);
		} catch (TransformerException e) {
			throw new WebServClientException(e);
		}

		return mensajeXML;
	}

	private DetalleSolicitud armarDetalleSolicitud(Solicitud solicitud, SocDetallessol socDetallessol) {
		DetalleSolicitud detalleSolicitud = new DetalleSolicitud();

		detalleSolicitud.setCodDetalle(socDetallessol.getId().getDetCodigo());
		detalleSolicitud.setCodBeneficiario(socDetallessol.getBenCodigo());
		detalleSolicitud.setMontoTransferido(socDetallessol.getDetMontotrans());

		if (socDetallessol.getCodMonedatdet() != null)
			detalleSolicitud.setCodMonedaTransferido(socDetallessol.getCodMonedatdet().toString());
		if (solicitud.getSolicitud().getSocTipoc() != null)
			detalleSolicitud.setTipoCambioTransferido(solicitud.getSolicitud().getSocTipoc().setScale(5, BigDecimal.ROUND_HALF_UP));

		return detalleSolicitud;
	}

	private DetalleSolicitud armarDetalleCarta(Solicitud solicitud, SocDetallessol socDetallessol, CarCartascr carCartascr, CarCartascrdet carCartascrdet) {
		DetalleSolicitud detalleSolicitud = new DetalleSolicitud();
		detalleSolicitud.setCodDetalle(socDetallessol.getId().getDetCodigo());
		detalleSolicitud.setCodBeneficiario(carCartascr.getCcrBencodigo());

		detalleSolicitud.setCodMonedaTransferido(carCartascrdet.getCcdCodmontrans().toString());
		detalleSolicitud.setMontoTransferido(BigDecimal.ZERO);
		
		if (CartasCredService.esRegistroDeEmision(carCartascrdet)) {
			detalleSolicitud.setMontoTransferido(carCartascrdet.getCcdMontotrans());
		} else if (CartasCredService.esRegistroDePago(carCartascrdet)) {
			detalleSolicitud.setMontoTransferido(carCartascrdet.getCcdMontotrans());
		} else if (CartasCredService.esEnmiendaDeIncremento(carCartascrdet)) {
			detalleSolicitud.setMontoTransferido(carCartascrdet.getCcdMontotrans());			
		} else if (CartasCredService.esEnmiendaDeDecremento(carCartascrdet)) {
			detalleSolicitud.setMontoTransferido(carCartascrdet.getCcdMontotrans());			
		} else if (CartasCredService.esEnmiendaDeAmpliacion(carCartascrdet) || CartasCredService.esEnmiendaDeReduccion(carCartascrdet)
				|| CartasCredService.esEnmiendaDeModificacionDatos(carCartascrdet)) {

		}

		if (solicitud.getSolicitud().getSocTipoc() != null)
			detalleSolicitud.setTipoCambioTransferido(solicitud.getSolicitud().getSocTipoc().setScale(5, BigDecimal.ROUND_HALF_UP));

		return detalleSolicitud;
	}

	private MontoDetalle armarMontoDetalle(SocOpecomi socOpecomi, String codMonto, SocSolicitudctas socSolicitudctas) {
		MontoDetalle montoDetalle = new MontoDetalle();
		montoDetalle.setCodMonto(codMonto);
		montoDetalle.setMonto(socOpecomi.getMontoMo());
		montoDetalle.setCodMoneda(socOpecomi.getCodMoneda().toString());
		if (socOpecomi.getTipoCambio() != null)
			montoDetalle.setTipoCambio(socOpecomi.getTipoCambio().setScale(5, BigDecimal.ROUND_HALF_UP));
		if (socSolicitudctas != null)
			montoDetalle.setNroCuenta(socSolicitudctas.getNroCuenta());

		return montoDetalle;
	}

}
