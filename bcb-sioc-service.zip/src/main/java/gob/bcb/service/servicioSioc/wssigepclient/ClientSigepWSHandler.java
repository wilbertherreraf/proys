package gob.bcb.service.servicioSioc.wssigepclient;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.ws.WebServiceException;
import javax.xml.ws.soap.SOAPFaultException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.xml.security.transforms.TransformationException;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocOpecomi;
import gob.bcb.bpm.pruebaCU.SocSolicitudctas;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.core.exception.InternaException;
import gob.bcb.core.exception.VerificaException;
import gob.bcb.core.exception.WebServClientException;
import gob.bcb.core.utils.FirmaDigHelper;
import gob.bcb.core.utils.JAXBHelper;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.core.utils.UtilsFile;
import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.core.utils.UtilsXML;
import gob.bcb.core.utils.XmlUtils;
import gob.bcb.service.commons.ConfigurationServ;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.wssigepclient.consultas.OperacionesDivisas;
import gob.bcb.service.servicioSioc.wssigepclient.consultas.OperacionesDivisas_Service;
import gob.bcb.service.servicioSioc.wssigepclient.xml.consultasigep.DetalleSolicitud;
import gob.bcb.service.servicioSioc.wssigepclient.xml.consultasigep.DetallesSolicitud;
import gob.bcb.service.servicioSioc.wssigepclient.xml.consultasigep.MontoDetalle;
import gob.bcb.service.servicioSioc.wssigepclient.xml.consultasigep.MontosDetalle;
import gob.bcb.service.servicioSioc.wssigepclient.xml.consultasigep.RespuestaSigepVdd;
import gob.bcb.service.servicioSioc.wssigepclient.xml.consultasigep.ServicioSigepVdd;
import gob.bcb.service.servicioSioc.wssigepclient.xml.consultasigep.SolicitudRespuesta;

public class ClientSigepWSHandler {
	private static final Log log = LogFactory.getLog(ClientSigepWSHandler.class);
	private static final QName SERVICE_NAME = new QName("http://mefp.gob.bo/itg", "OperacionesDivisas");
	private static Map<String, URL> urlsWSDL = new ConcurrentHashMap<String, URL>();

//	private final static JAXBContext jAXBContext;
//	static {
//		try {
//			jAXBContext = JAXBContext.newInstance("gob.bcb.service.servicioSioc.wssigepclient.xml.consultasigep");
//			log.info("Contexto objetos JAXB clinte iniciado");
//		} catch (JAXBException e) {
//			log.error("Error al inicializar contexto clinte JAXB " + e.getMessage(), e);
//			throw new RuntimeException(e);
//		}
//	}

	private static DocumentBuilderFactory documentBuilderFactory;

	public static URL genURLPort(String fileNameWsdl) {
		if (urlsWSDL.containsKey(fileNameWsdl)) {
			return urlsWSDL.get(fileNameWsdl);
		}

		URL baseUrl = null;
		try {
			//log.info("XXX:ConfigurationServ.getConfigurationHome() " + ConfigurationServ.getConfigurationHome());
			baseUrl = new URL("file:///" + ConfigurationServ.getConfigurationHome().concat("//").concat(Constants.WSDL_DIR_NAME).concat("//"));
			log.info(" configurando url wsdl baseUrl : " + baseUrl.getPath() + " directori " + "file:/" + ConfigurationServ.getConfigurationHome()
					+ "/" + Constants.WSDL_DIR_NAME);
		} catch (MalformedURLException e) {
			throw new RuntimeException("Error interno url de WSDL malformado " + e.getMessage());
		}
		URL wsdlURL = null;
		try {
			wsdlURL = new URL(baseUrl, fileNameWsdl);
			File h = new File(wsdlURL.getPath());
			if (!h.exists() || h.isDirectory()) {
				throw new RuntimeException(h.getAbsolutePath() + " archivo de configuración WSDL inexistente");
			}
			log.debug("wsdlURL : " + wsdlURL.getPath());
		} catch (MalformedURLException e) {
			throw new RuntimeException("Error al cargar WSDL " + fileNameWsdl + " " + e.getMessage());
		}
		urlsWSDL.put(fileNameWsdl, wsdlURL);
		return wsdlURL;
	}

	public RespuestaSigepVdd execWSServicioServicioSigepVdd(ServicioSigepVdd servicioSigep, String codTipoOperacion, String codSolicitudorig, 
			Map<String, Object> parametros) {
		log.info("en confirmacionDebito XML: \n" + codSolicitudorig);

		URL wsdlURL = ClientSigepWSHandler.genURLPort(Constants.FILE_NAME_WSDL_SIGEPAVISODEBITO);

		String mensaje = transformaXML(servicioSigep);

		String msgXMLRespuesta = "";
		RespuestaSigepVdd respuestaSigep = null;
		try {
			log.info("Invoking confirmacionDebito... con mensaje XML: \n" + mensaje);
			OperacionesDivisas_Service ss = new OperacionesDivisas_Service(wsdlURL, SERVICE_NAME);
			OperacionesDivisas port = ss.getOperacionesDivisasPort();

			FirmaDigHelper firmaDigHelper = new FirmaDigHelper();

			String firmadito = firmaDigHelper.sign(mensaje);

			String pathFile = UtilsFile.grabaEnArchivo(
					firmadito,
					ConfigurationServ.getConfigurationHome() + "/mensajes/" + servicioSigep.getTipoOperacion() + "_"
							+ servicioSigep.getCodSolicitud() + ".xml");
			log.info("Antes de enviar datos, Archivo consulta XML salvado en " + pathFile);

			if (!ConfigurationServ.getConfigurationHome().startsWith("e:/")) {

				msgXMLRespuesta = port.confirmarOperacionDivisas(firmadito);
				log.info("-------------XML Respuesta confirmacion debito -------");
				log.info(msgXMLRespuesta);
				log.info("------------------------------------------------------");
				// //////////////////////////////
				// validar fima
				// firmaDigHelper.verify(msgXMLRespuesta);

				String mensajeBO = UtilsXML.tagToString(msgXMLRespuesta, "respuesta_sigep_vdd");

				respuestaSigep = (RespuestaSigepVdd) transformaXML(mensajeBO);

			} else {
				respuestaSigep = new RespuestaSigepVdd();
				respuestaSigep.setCodEstado("P00");
				respuestaSigep.setDesEstado("P00");
			}
			log.info("Respuesta SIGEP: ["+ respuestaSigep.getCodEstado() + "] " + respuestaSigep.getDesEstado());
		} catch (SOAPFaultException e) {
			log.error("Error al consultar TGN WS con mensaje: " + e.getMessage(), e);
			throw new WebServClientException("Error al consultar WS TGN con mensaje: " + e.getMessage());
		} catch (WebServiceException e) {
			log.error("Error al ejecutar consulta WS TGN con mensaje: " + e.getMessage());
			throw new WebServClientException("Error al ejecutar consulta WS TGN con mensaje: " + e.getMessage());
		} catch (NullPointerException e) {
			log.error("Error al consultar TGN WS con mensaje: " + e.getMessage(), e);
			throw new WebServClientException("Error al consultar WS TGN con mensaje: " + e.getMessage());
		} catch (InternaException e) {
			log.error("Error interno al consultar TGN WS con mensaje: " + e.getMessage(), e);
			throw new WebServClientException("Error interno al consultar TGN WS con mensaje: " + e.getMessage());
		} catch (VerificaException e) {
			log.error("Error de firma digital al consultar TGN WS con mensaje: " + e.getMessage(), e);
			throw new WebServClientException(e.getMessage());
		} catch (ParserConfigurationException e) {
			log.error("Error en documento XML con mensaje: " + e.getMessage(), e);
			throw new WebServClientException("Error en documento XML con mensaje: " + e.getMessage());
		} catch (SAXException e) {
			log.error("Error: en documento XML con mensaje: " + e.getMessage(), e);
			throw new WebServClientException("Error: en documento XML con mensaje: " + e.getMessage());
		} catch (IOException e) {
			log.error("Error: " + e.getMessage(), e);
			throw new WebServClientException("Error: " + e.getMessage());
		} catch (TransformationException e) {
			log.error("Error XML: " + e.getMessage(), e);
			throw new WebServClientException("Error XML: " + e.getMessage());
		} catch (Exception e) {
			log.error("Error al consultar TGN WS con mensaje: " + e.getMessage(), e);
			throw new WebServClientException("Error al consultar WS TGN con mensaje: " + e.getMessage());

		}

		if (respuestaSigep == null || !respuestaSigep.getCodEstado().equals("P00")) {
			throw new WebServClientException("Error en Servicio SIGEP en solicitud MEFP[" + codSolicitudorig
					+ "] con mensaje: " + respuestaSigep.getDesEstado());
		}
		return respuestaSigep;

	}

	public RespuestaSigepVdd confirmacionDebito(String codTipoOperacion, Solicitud solicitudTO, Map<String, Object> parametros) {
		log.info("en confirmacionDebito XML: \n" + solicitudTO.getSolicitud().toString());

		ServicioSigepVdd servicioSigep = actualizarConfirmacionDebito(codTipoOperacion, solicitudTO, parametros);

		return execWSServicioServicioSigepVdd(servicioSigep, codTipoOperacion, solicitudTO.getSolicitud().getCodSolicitudorig(), parametros);
	}

	public RespuestaSigepVdd rechazarSolicitud(String codTipoOperacion, String codSolicitudorig, String statusCode, String consent,
			Map<String, Object> parametros) {
		log.info("en rechazarSolicitud XML: \n" + codSolicitudorig);

		ServicioSigepVdd servicioSigep = rechazoDeSolicitud(codTipoOperacion, codSolicitudorig, statusCode, consent, parametros);
		return execWSServicioServicioSigepVdd(servicioSigep, codTipoOperacion, codSolicitudorig, parametros);

	}

	private ServicioSigepVdd actualizarConfirmacionDebito(String codTipoOperacion, Solicitud solicitudTO, Map<String, Object> parametros) {

		Map<String, SocSolicitudctas> socSolicitudctasMap= new HashMap<String, SocSolicitudctas>();
		
		for (SocSolicitudctas socSolicitudctas : solicitudTO.getSocSolicitudctasLista()) {
			socSolicitudctasMap.put(socSolicitudctas.getId().getTipoCuenta(), socSolicitudctas);
		}

		
		ServicioSigepVdd servicioSigep = new ServicioSigepVdd();
		
		servicioSigep.setTipoOperacion(codTipoOperacion);
		servicioSigep.setFechaHora(UtilsDate.stringFromDate(solicitudTO.getSolicitud().getFechaReg(), "dd-MM-yyyy hh:mm:ss"));
		servicioSigep.setIdMensajeOrigen(UtilsDate.stringFromDate(new Date(), "yyyyMMdd") + "-" + UtilsGeneric.generateUUID().replaceAll("-", ""));
		servicioSigep.setCodSolicitud(solicitudTO.getSolicitud().getCodSolicitudorig());

		List<SocDetallessol> socDetallessolLista = solicitudTO.getSocDetallessolLista();
		if (socDetallessolLista.size() > 0){
			if (socDetallessolLista.get(0).getFechaHora() != null)
			servicioSigep.setFechaTransferencia(UtilsDate.stringFromDate(socDetallessolLista.get(0).getFechaHora(), "dd-MM-yyyy hh:mm:ss"));			

		}		
		DetallesSolicitud detallesSolicitud = new DetallesSolicitud();

		int ultben = 1;
		
		for (SocDetallessol socDetallessol : socDetallessolLista) {
			DetalleSolicitud detalleSolicitud = new DetalleSolicitud();

			detalleSolicitud.setCodDetalle(socDetallessol.getId().getDetCodigo());
			detalleSolicitud.setCodBeneficiario(socDetallessol.getBenCodigo());
			detalleSolicitud.setMontoTransferido(socDetallessol.getDetMontotrans());
			
			if (socDetallessol.getCodMonedatdet() != null)
				detalleSolicitud.setCodMonedaTransferido(socDetallessol.getCodMonedatdet().toString());
			if (solicitudTO.getSolicitud().getSocTipoc() != null)
				detalleSolicitud.setTipoCambioTransferido(solicitudTO.getSolicitud().getSocTipoc().setScale(5, BigDecimal.ROUND_HALF_UP));
			
			MontosDetalle montosDetalle = new MontosDetalle();

			MontoDetalle montoDetalle = new MontoDetalle();
			montoDetalle = new MontoDetalle();
			SocOpecomi socOpecomi = solicitudTO.buscarClaComision("MONTOTRANS", socDetallessol.getId().getDetCodigo());
			if (socOpecomi != null) {
				montoDetalle.setCodMonto("MONTOTRANS");
				montoDetalle.setMonto(socOpecomi.getMontoMo());
				montoDetalle.setCodMoneda(socOpecomi.getCodMoneda().toString());
				if (socOpecomi.getTipoCambio() != null)
					montoDetalle.setTipoCambio(socOpecomi.getTipoCambio().setScale(5, BigDecimal.ROUND_HALF_UP));
				montoDetalle.setNroCuenta(socSolicitudctasMap.get(Constants.COD_CLAVE_MOVPROVISION).getNroCuenta());
				montosDetalle.getMontoDetalle().add(montoDetalle);
			}

			montoDetalle = new MontoDetalle();
			socOpecomi = solicitudTO.buscarClaComision(Constants.COD_VAR_COMTRANSF, socDetallessol.getId().getDetCodigo());
			if (socOpecomi != null) {
				montoDetalle.setCodMonto("COMCTRA");
				montoDetalle.setMonto(socOpecomi.getMontoMo());
				montoDetalle.setCodMoneda(socOpecomi.getCodMoneda().toString());
				if (socOpecomi.getTipoCambio() != null)				
					montoDetalle.setTipoCambio(socOpecomi.getTipoCambio().setScale(5, BigDecimal.ROUND_HALF_UP));
				montoDetalle.setNroCuenta(socSolicitudctasMap.get(Constants.COD_CLAVE_COMCTRA).getNroCuenta());
				montosDetalle.getMontoDetalle().add(montoDetalle);
			}

			montoDetalle = new MontoDetalle();
			socOpecomi = solicitudTO.buscarClaComision("COMSWIFT", socDetallessol.getId().getDetCodigo());
			if (socOpecomi != null) {
				montoDetalle.setCodMonto(socOpecomi.getId().getClaComision());
				montoDetalle.setMonto(socOpecomi.getMontoMo());
				montoDetalle.setCodMoneda(socOpecomi.getCodMoneda().toString());
				if (socOpecomi.getTipoCambio() != null)				
					montoDetalle.setTipoCambio(socOpecomi.getTipoCambio().setScale(5, BigDecimal.ROUND_HALF_UP));
				montoDetalle.setNroCuenta(socSolicitudctasMap.get(Constants.COD_CLAVE_COMGADM).getNroCuenta());
				montosDetalle.getMontoDetalle().add(montoDetalle);
			}

			if (socDetallessolLista.size() == ultben) {
				montoDetalle = new MontoDetalle();
				socOpecomi = solicitudTO.buscarClaComision("COMUTIL", 0);
				if (socOpecomi != null) {
					montoDetalle.setCodMonto(socOpecomi.getId().getClaComision());
					montoDetalle.setMonto(socOpecomi.getMontoMo());
					montoDetalle.setCodMoneda(socOpecomi.getCodMoneda().toString());
					if (socOpecomi.getTipoCambio() != null)				
						montoDetalle.setTipoCambio(socOpecomi.getTipoCambio().setScale(5, BigDecimal.ROUND_HALF_UP));
					montoDetalle.setNroCuenta(socSolicitudctasMap.get(Constants.COD_CLAVE_COMGADM).getNroCuenta());
					montosDetalle.getMontoDetalle().add(montoDetalle);
				}
				
				montoDetalle = new MontoDetalle();
				socOpecomi = solicitudTO.buscarClaComision("DIFERTC", 0);

				if (socOpecomi != null && socOpecomi.getMontoMo() != null && socOpecomi.getMontoMo().compareTo(BigDecimal.ZERO) != 0) {
					montoDetalle.setCodMonto(socOpecomi.getId().getClaComision());
					montoDetalle.setMonto(socOpecomi.getOcoMonto());
					montoDetalle.setCodMoneda(socOpecomi.getCodMoneda().toString());
					if (socOpecomi.getTipoCambio() != null)					
						montoDetalle.setTipoCambio(socOpecomi.getTipoCambio().setScale(5, BigDecimal.ROUND_HALF_UP));
					montoDetalle.setNroCuenta(socSolicitudctasMap.get(Constants.COD_CLAVE_DIFCAMB).getNroCuenta());
					montosDetalle.getMontoDetalle().add(montoDetalle);
				}
			}
			detalleSolicitud.getMontosDetalle().add(montosDetalle);
			detallesSolicitud.getDetalleSolicitud().add(detalleSolicitud);
			ultben++;			
		}
		servicioSigep.setDetallesSolicitud(detallesSolicitud);

		return servicioSigep;
	}
	
	public ServicioSigepVdd rechazoDeSolicitud(String codTipoOperacion, String codSolicitudorig, String statusCode, String consent,
			Map<String, Object> parametros) {

		ServicioSigepVdd servicioSigep = new ServicioSigepVdd();
		servicioSigep.setTipoOperacion(codTipoOperacion);
		servicioSigep.setFechaHora(UtilsDate.stringFromDate(new Date(), "dd-MM-yyyy hh:mm:ss"));
		servicioSigep.setIdMensajeOrigen(UtilsDate.stringFromDate(new Date(), "yyyyMMdd") + "-" + UtilsGeneric.generateUUID().replace("-", ""));
		servicioSigep.setCodSolicitud(codSolicitudorig);

		SolicitudRespuesta solicitudRespuesta = new SolicitudRespuesta();
		solicitudRespuesta.setCodEstadoResp(statusCode);
		solicitudRespuesta.setDesEstadoResp(consent);

		servicioSigep.setSolicitudRespuesta(solicitudRespuesta);

		return servicioSigep;
	}

	private Object transformaXML(String mensajeXML) {

		Object mensajeJAXB = null;
		log.info("=======> inicio mensaje XML <========");
		log.info(mensajeXML);
		log.info("=======> fin mensaje XML <========");
		try {
			JAXBContext context = JAXBContext.newInstance(RespuestaSigepVdd.class);
			mensajeJAXB = JAXBHelper.convertXMLToMsgBcb(mensajeXML, context);
		} catch (Exception e) {
			log.error("Error al desparseo: " + e.getMessage(), e);
			throw new WebServClientException(e);
		}

		return mensajeJAXB;
	}

	private String transformaXML(ServicioSigepVdd servicioSigep) {
		String mensajeXML = null;
		try {

			JAXBContext context = JAXBContext.newInstance(ServicioSigepVdd.class);
			Document doc = JAXBHelper.toDocument(servicioSigep, documentBuilderFactory, context);
			mensajeXML = XmlUtils.getStringFromDom(doc);

		} catch (JAXBException e) {
			throw new WebServClientException(e);
		} catch (ParserConfigurationException e) {
			throw new WebServClientException(e);
		} catch (TransformerException e) {
			throw new WebServClientException(e);
		}

		return mensajeXML;
	}

}
