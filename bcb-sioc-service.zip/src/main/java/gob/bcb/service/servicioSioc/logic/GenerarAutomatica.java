package gob.bcb.service.servicioSioc.logic;

import gob.bcb.bpm.pruebaCU.FactoryDao;
import gob.bcb.bpm.pruebaCU.QueryProcessor;
import gob.bcb.bpm.pruebaCU.Servicios;
import gob.bcb.bpm.pruebaCU.SocComprobante;
import gob.bcb.bpm.pruebaCU.SocComprobanteDao;
import gob.bcb.bpm.pruebaCU.SocDetallesope;
import gob.bcb.bpm.pruebaCU.SocDetallesopeDao;
import gob.bcb.bpm.pruebaCU.SocDetallesopeId;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocFacturas;
import gob.bcb.bpm.pruebaCU.SocFacturasDao;
import gob.bcb.bpm.pruebaCU.SocOpecomi;
import gob.bcb.bpm.pruebaCU.SocOpecomiDao;
import gob.bcb.bpm.pruebaCU.SocOpecomiId;
import gob.bcb.bpm.pruebaCU.SocOperaciones;
import gob.bcb.bpm.pruebaCU.SocOperacionesDao;
import gob.bcb.bpm.pruebaCU.SocRengscomp;
import gob.bcb.bpm.pruebaCU.SocRengscompDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.joda.time.DateTime;

/**
 * Clase que contiene los metodos para generar las operaciones automáticas.
 * Transferencias locales, Pago regalías, Pago IDH
 * 
 * @author C. Cecilia Uriona
 * 
 */

public class GenerarAutomatica {

	private static final Log log = LogFactory.getLog(GenerarAutomatica.class);
	private static final char AUTORIZADO = 'A';

	public static void generarAutomatica(FactoryDao factoryDao, SocSolicitudes solicitud, SocDetallessol detalle, BigDecimal tcUS, String usuario,
			String estacion, String tipo) {

		log.info("Generar operación:" + detalle.getId().getSocCodigo());

		Date fechaValor = new Date();
		log.info("Fecha de la operación: " + fechaValor);

		// generando la operaci�n
		SocOperaciones operacion = new SocOperaciones();
		operacion.setSolCodigo(solicitud.getSolCodigo());
		operacion.setClaOperacion(solicitud.getClaTipo());
		operacion.setOpeFecha(fechaValor);
		operacion.setOpeMontome(solicitud.getSocMontome());
		String moneda = solicitud.getMoneda();

		int mon = Servicios.getMoneda(moneda);

		operacion.setMoneda(mon);
		operacion.setOpeCtaoperacion(solicitud.getSocCuentad());
		operacion.setOpeCtacomision(solicitud.getSocCuentac());
		operacion.setOpeNrocuentac(solicitud.getSocNrocuentac());
		operacion.setSocCorrelativo(solicitud.getSocCorrelativo());
		operacion.setSocCodigo(solicitud.getSocCodigo());
		operacion.setClaEstado(AUTORIZADO);
		operacion.setUsrCodigo(usuario);
		Date hoy = new Date();
		operacion.setFechaHora(hoy);
		operacion.setEstacion(estacion);
		String codOperacion = Long.toString(hoy.getTime());
		operacion.setOpeCodigo(codOperacion);

		BigDecimal tc = BigDecimal.ONE;
		if (mon == 34) {
			tc = tcUS;
		}

		final BigDecimal montoMN = solicitud.getSocMontome().multiply(tc);
		operacion.setOpeMontomn(montoMN);

		SocOperacionesDao socOperacionesDao = (SocOperacionesDao) factoryDao.getDao("socOperacionesDao");
		socOperacionesDao.saveOrUpdate(operacion);
		log.info("Operación generada: ");

		SocDetallesope detOpe = new SocDetallesope();
		SocDetallesopeId id = new SocDetallesopeId(codOperacion, 1);
		detOpe.setId(id);
		detOpe.setBenCodigo(detalle.getBenCodigo());
		detOpe.setDetMonto(solicitud.getSocMontome());
		detOpe.setMoneda(mon);
		Integer cta = detalle.getDetCtabenef();
		detOpe.setDetCtabenef(Integer.toString(cta));
		detOpe.setDetConcepto(detalle.getDetConcepto());

		SocDetallesopeDao socDetallesopeDao = (SocDetallesopeDao) factoryDao.getDao("socDetallesopeDao");
		socDetallesopeDao.saveOrUpdate(detOpe);
		log.info("Detalle generado: ");

		generarComisiones1(factoryDao, codOperacion, solicitud, tc);

		String codComprobante1 = null;
		DateTime hoy2 = new DateTime();
		Date hoy1 = new Date();

		codComprobante1 = Long.toString(hoy1.getTime());
		SocComprobante comprobante1 = new SocComprobante(codComprobante1, codOperacion, hoy2.getYear(), hoy2.getMonthOfYear(), hoy2.getDayOfMonth(),
				tcUS, "TRANSFERENCIA DE FONDOS SEGÚN SOLICITUD " + solicitud.getSocCorrelativo() + " REF.: " + detalle.getDetConcepto());

		SocComprobanteDao comprobanteDao = (SocComprobanteDao) factoryDao.getDao("socComprobanteDao");
		comprobanteDao.saveOrUpdate(comprobante1);

		log.info("Comprobante guardado: ");

		String subTipo = "";

		// CCUH SIOC V.2
		// R-04 Incluir opciones separadas para IDH, Regalías
		// Se crearon opciones separadas para generar comprobantes
		// 01-07-2013

		if (tipo.equals("TC")) { // transferencia a cuentas locales
			if (solicitud.getSocCuentac() != null) { // con cuenta de comisiones
				if (solicitud.getSocCuentad().equals(solicitud.getSocCuentac())) { // comisiones
																					// de
																					// la
																					// misma
																					// cuenta
					if (moneda.equals("USD")) { // cuenta en dólares
						subTipo = "CC";
					} else { // cuenta en bolivianos
						subTipo = "CB";
					}
				} else { // comisiones de otra cuenta
					if (moneda.equals("USD")) { // cuenta en dólares
						subTipo = "OC";
					} else { // cuenta en bolivianos
						subTipo = "OB";
					}
				}
			} else { // con comisiones al beneficiario
				if (moneda.equals("USD")) // facturar al beneficiario en dólares
					subTipo = "FB";
				else
					// facturar al beneficiario en bolivianos
					subTipo = "BB";
			}
		} else if (tipo.equals("REG")) { // pago de regalías
			subTipo = "BB";
		} else if (tipo.equals("IDH")) { // pago de IDH
			subTipo = "OC";
		}

		String query1 = "select re.det_codigo, re.cla_cuenta, re.esq_dh, re.esq_definicion, re.cla_glosa_r, re.repetible "
				+ "from soc_rengesq re, soc_esquemas ee " + "where re.esq_codigo = ee.esq_codigo " + "and ee.cla_operacion = 'TC' "
				+ "and ee.cla_subtipo = '" + subTipo + "'";

		String tipoOperacion = "TC";
		List<Map<String, Object>> resultado1 = Servicios.obtenerEsquema(tipoOperacion, subTipo);

		log.info("Inicio de creacion de renglones, solicitud:" + solicitud.toString());
		List<SocDetallessol> detalles = new ArrayList<SocDetallessol>();
		detalles.add(detalle);

		SocRengscompDao rengsCompDao = (SocRengscompDao) factoryDao.getDao("socRengscompDao");
		List<SocRengscomp> renglones = rengsCompDao.CrearRenglones(codComprobante1, resultado1, solicitud, detalles);

		query1 = "select ren_codigo " + "from soc_rengscomp " + "where cpb_codigo = '" + codComprobante1 + "' " + "and ren_afectable = '001564'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query1, "ren_codigo".split(","));
		
		for (Map<String, Object> res : resultado) {

			Integer nro = (Integer) res.get("ren_codigo");
			SocFacturasDao facturasDao = (SocFacturasDao) factoryDao.getDao("socFacturasDao");
			if (subTipo.equals("FB") || subTipo.equals("BB"))
				facturasDao.crearFactura(codComprobante1, nro, detalle.getBenCodigo(), 'B');
			else
				facturasDao.crearFactura(codComprobante1, nro, solicitud.getSolCodigo());
		}
		QueryProcessor.flush();
		SocComprobanteDao socCompDao = (SocComprobanteDao) factoryDao.getDao("socComprobanteDao");
		SocComprobante comp = (SocComprobante) socCompDao.getComprobante(codComprobante1);

		SocRengscompDao socRengscompDao = (SocRengscompDao) factoryDao.getDao("socRengscompDao");
		List<SocRengscomp> rengs = socRengscompDao.getRenglones(codComprobante1);

		SocFacturasDao socFacturasDao = (SocFacturasDao) factoryDao.getDao("socFacturasDao");
		List<SocFacturas> facts = socFacturasDao.getFacturas(codComprobante1);
		QueryProcessor.flush();
		Map<String, Object> mapaParametros2 = new HashMap<String, Object>();
		mapaParametros2.put("consulta", "crear");
		mapaParametros2.put("comp", comp);
		mapaParametros2.put("rengs", rengs);
		mapaParametros2.put("facts", facts);

		log.info("Llamando al servicio de coin: crear comprobante");
		Map<String, Object> mapaResultado2;

		SiocCoinService siocCoinService = new SiocCoinService();
		mapaResultado2 = siocCoinService.executeTask(mapaParametros2);

		String nroComprob = (String) mapaResultado2.get("comp");
		if (!nroComprob.equals("") && !nroComprob.equals("0000000")) {
			if (!nroComprob.equals("9999999")) {
				log.info("Comprobante coin creado: " + nroComprob);
			} else {
				log.info("Existe sobregiro en cuentas");
			}
		} else {
			log.info("Error al crear comprobante coin");
		}
	}

	private static void generarComisiones1(FactoryDao factoryDao, String codOperacion, SocSolicitudes solicitud, BigDecimal tc) {
		throw new RuntimeException("Operacion TC no implementada, avise a sistemas.");
//		SocOpecomiId id3 = new SocOpecomiId("3", codOperacion, 1);
//		final BigDecimal montoComi3 = BigDecimal.valueOf(Double.valueOf(Servicios.getComision("UTIL")));
//		SocOpecomi opeComi3 = new SocOpecomi(id3, montoComi3);
//
//		SocOpecomiDao socOpecomiDao = (SocOpecomiDao) factoryDao.getDao("socOpecomiDao");
//		opeComi3.setFechaHora(new Date());
//		
//		socOpecomiDao.saveOrUpdate(opeComi3);
//		log.info("Comisiones generadas: " + solicitud.getSocCodigo());
	}
}
