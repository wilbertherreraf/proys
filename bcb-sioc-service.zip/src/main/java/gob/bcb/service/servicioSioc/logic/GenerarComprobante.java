package gob.bcb.service.servicioSioc.logic;

import gob.bcb.bpm.pruebaCU.FactoryDao;
import gob.bcb.bpm.pruebaCU.Glosa;
import gob.bcb.bpm.pruebaCU.QueryProcessor;
import gob.bcb.bpm.pruebaCU.Servicios;
import gob.bcb.bpm.pruebaCU.SocComprobante;
import gob.bcb.bpm.pruebaCU.SocComprobanteDao;
import gob.bcb.bpm.pruebaCU.SocDetallesope;
import gob.bcb.bpm.pruebaCU.SocDetallesopeDao;
import gob.bcb.bpm.pruebaCU.SocDetallesopeId;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocFacturas;
import gob.bcb.bpm.pruebaCU.SocFacturasDao;
import gob.bcb.bpm.pruebaCU.SocOpecomi;
import gob.bcb.bpm.pruebaCU.SocOpecomiDao;
import gob.bcb.bpm.pruebaCU.SocOpecomiId;
import gob.bcb.bpm.pruebaCU.SocOperaciones;
import gob.bcb.bpm.pruebaCU.SocOperacionesDao;
import gob.bcb.bpm.pruebaCU.SocRengscomp;
import gob.bcb.bpm.pruebaCU.SocRengscompDao;
import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.service.commons.UserSessionHolder;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.joda.time.DateTime;

/**
 * Clase que contiene los metodos para generar las operaciones automÃ¡ticas.
 * Transferencias locales, Pago regalÃ­as, Pago IDH
 * 
 * @author C. Cecilia Uriona
 * 
 */

public class GenerarComprobante {

	private static final Log log = LogFactory.getLog(GenerarComprobante.class);

	public static Boolean generarComprobante(FactoryDao factoryDao, SocSolicitudes solicitud, SocDetallessol detalle, String tipoEnt,
			BigDecimal tcUS, String tipo) {
		log.info("Generando comprobante para " + solicitud.toString() + " tipoEnt: " + tipoEnt + " tipo: " + tipo + " tcUS: " + tcUS);
		Boolean continuar = false;
		String codComprobante = "";
		String tipoSol = solicitud.getClaTipo();

		// CCUH SIOC V.2
		// R-04 Incluir opciones separadas para IDH, RegalÃ­as
		// Se crearon opciones separadas para generar comprobantes
		// 01-07-2013
		if (tipo.equals("REG")) {
			tipoSol = "TC";
		} else if (tipo.equals("IDH")) {
			tipoSol = "TC";
		} else {
			if (tipoEnt.equals("SP")) {
				if (tipoSol.equals("TE"))
					tipoSol = tipoSol + "P";
			} else {
				if (tipoSol.equals("TE"))
					// transferencia al exterior
					tipoSol = tipoSol + "FP";
				else
					tipoSol = tipoSol + "F";
			}
		}
		// temporal modificar y unificar con tipoSol
		String tipoGlosaAux = tipoSol;
		String subTipo = "";
		// CCUH SIOC V.2
		// R-01 Suprimir provisiÃ³n comisiones
		// Se creÃ³ un nuevo esquema sin renglÃ³n de comisiones para
		// transferencias al exterior
		// Para transferencias con descuento de comisiones del monto ordenado se
		// realizan dos dÃ©bitos de la misma cuenta
		// Las provisiones para TC se mantienen como antes
		// 24-06-2013

		if (tipoSol.equals("TEP")) {
			if (solicitud.getSocMontoord().compareTo(BigDecimal.ZERO) == 0) {
				subTipo = "SC";
			} else { // con descuento de comisiones del monto ordenado
				// subTipo = "CD"; //1 solo dÃ©bito
				subTipo = "CC"; // 2 dÃ©bitos separados
			}

		} else {
			if (tipoSol.equals("TC")) {
				if (solicitud.getSocCuentac() != null) {
					if (solicitud.getSocCuentad().equals(solicitud.getSocCuentac())) {
						subTipo = "CC";
					} else {
						subTipo = "OC";
					}
				} else {
					subTipo = "FB";
				}
			}
		}

		if (tipoSol.equals("TC"))
			tipoSol = tipoSol + "P";

		if (tipoSol.equals("VE"))
			subTipo = "TE";

		// CCUH SIOC V.2
		// R-04 Incluir opciones separadas para IDH, RegalÃ­as
		// Se crearon opciones separadas para generar comprobantes
		// 01-07-2013
		if (tipo.equals("REG")) {
			tipoSol = "TCP";
			subTipo = "FB";
		} else if (tipo.equals("IDH")) {
			tipoSol = "TCP";
			subTipo = "OC";
		}
		log.info("Tipo de operacion:: tipo " + tipo + "; subTipo: " + subTipo + "; tipoSol: " + tipoSol);
		// //////////////////////////////
		// ya en serio!!! este es un parche para soluc el carnaval de arriba
		SocSolicitante socSolicitante = Servicios.getSocSolicitante(solicitud.getSolCodigo());
		if (socSolicitante == null) {
			throw new RuntimeException("Solicitante inexistente " + solicitud.getSolCodigo());
		}

		String sIOCWEB_TIPOPERACION = (String) UserSessionHolder.get("SIOCWEB_TIPOPERACION");
		if (sIOCWEB_TIPOPERACION.equals("SOL_PROV_FON_SIST_FIN") && solicitud.getClaTipo().equals("TE")
				&& socSolicitante.getClaEntidad().equals("SF")) {
			// autorizacion de una solicitud
			// cuenta 61
			tipoSol = "TRA_EXT_SF_PROV";
			subTipo = "CTA_CTA";
			tipoGlosaAux = tipoSol;
		}
		// /////////////////////////////////
		List<SocDetallessol> detalles = new ArrayList<SocDetallessol>();
		detalles.add(detalle);

		SocComprobanteDao comprobanteDao = (SocComprobanteDao) factoryDao.getDao("socComprobanteDao");
		codComprobante = comprobanteDao.CrearComprobante(tipoGlosaAux, solicitud, detalles);

		List<Map<String, Object>> resultado = Servicios.obtenerEsquema(tipoSol, subTipo);

		SocRengscompDao rengsCompDao = (SocRengscompDao) factoryDao.getDao("socRengscompDao");
		List<SocRengscomp> renglones = rengsCompDao.CrearRenglones(codComprobante, resultado, solicitud, detalles);

		SocComprobanteDao socCompDao = (SocComprobanteDao) factoryDao.getDao("socComprobanteDao");
		SocComprobante comp = (SocComprobante) socCompDao.getComprobante(codComprobante);

		SocRengscompDao socRengscompDao = (SocRengscompDao) factoryDao.getDao("socRengscompDao");
		List<SocRengscomp> rengs = socRengscompDao.getRenglones(codComprobante);
		QueryProcessor.flush();
		Map<String, Object> mapaParametros2 = new HashMap<String, Object>();
		mapaParametros2.put("consulta", "crear");
		mapaParametros2.put("comp", comp);
		mapaParametros2.put("rengs", rengs);

		log.info("Llamando al servicio de coin: crear comprobante");
		Map<String, Object> mapaResultado2;
		SiocCoinService siocCoinService = new SiocCoinService();
		mapaResultado2 = siocCoinService.executeTask(mapaParametros2);
		String nroComprob = (String) mapaResultado2.get("comp");

		if (StringUtils.isBlank(nroComprob)) {
			log.error("El servicio contable retorno nro comprobante invalido cod: " + codComprobante);
			throw new RuntimeException("El servicio contable retorno nro comprobante invalido cod: " + codComprobante);
		}

		if (tipo.equals("PROVISION")) {
			continuar = false;
			String codComprobante1 = rengsCompDao.CrearRenglonesITF(codComprobante, solicitud.getSocCodigo(), new Date(), solicitud, detalle);
			if (!StringUtils.isBlank(codComprobante1)) {
				SocComprobante comp1 = (SocComprobante) socCompDao.getComprobante(codComprobante1);

				List<SocRengscomp> rengs1 = socRengscompDao.getRenglones(codComprobante1);
				QueryProcessor.flush();

				Map<String, Object> mapaParametros3 = new HashMap<String, Object>();
				mapaParametros3.put("consulta", "crear");
				mapaParametros3.put("comp", comp1);
				mapaParametros3.put("rengs", rengs1);
				log.info("Llamando al servicio de coin: crear comprobante");
				Map<String, Object> mapaResultado3;

				siocCoinService = new SiocCoinService();
				mapaResultado3 = siocCoinService.executeTask(mapaParametros3);

				nroComprob = (String) mapaResultado3.get("comp");
				if (StringUtils.isBlank(nroComprob)) {
					log.error("El servicio contable retorno nro comprobante invalido cod: " + codComprobante1);
					throw new RuntimeException("El servicio contable retorno nro comprobante invalido cod: " + codComprobante1);
				}
				continuar = true;				
			}
			continuar = true;
		} else {
			// operacion diferente a TRA
			continuar = true;
		}
		return continuar;
	}

	public static Boolean generarComprobante(FactoryDao factoryDao, SocSolicitudes solicitud, List<SocDetallessol> detalles, String subTipo,
			BigDecimal tcUS) {

		String codComprobante = "";
		String tipo = "";
		if (solicitud.getClaTipo().equals("VE")) {
			tipo = "VEP";
			if (solicitud.getSocCuentad() == 5) // SIGMA
				subTipo = subTipo + "";
			else { // cuenta fiscal
					// CCUH SIOC V.2
					// R-03 Suprimir provisiÃ³n comisiones en Ventas a travÃ©s
					// de
					// cuenta fiscal
					// Se creÃ³ un nuevo esquema sin renglones de comisiones
					// para VE
					// 03-07-2013
				subTipo = "SC";
			}
		}

		SocComprobanteDao comprobanteDao = (SocComprobanteDao) factoryDao.getDao("socComprobanteDao");
		codComprobante = comprobanteDao.CrearComprobante(tipo, solicitud, detalles);

		String tipoOperacion = tipo;
		List<Map<String, Object>> resultado = Servicios.obtenerEsquema(tipoOperacion, subTipo);

		SocRengscompDao rengsCompDao = (SocRengscompDao) factoryDao.getDao("socRengscompDao");
		rengsCompDao.CrearRenglones(codComprobante, resultado, solicitud, detalles);

		QueryProcessor.flush();
		SocComprobanteDao socCompDao = (SocComprobanteDao) factoryDao.getDao("socComprobanteDao");
		SocComprobante comp = (SocComprobante) socCompDao.getComprobante(codComprobante);

		SocRengscompDao socRengscompDao = (SocRengscompDao) factoryDao.getDao("socRengscompDao");
		List<SocRengscomp> rengs = socRengscompDao.getRenglones(codComprobante);
		Map<String, Object> mapaParametros2 = new HashMap<String, Object>();
		mapaParametros2.put("consulta", "crear");
		mapaParametros2.put("comp", comp);
		mapaParametros2.put("rengs", rengs);

		log.info("Llamando al servicio de coin: crear comprobante");
		Map<String, Object> mapaResultado2;

		SiocCoinService siocCoinService = new SiocCoinService();
		mapaResultado2 = siocCoinService.executeTask(mapaParametros2);

		String nroComprob = (String) mapaResultado2.get("comp");
		if (StringUtils.isBlank(nroComprob)) {
			log.error("El servicio contable retorno nro comprobante invalido cod: " + codComprobante);
			throw new RuntimeException("El servicio contable retorno nro comprobante invalido cod: " + codComprobante);
		}

		return true;
	}
}
