package gob.bcb.service.servicioSioc.dao;

import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;

import java.util.Date;
import java.util.List;

public interface SocSolicitudesDaoLocal {

	public abstract void saveOrUpdate(SocSolicitudes pm);

	public abstract void saveOrUpdateSinAud(SocSolicitudes pm);

	public abstract SocSolicitudes getSolicitud(String solicitudId);

	public abstract List<SocSolicitudes> getSolicitudesSF(String solicitante);

	public abstract SocSolicitudes generarSolicitud(SocSolicitudes solicitud);

	public abstract SocSolicitudes generarSolicitud(SocSolicitudes solicitud, SocDetallessol detalle, Integer codDetalle);

	/****************************************************/
	public abstract SocSolicitudes getByCodSolicitudorig(String codSolicitudorig);

	public abstract List<SocSolicitudes> solicitudesPendientes(Date fecha, Date fechaReg, Character claEstado, String claEstadows);

	public abstract void eliminarSolicitud(SocSolicitudes solicitud);

	public abstract SocSolicitudes crearActualizar(SocSolicitudes solicitud);

	public abstract SocSolicitudes cambiarEstadoSolicitud(SocSolicitudes solicitud, Character nuevoEstado, String claEstadows, String tipo);

	public abstract String generarCodSolicitud();

}