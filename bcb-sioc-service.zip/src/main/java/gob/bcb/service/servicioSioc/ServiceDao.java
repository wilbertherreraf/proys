package gob.bcb.service.servicioSioc;

import gob.bcb.service.servicioSioc.dao.SocSolicitudesDaoLocal;

public interface ServiceDao {

	SocSolicitudesDaoLocal getSocSolicitudesDaoLocal();

}
