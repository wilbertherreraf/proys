package gob.bcb.service.servicioSioc.logic;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.SessionFactory;

import gob.bcb.bpm.pruebaCU.Beneficiario;
import gob.bcb.bpm.pruebaCU.CuentasBen;
import gob.bcb.bpm.pruebaCU.SocBenefsDao;
import gob.bcb.bpm.pruebaCU.SocComprobante;
import gob.bcb.bpm.pruebaCU.SocComprobanteDao;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocDetallessolDao;
import gob.bcb.bpm.pruebaCU.SocEsquemas;
import gob.bcb.bpm.pruebaCU.SocEsquemasDao;
import gob.bcb.bpm.pruebaCU.SocHorario;
import gob.bcb.bpm.pruebaCU.SocHorarioDao;
import gob.bcb.bpm.pruebaCU.SocOpecomi;
import gob.bcb.bpm.pruebaCU.SocOpecomiDao;
import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.bpm.pruebaCU.SocSolicitanteDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudctas;
import gob.bcb.bpm.pruebaCU.SocSolicitudctasDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.SocSolicitudesDao;
import gob.bcb.bpm.pruebaCU.SocUsuariosolDao;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.core.utils.FirmaDigHelper;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.core.utils.UtilsFile;
import gob.bcb.service.commons.ConfigurationServ;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.mail.MsgLogic;
import gob.bcb.service.servicioSioc.ws.MensajeSiocTO;
import gob.bcb.service.servicioSioc.ws.xml.consultasolic.CuentaSolicitud;
import gob.bcb.service.servicioSioc.ws.xml.consultasolic.DetalleSolicitud;
import gob.bcb.service.servicioSioc.ws.xml.consultasolic.Factura;
import gob.bcb.service.servicioSioc.ws.xml.consultasolic.ServicioSioc;
import gob.bcb.service.servicioSioc.wssigepclient.ClientSigepWSHandler;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;

public class RegistrarSolicitud {
	private static final Log log = LogFactory.getLog(RegistrarSolicitud.class);

	public static List<String> operacionesProvision = new ArrayList<String>();
	static {
		operacionesProvision.add("V01");
		operacionesProvision.add("V02");
		operacionesProvision.add("V03");
		operacionesProvision.add("V04");
		operacionesProvision.add("V05");
		operacionesProvision.add("V06");
		operacionesProvision.add("V07");
		operacionesProvision.add("V08");
		operacionesProvision.add("V09");
		operacionesProvision.add("V10");
		operacionesProvision.add("T01");
		operacionesProvision.add("T02");
		operacionesProvision.add("T03");
		operacionesProvision.add("T04");
		operacionesProvision.add("T05");
	}

	private SocEsquemasDao socEsquemasDao = new SocEsquemasDao();
	private SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
	private SocDetallessolDao socDetallessolDao = new SocDetallessolDao();
	private SocBenefsDao socBenefsDao = new SocBenefsDao();
	private CalcularVariables calcularVariables;
	private SocSolicitudctasDao socSolicitudctasDao = new SocSolicitudctasDao();
	private SocSolicitudesDao socSolicitudesDao = new SocSolicitudesDao();
	private SocOpecomiDao socOpecomiDao = new SocOpecomiDao();
	private SocComprobanteDao comprobanteDao = new SocComprobanteDao();
	private SocUsuariosolDao socUsuariosolDao = new SocUsuariosolDao();
	private SessionFactory sessionFactory;
	private SocHorarioDao socHorarioDao = new SocHorarioDao();

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
		socEsquemasDao.setSessionFactory(getSessionFactory());
		socSolicitanteDao.setSessionFactory(getSessionFactory());
		socDetallessolDao.setSessionFactory(getSessionFactory());
		socBenefsDao.setSessionFactory(getSessionFactory());
		calcularVariables = new CalcularVariables(getSessionFactory());
		socSolicitudctasDao.setSessionFactory(getSessionFactory());
		socSolicitudesDao.setSessionFactory(getSessionFactory());
		socOpecomiDao.setSessionFactory(getSessionFactory());
		comprobanteDao.setSessionFactory(getSessionFactory());
		socHorarioDao.setSessionFactory(getSessionFactory());
		socUsuariosolDao.setSessionFactory(getSessionFactory());

//		log.info("inicializado procesossoliidtu...");
	}

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}
	
	private Solicitud recuperarSolicitantebyCodSigep(Solicitud solicitud, String solCodigo, Integer codMoneda, String claTipo, String cveSubtipooper) {
		SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCodSigep(solCodigo);

		SocSolicitudes socSolicitudes = new SocSolicitudes();
		socSolicitudes.setSolCodigo(socSolicitante.getSolCodigo());
		socSolicitudes.setCodMonedat(codMoneda);
		socSolicitudes.setClaTipo(claTipo);
		socSolicitudes.setCveSubtipooper(cveSubtipooper);

		log.info("Entre a recuperarSolicitud con el id: [" + socSolicitudes.getSolCodigo() + "] ");
		solicitud.setSocSolicitante(socSolicitante);

		solicitud.setSolicitud(socSolicitudes);

		List<Beneficiario> beneficiarios = socBenefsDao.recuperarBeneficiariosSolicitante(socSolicitudes, null, socSolicitudes.getCodMonedat(),
				Short.valueOf("1"), true);

		for (Beneficiario beneficiario : beneficiarios) {
			List<CuentasBen> listaCuentasB = socBenefsDao.recuperarCuentasB(socSolicitudes, beneficiario.getBenCodigo(),
					socSolicitudes.getCodMonedat(), null, null, null, null);

			beneficiario.setCuentasBenLista(listaCuentasB);
		}

		solicitud.setBeneficiarioLista(beneficiarios);

		log.info("cuentas Solicitantes recuperadas: " + socSolicitudes.getSolCodigo() + " " + beneficiarios.size());

		return solicitud;
	}
	
	private String consultaDeOperacion(String socCodigoOrigen) {
		log.info("Entre a consultaDeOperacion " + socCodigoOrigen);
		SocSolicitudes socSolicitudesOrig = socSolicitudesDao.getByCodSolicitudorig(socCodigoOrigen);

		if (socSolicitudesOrig == null) {
			log.error("Codigo solicitud origen " + socCodigoOrigen + " inexistente.");
			throw new BusinessException("Solicitud [" + socCodigoOrigen + "] inexistente.");
		}

		if (socSolicitudesOrig.getClaEstado().equals(Constants.CLAVE_ESTSOLIC_ANULADO)) {
			log.error("Error solicitud [" + socSolicitudesOrig.getSocCodigo() + "] con estado invalido '"
					+ socSolicitudesOrig.getClaEstado()
					+ "' requiere estar contabilizado, no se puede notificar");
			throw new BusinessException("Solicitud [" + socCodigoOrigen + "] anulado.");
		}
		
		if (socSolicitudesOrig.getClaEstadows().equals(Constants.CLAVE_ESTWS_REVERT)) {
			throw new BusinessException("Solicitud [" + socCodigoOrigen + "] revertida.");
		}
		
		if (!socSolicitudesOrig.getClaEstado().equals(Constants.CLAVE_ESTSOLIC_CONTAB)) {
			log.error("Error solicitud [" + socSolicitudesOrig.getSocCodigo() + "] con estado invalido '"
					+ socSolicitudesOrig.getClaEstado()
					+ "' requiere estar contabilizado, no se puede notificar");
			throw new BusinessException("Solicitud [" + socCodigoOrigen + "] pendiente de proceso.");
		}
		
		Boolean esCartas = (socSolicitudesOrig.getClaTipo().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS)
				|| socSolicitudesOrig.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS));
		
		Solicitud solicitud = new Solicitud(); 
		if (esCartas) {
			CartasCredService cartasCredService = new CartasCredService(getSessionFactory(), SiocCoinService.getSessionFactory());
			solicitud = cartasCredService.recuperarCartaYDetalleParaSolicitud(socSolicitudesOrig.getSocCodigo());
			solicitud.setSolicitud(socSolicitudesOrig);			
		} else {
			ProcesosSolicitud procesosSolicitud = new ProcesosSolicitud();
			procesosSolicitud.setSessionFactory(getSessionFactory());			
			solicitud = procesosSolicitud.recuperarSolicitudSimple(socSolicitudesOrig.getSocCodigo());			
		}

		List<SocSolicitudctas> socSolicitudctasLista = socSolicitudctasDao.getCuentas(solicitud.getSolicitud().getSocCodigo());
		solicitud.setSocSolicitudctasLista(socSolicitudctasLista);
		
		ClientSigepWSHandler clientSigepWSHandler = new ClientSigepWSHandler(getSessionFactory(), SiocCoinService.getSessionFactory());		
		String confirmacionDebitofirmado = clientSigepWSHandler.confirmacionDebitoXMLFirmado(solicitud);
		
		if (!solicitud.getSolicitud().getClaEstadows().equals(Constants.CLAVE_ESTWS_NOTIF)) {
			socSolicitudesDao.cambiarEstadoSolicitud(solicitud.getSolicitud(), null, Constants.CLAVE_ESTWS_NOTIF);		
		}
		return confirmacionDebitofirmado;
	}
	
	public Solicitud registrarSolicitud(Solicitud solicitud) {
		log.info("Entre a registrarSolicitud " + solicitud.getCodUsuarioAudit());
		SocSolicitudes socSolicitudes = solicitud.getSolicitud();

		SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCod(socSolicitudes.getSolCodigo());
		solicitud.setSocSolicitante(socSolicitante);

		SocEsquemas socEsquemas = socEsquemasDao.esquemaByCod(socSolicitudes.getEsqCodigo());
		solicitud.setSocEsquemas(socEsquemas);

		// ////
		socHorarioDao.controlHorario(solicitud, socEsquemas, "REG");

		socSolicitudes.setUsrCodreg(solicitud.getCodUsuarioAudit());
		socSolicitudes.setUsrCodigo(solicitud.getCodUsuarioAudit());
		socSolicitudes.setEstacion(solicitud.getCodEstacionAudit());

		SocSolicitudes socSolicitudesNew = socSolicitudesDao.crearActualizar(socSolicitudes);

		solicitud.setSolicitud(socSolicitudesNew);

		List<SocDetallessol> socDetallessolLista = socDetallessolDao.crearActualizarDetalles(socSolicitudesNew, solicitud.getSocDetallessolLista());

		solicitud.setSocDetallessolLista(socDetallessolLista);

		socSolicitudctasDao.crearSolicitudctasLista(socSolicitudesNew, solicitud.getSocSolicitudctasLista(), socDetallessolLista);
		socSolicitudctasDao.completarCtasMovDestino(socSolicitudesNew);
		socSolicitudctasDao.validarCuentas(socSolicitudesNew);

		// eliminamos variables calculadas
		socOpecomiDao.eliminarRegs(socSolicitudes.getSocCodigo(), "F");
		socOpecomiDao.eliminarRegs(socSolicitudes.getSocCodigo(), "V");

		if (socSolicitudes.getCveTipctasolic().equals(Constants.CLAVE_GENERADOPOR_WS)) {
			if (solicitud.getSocOpecomiLista() != null) {
				// registro de facturas
				socOpecomiDao.crearSocOpecomiLista(socSolicitudesNew, solicitud.getSocOpecomiLista());
			}
		}

		socOpecomiDao.recuperarFacturas(socSolicitudesNew, socDetallessolLista);

		comprobanteDao.eliminarComprobante(socSolicitudesNew.getSocCodigo(), null, null);
		log.info("Solicitud creada !! " + socSolicitudesNew.toString());
		return solicitud;
	}

	public Solicitud registrarSolicitudCarta(Solicitud solicitud) {
		SocEsquemas socEsquemas = socEsquemasDao.esquemaByCod(solicitud.getSolicitud().getEsqCodigo());
		
		CartasCredService cartasCredService = new CartasCredService(getSessionFactory(), SiocCoinService.getSessionFactory()); 
		socHorarioDao.controlHorario(solicitud, socEsquemas, "REG");
		
		cartasCredService.crearCartascrParaSolicitudDeEmision(solicitud);
			
		return cartasCredService.inicilizaORecuperaEmisionCarta(solicitud.getSolicitud().getSocCodigo());
	}	
	
	public Solicitud registrarCartaPagoEnmienda(Solicitud solicitud) {
		
		SocEsquemas socEsquemas = socEsquemasDao.esquemaByCod(solicitud.getSolicitud().getEsqCodigo());
		
		CartasCredService cartasCredService = new CartasCredService(getSessionFactory(), SiocCoinService.getSessionFactory()); 
		socHorarioDao.controlHorario(solicitud, socEsquemas, "REG");
		
		Integer nroccreddet = cartasCredService.guardarOActualizarPagoEnmienda(solicitud);
	
		Solicitud solicitudTO = cartasCredService.inicializarSolicitudParaPagoEnmienda(solicitud.getCarCartascr().getCcrCodcartacr(), nroccreddet, solicitud);
		
		solicitudTO = registrarSolicitud(solicitudTO);
		
		cartasCredService.asignarSocDetallessolACarCartascrdet(solicitud.getCarCartascr().getCcrCodcartacr(), nroccreddet, solicitudTO.getSocDetallessolLista().get(0).getId().getSocCodigo(),
				solicitudTO.getSocDetallessolLista().get(0).getId().getDetCodigo()) ;

		solicitudTO = cartasCredService.recuperarDatosCartaParaCodcartacr(solicitud.getCarCartascr().getCcrCodcartacr(), nroccreddet);
		return solicitudTO;
	}

	public Solicitud actualizarCartaSinEnmienda(Solicitud solicitud) {
		CartasCredService cartasCredService = new CartasCredService(getSessionFactory(), SiocCoinService.getSessionFactory()); 
		cartasCredService.guardarCartascrSinEnmienda(solicitud);
		return solicitud;
	}
	
	/**
	 * Registra una solicitud proveniente del WS del MEFP 
	 * @param solicitud
	 * @param servicioSioc
	 * @return
	 */
	private Solicitud crearFromServicioSioc(Solicitud solicitud, ServicioSioc servicioSioc) {
		log.info("Entre a crearFromServicioSioc ");

		SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCodSigep(servicioSioc.getDatosOperacion().getSolicitud().getCodEntidad());
		solicitud.setSocSolicitante(socSolicitante);

		SocSolicitudes socSolicitudesOrig = socSolicitudesDao.getByCodSolicitudorig(servicioSioc.getDatosOperacion().getSolicitud()
				.getCodSolicitudOrigen());

		if (socSolicitudesOrig != null) {
			log.error("Codigo solicitud origen " + socSolicitudesOrig.getCodSolicitudorig() + " duplicada, registrada en solicitud "
					+ socSolicitudesOrig.getSocCodigo());
			throw new BusinessException("Codigo solicitud origen " + servicioSioc.getDatosOperacion().getSolicitud().getCodSolicitudOrigen()
					+ " duplicada, registrada en solicitud " + socSolicitudesOrig.getSocCodigo());
		}

		SocSolicitudes socSolicitudes = socSolicitudesDao.fromServicioSioc(servicioSioc, Constants.COD_IFA_MEFP, Constants.CLAVE_GENERADOPOR_WS);
		socSolicitudes.setEstacion(solicitud.getCodEstacionAudit());
		socSolicitudes.setUsrCodigo(solicitud.getCodUsuarioAudit());
		
		SocEsquemas socEsquemas = socEsquemasDao.esquemaByCod(socSolicitudes.getEsqCodigo());
		socHorarioDao.controlHorario(solicitud, socEsquemas, "WS");
		
		solicitud.setSolicitud(socSolicitudes);

		List<DetalleSolicitud> detalleSolicitudLista = servicioSioc.getDatosOperacion().getSolicitud().getDetallesSolicitud().getDetalleSolicitud();

		List<SocDetallessol> socDetallessolLista = socDetallessolDao.fromServicioSiocDetalles(socSolicitudes, detalleSolicitudLista);

		solicitud.setSocDetallessolLista(socDetallessolLista);

		List<CuentaSolicitud> cuentaSolicitudLista = servicioSioc.getDatosOperacion().getSolicitud().getCuentasSolicitud().getCuentaSolicitud();

		List<SocSolicitudctas> socSolicitudctasLista = socSolicitudctasDao.fromServicioSiocCtas(socSolicitudes, cuentaSolicitudLista);
		solicitud.setSocSolicitudctasLista(socSolicitudctasLista);

//		List<Factura> facturaLista = servicioSioc.getDatosOperacion().getSolicitud().getFacturaciones().getFactura();
		List<SocOpecomi> socOpecomiLista = socOpecomiDao.fromServicioSiocFactura(socSolicitudes, servicioSioc);

		solicitud.setSocOpecomiLista(socOpecomiLista);

		//log.info("XXX: despues de faturitas " + facturaLista.size());

		solicitud = registrarSolicitud(solicitud);

		// solicitud aprobada por el mefp
		socSolicitudes = socSolicitudesDao.cambiarEstadoSolicitud(solicitud.getSolicitud(), Constants.CLAVE_ESTSOLIC_APROBADO, null);
		solicitud.setSolicitud(socSolicitudes);

		log.info("Solicitud creada por WS " + solicitud.getSolicitud().toString());

		return solicitud;
	}

	private SocComprobante provisionarSolicitud(Solicitud solicitud, SocEsquemas socEsquemasOper) {
		// PROVISION DE FONDOS
		solicitud = calcularVariables.guardarVariablesSolicitud(solicitud, new Date());

		log.info("Provision ::> " + solicitud.getSolicitud().getSocCodigo());
		// solicitud recibida sin provisionar
		if (socEsquemasOper.getTipoTransfer().equals(Constants.CLAVE_TIPOTRANSFER_CONPROV)) {
			// si el estquema provisiona
			SocEsquemas socEsquemasPROV = socEsquemasDao.esquemaByCod(socEsquemasOper.getCodEsqref());

			// se contabiliza a fecha de recepcion
			SocComprobante socComprobante = comprobanteDao.generaComprobante(solicitud, socEsquemasPROV, 0, Constants.CLAVE_TIPOESQ_PROV, null, null);

			socSolicitudesDao.cambiarEstadoSolicitud(solicitud.getSolicitud(), null, Constants.CLAVE_ESTWS_PROV);

			// ######### PROVISIONAR#########
			ContabilizarService contabilizarService = new ContabilizarService();
			contabilizarService.setSessionFactory(getSessionFactory());

			contabilizarService.autorizarComprobante(solicitud, socComprobante.getCpbCodigo());

			// ######### PROVISIONAR#########
			// autorizado por el solic
			// provisionado
			log.info("Solicitud PROVISIONADA " + solicitud.getSolicitud().getSocCodigo());
			SocComprobante socComprobanteNew = comprobanteDao.getComprobante(socComprobante.getCpbCodigo());

			return socComprobanteNew;
		}
		// }
		return null;
	}
	
	public Map<String, Object> procesarServicioSolicitudesWS(Solicitud solicitud, Map<String, Object> parametros)
			throws Exception {
		Map<String, Object> mapaRespuesta = new HashMap<String, Object>();
		Map<String, String> paramsMailRespuesta = new HashMap<String, String>();

		String mensajeXMLResp = "";

		String statusCode = "0000";
		String consent = "Solicitud sin procesar avise al administrador";

		if (!parametros.containsKey("mensajeSiocTO")) {
			log.error("error parametro mensajeSiocTO inexistente avise a sistemas");
			throw new BusinessException("error parametro mensajeSiocTO inexistente avise a sistemas");
		}
		MensajeSiocTO mensajeSiocTO = (MensajeSiocTO) parametros.get("mensajeSiocTO");

		ServicioSioc servicioSioc = (ServicioSioc) mensajeSiocTO.getMensajeBCBJAXB();

		String codTipoOperacion = servicioSioc.getCabeceraMensaje().getCodTipoOperacion();

		log.info("[WS]::==> Inicio tipo operacion [" + codTipoOperacion + "]");

		boolean salvaRespuesta = false;

		if (codTipoOperacion.equals("C01")) {
			// solicitantes para transferencias al exterior
			solicitud = recuperarSolicitantebyCodSigep(solicitud, servicioSioc.getDatosOperacion().getCodEntidad(),
					Integer.valueOf(servicioSioc.getDatosOperacion().getCodMoneda()), "", Constants.CLAVE_SUBTIPOOPER_TRAEXT);

			mensajeSiocTO.actualizarRespuestaOperacion(solicitud);
			// consulta
			mapaRespuesta.put(Constants.AUDIT_COD_TIPO_OPERACION, codTipoOperacion);
			statusCode = "0000";
			consent = "La solicitud fue procesada satisfactoriamente";

		} else if (codTipoOperacion.equals("C04")) {
			// solicitantes para transferencias LOCALES
			solicitud = recuperarSolicitantebyCodSigep(solicitud, servicioSioc.getDatosOperacion().getCodEntidad(),
					Integer.valueOf(servicioSioc.getDatosOperacion().getCodMoneda()), "", Constants.CLAVE_SUBTIPOOPER_TRACTA);

			mensajeSiocTO.actualizarRespuestaOperacion(solicitud);

			mapaRespuesta.put(Constants.AUDIT_COD_TIPO_OPERACION, codTipoOperacion);

			statusCode = "0000";
			consent = "La solicitud fue procesada satisfactoriamente";

		} else if (codTipoOperacion.equals("C06")) {
			// consulta de notificacion de 
			String confirmacionDebitofirmado = consultaDeOperacion(servicioSioc.getDatosOperacion().getSolicitud().getCodSolicitudOrigen());
			
			mapaRespuesta.put("mensajeXML", confirmacionDebitofirmado);
			return mapaRespuesta;
		} else if (operacionesProvision.contains(codTipoOperacion)) {
			solicitud = crearFromServicioSioc(solicitud, servicioSioc);

			SocComprobante socComprobantePROV = provisionarSolicitud(solicitud, solicitud.getSocEsquemas());
			String tipoMensajemail = "";
			String subject = "";
			String content = "";

			statusCode = "0000";

			if (socComprobantePROV != null) {
				// solicitiud provisionada
				consent = "Solicitud procesada satisfactoriamente con numero de solicitud " + solicitud.getSolicitud().getSocCodigo();

				if (solicitud.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRACTA)
						|| solicitud.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_ORDPAG)) {
					mapaRespuesta.put("sgteoperacion", "PREAUTOAUTO");
				} else if (solicitud.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS)) {
					// NO HAGO NADA zzZZzzZzzz!!
				} else if (solicitud.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)) {
					// para transferencias al exterior en monedas se
					// verifica si se
					// encuentra en horario de lo contrario es para el sgte
					// dia
					// habil

					SocEsquemas socEsquemas = socEsquemasDao.esquemaByCod(solicitud.getSolicitud().getEsqCodigo());
					SocHorario socHorario = socHorarioDao.findByTOper(socEsquemas.getClaSubtipo());
					boolean enHorario = socHorarioDao.operacionEstaEnHorario(socEsquemas.getClaSubtipo(), new Date(), Constants.COD_IFA_MEFP);
					if (enHorario) {

					} else {
						consent = "SOLICITUD REGISTRADA satisfactoriamente posterior a ["
								+ UtilsDate.stringFromDate(socHorario.getHoraFin(), "HH:mm") + "] para su proceso EN LA SIGUIENTE FECHA HABIL"
								+ solicitud.getSolicitud().getSocCodigo();
					}

				}
				log.info(consent);
				paramsMailRespuesta.put("observacion", consent);

				subject = "Aviso Sioc: Registro de solicitud " + solicitud.getSocSolicitante().getSigla() + ": ["
						+ solicitud.getSocEsquemas().getCodTipoperacion() + "] - " + solicitud.getSolicitud().getSocCodigo();

				List<SocOpecomi> socOpecomiLista = socOpecomiDao.getComis(solicitud.getSolicitud().getSocCodigo());
				solicitud.setSocOpecomiLista(socOpecomiLista);
				
				content = MsgLogic.textoSolicitud(solicitud, 0, null, paramsMailRespuesta);
				tipoMensajemail = "WSREGISTROSOLICTUD";
			}

			SocSolicitudctas socSolicitudctasMOVPROVISION = socSolicitudctasDao.getCuenta(solicitud.getSolicitud().getSocCodigo(),
					Constants.COD_CLAVE_MOVPROVISION, null, null, null, null);
			
			if (solicitud.getSocOpecomiLista() == null || solicitud.getSocOpecomiLista().size() == 0){
				List<SocOpecomi> socOpecomiLista = socOpecomiDao.getComis(solicitud.getSolicitud().getSocCodigo());
				solicitud.setSocOpecomiLista(socOpecomiLista);
			}

			socUsuariosolDao.formarMail(tipoMensajemail, subject, content, "'900'");
			mensajeSiocTO.actualizarSolicitudRespuesta(solicitud, socSolicitudctasMOVPROVISION);

			mapaRespuesta.put(Constants.AUDIT_COD_TIPO_OPERACION, codTipoOperacion);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitud);
			salvaRespuesta = true;

		} else {
			log.error("Tipo de operacion no implementada " + codTipoOperacion);
			throw new BusinessException("Tipo de operacion no implementada " + codTipoOperacion);
		}

		mensajeSiocTO.actualizarRespuesta(statusCode, consent);

		mensajeXMLResp = mensajeSiocTO.transformaXML();

		log.info("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");
		log.info(mensajeXMLResp);
		log.info("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");

		FirmaDigHelper firmaDigHelper = new FirmaDigHelper();

		String firmadito = firmaDigHelper.sign(mensajeXMLResp);

		mapaRespuesta.put("mensajeXML", firmadito);

		if (salvaRespuesta) {
			String pathFile = UtilsFile.grabaEnArchivo(firmadito, ConfigurationServ.getConfigurationHome() + "/mensajes/" + codTipoOperacion + "_"
					+ mensajeSiocTO.getRespuestaSioc().getCabeceraRespuesta().getIdMensaje() + "_O.xml");

			log.info("Archivo XML salvado en " + pathFile);
		}

		return mapaRespuesta;
	}

}
