package gob.bcb.service.servicioSioc.logic;

import gob.bcb.bpm.pruebaCU.FactoryDao;
import gob.bcb.bpm.pruebaCU.Glosa;
import gob.bcb.bpm.pruebaCU.QueryProcessor;
import gob.bcb.bpm.pruebaCU.Servicios;
import gob.bcb.bpm.pruebaCU.SocComprobante;
import gob.bcb.bpm.pruebaCU.SocComprobanteDao;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocDetallessolDao;
import gob.bcb.bpm.pruebaCU.SocFacturasDao;
import gob.bcb.bpm.pruebaCU.SocOpecomi;
import gob.bcb.bpm.pruebaCU.SocOpecomiDao;
import gob.bcb.bpm.pruebaCU.SocOpecomiId;
import gob.bcb.bpm.pruebaCU.SocOperaciones;
import gob.bcb.bpm.pruebaCU.SocOperacionesDao;
import gob.bcb.bpm.pruebaCU.SocRengscomp;
import gob.bcb.bpm.pruebaCU.SocRengscompDao;
import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.SocSolicitudesDao;
import gob.bcb.service.commons.UserSessionHolder;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.joda.time.DateTime;

/**
 * Clase que contiene los metodos para generar los comprobantes de las
 * operaciones en monedas.
 * 
 * @author C. Cecilia Uriona
 * 
 */

public class GenerarFechaValor {

	private static final Log log = LogFactory.getLog(GenerarFechaValor.class);

	/**
	 * operaciones a fecha valor
	 * 
	 * @param factoryDao
	 * @param operacion
	 * @param tcUS
	 * @param tc
	 * @return
	 */
	public static void generarTE(FactoryDao factoryDao, SocOperaciones operacion, BigDecimal tcUS, BigDecimal tc) {
		log.info("Ingresando a generarTE(fecha VAlor) " + operacion.getOpeCodigo());

		DateTime hoyT = new DateTime(operacion.getOpeFecha());
		Date hoy2 = new Date();

		SocSolicitudesDao solicitudesDao = (SocSolicitudesDao) factoryDao.getDao("socSolicitudesDao");
		SocSolicitudes solicitud = solicitudesDao.getSolicitud(operacion.getSocCodigo());

		SocDetallessolDao detallesDao = (SocDetallessolDao) factoryDao.getDao("socDetallessolDao");
		SocDetallessol detalle = detallesDao.getDetalle(solicitud.getSocCodigo(), 1);

		if (!solicitud.getClaTipo().equals("OB")) {
			generarComisiones(factoryDao, operacion.getOpeCodigo(), solicitud, tc, tcUS);
			QueryProcessor.flush();
		}

		String codComprobante = Long.toString(hoy2.getTime());
		SocComprobante comprobante = new SocComprobante(codComprobante, operacion.getOpeCodigo(), hoyT.getYear(), hoyT.getMonthOfYear(),
				hoyT.getDayOfMonth(), tcUS, Glosa.crearGlosa(operacion.getClaOperacion(), solicitud, detalle.getDetConcepto()));

		SocComprobanteDao comprobanteDao = (SocComprobanteDao) factoryDao.getDao("socComprobanteDao");
		comprobanteDao.saveOrUpdate(comprobante);
		log.info("Comprobante guardado: ");

		String subTipo = "CCI";

		if (operacion.getMoneda() == 34) {
			// si la moneda es en SUS
			subTipo = "CCS";
		}

		String tipoOperacion = operacion.getClaOperacion();
		List<Map<String, Object>> resultado1 = Servicios.obtenerEsquema(tipoOperacion, subTipo);
		List<SocDetallessol> detalles = new ArrayList<SocDetallessol>();
		detalles.add(detalle);

		SocRengscompDao rengsCompDao = (SocRengscompDao) factoryDao.getDao("socRengscompDao");
		List<SocRengscomp> continuar = rengsCompDao.CrearRenglones(codComprobante, resultado1, solicitud, detalles);
		QueryProcessor.flush();

		log.info("Renglones creados para: " + codComprobante);

		String query = "select ren_codigo " + "from soc_rengscomp " + "where cpb_codigo = '" + codComprobante + "' " + "and ren_afectable = '001564'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "ren_codigo".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				Integer nro = (Integer) res.get("ren_codigo");
				SocFacturasDao facturasDao = (SocFacturasDao) factoryDao.getDao("socFacturasDao");
				if (solicitud.getSocMontoord().compareTo(BigDecimal.valueOf(0)) > 0) {
					facturasDao.crearFactura(codComprobante, nro, detalle.getBenCodigo(), 'T');
				} else {
					facturasDao.crearFactura(codComprobante, nro, solicitud.getSolCodigo());
				}
			}
			QueryProcessor.flush();
		}

		// //////////////////////////////
		SocSolicitante socSolicitante = Servicios.getSocSolicitante(solicitud.getSolCodigo());
		if (socSolicitante == null) {
			throw new RuntimeException("Solicitante inexistente " + solicitud.getSolCodigo());
		}

		int genITF = Servicios.getGenITF(solicitud.getSocCuentad());
		int genITFporCtaComision = Servicios.getGenITF(solicitud.getSocCuentac());
		boolean generaCompITF = false;

		String sIOCWEB_TIPOPERACION = (String) UserSessionHolder.get("SIOCWEB_TIPOPERACION");

		// en operaciones de Trans Ext del sector publico en dolares y que
		// sean a fecha valor ya no se crea el comprobante de ITF
		// ya que el itf se cobró al provisionar
		DateTime hoy = new DateTime();
		DateTime fechaValor = new DateTime(solicitud.getFecha());

		rengsCompDao.CrearRenglonesITF(codComprobante, operacion.getOpeCodigo(), operacion.getOpeFecha(), solicitud, detalle);
		QueryProcessor.flush();


		operacion.setFechaHora(new Date());
		SocOperacionesDao socOperDao = (SocOperacionesDao) factoryDao.getDao("socOperacionesDao");
		socOperDao.saveOrUpdate(operacion);
		log.info("Monto MN actualizado");
		QueryProcessor.flush();
	}

	public static void generarVE(FactoryDao factoryDao, SocOperaciones operacion, BigDecimal tcUS, BigDecimal tc, BigDecimal tcUSV) {
		log.info("Ingresando a generarVE " + operacion.getOpeCodigo());

		SocSolicitudesDao solicitudesDao = (SocSolicitudesDao) factoryDao.getDao("socSolicitudesDao");
		SocSolicitudes solicitud = solicitudesDao.getSolicitud(operacion.getSocCodigo());

		SocDetallessolDao detallesDao = (SocDetallessolDao) factoryDao.getDao("socDetallessolDao");
		List<SocDetallessol> detalles = detallesDao.getDetalles(solicitud.getSocCodigo());

		String concepto = "";
		for (SocDetallessol det : detalles) {
			concepto = det.getDetConcepto();
		}

		generarComisionesOM(factoryDao, operacion.getOpeCodigo(), solicitud, tc, detalles.size(), tcUS, tcUSV);
		QueryProcessor.flush();

		DateTime hoyT = new DateTime(operacion.getOpeFecha());
		Date hoy2 = new Date();

		String codComprobante = Long.toString(hoy2.getTime());
		SocComprobante comprobante = new SocComprobante(codComprobante, operacion.getOpeCodigo(), hoyT.getYear(), hoyT.getMonthOfYear(),
				hoyT.getDayOfMonth(), tcUS, Glosa.crearGlosa(operacion.getClaOperacion(), solicitud, concepto));

		SocComprobanteDao comprobanteDao = (SocComprobanteDao) factoryDao.getDao("socComprobanteDao");
		comprobanteDao.saveOrUpdate(comprobante);
		log.info("Comprobante guardado: ");

		String subTipo = "";
		if (operacion.getOpeCtaoperacion() == 5) {
			subTipo = "TEI";
		} else {
			subTipo = "TECI";
		}

		String query = "select re.det_codigo, re.cla_cuenta, re.esq_dh, re.esq_definicion, re.cla_glosa_r, re.repetible "
				+ "from soc_rengesq re, soc_esquemas ee " + "where re.esq_codigo = ee.esq_codigo " + "and ee.cla_operacion = '"
				+ operacion.getClaOperacion() + "' " + "and ee.cla_subtipo = '" + subTipo + "'";

		String tipoOperacion = operacion.getClaOperacion();
		List<Map<String, Object>> resultado1 = Servicios.obtenerEsquema(tipoOperacion, subTipo);

		SocRengscompDao rengsCompDao = (SocRengscompDao) factoryDao.getDao("socRengscompDao");
		List<SocRengscomp> continuar = rengsCompDao.CrearRenglones(codComprobante, resultado1, solicitud, detalles);
		QueryProcessor.flush();

		log.info("Renglones creados: codComprobante " + codComprobante);

		query = "select ren_codigo " + "from soc_rengscomp " + "where cpb_codigo = '" + codComprobante + "' " + "and ren_afectable = '001564'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "ren_codigo".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				Integer nro = (Integer) res.get("ren_codigo");
				SocFacturasDao facturasDao = (SocFacturasDao) factoryDao.getDao("socFacturasDao");
				if (solicitud.getSocMontoord().compareTo(BigDecimal.valueOf(0.00)) == 0) {
					facturasDao.crearFactura(codComprobante, nro, solicitud.getSolCodigo());
				} else {
					for (SocDetallessol det : detalles) {
						String ben = det.getBenCodigo();
						facturasDao.crearFactura(codComprobante, nro, ben, solicitud.getSolCodigo(), true);
					}
				}
			}
		}

		operacion.setFechaHora(new Date());
		SocOperacionesDao socOperDao = (SocOperacionesDao) factoryDao.getDao("socOperacionesDao");
		QueryProcessor.flush();
		socOperDao.saveOrUpdate(operacion);
		log.info("Monto MN actualizado");
	}

	private static void generarComisionesOM(FactoryDao factoryDao, String codOperacion, SocSolicitudes solicitud, BigDecimal tc, int nro,
			BigDecimal tcUS, BigDecimal tcUSV) {
		SocOpecomiId id1 = new SocOpecomiId("1", codOperacion, 1);
		BigDecimal monto1 = (solicitud.getSocMontome().multiply(tc)).divide(tcUS, 2, RoundingMode.HALF_UP);
		BigDecimal monto = monto1.multiply(BigDecimal.valueOf(Double.valueOf(Servicios.getComision("CTRA"))).divide(BigDecimal.valueOf(100))).divide(
				BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
		final BigDecimal montoComi1 = monto.multiply(tcUS);
		SocOpecomi opeComi1 = new SocOpecomi(id1, montoComi1);

		SocOpecomiId id2 = new SocOpecomiId("2", codOperacion, 1);
		final BigDecimal montoComi2 = BigDecimal.valueOf(Double.valueOf(Servicios.getComision("SWFT"))).multiply(BigDecimal.valueOf(nro));
		SocOpecomi opeComi2 = new SocOpecomi(id2, montoComi2);

		SocOpecomiId id3 = new SocOpecomiId("3", codOperacion, 1);
		final BigDecimal montoComi3 = BigDecimal.valueOf(Double.valueOf(Servicios.getComision("UTIL")));
		SocOpecomi opeComi3 = new SocOpecomi(id3, montoComi3);

		SocOpecomiId id4 = new SocOpecomiId("4", codOperacion, 1);
		BigDecimal montoV = ((solicitud.getSocMontome().multiply(tc)).multiply(tcUSV)).divide(tcUS, 2, RoundingMode.HALF_UP);
		BigDecimal montoC = (solicitud.getSocMontome().multiply(tc)).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
		
		if (solicitud.getSocMontoord() != null && solicitud.getSocMontoord().compareTo(BigDecimal.ZERO) > 0) {
			// SI EL MONTO ORDENADO ES MAYOR A CERO QUIERE DECIR QUE ES CON
			// DESCUENTO DEL MONTO ORDENADO
			montoV = (solicitud.getSocMontoord().multiply(tcUSV)).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
			montoC = (solicitud.getSocMontoord().multiply(tc)).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
		} else {
			montoV = ((solicitud.getSocMontome().multiply(tc)).multiply(tcUSV)).divide(tcUS, 2, RoundingMode.HALF_UP);
			montoC = (solicitud.getSocMontome().multiply(tc)).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
		}
		
		final BigDecimal montoComi4 = montoV.subtract(montoC);
		
		SocOpecomi opeComi4 = new SocOpecomi(id4, montoComi4);

		SocOpecomiDao socOpecomiDao = (SocOpecomiDao) factoryDao.getDao("socOpecomiDao");
		opeComi1.setFechaHora(new Date());
		opeComi2.setFechaHora(new Date());
		opeComi3.setFechaHora(new Date());
		opeComi4.setFechaHora(new Date());
		
		socOpecomiDao.saveOrUpdate(opeComi1);
		socOpecomiDao.saveOrUpdate(opeComi2);
		socOpecomiDao.saveOrUpdate(opeComi3);
		socOpecomiDao.saveOrUpdate(opeComi4);
		log.info("Comisiones generadas: " + solicitud.getSocCodigo());
	}

	private static void generarComisiones(FactoryDao factoryDao, String codOperacion, SocSolicitudes solicitud, BigDecimal tc, BigDecimal tcUS) {

		SocOpecomiId id1 = new SocOpecomiId("1", codOperacion, 1);
		BigDecimal monto = BigDecimal.valueOf(0.00);
		BigDecimal montoE = BigDecimal.valueOf(0.00);
		String tipoEnt = Servicios.getTipoEnt(solicitud.getSolCodigo());
		montoE = (solicitud.getSocMontome().multiply(tc).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP))
				.divide(tcUS, 2, RoundingMode.HALF_UP);
		if (tipoEnt.equals("SP")) {
			monto = montoE.multiply(BigDecimal.valueOf(Double.valueOf(Servicios.getComision("CTRA"))).divide(BigDecimal.valueOf(100))).divide(
					BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
		} else {
			monto = montoE.multiply(BigDecimal.valueOf(Double.valueOf(Servicios.getComision("CTRF"))).divide(BigDecimal.valueOf(100))).divide(
					BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
		}
		final BigDecimal montoComi1 = monto.multiply(tcUS);
		SocOpecomi opeComi1 = new SocOpecomi(id1, montoComi1);

		SocOpecomiId id2 = new SocOpecomiId("2", codOperacion, 1);
		final BigDecimal montoComi2 = BigDecimal.valueOf(Double.valueOf(Servicios.getComision("SWFT")));
		SocOpecomi opeComi2 = new SocOpecomi(id2, montoComi2);

		SocOpecomiId id3 = new SocOpecomiId("3", codOperacion, 1);
		final BigDecimal montoComi3 = BigDecimal.valueOf(Double.valueOf(Servicios.getComision("UTIL")));
		SocOpecomi opeComi3 = new SocOpecomi(id3, montoComi3);

		SocOpecomiDao socOpecomiDao = (SocOpecomiDao) factoryDao.getDao("socOpecomiDao");
		opeComi1.setFechaHora(new Date());
		opeComi2.setFechaHora(new Date());
		opeComi3.setFechaHora(new Date());
		
		socOpecomiDao.saveOrUpdate(opeComi1);
		socOpecomiDao.saveOrUpdate(opeComi2);
		socOpecomiDao.saveOrUpdate(opeComi3);
		log.info("Comisiones generadas: ");
	}

	public static void main(String[] args) {
		DateTime hoy = new DateTime();

		System.out.println(hoy);
		System.out.println(hoy.getDayOfMonth());
	}
}
