package gob.bcb.service.servicioSioc.logic;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.StringUtils;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;

import gob.bcb.bpm.pruebaCU.CarCartascr;
import gob.bcb.bpm.pruebaCU.CarCartascrDao;
import gob.bcb.bpm.pruebaCU.CarCartascrdet;
import gob.bcb.bpm.pruebaCU.CarCartascrdetDao;
import gob.bcb.bpm.pruebaCU.SocBenefs;
import gob.bcb.bpm.pruebaCU.SocBenefsDao;
import gob.bcb.bpm.pruebaCU.SocComitipoope;
import gob.bcb.bpm.pruebaCU.SocComitipoopeDao;
import gob.bcb.bpm.pruebaCU.SocCuentassol;
import gob.bcb.bpm.pruebaCU.SocCuentassolDao;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocDetallessolDao;
import gob.bcb.bpm.pruebaCU.SocDetallessolId;
import gob.bcb.bpm.pruebaCU.SocEsquemas;
import gob.bcb.bpm.pruebaCU.SocEsquemasDao;
import gob.bcb.bpm.pruebaCU.SocOpecomi;
import gob.bcb.bpm.pruebaCU.SocOpecomiDao;
import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.bpm.pruebaCU.SocSolicitanteDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudctas;
import gob.bcb.bpm.pruebaCU.SocSolicitudctasDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.SocSolicitudesDao;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;

public class CartasCredSolicitudService {
	private final Logger log = LoggerFactory.getLogger(CartasCredSolicitudService.class);

	private final SocDetallessolDao socDetallessolDao;
	private final SocSolicitudesDao socSolicitudesDao;
	private final SocEsquemasDao socEsquemasDao;
	private final SocSolicitudctasDao socSolicitudctasDao;
	private final SocCuentassolDao socCuentassolDao;
	private final SocBenefsDao socBenefsDao;
	private final SocSolicitanteDao socSolicitanteDao;
	private final SocOpecomiDao socOpecomiDao;
	private final SocComitipoopeDao socComitipoopeDao;

	private final SessionFactory sessionFactorySioc;
	private final SessionFactory sessionFactoryCoin;

	public CartasCredSolicitudService(SessionFactory sessionFactorySioc, SessionFactory sessionFactoryCoin) {
		this.socDetallessolDao = new SocDetallessolDao();
		this.socDetallessolDao.setSessionFactory(sessionFactorySioc);

		this.sessionFactorySioc = sessionFactorySioc;
		this.sessionFactoryCoin = sessionFactoryCoin;

		this.socEsquemasDao = new SocEsquemasDao();
		this.socEsquemasDao.setSessionFactory(sessionFactorySioc);

		this.socSolicitudesDao = new SocSolicitudesDao();
		this.socSolicitudesDao.setSessionFactory(sessionFactorySioc);

		this.socSolicitudctasDao = new SocSolicitudctasDao();
		this.socSolicitudctasDao.setSessionFactory(sessionFactorySioc);

		this.socCuentassolDao = new SocCuentassolDao();
		this.socCuentassolDao.setSessionFactory(sessionFactorySioc);

		this.socBenefsDao = new SocBenefsDao();
		this.socBenefsDao.setSessionFactory(sessionFactorySioc);

		this.socSolicitanteDao = new SocSolicitanteDao();
		this.socSolicitanteDao.setSessionFactory(sessionFactorySioc);

		this.socOpecomiDao = new SocOpecomiDao();
		this.socOpecomiDao.setSessionFactory(sessionFactorySioc);

		this.socComitipoopeDao = new SocComitipoopeDao();
		this.socComitipoopeDao.setSessionFactory(sessionFactorySioc);
	}

	public Solicitud inicializarOActualizarRegistroSolicitudParaPagoEnmienda(CarCartascr carCartascr, CarCartascrdet carCartascrdet, Solicitud solicitudIn) {
		log.info("en inicializarOActualizarRegistroSolicitudParaPagoEnmienda para carta {}", carCartascr.getCcrCodcartacr());

		Solicitud solicitud = recuperarSolicitudOpt(carCartascrdet.getCcdSoccodigo(), carCartascrdet.getCcdEsqcodigo());
		SocSolicitudes socSolicitudes = solicitud.getSolicitud();

		socSolicitudes.setSolCodigo(carCartascr.getCcrSolcodigo().trim());
		socSolicitudes.setEsqCodigo(carCartascrdet.getCcdEsqcodigo());
		SocEsquemas socEsquemas = socEsquemasDao.esquemaByCod(carCartascrdet.getCcdEsqcodigo());

		socSolicitudes.setClaTipo(socEsquemas.getCodTipooper());
		socSolicitudes.setCveSubtipooper(socEsquemas.getCveSubtipooper());
		
		socSolicitudes.setDetConcepto(carCartascrdet.getCcdGlosa());

		SocDetallessol socDetallessol = solicitudIn.getSocDetallessolLista().get(0);
		socDetallessol.setBenCodigo(carCartascr.getCcrBencodigo());

		if (CartasCredService.esRegistroDePago(carCartascrdet)) {
			socSolicitudes.setSocMontome(carCartascrdet.getCcdMontotrans());
			// moneda de la carta
			socSolicitudes.setCodMoneda(carCartascrdet.getCcdCodmontrans());
			// sera la moneda seleccionada
			socSolicitudes.setCodMonedat(carCartascrdet.getCcdCodmonmonto());

			//socDetallessol.setNroCuentabco(carCartascrdet.getCcdCodbcoreceptor());
			socDetallessol.setDetMonto(carCartascrdet.getCcdMontotrans());
			socDetallessol.setCodMoneda(carCartascrdet.getCcdCodmontrans());

			Assert.notNull(socDetallessol.getCodBanco(), "Entidad depositaria debe tener un valor");
			Assert.notNull(socDetallessol.getDetCodttransfer(), "Esquema swift debe tener un valor");
			Assert.isTrue(solicitudIn.getSocSolicitudctasLista() != null && solicitudIn.getSocSolicitudctasLista().size() > 0, "Lista de cuentas vacía");
			
			boolean existeCtaFV = false;
			// validar cuenta fondos vista
			for (SocSolicitudctas socSolicitudctas : solicitudIn.getSocSolicitudctasLista()) {
				if (socSolicitudctas.getId() != null) {
					if (!StringUtils.isBlank(socSolicitudctas.getId().getTipoCuenta())) {
						if (socSolicitudctas.getId().getTipoCuenta().equals(Constants.COD_CLAVE_BENEFMT)) {
							if (StringUtils.isBlank(socSolicitudctas.getCtaAfectable())) {
								throw new BusinessException("Cuenta Fondos Vista en socSolicitudctas debe tener valor.");
							}
							existeCtaFV = true;
							break;
						}
					}
				}
			}
			
			Assert.isTrue(existeCtaFV, "Cuenta Fondos Vista inválida");

		} else if (CartasCredService.esEnmiendaDeAmpliacion(carCartascrdet) || CartasCredService.esEnmiendaDeReduccion(carCartascrdet)
				|| CartasCredService.esEnmiendaDeModificacionDatos(carCartascrdet)) {

			socSolicitudes.setSocMontome(carCartascrdet.getCcdMontotrans());
			socSolicitudes.setCodMoneda(carCartascrdet.getCcdCodmontrans());
			socSolicitudes.setCodMonedat(carCartascrdet.getCcdCodmontrans());

			//socDetallessol.setNroCuentabco(carCartascrdet.getCcdCodbcoreceptor());
			socDetallessol.setDetMonto(carCartascrdet.getCcdMontotrans());
			socDetallessol.setCodMoneda(carCartascrdet.getCcdCodmontrans());

		} else if (CartasCredService.esEnmiendaDeIncremento(carCartascrdet)) {
			socSolicitudes.setSocMontome(carCartascrdet.getCcdMonto());
			socSolicitudes.setCodMoneda(carCartascrdet.getCcdCodmonmonto());
			socSolicitudes.setCodMonedat(carCartascrdet.getCcdCodmontrans());

			//socDetallessol.setNroCuentabco(carCartascrdet.getCcdCodbcoreceptor());
			socDetallessol.setDetMonto(carCartascrdet.getCcdMonto());
			socDetallessol.setCodMoneda(carCartascrdet.getCcdCodmonmonto());

		} else if (CartasCredService.esEnmiendaDeDecremento(carCartascrdet)) {
			socSolicitudes.setSocMontome(carCartascrdet.getCcdMonto());
			socSolicitudes.setCodMoneda(carCartascrdet.getCcdCodmonmonto());
			// la moneda de transferencia es la moneda de provision
			socSolicitudes.setCodMonedat(carCartascr.getCcrCodmoneda());

			//socDetallessol.setNroCuentabco(carCartascrdet.getCcdCodbcoreceptor());
			socDetallessol.setDetMonto(carCartascrdet.getCcdMonto());
			socDetallessol.setCodMoneda(carCartascrdet.getCcdCodmonmonto());
		}

		solicitud.setSocDetallessolLista(new ArrayList<SocDetallessol>());

		solicitud.getSocDetallessolLista().add(socDetallessol);

		solicitud.setCarCartascr(carCartascr);
		solicitud.setCarCartascrdet(carCartascrdet);

		return solicitud;
	}

	public Solicitud inicializaSolicitudParaPagoEnmienda(CarCartascr carCartascr, CarCartascrdet carCartascrdet) {
		log.info("en inicializaSolicitudParaPagoEnmienda para carta {}", carCartascr.getCcrCodcartacr());

		Solicitud solicitud = nuevoSolicitud(carCartascrdet.getCcdEsqcodigo());

		SocSolicitudes socSolicitudes = solicitud.getSolicitud();
		socSolicitudes.setSolCodigo(carCartascr.getCcrSolcodigo().trim());
		socSolicitudes.setCodMoneda(carCartascrdet.getCcdCodmonmonto());
		socSolicitudes.setCodMonedat(carCartascrdet.getCcdCodmontrans());

		solicitud.getSocDetallessolLista().get(0).setBenCodigo(carCartascr.getCcrBencodigo());
		//solicitud.getSocDetallessolLista().get(0).setNroCuentabco(carCartascr.getCcrBcocodigo());
		solicitud.getSocDetallessolLista().get(0).setCodMoneda(carCartascrdet.getCcdCodmonmonto());

		solicitud.setCarCartascr(carCartascr);
		solicitud.setCarCartascrdet(carCartascrdet);

		return solicitud;

	}

	public Solicitud recuperarSolicitudOpt(String socCodigo, Integer esqCodigo) {
		if (StringUtils.isBlank(socCodigo)) {
			return nuevoSolicitud(esqCodigo);
		}
		try {
			return recuperarSolicitud(socCodigo);
		} catch (Exception e) {
			return nuevoSolicitud(esqCodigo);
		}
	}

	public Solicitud recuperarSolicitud(String socCodigo) {
		Solicitud solicitud = new Solicitud();

		SocSolicitudes solicitudOld = socSolicitudesDao.getSolicitud(socCodigo);
		if (solicitudOld == null) {
			throw new BusinessException("Solicitud inexistente " + socCodigo);
		}
		solicitud.setSolicitud(solicitudOld);
		solicitud.setSocDetallessolLista(socDetallessolDao.getDetalles(solicitudOld.getSocCodigo()));

		return solicitud;
	}
	public SocSolicitudes getSolicitud(String socCodigo) {
		return socSolicitudesDao.getSolicitud(socCodigo);
	}
	public List<SocSolicitudctas> copiarSocSolicitudctasParaSocCodigo(String socCodigo) {
		List<SocSolicitudctas> socSolicitudctasListaOld = socSolicitudctasDao.getCuentas(socCodigo);
		return copiarSocSolicitudctas(socSolicitudctasListaOld);
	}

	public List<SocSolicitudctas> agregarCuentasACtasSolicitud(String socCodigo, List<SocSolicitudctas> socSolicitudctasListaIn) {
		Map<String, SocSolicitudctas> socSolicitudctasCrtl = new HashMap<String, SocSolicitudctas>();
		List<SocSolicitudctas> socSolicitudctasLista = new ArrayList<SocSolicitudctas>();

		List<SocSolicitudctas> socSolicitudctasListaOld = copiarSocSolicitudctasParaSocCodigo(socCodigo);

		for (SocSolicitudctas socSolicitudctas : socSolicitudctasListaOld) {
			socSolicitudctasCrtl.put(socSolicitudctas.getId().getTipoCuenta(), socSolicitudctas);
		}

		List<SocSolicitudctas> socSolicitudctasListaAdding = copiarSocSolicitudctas(socSolicitudctasListaIn);

		for (SocSolicitudctas socSolicitudctas : socSolicitudctasListaAdding) {
			socSolicitudctasCrtl.put(socSolicitudctas.getId().getTipoCuenta(), socSolicitudctas);
		}

		for (Entry<String, SocSolicitudctas> socSolicitudctas : socSolicitudctasCrtl.entrySet()) {
			socSolicitudctasLista.add(socSolicitudctas.getValue());
		}

		return socSolicitudctasLista;
	}

	public void guardarCtaAcreditivo(String socCodigo, SocSolicitudctas socSolicitudctas) {
		if (socSolicitudctas == null) {
			throw new BusinessException("Parámetro socSolicitudctas nulo");
		}
		if (StringUtils.isBlank(socCodigo)) {
			throw new BusinessException("Parámetro de código de solicitud inválido");
		}

		if (StringUtils.isBlank(socSolicitudctas.getCtaAfectable())) {
			throw new BusinessException("Parámetro de cuenta afectable en socSolicitudctas nulo.");
		}

		SocSolicitudes solicitudOld = socSolicitudesDao.getSolicitud(socCodigo);
		if (solicitudOld == null) {
			throw new BusinessException("Solicitud inexistente " + socCodigo);
		}

		SocCuentassol socCuentassolCLAVE_CTA_GARANT_ACREDIT = socCuentassolDao.getByAfectable(socSolicitudctas.getCtaAfectable());
		if (socCuentassolCLAVE_CTA_GARANT_ACREDIT == null) {
			throw new BusinessException("Cuenta contable con nro afectable [" + socSolicitudctas.getCtaAfectable() + "] no registrado en cuentas contables(socCuentassol)");
		}

		SocSolicitudctas socSolicitudctasCLAVE_CTA_GARANT_ACREDIT = socSolicitudctasDao.nuevo(socCodigo, Constants.CLAVE_CTA_GARANT_ACREDIT,
				socCuentassolCLAVE_CTA_GARANT_ACREDIT.getMoneda(), socCuentassolCLAVE_CTA_GARANT_ACREDIT.getCtaNommovimiento(),
				socCuentassolCLAVE_CTA_GARANT_ACREDIT.getCtaMovimiento(), null, null, null, Constants.COD_BCB, "C", "T", socCuentassolCLAVE_CTA_GARANT_ACREDIT.getCtaAfectable());

		socSolicitudctasDao.getHibernateTemplate().saveOrUpdate(socSolicitudctasCLAVE_CTA_GARANT_ACREDIT);
	}

	public Solicitud recuperarFacturasYCtas(String socCodigo) {
		Solicitud solicitud = new Solicitud();

		List<SocOpecomi> socOpecomiLista = socOpecomiDao.getByCveTipocomis(socCodigo, null, null, Constants.COD_TIPOREGVARIABLE_FACT);
		solicitud.setSocOpecomiLista(socOpecomiLista);

		List<SocSolicitudctas> socSolicitudctasListaOld = copiarSocSolicitudctasParaSocCodigo(socCodigo);
		solicitud.setSocSolicitudctasLista(socSolicitudctasListaOld);

		return solicitud;
	}

	public Solicitud recuperarFacturasYAgregarCtas(String socCodigo, List<SocSolicitudctas> socSolicitudctasListaIn) {
		Solicitud solicitud = new Solicitud();

		List<SocOpecomi> socOpecomiLista = socOpecomiDao.getByCveTipocomis(socCodigo, null, null, Constants.COD_TIPOREGVARIABLE_FACT);
		solicitud.setSocOpecomiLista(socOpecomiLista);

		List<SocSolicitudctas> socSolicitudctasListaOld = agregarCuentasACtasSolicitud(socCodigo, socSolicitudctasListaIn);
		solicitud.setSocSolicitudctasLista(socSolicitudctasListaOld);

		return solicitud;
	}

	private Solicitud nuevoSolicitud(Integer esqCodigo) {
		Solicitud solicitud = new Solicitud();
		SocSolicitudes socSolicitudes = inicializarSocSolicitudes(esqCodigo);
		solicitud.setSolicitud(socSolicitudes);

		solicitud = nuevoSolicitudDetalle(solicitud);

		solicitud.setSocSolicitante(new SocSolicitante());
		return solicitud;
	}

	private Solicitud nuevoSolicitudDetalle(Solicitud solicitud) {
		SocDetallessol socDetallessol = inicializarSolicitudDetalle(solicitud.getSocDetallessolLista().size() + 1);

		solicitud.getSocDetallessolLista().add(socDetallessol);

		return solicitud;
	}

	private SocSolicitudes inicializarSocSolicitudes(Integer esqCodigo) {
		SocSolicitudes socSolicitudes = new SocSolicitudes();

		socSolicitudes.setClaEstadows(Constants.CLAVE_ESTWS_PROCESADO);
		socSolicitudes.setFecha(new Date());
		socSolicitudes.setFechaReg(new Date());
		// para enmiendas fecha sera el saldo
		socSolicitudes.setSocMontome(BigDecimal.ZERO);
		socSolicitudes.setCodMoneda(Constants.COD_MONEDA_USD);
		socSolicitudes.setSocMontoord(BigDecimal.ZERO);
		socSolicitudes.setSocMontomn(BigDecimal.ZERO);
		socSolicitudes.setCodMonedat(Constants.COD_MONEDA_USD);
		socSolicitudes.setSolEntsolic(Constants.COD_BCB);
		socSolicitudes.setTipoConcepto("O"); // ojoooo
		socSolicitudes.setCveTipctasolic(Constants.CLAVE_GENERADOPOR_SISTEMA);
		socSolicitudes.setSocTipnegociacion(Constants.CLAVE_TIPNEGOCIA_NORMAL);
		socSolicitudes.setClaTipo(Constants.CLAVE_SUBTIPOOPER_CARTAS);
		socSolicitudes.setCveSubtipooper(Constants.CLAVE_SUBTIPOOPER_CARTAS);
		socSolicitudes.setTipoRetencion(Constants.CLAVE_TIPORETENCION_SINDESC);
		socSolicitudes.setEsqCodigo(esqCodigo);

		SocEsquemas socEsquemas = socEsquemasDao.esquemaByCod(esqCodigo);

		socSolicitudes.setClaTipo(socEsquemas.getCodTipooper());
		socSolicitudes.setCveSubtipooper(socEsquemas.getCveSubtipooper());

		return socSolicitudes;
	}

	private SocDetallessol inicializarSolicitudDetalle(Integer detCodigo) {

		SocDetallessol socDetallessol = new SocDetallessol();
		SocDetallessolId socDetallessolId = new SocDetallessolId();
		socDetallessolId.setDetCodigo(detCodigo);
		socDetallessol.setId(socDetallessolId);
		socDetallessol.setBenCodigo(Constants.COD_BCB);
		socDetallessol.setDetMonto(BigDecimal.ZERO);
		socDetallessol.setDetMontoord(BigDecimal.ZERO);
		socDetallessol.setDetMontotrans(BigDecimal.ZERO);
		socDetallessol.setCodMoneda(Constants.COD_MONEDA_USD);
		socDetallessol.setCodMonedatdet(Constants.COD_MONEDA_USD);

		return socDetallessol;
	}

	public List<SocSolicitudctas> copiarSocSolicitudctas(List<SocSolicitudctas> socSolicitudctasListaIn) {
		List<SocSolicitudctas> socSolicitudctasLista = new ArrayList<SocSolicitudctas>();

		for (SocSolicitudctas socSolicitudctas : socSolicitudctasListaIn) {
			if (socSolicitudctas.getId() != null && !StringUtils.isBlank(socSolicitudctas.getId().getTipoCuenta())) {
				SocSolicitudctas socSolicitudctasNew = socSolicitudctasDao.nuevo(null, socSolicitudctas.getId().getTipoCuenta(), socSolicitudctas.getCodMoneda(),
						socSolicitudctas.getDescripLibreta(), socSolicitudctas.getNroCuenta(), socSolicitudctas.getNroLibreta(), socSolicitudctas.getCodBanco(),
						socSolicitudctas.getNroCuentabco(), socSolicitudctas.getSolCodigo(), socSolicitudctas.getCveTipcuenta(), socSolicitudctas.getCveTipocomis(),
						socSolicitudctas.getCtaAfectable());

				socSolicitudctasLista.add(socSolicitudctasNew);
			}
		}

		return socSolicitudctasLista;
	}

	public Solicitud recuperarDatosComplementarios(Solicitud solicitudIn) {
		Solicitud solicitud = new Solicitud();
		solicitud.setSolicitud(solicitudIn.getSolicitud());
		solicitud.setCarCartascr(solicitudIn.getCarCartascr());
		solicitud.setCarCartascrdet(solicitudIn.getCarCartascrdet());
		solicitud.setSocDetallessolLista(solicitudIn.getSocDetallessolLista());

		SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCod(solicitudIn.getCarCartascr().getCcrSolcodigo());
		solicitud.setSocSolicitante(socSolicitante);

		SocBenefs socBenefs = socBenefsDao.getBenefsByBenCodigo(solicitudIn.getCarCartascr().getCcrBencodigo());
		if (socBenefs == null)
			socBenefs = new SocBenefs();

		solicitud.setSocBenefs(socBenefs);

		SocEsquemas socEsquemas = socEsquemasDao.esquemaByCod(solicitudIn.getCarCartascrdet().getCcdEsqcodigo());
		solicitud.setSocEsquemas(socEsquemas);
		return solicitud;
	}

	public SocComitipoope socComitipoopeParaEsquema(Integer esqcodigo, String claComision) {
		SocEsquemas socEsquemas = socEsquemasDao.esquemaByCod(esqcodigo);
		return socComitipoopeDao.comisionByCargoClaComisionopecomi(socEsquemas.getCodCargo(), claComision);
	}

}
