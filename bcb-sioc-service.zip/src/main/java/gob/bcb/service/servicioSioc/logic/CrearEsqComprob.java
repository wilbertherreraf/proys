package gob.bcb.service.servicioSioc.logic;

import gob.bcb.bpm.pruebaCU.SocRengesqDao;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class CrearEsqComprob extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(CrearEsqComprob.class);
	
	public void operacionTC(){
		
	}
	
}
