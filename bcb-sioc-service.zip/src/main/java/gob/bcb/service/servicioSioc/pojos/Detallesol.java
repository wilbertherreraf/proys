package gob.bcb.service.servicioSioc.pojos;

import java.io.Serializable;
import java.math.BigDecimal;

import gob.bcb.bpm.pruebaCU.Beneficiario;
import gob.bcb.bpm.pruebaCU.CarCartascr;
import gob.bcb.bpm.pruebaCU.CarCartascrdet;
import gob.bcb.bpm.pruebaCU.SocComitipoope;
import gob.bcb.bpm.pruebaCU.SocCuentassol;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocOpecomi;
import gob.bcb.bpm.pruebaCU.SocOrdenesPago;
import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.bpm.pruebaCU.SocSolicitudctas;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.SocValorescla;
import gob.bcb.swift.model.SwfMensaje;
import gob.bcb.swift.model.SwfMttransfer;

public class Detallesol implements Serializable {
	private Integer detCodigo;
	private SocSolicitudes socSolicitudes = new SocSolicitudes();
	private SocDetallessol socDetallessol = new SocDetallessol();
	private SocOrdenesPago socOrdenesPago = new SocOrdenesPago(); 
	private String socCodigo;	
	private String benCodigo;
	private Beneficiario beneficiarioDet = new Beneficiario();
	private String benNombre;	
	private String detConcepto;
	private Integer detCtabenef;
	private Integer ctaCodigo;
	private String nomMovimiento;	
	private String detInfo;
	private BigDecimal detMonto;
	private BigDecimal detMontotrans;
	private BigDecimal detMontoord;
	private Integer codMoneda;
	private String moneda;
	private String monedaT;
	private String detFacturas;
	private String beneficiario;
	private String claEstadodet;
	private String codBanco;
	private String bcoNombre;
	private BancoPlaza bancoPlaza = new BancoPlaza();
	private BancoPlaza bancoPlazainter = new BancoPlaza();	
	private String nroCuentabco;
	private String codBancointer;
	private String bcoNombreinter;	
	private String nroCuentabcointer;
	private String detCodttransfer;
	private SocCuentassol socCuentassol = new SocCuentassol();
	private SocSolicitudctas socSolicitudctas = new SocSolicitudctas();
	private SocOpecomi socOpecomi;
	private SocComitipoope socComitipoope;
	private SwfMensaje swfMensaje = new SwfMensaje();	
	private SwfMttransfer swfMttransfer = new SwfMttransfer();
	private CarCartascr carCartascr = new CarCartascr();
	private CarCartascrdet carCartascrdet = new CarCartascrdet();
	private SocValorescla socValorescla = new SocValorescla();
	private SocValorescla socValorescla2 = new SocValorescla();	
	private SocValorescla socValorescla3 = new SocValorescla();	
	private SocSolicitante socSolicitante = new SocSolicitante();
	public Detallesol() {
	}

	public String getBenCodigo() {
		return this.benCodigo;
	}

	public void setBenCodigo(String benCodigo) {
		this.benCodigo = benCodigo;
	}

	public String getDetConcepto() {
		return this.detConcepto;
	}

	public void setDetConcepto(String detConcepto) {
		this.detConcepto = detConcepto;
	}

	public Integer getDetCtabenef() {
		return this.detCtabenef;
	}

	public void setDetCtabenef(Integer detCtabenef) {
		this.detCtabenef = detCtabenef;
	}

	public String getDetInfo() {
		return this.detInfo;
	}

	public void setDetInfo(String detInfo) {
		this.detInfo = detInfo;
	}

	public BigDecimal getDetMonto() {
		return this.detMonto;
	}

	public void setDetMonto(BigDecimal detMonto) {
		this.detMonto = detMonto;
	}

	public BigDecimal getDetMontoord() {
		return this.detMontoord;
	}

	public void setDetMontoord(BigDecimal detMontoord) {
		this.detMontoord = detMontoord;
	}

	public String getMoneda() {
		return this.moneda;
	}

	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	public String getMonedaT() {
		return this.monedaT;
	}

	public void setMonedaT(String monedaT) {
		this.monedaT = monedaT;
	}

	public String getDetFacturas() {
		return detFacturas;
	}

	public void setDetFacturas(String detFacturas) {
		this.detFacturas = detFacturas;
	}

	public void setBeneficiario(String beneficiario) {
		this.beneficiario = beneficiario;
	}

	public String getBeneficiario() {
		return beneficiario;
	}

	public void setCtaCodigo(Integer ctaCodigo) {
		this.ctaCodigo = ctaCodigo;
	}

	public Integer getCtaCodigo() {
		return ctaCodigo;
	}

	public Integer getCodMoneda() {
		return codMoneda;
	}

	public void setCodMoneda(Integer codMoneda) {
		this.codMoneda = codMoneda;
	}

	public BigDecimal getDetMontotrans() {
		return detMontotrans;
	}

	public void setDetMontotrans(BigDecimal detMontotrans) {
		this.detMontotrans = detMontotrans;
	}

	public String getNroCuentabco() {
		return nroCuentabco;
	}

	public void setNroCuentabco(String nroCuentabco) {
		this.nroCuentabco = nroCuentabco;
	}

	public String getClaEstadodet() {
		return claEstadodet;
	}

	public void setClaEstadodet(String claEstadodet) {
		this.claEstadodet = claEstadodet;
	}

	public String getCodBanco() {
		return codBanco;
	}

	public void setCodBanco(String codBanco) {
		this.codBanco = codBanco;
	}

	public String getCodBancointer() {
		return codBancointer;
	}

	public void setCodBancointer(String codBancointer) {
		this.codBancointer = codBancointer;
	}

	public String getNroCuentabcointer() {
		return nroCuentabcointer;
	}

	public void setNroCuentabcointer(String nroCuentabcointer) {
		this.nroCuentabcointer = nroCuentabcointer;
	}

	public String getDetCodttransfer() {
		return detCodttransfer;
	}

	public void setDetCodttransfer(String detCodttransfer) {
		this.detCodttransfer = detCodttransfer;
	}

	public String getBenNombre() {
		return benNombre;
	}

	public void setBenNombre(String benNombre) {
		this.benNombre = benNombre;
	}

	public String getNomMovimiento() {
		return nomMovimiento;
	}

	public void setNomMovimiento(String nomMovimiento) {
		this.nomMovimiento = nomMovimiento;
	}

	public String getBcoNombre() {
		return bcoNombre;
	}

	public void setBcoNombre(String bcoNombre) {
		this.bcoNombre = bcoNombre;
	}

	public String getBcoNombreinter() {
		return bcoNombreinter;
	}

	public void setBcoNombreinter(String bcoNombreinter) {
		this.bcoNombreinter = bcoNombreinter;
	}


	public Integer getDetCodigo() {
		return detCodigo;
	}


	public void setDetCodigo(Integer detCodigo) {
		this.detCodigo = detCodigo;
	}


	public String getSocCodigo() {
		return socCodigo;
	}


	public void setSocCodigo(String socCodigo) {
		this.socCodigo = socCodigo;
	}

	public BancoPlaza getBancoPlaza() {
		return bancoPlaza;
	}

	public void setBancoPlaza(BancoPlaza bancoPlaza) {
		this.bancoPlaza = bancoPlaza;
	}

	public BancoPlaza getBancoPlazainter() {
		return bancoPlazainter;
	}

	public void setBancoPlazainter(BancoPlaza bancoPlazainter) {
		this.bancoPlazainter = bancoPlazainter;
	}

	public Beneficiario getBeneficiarioDet() {
		return beneficiarioDet;
	}

	public void setBeneficiarioDet(Beneficiario beneficiarioDet) {
		this.beneficiarioDet = beneficiarioDet;
	}

	public SocCuentassol getSocCuentassol() {
		return socCuentassol;
	}

	public void setSocCuentassol(SocCuentassol socCuentassol) {
		this.socCuentassol = socCuentassol;
	}

	public SwfMttransfer getSwfMttransfer() {
		return swfMttransfer;
	}

	public void setSwfMttransfer(SwfMttransfer swfMttransfer) {
		this.swfMttransfer = swfMttransfer;
	}

	public SocDetallessol getSocDetallessol() {
		return socDetallessol;
	}

	public void setSocDetallessol(SocDetallessol socDetallessol) {
		this.socDetallessol = socDetallessol;
	}

	public SocOrdenesPago getSocOrdenesPago() {
		return socOrdenesPago;
	}

	public void setSocOrdenesPago(SocOrdenesPago socOrdenesPago) {
		this.socOrdenesPago = socOrdenesPago;
	}

	public SwfMensaje getSwfMensaje() {
		return swfMensaje;
	}

	public void setSwfMensaje(SwfMensaje swfMensaje) {
		this.swfMensaje = swfMensaje;
	}

	public SocSolicitudctas getSocSolicitudctas() {
		return socSolicitudctas;
	}

	public void setSocSolicitudctas(SocSolicitudctas socSolicitudctas) {
		this.socSolicitudctas = socSolicitudctas;
	}

	public SocOpecomi getSocOpecomi() {
		return socOpecomi;
	}

	public void setSocOpecomi(SocOpecomi socOpecomi) {
		this.socOpecomi = socOpecomi;
	}

	public SocComitipoope getSocComitipoope() {
		return socComitipoope;
	}

	public void setSocComitipoope(SocComitipoope socComitipoope) {
		this.socComitipoope = socComitipoope;
	}

	public CarCartascr getCarCartascr() {
		return carCartascr;
	}

	public void setCarCartascr(CarCartascr carCartascr) {
		this.carCartascr = carCartascr;
	}

	public CarCartascrdet getCarCartascrdet() {
		return carCartascrdet;
	}

	public void setCarCartascrdet(CarCartascrdet carCartascrdet) {
		this.carCartascrdet = carCartascrdet;
	}

	public SocValorescla getSocValorescla() {
		return socValorescla;
	}

	public void setSocValorescla(SocValorescla socValorescla) {
		this.socValorescla = socValorescla;
	}

	public SocSolicitante getSocSolicitante() {
		return socSolicitante;
	}

	public void setSocSolicitante(SocSolicitante socSolicitante) {
		this.socSolicitante = socSolicitante;
	}

	public SocSolicitudes getSocSolicitudes() {
		return socSolicitudes;
	}

	public void setSocSolicitudes(SocSolicitudes socSolicitudes) {
		this.socSolicitudes = socSolicitudes;
	}

	public SocValorescla getSocValorescla2() {
		return socValorescla2;
	}

	public void setSocValorescla2(SocValorescla socValorescla2) {
		this.socValorescla2 = socValorescla2;
	}

	public SocValorescla getSocValorescla3() {
		return socValorescla3;
	}

	public void setSocValorescla3(SocValorescla socValorescla3) {
		this.socValorescla3 = socValorescla3;
	}

	
}
