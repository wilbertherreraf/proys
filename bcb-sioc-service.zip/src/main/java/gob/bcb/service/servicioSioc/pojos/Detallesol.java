package gob.bcb.service.servicioSioc.pojos;

import gob.bcb.bpm.pruebaCU.Beneficiario;
import gob.bcb.bpm.pruebaCU.SocCuentassol;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocOrdenesPago;
import gob.bcb.swift.model.SwfMensaje;
import gob.bcb.swift.model.SwfMttransfer;

import java.io.Serializable;
import java.math.BigDecimal;

public class Detallesol implements Serializable {
	private Integer detCodigo;
	private SocDetallessol socDetallessol = new SocDetallessol();
	private SocOrdenesPago socOrdenesPago = new SocOrdenesPago(); 
	private String socCodigo;	
	private String benCodigo;
	private Beneficiario beneficiarioDet = new Beneficiario();
	private String benNombre;	
	private String detConcepto;
	private Integer detCtabenef;
	private Integer ctaCodigo;
	private String nomMovimiento;	
	private String detInfo;
	private BigDecimal detMonto;
	private BigDecimal detMontotrans;
	private BigDecimal detMontoord;
	private Integer codMoneda;
	private String moneda;
	private String monedaT;
	private String detFacturas;
	private String beneficiario;
	private String claEstadodet;
	private String codBanco;
	private String bcoNombre;
	private BancoPlaza bancoPlaza = new BancoPlaza();
	private BancoPlaza bancoPlazainter = new BancoPlaza();	
	private String nroCuentabco;
	private String codBancointer;
	private String bcoNombreinter;	
	private String nroCuentabcointer;
	private String detCodttransfer;
	private SocCuentassol socCuentassol = new SocCuentassol();
	private SwfMensaje swfMensaje = new SwfMensaje();	
	private SwfMttransfer swfMttransfer = new SwfMttransfer();

	public Detallesol() {
	}

	public String getBenCodigo() {
		return this.benCodigo;
	}

	public void setBenCodigo(String benCodigo) {
		this.benCodigo = benCodigo;
	}

	public String getDetConcepto() {
		return this.detConcepto;
	}

	public void setDetConcepto(String detConcepto) {
		this.detConcepto = detConcepto;
	}

	public Integer getDetCtabenef() {
		return this.detCtabenef;
	}

	public void setDetCtabenef(Integer detCtabenef) {
		this.detCtabenef = detCtabenef;
	}

	public String getDetInfo() {
		return this.detInfo;
	}

	public void setDetInfo(String detInfo) {
		this.detInfo = detInfo;
	}

	public BigDecimal getDetMonto() {
		return this.detMonto;
	}

	public void setDetMonto(BigDecimal detMonto) {
		this.detMonto = detMonto;
	}

	public BigDecimal getDetMontoord() {
		return this.detMontoord;
	}

	public void setDetMontoord(BigDecimal detMontoord) {
		this.detMontoord = detMontoord;
	}

	public String getMoneda() {
		return this.moneda;
	}

	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	public String getMonedaT() {
		return this.monedaT;
	}

	public void setMonedaT(String monedaT) {
		this.monedaT = monedaT;
	}

	public String getDetFacturas() {
		return detFacturas;
	}

	public void setDetFacturas(String detFacturas) {
		this.detFacturas = detFacturas;
	}

	public void setBeneficiario(String beneficiario) {
		this.beneficiario = beneficiario;
	}

	public String getBeneficiario() {
		return beneficiario;
	}

	public void setCtaCodigo(Integer ctaCodigo) {
		this.ctaCodigo = ctaCodigo;
	}

	public Integer getCtaCodigo() {
		return ctaCodigo;
	}

	public Integer getCodMoneda() {
		return codMoneda;
	}

	public void setCodMoneda(Integer codMoneda) {
		this.codMoneda = codMoneda;
	}

	public BigDecimal getDetMontotrans() {
		return detMontotrans;
	}

	public void setDetMontotrans(BigDecimal detMontotrans) {
		this.detMontotrans = detMontotrans;
	}

	public String getNroCuentabco() {
		return nroCuentabco;
	}

	public void setNroCuentabco(String nroCuentabco) {
		this.nroCuentabco = nroCuentabco;
	}

	public String getClaEstadodet() {
		return claEstadodet;
	}

	public void setClaEstadodet(String claEstadodet) {
		this.claEstadodet = claEstadodet;
	}

	public String getCodBanco() {
		return codBanco;
	}

	public void setCodBanco(String codBanco) {
		this.codBanco = codBanco;
	}

	public String getCodBancointer() {
		return codBancointer;
	}

	public void setCodBancointer(String codBancointer) {
		this.codBancointer = codBancointer;
	}

	public String getNroCuentabcointer() {
		return nroCuentabcointer;
	}

	public void setNroCuentabcointer(String nroCuentabcointer) {
		this.nroCuentabcointer = nroCuentabcointer;
	}

	public String getDetCodttransfer() {
		return detCodttransfer;
	}

	public void setDetCodttransfer(String detCodttransfer) {
		this.detCodttransfer = detCodttransfer;
	}

	public String getBenNombre() {
		return benNombre;
	}

	public void setBenNombre(String benNombre) {
		this.benNombre = benNombre;
	}

	public String getNomMovimiento() {
		return nomMovimiento;
	}

	public void setNomMovimiento(String nomMovimiento) {
		this.nomMovimiento = nomMovimiento;
	}

	public String getBcoNombre() {
		return bcoNombre;
	}

	public void setBcoNombre(String bcoNombre) {
		this.bcoNombre = bcoNombre;
	}

	public String getBcoNombreinter() {
		return bcoNombreinter;
	}

	public void setBcoNombreinter(String bcoNombreinter) {
		this.bcoNombreinter = bcoNombreinter;
	}


	public Integer getDetCodigo() {
		return detCodigo;
	}


	public void setDetCodigo(Integer detCodigo) {
		this.detCodigo = detCodigo;
	}


	public String getSocCodigo() {
		return socCodigo;
	}


	public void setSocCodigo(String socCodigo) {
		this.socCodigo = socCodigo;
	}

	public BancoPlaza getBancoPlaza() {
		return bancoPlaza;
	}

	public void setBancoPlaza(BancoPlaza bancoPlaza) {
		this.bancoPlaza = bancoPlaza;
	}

	public BancoPlaza getBancoPlazainter() {
		return bancoPlazainter;
	}

	public void setBancoPlazainter(BancoPlaza bancoPlazainter) {
		this.bancoPlazainter = bancoPlazainter;
	}

	public Beneficiario getBeneficiarioDet() {
		return beneficiarioDet;
	}

	public void setBeneficiarioDet(Beneficiario beneficiarioDet) {
		this.beneficiarioDet = beneficiarioDet;
	}

	public SocCuentassol getSocCuentassol() {
		return socCuentassol;
	}

	public void setSocCuentassol(SocCuentassol socCuentassol) {
		this.socCuentassol = socCuentassol;
	}

	public SwfMttransfer getSwfMttransfer() {
		return swfMttransfer;
	}

	public void setSwfMttransfer(SwfMttransfer swfMttransfer) {
		this.swfMttransfer = swfMttransfer;
	}

	public SocDetallessol getSocDetallessol() {
		return socDetallessol;
	}

	public void setSocDetallessol(SocDetallessol socDetallessol) {
		this.socDetallessol = socDetallessol;
	}

	public SocOrdenesPago getSocOrdenesPago() {
		return socOrdenesPago;
	}

	public void setSocOrdenesPago(SocOrdenesPago socOrdenesPago) {
		this.socOrdenesPago = socOrdenesPago;
	}

	public SwfMensaje getSwfMensaje() {
		return swfMensaje;
	}

	public void setSwfMensaje(SwfMensaje swfMensaje) {
		this.swfMensaje = swfMensaje;
	}

	
}
