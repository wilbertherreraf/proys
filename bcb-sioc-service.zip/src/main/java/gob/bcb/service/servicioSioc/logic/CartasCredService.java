package gob.bcb.service.servicioSioc.logic;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;

import gob.bcb.bpm.pruebaCU.CarCartascr;
import gob.bcb.bpm.pruebaCU.CarCartascrDao;
import gob.bcb.bpm.pruebaCU.CarCartascrdet;
import gob.bcb.bpm.pruebaCU.CarCartascrdetDao;
import gob.bcb.bpm.pruebaCU.CarCartascrdetPK;
import gob.bcb.bpm.pruebaCU.SocBancosDao;
import gob.bcb.bpm.pruebaCU.SocBenefs;
import gob.bcb.bpm.pruebaCU.SocBenefsDao;
import gob.bcb.bpm.pruebaCU.SocComitipoope;
import gob.bcb.bpm.pruebaCU.SocCuentassolDao;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocDetallessolDao;
import gob.bcb.bpm.pruebaCU.SocEsquemasDao;
import gob.bcb.bpm.pruebaCU.SocOpecomi;
import gob.bcb.bpm.pruebaCU.SocOpecomiDao;
import gob.bcb.bpm.pruebaCU.SocOpecomiId;
import gob.bcb.bpm.pruebaCU.SocRengscomp;
import gob.bcb.bpm.pruebaCU.SocRengscompDao;
import gob.bcb.bpm.pruebaCU.SocSolicitanteDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudctas;
import gob.bcb.bpm.pruebaCU.SocSolicitudctasDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudctasPK;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.SocSolicitudesDao;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.bpm.pruebaCU.UtilsSioc;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.pojos.BancoPlaza;
import gob.bcb.service.servicioSioc.pojos.Detallesol;
import gob.bcb.service.servicioTres.model.SaldoConcilia;
import gob.bcb.service.servicioTres.model.SaldoConciliaDao;
import gob.bcb.swift.commons.MensSwiftUtiles;

public class CartasCredService {
	private final Logger log = LoggerFactory.getLogger(CartasCredService.class);
	private final CarCartascrDao carCartascrDao;
	private final CarCartascrdetDao carCartascrdetDao;
	private final SocDetallessolDao socDetallessolDao;
	private final SocSolicitudesDao socSolicitudesDao;
	private final SocEsquemasDao socEsquemasDao;
	private final SocSolicitudctasDao socSolicitudctasDao;
	private final SocCuentassolDao socCuentassolDao;
	private final SocBenefsDao socBenefsDao;
	private final SocSolicitanteDao socSolicitanteDao;
	private final SocOpecomiDao socOpecomiDao;
	private final SocBancosDao socBancosDao;
	private final CartasCredSolicitudService cartasCredSolicitudService;
	private final SessionFactory sessionFactorySioc;
	private final SessionFactory sessionFactoryCoin;

	public static final Integer ESQ_CODIGO_PAGO = 281;
	public static final Integer ESQ_CODIGO_ENMIENDA_AMPLIACION = 283;
	public static final Integer ESQ_CODIGO_ENMIENDA_REDUCCION = 287;
	public static final Integer ESQ_CODIGO_ENMIENDA_INCREMENTO = 285;
	public static final Integer ESQ_CODIGO_ENMIENDA_DECREMENTO = 286;

	public static final String SWIFT_EOL = "\r\n";
	
	public CartasCredService(SessionFactory sessionFactorySioc, SessionFactory sessionFactoryCoin) {
		this.carCartascrDao = new CarCartascrDao();
		this.carCartascrDao.setSessionFactory(sessionFactorySioc);

		this.carCartascrdetDao = new CarCartascrdetDao();
		this.carCartascrdetDao.setSessionFactory(sessionFactorySioc);

		this.socDetallessolDao = new SocDetallessolDao();
		this.socDetallessolDao.setSessionFactory(sessionFactorySioc);

		this.sessionFactorySioc = sessionFactorySioc;
		this.sessionFactoryCoin = sessionFactoryCoin;

		this.socEsquemasDao = new SocEsquemasDao();
		this.socEsquemasDao.setSessionFactory(sessionFactorySioc);

		this.socSolicitudesDao = new SocSolicitudesDao();
		this.socSolicitudesDao.setSessionFactory(sessionFactorySioc);

		this.socSolicitudctasDao = new SocSolicitudctasDao();
		this.socSolicitudctasDao.setSessionFactory(sessionFactorySioc);

		this.socCuentassolDao = new SocCuentassolDao();
		this.socCuentassolDao.setSessionFactory(sessionFactorySioc);

		this.socBenefsDao = new SocBenefsDao();
		this.socBenefsDao.setSessionFactory(sessionFactorySioc);

		this.socSolicitanteDao = new SocSolicitanteDao();
		this.socSolicitanteDao.setSessionFactory(sessionFactorySioc);

		this.socOpecomiDao = new SocOpecomiDao();
		this.socOpecomiDao.setSessionFactory(sessionFactorySioc);
		
		this.socBancosDao = new SocBancosDao();
		this.socBancosDao.setSessionFactory(sessionFactorySioc);		

		this.cartasCredSolicitudService = new CartasCredSolicitudService(sessionFactorySioc, sessionFactoryCoin);
	}

	public Solicitud recuperarDatosCartaParaCodcartacr(String codcartacr) {
		CarCartascr carCartascr = carCartascrDao.findByCodcartacr(codcartacr);
		CarCartascrdet carCartascrdet = carCartascrdetDao.findByCodcartacrCcdTipomov(carCartascr.getCcrCodcartacr(), Constants.CLAVE_CCRED_TIPOMOVDETALLE_APERTURA,
				Constants.CLAVE_CCRED_TIPOEMISION_EMISION);

		Solicitud solicitud = cartasCredSolicitudService.recuperarSolicitudOpt(carCartascrdet.getCcdSoccodigo(), carCartascrdet.getCcdEsqcodigo());
		solicitud.setCarCartascr(carCartascr);
		solicitud.setCarCartascrdet(carCartascrdet);

		return cartasCredSolicitudService.recuperarDatosComplementarios(solicitud);
	}

	public Solicitud recuperarDatosCartaParaCodcartacr(String codcartacr, Integer nroccreddetIn) {
		log.info("Recuperando " + codcartacr + " : " + nroccreddetIn);
		CarCartascr carCartascr = carCartascrDao.findByCodcartacr(codcartacr);
		CarCartascrdet carCartascrdet = carCartascrdetDao.findByCodcartacrNroccreddet(codcartacr, nroccreddetIn);

		Solicitud solicitud = cartasCredSolicitudService.recuperarSolicitudOpt(carCartascrdet.getCcdSoccodigo(), carCartascrdet.getCcdEsqcodigo());

		solicitud.setCarCartascr(carCartascr);
		solicitud.setCarCartascrdet(carCartascrdet);

		return cartasCredSolicitudService.recuperarDatosComplementarios(solicitud);
	}

	public Solicitud inicilizaORecuperaEmisionCarta(String socCodigo) {
		log.info("Recuperando solicitud " + socCodigo);
		Solicitud solicitud = cartasCredSolicitudService.recuperarSolicitud(socCodigo);
		CarCartascr carCartascr = recuperarOCrearCartaParaSolicitud("", solicitud.getSolicitud());

		CarCartascrdet carCartascrdet = null;
		if (existCartaDetForSolicitud(socCodigo)) {
			carCartascrdet = carCartascrdetDao.findByCodcartacrCcdTipomov(carCartascr.getCcrCodcartacr(), Constants.CLAVE_CCRED_TIPOMOVDETALLE_APERTURA,
					Constants.CLAVE_CCRED_TIPOEMISION_EMISION);
		} else {
			carCartascrdet = nuevoCartascrdet(carCartascr.getCcrCodcartacr(), Constants.CLAVE_CCRED_TIPOMOVDETALLE_APERTURA, Constants.CLAVE_CCRED_TIPOEMISION_EMISION,
					solicitud.getSolicitud().getCodMoneda(), carCartascr.getCcrCodmontrans(), solicitud.getSolicitud().getEsqCodigo(), "");
			//carCartascr.setCcrMonto(socDetallessol.getDetMonto());
			// monto solicitado
			carCartascrdet.setCcdMonto(solicitud.getSolicitud().getSocMontome());
			carCartascrdet.setCcdCodmonmonto(solicitud.getSolicitud().getCodMoneda());
			carCartascrdet.setCcdGlosa(StringUtils.trimToEmpty(solicitud.getSolicitud().getDetConcepto()).toUpperCase());
		}

		solicitud.setCarCartascr(carCartascr);
		solicitud.setCarCartascrdet(carCartascrdet);

		return cartasCredSolicitudService.recuperarDatosComplementarios(solicitud);
	}

	public Solicitud recuperarCartaYDetalleParaSolicitud(String socCodigo) {
		Solicitud solicitud = new Solicitud();
		CarCartascrdet carCartascrdet = carCartascrdetDao.findBySocCodigo(socCodigo);
		CarCartascr carCartascr = carCartascrDao.findByCodcartacr(carCartascrdet.getId().getCcdCodcartacr());

		solicitud.setCarCartascr(carCartascr);
		solicitud.setCarCartascrdet(carCartascrdet);

		return solicitud;
	}

	public Solicitud inicilizaORecuperaPago(String codcartacr, String tipoEmision) {
		CarCartascr carCartascr = carCartascrDao.findByCodcartacr(codcartacr);

		CarCartascrdet carCartascrdet = nuevoCartascrdet(codcartacr, Constants.CLAVE_CCRED_TIPOMOVDETALLE_PAGO, tipoEmision, carCartascr.getCcrCodmontrans(),
				carCartascr.getCcrCodmontrans(), ESQ_CODIGO_PAGO, obtenerCodigoConcilia(codcartacr));

		carCartascrdet.setCcdFechareg(carCartascr.getCcrFechaemis());
		carCartascrdet.setCcdFechacargo(carCartascr.getCcrFechavtopag());

		Solicitud solicitud = cartasCredSolicitudService.inicializaSolicitudParaPagoEnmienda(carCartascr, carCartascrdet);

		final StringBuilder result = new StringBuilder();
		
		List<CarCartascrdet> lista = carCartascrdetDao.findByTipoemision(codcartacr, Constants.CLAVE_CCRED_TIPOEMISION_PAGO);
		Integer nroPagos = 1;

		for (CarCartascrdet carCartascrdetPag : lista) {
			if (carCartascrdetPag.getCcdEstmovccred().equals(Constants.CLAVE_CCRED_ESTMOVDETALLE_AUTORIZADO)) {
				nroPagos++;
			}
		}
		
		result.append("/BNF/PAYMENT NRO " + nroPagos);
		result.append(SWIFT_EOL);
		result.append("//BNK BK REF:");
		result.append(SWIFT_EOL);		
		result.append("//LC REF:" + carCartascr.getCcrCorrelativo());		
		solicitud.getSocDetallessolLista().get(0).setDetInfo(result.toString());
		return cartasCredSolicitudService.recuperarDatosComplementarios(solicitud);
	}

	public Solicitud inicilizaORecuperaEnmiendaFecha(String codcartacr, String tipoEmision) {
		CarCartascr carCartascr = carCartascrDao.findByCodcartacr(codcartacr);

		CarCartascrdet carCartascrdet = nuevoCartascrdet(codcartacr, Constants.CLAVE_CCRED_TIPOMOVDETALLE_ENMIENDA, tipoEmision, carCartascr.getCcrCodmontrans(),
				carCartascr.getCcrCodmontrans(), ESQ_CODIGO_ENMIENDA_AMPLIACION, obtenerCodigoConcilia(codcartacr));

		carCartascrdet.setCcdFechareg(carCartascr.getCcrFechaemis());
		carCartascrdet.setCcdFechacargo(carCartascr.getCcrFechavtopag());

		if (esEnmiendaDeReduccion(carCartascrdet)) {
			// el monto es cero ya que no hay comisiones
			carCartascrdet.setCcdEsqcodigo(ESQ_CODIGO_ENMIENDA_REDUCCION);
		}

		Solicitud solicitud = cartasCredSolicitudService.inicializaSolicitudParaPagoEnmienda(carCartascr, carCartascrdet);

		return cartasCredSolicitudService.recuperarDatosComplementarios(solicitud);
	}

	public Solicitud inicilizaORecuperaEnmiendaModificacion(String codcartacr, String tipoEmision) {
		CarCartascr carCartascr = carCartascrDao.findByCodcartacr(codcartacr);

		CarCartascrdet carCartascrdet = nuevoCartascrdet(codcartacr, Constants.CLAVE_CCRED_TIPOMOVDETALLE_ENMIENDA, tipoEmision, carCartascr.getCcrCodmontrans(),
				carCartascr.getCcrCodmontrans(), ESQ_CODIGO_ENMIENDA_REDUCCION, obtenerCodigoConcilia(codcartacr));

		// no existe dias de comision
		carCartascrdet.setCcdFechareg(carCartascr.getCcrFechaemis());
		carCartascrdet.setCcdFechacargo(carCartascr.getCcrFechavtopag());

		Solicitud solicitud = cartasCredSolicitudService.inicializaSolicitudParaPagoEnmienda(carCartascr, carCartascrdet);

		return cartasCredSolicitudService.recuperarDatosComplementarios(solicitud);
	}

	public void crearCartascrParaSolicitudDeEmision(Solicitud solicitud) {
		log.info("en crearCartascrParaSolicitudDeEmision " + solicitud.getCarCartascr().getCcrCodcartacr() + " socCodigo: " + solicitud.getSolicitud().getSocCodigo() + " "
				+ solicitud.getCarCartascrdet().getCcdTipoemision());
		CarCartascr carCartascr = recuperarOCrearCartaParaSolicitud(solicitud.getCarCartascr().getCcrCodcartacr(), solicitud.getSolicitud());

		if (esRegistroDeEmision(solicitud.getCarCartascrdet())) {

			validarCartacrFechas(solicitud.getCarCartascr());
			validarCartacrDatos(solicitud.getCarCartascr());

			carCartascr.setCcrFechaemis(solicitud.getCarCartascr().getCcrFechaemis());
			carCartascr.setCcrFechavtopag(solicitud.getCarCartascr().getCcrFechavtopag());

			if (StringUtils.isBlank(carCartascr.getCcrCodcartacr())) {
				carCartascr.setCcrCodcartacr(carCartascrDao.generarCodigo());
			}

			carCartascr.setCcrAnio(Integer.valueOf(UtilsDate.stringFromDate(carCartascr.getCcrFechaemis(), "yyyy")));
			carCartascr.setCcrNrocorr(carCartascrDao.nextNroCorr(carCartascr.getCcrCodcartacr(), carCartascr.getCcrTipoimpexp(), carCartascr.getCcrAnio()));
			carCartascr.setCcrCorrelativo(correlativoLiteral(carCartascr.getCcrTipoimpexp(), carCartascr.getCcrAnio(), carCartascr.getCcrNrocorr()));
			carCartascr.setCcrNrodias(nroDias(carCartascr.getCcrFechaemis(), carCartascr.getCcrFechavtopag()));
			//carCartascr.setCcrMonto(solicitud.getCarCartascr().getCcrMonto());
			carCartascr.setCcrNomexportador(solicitud.getCarCartascr().getCcrNomexportador());
			carCartascr.setCcrNomimportador(solicitud.getCarCartascr().getCcrNomimportador());
			carCartascr.setCcrNomproducto(solicitud.getCarCartascr().getCcrNomproducto());
			carCartascr.setCcrBencodigo(solicitud.getCarCartascr().getCcrBencodigo());
			// carCartascr.setCcrBcocodigo(solicitud.getCarCartascr().getCcrBcocodigo());

			carCartascr.setCcrAuditusr(solicitud.getCodUsuarioAudit());
			carCartascr.setCcrAuditwst(solicitud.getCodEstacionAudit());

			carCartascrDao.saveOrUpdate(carCartascr);
			String codcartacr = carCartascr.getCcrCodcartacr();

			guardarOActualizarCartascrDetalleParaEmisionSolicitud(codcartacr, solicitud);

			if (solicitud.getSocSolicitudctasLista().size() == 0) {
				throw new BusinessException("No existe datos de cuenta acreditivo en SocSolicitudctasLista.");
			}
			cartasCredSolicitudService.guardarCtaAcreditivo(solicitud.getSolicitud().getSocCodigo(), solicitud.getSocSolicitudctasLista().get(0));
			return;
		}

		throw new BusinessException("Carta de crédito [" + carCartascr.getCcrCodcartacr() + "] en estado invalido, no puede modificar.");
	}

	private void guardarOActualizarCartascrDetalleParaEmisionSolicitud(String codcartacr, Solicitud solicitudIn) {

		// CarCartascr carCartascr = carCartascrDao.findByCodcartacr(codcartacr);

		Solicitud solicitud = cartasCredSolicitudService.recuperarSolicitud(solicitudIn.getSolicitud().getSocCodigo());
		SocDetallessol socDetallessol = solicitud.getSocDetallessolLista().get(0);

		Integer nroccreddet = guardarOActualizarCartadet(codcartacr, solicitudIn.getCarCartascrdet(), solicitudIn, solicitudIn.getCodUsuarioAudit(),
				solicitudIn.getCodEstacionAudit());
		CarCartascrdet carCartascrdet = carCartascrdetDao.findByCodcartacrNroccreddet(codcartacr, nroccreddet);

		carCartascrdet.setCcdSoccodigo(socDetallessol.getId().getSocCodigo());
		carCartascrdet.setCcdDetcodigo(socDetallessol.getId().getDetCodigo());

		carCartascrdetDao.saveOrUpdate(carCartascrdet);
	}

	public Integer guardarOActualizarPagoEnmienda(Solicitud solicitudIn) {
		// registro de un pago posterior al llenado de datos en la vista
		log.info("Guardar o actualizando carta {}", solicitudIn.getCarCartascr().getCcrCodcartacr());

		// CarCartascr carCartascr =
		// carCartascrDao.findByCodcartacr(solicitudIn.getCarCartascr().getCcrCodcartacr());

		Integer nroccreddet = guardarOActualizarCartadet(solicitudIn.getCarCartascr().getCcrCodcartacr(), solicitudIn.getCarCartascrdet(), solicitudIn,
				solicitudIn.getCodUsuarioAudit(), solicitudIn.getCodEstacionAudit());

		CarCartascrdet carCartascrdet = carCartascrdetDao.findByCodcartacrNroccreddet(solicitudIn.getCarCartascr().getCcrCodcartacr(), nroccreddet);

		return carCartascrdet.getId().getCcdNroccreddet();
	}

	private Integer guardarOActualizarCartadet(String codcartacr, CarCartascrdet carCartascrdetIn, Solicitud solicitudIn, String codUsuarioAudit, String codEstacionAudit) {
		CarCartascr carCartascr = carCartascrDao.findByCodcartacr(codcartacr);
		Assert.notNull(carCartascrdetIn.getCcdTipoemision(), "Tipo de registro debe tener valor (Emision, pago, incremento, decremento).");
		Assert.notNull(carCartascrdetIn.getCcdEsqcodigo(), "Codigo de esquema en campo CcdEsqcodigo debe tener valor");

		// la moneda es la moneda registrada
		CarCartascrdet carCartascrdet = crearORecuperarCarCartascrdet(carCartascr.getCcrCodcartacr(), carCartascrdetIn.getId().getCcdNroccreddet(),
				carCartascrdetIn.getCcdTipomov(), carCartascrdetIn.getCcdTipoemision(), carCartascrdetIn.getCcdCodmonmonto(), carCartascrdetIn.getCcdCodmontrans(),
				carCartascrdetIn.getCcdEsqcodigo());

		if (carCartascrdet.getId().getCcdNroccreddet() == null) {
			carCartascrdet.getId().setCcdNroccreddet(carCartascrdetDao.nextNroCorrDetalle(carCartascr.getCcrCodcartacr()));
		}

		verificaSiEsPendiente(carCartascrdet);
		carCartascrdet.setCcdTipoemision(carCartascrdetIn.getCcdTipoemision());
		carCartascrdet.setCcdGlosa(StringUtils.trimToEmpty(carCartascrdetIn.getCcdGlosa().trim()).toUpperCase());
		carCartascrdet.setCcdFechacont(solicitudIn.getSolicitud().getFechaCont());
		carCartascrdet.setCcdFechareg(carCartascr.getCcrFechaemis());
		carCartascrdet.setCcdMonto(carCartascrdetIn.getCcdMonto());
		carCartascrdet.setCcdCodbcoreceptor(carCartascrdetIn.getCcdCodbcoreceptor());
		carCartascrdet.setCcdCodbcornocta(carCartascrdetIn.getCcdCodbcornocta());		
		carCartascrdet.setCcdNrodias(0);

		// la moneda de destino deberia ser la de la carta
		carCartascrdet.setCcdCodmontrans(carCartascr.getCcrCodmontrans());

		Assert.notNull(carCartascrdet.getCcdFechacont(), "Fecha operación inválida");

		if (esRegistroDeEmision(carCartascrdet)) {
			carCartascrdet.setCcdFechacargo(carCartascr.getCcrFechavtopag());
			validarCartacrdetFechas(carCartascrdet);
			carCartascrdet.setCcdNrodias(nroDias(carCartascrdet.getCcdFechareg(), carCartascrdet.getCcdFechacargo()));
			Assert.isTrue(carCartascrdet.getCcdMonto() != null && carCartascrdet.getCcdMonto().compareTo(BigDecimal.ZERO) != 0, "El campo monto debe tener valor");

		} else if (esRegistroDePago(carCartascrdet)) {
			carCartascrdet.setCcdEsqcodigo(ESQ_CODIGO_PAGO);
			carCartascrdet.setCcdFechacargo(carCartascr.getCcrFechavtopag());
			// moneda de la transferencia
			carCartascrdet.setCcdCodmonmonto(carCartascrdetIn.getCcdCodmonmonto());

			// en pagos el monto transferido es el monto debitado de acreditivos
			carCartascrdet.setCcdMontotrans(carCartascrdetIn.getCcdMontotrans().setScale(2, BigDecimal.ROUND_HALF_UP));
			carCartascrdet.setCcdCodmontrans(carCartascr.getCcrCodmontrans());

			validarCartacrdetFechas(carCartascrdet);

			Assert.isTrue(carCartascrdet.getCcdMontotrans() != null && carCartascrdet.getCcdMontotrans().compareTo(BigDecimal.ZERO) != 0, "El campo monto debe tener valor");
			Assert.notNull(carCartascrdet.getCcdCodbcoreceptor(), "Banco Beneficiario debe tener un valor");

			BancoPlaza bancoPlaza = socBancosDao.bancoPlazaByCod(carCartascrdet.getCcdCodbcoreceptor());
			Assert.notNull(bancoPlaza, "Banco " +carCartascrdet.getCcdCodbcoreceptor()+ " de beneficiario inexistente.");
			Assert.notNull(bancoPlaza.getSocPlazas().getPlaBic(), "Banco " +carCartascrdet.getCcdCodbcoreceptor()+ " de beneficiario requiere BIC.");
			
			verificarSaldo(carCartascr.getCcrCodcartacr(), carCartascrdet.getCcdMontotrans());

		} else if (esEnmiendaDeAmpliacion(carCartascrdet) || esEnmiendaDeReduccion(carCartascrdet) || esEnmiendaDeModificacionDatos(carCartascrdet)) {
			carCartascrdet.setCcdEsqcodigo(ESQ_CODIGO_ENMIENDA_AMPLIACION);

			carCartascrdet.setCcdFechareg(carCartascr.getCcrFechavtopag());
			carCartascrdet.setCcdFechacargo(carCartascrdetIn.getCcdFechacargo());

			BigDecimal saldo = saldoCarta(carCartascr.getCcrCodcartacr());
			// sobre el saldo
			carCartascrdet.setCcdMonto(saldo);
			carCartascrdet.setCcdCodmonmonto(carCartascr.getCcrCodmontrans());

			Assert.notNull(carCartascrdet.getCcdFechareg(), "Fecha inicio inválida");
			Assert.notNull(carCartascrdet.getCcdFechacargo(), "Fecha fin inválida");

			SocOpecomi socOpecomi = comisionEmisionMontoSaldoBS(carCartascrdet, carCartascrdet.getCcdFechacont());

			if (socOpecomi.getOcoMonto().compareTo(BigDecimal.ZERO) == 0) {
				// si no existe comisiones por emision
				SocComitipoope socComitipoope = porcComisionEnmienda(carCartascrdet);
				carCartascrdet.setCcdTipomov(Constants.CLAVE_CCRED_TIPOMOVDETALLE_COMISION);
				carCartascrdet.setCcdMontotrans(socComitipoope.getValor());
			} else {
				carCartascrdet.setCcdNrodias(socOpecomi.getOcoMontoimpt().intValue());
				carCartascrdet.setCcdTipomov(Constants.CLAVE_CCRED_TIPOMOVDETALLE_ENMIENDA);
				carCartascrdet.setCcdMontotrans(socOpecomi.getOcoMonto());
			}

			carCartascrdet.setCcdCodmontrans(Constants.COD_MONEDA_BS);

		} else if (esEnmiendaDeIncremento(carCartascrdet)) {
			carCartascrdet.setCcdEsqcodigo(ESQ_CODIGO_ENMIENDA_INCREMENTO);
			carCartascrdet.setCcdFechareg(carCartascrdetIn.getCcdFechareg());
			carCartascrdet.setCcdFechacargo(carCartascrdetIn.getCcdFechacargo());

			Assert.notNull(carCartascrdet.getCcdFechareg(), "Fecha inicio inválida");
			Assert.notNull(carCartascrdet.getCcdFechacargo(), "Fecha fin inválida");

			carCartascrdet.setCcdNrodias(nroDias(carCartascrdet.getCcdFechareg(), carCartascrdet.getCcdFechacargo()));
			Assert.isTrue(carCartascrdet.getCcdMonto() != null && carCartascrdet.getCcdMonto().compareTo(BigDecimal.ZERO) != 0, "El campo monto debe tener valor");

		} else if (esEnmiendaDeDecremento(carCartascrdet)) {
			carCartascrdet.setCcdEsqcodigo(ESQ_CODIGO_ENMIENDA_DECREMENTO);
			carCartascrdet.setCcdFechacargo(carCartascrdetIn.getCcdFechacargo());

			// la moneda deberia ser la de la carta
			carCartascrdet.setCcdCodmonmonto(carCartascr.getCcrCodmontrans());
			carCartascrdet.setCcdMontotrans(carCartascrdet.getCcdMonto().setScale(2, BigDecimal.ROUND_HALF_UP));
			carCartascrdet.setCcdCodmontrans(carCartascr.getCcrCodmontrans());

			Assert.notNull(carCartascrdet.getCcdFechareg(), "Fecha inicio inválida");
			Assert.notNull(carCartascrdet.getCcdFechacargo(), "Fecha fin inválida");

			carCartascrdet.setCcdNrodias(nroDias(carCartascrdet.getCcdFechareg(), carCartascrdet.getCcdFechacargo()));

			Assert.isTrue(carCartascrdet.getCcdMonto() != null && carCartascrdet.getCcdMonto().compareTo(BigDecimal.ZERO) != 0, "El campo monto debe tener valor");

			verificarSaldo(carCartascr.getCcrCodcartacr(), carCartascrdet.getCcdMonto());
		} else {
			throw new BusinessException("Tipo de operación no implementada " + carCartascr.getCcrCodcartacr() + " tipo mov.:" + solicitudIn.getCarCartascrdet().getCcdTipomov()
					+ " tipo emision: " + solicitudIn.getCarCartascrdet().getCcdTipoemision() + " comunique a sistemas.");
		}

		validarCartacrDetalleDatos(carCartascrdet);

		carCartascrdet.setCcdAuditusr(codUsuarioAudit);
		carCartascrdet.setCcdAuditwst(codEstacionAudit);

		carCartascrdetDao.saveOrUpdate(carCartascrdet);
		return carCartascrdet.getId().getCcdNroccreddet();
	}

	public void actualizarAFecha(Solicitud solicitudIn) {
		// registro de un pago posterior al llenado de datos en la vista
		log.info("Actualizando a fecha {}", solicitudIn.getCarCartascr().getCcrCodcartacr());
		Solicitud solicitudTO = cartasCredSolicitudService.recuperarSolicitud(solicitudIn.getSolicitud().getSocCodigo());		
		Solicitud solicitud = recuperarCartaYDetalleParaSolicitud(solicitudIn.getSolicitud().getSocCodigo());
		
		CarCartascr carCartascr = solicitud.getCarCartascr();		
		CarCartascrdet carCartascrdet = solicitud.getCarCartascrdet();
		carCartascrdet.setCcdFechacont(solicitudIn.getSolicitud().getFechaCont());

		if (esCartaConComisionDeEmision(carCartascrdet)) {
			Map<String, Object> montoConvertido = UtilsSioc.conversion(solicitudTO.getSocDetallessolLista().get(0).getDetMontotrans(), solicitudTO.getSocDetallessolLista().get(0).getCodMonedatdet(), carCartascr.getCcrCodmontrans(),
					solicitudTO.getSolicitud().getFechaCont(), null, "C");
			BigDecimal montoMO = (BigDecimal) montoConvertido.get("montomo");
			
			// en enmisiones se actualiza el monto transfereido
			carCartascrdet.setCcdMontotrans(montoMO);
			carCartascrdet.setCcdCodmontrans(carCartascr.getCcrCodmontrans());

			// el monto de la carta sera el monto transferido en la emision
			carCartascr.setCcrMonto(carCartascrdet.getCcdMontotrans());
			
			carCartascrDao.saveOrUpdate(carCartascr);			
		} else if (esRegistroDePago(carCartascrdet)) {
			// actualizamos el monto de transferencia 
			carCartascrdet.setCcdMonto(solicitudTO.getSocDetallessolLista().get(0).getDetMontotrans());			
			carCartascrdet.setCcdCodmonmonto(solicitudTO.getSocDetallessolLista().get(0).getCodMonedatdet());			
		}
		
		carCartascrdet.setCcdAuditusr(solicitudIn.getCodUsuarioAudit());
		carCartascrdet.setCcdAuditwst(solicitudIn.getCodEstacionAudit());

		carCartascrdetDao.saveOrUpdate(carCartascrdet);
	}

	public void preAutorizarEmisionCartascr(Solicitud solicitudIn) {
		// actualiza datos de detalle carta despues de pre autorizar transferencia de
		// la solicitud
		Solicitud solicitud = cartasCredSolicitudService.recuperarSolicitud(solicitudIn.getSolicitud().getSocCodigo());

		for (SocDetallessol socDetallessol : solicitud.getSocDetallessolLista()) {
			CarCartascrdet carCartascrdet = carCartascrdetDao.findBySocCodigoDetcodigoEstDet(socDetallessol.getId().getSocCodigo(), socDetallessol.getId().getDetCodigo(),
					Constants.CLAVE_CCRED_ESTMOVDETALLE_PENDIENTE);
			log.info("Preautorizando " + carCartascrdet.getId().getCcdCodcartacr() + " " + carCartascrdet.getId().getCcdNroccreddet());

			carCartascrdet.setCcdEstmovccred(Constants.CLAVE_CCRED_ESTMOVDETALLE_PREAUTORIZADO);

			carCartascrdet.setCcdAuditusr(solicitudIn.getCodUsuarioAudit());
			carCartascrdet.setCcdAuditwst(solicitudIn.getCodEstacionAudit());

			carCartascrdetDao.saveOrUpdate(carCartascrdet);
		}
	}

	public void autorizarCartascrdetParaSolicitudAutorizada(Solicitud solicitudIn) {
		// actualiza datos de detalle carta despues de contabilizar la transferencia

		CarCartascrdet carCartascrdet = obtenerRegistroDetallePreautorizado(solicitudIn.getSolicitud().getSocCodigo());
		log.info("Autorizando " + carCartascrdet.getId().getCcdCodcartacr() + " " + carCartascrdet.getId().getCcdNroccreddet());
		carCartascrdet.setCcdEstmovccred(Constants.CLAVE_CCRED_ESTMOVDETALLE_AUTORIZADO);

		// obtenemos el numero concilia de coin
		carCartascrdet.setCcdRengconcilia(recuperarDatosConciliaParaSolicitud(solicitudIn.getSolicitud().getSocCodigo()));
		// carCartascrdet.setCcdFechacont(socSolicitudes.getFechaCont());

		carCartascrdet.setCcdAuditusr(solicitudIn.getCodUsuarioAudit());
		carCartascrdet.setCcdAuditwst(solicitudIn.getCodEstacionAudit());

		carCartascrdetDao.saveOrUpdate(carCartascrdet);

		actualizarCartacrParaCarCartascrdet(carCartascrdet.getId().getCcdCodcartacr(), carCartascrdet.getId().getCcdNroccreddet());
	}

	private void actualizarCartacrParaCarCartascrdet(String codcartacr, Integer nroccreddet) {

		CarCartascr carCartascr = carCartascrDao.findByCodcartacr(codcartacr);
		CarCartascrdet carCartascrdet = carCartascrdetDao.findByCodcartacrNroccreddet(carCartascr.getCcrCodcartacr(), nroccreddet);

		// total de la carta = suma de las aperturas mas enmiendas a monto
		BigDecimal totalCarta = carCartascrdetDao.totalMontoCarta(codcartacr);
		carCartascr.setCcrMonto(totalCarta);

		if (esEnmiendaDeAmpliacion(carCartascrdet) || esEnmiendaDeReduccion(carCartascrdet) || esEnmiendaDeModificacionDatos(carCartascrdet)
				|| esEnmiendaDeIncremento(carCartascrdet) || esEnmiendaDeDecremento(carCartascrdet)) {
			carCartascr.setCcrFechavtopag(carCartascrdet.getCcdFechacargo());
		}

		carCartascr.setCcrNrodias(nroDias(carCartascr.getCcrFechaemis(), carCartascr.getCcrFechavtopag()));
		carCartascr.setCcrSaldo(saldoCarta(codcartacr));

		if (carCartascr.getCcrSaldo().compareTo(BigDecimal.ZERO) == 0 && !esRegistroDeEmision(carCartascrdet)) {
			log.info("Carta [" + carCartascr.getCcrCodcartacr() + "] con saldo CERO cambiando a Liquidado");
			carCartascr.setCcrEstadoccred(Constants.CLAVE_CCRED_ESTCARTACRED_LIQUIDADO);
		} else {
			if (carCartascr.getCcrSaldo().compareTo(BigDecimal.ZERO) != 0 && !esRegistroDeEmision(carCartascrdet)) {
				carCartascr.setCcrEstadoccred(Constants.CLAVE_CCRED_ESTCARTACRED_VIGENTE);
			}
		}

		carCartascrDao.saveOrUpdate(carCartascr);

		// control del saldo en SIOC con el saldo en coin
		verificarSaldoConCoin(codcartacr);
	}

	public void rechazarCartascrdet(Solicitud solicitudIn) {
		// actualiza datos de detalle carta despues de pre autorizar transferencia de
		// emision
		Solicitud solicitud = cartasCredSolicitudService.recuperarSolicitud(solicitudIn.getSolicitud().getSocCodigo());
		SocDetallessol socDetallessol = solicitud.getSocDetallessolLista().get(0);

		CarCartascrdet carCartascrdet = carCartascrdetDao.findBySocCodigoDetcodigo(socDetallessol.getId().getSocCodigo(), socDetallessol.getId().getDetCodigo());

		verificaSiEstaAutorizado(carCartascrdet);

		carCartascrdet.setCcdEstmovccred(Constants.CLAVE_CCRED_ESTMOVDETALLE_PENDIENTE);

		carCartascrdet.setCcdAuditusr(solicitudIn.getCodUsuarioAudit());
		carCartascrdet.setCcdAuditwst(solicitudIn.getCodEstacionAudit());

		carCartascrdetDao.saveOrUpdate(carCartascrdet);
		log.info("Carta Rechazada " + carCartascrdet.getId().getCcdCodcartacr() + " - " + carCartascrdet.getId().getCcdNroccreddet());
	}

	public void suspenderCartascrdet(Solicitud solicitudIn) {
		// actualiza datos de detalle carta despues de pre autorizar transferencia de
		// emision
		Solicitud solicitud = cartasCredSolicitudService.recuperarSolicitud(solicitudIn.getSolicitud().getSocCodigo());
		SocDetallessol socDetallessol = solicitud.getSocDetallessolLista().get(0);

		CarCartascrdet carCartascrdet = carCartascrdetDao.findBySocCodigoDetcodigo(socDetallessol.getId().getSocCodigo(), socDetallessol.getId().getDetCodigo());

		verificaSiEstaAutorizado(carCartascrdet);

		carCartascrdet.setCcdEstregistro(Constants.CLAVE_CCRED_ESTREGISTRO_SUSPENDIDO);

		carCartascrdet.setCcdAuditusr(solicitudIn.getCodUsuarioAudit());
		carCartascrdet.setCcdAuditwst(solicitudIn.getCodEstacionAudit());

		carCartascrdetDao.saveOrUpdate(carCartascrdet);
		log.info("Carta suspendida " + carCartascrdet.getId().getCcdCodcartacr() + " - " + carCartascrdet.getId().getCcdNroccreddet());
	}

	public void guardarCartascrSinEnmienda(Solicitud solicitud) {
		log.info("en guardarCartascrSinEnmienda " + solicitud.getCarCartascr().getCcrCodcartacr());
		CarCartascr carCartascr = recuperarCartaParaModificar(solicitud.getCarCartascr().getCcrCodcartacr());
		CarCartascrdet carCartascrdet = carCartascrdetDao.findByCodcartacrCcdTipomov(carCartascr.getCcrCodcartacr(), Constants.CLAVE_CCRED_TIPOMOVDETALLE_APERTURA,
				Constants.CLAVE_CCRED_TIPOEMISION_EMISION);

		if (!carCartascrdet.getCcdEstmovccred().equals(Constants.CLAVE_CCRED_ESTMOVDETALLE_AUTORIZADO)) {
			throw new BusinessException("Registro de emisión debe estar autorizado");
		}

		carCartascr.setCcrNomexportador(solicitud.getCarCartascr().getCcrNomexportador());
		carCartascr.setCcrNomimportador(solicitud.getCarCartascr().getCcrNomimportador());
		carCartascr.setCcrNomproducto(solicitud.getCarCartascr().getCcrNomproducto());
		carCartascr.setCcrBencodigo(solicitud.getCarCartascr().getCcrBencodigo());

		carCartascr.setCcrAuditusr(solicitud.getCodUsuarioAudit());
		carCartascr.setCcrAuditwst(solicitud.getCodEstacionAudit());

		carCartascrDao.saveOrUpdate(carCartascr);

		cartasCredSolicitudService.guardarCtaAcreditivo(solicitud.getSolicitud().getSocCodigo(), solicitud.getSocSolicitudctasLista().get(0));
	}

	public Solicitud inicializarSolicitudParaPagoEnmienda(String codcartacr, Integer nroccreddet, Solicitud solicitudIn) {
		log.info("en inicializarSolicitudParaPagoEnmienda para carta {}", codcartacr);

		CarCartascr carCartascr = carCartascrDao.findByCodcartacr(codcartacr);
		CarCartascrdet carCartascrdet = carCartascrdetDao.findByCodcartacrNroccreddet(codcartacr, nroccreddet);

		Solicitud solicitud = cartasCredSolicitudService.inicializarOActualizarRegistroSolicitudParaPagoEnmienda(carCartascr, carCartascrdet, solicitudIn);

		CarCartascrdet carCartascrdetEmis = obtenerRegistroAperturaAutorizado(carCartascr.getCcrCodcartacr());

		Solicitud solicitudFactsYCtasEmis = cartasCredSolicitudService.recuperarFacturasYAgregarCtas(carCartascrdetEmis.getCcdSoccodigo(),
				solicitudIn.getSocSolicitudctasLista());

		solicitud.setSocSolicitudctasLista(solicitudFactsYCtasEmis.getSocSolicitudctasLista());
		solicitud.setSocOpecomiLista(solicitudFactsYCtasEmis.getSocOpecomiLista());

		return solicitud;
	}

	private CarCartascr recuperarOCrearCartaParaSolicitud(String codcartacr, SocSolicitudes socSolicitudes) {
		if (!StringUtils.isBlank(codcartacr)) {
			return carCartascrDao.findByCodcartacr(codcartacr);
		}

		if (!existCartaForSocCodigo(socSolicitudes.getSocCodigo())) {
			return crearCartaParaSolicitud(socSolicitudes.getSocCodigo(), socSolicitudes.getCodMoneda(), socSolicitudes.getCodMonedat(), socSolicitudes.getSolCodigo());
		}
		return carCartascrDao.findBySoccodigo(socSolicitudes.getSocCodigo());
	}

	private CarCartascr recuperarCartaParaModificar(String codcartacr) {
		return carCartascrDao.findByCodcartacrEstcred(codcartacr, Constants.CLAVE_CCRED_ESTCARTACRED_VIGENTE);
	}

	public void asignarSocDetallessolACarCartascrdet(String codcartacr, Integer nroccreddet, String socCodigo, Integer detCodigo) {
		CarCartascrdet carCartascrdet = carCartascrdetDao.findByCodcartacrNroccreddet(codcartacr, nroccreddet);

		log.info("Asignando socDetallessol[" + socCodigo + " - " + detCodigo + "] a detalle carta [" + codcartacr + " - " + nroccreddet + "] ");

		SocDetallessol socDetallessolIn = socDetallessolDao.getDetalle(socCodigo, detCodigo);
		if (socDetallessolIn == null) {
			throw new BusinessException("Solicitud Detalle[ " + socCodigo + " - " + detCodigo + "] inexistente");
		}

		carCartascrdet.setCcdSoccodigo(socCodigo);
		carCartascrdet.setCcdDetcodigo(detCodigo);

		carCartascrdetDao.saveOrUpdate(carCartascrdet);
	}

	public boolean existCartaDetForSolicitud(String socCodigo) {
		try {
			carCartascrdetDao.findBySocCodigo(socCodigo);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public boolean existCartaForSocCodigo(String socCodigo) {
		try {
			if (StringUtils.isBlank(socCodigo)) {
				return false;
			}

			carCartascrDao.findBySoccodigo(socCodigo);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public static String correlativoLiteral(String tipoimpexp, Integer anio, Integer correlativo) {
		return tipoimpexp + "-" + anio + "-" + correlativo;
	}

	public Integer nroDiasEnmiendaAmpliacion(String socCodigo) {
		Integer dias = 0;
		List<SocDetallessol> socDetallesopeLista = socDetallessolDao.getDetalles(socCodigo);
		for (SocDetallessol socDetallessol : socDetallesopeLista) {
			CarCartascrdet carCartascrdet = carCartascrdetDao.findBySocCodigoDetcodigo(socDetallessol.getId().getSocCodigo(), socDetallessol.getId().getDetCodigo());
			dias = dias + nroDiasParaSaldo(carCartascrdet.getId().getCcdCodcartacr(), carCartascrdet);
		}
		return dias;
	}

	public Integer nroDiasParaSaldo(String ccdCodcartacr, CarCartascrdet carCartascrdet) {
		Integer dias = 0;
		Integer ccdDetcodigo = carCartascrdetDao.ultimoRegistroDeVctoFecha(ccdCodcartacr);

		if (ccdDetcodigo.compareTo(0) != 0) {
			CarCartascrdet carCartascrdetUltimo = carCartascrdetDao.findByCodcartacrNroccreddet(ccdCodcartacr, ccdDetcodigo);
			dias = nroDias(carCartascrdetUltimo.getCcdFechacargo(), carCartascrdet.getCcdFechacargo());
		}

		return dias;
	}

	public SocOpecomi comisionEmisionMontoTransferenciaBS(SocSolicitudes socSolicitudes, BigDecimal montoTransferencia, Integer codMonedaMonto, Date fechaTc) {
		List<SocDetallessol> socDetallesopeLista = socDetallessolDao.getDetalles(socSolicitudes.getSocCodigo());
		SocDetallessol socDetallessol = socDetallesopeLista.get(0);

		CarCartascrdet carCartascrdet = carCartascrdetDao.findBySocCodigoDetcodigo(socDetallessol.getId().getSocCodigo(), socDetallessol.getId().getDetCodigo());

		SocOpecomiId socOpecomiId = new SocOpecomiId(Constants.COD_VAR_MONTOCOMEMISCARTCREDMT, socSolicitudes.getSocCodigo(), 0);
		SocOpecomi socOpecomi = new SocOpecomi();
		socOpecomi.setId(socOpecomiId);

		socOpecomi.setOcoMonto(BigDecimal.ZERO);
		socOpecomi.setMontoMo(BigDecimal.ZERO);
		socOpecomi.setOcoMontoimpt(BigDecimal.ZERO);
		socOpecomi.setCodMoneda(codMonedaMonto);
		socOpecomi.setClaEstadovar(Constants.CLAVE_CLA_ESTADOVAR_REGISTRADO);

		if (esCartaConComisionDeEmision(carCartascrdet)) {
			SocComitipoope socComitipoope = porcComisionEmision(carCartascrdet);
			Integer dias = nroDias(carCartascrdet.getCcdFechareg(), carCartascrdet.getCcdFechacargo());
			BigDecimal comisionEmision = comisionEmisionUSD(dias, montoTransferencia, codMonedaMonto, socComitipoope.getValor(), fechaTc);

			if (comisionEmision.compareTo(BigDecimal.ZERO) != 0) {
				socOpecomi.setMontoMo(montoTransferencia);
				socOpecomi.setCodMoneda(codMonedaMonto);
				socOpecomi.setOcoMonto(comisionEmision);
				socOpecomi.setOcoMontoimpt(BigDecimal.valueOf(dias));
				socOpecomi.setTipoCambio(BigDecimal.valueOf(1));

				String rangoFechas = UtilsDate.stringFromDate(carCartascrdet.getCcdFechareg(), "dd/MM/yyyy");
				rangoFechas = rangoFechas.concat(" : ").concat(UtilsDate.stringFromDate(carCartascrdet.getCcdFechacargo(), "dd/MM/yyyy"));
				socOpecomi.setFactura(rangoFechas);
			}
		}
		return socOpecomi;
	}

	public SocOpecomi comisionEmisionMontoSaldoBS(CarCartascrdet carCartascrdet, Date fechaTc) {
		SocOpecomiId socOpecomiId = new SocOpecomiId(Constants.COD_VAR_MONTOCOMEMISCARTCREDSLD, carCartascrdet.getCcdSoccodigo(), 0);

		SocOpecomi socOpecomi = new SocOpecomi();
		socOpecomi.setId(socOpecomiId);

		socOpecomi.setOcoMonto(BigDecimal.ZERO);
		socOpecomi.setMontoMo(BigDecimal.ZERO);
		socOpecomi.setOcoMontoimpt(BigDecimal.ZERO);
		socOpecomi.setClaEstadovar(Constants.CLAVE_CLA_ESTADOVAR_REGISTRADO);

		CarCartascr carCartascr = carCartascrDao.findByCodcartacr(carCartascrdet.getId().getCcdCodcartacr());

		Integer ccdDetcodigoUltVigente = carCartascrdetDao.ultimoRegistroDeVctoFecha(carCartascrdet.getId().getCcdCodcartacr());
		Integer diasCarta = 0;
		String rangoFechas = "";

		if (ccdDetcodigoUltVigente.compareTo(0) != 0) {
			CarCartascrdet carCartascrdetUltimo = carCartascrdetDao.findByCodcartacrNroccreddet(carCartascrdet.getId().getCcdCodcartacr(), ccdDetcodigoUltVigente);
			diasCarta = nroDias(carCartascrdetUltimo.getCcdFechacargo(), carCartascrdet.getCcdFechacargo());

			rangoFechas = UtilsDate.stringFromDate(carCartascrdetUltimo.getCcdFechacargo(), "dd/MM/yyyy");
			rangoFechas = rangoFechas.concat(" : ").concat(UtilsDate.stringFromDate(carCartascrdet.getCcdFechacargo(), "dd/MM/yyyy"));
		}

		SocComitipoope socComitipoope = porcComisionEmision(carCartascrdet);

		BigDecimal saldo = saldoCarta(carCartascrdet.getId().getCcdCodcartacr());
		BigDecimal comisionEmision = comisionEmisionUSD(diasCarta, saldo, carCartascr.getCcrCodmontrans(), socComitipoope.getValor(), fechaTc);

		if (comisionEmision.compareTo(BigDecimal.ZERO) != 0) {
			socOpecomi.setMontoMo(saldo);
			socOpecomi.setCodMoneda(carCartascr.getCcrCodmontrans());
			socOpecomi.setOcoMonto(comisionEmision);
			socOpecomi.setOcoMontoimpt(BigDecimal.valueOf(diasCarta));
			socOpecomi.setTipoCambio(BigDecimal.valueOf(1));
			socOpecomi.setFactura(rangoFechas);
		}

		return socOpecomi;
	}

	public SocOpecomi comisionEmisionMontoSaldoBS(SocSolicitudes socSolicitudes, Date fechaTc) {
		List<SocDetallessol> socDetallesopeLista = socDetallessolDao.getDetalles(socSolicitudes.getSocCodigo());
		SocDetallessol socDetallessol = socDetallesopeLista.get(0);

		CarCartascrdet carCartascrdet = carCartascrdetDao.findBySocCodigoDetcodigo(socDetallessol.getId().getSocCodigo(), socDetallessol.getId().getDetCodigo());
		return comisionEmisionMontoSaldoBS(carCartascrdet, fechaTc);
	}

	public static BigDecimal comisionEmisionUSD(Integer diasCarta, BigDecimal montoMO, Integer codMonedaMonto, BigDecimal tasaComision, Date fechaTc) {

		if (diasCarta.compareTo(Integer.valueOf(0)) <= 0) {
			return BigDecimal.ZERO;
		}

		Map<String, Object> montoConvertido = UtilsSioc.conversion(montoMO, codMonedaMonto, Constants.COD_MONEDA_USD, fechaTc, null, "C");
		BigDecimal montoSUS = (BigDecimal) montoConvertido.get("montomo");

		// para Cartas comiPorc = dias carta * porccomis / 360 dias
		BigDecimal diasCartaBD = BigDecimal.valueOf(diasCarta).setScale(0);
		BigDecimal anios = BigDecimal.valueOf(Constants.DIAS_CARTA_CREDITO_ANIO).setScale(0);

		BigDecimal equivDiasAnioCarta = diasCartaBD.divide(anios, 8, RoundingMode.HALF_UP);

		// moneda de la cuenta a debitar del cargo
		BigDecimal comiPorc = tasaComision.divide(BigDecimal.valueOf(100));

		BigDecimal montoComsionUSD = montoSUS.multiply(comiPorc.multiply(equivDiasAnioCarta)).setScale(2, BigDecimal.ROUND_HALF_UP);
		return montoComsionUSD;
	}

	public static Integer nroDias(Date fechaemis, Date fechavtopag) {
		Assert.notNull(fechaemis, "Fecha emisión nulo");
		Assert.notNull(fechavtopag, "Fecha vencimiento nulo");

		return (int) UtilsDate.getDifferenceDays(fechaemis, fechavtopag);
	}

	public BigDecimal sumaEmision(String ccdCodcartacr) {
		return carCartascrdetDao.totalMontoCarta(ccdCodcartacr);
	}

	public BigDecimal sumaPagos(String ccdCodcartacr) {
		return carCartascrdetDao.sumaPagos(ccdCodcartacr);
	}

	public BigDecimal saldoCarta(String ccdCodcartacr) {
		return sumaEmision(ccdCodcartacr).subtract(sumaPagos(ccdCodcartacr));
	}

	public BigDecimal saldoCartaParaSocCodigo(String socCodigo) {
		List<CarCartascrdet> carCartascrdetLista = carCartascrdetDao.findListaBySocCodigo(socCodigo);
		if (carCartascrdetLista.size() > 0)
			return saldoCarta(carCartascrdetLista.get(0).getId().getCcdCodcartacr());
		return BigDecimal.ZERO;
	}

	public BigDecimal saldoCartaConcilia(String ccdCodcartacr) {
		SaldoConciliaDao saldoDao = new SaldoConciliaDao();
		saldoDao.setSessionFactory(sessionFactoryCoin);

		String codigoConcilia = obtenerCodigoConcilia(ccdCodcartacr);
		String[] nroLibreta = codigoConcilia.split("-");
		int nroconcilia = Integer.parseInt(nroLibreta[0]);
		int gestion = Integer.parseInt(nroLibreta[1]);
		SaldoConcilia saldoConcilia = saldoDao.getSaldoById(nroconcilia, gestion);

		if (saldoConcilia == null) {
			log.error("No se logro encontrar SaldoConciliable para nroConcilia " + nroconcilia + " - " + gestion);
			return BigDecimal.ZERO;
		}
		return saldoConcilia.getSaldo();
	}

	private void verificarSaldo(String ccdCodcartacr, BigDecimal montoPago) {
		BigDecimal montoSaldo = saldoCarta(ccdCodcartacr);

		BigDecimal diff = montoSaldo.subtract(montoPago).setScale(2, BigDecimal.ROUND_HALF_UP);
		if (diff.compareTo(BigDecimal.valueOf(0.00)) < 0) {
			throw new BusinessException("Saldo insuficiente " + montoSaldo + " para " + montoPago);
		}
	}

	public void verificarSaldoCoin(String ccdCodcartacr, BigDecimal montoPago) {
		BigDecimal montoSaldo = saldoCartaConcilia(ccdCodcartacr);
		if (montoPago.compareTo(montoSaldo) > 0) {
			throw new BusinessException("Saldo Conciliable insuficiente " + montoSaldo);
		}
	}

	public void verificarSaldoConCoin(String ccdCodcartacr) {
		BigDecimal montoSaldoSioc = saldoCarta(ccdCodcartacr);
		BigDecimal montoSaldoCoin = saldoCartaConcilia(ccdCodcartacr);
		BigDecimal diff = montoSaldoSioc.subtract(montoSaldoCoin).setScale(2, BigDecimal.ROUND_HALF_UP);
		if (diff.abs().compareTo(BigDecimal.valueOf(0.00)) > 0) {
			throw new BusinessException("Saldo Sioc [" + montoSaldoSioc + "] difiere con el saldo en Coin " + montoSaldoCoin);
		}
	}

	public String recuperarDatosConciliaParaSolicitud(String socCodigo) {
		SocRengscompDao socRengscompDao = new SocRengscompDao();
		socRengscompDao.setSessionFactory(sessionFactorySioc);

		List<SocRengscomp> socRengscompLista = socRengscompDao.rengloesByCodOpeDHCtaMov(null, socCodigo, null, null, Constants.CLAVE_ESTCOMP_CONTAB, Constants.CLAVE_TIPOESQ_PROV,
				0, null, null, null);

		for (SocRengscomp socRengscomp : socRengscompLista) {
			Map<String, String> decodeMap = UtilsGeneric.paramsLista(socRengscomp.getNomDatoadic());
			if (decodeMap.containsKey("RCONCSECRENG")) {
				// existe datos de renglon concilia
				String vRCONCNROCON = decodeMap.containsKey("RCONCNROCON") ? decodeMap.get("RCONCNROCON") : "";
				String vRCONCGESTION = decodeMap.containsKey("RCONCGESTION") ? decodeMap.get("RCONCGESTION") : "";
				String vRCONCSECRENG = decodeMap.containsKey("RCONCSECRENG") ? decodeMap.get("RCONCSECRENG") : "";

				return (vRCONCNROCON) + "-" + vRCONCGESTION + "-" + vRCONCSECRENG;
			}
		}
		return "";
	}

	private static CarCartascr crearCartaParaSolicitud(String socCodigo, Integer ccrCodmoneda, Integer ccrCodmontrans, String ccrSolcodigo) {
		// registra una nueva carta a partir de la solicitud
		CarCartascr carCartascr = new CarCartascr();
		carCartascr.setCcrSoccodigo(socCodigo);
		carCartascr.setCcrTipoimpexp(Constants.CLAVE_CCRED_TIPOIMPEXP_I);
		carCartascr.setCcrEstadoccred(Constants.CLAVE_CCRED_ESTCARTACRED_VIGENTE);
		carCartascr.setCcrMonto(BigDecimal.ZERO);
		carCartascr.setCcrSaldo(BigDecimal.ZERO);
		carCartascr.setCcrCodmoneda(ccrCodmoneda);
		carCartascr.setCcrCodmontrans(ccrCodmontrans);
		carCartascr.setCcrSolcodigo(ccrSolcodigo);
		carCartascr.setCcrFechaemis(new Date());
		carCartascr.setCcrFechavtopag(new Date());
		carCartascr.setCcrNrodias(0);

		return carCartascr;
	}

	public static CarCartascrdet nuevoCartascrdet(String codcartacr, String tipoMov, String tipoEmision, Integer ccdCodmonmonto, Integer ccdCodmontrans, Integer esqcodigo,
			String ccdRengconcilia) {
		CarCartascrdet carCartascrdet = new CarCartascrdet();
		carCartascrdet.setId(new CarCartascrdetPK());
		carCartascrdet.getId().setCcdCodcartacr(codcartacr);
		carCartascrdet.setCcdEstmovccred(Constants.CLAVE_CCRED_ESTMOVDETALLE_PENDIENTE);
		carCartascrdet.setCcdFechareg(new Date());
		carCartascrdet.setCcdFechacargo(new Date());
		carCartascrdet.setCcdMonto(BigDecimal.ZERO);
		carCartascrdet.setCcdMontotrans(BigDecimal.ZERO);
		carCartascrdet.setCcdTipomov(tipoMov);
		carCartascrdet.setCcdTipoemision(tipoEmision);
		carCartascrdet.setCcdEstregistro(Constants.CLAVE_CCRED_ESTREGISTRO_VIGENTE);
		carCartascrdet.setCcdSoccodigo("");
		carCartascrdet.setCcdDetcodigo(0);
		carCartascrdet.setCcdGlosa("");
		carCartascrdet.setCcdNrodias(0);
		carCartascrdet.setCcdEsqcodigo(esqcodigo);
		carCartascrdet.setCcdRengconcilia(ccdRengconcilia);
		carCartascrdet.setCcdCodmonmonto(ccdCodmonmonto);
		carCartascrdet.setCcdCodmontrans(ccdCodmontrans);

		return carCartascrdet;
	}

	private CarCartascrdet crearORecuperarCarCartascrdet(String codcartacr, Integer nroccreddetIn, String tipoMov, String tipoEmision, Integer ccdCodmonmonto,
			Integer ccdCodmontrans, Integer esqCodigo) {

		if (!StringUtils.isBlank(codcartacr) && nroccreddetIn != null) {
			return carCartascrdetDao.findByCodcartacrNroccreddet(codcartacr, nroccreddetIn);
		}

		return nuevoCartascrdet(codcartacr, tipoMov, tipoEmision, ccdCodmonmonto, ccdCodmontrans, esqCodigo, obtenerCodigoConcilia(codcartacr));
	}

	private static void verificaSiEstaAutorizado(CarCartascrdet carCartascrdet) {
		if ((carCartascrdet.getCcdEstmovccred().equals(Constants.CLAVE_CCRED_ESTMOVDETALLE_AUTORIZADO))) {
			throw new BusinessException("Registro en estado autorizado, no puede modificar");
		}
	}

	private static void verificaSiEsPendiente(CarCartascrdet carCartascrdet) {
		if (!carCartascrdet.getCcdEstmovccred().equals(Constants.CLAVE_CCRED_ESTMOVDETALLE_PENDIENTE)) {
			throw new BusinessException("Registro en estado inválido, no puede modificar");
		}
	}

	public boolean existeBeneficiario(SocSolicitudes socSolicitudes, SocDetallessol socDetallessol) {
		List<SocBenefs> socBenefsLista = socBenefsDao.beneficiariosExterior(socSolicitudes.getSolCodigo(), socSolicitudes.getCodMonedat(), socDetallessol.getBenCodigo(), null,
				false);
		if (socBenefsLista.size() > 0) {
			return true;
		}
		return false;
	}

	public CarCartascrdet obtenerRegistroAperturaAutorizado(String codcartacr) {
		return carCartascrdetDao.findByCodcartacrCcdTipomov(codcartacr, Constants.CLAVE_CCRED_TIPOMOVDETALLE_APERTURA, Constants.CLAVE_CCRED_TIPOEMISION_EMISION,
				Constants.CLAVE_CCRED_ESTMOVDETALLE_AUTORIZADO);
	}

	public CarCartascrdet obtenerRegistroDetallePreautorizado(String socCodigo) {
		Solicitud solicitud = cartasCredSolicitudService.recuperarSolicitud(socCodigo);
		SocDetallessol socDetallessol = solicitud.getSocDetallessolLista().get(0);
		return carCartascrdetDao.findBySocCodigoDetcodigoEstDet(socDetallessol.getId().getSocCodigo(), socDetallessol.getId().getDetCodigo(),
				Constants.CLAVE_CCRED_ESTMOVDETALLE_PREAUTORIZADO);
	}

	public boolean solicitudAfectaCartasDeCredito(SocSolicitudes socSolicitudes, Integer esqCodigo) {
		try {
			if ((socSolicitudes.getCveSubtipooper() != null && socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS))
					|| (socSolicitudes.getCveSubtipooper() != null && socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT))) {
				boolean existCtasCarta = socEsquemasDao.existsClaveCuenta(esqCodigo, Constants.CLAVE_CTA_GARANT_ACREDIT)
						|| socEsquemasDao.existsClaveCuenta(esqCodigo, Constants.CLAVE_CTA_COMEMISCARTCRED);
				if (existCtasCarta) {
					List<SocDetallessol> lista = socDetallessolDao.getDetalles(socSolicitudes.getSocCodigo());
					carCartascrdetDao.findBySocCodigoDetcodigo(socSolicitudes.getSocCodigo(), lista.get(0).getId().getDetCodigo());
					return true;
				}
			}
			return false;
		} catch (Exception e) {
			return false;
		}
	}

	public String obtenerCodigoConcilia(String codcartacr) {
		if (StringUtils.isBlank(codcartacr)) {
			return "";
		}
		try {
			CarCartascrdet carCartascrdetEMIS = obtenerRegistroAperturaAutorizado(codcartacr);
			return carCartascrdetEMIS.getCcdRengconcilia();
		} catch (Exception e) {
			return "";
		}
	}

	public String obtenerCodigoConciliaSinoException(String codcartacr) {
		try {
			CarCartascrdet carCartascrdetEMIS = obtenerRegistroAperturaAutorizado(codcartacr);
			return carCartascrdetEMIS.getCcdRengconcilia();
		} catch (Exception e) {
			throw new BusinessException("No se pudo obtener Numero de conciliación para carta " + codcartacr, e);
		}
	}

	public String obtenerCodigoConciliaParaSolicitud(String socCodigo) {
		String cveTipoope = "";
		List<CarCartascrdet> carCartascrdetLista = carCartascrdetDao.findListaBySocCodigo(socCodigo);

		for (CarCartascrdet carCartascrdet : carCartascrdetLista) {
			if (esRegistroDeEmision(carCartascrdet)) {
				// constitucion
				return "C";
			} else if (esEnmiendaDeIncremento(carCartascrdet)) {
				// adcion
				cveTipoope = "A";
			} else if (esEnmiendaDeDecremento(carCartascrdet) || esRegistroDePago(carCartascrdet)) {
				// retiro
				cveTipoope = "R";
			}
		}
		if (StringUtils.isBlank(cveTipoope)) {
			throw new BusinessException(
					"Tipo de conciliacion para carta " + carCartascrdetLista.get(0).getId().getCcdCodcartacr() + " no coincide con tipo de operación, avise a sistemas.");
		}
		// la solicitud con el código
		String codConcilia = obtenerCodigoConciliaSinoException(carCartascrdetLista.get(0).getId().getCcdCodcartacr());

		return cveTipoope + "-" + codConcilia;
	}

	public static boolean esRegistroDeEmision(CarCartascrdet carCartascrdet) {
		return carCartascrdet.getCcdTipoemision().equals(Constants.CLAVE_CCRED_TIPOEMISION_EMISION);
	}

	public static boolean esRegistroDePago(CarCartascrdet carCartascrdet) {
		return carCartascrdet.getCcdTipoemision().equals(Constants.CLAVE_CCRED_TIPOEMISION_PAGO);
	}

	public static boolean esEnmiendaDeIncremento(CarCartascrdet carCartascrdet) {
		return carCartascrdet.getCcdTipoemision().equals(Constants.CLAVE_CCRED_TIPOEMISION_INCREMENTO);
	}

	public static boolean esEnmiendaDeDecremento(CarCartascrdet carCartascrdet) {
		return carCartascrdet.getCcdTipoemision().equals(Constants.CLAVE_CCRED_TIPOEMISION_DECREMENTO);
	}

	public static boolean esEnmiendaDeAmpliacion(CarCartascrdet carCartascrdet) {
		return carCartascrdet.getCcdTipoemision().equals(Constants.CLAVE_CCRED_TIPOEMISION_AMPLIACION);
	}

	public static boolean esEnmiendaDeReduccion(CarCartascrdet carCartascrdet) {
		return carCartascrdet.getCcdTipoemision().equals(Constants.CLAVE_CCRED_TIPOEMISION_REDUCCION);
	}

	public static boolean esEnmiendaDeModificacionDatos(CarCartascrdet carCartascrdet) {
		return carCartascrdet.getCcdTipoemision().equals(Constants.CLAVE_CCRED_TIPOEMISION_MODIFICACION);
	}

	public static boolean esCartaConComisionDeEmision(CarCartascrdet carCartascrdet) {
		return esRegistroDeEmision(carCartascrdet) || esEnmiendaDeIncremento(carCartascrdet);
	}

	public static boolean esOperacionConTransferencia(CarCartascrdet carCartascrdet) {
		return esRegistroDeEmision(carCartascrdet) || esEnmiendaDeIncremento(carCartascrdet) || esEnmiendaDeDecremento(carCartascrdet) || esRegistroDePago(carCartascrdet);
	}
	
	public static boolean esOperacionConEnmiendaEnFecha(CarCartascrdet carCartascrdet) {
		return esEnmiendaDeIncremento(carCartascrdet) || esEnmiendaDeAmpliacion(carCartascrdet) || esEnmiendaDeReduccion(carCartascrdet) || esEnmiendaDeModificacionDatos(carCartascrdet) ;
	}

	public SocSolicitudctas obtenerCtaAcreditivosOpt(String codcartacr) {
		SocSolicitudctasPK socSolicitudctasPK = new SocSolicitudctasPK();
		socSolicitudctasPK.setTipoCuenta(Constants.CLAVE_CTA_GARANT_ACREDIT);
		SocSolicitudctas socSolicitudctas = new SocSolicitudctas();
		socSolicitudctas.setId(socSolicitudctasPK);

		try {
			if (StringUtils.isBlank(codcartacr))
				return socSolicitudctas;
			CarCartascrdet carCartascrdet = carCartascrdetDao.findByCodcartacrCcdTipomov(codcartacr, Constants.CLAVE_CCRED_TIPOMOVDETALLE_APERTURA,
					Constants.CLAVE_CCRED_TIPOEMISION_EMISION);
			if (StringUtils.isBlank(carCartascrdet.getCcdSoccodigo()))
				return socSolicitudctas;
			return socSolicitudctasDao.getCuenta(carCartascrdet.getCcdSoccodigo(), Constants.CLAVE_CTA_GARANT_ACREDIT, null, null, null, null);
		} catch (Exception e) {
			return socSolicitudctas;
		}
	}

	public List<Detallesol> registrosAfectablesCarta(String ccdCodcartacr) {
		return carCartascrdetDao.obtenerEmisionesCarta(ccdCodcartacr);
	}

	public List<Detallesol> pagosAfectablesCarta(String ccdCodcartacr) {
		return carCartascrdetDao.obtenerPagosCarta(ccdCodcartacr);
	}

	public List<Detallesol> buscarCartas(CarCartascr carCartascr, CarCartascrdet carCartascrdet) {
		List<Detallesol> detallesolLista = carCartascrDao.buscarCartas(carCartascr, carCartascrdet);
		for (Detallesol detallesol : detallesolLista) {
			SocSolicitudes socSolicitudes = cartasCredSolicitudService.getSolicitud(detallesol.getCarCartascrdet().getCcdSoccodigo());
			detallesol.setSocSolicitudes(socSolicitudes);
		}
		return detallesolLista;
	}

	public List<Detallesol> buscarCartasNotifica() {
		List<Detallesol> detallesolLista = carCartascrDao.buscarCartasForNotif();
		for (Detallesol detallesol : detallesolLista) {
			SocSolicitudes socSolicitudes = cartasCredSolicitudService.getSolicitud(detallesol.getCarCartascrdet().getCcdSoccodigo());
			detallesol.setSocSolicitudes(socSolicitudes);
		}
		return detallesolLista;
	}

	public List<Detallesol> cartasVigentesPendientes(CarCartascr carCartascr, CarCartascrdet carCartascrdet) {
		return carCartascrDao.cartasVigentesPendientes();
	}

	public static void validarCartacrFechas(CarCartascr carCartascr) {
		Assert.notNull(carCartascr.getCcrFechaemis(), "Fecha emisión inválida");
		Assert.notNull(carCartascr.getCcrFechavtopag(), "Fecha vencimiento inválida");
		Assert.isTrue((UtilsDate.compara(carCartascr.getCcrFechaemis(), carCartascr.getCcrFechavtopag()) < 0), "Fecha de emision debe ser menor a la fecha de vencimiento");
	}

	public static void validarCartacrdetFechas(CarCartascrdet carCartascrdet) {
		Assert.notNull(carCartascrdet.getCcdFechareg(), "Fecha inicio inválida");
		Assert.notNull(carCartascrdet.getCcdFechacargo(), "Fecha fin inválida");
		Assert.isTrue((UtilsDate.compara(carCartascrdet.getCcdFechareg(), carCartascrdet.getCcdFechacargo()) < 0), "Fecha de inicio debe ser menor a la fecha de fin");
	}

	public static void validarCartacrDatos(CarCartascr carCartascr) {
		Assert.isTrue(!StringUtils.isBlank(carCartascr.getCcrNomexportador()), "Nombre de exportador debe tener un valor");
		Assert.isTrue(!StringUtils.isBlank(carCartascr.getCcrNomimportador()), "Nombre de importador debe tener un valor");
		Assert.isTrue(!StringUtils.isBlank(carCartascr.getCcrNomproducto()), "Descripción de producto debe tener un valor");
		Assert.isTrue(!StringUtils.isBlank(carCartascr.getCcrBencodigo()), "No existe un beneficiario seleccionado");
		Assert.isTrue(!StringUtils.isBlank(carCartascr.getCcrSolcodigo()), "No existe un solicitante seleccionado");
		Assert.notNull(carCartascr.getCcrCodmontrans(), "Moneda de la carta debe tener valor.");
	}

	public static void validarCartacrDetalleDatos(CarCartascrdet carCartascrdet) {
		Assert.notNull(carCartascrdet.getCcdCodmontrans(), "Moneda de la carta para la operación debe tener valor.");
		Assert.isTrue(!StringUtils.isBlank(carCartascrdet.getCcdGlosa()), "La glosa debe tener un valor");

	}

	public static Integer retornarCodEsquemaDeCartascrdet(CarCartascrdet carCartascrdet) {
		if (esEnmiendaDeIncremento(carCartascrdet)) {
			return ESQ_CODIGO_ENMIENDA_INCREMENTO;
		} else if (esEnmiendaDeDecremento(carCartascrdet)) {
			return ESQ_CODIGO_ENMIENDA_DECREMENTO;
		} else if (esEnmiendaDeDecremento(carCartascrdet)) {
			return ESQ_CODIGO_ENMIENDA_DECREMENTO;
		}

		return carCartascrdet.getCcdEsqcodigo();
	}

	public SocComitipoope porcComisionEmision(CarCartascrdet carCartascrdet) {
		return cartasCredSolicitudService.socComitipoopeParaEsquema(carCartascrdet.getCcdEsqcodigo(), Constants.COD_VAR_MONTOCOMEMISCARTCRED);
	}

	public SocComitipoope porcComisionEnmienda(CarCartascrdet carCartascrdet) {
		return cartasCredSolicitudService.socComitipoopeParaEsquema(carCartascrdet.getCcdEsqcodigo(), Constants.COD_VAR_MONTOCOMENMIENDA);
	}
	
	public Integer nroDiasMontoTransferencia(String socCodigo) {
		SocOpecomi socOpecomi = socOpecomiDao.getOpeComisByDetCodClaCom(socCodigo, 0, Constants.COD_VAR_MONTOCOMEMISCARTCREDMT);
		if (socOpecomi == null || socOpecomi.getOcoMontoimpt() == null) {
			return 0;
		}
		
		return Integer.valueOf(socOpecomi.getOcoMontoimpt().toString());
	}
	
	public Integer nroDiasSaldo(String socCodigo) {
		SocOpecomi socOpecomi = socOpecomiDao.getOpeComisByDetCodClaCom(socCodigo, 0, Constants.COD_VAR_MONTOCOMEMISCARTCREDSLD);
		if (socOpecomi == null || socOpecomi.getOcoMontoimpt() == null) {
			return 0;
		}
		
		return Integer.valueOf(socOpecomi.getOcoMontoimpt().toString());
	}
	
	public Solicitud recuperarEmisionCarta(String codcartacr) {
		CarCartascr carCartascr = carCartascrDao.findByCodcartacr(codcartacr);		
		Solicitud solicitud = cartasCredSolicitudService.recuperarSolicitud(carCartascr.getCcrSoccodigo());

		CarCartascrdet carCartascrdetEMIS = carCartascrdetDao.findByCodcartacrCcdTipomov(carCartascr.getCcrCodcartacr(), Constants.CLAVE_CCRED_TIPOMOVDETALLE_APERTURA,
				Constants.CLAVE_CCRED_TIPOEMISION_EMISION);
		
		solicitud.setCarCartascr(carCartascr);
		solicitud.setCarCartascrdet(carCartascrdetEMIS);

		return solicitud;
	}
	public static final Integer numcharsline = 34;
	public static void validarCartacrDetInfo(CarCartascrdet carCartascrdet, String valor) {
		if (esRegistroDePago(carCartascrdet)) {
			int numlinea = MensSwiftUtiles.isValidoConcepto(valor, numcharsline);
			if (numlinea > 0) {
				throw new BusinessException("Numero de caracteres invalido en linea "  + numlinea);			
			}
		}
	}	
}