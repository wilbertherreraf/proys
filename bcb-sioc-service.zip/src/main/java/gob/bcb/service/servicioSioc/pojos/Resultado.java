package gob.bcb.service.servicioSioc.pojos;

/**
 * Clase generica para almacenamiento de informacin segun el formato.
 */
public class Resultado {

	// Verifica si el resultado es valido.
	private boolean esValido;
	// Propiedad para el mensaje.
	private String mensaje;
	// Propiedad para el tipo de mensaje.
	private String tipoMensaje;
	// Propiedad para almacenar datos adicionales.
	private Object datosAdicionales;
	
	/**
	 * Instancia constructor de la clase.
	 */
	public Resultado() {
			
	}
	
	/**
	 * Instancia constructor de la clase con parametros de entrada.
	 */
	public Resultado(boolean esValido, String mensaje, String tipoMensaje, Object datosAdicionales) {

		this.esValido = esValido;
		this.mensaje = mensaje;
		this.tipoMensaje = tipoMensaje;
		this.datosAdicionales = datosAdicionales;
	}
	
	// Obtiene valor de propiedad es valido.
	public boolean getEsValido() {
		return esValido;
	}

	// Almacena valor de propiedad es valido.
	public void setEsValido(boolean esValido) {
		this.esValido = esValido;
	}
	
	// Obtiene valor de propiedad mensaje.
	public String getMensaje() {
		return mensaje;
	}

	// Almacena valor de propiedad mensaje.
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
	
	// Obtiene valor de propiedad tipo de mensaje.
	public String getTipoMensaje() {
		return tipoMensaje;
	}
	
	// Almacena valor de propiedad tipo mensaje.
	public void setTipoMensaje(String tipoMensaje) {
		this.tipoMensaje = tipoMensaje;
	}
	
	// Obtiene valor de propiedad datos adicionales.
	public Object getDatosAdicionales() {
		return datosAdicionales;
	}
	
	// Almacena valor de propiedad datos adicionales.
	public void setDatosAdicionales(Object datosAdicionales) {
		this.datosAdicionales = datosAdicionales;
	}
}
