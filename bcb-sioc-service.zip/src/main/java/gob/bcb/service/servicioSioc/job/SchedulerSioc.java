package gob.bcb.service.servicioSioc.job;

import gob.bcb.bpm.pruebaCU.Servicios;
import gob.bcb.service.servicioSioc.common.Constants;

import java.util.Date;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.log4j.Logger;
import org.quartz.CronScheduleBuilder;
import org.quartz.DateBuilder;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerFactory;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;
import org.slf4j.LoggerFactory;

public final class SchedulerSioc {
	private static Logger log = Logger.getLogger(SchedulerSioc.class);
	public static final Timer CLOCK_DAEMON = new Timer("Sioc Scheduler", true);
	private static final HashMap<Runnable, TimerTask> TIMER_TASKS = new HashMap<Runnable, TimerTask>();
	private Scheduler scheduler; 
		
	public SchedulerSioc() {
	}

	public void run() throws Exception {
		log.info("Inicializando Programador de tareas");
		final String prefJob = "job_";
		final String prefTrigger = "trigger_";
		
		// First we must get a reference to a scheduler
		SchedulerFactory sf = new StdSchedulerFactory();
		scheduler = sf.getScheduler();
		
		// computer a time that is on the next round minute
		Date runTimeAdjudAuto = DateBuilder.nextGivenSecondDate(new Date(), 10);
		Date runTimeRetiroAuto = DateBuilder.nextGivenSecondDate(new Date(), 30);
		Date runRevisaVDAuto = DateBuilder.nextGivenSecondDate(new Date(), 20);
		
		String horaAdjudAuto = Servicios.getParam("horaAdjudAuto");
		String horaRetiroAuto = Servicios.getParam("horaRetiroAuto");
		String horaRevisaVDAuto = Servicios.getParam("horaRevisaVDAuto");
		
		String[] horaAAuto = horaAdjudAuto.split(":");
		String cronExpr = "0 " + horaAAuto[1] + " " + horaAAuto[0] + " ? * 2-6";
		
		horaAAuto = horaRetiroAuto.split(":");
		String cronExprRetiro = "0 " + horaAAuto[1] + " " + horaAAuto[0] + " ? * 2-6";
		
		horaAAuto = horaRevisaVDAuto.split(":");
		String cronRevisaVD = "0 " + horaAAuto[1] + " " + horaAAuto[0] + " ? * 2-6";
		
		log.info("Scheduling Job: " + Constants.TIPO_OPERACION_ADJUD_AUTO + " desde " + runTimeAdjudAuto + " a hrs "  + cronExpr);		
		// define the job
		JobDetail jobAdjudAuto = JobBuilder.newJob(GenerateTasks.class).withIdentity(prefJob + Constants.TIPO_OPERACION_ADJUD_AUTO, "group1").build();
		JobDetail jobRetiroAuto = JobBuilder.newJob(GenerateTasks.class).withIdentity(prefJob + Constants.TIPO_OPERACION_RETIRO_AUTO, "group1").build();		
		JobDetail jobRevisaVDAuto = JobBuilder.newJob(GenerateTasks.class).withIdentity(prefJob + Constants.TIPO_OPERACION_REVISAVD_AUTO, "group1").build();		

		Trigger triggerAdjudAuto = TriggerBuilder.newTrigger().withIdentity(prefTrigger + Constants.TIPO_OPERACION_ADJUD_AUTO, "group1")
				.startAt(runTimeAdjudAuto).withSchedule(CronScheduleBuilder.cronSchedule(cronExpr)).build();
		Trigger triggerRetiroAuto = TriggerBuilder.newTrigger().withIdentity(prefTrigger + Constants.TIPO_OPERACION_RETIRO_AUTO, "group1")
				.startAt(runTimeRetiroAuto).withSchedule(CronScheduleBuilder.cronSchedule(cronExprRetiro)).build();		
		Trigger triggerRevisaVDAuto = TriggerBuilder.newTrigger().withIdentity(prefTrigger + Constants.TIPO_OPERACION_REVISAVD_AUTO, "group1")
		.startAt(runRevisaVDAuto).withSchedule(CronScheduleBuilder.cronSchedule(cronRevisaVD)).build();		
		
		jobAdjudAuto.getJobDataMap().put(GenerateTasks.TIPO_OPERACION, Constants.TIPO_OPERACION_ADJUD_AUTO);
		jobRetiroAuto.getJobDataMap().put(GenerateTasks.TIPO_OPERACION, Constants.TIPO_OPERACION_RETIRO_AUTO);
		jobRevisaVDAuto.getJobDataMap().put(GenerateTasks.TIPO_OPERACION, Constants.TIPO_OPERACION_REVISAVD_AUTO);		
		
		scheduler.start();
		log.info("Programacion de tareas inicializado...");		
		scheduler.scheduleJob(jobAdjudAuto, triggerAdjudAuto);		
		scheduler.scheduleJob(jobRetiroAuto, triggerRetiroAuto);
		scheduler.scheduleJob(jobRevisaVDAuto, triggerRevisaVDAuto);		
		
		log.info(jobAdjudAuto.getKey() + " will run at: " + runTimeAdjudAuto + " " + triggerAdjudAuto.getNextFireTime());		
		log.info(jobRetiroAuto.getKey() + " will run at: " + runTimeRetiroAuto + " " + triggerRetiroAuto.getNextFireTime());		
		log.info(jobRevisaVDAuto.getKey() + " will run at: " + runRevisaVDAuto + " " + triggerRevisaVDAuto.getNextFireTime());		
		log.info("Programacion de tareas finalizado...");		
	}

	public Scheduler getScheduler() {
		return scheduler;
	}

	public void setScheduler(Scheduler scheduler) {
		this.scheduler = scheduler;
	}
}
