package gob.bcb.service.servicioSioc;

import gob.bcb.bpm.pruebaCU.QueryProcessor;
import gob.bcb.bpm.pruebaCU.SocParametros;
import gob.bcb.bpm.pruebaCU.SocParametrosDao;
import gob.bcb.core.jms.BcbRequest;
import gob.bcb.core.jms.BcbRequestImpl;
import gob.bcb.core.jms.BcbResponseImpl;
import gob.bcb.core.jms.ResponseContext;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.service.commons.ConfigurationServ;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.job.GenerateTasks;
import gob.bcb.service.servicioSioc.job.SchedulerSioc;
import gob.bcb.service.servicioSioc.mail.MsgLogic;
import gob.bcb.swift.commons.ConstantsSwift;

import java.io.File;
import java.util.Date;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.springframework.jms.listener.SessionAwareMessageListener;

public class ServicioSiocListener implements SessionAwareMessageListener {
	private static final Log log = LogFactory.getLog(ServicioSiocListener.class);
	private static boolean initialized = false;
	private static SchedulerSioc schedulerSioc ; 
	public ServicioSiocListener() {
		log.info("ServicioSiocListener creado");
	}

	/**
	 * inicializa las variables genericas de la aplicaci�n
	 */
	public final void init() {
		if (!initialized) {
			log.info("Inicializando Servicio listener...");
			if (!ConfigurationServ.isConfigured()) {
				throw new RuntimeException("Objeto ConfigurationServ no fue inicializado ");
			}
			SocParametrosDao socParametrosDao = new SocParametrosDao();
			socParametrosDao.setSessionFactory(QueryProcessor.getSessionFactory());

			SocParametros socParametros = socParametrosDao.getByCodigo("ip-correo");
			
			String ipCorreo = socParametros.getParValor();
			log.info("Parametro ipCorreo: " + ipCorreo);
			if (ipCorreo != null) {
				String[] configMails = ipCorreo.split(" ");
				MsgLogic.IP_SMTP = configMails[0];
				try {
					MsgLogic.PORT_SMTP = Integer.valueOf(configMails[1]);
				} catch (Exception e) {
					MsgLogic.PORT_SMTP = 25;
				}
			}
			socParametros = socParametrosDao.getByCodigo(ConstantsSwift.PARAM_PATHSWIFT);
			String pathSwift = socParametros.getParValor();
			
			File f = new File(pathSwift);
			if (!f.exists() || !f.isDirectory()){
				throw new RuntimeException("Directorio Swift inexistente " + pathSwift);				
			}
			
			String directory = pathSwift + "Autorizados";
			log.info("Directorio swift configurado: " + pathSwift);
			
			File d = new File(directory);
			if (!d.exists()|| !d.isDirectory()){
				d.mkdirs();
				log.info("Directorio Swift Autorizados [" +directory+ "] creado ... hecho");				
			}
			
			directory = pathSwift + "Backup";
			d = new File(directory);
			if (!d.exists() || !f.isDirectory()){
				d.mkdirs();				
				log.info("Directorio Swift Backup [" +directory+ "] creado ... hecho");				
			}			

//
//			SAMLConfiguration.setPathFileCommon(ConfigurationServ.getConfigurationHome() + "/configdb.xml", false);
//			SAMLConfiguration.setNameApplication(ConfigurationServ.getServiceName());

			socParametros = socParametrosDao.getByCodigo("correoremitente");
			String correoremitente = socParametros.getParValor();
			
			ConfigurationServ.setParamsSystem("correoremitente", correoremitente);
			startScheduler();
			//ConfigurationServ.initConnectionFactory(null);
			initialized = true;
			log.info("Iniciando Configuracion servicio listener ... hecho");
		}
	}
	
	public static void startScheduler(){
		schedulerSioc = new SchedulerSioc();
		try {
			schedulerSioc.run();
			log.info("schedulerSioc iniciado... ");			
		} catch (Exception e) {
			log.error("Error en schedulerSioc " + e.getMessage(), e);
			throw new RuntimeException(e);
		}
	}
	
	public static void stopScheduler(){
		log.info("stopScheduler ...");		
		final String prefJob = "job_";		
		JobDetail jobAdjudAuto = JobBuilder.newJob(GenerateTasks.class).withIdentity(prefJob + Constants.TIPO_OPERACION_ADJUD_AUTO, "group1").build();
		JobDetail jobRetiroAuto = JobBuilder.newJob(GenerateTasks.class).withIdentity(prefJob + Constants.TIPO_OPERACION_RETIRO_AUTO, "group1").build();		
		JobDetail jobRevisaVDAuto = JobBuilder.newJob(GenerateTasks.class).withIdentity(prefJob + Constants.TIPO_OPERACION_REVISAVD_AUTO, "group1").build();		
		try {
			schedulerSioc.getScheduler().interrupt(jobAdjudAuto.getKey());
			schedulerSioc.getScheduler().interrupt(jobRetiroAuto.getKey());			
			schedulerSioc.getScheduler().interrupt(jobRevisaVDAuto.getKey());			
		} catch (Exception e) {
			log.error("Ocurrio un error al interrumpir JOb " + e.getMessage(), e);
		}
		try {
			schedulerSioc.getScheduler().shutdown();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.error("Ocurrio un error al shutdown JObs " + e.getMessage(), e);
		}
		log.info("Jobs interrumpidos ...");
		
	}
	public static String execServicioToString(BcbRequest bcbRequest) {
		String result = null;
		log.info("=======ooooOO00inicio servicio00OOooo======= " + UtilsDate.stringFromDate(new Date(), Constants.FORMAT_DATE_TIME));
		DispatcherSioc dispatcherSirAladi = null;
		try {
			ResponseContext responseContext = new ResponseContext(bcbRequest);
			try {
				if (!initialized) {
					throw new RuntimeException("Objeto ServicioSiocListener no fue inicializado");
				}
				dispatcherSirAladi = new DispatcherSioc();
				dispatcherSirAladi.doService(bcbRequest, responseContext);
				result = "OK";
			} catch (Throwable t) {
				// String consent = t instanceof Exception ?
				// t.getCause().getMessage() : t.getMessage();
				String consent = t.getMessage();
				log.error("ERROR INESPERADO: " + UtilsDate.stringFromDate(new Date(), Constants.FORMAT_DATE_TIME) + " :: " + consent, t);
				// error FATAL !!!! se genera un mensaje de error
				ResponseContext.errorRequest(bcbRequest.getJmsMessage(), bcbRequest.getJmsSession(), Constants.UNKNOWN_EXCEPTION,
						"ERROR INESPERADO: " + consent + ". Comunique a sistemas", "no definido");
			}
		} finally {
			if (dispatcherSirAladi != null)
				dispatcherSirAladi.rollbackEntityManager();
		}
		log.info("=======ooooOO00Fin servicio00OOooo======= " + UtilsDate.stringFromDate(new Date(), Constants.FORMAT_DATE_TIME));
		return result;
	}

	public void onMessage(Message message, Session session) throws JMSException {
		log.info("==== MENSAJE RECIBIDO =====" + message.getJMSDestination());
		log.info(message);
		
		try {
			if (log.isDebugEnabled()) {
				StringBuffer sb = new StringBuffer();
				sb.append("Received JMS message to destination : " + message.getJMSDestination());
				sb.append("\nMessage ID : " + message.getJMSMessageID());
				sb.append("\nCorrelation ID : " + message.getJMSCorrelationID());
				sb.append("\nReplyTo ID : " + message.getJMSReplyTo());
				log.debug(sb.toString());
				if (log.isTraceEnabled() && message instanceof TextMessage) {
					log.trace("\nMessage : " + ((TextMessage) message).getText());
				}
			}
		} catch (JMSException e) {
			if (log.isDebugEnabled()) {
				log.debug("Error reading JMS message headers for debug logging", e);
			}
		}

		// has this message already expired? expiration time == 0 means never
		// expires
		try {
			long expiryTime = message.getJMSExpiration();
			Date dnow = new Date(System.currentTimeMillis());
			log.info("expiryTime = " + expiryTime + " " + System.currentTimeMillis() + " " + (expiryTime - System.currentTimeMillis()));
			Date d = new Date(expiryTime);
			log.info("Fecha expiryTime = " + UtilsDate.stringFromDate(d, "dd/MM/yyyy H:mm:ss") + " now: " + UtilsDate.stringFromDate(dnow, "dd/MM/yyyy H:mm:ss"));
			if ((expiryTime > 0) && (System.currentTimeMillis() > expiryTime)) {
				log.info("Discard expired message with ID : " + message.getJMSMessageID());
				//return;
			}
		} catch (JMSException ignore) {
		}
		BcbRequestImpl bcbRequestImpl = new BcbRequestImpl(message, session);

		try {
			// contruimos un mensaje de entrada
			Object resp = bcbRequestImpl.procesarMsgIn();

			if (resp instanceof String && resp.equals("PING")){
				log.info("respondiento a ping");
				BcbResponseImpl bcbResponseImpl = new BcbResponseImpl(message, session);
				bcbResponseImpl.setDestination(message.getJMSReplyTo());
				bcbResponseImpl.sendResponseBcbMsg(Constants.OPERACION_SUCCESS, "Pinngggg");
			} else {
				// ####INICIO:EJECUTAR SERVICIO DE NEGOCIO#####
				execServicioToString(bcbRequestImpl);
				// ####FIN:EJECUTAR SERVICIO DE NEGOCIO####
				
			}
		} catch (Throwable t) {
			log.error("ERROR INESPERADO: " + t.getMessage());
			// String consent = t instanceof Exception ?
			// t.getCause().getMessage() : t.getMessage();
			String consent = t.getMessage();
			log.error("ERROR INESPERADO: " + UtilsDate.stringFromDate(new Date(), Constants.FORMAT_DATE_TIME) + " :: " + consent, t);
			// error FATAL !!!! se genera un mensaje de error
			BcbResponseImpl bcbResponseImpl = new BcbResponseImpl(message, session);
			try {
				bcbResponseImpl.sendResponseBcbMsg(Constants.UNKNOWN_EXCEPTION, "ERROR INESPERADO: " + consent + ". Comunique a sistemas");
			} catch (Exception e) {
				log.error("no se pudo enviar mensaje de respuesta " + e.getMessage(), e);
			}
		}
		if (session != null) {
			try {
				// session.close();
				log.info("session JMS server cerrado...");
			} catch (Exception e) {
				log.error("Error al cerrar session JMS " + e.getMessage(), e);
			}
		}
	}

	public static SchedulerSioc getSchedulerSioc() {
		return schedulerSioc;
	}

	public static void setSchedulerSioc(SchedulerSioc schedulerSioc) {
		ServicioSiocListener.schedulerSioc = schedulerSioc;
	}
}
