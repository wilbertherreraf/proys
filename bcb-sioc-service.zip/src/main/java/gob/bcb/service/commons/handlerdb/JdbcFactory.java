package gob.bcb.service.commons.handlerdb;

import gob.bcb.core.utils.Utils;
import gob.bcb.core.utils.UtilsPersist;

import java.beans.PropertyVetoException;
import java.io.File;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.XMLConfiguration;
import org.apache.log4j.Logger;

import com.mchange.v2.c3p0.ComboPooledDataSource;

public class JdbcFactory implements DBSourceHandlerFactory {
	private static Logger log = Logger.getLogger(JdbcFactory.class);
	private XMLConfiguration config = null;
	static {
		System.setProperty("com.mchange.v2.log.MLog", "com.mchange.v2.log.FallbackMLog");
		System.setProperty("com.mchange.v2.log.FallbackMLog.DEFAULT_CUTOFF_LEVEL", "WARNING");
	}

	// cambiar mensajes oio
	private JdbcDBSourceHandler jdbcDBSourceHandlerInstance;

	public void close() {

	}

	public void configure(String idDBSource) {
		String url = (String) Utils.getValueFromXML(config, UtilsPersist.PROP_DB_JDBC_URL.replaceFirst("ID-DATABASE", idDBSource), "string");
		String username = (String) Utils.getValueFromXML(config, UtilsPersist.PROP_DB_JDBC_USER.replaceFirst("ID-DATABASE", idDBSource), "string");
		String password = (String) Utils
				.getValueFromXML(config, UtilsPersist.PROP_DB_JDBC_PASSWORD.replaceFirst("ID-DATABASE", idDBSource), "string");
		String driver = (String) Utils.getValueFromXML(config, UtilsPersist.PROP_DB_JDBC_DRIVER.replaceFirst("ID-DATABASE", idDBSource), "string");

		configure(url, username, password, driver);
	}

	public void configure(String path, String idDBSource) {
		try {
			log.info("condigure " + path + " :: " + idDBSource);
			config = new XMLConfiguration(new File(path));
		} catch (ConfigurationException e) {
			log.error("Error al iniciaar config db: " + e.getMessage(), e);
			throw new RuntimeException("Error al iniciaar config db: " + e.getMessage(), e);
		}
		configure(idDBSource);

	}

	public void configure() {
	}

	public void configure(String url, String username, String password, String driver) {
		Map<String, String> options = new HashMap<String, String>();
		options.put("url", url);
		options.put("username", username);
		options.put("password", password);
		options.put("driver", driver);

		jdbcDBSourceHandlerInstance = new JdbcDBSourceHandler(buildApplicationManagedConnection(options));
	}

	public DBSourceHandler getHandler() {
		if (jdbcDBSourceHandlerInstance == null)
			throw new IllegalStateException(
					"Instancia del Datasource a conexion a Base de datos es nulo, Por favor invoque configure antes de llamar a getHandler");
		return jdbcDBSourceHandlerInstance;
	}

	protected DataSource buildApplicationManagedConnection(Map<String, String> options) {
		ComboPooledDataSource datasource = new ComboPooledDataSource();
		ClassLoader classLoader = this.getClass().getClassLoader();
		try {
			classLoader.loadClass(options.get("driver"));
		} catch (ClassNotFoundException e) {
			log.error("Unable to create relational database connector, JDBC driver can not be found on the classpath");
			throw new RuntimeException("Unable to create relational database connector, JDBC driver can not be found on the classpath");
		}

		try {
			log.info("=== INIT POOL DB ===" );			
			datasource.setDriverClass(options.get("driver"));
			datasource.setJdbcUrl(options.get("url"));
			datasource.setUser(options.get("username"));
			datasource.setPassword(options.get("password"));

			datasource.setAcquireIncrement(5);
			datasource.setMinPoolSize(5);
			datasource.setMaxPoolSize(100);
			datasource.setInitialPoolSize(5);
			
			datasource.setAcquireRetryAttempts(0);
			datasource.setAcquireRetryAttempts(10);
			datasource.setAcquireRetryDelay(5000);
			datasource.setAcquireRetryDelay(100);
			datasource.setBreakAfterAcquireFailure(false);
			//datasource.setMaxIdleTime(1);
			datasource.setIdleConnectionTestPeriod(180);
			datasource.setCheckoutTimeout(30000);
			
			log.info("Created application managed data source for data connector");
			return datasource;
		} catch (PropertyVetoException e) {
			log.error("Unable to create data source for data connector with JDBC driver class " + options.get("driver"), e);
			return null;
		}
	}
}
