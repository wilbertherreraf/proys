package gob.bcb.service.commons;

import gob.bcb.core.jms.client.JMSConnectionHandler;

import gob.bcb.core.utils.UtilsProperties;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;

import javax.jms.ConnectionFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.XMLConfiguration;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;

public class ConfigurationServ {
	private static String serviceName;
	private static Logger log = Logger.getLogger(ConfigurationServ.class);
	private static String pathDbConfig;
	public static final String CONFIG_PROPERTIES = "configapp.properties";
	private static Properties configProp;
	private static String home;
	private static Map<String, String> paramsSystem = new ConcurrentHashMap<String, String>();
	private static XMLConfiguration config;
	private static boolean configInitialized = false;
	private static transient ConnectionFactory connectionFactory;

	public static void init(String home) {
		if (!configInitialized) {
			log.info("Inicializando objetos de configuracion ConfigurationServ");
			log.info("Cargando ... " + ConfigurationServ.getConfigurationHome() + "/" + CONFIG_PROPERTIES);

			configProp = UtilsProperties.loadFileMsgProperties(ConfigurationServ.getConfigurationHome() + "/" + CONFIG_PROPERTIES);
			pathDbConfig = configProp.getProperty("db.config");

			if (pathDbConfig == null) {
				throw new RuntimeException("Par�metro [db.config] requerido no esta definido en " + CONFIG_PROPERTIES);
			}

			log.info("Cargando archivo de conexiones a bases " + pathDbConfig);

			try {
				config = new XMLConfiguration(new File(pathDbConfig));
				File configf = new File(pathDbConfig);				
				log.info("Cargando archivo de conexiones a bases " + pathDbConfig + " hecho..." + " " + configf.exists());
			} catch (ConfigurationException e) {
				throw new RuntimeException(e);
			}

			configInitialized = true;

			log.info("Estado connectionFactory nulo?: " + (connectionFactory == null));
			// if (connectionFactory == null) {
			// String queueSioc =
			// ConfigurationServ.getConfigProperty("jms.queue.sioc");
			// initConnectionFactory(queueSioc);
			// }

			log.info("Inicializando objetos de configuracin ConfigurationServ ... hecho");
		}
		
		if (isConfigured()) {
		} else {
			throw new RuntimeException(
					"Error al iniciar la Configuracion del sistema, no fue seteado variables home o name del archivo de configuracion");
		}
	}

	public static boolean isConfigured() {
		if (pathDbConfig == null)
			return false;
		log.info("Config filename: " + pathDbConfig);
		File config = new File(pathDbConfig);
		return config.exists();
	}

	public static String getConfigurationHome() {
		return home;
	}

	public static XMLConfiguration getConfig() {
		return config;
	}

	public boolean isConfigInitialized() {
		return configInitialized;
	}

	public static void setHomeProperty(String home) {
		if (home == null) {
			throw new IllegalStateException("Valor de variable HOME nulo");
		}

		File h = new File(home);
		if (h.exists() && !h.isDirectory()) {
			throw new IllegalStateException(home + " no es un directorio");
		} else if (!h.exists()) {
			log.info("Creando un directorio vacio " + home);
			try {
				FileUtils.forceMkdir(h);
			} catch (IOException e) {
				throw new IllegalStateException(h + " no puede ser creado");
			}
		}
		log.info("Configuration.home seteado a " + home);
		ConfigurationServ.home = home;
	}

	public static Object getConfigProperty(String expXpath, String typeValRet) {
		Object propResult = null;

		Document document = getConfig().getDocument();
		try {
			XPathFactory xFactory = XPathFactory.newInstance();
			XPath xpath = xFactory.newXPath();
			XPathExpression exp = null;

			exp = xpath.compile(expXpath);

			if (typeValRet.equalsIgnoreCase("STRING")) {
				propResult = exp.evaluate(document, XPathConstants.STRING);
			} else if (typeValRet.equalsIgnoreCase("NUMBER")) {
				propResult = exp.evaluate(document, XPathConstants.NUMBER);
			} else if (typeValRet.equalsIgnoreCase("NODE")) {
				propResult = exp.evaluate(document, XPathConstants.NODE);
			} else if (typeValRet.equalsIgnoreCase("DOM")) {
				propResult = exp.evaluate(document);
			}

		} catch (XPathExpressionException e) {
			document = null;
			throw new RuntimeException(e);
		} catch (Exception e) {
			document = null;
			throw new RuntimeException(e);
		}
		document = null;
		return propResult;
	}

	public static String getConfigProperty(String claveProp) {
		String propResult = null;

		propResult = getConfigProp().getProperty(claveProp);
		return propResult;
	}

	public static void setServiceName(String serviceName) {
		ConfigurationServ.serviceName = serviceName;
	}

	public static String getServiceName() {
		return serviceName;
	}

	public static void setParamsSystem(String key, String value) {
		if (ConfigurationServ.paramsSystem == null)
			ConfigurationServ.paramsSystem = new ConcurrentHashMap<String, String>();
		getParamsSystem().put(key, value);
	}

	public static Map<String, String> getParamsSystem() {
		return paramsSystem;
	}

	public static synchronized ConnectionFactory initConnectionFactory(String queueSioc) {
		// configuracion e inicializacion para colas
		if (connectionFactory == null) {
			// connectionFactory =
			// BeanContextFactory.getInstance().getPooledConnectionFactory();
			try {
				Properties props = new Properties();
				// para el pool
				props.setProperty("maxConnections", "10");
				props.setProperty("maximumActive", "5");

				props.setProperty("brokerURL", gob.bcb.core.jms.Constants.getUrlBroker());
				props.setProperty("dispatchAsync", "false");
				props.setProperty("prefetchPolicy.durableTopicPrefetch", "2");
				props.setProperty("prefetchPolicy.optimizeDurableTopicPrefetch", "2");
				props.setProperty("prefetchPolicy.queuePrefetch", "10");
				props.setProperty("prefetchPolicy.topicPrefetch", "100");
				props.setProperty("useAsyncSend", "false");
				props.setProperty("useCompression", "false");
				props.setProperty("copyMessageOnSend", "false");
				props.setProperty("closeTimeout", "10000");
				props.setProperty("alwaysSessionAsync", "false");
				props.setProperty("optimizeAcknowledge", "false");
				// props.setProperty("statsEnabled",
				// Boolean.toString(isStatsEnabled()));
				props.setProperty("alwaysSyncSend", "false");
				// props.setProperty("producerWindowSize",
				// Integer.toString(getProducerWindowSize()));
				// props.setProperty("sendTimeout", "60000");
				props.setProperty("sendAcksAsync", "true");
				// props.setProperty("auditDepth",
				// Integer.toString(getAuditDepth()));
				// props.setProperty("auditMaximumProducerNumber",
				// Integer.toString(getAuditMaximumProducerNumber()));
				// props.setProperty("checkForDuplicates",
				// Boolean.toString(isCheckForDuplicates()));
				// props.setProperty("messagePrioritySupported",
				// Boolean.toString(isMessagePrioritySupported()));

				// PooledConnectionFactory pooledConnectionFactory =
				// DaoFactory.getInstance().getPooledConnectionFactory();
				// connectionFactory = pooledConnectionFactory;
				connectionFactory = JMSConnectionHandler.initFromPropertiesContext(props);
				log.info("ConnectionFactory creado mediante propiedades");
			} catch (Exception e) {
				log.error("Error al crear ConnectionFactory mediante propiedades " + e.getMessage(), e);
				throw new RuntimeException(e);
			}

			if (connectionFactory == null) {
				throw new RuntimeException("no se pudo recuperar coneccion JMS. comunique a sistemas");
			}

			log.info("CONNECTION_FACTORY_ATTRIBUTE seteado en servletContext " + connectionFactory);
		}

		return connectionFactory;
	}

	public static Properties getConfigProp() {
		return configProp;
	}

	public static ConnectionFactory getConnectionFactory() {
		return connectionFactory;
	}

	public static void setConnectionFactory(ConnectionFactory connectionFactory) {
		ConfigurationServ.connectionFactory = connectionFactory;
	}

	public String pathDbConfig() {
		return pathDbConfig;
	}

	public static void setPathDbConfig(String pathDbConfig) {
		ConfigurationServ.pathDbConfig = pathDbConfig;
	}
}
