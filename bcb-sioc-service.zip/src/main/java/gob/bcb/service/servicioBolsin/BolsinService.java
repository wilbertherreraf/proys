/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-service-prototype
 * gob.bcb.service.prototype.server.BolsinService
 * 13/05/2011 - 13:58:49
 * Creado por scriales
 */
package gob.bcb.service.servicioBolsin;

import gob.bcb.bpm.pruebaCU.FactoryDao;
import gob.bcb.bpm.pruebaCU.SocBolsin;
import gob.bcb.bpm.pruebaCU.SocBolsinDao;
import gob.bcb.bpm.pruebaCU.SocComprobante;
import gob.bcb.bpm.pruebaCU.SocComprobanteDao;
import gob.bcb.bpm.pruebaCU.SocFacturas;
import gob.bcb.bpm.pruebaCU.SocFacturasDao;
import gob.bcb.bpm.pruebaCU.SocRengscomp;
import gob.bcb.bpm.pruebaCU.SocRengscompDao;
import gob.bcb.core.persist.EntityUserTransactionBolsin;
import gob.bcb.core.persist.EntityUserTransactionCoin;
import gob.bcb.core.persist.EntityUserTransactionSioc;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.service.commons.UserSessionHolder;
import gob.bcb.service.commons.handlerdb.DBSourceHandlerFactory;
import gob.bcb.service.qnatives.coin.CalendarioComun;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.exception.GenericJDBCException;
import org.joda.time.DateTime;

/**
 * ServiceWorkerProducer del prototipo, reemplazar por el del servicio.
 * 
 * @author scriales
 * 
 */
public class BolsinService extends EntityUserTransactionBolsin {
	private static final Log log = LogFactory.getLog(BolsinService.class);
	private FactoryDao factoryDao;

	/**
	 * Constructor
	 */
	public BolsinService() {
		// setNameSessionFactory(Constants.PROP_ALIAS_BOLSIN);
		// log.info("nuevo BolsinService ha sido creado." +
		// getNameSessionFactory());
		// factoryDao = new FactoryDao();
		// Map<String, Object> mapa = new HashMap<String, Object>();
		//
		// CambioDao cambioDao = new CambioDao();
		// mapa.put("CambioDao", cambioDao);
		// TablaCotizDao tablaCotizDao = new TablaCotizDao();
		// mapa.put("TablaCotizDao", tablaCotizDao);
		//
		// for (Iterator<?> i = mapa.keySet().iterator(); i.hasNext();) {
		// String key = (String) i.next();
		// HibernateDaoSupport hibernateDaoSupport =(HibernateDaoSupport)
		// mapa.get(key);
		// hibernateDaoSupport.setSessionFactory(getSessionFactory());
		// hibernateDaoSupport.getHibernateTemplate().setAllowCreate(false);
		// }
		// factoryDao.setDaos(mapa);
	}

	// public BolsinService(SessionFactory sessionFactory) {
	// super(sessionFactory);
	// }

	public void setFactoryDao(FactoryDao factoryDao) {
		this.factoryDao = factoryDao;
		// this.factoryDao.initFactory(getSessionFactory());
	}

	public FactoryDao getFactoryDao() {
		return factoryDao;
	}

	public void doPublicar(Date fecha) throws RuntimeException {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rs;
		boolean publicado = false;
		Calendar fechaAl = GregorianCalendar.getInstance();
		fechaAl.setTime(fecha);
		String strFecha = " mdy(" + (fechaAl.get(Calendar.MONTH) + 1) + "," + fechaAl.get(Calendar.DAY_OF_MONTH) + "," + fechaAl.get(Calendar.YEAR)
				+ ") ";
		try {
			conn = DBSourceHandlerFactory.Factory.newInstance(Constants.PROP_ALIAS_SIOC).getHandler().getConnection();
			conn.setAutoCommit(false);
			log.info("Inicio de publicacion de tabla de cotizaciones " + strFecha);
			stmt = conn.prepareCall("execute procedure p_publicartc(" + strFecha + ", 1, '" + UserSessionHolder.get(Constants.AUDIT_USER_ESTACION)
					+ "', '" + UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID) + "')");
			stmt.execute();
			conn.commit();
			publicado = true;
			log.info("==>Tabla cotizaciones publicada " + strFecha);
		} catch (GenericJDBCException e) {
			log.error(e.getMessage(), e);
			StringBuilder sb = new StringBuilder();
			int count = 0;
			for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
				if (cause instanceof SQLException) {
					count++;
					sb.append(cause.getMessage());
					sb.append(" , ");
				}
			}
			throw new RuntimeException((count > 0 ? sb.toString().replace(", null ,", "") : e.getMessage().replace(", null ,", "")));
		} catch (Exception e) {
			StringBuilder sb = new StringBuilder();
			int count = 0;
			for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
				if (cause instanceof SQLException) {
					count++;
					sb.append(cause.getMessage());
					sb.append(" , ");
				}
			}
			log.error("Error al ejecutar procedimiento almacenado p_publicartc " + e.getMessage(), e);
			throw new RuntimeException((count > 0 ? sb.toString().replace(", null ,", "") : e.getMessage().replace(", null ,", "")));

		} finally {
			try {
				conn.rollback();
			} catch (SQLException e1) {
				log.warn("Error al realizar rollback de cierre", e1);
			}
			if (conn != null)
				try {
					if (!conn.isClosed()) {
						conn.close();
					}
				} catch (SQLException e) {
					log.warn("Error al realizar cerrar transaccion", e);
				}
		}
		// return 0;
	}

	public Map<String, String> adjudicar(FactoryDao factDao, boolean esAutomatico) {
		// en procesos automaticos se extrae un mapa de comprobantes generados o
		// con errores
		// en procesos manuales se lanza una excepcion al usuario
		
		log.info("Entrando a adjudicacion de bolsin: ");
		log.info("Adjudicacion es automatico: " + esAutomatico);		
		Date hoy = new Date();
		CalendarioComun calendarioComun = new CalendarioComun();
		calendarioComun.setSessionFactory(SiocCoinService.getSessionFactory());
		boolean isHabil = calendarioComun.isHabil(hoy);
		Date ultdiahabil = calendarioComun.fecHabilAntesDespuesDe(new Date(), -1);
		log.info("Fecha hoy: " + UtilsDate.stringFromDate(hoy, "dd/MM/yyyy")  + " Fecha adjudicacion. " + UtilsDate.stringFromDate(ultdiahabil, "dd/MM/yyyy"));
		
		if (!isHabil) {
			log.warn("Proceso de adjudicacion ejecutado en dia inhabil");
			throw new RuntimeException("Proceso de adjudicacion ejecutado en dia inhabil " + hoy);
		}

		List<SocBolsin> listaBolsin = gob.bcb.bpm.pruebaCU.Servicios.getSocBolsinList("'1', '2'", ultdiahabil, null, "'E','G'");

		String codigo1 = "";
		int dia = new DateTime().getDayOfMonth();
		Map<String, String> msgRepuesta = new HashMap<String, String>();
		String msgError = "";
		msgRepuesta.put("00001", "Fecha Bolsin: " + UtilsDate.stringFromDate(ultdiahabil, "dd/MM/yyyy"));
		msgRepuesta.put("00002", "Fecha Adjudicacion: " + UtilsDate.stringFromDate(hoy, "dd/MM/yyyy"));		
		
		for (SocBolsin socBolsin : listaBolsin) {
			EntityUserTransactionSioc.begin();
			SocBolsinDao bolsinDao = (SocBolsinDao) factDao.getDao("socBolsinDao");				
			SocBolsin solic = bolsinDao.getBySocCodigo(socBolsin.getSocCodigo());			
			String msgSolicitud = "";
			try {

				log.info("Inicio proceso Adjudicacion solicitud " + solic.toString());
				String query = "select cpb_codigo " + "from soc_comprobante " + "where ope_codigo = '" + solic.getSocCodigo() + "' "
						+ "and cpb_dia = " + dia + " and cpb_gestion = " + new DateTime().getYear() + " and cpb_periodo = "
						+ new DateTime().getMonthOfYear() + "  ";
				List<Map<String, Object>> resultado = gob.bcb.bpm.pruebaCU.Servicios.ejecutarQuery(query, "cpb_codigo".split(","));
				if (resultado.size() == 1) {
					for (Map<String, Object> res1 : resultado) {
						codigo1 = (String) res1.get("cpb_codigo");
					}
				} else {
					msgError = "No existe registro de comprobante " + solic.getSocCodigo();
					msgSolicitud = "Solicitud: " + solic.getCorr() + " NO GENERADO, Error: " + msgError;
					throw new RuntimeException(msgError);
				}

				SocComprobanteDao socCompDao = (SocComprobanteDao) factDao.getDao("socComprobanteDao");
				SocComprobante comp = (SocComprobante) socCompDao.getComprobante(codigo1);
				if (comp == null) {
					msgError = "Comprobante inexistente en sioc " + codigo1 + " comunique a sistemas.";
					log.error(msgError);
					throw new RuntimeException(msgError);
				}

				SocRengscompDao socRengscompDao = (SocRengscompDao) factDao.getDao("socRengscompDao");
				List<SocRengscomp> rengs = socRengscompDao.getRenglones(comp.getCpbCodigo());

				SocFacturasDao socFacturasDao = (SocFacturasDao) factDao.getDao("socFacturasDao");
				List<SocFacturas> facts = socFacturasDao.getFacturas(comp.getCpbCodigo());
				flush();
				Map<String, Object> mapaParametros2 = new HashMap<String, Object>();
				mapaParametros2.put("consulta", "crear");
				mapaParametros2.put("comp", comp);
				mapaParametros2.put("rengs", rengs);
				mapaParametros2.put("facts", facts);

				log.info("Llamando al servicio de coin: crear comprobante");
				Map<String, Object> mapaResultado2;

				SiocCoinService siocCoinService = new SiocCoinService();
				mapaResultado2 = siocCoinService.executeTask(mapaParametros2);
				String nroComprob = (String) mapaResultado2.get("comp");

				if (nroComprob != null && !nroComprob.equals("") && !nroComprob.equals("0000000")) {
					if (!nroComprob.equals("9999999")) {
						log.info("Comprobante coin creado: " + nroComprob);

						solic.setClaEstado('5');
						bolsinDao.saveOrUpdate(solic);
						msgSolicitud = "Solicitud: " + solic.getCorr() + " generado satisfactoriamente con comprobante " + nroComprob;
					} else {
						log.error("Codigo de comprobante no esperado " + nroComprob + " resultado del proceso siocCoinService.executeTask(crear)");
						msgSolicitud = "Solicitud: " + solic.getCorr() + " NO GENERADO, Error: Codigo de comprobante no esperado " + nroComprob;
						throw new RuntimeException("Codigo de comprobante no esperado " + nroComprob
								+ " resultado del proceso siocCoinService.executeTask(crear)");
						// mapaRespuesta.put("estado", ERROR);
					}
				} else {
					msgError = "Codigo de comprobante inesperado " + nroComprob + " resultado del proceso siocCoinService.executeTask(crear)";
					log.error(msgError);
					msgSolicitud = "Solicitud: " + solic.getCorr() + " NO GENERADO, Error: Codigo de comprobante no esperado " + nroComprob;
					throw new RuntimeException(msgError);
				}

			} catch (Exception e) {
				log.error(e.getMessage(), e);
				if (!esAutomatico) {
					// throw new RuntimeException(e.getMessage());
				}
				log.error("Proceso automatico: Hubo un error al generar comprobante de solicitud " + solic.getSocCodigo()
						+ " se realiza un rollback " + e.getMessage());
				EntityUserTransactionCoin.rollbackTransaction();
				EntityUserTransactionSioc.rollbackTransaction();
				msgSolicitud = "Solicitud: " + solic.getCorr() + " NO GENERADO, Error: " + e.getMessage();
			}
			msgRepuesta.put(solic.getSocCodigo(), msgSolicitud);
		}
		// si no existe registros a procesar se sale del proceso
		if (listaBolsin.size() == 0) {
			msgError = "Proceso de adjudicacion de fecha sin solicitudes registradas.";
			log.info(msgError);
			if (!esAutomatico) {
				// return msgRepuesta;
			}
			msgRepuesta.put("00003", msgError);
		} 
		return msgRepuesta;
	}

}
