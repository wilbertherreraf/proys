package gob.bcb.service.qnatives.coin;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import gob.bcb.core.utils.UtilsDate;

public class CalendarioComun extends HibernateDaoSupport {
	private static Logger log = Logger.getLogger(CalendarioComun.class);
	private static final String SELECT_COUNT_FERIADO = "select count(*) from feriado where fecha_feriado = ?";

	/**
	 * Determina si una fecha es habil o no
	 * 
	 * @param fecha
	 *            fecha a evaluar en contbcb
	 * @return true si es habil, falso de lo contrario
	 */
	public boolean isHabil(Date fecha) {
		boolean resp = true;

		String jsql = "select count(*) from feriado where fecha_feriado = :fecha";
		Query consulta = getSession().createSQLQuery(jsql);
		consulta.setParameter("fecha", fecha);

		Long codigo = null;
		BigDecimal maxi = BigDecimal.ZERO;
		List result = consulta.list();
		if (result.size() > 0)
			maxi = (BigDecimal) result.get(0);

		if (maxi != null) {
			codigo = Long.valueOf(maxi.toPlainString());
		} else {
			codigo = Long.valueOf(0);
		}
		
		if (codigo.compareTo(Long.valueOf(0)) == 0) {
			Calendar fec = Calendar.getInstance();
			fec.setTime(fecha);

			if (fec.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY) {
				resp = false;
			} else if (fec.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
				resp = false;
			}
		} else {
			resp = false;
		}
		log.debug("Fecha " + UtilsDate.stringFromDate(fecha, "dd/MM/yyyy") +" es habil? : " + resp);
		return resp;
	}

	/**
	 * Calcula o cuenta los d�as habiles antes(- negativo) o despues (+
	 * positivo) de una fecha
	 * 
	 * @param fecha
	 *            fecha a partir de la cual se calcula
	 * @param diasAntes
	 *            dias habiles que se debe contar si es negativo es dias antes,
	 *            positivo dias despues
	 * @return
	 */
	public Date fecHabilAntesDespuesDe(Date fecha, int diasAntes) {
		if (diasAntes == 0) {
			return fecha;
		}

		if (diasAntes > 365) {
			throw new RuntimeException("El numero de dias para calcular fecha habil antes de " + diasAntes + " dias es mayor al permitido 365.");
		}

		int diasAbs = (diasAntes < 0 ? -diasAntes : diasAntes);
		int signo = (diasAntes < 0 ? -1 : 1);

		int contDias = 1;
		int cont = 1;

		Calendar fecEval = null;
		fecEval = Calendar.getInstance();
		fecEval.setTime(fecha);

		while (cont <= diasAbs && contDias <= 365) {
			fecEval.setTime(fecha);
			fecEval.add(Calendar.DAY_OF_YEAR, signo * contDias);

			if (isHabil(fecEval.getTime())) {
				cont++;
			}
			contDias++;
		}

		if ((cont > diasAntes) && (fecEval.getTime().before(fecha) || fecEval.getTime().after(fecha))) {
			return fecEval.getTime();
		} else {
			return null;
		}
	}
}
